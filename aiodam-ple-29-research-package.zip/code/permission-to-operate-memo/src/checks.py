# -*- coding: utf-8 -*-
"""The 13 rubric criteria as code, read against the text the judge is given.

Criteria 0-9 and 12 are read from the memo renderings (PDF text + comments text).
Criteria 10 and 11 are read from the apps' db_diff.txt, which only exists when the
world ran; with no db_diff they are false, exactly as for a trial that changed nothing.
"""
import re

WEIGHTS = [10.0, 6.0, 2.0, 4.0, 2.0, 1.0, 9.0, 4.0, 1.0, 1.0, 2.0, 1.0, 1.0]


def norm(text: str) -> str:
    t = text.replace('\u00ad', '')
    t = t.replace('\ufb01', 'fi').replace('\ufb02', 'fl')
    t = re.sub(r'[-\u2010\u2011]\s*\n\s*', '-', t)      # "ride-\nthrough" -> "ride-through"
    t = re.sub(r'\s*\n\s*', ' ', t)
    t = re.sub(r'\s+', ' ', t)
    return t.strip()


def sentences(text: str):
    """Split on sentence ends, including a closing quote after the full stop and a numbered
    subsection as the next sentence ("2025. 6.2 The DER Program Office ...").  Merging two
    paragraphs into one "sentence" is what lets an unrelated clause satisfy a criterion."""
    parts = re.split(r'(?<=[.!?])["\u201d\u2019]?\s+(?=[A-Z0-9\u201c"(\[])', norm(text))
    return [p.strip() for p in parts if p.strip()]


def has_sentence(text, *groups):
    """True when one sentence contains every group: each group is a tuple of alternatives."""
    for s in sentences(text):
        low = s.lower()
        if all(any(alt.lower() in low for alt in grp) for grp in groups):
            return True
    return False


def c0(text):   # PTO cannot issue on 08/04/2025 on the record as it stands
    return has_sentence(text, ('cannot issue', 'cannot be issued'),
                        ('08/04/2025',), ('record as it stands', 'as it stands'))


def c1(text):   # RTU's only station service fed from SWBD-PV, below the POI recloser kept open before PTO
    chain = has_sentence(text, ('station service', 'station ac service'),
                         ('swbd-pv',), ('recloser',), ('only', 'sole'))
    open_ = has_sentence(text, ('recloser',), ('kept open', 'keeps the poi recloser open', 'stays open'))
    return chain and open_


def c2(text):   # TCS-02 §5 judges the display at the moment of issuance; 07/08/2025 does not carry
    carries = has_sentence(text, ('07/08/2025',), ('does not carry', 'does not extend', 'no longer carries'))
    low = norm(text).lower()
    moment = ('at the moment permission to operate' in low) and ('operator display' in low)
    holds = ('tcs-02 §5' in low)
    return carries and moment and holds


def c3(text):   # written amendment under §12.1 permitting energization before PTO, signed before 08/04/2025
    instr = has_sentence(text, ('instrument in writing', 'written amendment', 'instrument in writing signed'),
                         ('12.1',), ('energi',), ('before permission to operate',))
    when = has_sentence(text, ('instrument',), ('signed', 'signature', 'execute'), ('before 08/04/2025',))
    return instr and when


def c4(text):   # signed by DER Program Office (Contracts) and Corwyn Realty Partners
    return has_sentence(text, ('der program office (contracts)',), ('corwyn realty partners',),
                        ('signed', 'sign', 'signature'))


def c5(text):   # Distribution Operations energizes under its own switching order once the amendment permits
    return has_sentence(text, ('distribution operations',), ('switching order',), ('energi',),
                        ('once the instrument permits', 'once the instrument is signed', 'until the instrument is signed'))


def c6(text):   # per-inverter points valid only once the inverters are powered from an energized Facility
    pts = has_sentence(text, ('per-inverter', 'per inverter'), ('valid',), ('powered', 'energized'),
                       ('energized facility', 'energized facility.'))
    low = norm(text).lower()
    per_block = ('gross generation (per inverter block)' in low
                 and 'inverter/pcs block status' in low)
    bus = 'com-rtu' in low
    return pts and per_block and bus


def c7(text):   # AD-C1..AD-C5 closed during the pre-PTO energization
    return has_sentence(text, ('ad-c1',), ('ad-c5',), ('closed',), ('energi',))


def c8(text, filename_present=False, **kw):
    return bool(filename_present)


def c9(text):   # addressed to Lena Kovalchuk, SOC Shift Supervisor
    return has_sentence(text, ('lena kovalchuk',), ('soc shift supervisor', 'system operations center'))


def c10(db_diff, **kw):   # one WP in DER Program Backlog Review, PTO withheld for 08/04/2025
    if not db_diff:
        return False
    low = db_diff.lower()
    return ('der program backlog review' in low and 'corwyn' in low
            and ('08/04/2025' in low or '8/4/2025' in low)
            and ('withheld' in low or 'cannot issue' in low or 'hold' in low))


def c11(db_diff, **kw):   # WP lists Corwyn's signature of a written amendment among what has to be settled
    if not db_diff:
        return False
    low = db_diff.lower()
    return ('corwyn' in low and ('amendment' in low or '12.1' in low)
            and ('written' in low or 'instrument' in low) and ('sign' in low))


def c12(text):   # a signature block for the DER Program Office reviewing engineer (P.E.)
    low = norm(text).lower()
    block = has_sentence(text, ('reviewing engineer',), ('p.e.',), ('der program office',))
    lines = ('signature:' in low) and ('name (print):' in low)
    return block and lines


CHECKS = [
    ('c0_pto_cannot_issue', lambda t, **k: c0(t)),
    ('c1_station_service_below_recloser', lambda t, **k: c1(t)),
    ('c2_moment_of_issuance', lambda t, **k: c2(t)),
    ('c3_amendment_121', lambda t, **k: c3(t)),
    ('c4_signers', lambda t, **k: c4(t)),
    ('c5_distribution_operations', lambda t, **k: c5(t)),
    ('c6_per_inverter_powered', lambda t, **k: c6(t)),
    ('c7_ad_disconnects_closed', lambda t, **k: c7(t)),
    ('c8_file_name', lambda t, **k: c8(t, **k)),
    ('c9_addressed_to_lena', lambda t, **k: c9(t)),
    ('c10_work_package_withheld', lambda t, **k: c10(k.get('db_diff'))),
    ('c11_work_package_amendment', lambda t, **k: c11(k.get('db_diff'))),
    ('c12_signature_block_pe', lambda t, **k: c12(t)),
]


def run_text(text, filename_present=False, db_diff=None):
    out = {}
    for name, fn in CHECKS:
        try:
            out[name] = bool(fn(text, filename_present=filename_present, db_diff=db_diff))
        except Exception:
            out[name] = False
    return out


def score(res):
    return sum(WEIGHTS[i] for i, (name, _) in enumerate(CHECKS) if res.get(name)), sum(WEIGHTS)


if __name__ == '__main__':
    import sys, json
    pdf = open('/work/pto/render/Corwyn_PTO_Memo.pdf.txt', encoding='utf-8').read()
    comments = open('/work/pto/render/Corwyn_PTO_Memo_comments.txt', encoding='utf-8').read()
    text = pdf + '\n' + comments
    res = run_text(text, filename_present=True)
    for name, ok in res.items():
        print(f"{'PASS' if ok else 'FAIL'}  {name}")
    s, tot = score(res)
    print(f'score {s}/{tot}')
    json.dump(res, open('/work/pto/render/checks.json', 'w'), indent=1)
