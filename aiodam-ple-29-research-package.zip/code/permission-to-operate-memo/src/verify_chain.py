# -*- coding: utf-8 -*-
"""Second path to the decisive facts: read the record's own structured files (xlsx cells, docx
paragraphs) and assert the chain the memo rests on, without going through the text dumps."""
import re
import docx
import openpyxl

ENV = '/work/ple-dataset/tasks/permission-to-operate-memo/environment/files/'
ok = []

wb = openpyxl.load_workbook(ENV + 'Equipment/PXA-2023-0629_Corwyn_Equipment_Schedule.xlsx', data_only=True)
cells = {}
for ws in wb.worksheets:
    for row in ws.iter_rows(values_only=True):
        if row and row[0]:
            cells[str(row[0]).strip()] = ' | '.join('' if c is None else str(c) for c in row)
pp1 = cells['PP-1']; tx1 = cells['TX-1']; swbd = cells['SWBD-PV']; inv = cells['INV-C1 to INV-C5']
ok.append(('PP-1 circuit 1 feeds the RTU enclosure', 'Circuit 1: dedicated 20 A circuit to the utility RTU enclosure' in pp1))
ok.append(('PP-1 circuit 1 goes through the 1.5 kVA online UPS', 'through the 1.5 kVA online UPS in that enclosure' in pp1 and '5.5 h at the RTU load' in pp1))
ok.append(('TX-1 is fed from a 40 A two-pole breaker in SWBD-PV', 'fed from a 40 A two-pole breaker in SWBD-PV' in tx1))
ok.append(('SWBD-PV is the Facility 1,200 A switchboard', '1,200 A bus, 1,200 A main breaker' in swbd))
ok.append(('inverter control power comes from its own ac output terminals', 'control power internal, from the inverter' in inv))
ok.append(('AD-C is the inverter ac isolating device on the output circuit',
           'ac isolating device' in cells['AD-C1 to AD-C5'] and 'inverter output circuit' in cells['AD-C1 to AD-C5']))

mcs = openpyxl.load_workbook(ENV + 'Equipment/PXA-2023-0629_Corwyn_Monitoring_and_Communications_Schedule.xlsx', data_only=True)
links = {}
for ws in mcs.worksheets:
    for row in ws.iter_rows(values_only=True):
        if row and row[0]:
            links[str(row[0]).strip()] = ' | '.join('' if c is None else str(c) for c in row)
ok.append(('per-inverter points reach the RTU over COM-RTU from RS-485 port 2',
           'INV-C1 to INV-C5 RS-485 port 2, one multi-drop bus' in links['COM-RTU']
           and 'per-inverter ac power and status for SCADA' in links['COM-RTU']))
ok.append(('DAS-1 is customer monitoring on LP-2, not the RTU feed',
           'LP-2' in links['DAS-1'] and 'DAS-1' in links['DAS-1']))

agr = docx.Document(ENV + 'Contracts/ISA-Corwyn-Office-Complex_Executed_Agreement.docx')
body = '\n'.join(p.text for p in agr.paragraphs)
ok.append(('ISA 6.1 keeps the POI recloser open before PTO', 'At all other times before permission to operate the POI recloser is kept open.' in body))
ok.append(('ISA 7.2 makes live telemetry a condition of PTO', 'Live telemetry at the System Operations Center is a condition of permission to operate' in body))
ok.append(('ISA 12.1 requires a written instrument signed by both Parties', 'No term of this Agreement may be modified or waived except by an instrument in writing signed by authorized representatives of both Parties.' in body))
ok.append(('ISA 5.2 puts the RTU station service on the customer', 'the station service and communications entrance for the RTU' in body))
ok.append(('ISA 8.7 forbids equipment/settings changes without written consent', "makes no change to the Facility's equipment or settings without the Company's written consent" in body))
ok.append(('the Corwyn agreement carries NO pre-PTO backfeed term', 'backfeed' not in body.lower() and 'before permission to operate' in body))
ok.append(('Exhibit B.3 excludes DAS-1 from Company telemetry', "is not part of the Company's telemetry" in body))

halb = '\n'.join(p.text for p in docx.Document(ENV + 'Contracts/Harkwell_Ridge/Executed_ISA_Harkwell_Ridge.docx').paragraphs)
print('(Harkwell read for contrast; backfeed term present:', 'backfeed' in halb.lower(), ')')

for name, val in ok:
    print(('OK  ' if val else 'FAIL'), name)
print(f'{sum(1 for _, v in ok if v)}/{len(ok)} record facts confirmed from the structured files')
