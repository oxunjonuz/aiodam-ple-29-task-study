# -*- coding: utf-8 -*-
"""Every quoted phrase in the memo must appear verbatim in the document the memo attributes it to.

Quotations are checked against the source file itself, not against my notes about it.
"""
import re

TXT = '/work/pto/txt/'
ISA = TXT + 'Contracts__ISA-Corwyn-Office-Complex_Executed_Agreement.docx.txt'
ISASUM = TXT + 'Contracts__ISA-Corwyn-Office-Complex_Executed_Summary.pdf.txt'
HALB = TXT + 'Contracts__ISA-Halbray-Field-Site-3_Executed_Summary.pdf.txt'
TCS = TXT + 'Standards__TCS-02_Telemetry_Comms_Standard.pdf.txt'
DIS = TXT + 'Standards__DIS-01_Rev4_DER_Interconnection_Standard.pdf.txt'
EQP = TXT + 'Equipment__PXA-2023-0629_Corwyn_Equipment_Schedule.xlsx.txt'
MCS = TXT + 'Equipment__PXA-2023-0629_Corwyn_Monitoring_and_Communications_Schedule.xlsx.txt'
WT = TXT + 'Commissioning__PXA-2023-0629_Corwyn_Witness_Test_Record_WT-0629-01.pdf.txt'
LOG = TXT + 'Equipment__SOC_PTO_Hold_Log.xlsx.txt'

QUOTES = [
    ("Parallel operation begins only with the Company's written permission to operate, issued once the Company's facilities are commissioned and accepted, telemetry is live at the System Operations Center, the witness test is complete, and the authority having jurisdiction has given final approval of the customer's facilities.", ISA, 'ISA 6.2'),
    ("closed at 08:10 and opened at 15:35 locally by Distribution Operations", WT, 'WT-0629-01'),
    ("Circuit 1: dedicated 20 A circuit to the utility RTU enclosure on the POI pole, through the 1.5 kVA online UPS in that enclosure (5.5 h at the RTU load)", EQP, 'E-101 PP-1'),
    ("fed from a 40 A two-pole breaker in SWBD-PV", EQP, 'E-101 TX-1'),
    ("is the Interconnection Customer's own monitoring and is not part of the Company's telemetry", ISA, 'Exhibit B.3'),
    ("solely for the witness test", ISA, 'ISA 6.1'),
    ("At all other times before permission to operate the POI recloser is kept open.", ISA, 'ISA 6.1'),
    ("through a dedicated branch circuit backed by an uninterruptible supply sized for a minimum four (4) hour outage ride-through", TCS, 'TCS-02 3.4'),
    ("Presenting all required data points (\u00a76) as valid (not stale, not forced, not flagged bad-quality) at the SCADA operator display at the moment Permission to Operate (PTO) is issued", TCS, 'TCS-02 5(c)'),
    ("is confirmed by the SOC Shift Supervisor on shift at the time PTO is requested", TCS, 'TCS-02 5'),
    ("PTO shall not be issued to any in-scope DER site until \u00a75 is satisfied", TCS, 'TCS-02 5'),
    ("No PTO without live telemetry \u2014 TCS-02 \u00a75 (no interim provision)", LOG, 'SOC PTO-Hold Log'),
    ("Requests for early, provisional, partial, or conditional operation are refused on the same basis and returned to the DER Program Office", LOG, 'SOC PTO-Hold Log'),
    ("Live telemetry at the System Operations Center is a condition of permission to operate", ISA, 'ISA 7.2'),
    ("individually per block", TCS, 'TCS-02 6.1'),
    ("Gross generation (per inverter block)", TCS, 'TCS-02 6.1'),
    ("Inverter/PCS block status", TCS, 'TCS-02 6.1'),
    ("INV-C1 to INV-C5 RS-485 port 2, one multi-drop bus", MCS, 'E-401 COM-RTU'),
    ("per-inverter ac power and status for SCADA", MCS, 'E-401 COM-RTU'),
    ("control power internal, from the inverter's own ac output terminals", EQP, 'E-101 INV-C1 to INV-C5'),
    ("reported with the communications-lost flag until fresh source values are acquired", TCS, 'TCS-02 6.3'),
    ("No term of this Agreement may be modified or waived except by an instrument in writing signed by authorized representatives of both Parties.", ISA, 'ISA 12.1'),
    ("On the interconnection customer's written request, the Company may energize the customer's facilities from the feeder for construction and commissioning power before permission to operate", HALB, 'ISA-Halbray summary'),
    ("Distribution Operations performs the switching for a backfeed under its own switching order", HALB, 'ISA-Halbray summary'),
    ("for Alleniom Utilities by the DER Program Office (Contracts) and for Corwyn Realty Partners", ISASUM, 'Corwyn executed summary'),
    ("Modifications to protective schemes, telemetry endpoints, equipment models within the same nameplate rating, and administrative items that do not alter capacity or POI are handled under the change-order provisions of the executed ISA and are not subject to this section", DIS, 'DIS-01 7'),
    ("ac isolating device", EQP, 'E-101 AD-C'),
    ("the inverter output circuit", EQP, 'E-101 AD-C'),
    ("as specified in the Company's construction package", ISA, 'ISA 5.2'),
]


def norm(t):
    t = t.replace('\u2019', "'").replace('\u2018', "'").replace('\u201c', '"').replace('\u201d', '"')
    t = re.sub(r'[-\u2010\u2011]\s*\n\s*', '-', t)
    t = re.sub(r'\s*\n\s*', ' ', t)
    return re.sub(r'\s+', ' ', t)


def check(memo_text):
    memo = norm(memo_text).replace(' ', '')
    rows = []
    for quote, path, label in QUOTES:
        src = norm(open(path, encoding='utf-8', errors='replace').read()).replace(' ', '')
        q = norm(quote).replace(' ', '')
        rows.append({'label': label, 'in_source': q in src, 'in_memo': q in memo, 'quote': quote[:60]})
    return rows


if __name__ == '__main__':
    memo = open('/work/pto/render/Corwyn_PTO_Memo.pdf.txt', encoding='utf-8').read()
    rows = check(memo)
    bad = [r for r in rows if not r['in_source']]
    notin = [r for r in rows if not r['in_memo']]
    for r in rows:
        print(('OK  ' if r['in_source'] and r['in_memo'] else 'BAD '), r['label'], '|', r['quote'])
    print(f"{len(rows)-len(bad)}/{len(rows)} quotes found in their source; "
          f"{len(rows)-len(notin)}/{len(rows)} present in the rendered memo")
