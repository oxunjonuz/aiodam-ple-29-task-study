# -*- coding: utf-8 -*-
"""Build Corwyn_PTO_Memo.docx from the record as it stands at 07/14/2025."""
import docx
from docx.shared import Pt, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH

OUT = '/work/pto/out/Corwyn_PTO_Memo.docx'

HEAD = [
    ('ALLENIOM UTILITIES — DER PROGRAM OFFICE', True, 12),
    ('4200 Veldmere Boulevard, Halston, Alleron 01HA · (612) 555-0100 · alleniom.com', False, 9),
]

BLOCKS = [
    ('title', 'MEMORANDUM'),
    ('kv', ('To:', 'Lena Kovalchuk, SOC Shift Supervisor, System Operations Center')),
    ('kv', ('From:', 'DER Program Office — reviewing engineer (P.E.); signature block at Section 8')),
    ('kv', ('Date:', '07/14/2025')),
    ('kv', ('Subject:', 'Permission to Operate for Corwyn Office Complex PV (PXA-2023-0629): whether it can issue on 08/04/2025')),
    ('kv', ('References:', 'Interconnection Service Agreement ISA-Corwyn-Office-Complex, executed 09/12/2024; Corwyn Realty Partners\u2019 permission-to-operate request of 07/10/2025; the record as it stands at 07/14/2025')),
    ('kv', ('Copy:', 'DER Program Office \u2014 Contracts; Commissioning, DER Program Office')),

    ('h', '1. Determination'),
    ('p', 'Permission to Operate cannot issue on 08/04/2025 on the record as it stands. The bar is the telemetry condition, not the equipment: the Facility cannot be energized before Permission to Operate under the agreement as executed, and the Company\u2019s RTU takes its only station service from the Facility\u2019s own 480 V switchboard. While the POI recloser is held open before Permission to Operate, the RTU has no station service and does not present valid points at the SCADA operator display \u2014 which is what TCS-02 \u00a75 requires at the moment Permission to Operate is issued.'),
    ('p', 'That answer turns on the record as it stands and not on the calendar: the record holds no event between 07/14/2025 and 08/04/2025 that would put station power on the RTU or valid points on the operator display. The bar can be removed, and the cure is capable of being completed before 08/04/2025, but only by an instrument in writing signed by authorized representatives of both Parties under Section 12.1 of the agreement, followed by an energization of the Facility by Distribution Operations and a fresh confirmation by the System Operations Center at the moment of issuance. None of that is done, none of it is required of either Party by the record, and the Office cannot do it for them. What has to be done, by whom, and whether it can be done before 08/04/2025 is set out at Section 4.'),

    ('h', '2. The record as it stands'),
    ('p', '2.1 The agreement. ISA-Corwyn-Office-Complex was executed 09/12/2024 for 700 kW (ac) on feeder ALN-072, five Vexlar VX-140C inverters of 140 kW each at 480 V. Section 6.2 states the five conditions of Permission to Operate: \u201cParallel operation begins only with the Company\u2019s written permission to operate, issued once the Company\u2019s facilities are commissioned and accepted, telemetry is live at the System Operations Center, the witness test is complete, and the authority having jurisdiction has given final approval of the customer\u2019s facilities.\u201d'),
    ('p', '2.2 Four of the five are satisfied on the record. The commissioning checklist CX-CW-01 (07/14/2025) records the RTU installed and its end-to-end point-to-point test accepted by SCADA/EMS Engineering (M. Deele) on 07/08/2025, and the POI recloser site acceptance items 1 to 7 accepted in writing by Distribution Protection Engineering (N. Achterberg, P.E.) on 07/08/2025. Witness test record WT-0629-01, dated 07/08/2025, records every test point passed and is signed by the witness engineer (M. Halbrook, P.E.); parallel operation for the test ran from 08:10 to 15:35 under Distribution Operations switching order DO-2025-0677, with the POI recloser \u201cclosed at 08:10 and opened at 15:35 locally by Distribution Operations\u201d. The City of Wrenford gave final approval under permit WEP-25-0317 on 07/02/2025. Revenue meter RM-0629 was set and tested by Alleniom Metering with its registers verified on 07/08/2025.'),
    ('p', '2.3 The fifth condition \u2014 telemetry live at the System Operations Center \u2014 is not satisfied and does not become satisfied by the passage of time to 08/04/2025. That is what stands in the way.'),

    ('h', '3. What stands in the way'),
    ('p', '3.1 The RTU\u2019s only station service is fed from SWBD-PV, below the POI recloser. The equipment schedule for the site (drawing E-101 Rev C) gives PP-1 \u201cCircuit 1: dedicated 20 A circuit to the utility RTU enclosure on the POI pole, through the 1.5 kVA online UPS in that enclosure (5.5 h at the RTU load)\u201d. PP-1 is fed from the auxiliary transformer TX-1, 15 kVA, 480 V to 120/240 V, which is \u201cfed from a 40 A two-pole breaker in SWBD-PV\u201d. SWBD-PV is the Facility\u2019s own 480Y/277 V switchboard with its 1,200 A main breaker; it is fed through the step-up transformer T-1, 750 kVA, and the primary switch PSW-1 from the 13.2 kV conductors that run from the Point of Interconnection (Exhibit A of the agreement). There is no other source for the RTU. The customer\u2019s monitoring cabinet DAS-1 is fed from office building panel LP-2 circuit 14, but Exhibit B.3 of the agreement states that DAS-1 \u201cis the Interconnection Customer\u2019s own monitoring and is not part of the Company\u2019s telemetry\u201d.'),
    ('p', '3.2 Before Permission to Operate the agreement keeps the POI recloser open. Section 6.1 permits the Company to place the Facility in parallel \u201csolely for the witness test\u201d and provides: \u201cAt all other times before permission to operate the POI recloser is kept open.\u201d The witness test is over: the recloser was opened at 15:35 on 07/08/2025. With the recloser open, T-1, SWBD-PV, TX-1 and PP-1 are dead, and the RTU is on its uninterruptible supply only. At 5.5 h at the RTU load that supply carried the RTU to about 21:05 on 07/08/2025 (my arithmetic from the two figures on E-101: 15:35 plus 5.5 h); since then the RTU has had no station service. TCS-02 \u00a73.4 requires the customer to provide that station AC service \u201cthrough a dedicated branch circuit backed by an uninterruptible supply sized for a minimum four (4) hour outage ride-through\u201d; a 5.5 h supply meets that requirement, but a ride-through supply is not a station source, and the two together do not give continuous telemetry across the weeks between the witness test and the date requested.'),
    ('p', '3.3 The System Operations Center\u2019s confirmation of 07/08/2025 does not carry to 08/04/2025. TCS-02 \u00a75(c) defines live telemetry as \u201cPresenting all required data points (\u00a76) as valid (not stale, not forced, not flagged bad-quality) at the SCADA operator display at the moment Permission to Operate (PTO) is issued\u201d, states that compliance with \u00a75 \u201cis confirmed by the SOC Shift Supervisor on shift at the time PTO is requested\u201d, and that \u201cPTO shall not be issued to any in-scope DER site until \u00a75 is satisfied\u201d. The commissioning checklist records the SOC confirmation by L. Kovalchuk on 07/08/2025 \u2014 inside the witness-test window, when the recloser was closed and the RTU was on station power. That entry is a statement about the operator display on 07/08/2025; \u00a75(c) judges the operator display at the moment of issuance. The SOC PTO-Hold Log (DER-EQP-SOC-PTOH, as of 07/14/2025) states the position in terms: \u201cNo PTO without live telemetry \u2014 TCS-02 \u00a75 (no interim provision)\u201d, and \u201cRequests for early, provisional, partial, or conditional operation are refused on the same basis and returned to the DER Program Office\u201d. The agreement says the same: \u00a77.2, \u201cLive telemetry at the System Operations Center is a condition of permission to operate\u201d, and DIS-01 Rev 4 \u00a76 likewise.'),
    ('p', '3.4 Powering the RTU alone would not satisfy \u00a75. TCS-02 \u00a76.1 requires values \u201cindividually per block\u201d, among them \u201cGross generation (per inverter block)\u201d and \u201cInverter/PCS block status\u201d. On this site those values reach the RTU only over COM-RTU, which the monitoring and communications schedule (drawing E-401 Rev C) gives as \u201cINV-C1 to INV-C5 RS-485 port 2, one multi-drop bus\u201d to the RTU serial port for \u201cper-inverter ac power and status for SCADA\u201d. Each VX-140C takes its \u201ccontrol power internal, from the inverter\u2019s own ac output terminals\u201d (E-101), so an inverter that is not energized on its ac side is dead and reports nothing. TCS-02 \u00a76.3 requires values held during a loss to be \u201creported with the communications-lost flag until fresh source values are acquired\u201d, and \u00a75(c) admits only valid points. So the per-inverter points are valid at issuance only once the inverters are powered from an energized Facility \u2014 not merely once the RTU is powered.'),

    ('h', '4. What has to be done about it, by whom, and whether it can be done before 08/04/2025'),
    ('p', '4.1 A written instrument under Section 12.1 permitting energization of the Facility before Permission to Operate. Section 12.1 provides: \u201cNo term of this Agreement may be modified or waived except by an instrument in writing signed by authorized representatives of both Parties.\u201d Section 6.1 permits parallel operation before Permission to Operate solely for the witness test and keeps the POI recloser open at all other times, and the Corwyn agreement contains no pre-PTO backfeed term. The program record shows what such a term looks like: ISA-Halbray-Field-Site-3 carries one \u2014 \u201cOn the interconnection customer\u2019s written request, the Company may energize the customer\u2019s facilities from the feeder for construction and commissioning power before permission to operate\u201d, with the generating facility staying disabled and \u201cDistribution Operations performs the switching for a backfeed under its own switching order\u201d. Corwyn\u2019s agreement has no such term, so one has to be made: an instrument in writing under Section 12.1 permitting the energization of the Facility from feeder ALN-072 before Permission to Operate.'),
    ('p', '4.2 It is signed by the DER Program Office (Contracts) and by Corwyn Realty Partners. Section 12.1 asks for authorized representatives of both Parties; the executed summary records execution \u201cfor Alleniom Utilities by the DER Program Office (Contracts) and for Corwyn Realty Partners\u201d, and Nadia Ferreira-Holt, Director of Property Operations, signed the agreement for Corwyn.'),
    ('p', '4.3 The instrument can be signed before 08/04/2025, and it does not reopen the queue. The change is administrative and does not alter capacity or the point of interconnection, so it is handled under the change-order provisions of Section 12.1 and not by the withdrawal-and-reapplication path of DIS-01 \u00a77, which applies to capacity and Point of Interconnection changes and states that \u201cModifications to protective schemes, telemetry endpoints, equipment models within the same nameplate rating, and administrative items that do not alter capacity or POI are handled under the change-order provisions of the executed ISA and are not subject to this section\u201d. Two signatures, no study, no queue action; 21 calendar days run between 07/14/2025 and 08/04/2025.'),
    ('p', '4.4 Distribution Operations energizes the Facility under its own switching order. Once the instrument permits energization before Permission to Operate, Distribution Operations closes the POI recloser and energizes the Facility from feeder ALN-072 under a switching order of its own, as it did for the witness test under DO-2025-0677 and as the Halbray term describes. Until the instrument is signed, Distribution Operations cannot close the POI recloser for this purpose: \u00a76.1 keeps it open at all other times before Permission to Operate. A switching order is a matter of days and can be scheduled before 08/04/2025.'),
    ('p', '4.5 The energization has to keep the inverter ac disconnects AD-C1 to AD-C5 closed, so that the inverters are powered. Each AD-C is the inverter\u2019s \u201cac isolating device\u201d on \u201cthe inverter output circuit\u201d (E-101); an AD-C left open leaves its inverter unpowered, and its COM-RTU points would be reported communications-lost under TCS-02 \u00a76.3, which \u00a75(c) does not admit. So during the pre-PTO energization the five 225 A inverter breakers in SWBD-PV and AD-C1 to AD-C5 are closed and the inverters are powered from the energized Facility. The Facility stays out of generation by other means: each VX-140C has two dc inputs, each fused from 80 to 250 A at 1000 V dc with a load-break disconnect (Vexlar VXC-DS Rev 5), and those dc input disconnects are opened for the energization, so the inverters hold control power from their own ac terminals and report status, but have no dc source and do not export. No inverter setting is changed: \u00a78.7 of the agreement forbids changes to the Facility\u2019s equipment or settings without the Company\u2019s written consent, and the IEEE 1547-2018 Category III settings verified at the witness test stand as verified.'),
    ('p', '4.6 The System Operations Center confirms the points at the moment of issuance. When Permission to Operate is to be issued, the SOC Shift Supervisor on shift confirms at the SCADA operator display that the required points are valid (TCS-02 \u00a75, \u00a75(c)). That is a fresh confirmation and not the 07/08/2025 entry, and it is the last step: it can be given only after 4.1 to 4.5 are done.'),
    ('p', '4.7 Whether all of that can be done before 08/04/2025. The cure fits before 08/04/2025: two signatures, one switching order and one SOC confirmation inside the 21 calendar days between 07/14/2025 and 08/04/2025, with no study, no queue action and no equipment delivery in the way. Corwyn is not on the register of completed sites awaiting utility equipment (DER-EQP-COMPL Rev 3) because its RTU and POI recloser are installed and accepted. But nothing in the record requires either Party to sign, and the Office cannot give the date for them. If the Parties execute the instrument, and Distribution Operations energizes the Facility, and the SOC Shift Supervisor confirms the points at the moment of issuance, all of that can fall inside the 21 days and the telemetry condition is then satisfied on 08/04/2025. If any of it is not done, the condition is not satisfied on that date and Permission to Operate cannot issue.'),
    ('p', '4.8 One alternative is not open on this record. Moving the RTU\u2019s station service to a supply that is not fed through the Facility \u2014 the office building panel, as DAS-1 has \u2014 would be a change to the interconnection facilities the customer provides under \u00a75.2 \u201cas specified in the Company\u2019s construction package\u201d, and \u00a78.7 requires the Company\u2019s written consent for a change to the Facility\u2019s equipment. No such request is on file, and it would not be the shorter route to 08/04/2025. The instrument at 4.1 is the path the record supports.'),

    ('h', '5. What this memo does not cover'),
    ('p', 'Four matters are under separate review and are not assessed here: the installation, configuration and commissioning tests of the Company\u2019s RTU and POI recloser (SCADA/EMS Engineering and Distribution Protection Engineering); the POI recloser\u2019s settings and the protection coordination study behind them (Distribution Protection Engineering, which issued them and keeps them outside these records); the site\u2019s queue position (Interconnection Studies, under the weekly queue reports); and the system impact study and its conditions (the DER Planning Group, which keeps them outside these records). Nothing else is under separate review. Apart from the telemetry condition set out above, nothing else on the record stands in the way of Permission to Operate.'),
    ('p', 'For the record, the SOC PTO-Hold Log as of 07/14/2025 carries seven sites held on telemetry grounds; Corwyn Office Complex PV is not among them, its request of 07/10/2025 having been referred to this Office before issuance. This determination would be the basis of its entry.'),

    ('h', '6. Recommended action'),
    ('p', '6.1 The System Operations Center holds Permission to Operate for 08/04/2025 and records the hold on the PTO-Hold Log.'),
    ('p', '6.2 The DER Program Office (Contracts) prepares the Section 12.1 instrument with Corwyn Realty Partners for signature, and the Parties execute it before 08/04/2025.'),
    ('p', '6.3 On execution, Distribution Operations schedules the energization switching order for the Facility from feeder ALN-072, with AD-C1 to AD-C5 closed and the dc input disconnects at each inverter open.'),
    ('p', '6.4 On completion of the energization, the SOC Shift Supervisor confirms the points valid at the SCADA operator display at the moment of issuance, and Permission to Operate may issue.'),
    ('p', '6.5 The determination and the items at 6.1 to 6.4, including the signature of the Section 12.1 instrument by Corwyn Realty Partners, are to be settled before Permission to Operate and are recorded in one work package for the site in the DER Program Backlog Review project.'),

    ('h', '7. Basis of this memo'),
    ('p', 'This memo works from the record as it stands at 07/14/2025: ISA-Corwyn-Office-Complex and its executed summary; the site equipment schedule (E-101 Rev C), the monitoring and communications schedule (E-401 Rev C) and the Vexlar VX-C series data sheet (VXC-DS Rev 5); TCS-02 Rev 1, DIS-01 Rev 4 and the APUC-filed tariff \u00a712; the commissioning checklist CX-CW-01, the witness test record WT-0629-01, the SOC PTO-Hold Log, the register of completed sites awaiting utility equipment (DER-EQP-COMPL Rev 3), the active queue report of 07/14/2025 and the contact directory; the City of Wrenford permit WEP-25-0317 and its final approval; the Corwyn request of 07/10/2025; and, for comparison of the pre-PTO energization term, ISA-Halbray-Field-Site-3.'),

    ('h', '8. Signature'),
    ('p', 'Reviewed and submitted for signature for the DER Program Office.'),
    ('sig', 'Signature: ______________________________________     Date: ________________'),
    ('sig', 'Name (print): ___________________________________, P.E.'),
    ('sig', 'Reviewing Engineer (P.E.), DER Program Office, Alleniom Utilities'),
]

def build():
    d = docx.Document()
    sec = d.sections[0]
    sec.left_margin = Inches(1.0); sec.right_margin = Inches(1.0)
    sec.top_margin = Inches(0.9); sec.bottom_margin = Inches(0.9)
    style = d.styles['Normal']
    style.font.name = 'Calibri'; style.font.size = Pt(10.5)
    style.paragraph_format.space_after = Pt(4)
    for text, bold, size in HEAD:
        p = d.add_paragraph()
        r = p.add_run(text); r.bold = bold; r.font.size = Pt(size)
        p.paragraph_format.space_after = Pt(1)
    for kind, payload in BLOCKS:
        if kind == 'title':
            p = d.add_paragraph(); r = p.add_run(payload); r.bold = True; r.font.size = Pt(13)
            p.paragraph_format.space_before = Pt(8); p.paragraph_format.space_after = Pt(6)
        elif kind == 'kv':
            label, value = payload
            p = d.add_paragraph()
            p.paragraph_format.space_after = Pt(1)
            r = p.add_run(label + ' '); r.bold = True
            p.add_run(value)
        elif kind == 'h':
            p = d.add_paragraph(); r = p.add_run(payload); r.bold = True; r.font.size = Pt(11)
            p.paragraph_format.space_before = Pt(8); p.paragraph_format.space_after = Pt(3)
        elif kind == 'p':
            p = d.add_paragraph(payload); p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
        elif kind == 'sig':
            p = d.add_paragraph(payload); p.paragraph_format.space_after = Pt(2)
    d.save(OUT)
    print('saved', OUT)

if __name__ == '__main__':
    build()
