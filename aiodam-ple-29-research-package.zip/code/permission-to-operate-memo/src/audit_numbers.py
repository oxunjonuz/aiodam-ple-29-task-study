# -*- coding: utf-8 -*-
"""Every number in the memo must be either in the record or a declared computation of mine.

Not a phrase search: the question asked of each token is whether the record contains that
number at all.  Identifiers (ISA-Corwyn-Office-Complex, TCS-02, DO-2025-0677, E-101, ...) are
checked as whole strings against the corpus.
"""
import json
import os
import re

CORPUS_DIR = '/work/pto/txt'

# numbers I computed, with the arithmetic that produced them
DERIVED = {
    '21': 'calendar days from 07/14/2025 to 08/04/2025',
    '21:05': '15:35 (witness test recloser opened) + 5.5 h (UPS at the RTU load, E-101)',
}

SECTION_NUMBERS = {f'{a}.{b}' for a in range(1, 9) for b in range(0, 9)}
SECTION_NUMBERS |= {str(i) for i in range(1, 9)}


def norm(text):
    t = re.sub(r'[-\u2010\u2011]\s*\n\s*', '', text)
    t = re.sub(r'\s*\n\s*', ' ', t)
    return re.sub(r'\s+', ' ', t)


def corpus():
    parts = []
    for name in sorted(os.listdir(CORPUS_DIR)):
        if name.endswith('.json'):
            continue
        parts.append(norm(open(os.path.join(CORPUS_DIR, name), encoding='utf-8', errors='replace').read()))
    return ' \n '.join(parts)


ID_RE = re.compile(r'[A-Za-z][A-Za-z0-9]*(?:[-/][A-Za-z0-9.]+)+')
NUM_RE = re.compile(r'\d[\d,]*(?:\.\d+)?')


DATE_RE = re.compile(r'\b\d{2}/\d{2}/\d{4}\b')


def numeric_set(text):
    out = set()
    for tok in NUM_RE.findall(text):
        tok = tok.rstrip(',.')
        if not tok:
            continue
        out.add(tok)
        out.add(tok.replace(',', ''))
    for tok in DATE_RE.findall(text):
        out.add(tok)
    return out


def audit(memo_text, corpus_text):
    ids_in_memo = sorted(set(ID_RE.findall(memo_text)))
    missing_ids = [i for i in ids_in_memo if i not in corpus_text and i.rstrip('.') not in corpus_text]
    numbers = numeric_set(memo_text)
    memo_dates = set(DATE_RE.findall(memo_text))
    corpus_dates = set(DATE_RE.findall(corpus_text))
    record_numbers = numeric_set(corpus_text)
    unexplained = []
    for tok in sorted(numbers):
        if tok in record_numbers:
            continue
        if tok in DERIVED:
            continue
        if tok in SECTION_NUMBERS:
            continue
        unexplained.append(tok)
    for d in sorted(memo_dates):
        if d not in corpus_dates and d not in DERIVED:
            unexplained.append(d)
    return {
        'identifiers': len(ids_in_memo),
        'missing_identifiers': missing_ids,
        'numbers': len(numbers),
        'unexplained': unexplained,
    }


if __name__ == '__main__':
    memo = open('/work/pto/render/Corwyn_PTO_Memo.pdf.txt', encoding='utf-8').read()
    corpus_text = corpus()
    open('/work/pto/render/corpus.txt', 'w', encoding='utf-8').write(corpus_text)
    res = audit(memo, corpus_text)
    print(json.dumps(res, indent=1, ensure_ascii=False))

    # negative control: three invented numbers must be caught, and nothing else may change
    bad = memo + ' The RTU draws 47.3 A at 612 V and 1,988 kWh was logged on 09/31/2026.'
    ctl = audit(bad, corpus_text)
    caught = set(ctl['unexplained']) - set(res['unexplained'])
    print('control caught:', sorted(caught))
    assert {'47.3', '612', '1,988', '09/31/2026'} <= caught or len(caught) >= 3, caught
