# -*- coding: utf-8 -*-
"""A stand-in judge on loopback so the task's own tests/test.sh -> verify.py -> grade.py runs end to end.

It speaks the OpenAI chat-completions shape the task's grader posts to.  It does not return a constant:
it reads the candidate text out of the request and runs checks.py on it, so a document with a broken
statement comes back with that criterion failed and a reward below 1.  This is a wiring test, not an
evaluation: the stub is my reader, not an independent judge.
"""
import json
import re
import sys

from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

sys.path.insert(0, '/work/pto/src')
import checks

PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 8777
LOG = []


class Handler(BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'

    def log_message(self, fmt, *args):
        pass

    def do_POST(self):
        n = int(self.headers.get('Content-Length') or 0)
        body = self.rfile.read(n).decode('utf-8', 'replace')
        try:
            req = json.loads(body)
        except json.JSONDecodeError:
            req = {}
        text = '\n'.join(m.get('content', '') if isinstance(m.get('content'), str)
                         else ' '.join(p.get('text', '') for p in m.get('content', []) if isinstance(p, dict))
                         for m in req.get('messages', []))
        wanted = sorted({int(x) for x in re.findall(r'"index":\s*(\d+)', text)})
        # the request is "<criteria payload>\n\nReturn JSON matching this schema:\n<schema>\n<body>"
        marker = 'Return JSON matching this schema:'
        i = text.find(marker)
        if i >= 0:
            j = text.find('"additionalProperties": false}', i)
            if j > 0:
                text = text[j + len('"additionalProperties": false}'):]
        import os
        idx = len(LOG)
        os.makedirs('/work/pto/render/bodies', exist_ok=True)
        open(f'/work/pto/render/bodies/body{idx}.txt', 'w', encoding='utf-8').write(text[-3000:])
        db = text if any(i in (10, 11) for i in wanted) else None
        res = checks.run_text(text, filename_present=True, db_diff=db)
        if not wanted:
            wanted = list(range(len(checks.CHECKS)))
        grades = []
        for i in wanted:
            name = checks.CHECKS[i][0]
            ok = bool(res.get(name))
            grades.append({'index': i, 'score': 1.0 if ok else 0.0, 'passed': ok,
                           'evidence': f'stub reader: {name} {"found" if ok else "did not find"} its statement',
                           'reason': f'checks.{name} over the received candidate text'})
        LOG.append({'n_chars': len(text), 'asked': wanted, 'passed': sum(g['passed'] for g in grades)})
        payload = {'id': 'stub', 'object': 'chat.completion', 'model': 'stub-judge', 'choices': [
            {'index': 0, 'finish_reason': 'stop',
             'message': {'role': 'assistant', 'content': json.dumps({'grades': grades})}}],
            'usage': {'prompt_tokens': len(text) // 4, 'completion_tokens': 10, 'total_tokens': len(text) // 4 + 10}}
        raw = json.dumps(payload).encode()
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)
        with open('/work/pto/render/stub_log.json', 'w') as f:
            json.dump(LOG, f, indent=1)


if __name__ == '__main__':
    srv = ThreadingHTTPServer(('127.0.0.1', PORT), Handler)
    srv.serve_forever()
