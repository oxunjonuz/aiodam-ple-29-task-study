import os, subprocess, sys, json
SRC='/work/ple-dataset/tasks/permission-to-operate-memo/environment/files'
OUT='/work/pto/txt'
def sh(cmd):
    return subprocess.run(cmd, shell=True, capture_output=True, text=True)
idx={}
for root,d,fs in os.walk(SRC):
    for f in sorted(fs):
        p=os.path.join(root,f)
        rel=os.path.relpath(p,SRC)
        out=os.path.join(OUT, rel.replace('/','__')+'.txt')
        ext=f.lower().rsplit('.',1)[-1]
        txt=''
        if ext=='pdf':
            r=sh(f'pdftotext -layout {p!r} -'); txt=r.stdout
        elif ext=='docx':
            r=sh(f'/work/venv-verifier/bin/python3 -c "import docx,sys; d=docx.Document(sys.argv[1]);\nimport json\nprint(chr(10).join(p.text for p in d.paragraphs));\nprint(\'=== TABLES ===\');\n[ (print(\'--- table\'), [print(\' | \'.join(c.text.strip() for c in row.cells)) for row in t.rows]) for t in d.tables]" {p!r}')
            txt=r.stdout+r.stderr
        elif ext=='xlsx':
            r=sh(f'/work/venv-verifier/bin/python3 /work/pto/src/xl.py {p!r}')
            txt=r.stdout+r.stderr
        elif ext=='eml':
            txt=open(p, encoding='utf-8', errors='replace').read()
        else:
            txt=open(p, encoding='utf-8', errors='replace').read()
        open(out,'w').write(txt)
        idx[rel]={'txt':out,'chars':len(txt)}
json.dump(idx, open('/work/pto/txt/index.json','w'), indent=1)
print(len(idx),'files')
for k,v in sorted(idx.items()):
    print(f"{v['chars']:>8} {k}")
