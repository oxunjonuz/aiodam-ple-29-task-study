# -*- coding: utf-8 -*-
"""Mutation campaign: break one statement at a time, everywhere it is stated, render through the
task's own transform.py, and ask the reader (checks.py) whether that criterion goes red.

A mutation counts as caught only when the targeted criterion fails on the rendered text.  Every
occurrence of the statement is replaced: a fact asserted twice is not broken by breaking it once.
"""
import json
import os
import subprocess
import sys

import docx

sys.path.insert(0, '/work/pto/src')
import checks

TR = '/work/ple-dataset/tasks/permission-to-operate-memo/tests/tools/verifiers/deps/transform.py'
PY = '/work/venv-verifier/bin/python3'
SRC = '/work/pto/out/Corwyn_PTO_Memo.docx'
WORK = '/work/pto/work_mut'

MUTATIONS = [
    ('M01', 'c0_pto_cannot_issue',
     [('cannot issue on 08/04/2025 on the record as it stands', 'can issue on 08/04/2025 on the record as it stands')]),
    ('M02', 'c0_pto_cannot_issue',
     [('Permission to Operate cannot issue on 08/04/2025', 'Permission to Operate should not issue on 08/04/2025')]),
    ('M03', 'c1_station_service_below_recloser',
     [('only station service is fed from SWBD-PV, below the POI recloser',
       'only station service is fed from office building panel LP-2, below the POI recloser')]),
    ('M04', 'c1_station_service_below_recloser',
     [('the agreement keeps the POI recloser open.', 'the agreement keeps the POI recloser closed.'),
      ('the POI recloser is kept open.', 'the POI recloser may be closed.'),
      ('held open before Permission to Operate', 'held closed before Permission to Operate'),
      ('\u00a76.1 keeps it open at all other times', '\u00a76.1 keeps it closed at all other times'),
      ('keeps the POI recloser open at all other times', 'keeps the POI recloser closed at all other times')]),
    ('M05', 'c2_moment_of_issuance', [('does not carry to 08/04/2025', 'does carry to 08/04/2025')]),
    ('M06', 'c2_moment_of_issuance',
     [('at the moment Permission to Operate is issued', 'at the time of the witness test'),
      ('at the moment Permission to Operate (PTO) is issued', 'at the time of the witness test')]),
    ('M07', 'c3_amendment_121',
     [('instrument in writing under Section 12.1 permitting the energization',
       'instrument in writing under Section 6.2 permitting the energization')]),
    ('M08', 'c3_amendment_121',
     [('The instrument can be signed before 08/04/2025', 'The instrument can be signed after 08/04/2025'),
      ('the Parties execute it before 08/04/2025', 'the Parties execute it after 08/04/2025'),
      ('capable of being completed before 08/04/2025', 'capable of being completed after 08/04/2025')]),
    ('M09', 'c4_signers',
     [('It is signed by the DER Program Office (Contracts) and by Corwyn Realty Partners.',
       'It is signed by the DER Program Office (Contracts) alone.'),
      ('for Alleniom Utilities by the DER Program Office (Contracts) and for Corwyn Realty Partners',
       'for Alleniom Utilities by the DER Program Office (Contracts) alone'),
      ('instrument with Corwyn Realty Partners for signature', 'instrument for signature')]),
    ('M10', 'c5_distribution_operations',
     [('Once the instrument permits energization before Permission to Operate, Distribution Operations closes',
       'Distribution Operations closes')]),
    ('M11', 'c6_per_inverter_powered',
     [('So the per-inverter points are valid at issuance only once the inverters are powered from an energized '
       'Facility \u2014 not merely once the RTU is powered.',
       'So the per-inverter points are valid at issuance once the RTU is powered.')]),
    ('M12', 'c6_per_inverter_powered', [('Gross generation (per inverter block)', 'Gross generation')]),
    ('M13', 'c7_ad_disconnects_closed',
     [('AD-C1 to AD-C5 closed', 'AD-C1 to AD-C5 open'), ('AD-C1 to AD-C5 are closed', 'AD-C1 to AD-C5 are open')]),
    ('M14', 'c9_addressed_to_lena',
     [('Lena Kovalchuk, SOC Shift Supervisor, System Operations Center',
       'Meera Vellanki, Manager, Interconnection Studies')]),
    ('M15', 'c9_addressed_to_lena',
     [('Lena Kovalchuk, SOC Shift Supervisor, System Operations Center',
       'Lena Kovalchuk, Manager, Interconnection Studies')]),
    ('M16', 'c12_signature_block_pe',
     [('Reviewing Engineer (P.E.), DER Program Office', 'Reviewing Engineer, DER Program Office'),
      ('reviewing engineer (P.E.)', 'reviewing engineer')]),
    ('C01', None, [('DER Program Office \u2014 Contracts; Commissioning, DER Program Office',
                    'DER Program Office \u2014 Contracts')]),
]


def apply(doc, pairs):
    counts = []
    for find, repl in pairs:
        n = 0
        for p in doc.paragraphs:
            for r in p.runs:
                if find in r.text:
                    r.text = r.text.replace(find, repl)
                    n += 1
        counts.append(n)
    return counts


def render(docx_path, out_pdf):
    r = subprocess.run([PY, TR, '--input', docx_path, '--output', out_pdf, '--transformation', 'docx_to_pdf'],
                       capture_output=True, text=True)
    if r.returncode != 0:
        return None
    txt = out_pdf + '.txt'
    r2 = subprocess.run([PY, TR, '--input', out_pdf, '--output', txt, '--transformation', 'pdf_to_text'],
                        capture_output=True, text=True)
    if r2.returncode != 0 or not os.path.exists(txt):
        return None
    return open(txt, encoding='utf-8', errors='replace').read()


def main():
    os.makedirs(WORK, exist_ok=True)
    base = render(SRC, os.path.join(WORK, 'base.pdf'))
    base_res = checks.run_text(base, filename_present=True)
    base_red = sorted(k for k, v in base_res.items() if not v)
    print('baseline:', sum(base_res.values()), '/', len(base_res), 'green; red:', base_red)
    rows = []
    for mid, target, pairs in MUTATIONS:
        doc = docx.Document(SRC)
        counts = apply(doc, pairs)
        if sum(counts) == 0 or any(c == 0 for c in counts):
            rows.append({'id': mid, 'target': target, 'applied': counts, 'caught': False, 'note': 'phrase not found'})
            print(mid, 'PHRASE NOT FOUND', counts)
            continue
        path = os.path.join(WORK, f'{mid}.docx')
        doc.save(path)
        text = render(path, os.path.join(WORK, f'{mid}.pdf'))
        if text is None:
            rows.append({'id': mid, 'target': target, 'applied': counts, 'caught': False, 'note': 'render failed'})
            continue
        res = checks.run_text(text, filename_present=True)
        red = sorted(k for k, v in res.items() if not v)
        extra = [k for k in red if k in base_red]     # criteria red before the mutation too
        changed_red = [k for k in red if k not in base_red]
        caught = bool(target) and (target in red)
        rows.append({'id': mid, 'target': target, 'applied': counts, 'caught': caught,
                     'red': red, 'newly_red': changed_red, 'green': sum(res.values())})
        print(f"{mid} applied={counts} target={target} caught={caught} newly_red={changed_red}")
    json.dump(rows, open('/work/pto/render/mutations.json', 'w'), indent=1)
    targeted = [r for r in rows if r['target']]
    caught = [r for r in targeted if r['caught']]
    print(f"\ncaught {len(caught)}/{len(targeted)} targeted mutations")
    for r in rows:
        if not r['target']:
            print('control', r['id'], '| newly red:', r.get('newly_red'))


if __name__ == '__main__':
    main()
