#!/usr/bin/env python3
"""Fill in RUN.json for the official-path runs that were driven by hand.

Each entry below was a manual `bash /tests/test.sh` run this turn; the reward is read back from that
run's own /logs/verifier copy (reward.json / reward.txt), not typed in here — except `reward=` which
is only used when the run left no reward file and the value is the one printed by test.sh itself.
"""
import json
import pathlib

RUNS = {
    "data-center-site-model": {
        "artifact_path": "/app/files/frontier__DCBim__p6_002/submission/model.ifc",
        "submission": "/work/ple-solve/data-center-site-model/ws/submission/model.ifc",
        "interpreter": "/work/venv311/bin (python 3.11.18, tests/grader_wheels installed)",
        "note": "the task's verifier image is python:3.11-slim; its wheels are cp311, so it needs 3.11"},
    "data-hall-mep-routing": {
        "artifact_path": "/app/files/dc_model__hall_seed000_d000__mep_routing/output/solution.py",
        "submission": "/work/ple-solve/data-hall-mep-routing/output/solution.py",
        "interpreter": "/work/venv-verifier/bin",
        "note": "test.sh's python3 shim needs an exec-capable TMPDIR (/tmp here is noexec); TMPDIR=/work/tmp"},
    "data-hall-mep-routing-offset": {
        "artifact_path": "/app/files/dc_model__hall_seed005_d100__mep_routing/output/solution.py",
        "submission": "/work/ple-solve/data-hall-mep-routing-offset/output/solution.py",
        "interpreter": "/work/venv-verifier/bin",
        "note": "same TMPDIR note as its sibling"},
    "mv-conveyance-study": {
        "artifact_path": "/filesystem/final_batch4__electrical_task12_conveyance_study__blind/output/submission.zip",
        "submission": "/work/ple-solve/mv-conveyance-study/build/submission.zip",
        "interpreter": "/work/venv-verifier/bin",
        "note": "corrino adapter -> paper_score -> apply-native, the whole delivered chain"},
    "wind-diaphragm-shear": {
        "artifact_path": "/filesystem/final_batch4__structural_task5_wind_diaphragm_shear__blind/output/submission.zip",
        "submission": "/work/ple-solve/wind-diaphragm-shear/out/submission.zip",
        "interpreter": "/work/venv-verifier/bin",
        "note": "first official-path attempt used the system python3 (no ezdxf/pymupdf) and scored 0.740356 "
                "with G12_DXF/G13_PDF failed; with the task's requirements present it is 0.762579"},
    "eor-review-corrections": {
        "artifact_path": "/filesystem/dc_structural__eor_revision__blind/submission/submission.zip",
        "submission": "/work/ple-solve/eor-review-corrections/build/submission.zip",
        "interpreter": "/work/venv-verifier/bin",
        "note": "JUDGE_BASE_URL pointed at the mechanical stub of results_522/stub_judge.py (plumbing only); "
                "/grader/logs had to exist and be writable by the grader user"},
}

for task, spec in RUNS.items():
    d = pathlib.Path("/work/ple-solve") / task / "results_523" / "official_testsh"
    reward = None
    for name in ("reward.json", "reward.txt"):
        p = d / name
        if p.is_file():
            txt = p.read_text().strip()
            try:
                v = json.loads(txt)
                reward = v.get("reward") if isinstance(v, dict) else v
            except Exception:
                reward = txt
            break
    rec = dict(task=task, **spec, reward=reward,
               grader_failed=(d / "GRADER_FAILED.txt").is_file(),
               files=sorted(p.name for p in d.iterdir() if p.is_file()))
    (d / "RUN.json").write_text(json.dumps(rec, indent=1, default=str))
    print(task, "reward", reward, "failed", rec["grader_failed"])
