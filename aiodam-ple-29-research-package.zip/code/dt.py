#!/usr/bin/env python3
"""Doc tool: dump text from project documents. Usage: dt.py <file|dir> [--max N] [--grep PAT]"""
import sys, os, re, json, zipfile

def pdf_text(p, maxc=20000):
    import pymupdf
    d = pymupdf.open(p)
    out = []
    for i, page in enumerate(d):
        t = page.get_text()
        out.append(f"--- page {i+1} ---\n{t}")
        if sum(len(x) for x in out) > maxc: break
    return "".join(out)[:maxc]

def docx_text(p, maxc=20000):
    import docx
    d = docx.Document(p)
    out = [para.text for para in d.paragraphs]
    for t in d.tables:
        for row in t.rows:
            out.append(" | ".join(c.text.strip() for c in row.cells))
    return "\n".join(out)[:maxc]

def xlsx_text(p, maxc=20000):
    import openpyxl
    wb = openpyxl.load_workbook(p, data_only=True)
    out = []
    for ws in wb.worksheets:
        out.append(f"=== sheet {ws.title} dims={ws.dimensions} ===")
        for row in ws.iter_rows(values_only=True):
            if all(c is None for c in row): continue
            out.append(" | ".join("" if c is None else str(c) for c in row))
            if sum(len(x) for x in out) > maxc: break
        if sum(len(x) for x in out) > maxc: break
    return "\n".join(out)[:maxc]

def dxf_text(p, maxc=20000):
    import ezdxf
    d = ezdxf.readfile(p)
    out = [f"layers: {[l.dxf.name for l in d.layers]}"]
    msp = d.modelspace()
    from collections import Counter
    c = Counter(e.dxftype() for e in msp)
    out.append(f"entities: {dict(c)}")
    n = 0
    for e in msp:
        if e.dxftype() == 'TEXT':
            out.append(f"TEXT[{e.dxf.layer}] {e.dxf.insert} : {e.dxf.text}")
        elif e.dxftype() == 'MTEXT':
            out.append(f"MTEXT[{e.dxf.layer}] {e.dxf.insert} : {e.text}")
        elif e.dxftype() == 'LINE':
            out.append(f"LINE[{e.dxf.layer}] {tuple(round(v,2) for v in e.dxf.start)[:2]} -> {tuple(round(v,2) for v in e.dxf.end)[:2]}")
        elif e.dxftype() in ('LWPOLYLINE', 'POLYLINE'):
            pts = [tuple(round(v,2) for v in (pt[0], pt[1])) for pt in (e.get_points() if e.dxftype()=='LWPOLYLINE' else [(v.dxf.location.x, v.dxf.location.y) for v in e.vertices])]
            out.append(f"{e.dxftype}[{e.dxf.layer}] {pts[:12]}{'...' if len(pts)>12 else ''}")
        n += 1
        if sum(len(x) for x in out) > maxc: break
    return "\n".join(out)[:maxc]

def zip_text(p, maxc=20000):
    z = zipfile.ZipFile(p)
    return "zip members:\n" + "\n".join(z.namelist())[:maxc]

def ifc_text(p, maxc=20000):
    import ifcopenshell
    f = ifcopenshell.open(p)
    out = [f"schema={f.schema}"]
    for k in ("IfcBuildingStorey","IfcWall","IfcSlab","IfcSpace","IfcDoor","IfcBeam","IfcColumn","IfcMember","IfcPlate","IfcRoof","IfcBuildingElementProxy","IfcWindow"):
        try:
            els = f.by_type(k)
        except Exception:
            continue
        out.append(f"{k}: {len(els)}")
        for e in els[:40]:
            nm = getattr(e, 'Name', None) or ''
            out.append(f"  {e.GlobalId[:8]} {nm}")
        if sum(len(x) for x in out) > maxc: break
    return "\n".join(out)[:maxc]

def text(p, maxc=20000):
    ext = os.path.splitext(p)[1].lower()
    try:
        if ext == '.pdf': return pdf_text(p, maxc)
        if ext == '.docx': return docx_text(p, maxc)
        if ext in ('.xlsx', '.xlsm'): return xlsx_text(p, maxc)
        if ext == '.dxf': return dxf_text(p, maxc)
        if ext == '.ifc': return ifc_text(p, maxc)
        if ext == '.zip': return zip_text(p, maxc)
        raw = open(p, 'rb').read(maxc * 4)
        try:
            return raw.decode('utf-8', 'replace')[:maxc]
        except Exception:
            return repr(raw[:2000])
    except Exception as e:
        return f"[[ERROR {type(e).__name__}: {e}]]"

if __name__ == '__main__':
    args = [a for a in sys.argv[1:] if not a.startswith('--')]
    maxc = 20000
    grep = None
    for a in sys.argv[1:]:
        if a.startswith('--max'): maxc = int(a.split('=')[1])
        if a.startswith('--grep'): grep = a.split('=', 1)[1]
    target = args[0]
    files = []
    if os.path.isdir(target):
        for root, dirs, fs in os.walk(target):
            for f in sorted(fs):
                files.append(os.path.join(root, f))
    else:
        files = [target]
    if grep:
        rx = re.compile(grep, re.I)
        for f in files:
            t = text(f, maxc=200000)
            for line in t.splitlines():
                if rx.search(line):
                    print(f"{os.path.relpath(f, target if os.path.isdir(target) else '.')}: {line.strip()[:300]}")
        sys.exit(0)
    for f in files:
        print(f"\n########## {f} ##########")
        print(text(f, maxc))
