#!/usr/bin/env python3
"""Independent check of the delivered package, by a path that does not share my model's blind spot.

1. the grader's own recomputation (fdn_check.recompute_foundation on the shipped truth profiles)
   against the numbers I report and against my own model, foundation by foundation;
2. the grader's repricing of my design against my cost model, pad by pad;
3. every register row: does its clause alias resolve to a real clause of a live document?
"""
from __future__ import annotations
import json, math, sys
from pathlib import Path

GRAD = Path("/work/ple-dataset/tasks/foundation-strategy/tests/grading")
sys.path.insert(0, str(GRAD))
sys.path.insert(0, "/work/ple-solve/foundation-strategy/src")
import fdn_check as C           # noqa: E402
import fsmodel as M             # noqa: E402

OUT = Path("/work/ple-solve/foundation-strategy/out")
PKG = OUT / "pkg"
TAGS = C.TAGS
truth = C.load_truth()
geo = json.loads((PKG / "foundation_geometry.json").read_text())
prog = json.loads((OUT / "programme.json").read_text())

rows = []
worst = {}
def rel(a, b):
    if abs(b) < 1e-12:
        return 0.0 if abs(a) < 1e-12 else math.inf
    return abs(a - b) / abs(b)

for pad in sorted(geo["pads"]):
    pb = geo["pads"][pad]
    Df = pb["bearing_depth_in"] / 12.0
    for tag in TAGS:
        fd = pb["foundations"][tag]
        r = C.recompute_foundation(truth, pad, tag, fd, Df)
        u = M._unit(pad, tag)
        strata = M.strata_for(pad, tag)
        c = prog["chosen"][pad]["foundations"][tag]
        mine = {
            "q_net": c["q_net"], "q_all": c["q_all"], "settlement": c["settlement"],
            "t_req": M.thickness(u["Pu"], c["B"], c["L"], u["col_in"] / 12, M.pad_config(pad)["fc_psi"],
                                 kind=u["kind"])[0],
            "rho_req": c["rho"], "stratum": c["stratum"],
        }
        for k, v in (("q_net", r["q_net"]), ("q_all", r["q_all"]), ("settlement", r["settlement"]),
                     ("t_req", r["t_req"]), ("rho_req", r["rho_req"])):
            d = rel(mine[k], v)
            worst[k] = max(worst.get(k, 0.0), d)
        if mine["stratum"] != r["stratum"]:
            worst["stratum"] = max(worst.get("stratum", 0), 1.0)
        # the numbers I report in the parameter file must be the ones the grader recomputes
        drep = max(rel(fd["q_net_ksf"], r["q_net"]), rel(fd["q_allow_net_ksf"], r["q_all"]),
                   rel(fd["settlement_in"], r["settlement"]))
        worst["reported"] = max(worst.get("reported", 0.0), drep)
        if fd["area_replacement_ratio"]:
            worst["ra"] = max(worst.get("ra", 0.0), rel(fd["area_replacement_ratio"], r["ra"]))
            worst["qg"] = max(worst.get("qg", 0.0), rel(fd["top_of_pier_stress_psf"], r["qg_psf"]))
        rows.append((pad, tag, r, mine, drep))

print("worst relative disagreement over all 36 foundations:")
for k, v in sorted(worst.items()):
    print(f"   {k:12s} {v:.3e}")

# campus cost
improved = [p for p in truth["campus"]["pads"]
            if geo["pads"][p]["improved"]]
need = M_IN = C.M.rigs_required(len(improved), truth["const"]["pads_per_rig"])
cost, detail = C.recompute_campus_cost(truth, geo, improved, need)
print(f"\ngrader repricing of my design: {cost:,.2f} USD   (my model: "
      f"{prog['campus_total']:,.2f} USD, difference {cost - prog['campus_total']:+,.2f})")
for pad in sorted(detail):
    mine = prog["chosen"][pad]["pad_cost"]
    print(f"   {pad}: grader {detail[pad]['cost_usd']:>12,.2f}   mine {mine:>12,.2f}   "
          f"diff {detail[pad]['cost_usd'] - mine:+,.2f}")

# register rows resolve to live documents
from register_check import check_register
reg = check_register(PKG / "constraint_register.xlsx", C.N_FAMILIES, C.HARD_FAMILIES, C.ALL_FAMILIES)
print(f"\nregister: rows {reg['n_rows']}, precision {reg['precision']:.3f}, "
      f"distractor {reg['distractor_rows']}, fabricated {reg['fabricated_rows']}, "
      f"neutral {reg['neutral_rows']}, matched rows {reg['matched_rows']}, "
      f"recall all {reg['recall_all']:.3f}, hard {reg['recall_hard']:.3f}")
missing = [f for f in C.ALL_FAMILIES if not reg["matched"][f]]
print("families not covered by the register:", missing or "none")
