#!/usr/bin/env python3
"""Build the six-file submission from the searched programme."""
from __future__ import annotations
import json, math, zipfile
from pathlib import Path

import fsmodel as M
import design as D

OUT = Path("/work/ple-solve/foundation-strategy/out")
PKG = OUT / "pkg"
PKG.mkdir(parents=True, exist_ok=True)
INP = M.INP
TAGS = M.TAGS
BAR_AREA = {4: 0.20, 5: 0.31, 6: 0.44, 7: 0.60, 8: 0.79, 9: 1.00, 10: 1.27, 11: 1.56}
KET = INP["ket"]


def bar_layout(rho, t):
    """Smallest bar whose layout closes at a practical spacing: 6 in to 12 in where that is possible,
    otherwise 4 in to 12 in (UFC 3-220-01 2-4.7.7 caps the spacing at 12 in and the bar at No. 4)."""
    d_in = max(3.0, t * 12.0 - 4.0)
    a_req = rho * 12.0 * d_in            # in^2 per foot of width
    for lo in (6.0, 4.0):
        for b in sorted(BAR_AREA):
            sp = math.floor(BAR_AREA[b] * 12.0 / a_req * 2.0) / 2.0
            if lo <= sp <= 12.0:
                return b, sp
    b = max(BAR_AREA)
    return b, min(12.0, max(4.0, math.floor(BAR_AREA[b] * 12.0 / a_req * 2) / 2.0))


def campus_programme():
    opt = json.loads((OUT / "options.json").read_text())
    pads = sorted(opt)
    spread = {p: opt[p]["spread"]["pad_cost"] for p in pads}
    imp = {p: (opt[p]["improved"]["pad_cost"] if opt[p]["improved"] else None) for p in pads}
    best = None
    for k in range(len(pads) + 1):
        savers = sorted([p for p in pads if imp[p] is not None and imp[p] < spread[p]],
                        key=lambda p: spread[p] - imp[p], reverse=True)[:k]
        if len(savers) < k:
            continue
        total = sum(spread.values()) - sum(spread[p] - imp[p] for p in savers)
        total += 40000.0 * math.ceil(k / 2)
        if best is None or total < best[0]:
            best = (total, sorted(savers))
    total, improved = best
    chosen = {}
    for p in pads:
        chosen[p] = opt[p]["improved"] if p in improved else opt[p]["spread"]
        chosen[p]["mode"] = "improved" if p in improved else "spread"
    return chosen, total, improved


def governing(pad, sol, cfg):
    """The sizing-driver test of the task brief: which limit does one 3-in step of plan width off a
    single foundation (its shear thickness re-derived) break?  A constraint that no single step
    breaks is not the one that selected the design."""
    Df = sol["Df"]
    hits = set()
    for tag in TAGS:
        c = sol["foundations"][tag]
        u = M._unit(pad, tag)
        B2 = c["B"] - 0.25
        mw_in = INP["ufc322001"]["min_width_column_in"] if u["kind"] == "column" \
            else INP["ufc322001"]["min_width_wall_in"]
        if B2 * 12 < mw_in - 1e-9:
            hits.add("MIN_WIDTH")
            continue
        L2 = c["L"] if u["kind"] == "wall" else B2
        t2, _ = M.thickness(u["Pu"], B2, L2, u["col_in"] / 12, cfg["fc_psi"], kind=u["kind"])
        strata = M.strata_for(pad, tag)
        gw = INP["gw_depth_ft"][pad]
        gamma_avg = M.overburden(strata, Df) / Df
        w = (u["Ps"] + B2 * L2 * t2 * M.GAMMA_C + B2 * L2 * max(0.0, Df - t2) * gamma_avg) / (B2 * L2)
        q_net = max(1e-9, w - M.overburden(strata, Df))
        q_ult, q_s = M.bearing(B2, L2, Df, strata, gw)
        q_all = (q_ult - q_s) / cfg["fs_bearing"]
        if q_net > q_all * 1.001:
            hits.add("BEARING")
        if c["improved"] and c["n_pier"]:
            ra = c["n_pier"] * M.A_PIER / (B2 * L2)
            s, _qg = M.settlement_improved(q_net, B2, L2, Df, strata, 10.0, ra,
                                           INP["kg_pci"][pad], c["treat"])
        else:
            s = M.settlement(q_net, B2, L2, Df, strata)
        if s > 1.0 + 1e-9:
            hits.add("SETTLEMENT")
        for other in TAGS:
            if other == tag:
                continue
            span = abs(M._unit(pad, other)["x"] - u["x"]) * 12.0
            if abs(s - sol["foundations"][other]["settlement"]) > span / 500.0 + 1e-9 and \
                    abs(M._unit(pad, other)["x"] - u["x"]) <= 5.01:
                hits.add("ANGULAR_DISTORTION")
        if u["kind"] == "wall":
            st = M.wall_stability(strata, u, B2, L2, t2, Df)
            if st["sliding_fs"] < 2.0:
                hits.add("SLIDING")
            if st["eccentricity_ft"] > B2 / 6.0:
                hits.add("OVERTURNING")
            if st["uplift_fs"] < 1.0:
                hits.add("UPLIFT")
    for name in ("BEARING", "SETTLEMENT", "ANGULAR_DISTORTION", "MIN_WIDTH", "SLIDING",
                 "OVERTURNING", "UPLIFT"):
        if name in hits:
            return name
    return "FROST"


def main():
    chosen, campus_total, improved_pads = campus_programme()
    rigs = math.ceil(len(improved_pads) / 2) if improved_pads else 0
    assign = {}
    for i, p in enumerate(improved_pads):
        assign.setdefault(f"RIG-{i // 2 + 1}", []).append(p)

    geo = {"project": {"campus_total_cost_usd": round(campus_total, 2),
                       "frost_depth_in": INP["frost_depth_in"],
                       "afi_100yr_F_days": INP["afi"]["afi_100yr"]},
           "pads": {}}
    plan = {"stress_concentration_ratio_ns": 10.0, "pier_diameter_in": KET["pier_dia_in"],
            "rigs_mobilised": rigs,
            "mobilisation_cost_usd": rigs * KET["rap_mobilisation_usd_per_rig"],
            "pads_improved": sorted(improved_pads), "rig_assignments": assign,
            "modulus_tests": {p: (1 if p in improved_pads else 0) for p in sorted(chosen)},
            "pads": {}}
    basis = {"frost": {"afi_100yr_F_days": INP["afi"]["afi_100yr"],
                       "afi_product_period": "1981-2010",
                       "frost_depth_in": INP["frost_depth_in"],
                       "superseded_product_period": "1951-1980",
                       "superseded_afi_100yr_F_days": INP["afi"]["afi_superseded_1980"]},
             "pads": {}, "campus": {}, "rejected_criteria": []}
    schedule_rows = []
    govs = {}
    for pad in sorted(chosen):
        sol = chosen[pad]
        cfg = M.pad_config(pad)
        Df = sol["Df"]
        g = governing(pad, sol, cfg)
        govs[pad] = g
        pb = {"bearing_depth_in": Df * 12.0, "fs_bearing": cfg["fs_bearing"],
              "occupancy_class": cfg["occupancy"],
              "improved": any(c["improved"] for c in sol["foundations"].values()),
              "sulfate_pct": cfg["so4_pct"], "sulfate_exposure_class": cfg["sulfate_class"],
              "exposure_classes": cfg["exposure_classes"], "fc_psi": cfg["fc_psi"],
              "max_wcm": cfg["max_wcm"], "dewatering_days": sol["dewatering_days"],
              "governing_constraint": g, "foundations": {}}
        lf = 0.0
        tr_max = 0
        for tag in TAGS:
            c = sol["foundations"][tag]
            b, s = bar_layout(c["rho"], c["t"])
            fd = {"foundation_type": "IMPROVED_SPREAD" if c["improved"] else "SPREAD",
                  "B_in": c["B"] * 12.0, "L_in": c["L"] * 12.0, "thickness_in": c["t"] * 12.0,
                  "bearing_stratum": c["stratum"],
                  "reinforcement_ratio": round(c["rho"], 6), "bar_size": b, "bar_spacing_in": s,
                  "q_net_ksf": round(c["q_net"], 4), "q_allow_net_ksf": round(c["q_all"], 4),
                  "settlement_in": round(c["settlement"], 4),
                  "pier_count": int(c["n_pier"]) if c["improved"] else 0,
                  "pier_diameter_in": int(KET["pier_dia_in"]) if c["improved"] else 0,
                  "pier_depth_ft": int(c["treat"]) if c["improved"] else 0,
                  "area_replacement_ratio": round(c["ra"], 6) if c["improved"] else 0.0,
                  "top_of_pier_stress_psf": round(c["qg_psf"], 2) if c["improved"] else 0.0,
                  "governing_constraint": g}
            if tag == "W1":
                fd.update(sliding_fs=round(c["sliding_fs"], 4),
                          eccentricity_in=round(c["eccentricity_ft"] * 12.0, 4),
                          uplift_fs=round(c["uplift_fs"], 4))
            pb["foundations"][tag] = fd
            if c["improved"]:
                lf += c["n_pier"] * c["treat"]
                tr_max = max(tr_max, c["treat"])
            schedule_rows.append({
                "pad": pad, "foundation_tag": tag, "foundation_type": fd["foundation_type"],
                "B_in": fd["B_in"], "L_in": fd["L_in"], "thickness_in": fd["thickness_in"],
                "bearing_depth_in": fd["bearing_depth_in"] if "bearing_depth_in" in fd else pb["bearing_depth_in"],
                "bearing_stratum": fd["bearing_stratum"], "fc_psi": cfg["fc_psi"],
                "max_wcm": cfg["max_wcm"], "reinforcement_ratio": fd["reinforcement_ratio"],
                "bar_size": b, "bar_spacing_in": s, "pier_count": fd["pier_count"],
                "pier_diameter_in": fd["pier_diameter_in"], "pier_depth_ft": fd["pier_depth_ft"],
                "area_replacement_ratio": fd["area_replacement_ratio"],
                "settlement_in": fd["settlement_in"], "governing_constraint": g})
        geo["pads"][pad] = pb
        if pb["improved"]:
            plan["pads"][pad] = {"stiffness_modulus_pci": INP["kg_pci"][pad],
                                 "treatment_depth_ft": tr_max,
                                 "total_pier_lf": round(lf, 3)}
        basis["pads"][pad] = {"governing_constraint": g,
                              "foundation_decision": "IMPROVED_SPREAD" if pb["improved"] else "SPREAD",
                              "spread_only_cost_usd": round(chosen[pad].get("spread_cost",
                                                                            _other(pad, "spread")), 2),
                              "improved_cost_usd": round(_other(pad, "improved"), 2)}
    basis["campus"] = {"rigs_mobilised": rigs,
                       "mobilisation_cost_usd": rigs * KET["rap_mobilisation_usd_per_rig"],
                       "total_cost_usd": round(campus_total, 2),
                       "pads_improved": sorted(improved_pads)}
    basis["rejected_criteria"] = [
        "UFC 3-220-01N (2005, cancelled) - superseded by UFC 3-220-01 (2012, Change 3)",
        "UFC 3-220-10N (2005, cancelled) - superseded by UFC 3-220-20 (2025)",
        "Basis of Design Structural Rev 1 - superseded in its entirety by Rev 3",
        "Geotechnical Addendum 1 - superseded by the Geotechnical Data Report Rev 2",
        "NOAA NCEI AFI 1951-1980 return periods - superseded edition of the AFI product",
        "FHWA GEC 6 (shallow foundations for highway bridges) - different class of structure",
        "Broadview Commons adjacent-parcel report - different property, information only",
        "Presumptive bearing pressure of 3000 psf - preliminary only, prohibited by AHJ Amendment 4",
    ]
    (PKG / "foundation_geometry.json").write_text(json.dumps(geo, indent=1))
    (PKG / "ground_improvement_plan.json").write_text(json.dumps(plan, indent=1))
    write_schedule(schedule_rows)
    (OUT / "basis_block.json").write_text(json.dumps(basis, indent=1))
    (OUT / "programme.json").write_text(json.dumps({"chosen": chosen, "campus_total": campus_total,
                                                    "improved": improved_pads, "rigs": rigs,
                                                    "governing": govs}, indent=1, default=float))
    print("campus total", round(campus_total), "rigs", rigs, "improved", improved_pads)
    print("governing", govs)


def _other(pad, mode):
    opt = json.loads((OUT / "options.json").read_text())
    r = opt[pad][mode]
    return r["pad_cost"] if r else opt[pad]["spread"]["pad_cost"] * 1.6


def write_schedule(rows):
    import openpyxl
    tpl = ("/work/ple-dataset/tasks/foundation-strategy/environment/filesystem/"
           "dc_structural__foundation_strategy__blind/project/owner/"
           "AV-CR-2604_foundation_schedule_TEMPLATE.xlsx")
    wb = openpyxl.load_workbook(tpl)
    ws = wb["FOUNDATION SCHEDULE"]
    hdr = [c.value for c in ws[1]]
    ws.delete_rows(2, ws.max_row)
    for r in rows:
        ws.append([r.get(h) for h in hdr])
    wb.save(PKG / "foundation_schedule.xlsx")


if __name__ == "__main__":
    main()
