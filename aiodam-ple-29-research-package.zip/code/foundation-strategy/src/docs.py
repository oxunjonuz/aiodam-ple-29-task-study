#!/usr/bin/env python3
"""Parse the Cattail Run data room into inputs.json.

Every number here is READ from a shipped document; the few constants that are read out of a
clause are asserted against the clause text.
Output: out/inputs.json
"""
from __future__ import annotations
import csv, json, math, re, subprocess, sys
from pathlib import Path

ROOT = Path("/work/ple-dataset/tasks/foundation-strategy/environment/filesystem/"
            "dc_structural__foundation_strategy__blind/project")
OUT = Path("/work/ple-solve/foundation-strategy/out")
OUT.mkdir(parents=True, exist_ok=True)


def pdftext(p: Path) -> str:
    return subprocess.run(["pdftotext", "-layout", str(p), "-"], capture_output=True, text=True,
                          check=True).stdout


# ------------------------------------------------------------------ 1. geotechnical data report
gdr = pdftext(ROOT / "geotech/AV-CR-2604_Geotechnical_Data_Report_Rev2.pdf")

props = {}
for ln in gdr.splitlines():
    m = re.match(r"[ \t]*(I{1,3})[ \t]+(\d{3})[ \t]+([\d.]+)[ \t]+([\d.]+)[ \t]+"
                 r"((?:\d+[ \t]+){5}\d+)[ \t]*$", ln)
    if m:
        props[m.group(1)] = {
            "gamma_pcf": int(m.group(2)), "phi_deg": float(m.group(3)), "c_ksf": float(m.group(4)),
            "es_ksf": {f"CR-P{i+1}": int(v) for i, v in enumerate(m.group(5).split())},
        }
assert set(props) == {"I", "II", "III"}, props

strat = {}
for ln in gdr.splitlines():
    m = re.match(r"\s*(CR-P\d)\s+(B-\d{3}[AB])\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)\s*$", ln)
    if m:
        pad, bor, sta, base1, t2 = m.group(1), m.group(2), float(m.group(3)), float(m.group(4)), float(m.group(5))
        strat.setdefault(pad, []).append({"boring": bor, "station_ft": sta,
                                          "base_I_ft": base1, "thick_II_ft": t2})
for pad, rows in strat.items():
    assert len(rows) == 2 and abs(rows[0]["station_ft"] - rows[1]["station_ft"]) > 1, (pad, rows)
    assert abs(rows[0]["thick_II_ft"] - rows[1]["thick_II_ft"]) < 1e-9, (pad, rows)

for bor in sorted((ROOT / "geotech/logs").glob("BORING_LOG_*.pdf")):
    txt = pdftext(bor)
    m = re.search(r"Station along instrumented column line A:\s*([\d.]+)\s*ft", txt)
    sta = float(m.group(1))
    mi = re.search(r"^I\s+.*?\s([\d.]+)\s*ft\s+([\d.]+)\s*ft\s*$", txt, re.M)
    mii = re.search(r"^II\s+.*?\s([\d.]+)\s*ft\s+([\d.]+)\s*ft\s*$", txt, re.M)
    bid = bor.stem.replace("BORING_LOG_", "")
    pad = None
    for p, rows in strat.items():
        for r in rows:
            if r["boring"] == bid:
                pad = p
                if abs(r["station_ft"] - sta) > 1e-9:
                    raise SystemExit(f"station mismatch {bid}")
                base1_log = float(mi.group(2))
                t2_log = float(mii.group(2)) - float(mii.group(1))
                if abs(base1_log - r["base_I_ft"]) > 1e-9 or abs(t2_log - r["thick_II_ft"]) > 1e-9:
                    raise SystemExit(f"log {bid} disagrees with the report table")
    if pad is None:
        raise SystemExit(f"boring {bid} not in the report table")

# ------------------------------------------------------------------ 2. laboratory sulfate
import openpyxl
lab = openpyxl.load_workbook(ROOT / "geotech/lab/AV-CR-2604_laboratory_test_summary.xlsx",
                             data_only=True)["lab_results"]
rows = list(lab.iter_rows(values_only=True))
hdr = rows[0]
so4 = {}
for r in rows[1:]:
    d = dict(zip(hdr, r))
    if d["water_soluble_sulfate_SO4_pct"] is not None:
        so4.setdefault(d["pad"], []).append(float(d["water_soluble_sulfate_SO4_pct"]))
so4_design = {p: max(v) for p, v in so4.items()}
assert all(len(v) == 2 for v in so4.values())

# ------------------------------------------------------------------ 3. civil grading + groundwater
civil = pdftext(ROOT / "civil/AV-CR-2604_grading_and_groundwater_record.pdf")
gw = {}
for m in re.finditer(r"\s*(CR-P\d)\s+PZ-\d\d\s+([\d.]+)\s+\d{4}-\d\d-\d\d", civil):
    gw[m.group(1)] = float(m.group(2))
assert len(gw) == 6, gw
dew_days_per_ft = float(re.search(r"Dewatering duration allowance\s*\.*\s*([\d.]+)\s*days per foot",
                                  civil).group(1))
slope_trigger_ft = float(re.search(r"Open-cut side slope required below\s*\.*\s*([\d.]+)\s*ft",
                                   civil).group(1))
slope_ratio = float(re.search(r"Maximum open-cut side slope\s*\.*\s*([\d.]+)\s*horizontal",
                              civil).group(1))
working_room_ft = 1.0
assert "One foot of working room" in civil

# ------------------------------------------------------------------ 4. base reactions
lines = list(csv.reader(open(ROOT / "structural/AV-CR-2604_base_reactions.csv", newline="")))
lines = [r for r in lines if r and not r[0].startswith("#")]
hdrr, data = lines[0], [dict(zip(lines[0], r)) for r in lines[1:]]
units = {}
for d in data:
    pad, tag, case = d["pad"], d["foundation_tag"], d["load_case"]
    u = units.setdefault((pad, tag), {"pad": pad, "tag": tag, "element": d["element"],
                                      "kind": "wall" if tag == "W1" else "column"})
    col = re.match(r"column (\d+) in sq", d["element"])
    wal = re.match(r"shear wall \(([\d.]+) ft\)", d["element"])
    u["col_in"] = int(col.group(1)) if col else 0
    u["L_fixed_ft"] = float(wal.group(1)) if wal else None
    P, H, M = float(d["P_kips"]), float(d["Hx_kips"]), float(d["My_kipft"])
    if case == "SERVICE_D_PLUS_L":
        u["Ps"] = P
    elif case == "STRENGTH_1.2D_1.6L":
        u["Pu"] = P
    elif case == "SERVICE_D_PLUS_L_PLUS_W":
        u["H_service"] = H
        u["M_service"] = M
    elif case == "DEAD_ONLY":
        u["P_dead"] = P
    elif case == "UPLIFT_W":
        u["W_uplift"] = -P
assert len(units) == 36, len(units)
assert all(set(u) >= {"Ps", "Pu", "col_in", "kind"} for u in units.values())

# ------------------------------------------------------------------ 5. column grid (stations)
import ezdxf
doc = ezdxf.readfile(str(ROOT / "structural/AV-CR-2604_column_grid.dxf"))
stations = {}
wt = {}
for e in doc.modelspace():
    if e.dxftype() != "TEXT":
        continue
    m = re.match(r"(CR-P\d)-(F\d|W1) STA ([\d.]+)(?:.*WALL t=(\d+) IN)?", e.dxf.text)
    if m:
        stations[(m.group(1), m.group(2))] = float(m.group(3))
        if m.group(2) == "W1":
            wt[m.group(1)] = int(m.group(4))
assert len(stations) == 36, len(stations)
for u in units.values():
    u["x"] = stations[(u["pad"], u["tag"])]
    if u["kind"] == "wall":
        u["col_in"] = wt[u["pad"]]      # the wall footing's one-way critical section is at d from the WALL face

# ------------------------------------------------------------------ 6. bid schedule
bs = openpyxl.load_workbook(ROOT / "cost/AV-CR-2604_bid_schedule_Rev1.xlsx", data_only=True)
up = list(bs["unit_prices"].iter_rows(values_only=True))
prices = {"concrete_usd_per_cy": {}}
for r in up[1:]:
    if not r or r[0] is None:
        continue
    item, desc, unit, price = r
    if str(item).startswith("03-30-"):
        prices["concrete_usd_per_cy"][re.search(r"=\s*(\d+) psi", desc).group(1)] = float(price)
    elif str(item) == "03-20-01":
        prices["rebar_usd_per_lb"] = float(price)
    elif str(item) == "31-23-16":
        prices["excavation_usd_per_cy"] = float(price)
    elif str(item) == "31-23-23":
        prices["backfill_usd_per_cy"] = float(price)
    elif str(item) == "31-23-19":
        prices["dewatering_usd_per_day"] = float(price)
prices.update({"slope_trigger_ft": slope_trigger_ft, "slope_ratio": slope_ratio,
               "dewatering_days_per_ft": dew_days_per_ft})
assert set(prices["concrete_usd_per_cy"]) == {"3000", "4000", "4500", "5000"}

# ------------------------------------------------------------------ 7. Kettleridge proposal
ket = pdftext(ROOT / "cost/Kettleridge_Ground_Systems_budget_proposal.pdf")


def one(pat, txt, cast=float):
    m = re.search(pat, txt)
    assert m, pat
    return cast(m.group(1))


ket_p = {
    "pier_dia_in": one(r"Pier diameter.*?(\d+) in", ket),
    "min_clear_spacing_ft": one(r"Minimum clear spacing between adjacent piers\s*([\d.]+) ft", ket),
    "treat_depth_min_ft": one(r"Minimum treatment depth below footing soffit\s*(\d+) ft", ket),
    "treat_depth_max_ft": one(r"Maximum treatment depth below footing soffit\s*(\d+) ft", ket),
    "qg_allow_psf": one(r"Maximum design top-of-pier stress\s*(\d+) psf", ket),
    "rap_usd_per_lf": one(r"per vertical foot\s*\$?\s*([\d.,]+)", ket, str),
    "platform_usd_per_sy": one(r"geosynthetic\s*\$?\s*([\d.,]+) / SY", ket),
    "modulus_test_usd": one(r"modulus test, each\s*\$?\s*([\d,]+)", ket, str),
    "rap_mobilisation_usd_per_rig": one(r"Mobilisation, per rig\s*\$?\s*([\d,]+)", ket, str),
    "pads_per_rig": one(r"serve AT MOST (\d+) building pads", ket, int),
}
for k in ("rap_usd_per_lf", "modulus_test_usd", "rap_mobilisation_usd_per_rig"):
    ket_p[k] = float(str(ket_p[k]).replace(",", ""))
kg = {}
for m in re.finditer(r"\s*(CR-P\d)\s+(\d{3})\s+MT-\d\d", ket):
    kg[m.group(1)] = float(m.group(2))
assert len(kg) == 6, kg

# ------------------------------------------------------------------ 8. air-freezing index
afi_txt = (ROOT / "geotech/regional/NOAA_NCEI_AFI_1981-2010_rtp_tavg_afzndx.txt").read_text()
row = [l for l in afi_txt.splitlines() if l.startswith("USC00444909")][0]
vals = [int(v.rstrip("RS")) if v.rstrip("RS").lstrip("-").isdigit() else None for v in row.split()[1:]]
assert len(vals) == 11, row
afi_100yr = vals[-1]
import xlrd
wb = xlrd.open_workbook(str(ROOT / "geotech/regional/NOAA_NCEI_AFI_return_periods_1951-1980.xls"))
afi_old = None
for sh in wb.sheets():
    for i in range(sh.nrows):
        r = sh.row_values(i)
        if any(str(c).split(".")[0] == "444909" for c in r):
            afi_old = int(r[-1])
            break
    if afi_old:
        break
assert afi_old is not None
ahj = pdftext(ROOT / "owner/Loudoun_County_AHJ_amendment_letter_LC-BD-26-0774.pdf")
frost_depth_in = 42 if afi_100yr > 500 else 30
assert "exceeding 500 degree F-days" in ahj and "42 in below" in ahj

# ------------------------------------------------------------------ 9. owner basis of design
import docx
bod = docx.Document(str(ROOT / "owner/AV-CR-2604_Basis_of_Design_Structural_Rev3.docx"))
tbl = bod.tables[0]
pads = {}
for r in tbl.rows[1:]:
    c = [x.text.strip() for x in r.cells]
    pads[c[0]] = {"building": c[1], "occupancy": c[2], "exposure": [c[3], c[4], c[5]]}
assert len(pads) == 6, pads

# UFC 3-220-01 Table 2-3
u1 = pdftext(ROOT / "criteria/UFC_3-220-01_Geotechnical_Engineering_2012_c3.pdf")
fs_table = {}
for m in re.finditer(r"^\s{4,}([\w ,\-]+?)\s{2,}([\d.>]+)\*?\s*$", u1, re.M):
    name, val = m.group(1).strip(), m.group(2)
    if name in ("Warehouse", "Apartments, Office", "Light Industrial, Public", "Silos",
                "Footings, Other", "Mats"):
        try:
            fs_table[name] = float(val.lstrip(">"))
        except ValueError:
            pass
assert fs_table.get("Light Industrial, Public") == 3.5, fs_table
assert fs_table.get("Apartments, Office") == 3.0, fs_table
assert fs_table.get("Warehouse") == 2.5, fs_table

inputs = {
    "props": props, "strat": strat, "so4_design": so4_design, "gw_depth_ft": gw,
    "units": sorted(units.values(), key=lambda u: (u["pad"], u["tag"])),
    "prices": prices, "ket": ket_p, "kg_pci": kg,
    "afi": {"afi_100yr": afi_100yr, "afi_superseded_1980": afi_old,
            "product_period": "1981-2010", "superseded_period": "1951-1980",
            "station": "USC00444909"},
    "frost_depth_in": frost_depth_in, "pads": pads, "fs_table": fs_table,
    "civil": {"dewatering_days_per_ft": dew_days_per_ft, "slope_trigger_ft": slope_trigger_ft,
              "slope_ratio": slope_ratio, "working_room_ft": working_room_ft},
    "ufc322001": {"total_settlement_limit_in": 1.0, "angular_distortion_limit": 1 / 500,
                  "min_width_column_in": 24, "min_width_wall_in": 18,
                  "rho_min_thick_ft": 3.0, "rho_min": 0.0015, "rho_floor_project": 0.0018,
                  "bar_min": 4, "spacing_max_in": 12, "min_depth_in": 18,
                  "sliding_fs_min": 2.0, "presumptive_bearing_psf": 3000},
}
(OUT / "inputs.json").write_text(json.dumps(inputs, indent=1))
print(json.dumps({k: v for k, v in inputs.items() if k not in ("props", "strat", "units")}, indent=1))
print("n units", len(inputs["units"]))
