#!/usr/bin/env python3
"""Exact per-pad search: dynamic programme over the six foundations of the column line.

The angular-distortion rule of UFC 3-220-01 2-4.7.1 couples ADJACENT units only, so the pad
decomposes into a chain: with the settlement of each foundation as the state, a DP gives the
cheapest compliant combination of plan sizes, thicknesses and (per foundation) piers.  Run twice
per pad: once with plain spread footings only, once allowing piers under any subset - which the
BIM standard and F18-F20 permit foundation by foundation.

Output: out/options.json  {pad: {"spread": {...}, "improved": {...}}}
"""
from __future__ import annotations
import json, math
from pathlib import Path

import fsmodel as M
import design as D

OUT = Path("/work/ple-solve/foundation-strategy/out")
INP = M.INP
TAGS = M.TAGS
STEP = 0.25
DFS = ([round(3.5 + i * 0.25, 2) for i in range(19)] +
       [round(8.5 + i * 0.5, 2) for i in range(14)])
B_CAP = 40.0
KET = INP["ket"]
NS = 10.0
RA_MIN = 0.33


def cand_for(pad, tag, Df, cfg, allow_piers, suf_cache):
    """Every plan size from the minimum width up to the cap, one cheapest compliant pier schedule
    each when piers are allowed."""
    u = M._unit(pad, tag)
    strata = M.strata_for(pad, tag)
    gw = INP["gw_depth_ft"][pad]
    mw_in = INP["ufc322001"]["min_width_column_in"] if u["kind"] == "column" \
        else INP["ufc322001"]["min_width_wall_in"]
    out = []
    B = max(STEP, math.ceil(mw_in / 12.0 / STEP) * STEP)
    if u["kind"] == "wall":
        B = max(B, math.ceil((u["col_in"] / 12.0 + 8.0 / 12.0) / STEP) * STEP)
    while B <= B_CAP:
        L = u["L_fixed_ft"] if u["kind"] == "wall" else B
        t, _ = M.thickness(u["Pu"], B, L, u["col_in"] / 12, cfg["fc_psi"], kind=u["kind"])
        gamma_avg = M.overburden(strata, Df) / Df
        w_f, w_s = B * L * t * M.GAMMA_C, B * L * max(0.0, Df - t) * gamma_avg
        q_net = max(1e-9, (u["Ps"] + w_f + w_s) / (B * L) - M.overburden(strata, Df))
        q_ult, q_s = M.bearing(B, L, Df, strata, gw)
        q_all = (q_ult - q_s) / cfg["fs_bearing"]
        rho = M.rho_required(u["Pu"], B, L, t, u["col_in"] / 12, cfg["fc_psi"], 60000,
                             INP["ufc322001"]["rho_floor_project"])
        base = dict(B=B, L=L, t=t, q_net=q_net, q_all=q_all, rho=rho,
                    stratum=M.layer_at(strata, Df)["key"])
        if u["kind"] == "wall":
            base.update(M.wall_stability(strata, u, B, L, t, Df))
        ok_wall = (u["kind"] != "wall" or
                   (base["sliding_fs"] >= 2.0 and base["eccentricity_ft"] <= B / 6 + 1e-9
                    and base["uplift_fs"] >= 1.0))
        if q_net <= q_all and ok_wall:
            fcost = M.foundation_cost(B, L, t, Df, cfg["fc_psi"], rho, INP["prices"])
            cell = dict(base, cost=fcost["total"] + fcost["piers"], improved=False,
                        n_pier=0, treat=0, ra=0.0, qg_psf=0.0,
                        settlement=_s_settle(pad, tag, B, L, Df, strata, q_net, suf_cache))
            if cell["settlement"] <= 1.0:
                out.append(cell)
            if allow_piers:
                n_min = math.ceil(RA_MIN * B * L / M.A_PIER - 1e-9)
                # top-of-pier stress limit fixes the smallest admissible Ra
                kg = INP["kg_pci"][pad]
                n = n_min
                ok = False
                while n * M.A_PIER / (B * L) <= D.RA_MAX + 1e-9:
                    ra = n * M.A_PIER / (B * L)
                    qg = M.rap_qg(q_net, NS, ra)
                    if qg * 1000.0 <= KET["qg_allow_psf"]:
                        ok = True
                        break
                    n += 1
                if ok:
                    suf = suf_cache[(tag, B, Df)]
                    for treat in range(int(KET["treat_depth_min_ft"]),
                                       int(KET["treat_depth_max_ft"]) + 1):
                        s = (qg * 1000.0 / 144.0) / kg + q_net * suf[min(len(suf) - 1, int(round(treat / M.DZ)))]
                        if s > 1.0:
                            continue
                        pcost = n * treat * KET["rap_usd_per_lf"]
                        out.append(dict(base, cost=fcost["total"] - fcost["piers"] + pcost,
                                        improved=True, n_pier=n, treat=treat, ra=ra,
                                        qg_psf=qg * 1000.0, settlement=s))
                        break        # shallower treatment is always cheaper
        B = round(B + STEP, 4)
    return out


def _s_settle(pad, tag, B, L, Df, strata, q_net, suf_cache):
    key = (tag, B, Df)
    if key not in suf_cache:
        suf_cache[key] = M.settle_kernel(B, L, Df, strata)
    return q_net * suf_cache[key][0]


def pareto(cands):
    """drop dominated (cost, settlement) pairs"""
    cands = sorted(cands, key=lambda c: (c["settlement"], c["cost"]))
    out, best = [], math.inf
    for c in cands:
        if c["cost"] < best - 1e-9:
            out.append(c)
            best = c["cost"]
    return out


def solve(pad, Df, cfg, allow_piers, require_any=False):
    suf_cache = {}
    cands = {t: pareto(cand_for(pad, t, Df, cfg, allow_piers, suf_cache)) for t in TAGS}
    if any(not cands[t] for t in TAGS):
        return None
    def state_ok(c, used):
        return True if not require_any else True
    dp = {i: {} for i in range(len(TAGS))}
    for j, c in enumerate(cands[TAGS[0]]):
        dp[0][j] = (c["cost"], None, bool(c["improved"]))
    for i in range(1, len(TAGS)):
        a, b = TAGS[i - 1], TAGS[i]
        span = abs(M._unit(pad, b)["x"] - M._unit(pad, a)["x"]) * 12.0
        lim = INP["ufc322001"]["angular_distortion_limit"] * span
        prev = dp[i - 1]
        for j, c in enumerate(cands[b]):
            best = None
            for k, (cost, _kp, used) in prev.items():
                if abs(cands[a][k]["settlement"] - c["settlement"]) <= lim + 1e-9:
                    if best is None or cost < best[0]:
                        best = (cost, k, used or bool(c["improved"]))
            if best is not None:
                dp[i][j] = (best[0] + c["cost"], best[1], best[2])
    last = {j: v for j, v in dp[len(TAGS) - 1].items() if (v[2] or not require_any)}
    if not last:
        return None
    jbest = min(last, key=lambda j: last[j][0])
    chain, j = [], jbest
    for i in range(len(TAGS) - 1, -1, -1):
        chain.append(cands[TAGS[i]][j])
        j = dp[i][j][1]
        if j is None and i > 0:
            raise SystemExit("DP chain broken")
    chain.reverse()
    fds = {t: c for t, c in zip(TAGS, chain)}
    area = sum(c["B"] * c["L"] for c in chain)
    improved_any = any(c["improved"] for c in chain)
    fcost = sum(c["cost"] for c in chain)
    oh, days = M.pad_overhead(pad, Df, improved_any, area, cfg, INP["prices"])
    return {"pad": pad, "Df": Df, "improved_pad": improved_any, "foundations": fds,
            "foundation_cost": fcost, "overhead": oh, "dewatering_days": days,
            "pad_cost": fcost + oh}


def main():
    res = {}
    for pad in M.pads():
        cfg = M.pad_config(pad)
        row = {}
        for mode, allow in (("spread", False), ("improved", True)):
            best = None
            for Df in DFS:
                r = solve(pad, Df, cfg, allow, require_any=(mode == "improved"))
                if r is None:
                    continue
                if mode == "spread" and r["improved_pad"]:
                    continue
                if mode == "improved" and not r["improved_pad"]:
                    continue
                if best is None or r["pad_cost"] < best["pad_cost"] - 1e-9:
                    best = r
            row[mode] = best
        res[pad] = row
        f = lambda r: None if r is None else round(r["pad_cost"])
        d = lambda r: None if r is None else r["Df"]
        print(pad, cfg["fs_bearing"], "spread", f(row["spread"]), "@", d(row["spread"]),
              "| improved", f(row["improved"]), "@", d(row["improved"]))
    (OUT / "options.json").write_text(json.dumps(res, indent=1, default=float))


if __name__ == "__main__":
    main()
