#!/usr/bin/env python3
"""Search the foundation programme: per pad, the cheapest compliant option.

Design variables per pad: the shared bearing elevation Df, improved / not improved, and per
foundation the plan size B (L follows: square for the isolated column footings, the wall's 24 ft
length for W1), the shear thickness and the flexural steel.  Piers: count (whole piers) and whole-
foot treatment depth, with the area replacement ratio that follows from the count.

Constraints enforced here (each traced to its document in NOTES):
  bearing   q_net <= q_all, q_all = (q_ult - q_s)/FS, FS from UFC 3-220-01 Table 2-3 by occupancy
  settlement  s <= 1 in (UFC 3-220-01 2-4.7.1);  |s_i - s_j| <= span/500 for ADJACENT units
  widths    B >= 24 in columns, >= 18 in the wall footing, and >= the wall width + 8 in
  frost     Df >= 42 in (AHJ Amendment 3 on AFI 556 F-days)
  wall      sliding FS >= 2.0, resultant in the middle third, uplift FS >= 1.0
  piers     Ra >= 0.33, Ra <= the geometry ceiling, qg <= 18000 psf, depth 8..25 ft, whole feet
  concrete  f'c and w/cm from the assigned exposure classes (UFGS 03 30 00)
"""
from __future__ import annotations
import itertools, json, math
from pathlib import Path

import fsmodel as M

OUT = Path("/work/ple-solve/foundation-strategy/out")
INP = M.INP
TAGS = M.TAGS
STEP = 0.25          # ft, the owner's 3-in dimensioning grid
DF_MIN = INP["frost_depth_in"] / 12.0
DFS = [round(DF_MIN + i * STEP, 2) for i in range(int((15.0 - DF_MIN) / STEP) + 1)]
RA_MIN = 0.33
NS = 10.0
KET = INP["ket"]


def ra_max():
    d = KET["pier_dia_in"] / 12.0
    cell = (d + KET["min_clear_spacing_ft"]) ** 2 * (math.sqrt(3.0) / 2.0)
    return (math.pi * d * d / 4.0) / cell


RA_MAX = ra_max()


def plan_size(u, B, L=None):
    return B, (u["L_fixed_ft"] if u["kind"] == "wall" else B)


def evaluate(pad, tag, B, Df, improved, cfg, n_pier=0, treat=0):
    """Recompute everything the grader recomputes, from my own geometry."""
    u = M._unit(pad, tag)
    strata = M.strata_for(pad, tag)
    L = u["L_fixed_ft"] if u["kind"] == "wall" else B
    gw = INP["gw_depth_ft"][pad]
    t, _d = M.thickness(u["Pu"], B, L, u["col_in"] / 12.0, cfg["fc_psi"], kind=u["kind"])
    gamma_avg = M.overburden(strata, Df) / Df
    w_f = B * L * t * M.GAMMA_C
    w_s = B * L * max(0.0, Df - t) * gamma_avg
    q_gross = (u["Ps"] + w_f + w_s) / (B * L)
    q_net = max(1e-9, q_gross - M.overburden(strata, Df))
    q_ult, q_s = M.bearing(B, L, Df, strata, gw)
    q_all = (q_ult - q_s) / cfg["fs_bearing"]
    out = {"B": B, "L": L, "t": t, "q_net": q_net, "q_all": q_all, "stratum": M.layer_at(strata, Df)["key"]}
    if improved and n_pier > 0 and treat > 0:
        ra = n_pier * M.A_PIER / (B * L)
        s, qg = M.settlement_improved(q_net, B, L, Df, strata, NS, ra, INP["kg_pci"][pad], treat)
        out.update(ra=ra, qg_psf=qg * 1000.0)
    else:
        s = M.settlement(q_net, B, L, Df, strata)
        out.update(ra=0.0, qg_psf=0.0)
    out["settlement"] = s
    out["rho"] = M.rho_required(u["Pu"], B, L, t, u["col_in"] / 12.0, cfg["fc_psi"], 60000,
                                INP["ufc322001"]["rho_floor_project"])
    if u["kind"] == "wall":
        out.update(M.wall_stability(strata, u, B, L, t, Df))
    return out


def piers_for(pad, tag, B, L, Df, q_net, cfg):
    """Cheapest whole-pier count/depth that satisfies Ra, qg and the settlement limit."""
    best = None
    kg = INP["kg_pci"][pad]
    strata = M.strata_for(pad, tag)
    for treat in range(int(KET["treat_depth_min_ft"]), int(KET["treat_depth_max_ft"]) + 1):
        n_min = math.ceil(RA_MIN * B * L / M.A_PIER - 1e-9)
        for n in range(n_min, int(RA_MAX * B * L / M.A_PIER) + 2):
            ra = n * M.A_PIER / (B * L)
            if ra < RA_MIN - 1e-9 or ra > RA_MAX + 1e-9:
                continue
            s, qg = M.settlement_improved(q_net, B, L, Df, strata, NS, ra, kg, treat)
            if qg * 1000.0 > KET["qg_allow_psf"] + 1e-6 or s > 1.0:
                continue
            cost = n * treat * KET["rap_usd_per_lf"]
            if best is None or cost < best[0]:
                best = (cost, n, treat, ra, s, qg)
            break           # the cheapest count that clears qg at this depth
    return best


def solve_pad(pad, improved, Df, cfg, area_hint=None):
    """Minimum-cost compliant geometry at one (Df, improved) setting."""
    pads_units = [M._unit(pad, t_) for t_ in TAGS]
    sizing = {}
    for u in pads_units:
        B = 2.0 if u["kind"] == "column" else 1.5
        while True:
            n_pier = treat = 0
            if improved:
                # start from the smallest plan that can hold Ra = 0.33 with whole piers
                r = evaluate(pad, u["tag"], B, Df, False, cfg)
                pick = piers_for(pad, u["tag"], r["B"], r["L"], Df, r["q_net"], cfg)
                if pick is None:
                    B += STEP
                    if B > 40:
                        return None
                    continue
                _c, n_pier, treat, _ra, _s, _qg = pick
            r = evaluate(pad, u["tag"], B, Df, improved, cfg, n_pier, treat)
            mw = INP["ufc322001"]["min_width_column_in"] if u["kind"] == "column" \
                else INP["ufc322001"]["min_width_wall_in"]
            ok = (r["B"] * 12 >= mw - 1e-9 and r["q_net"] <= r["q_all"] and r["settlement"] <= 1.0)
            if u["kind"] == "wall":
                ok = ok and r["sliding_fs"] >= 2.0 and r["eccentricity_ft"] <= r["B"] / 6 + 1e-9 \
                    and r["uplift_fs"] >= 1.0
            if ok:
                break
            nxt = B + STEP
            if nxt > 40:
                return None
            B = nxt
        sizing[u["tag"]] = (B, n_pier, treat)

    # angular distortion between ADJACENT units: raise the more-settling side until it clears
    for _ in range(400):
        rec = {t_: evaluate(pad, t_, *sizing[t_][:1], Df, improved, cfg, sizing[t_][1], sizing[t_][2])
               for t_ in TAGS}
        worst = None
        for a, b in zip(TAGS, TAGS[1:]):
            span_in = abs(M._unit(pad, b)["x"] - M._unit(pad, a)["x"]) * 12.0
            lim = INP["ufc322001"]["angular_distortion_limit"] * span_in
            d = rec[a]["settlement"] - rec[b]["settlement"]
            if abs(d) > lim + 1e-9:
                tgt = a if d > 0 else b
                gap = abs(d) - lim
                if worst is None or gap > worst[0]:
                    worst = (gap, tgt)
        if worst is None:
            break
        tgt = worst[1]
        B, n, tr = sizing[tgt]
        sizing[tgt] = (B + STEP, n, tr)
        if sizing[tgt][0] > 40:
            return None
        # re-solve the pier schedule for the enlarged footing and keep the pad compliant
        if improved:
            r = evaluate(pad, tgt, sizing[tgt][0], Df, False, cfg)
            pick = piers_for(pad, tgt, r["B"], r["L"], Df, r["q_net"], cfg)
            if pick is None:
                return None
            sizing[tgt] = (sizing[tgt][0], pick[1], pick[2])
    else:
        return None

    rec = {t_: evaluate(pad, t_, sizing[t_][0], Df, improved, cfg, sizing[t_][1], sizing[t_][2])
           for t_ in TAGS}
    prices = INP["prices"]
    total, area = 0.0, 0.0
    detail = {}
    for t_ in TAGS:
        r = rec[t_]
        c = M.foundation_cost(r["B"], r["L"], r["t"], Df, cfg["fc_psi"], r["rho"], prices,
                              sizing[t_][1] if improved else 0,
                              sizing[t_][2] if improved else 0)
        detail[t_] = dict(r, cost=c, n_pier=sizing[t_][1], treat=sizing[t_][2])
        total += c["total"]
        area += r["B"] * r["L"]
    oh, days = M.pad_overhead(pad, Df, improved, area, cfg, prices)
    return {"pad": pad, "Df": Df, "improved": improved, "foundations": detail,
            "foundation_cost": total, "overhead": oh, "dewatering_days": days,
            "pad_cost": total + oh}


def best_per_pad():
    out = {}
    for pad in M.pads():
        cfg = M.pad_config(pad)
        best = None
        for improved in (False, True):
            for Df in DFS:
                r = solve_pad(pad, improved, Df, cfg)
                if r is None:
                    continue
                if best is None or r["pad_cost"] < best["pad_cost"] - 1e-9:
                    best = r
        out[pad] = best
        print(pad, cfg["occupancy"], "FS", cfg["fs_bearing"],
              "| spread", None if not best else round(best["pad_cost"]))
    return out


if __name__ == "__main__":
    import sys
    res = {}
    for pad in M.pads():
        cfg = M.pad_config(pad)
        row = {}
        for improved in (False, True):
            b = None
            for Df in DFS:
                r = solve_pad(pad, improved, Df, cfg)
                if r and (b is None or r["pad_cost"] < b["pad_cost"]):
                    b = r
            row["improved" if improved else "spread"] = b
        res[pad] = row
        print(pad, cfg["fs_bearing"],
              "spread", round(row["spread"]["pad_cost"], 1) if row["spread"] else None,
              "improved", round(row["improved"]["pad_cost"], 1) if row["improved"] else None,
              "| Df", row["spread"]["Df"] if row["spread"] else None,
              row["improved"]["Df"] if row["improved"] else None)
    (OUT / "candidates.json").write_text(json.dumps(res, indent=1))
