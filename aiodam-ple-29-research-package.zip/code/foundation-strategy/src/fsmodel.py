#!/usr/bin/env python3
"""My own implementation of the Cattail Run foundation physics, written from the shipped corpus.

Sources (all in project/, quoted in NOTES):
  bearing capacity  UFC 3-220-20 (DM 7.2) Sec. 5-3, general equation, Vesic N-factors,
                    shape/depth factors, three groundwater cases (Figure 5-6)
  settlement        UFC 3-220-20 Sec. 5-4 + FHWA GEC 13 Eq. 5-14, 2:1 distribution, layered
                    elastic compression with the depth of influence and slice thickness RFI-019 fixes
  aggregate piers   FHWA GEC 13 Sec. 4.2.1 / 4.2.3: ns = 10 rigid footings, Ra >= 0.33,
                    kg 75-360 pci, Eq. 5-11/5-12/5-13
  footing structure EM 1110-2-2104 Ch. 5: two-way 4 sqrt(f'c), one-way 2 sqrt(f'c), phi 0.85
  wall stability    EM 1110-2-2502 Ch. 3-4: delta = 2/3 phi, half the passive resistance,
                    middle third; uplift on 0.6(D + footing + soil)
  cost              bid schedule Rev 1 + Kettleridge KGS-26-0917 Sec. 4/5, excavation prism with
                    the 1.5H:1V side slopes below 4 ft (civil record Sec. 3)
"""
from __future__ import annotations
import json, math
from pathlib import Path

OUT = Path("/work/ple-solve/foundation-strategy/out")
INP = json.loads((OUT / "inputs.json").read_text())
GW_W = 0.0624                     # ksf, unit weight of water
GAMMA_C = 0.150                   # kcf, reinforced concrete (BOD Sec. 3)
STEEL = 490.0                     # pcf (BOD Sec. 3)
DZ = 0.25                         # ft, RFI-019 "uniform layers 0.25 ft thick"
TAGS = ["F1", "F2", "F3", "F4", "F5", "W1"]
A_PIER = math.pi * (30.0 / 12.0) ** 2 / 4.0     # ft2, 30 in installed diameter


def pads():
    return sorted(INP["pads"])


# ------------------------------------------------------------------ stratigraphy
def strata_for(pad: str, tag: str) -> list[dict]:
    """Layered profile at the foundation's station, GDR Sec. 4: the base of Stratum I is
    interpolated linearly between the pad's two borings and rounded to 0.1 ft; Stratum II has a
    uniform thickness within the pad.  Stratum III extends below."""
    rows = sorted(INP["strat"][pad], key=lambda r: r["station_ft"])
    a, b = rows[0], rows[-1]
    x = _unit(pad, tag)["x"]
    if x <= a["station_ft"]:
        base1 = a["base_I_ft"]                     # no extrapolation past the borings
    elif x >= b["station_ft"]:
        base1 = b["base_I_ft"]
    else:
        f = (x - a["station_ft"]) / (b["station_ft"] - a["station_ft"])
        base1 = round(a["base_I_ft"] + f * (b["base_I_ft"] - a["base_I_ft"]), 1)
    t2 = a["thick_II_ft"]
    P = INP["props"]
    out = []
    for key, top, bot in (("I", 0.0, base1), ("II", base1, round(base1 + t2, 1)), ("III", round(base1 + t2, 1), 400.0)):
        p = P[key]
        out.append({"key": key, "top_ft": top, "bot_ft": bot, "gamma_pcf": p["gamma_pcf"],
                    "phi_deg": p["phi_deg"], "c_ksf": p["c_ksf"], "es_ksf": p["es_ksf"][pad]})
    return out


def layer_at(strata, z):
    for s in strata:
        if s["top_ft"] <= z < s["bot_ft"]:
            return s
    return strata[-1]


def overburden(strata, z):
    q = 0.0
    for s in strata:
        bot = min(s["bot_ft"], z)
        if bot > s["top_ft"]:
            q += s["gamma_pcf"] / 1000.0 * (bot - s["top_ft"])
    return q


def _unit(pad, tag):
    for u in INP["units"]:
        if u["pad"] == pad and u["tag"] == tag:
            return u
    raise KeyError((pad, tag))


# ------------------------------------------------------------------ bearing capacity
def n_factors(phi):
    p = math.radians(phi)
    nq = math.exp(math.pi * math.tan(p)) * math.tan(math.radians(45 + phi / 2)) ** 2
    nc = (nq - 1) / math.tan(p) if phi > 0 else 5.14
    ng = 2 * (nq + 1) * math.tan(p)
    return nq, nc, ng


def bearing(B, L, Df, strata, gw):
    lay = layer_at(strata, Df)
    phi, c = lay["phi_deg"], lay["c_ksf"]
    nq, nc, ng = n_factors(phi)
    bl = min(1.0, B / L)
    sc = 1 + bl * nq / nc
    sq = 1 + bl * math.tan(math.radians(phi))
    sg = max(0.6, 1 - 0.4 * bl)
    k = min(1.0, Df / B)
    dq = 1 + 2 * math.tan(math.radians(phi)) * (1 - math.sin(math.radians(phi))) ** 2 * k
    dc = dq - (1 - dq) / (nc * math.tan(math.radians(phi))) if phi > 0 else 1 + 0.4 * k
    # effective surcharge at the base (UFC 3-220-20 Fig. 5-6)
    q = 0.0
    for s in strata:
        top, bot = s["top_ft"], min(s["bot_ft"], Df)
        if bot <= top:
            continue
        g = s["gamma_pcf"] / 1000.0
        if gw >= bot:
            q += g * (bot - top)
        elif gw <= top:
            q += (g - GW_W) * (bot - top)
        else:
            q += g * (gw - top) + (g - GW_W) * (bot - gw)
        if bot >= Df:
            break
    gam = lay["gamma_pcf"] / 1000.0
    if gw <= Df:
        gam_eff = gam - GW_W
    elif gw >= Df + B:
        gam_eff = gam
    else:
        gam_eff = (gam - GW_W) + (gw - Df) / B * GW_W
    return c * nc * sc * dc + q * nq * sq * dq + 0.5 * gam_eff * B * ng * sg, q


# ------------------------------------------------------------------ settlement
def settle_kernel(B, L, Df, strata):
    n = int(max(4.0 * B, 40.0) / DZ)
    suf = [0.0] * (n + 1)
    for j in range(n - 1, -1, -1):
        zc = (j + 0.5) * DZ
        lay = layer_at(strata, Df + zc)
        suf[j] = suf[j + 1] + (B * L) / ((B + zc) * (L + zc)) * DZ / lay["es_ksf"] * 12.0
    return suf


def settlement(q_net, B, L, Df, strata, z_start=0.0):
    suf = settle_kernel(B, L, Df, strata)
    j = min(len(suf) - 1, int(round(z_start / DZ)))
    return q_net * suf[j]


def rap_qg(q_net, ns, ra):
    return q_net * ns / (ns * ra - ra + 1)


def settlement_improved(q_net, B, L, Df, strata, ns, ra, kg, treat):
    qg = rap_qg(q_net, ns, ra)
    s_uz = (qg * 1000.0 / 144.0) / kg
    s_lz = settlement(q_net, B, L, Df, strata, z_start=treat)
    return s_uz + s_lz, qg


# ------------------------------------------------------------------ footing structure
PHI_SHEAR = 0.85


def thickness(Pu, B, L, col_ft, fc, kind="column", min_t=1.0):
    qu = Pu / (B * L)
    two_way = kind != "wall"
    d = 0.75
    for _ in range(600):
        ok = True
        if two_way:
            bo = 4 * (col_ft + d)
            vu2 = Pu - qu * (col_ft + d) ** 2
            vc2 = PHI_SHEAR * 4 * math.sqrt(fc) * bo * d * 144.0 / 1000.0
            ok = ok and vc2 >= vu2
        a = max(0.0, (B - col_ft) / 2 - d)
        vu1 = qu * a * L
        vc1 = PHI_SHEAR * 2 * math.sqrt(fc) * L * d * 144.0 / 1000.0
        ok = ok and vc1 >= vu1
        if ok:
            break
        d += 0.02
    t = max(min_t, d + 4.0 / 12.0)
    return math.ceil(t * 12 / 3.0) * 3.0 / 12.0, d


def rho_required(Pu, B, L, t, col_ft, fc, fy, rho_project):
    """Flexural steel, EM 1110-2-2104 Ch. 5 with the proper rectangular stress block, plus the
    UFC 3-220-01 2-4.7.7 minimum for footings over 3 ft and the project minimum."""
    qu = Pu / (B * L)
    mu = qu * L * ((B - col_ft) / 2) ** 2 / 2.0
    d_in = max(3.0, (t - 4.0 / 12.0) * 12.0)
    b_in = L * 12.0
    fy_ksi, fc_ksi = fy / 1000.0, fc / 1000.0
    a_s = mu * 12.0 / (0.9 * fy_ksi * (d_in - 1.5))
    for _ in range(60):
        a = a_s * fy_ksi / (0.85 * fc_ksi * b_in)
        a_s = mu * 12.0 / (0.9 * fy_ksi * max(0.5, d_in - a / 2))
    rho = a_s / (b_in * t * 12.0)
    floor = 0.0015 if t > 3.0 else rho_project
    return max(rho, floor, 0.0015 if t > 3.0 else 0.0)


# ------------------------------------------------------------------ cost
def excavation(B, L, Df, prices):
    b, l = B + 2 * INP["civil"]["working_room_ft"], L + 2 * INP["civil"]["working_room_ft"]
    if Df <= prices["slope_trigger_ft"]:
        return b * l * Df / 27.0
    h, s = Df, prices["slope_ratio"]
    tb, tl = b + 2 * s * h, l + 2 * s * h
    return h / 6.0 * (b * l + tb * tl + (b + tb) * (l + tl)) / 27.0


def foundation_cost(B, L, t, Df, fc, rho, prices, n_pier=0, pier_depth=0.0):
    vol = B * L * t / 27.0
    conc = vol * prices["concrete_usd_per_cy"][str(int(fc))]
    steel = 2.0 * rho * B * L * t * STEEL * prices["rebar_usd_per_lb"]
    exc = excavation(B, L, Df, prices) * prices["excavation_usd_per_cy"]
    back = max(0.0, excavation(B, L, Df, prices) - vol) * prices["backfill_usd_per_cy"]
    piers = n_pier * pier_depth * INP["ket"]["rap_usd_per_lf"]
    return {"concrete": conc, "rebar": steel, "excavation": exc, "backfill": back, "piers": piers,
            "total": conc + steel + exc + back + piers}


def dewatering_days(Df, gw, prices):
    return int(math.ceil((Df - gw) * prices["dewatering_days_per_ft"])) if Df > gw else 0


def pad_overhead(pad, Df, improved, area_sf, pad_cfg, prices):
    days = dewatering_days(Df, INP["gw_depth_ft"][pad], prices)
    c = days * prices["dewatering_usd_per_day"]
    if improved:
        c += INP["ket"]["modulus_test_usd"] * 1        # one production modulus test per improved pad
        c += area_sf / 9.0 * INP["ket"]["platform_usd_per_sy"]
    return c, days


# ------------------------------------------------------------------ wall stability
def wall_stability(strata, u, B, L, t, Df, sliding_min=2.0):
    lay = layer_at(strata, Df)
    phi = lay["phi_deg"]
    gamma_avg = overburden(strata, Df) / max(Df, 1e-9)
    w_ftg = B * L * t * GAMMA_C
    w_soil = B * L * max(0.0, Df - t) * gamma_avg
    N_serv = u["Ps"] + w_ftg + w_soil
    N_06 = 0.6 * (u["P_dead"] + w_ftg + w_soil)
    delta = math.radians(2.0 / 3.0 * phi)
    kp = math.tan(math.radians(45 + phi / 2)) ** 2
    pp = 0.5 * kp * (lay["gamma_pcf"] / 1000.0) * Df ** 2 * L
    resist = N_06 * math.tan(delta) + 0.5 * pp
    return {"sliding_fs": resist / u["H_service"] if u["H_service"] else 99.0,
            "eccentricity_ft": u["M_service"] / max(N_serv, 1e-9),
            "uplift_fs": 0.6 * (w_ftg + w_soil + u["P_dead"]) / max(u["W_uplift"], 1e-9),
            "passive_kips": pp, "friction_kips": N_06 * math.tan(delta)}


# ------------------------------------------------------------------ concrete by exposure
UFGS = {"F0": (None, 2500), "F1": (0.55, 3500), "F2": (0.45, 4500), "F3": (0.40, 5000),
        "S0": (None, 2500), "S1": (0.50, 4000), "S2": (0.45, 4500),
        "W0": (None, 2500), "W1": (0.50, 4000), "W2": (0.50, 4000),
        "C0": (None, 2500), "C1": (None, 2500), "C2": (0.40, 5000)}
MENU = [3000, 4000, 4500, 5000]


def sulfate_class(so4):
    return "S2" if so4 > 0.20 else ("S1" if so4 >= 0.10 else "S0")


def concrete_for(classes):
    wcm = min([UFGS[c][0] for c in classes if UFGS[c][0] is not None])
    fc_min = max(UFGS[c][1] for c in classes)
    return wcm, next(f for f in MENU if f >= fc_min), fc_min


def pad_config(pad):
    p = INP["pads"][pad]
    s = sulfate_class(INP["so4_design"][pad])
    classes = sorted(p["exposure"] + [s])
    wcm, fc, fc_min = concrete_for(classes)
    return {"occupancy": p["occupancy"], "fs_bearing": INP["fs_table"][p["occupancy"]],
            "exposure_classes": classes, "sulfate_class": s, "so4_pct": INP["so4_design"][pad],
            "max_wcm": wcm, "fc_psi": fc, "fc_min_psi": fc_min}


if __name__ == "__main__":
    for pad in pads():
        cfg = pad_config(pad)
        print(pad, cfg)
        for tag in TAGS:
            st = strata_for(pad, tag)
            print("   ", tag, [(s["key"], s["top_ft"], s["bot_ft"]) for s in st])
