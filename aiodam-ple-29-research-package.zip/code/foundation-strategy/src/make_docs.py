#!/usr/bin/env python3
"""Write constraint_register.xlsx, design_basis.md and foundation_feasibility_matrix.md."""
from __future__ import annotations
import json, math
from pathlib import Path

OUT = Path("/work/ple-solve/foundation-strategy/out")
PKG = OUT / "pkg"
PROG = json.loads((OUT / "programme.json").read_text())
OPT = json.loads((OUT / "options.json").read_text())
INP = json.loads((OUT / "inputs.json").read_text())
TAGS = ["F1", "F2", "F3", "F4", "F5", "W1"]

U1 = "UFC 3-220-01 Geotechnical Engineering (2012, Change 3, 2025)"
U2 = "UFC 3-220-20 Foundations and Earth Structures DM 7-2 (2025)"
U3 = "UFC 3-301-01 Structural Engineering (2023, Change 4)"
UGS = "UFGS 03 30 00 Cast-in-Place Concrete"
UGS31 = "UFGS 31 00 00 Earthwork"
EM05 = "EM 1110-1-1905 Bearing Capacity of Soils"
EM00 = "EM 1110-2-2000 Concrete for Civil Works Structures"
EM04 = "EM 1110-2-2104 Strength Design for Reinforced Concrete"
EM02 = "EM 1110-2-2502 Retaining and Flood Walls"
G13 = "FHWA GEC 13 Vol I Ground Modification Methods (FHWA-NHI-16-027)"
GDR = "Geotechnical Data Report Rev 2 (Harrowgate, project 26-0431)"
LAB = "Laboratory Test Summary (geotech/lab/AV-CR-2604)"
BOD = "Basis of Design Structural Rev 3 (AV-CR-2604)"
BIM = "BIM Foundation Parameter Standard Rev 2 (AV-CR-2604)"
SCH = "Foundation Schedule Template (AV-CR-2604)"
REG = "Constraint Register Template (AV-CR-2604)"
AHJ = "Loudoun County AHJ amendment letter LC-BD-26-0774 (2026-08-14)"
RFI = "RFI Log (AV-CR-2604)"
NOAA = "NOAA NCEI AFI return periods, 1981-2010 normals product, station USC00444909"
CIV = "Grading and Groundwater Record C-301 (Vantry Civil Group)"
BS = "Bid Schedule Rev 1 unit prices (AV-CR-2604)"
KET = "Kettleridge Ground Systems budget proposal KGS-26-0917"
BR = "Base Reactions export AV-CR-2604-STR.rev7"
LCM = "Load Combination Memorandum (AV-CR-2604)"
CG = "Column Grid AV-CR-2604 (DXF)"

ROWS = [
    ("RQ-01", U1, "Table 2-3", "Minimum factor of safety on bearing capacity by STRUCTURE row: Light Industrial, Public",
     "3.5", "-", "hard", "CR-P1, CR-P2, CR-P3, CR-P6", "FS = 3.5 adopted for the four light-industrial pads"),
    ("RQ-02", U1, "Table 2-3", "Minimum factor of safety on bearing capacity: Apartments, Office",
     "3.0", "-", "hard", "CR-P4", "FS = 3.0 adopted for the administration building"),
    ("RQ-03", U1, "Table 2-3", "Minimum factor of safety on bearing capacity: Warehouse",
     "2.5", "-", "hard", "CR-P5", "FS = 2.5 adopted; the super-flat-floor footnote does not apply, no floor flatness criterion is imposed in the data room"),
    ("RQ-04", BOD, "Section 2", "Occupancy classification is the STRUCTURE row used to select the bearing FS",
     "Light Industrial, Public", "-", "hard", "all pads", "Occupancy taken from the basis of design table, per pad"),
    ("RQ-05", U2, "Section 5-3", "General bearing-capacity equation with Vesic N-factors, shape and depth factors",
     "q_ult = c Nc sc dc + q Nq sq dq + 0.5 gamma B Ng sg dg", "-", "hard", "all pads",
     "Vesic general equation applied to every foundation at its own interpolated profile"),
    ("RQ-06", U2, "Figure 5-6", "Groundwater correction of the surcharge and of the unit weight in the bearing term",
     "3 cases (water above base / within B / deeper than B)", "-", "hard", "all pads",
     "Effective surcharge and submerged unit weight applied where the piezometric level is above the base"),
    ("RQ-07", EM05, "Chapter 4", "Second, independent bearing-capacity method (general equation, Meyerhof form)",
     "3 methods required", "count", "hard", "all pads",
     "Least-of-three review: Meyerhof and Brinch Hansen computed as checks on the Vesic value"),
    ("RQ-08", U1, "2-4.7.1", "Ultimate bearing capacity and settlement analysis with a minimum of three widely accepted methods",
     "3", "methods", "hard", "all pads", "Three methods computed; the reported value is the Vesic value the design relies on"),
    ("RQ-09", GDR, "Section 4", "Base of Stratum I interpolated linearly between the two borings of the pad, rounded to 0.1 ft; no extrapolation",
     "0.1", "ft", "hard", "all pads", "Interpolated at the station of each foundation along column line A"),
    ("RQ-10", GDR, "Section 2", "Engineering properties of the strata by pad (unit weight, friction, cohesion, elastic modulus)",
     "Es", "ksf", "hard", "all pads", "Stratum I/II/III parameters and the pad-specific Es values used in the settlement integral"),
    ("RQ-11", U1, "2-4.7.1", "Total post-construction settlement limited to 1 in",
     "1.0", "in", "hard", "all pads", "1 in total settlement limit applied to every foundation"),
    ("RQ-12", U1, "2-4.7.1", "Differential settlement shall not produce angular distortion in excess of 1/500",
     "500", "1/x", "hard", "all pads", "Angular distortion checked between adjacent units of the column line"),
    ("RQ-13", U1, "2-4.7.1", "Minimum width 24 in for individual column foundations and 18 in (or wall + 8 in) for continuous footings",
     "24", "in", "hard", "all pads", "Column footings sized well above 24 in; the wall footing above 18 in"),
    ("RQ-14", U1, "2-4.8.4", "Frost line depths published by the local government municipality shall be used",
     "42", "in", "hard", "all pads", "AHJ Amendment 3 depth of 42 in adopted as the minimum bearing depth"),
    ("RQ-15", AHJ, "Amendment 3", "100-year air-freezing index above 500 degree F-days requires a minimum bearing depth of 42 in",
     "42", "in", "hard", "all pads", "AFI 556 F-days > 500, so the 42 in branch governs every pad"),
    ("RQ-16", AHJ, "Amendment 3", "Air-freezing index read from the current 1981-2010 product; the 1951-1980 tables are superseded",
     "500", "F-days", "hard", "all pads", "Current product used; the 1951-1980 edition was set aside"),
    ("RQ-17", NOAA, "100 year", "One-hundred-year air-freezing index at station USC00444909 (LINCOLN, VA)",
     "556", "F-days", "hard", "all pads", "556 F-days read from the 1981-2010 return-period product"),
    ("RQ-18", U1, "2-4.6.3", "Factor of safety against sliding not less than 2.0",
     "2.0", "-", "hard", "W1 of all pads", "Shear-wall footing sliding FS checked at every pad"),
    ("RQ-19", EM02, "Chapter 3", "Sliding by limit equilibrium: base friction at 2/3 phi plus at most half the available passive resistance; resultant in the middle third",
     "2/3 phi", "-", "hard", "W1 of all pads", "Sliding resistance built as base friction plus half the passive resistance"),
    ("RQ-20", LCM, "Section 3", "Sliding resistance from base friction and not more than one half of the available passive resistance; resultant within the middle third",
     "0.5", "-", "hard", "W1 of all pads", "Same rule applied in the wall-footing check"),
    ("RQ-21", U3, "2-4.3", "Uplift resisted by 0.6 times footing self weight, soil above the footing and unfactored dead load",
     "0.6", "-", "hard", "W1 of all pads", "Uplift FS computed on the 0.6D combination"),
    ("RQ-22", LCM, "Section 2", "Net uplift at the shear-wall footing on the 0.6D + W combination; uplift load case UPLIFT_W",
     "UPLIFT_W", "-", "hard", "W1 of all pads", "UPLIFT_W reaction used with the 0.6D resistance"),
    ("RQ-23", BR, "load_case", "Service and factored base reactions by foundation, including the 0.6D + W and uplift cases",
     "Ps, Pu", "kips", "hard", "all pads", "Reactions taken from the analytical model export for each load case"),
    ("RQ-24", EM04, "Chapter 5", "Two-way shear v_c = 4 sqrt(f'c) and one-way shear 2 sqrt(f'c) with the punching perimeter",
     "4 sqrt(f'c)", "-", "hard", "all pads", "Footing thickness derived from punching and one-way shear"),
    ("RQ-25", U1, "2-4.7.7", "Footings over 3 ft thick: minimum reinforcement ratio 0.0015 each way, No. 4 minimum, 12 in maximum spacing",
     "0.0015", "-", "hard", "all pads", "Minimum steel applied where the footing exceeds 3 ft; No. 4 at 12 in governs the schedule"),
    ("RQ-26", BOD, "Section 3", "Project minimum shrinkage and temperature reinforcement ratio 0.0018 each way; Grade 60; effective depth = thickness - 4 in",
     "0.0018", "-", "hard", "all pads", "Project minimum applied wherever the code minimum for thick footings does not exceed it"),
    ("RQ-27", EM00, "Table 2-2", "Sulfate exposure condition: 0.10-0.20 % moderate, above 0.20 % severe",
     "0.1", "% SO4", "hard", "all pads", "Condition assigned from the measured water-soluble sulfate of Stratum I"),
    ("RQ-28", LAB, "lab_results", "Design sulfate exposure condition is the more severe of the two Stratum I results for the pad",
     "water_soluble_sulfate_SO4_pct", "%", "hard", "all pads", "The higher of the two measured values adopted per pad"),
    ("RQ-29", UGS, "2.5.2.4", "Sulfate resistance: S1 maximum w/cm 0.50 and minimum f'c 4000 psi; S2 0.45 and 4500 psi",
     "0.45", "w/cm", "hard", "CR-P2, CR-P6", "S2 concrete adopted at the two S2 pads"),
    ("RQ-30", UGS, "2.5.2.2", "Freezing and thawing resistance: F1 maximum w/cm 0.55 minimum 3500 psi; F3 0.40 and 5000 psi",
     "0.55", "w/cm", "hard", "all pads", "F1 concrete at five pads, F3 at the warehouse"),
    ("RQ-31", UGS, "2.5.2.6", "Concrete permeability: W1 maximum w/cm 0.50 and minimum f'c 4000 psi",
     "0.5", "w/cm", "hard", "all pads", "W1 requirement carried into the governing mix of every pad"),
    ("RQ-32", UGS, "2.5.2.3", "Corrosion protection class C1: no w/cm limit, minimum f'c 2500 psi",
     "2500", "psi", "hard", "all pads", "C1 is not the governing class anywhere on this project"),
    ("RQ-33", BOD, "Section 2", "Exposure classes assigned by the owner per building; the sulfate class is established from the measured sulfate",
     "F1, W1, C1", "-", "hard", "all pads", "Owner classes combined with the sulfate class derived from the laboratory results"),
    ("RQ-34", G13, "Section 4.2.1", "Minimum area replacement ratio 0.33 for rammed aggregate piers",
     "0.33", "-", "hard", "improved pads", "Every improved footing carries Ra >= 0.33"),
    ("RQ-35", KET, "Section 2", "Installed pier diameter 30 in and minimum clear spacing 1.0 ft",
     "30", "in", "hard", "improved pads", "Pier diameter 30 in; the staggered grid fixes the maximum achievable Ra"),
    ("RQ-36", G13, "Section 4.2.1", "Stress concentration ratio 10 for structure foundation support under rigid footings",
     "10", "-", "hard", "improved pads", "ns = 10 adopted; the vendor manual value and the 5-10 embankment band rejected"),
    ("RQ-37", G13, "Section 4.2.3.1", "Design stiffness modulus of rammed aggregate piers in the range 75 to 360 pci",
     "75", "pci", "hard", "improved pads", "Every pad modulus lies inside the range"),
    ("RQ-38", KET, "Section 3", "Pad-specific design pier stiffness modulus kg from the pre-production modulus tests",
     "165", "pci", "hard", "improved pads", "The as-tested modulus of the pad is used, not a default"),
    ("RQ-39", KET, "Section 2", "Maximum design top-of-pier stress 18000 psf",
     "18000", "psf", "hard", "improved pads", "Top-of-pier stress computed from Eq. 5-12 and held below the limit"),
    ("RQ-40", G13, "Section 4.2.3", "Top-of-pier stress from Eq. 5-12 and upper-zone settlement from Eq. 5-13",
     "qg = q ns / (ns Ra - Ra + 1)", "-", "hard", "improved pads", "Two-layer method with the upper-zone term from Eq. 5-12/5-13"),
    ("RQ-41", G13, "5-11", "Total settlement of the improved ground is the upper-zone plus lower-zone settlement",
     "s_tot = s_uz + s_lz", "-", "hard", "improved pads", "Lower-zone compression from the same layered elastic method"),
    ("RQ-42", G13, "5-14", "Layered elastic compression s = dq H / E for the lower zone and for the unimproved case",
     "s = dq H / E", "-", "hard", "all pads", "The unimproved case and the lower zone use the same equation"),
    ("RQ-43", RFI, "RFI-019", "Settlement by layered elastic compression with the 2:1 stress distribution; integral to 4B and not less than 40 ft in 0.25 ft layers",
     "4B, 40", "ft", "hard", "all pads", "Depth of influence and slice thickness taken from the RFI answer"),
    ("RQ-44", KET, "Section 2", "Treatment depth between 8 ft and 25 ft below the footing soffit in whole feet",
     "8", "ft", "hard", "improved pads", "Treatment depths of 8 to 9 ft adopted, inside the window"),
    ("RQ-45", KET, "Section 4", "Mobilisation 40000 USD per rig; one rig serves at most 2 building pads in the Phase 1 window",
     "40000", "USD", "hard", "campus", "Two rigs mobilised for four improved pads"),
    ("RQ-46", G13, "Section 4.4", "Design verification testing of the improved ground (modulus testing) as part of the quality programme",
     "verification testing", "-", "soft", "improved pads", "One production modulus test per improved pad"),
    ("RQ-47", KET, "Section 5", "Unit prices: piers 28 USD per vertical foot, working platform 2.40 USD/SY, production modulus test 9500 USD each",
     "9500", "USD", "hard", "improved pads", "Prices taken from the subcontractor proposal and applied in the cost comparison"),
    ("RQ-48", BS, "unit_prices", "Project unit prices: concrete by strength, reinforcing steel, structural excavation, backfill, dewatering",
     "196", "USD/CY", "hard", "all pads", "Campus cost built from this schedule only"),
    ("RQ-49", CIV, "Section 3", "Dewatering allowance 3.0 days per foot below the stabilised groundwater depth, rounded up; side slopes 1.5H:1V below 4 ft",
     "3.0", "days/ft", "hard", "all pads", "Dewatering and the excavation prism computed with this rule"),
    ("RQ-50", CIV, "Section 2", "Stabilised groundwater depth below finished grade from the piezometer record",
     "8.0", "ft", "hard", "all pads", "Design groundwater depths taken per pad from the piezometer record"),
    ("RQ-51", U1, "2-4.8.1", "Spacing between footings at least 1.5 times the width of the larger foundation (preliminary sizing); footing type selection by detailed cost comparison",
     "1.5", "B", "hard", "all pads", "RFI-017 answer applied: individual units, no reduction factor for overlapping zones"),
    ("RQ-52", U1, "2-4.5.2", "Presumptive load-bearing values may be used only for preliminary design and minor construction",
     "3000", "psf", "hard", "all pads", "The 3000 psf presumptive value was not used for design"),
    ("RQ-53", U1, "2-4.6.4", "Vertical load resistance determined by the registered design professional from site soil conditions",
     "3000", "psf", "hard", "all pads", "Site-specific analysis used instead of the presumptive value"),
    ("RQ-54", GDR, "Section 7", "Preliminary presumptive bearing pressure of 3000 psf: not a design value",
     "3000", "psf", "hard", "all pads", "Recognised and not used"),
    ("RQ-55", AHJ, "Amendment 4", "Presumptive load-bearing values may not be used; a site-specific bearing-capacity and settlement analysis is required",
     "presumptive", "-", "hard", "all pads", "Site-specific analysis performed at every pad"),
    ("RQ-56", BOD, "Section 4", "Plan dimensions and thickness dimensioned to the nearest 3 in; bearing depth to the nearest 3 in and not more than 15 ft",
     "3", "in", "hard", "all pads", "Every dimension on the 3 in grid; bearing depths below 15 ft"),
    ("RQ-57", BOD, "Section 4", "No footing thinner than 12 in; pier counts whole piers and treatment depths whole feet",
     "12", "in", "hard", "all pads", "All thicknesses 12 in or more; whole piers and whole-foot depths"),
    ("RQ-58", BIM, "rules", "Parameter file rules: all six pads and six foundations each, 3 in grid, no null values, spread footings carry zeros in the pier fields",
     "3", "in", "hard", "all pads", "Parameter file built to the standard"),
    ("RQ-59", SCH, "instructions", "One row per foundation, all 36 foundations, plan dimensions and thickness in inches",
     "36", "rows", "soft", "all pads", "Schedule carries all 36 rows and agrees with the parameter file"),
    ("RQ-60", REG, "Table 1", "One row per requirement actually applied, with the real document and clause",
     "9", "columns", "soft", "campus", "This register"),
    ("RQ-61", U1, "2-4.7.1", "The governing constraint per pad is the one that selects the design (sizing driver)",
     "governing constraint", "-", "soft", "all pads", "Reported per pad from the one-step plan-width test"),
    ("RQ-62", BIM, "schema", "governing_constraint is one of the nine enumerated values",
     "9", "values", "soft", "all pads", "Enumeration respected in the parameter file"),
    ("RQ-63", RFI, "RFI-007", "Air-freezing index edition: the current 1981-2010 product governs, the 1951-1980 tables are superseded",
     "1981-2010", "-", "soft", "campus", "Current edition used"),
    ("RQ-64", RFI, "RFI-011", "Stress concentration ratio for aggregate piers under rigid footings from the governing public reference; vendor manuals not accepted",
     "10", "-", "soft", "improved pads", "ns = 10 from GEC 13, vendor value rejected"),
    ("RQ-65", RFI, "RFI-015", "Deep foundations may be evaluated in the cost comparison but are not accepted in Phase 1",
     "no deep foundation", "-", "soft", "campus", "Spread versus improved spread compared; no deep alternative offered"),
    ("RQ-66", RFI, "RFI-013", "The Broadview Commons adjacent-parcel report is information only",
     "information only", "-", "soft", "campus", "Set aside, different property"),
    ("RQ-67", RFI, "RFI-004", "The geotechnical data report recommends no foundation type; the engineer of record selects it",
     "no recommendation", "-", "soft", "campus", "Type selection made here under UFC 3-220-01"),
    ("RQ-68", UGS31, "Part 3", "Structural excavation incl. side slopes and structural backfill and compaction",
     "side slopes", "-", "soft", "all pads", "Excavation prism with working room and side slopes below 4 ft"),
    ("RQ-69", "UFC 3-220-01N Foundation Design (2005, cancelled)", "1",
     "Cancelled predecessor volume of the governing geotechnical criteria", "-", "-", "soft", "campus",
     "Set aside: cancelled, superseded by UFC 3-220-01 (2012, Change 3)"),
    ("RQ-70", "UFC 3-220-10N Soil Mechanics (2005, cancelled)", "1",
     "Cancelled predecessor volume of the soil mechanics criteria", "-", "-", "soft", "campus",
     "Set aside: cancelled, superseded by UFC 3-220-20 (2025)"),
    ("RQ-71", "Basis of Design Structural Rev 1 (superseded)", "Revision 1",
     "Superseded revision of the owner's basis of design", "-", "-", "soft", "campus",
     "Set aside: superseded in its entirety by Rev 3"),
    ("RQ-72", "Geotechnical Addendum 1 (superseded)", "1",
     "Superseded geotechnical addendum", "-", "-", "soft", "campus",
     "Set aside: superseded by the Geotechnical Data Report Rev 2"),
    ("RQ-73", "NOAA NCEI AFI return periods 1951-1980 (superseded edition)", "1951-1980",
     "Superseded edition of the air-freezing-index return-period product", "416", "F-days", "soft", "campus",
     "Set aside: the 1981-2010 product governs; the 1951-1980 100-year value of 416 F-days was not used"),
    ("RQ-74", "FHWA GEC 6 Shallow Foundations for Highway Bridges", "1",
     "Design manual for a different class of structure; its tolerable angular distortion of 0.004 is for continuous-span bridges",
     "0.004", "-", "soft", "campus", "Set aside: not governing for a building; the criteria limit of 1/500 adopted"),
    ("RQ-75", "Broadview Commons adjacent-parcel report (2023)", "1",
     "Subsurface report for a different property", "-", "-", "soft", "campus",
     "Set aside: information only, different property"),
    ("RQ-76", CG, "1", "Foundation stations along the instrumented column line A and the column sizes",
     "24", "in", "hard", "all pads", "Stations and column sizes taken from the grid; the wall footing is 24 ft long, 12 in thick"),
]


def write_register():
    import openpyxl
    tpl = ("/work/ple-dataset/tasks/foundation-strategy/environment/filesystem/"
           "dc_structural__foundation_strategy__blind/project/owner/"
           "constraint_register_template.xlsx")
    wb = openpyxl.load_workbook(tpl)
    ws = wb["CONSTRAINT REGISTER"]
    hdr = [c.value for c in ws[1]]
    ws.delete_rows(2, ws.max_row)
    for r in ROWS:
        ws.append(list(r))
    wb.save(PKG / "constraint_register.xlsx")


def fmt(x, n=1):
    return f"{x:,.{n}f}"


def write_basis():
    basis = json.loads((OUT / "basis_block.json").read_text())
    chosen = PROG["chosen"]
    lines = ["```json", json.dumps(basis, indent=1), "```", "",
             "# Design basis - Cattail Run Data Campus, Phase 1 foundation package", "",
             "Ardent Vale Infrastructure LLC.  Six building pads CR-P1 ... CR-P6, six foundation units on",
             "each pad's instrumented column line: five isolated column footings (F1-F5) and one 24 ft",
             "continuous shear-wall footing (W1).  For the thirty-six foundations this basis states the",
             "bearing elevation, the plan size, the shear thickness, the reinforcement and the decision",
             "between a shallow spread footing alone and a spread footing over rammed aggregate piers.", "",
             "## 1. Criteria that govern, and the documents reviewed and set aside", "",
             "The governing geotechnical criteria are UFC 3-220-01 Geotechnical Engineering (2012, Change 3, 2025)",
             "for the factor of safety, the settlement and drift limits, the minimum widths and the",
             "prohibition on presumptive values; UFC 3-220-20 Foundations and Earth Structures (DM 7-2, 2025)",
             "Section 5-3 for the bearing-capacity equation and Figure 5-6 for the groundwater correction;",
             "Section 5-4 and FHWA GEC 13 Vol I Equation 5-14 for the settlement method; FHWA GEC 13 Section 4.2",
             "for the rammed aggregate piers; EM 1110-2-2104 for the footing shear and flexure; EM 1110-2-2502",
             "Chapter 3 for sliding and overturning of the shear-wall footing; EM 1110-2-2000 Table 2-2 with UFGS",
             "03 30 00 for the concrete; and the owner's Basis of Design Rev 3, its BIM parameter standard and the",
             "Loudoun County amendment letter.", "",
             "Reviewed and set aside:", "",
             "* **UFC 3-220-01N (2005)** - cancelled predecessor of the governing geotechnical criteria;",
             "  UFC 3-220-01 (2012, Change 3) governs instead.",
             "* **UFC 3-220-10N (2005)** - cancelled; UFC 3-220-20 (2025) governs instead.",
             "* **Basis of Design Structural Rev 1** - superseded in its entirety by Rev 3, which governs.",
             "* **Geotechnical Addendum 1** - superseded by the Geotechnical Data Report Rev 2, which governs.",
             "* **NOAA NCEI air-freezing-index return periods 1951-1980** - the superseded edition of the AFI",
             "  product; the 1981-2010 product governs, as AHJ Amendment 3 and RFI-007 both direct.",
             "* **FHWA GEC 6 Shallow Foundations for Highway Bridges** - written for bridges. Its tolerable",
             "  angular distortion of 0.004 for continuous-span bridges is a bridge serviceability criterion and",
             "  is not adopted here; the criteria's own 1/500 limit governs buildings.",
             "* **Broadview Commons adjacent-parcel report (2023)** - a different property, information only.",
             "* **The 3000 psf presumptive bearing pressure** of the data report Section 7 - preliminary only,",
             "  prohibited for design by AHJ Amendment 4 and by UFC 3-220-01 paragraphs 2-4.5.2 and 2-4.6.4.", "",
             "## 2. Bearing elevation and frost protection", "",
             f"The 100-year air-freezing index at the county station of record USC00444909 (LINCOLN, VA) is",
             f"**{basis['frost']['afi_100yr_F_days']} F-days** read from the current 1981-2010 return-period product. It exceeds the",
             "500 F-day threshold of AHJ Amendment 3, so **the minimum depth of the bearing surface is 42 in**",
             "below finished grade at every pad. The 1951-1980 tables give 416 F-days for the same station and",
             "are the superseded edition of the same product; they were not used. Every pad is founded at",
             f"**{chosen['CR-P1']['Df']:.2f} ft** or deeper, on the 3 in dimensioning grid, with one shared bearing elevation per pad:",
             "", "| pad | bearing elevation below finished grade (in) | bearing elevation (ft) |", "|---|---|---|"]
    for pad in sorted(chosen):
        lines.append(f"| {pad} | {chosen[pad]['Df'] * 12:.0f} | {chosen[pad]['Df']:.2f} |")
    lines += ["",
              "## 3. Bearing-capacity method and the factor of safety at each pad", "",
              "The net allowable bearing pressure of every foundation is derived from the general",
              "bearing-capacity equation of UFC 3-220-20 Section 5-3 (DM 7-2) with the Vesic N-factors of",
              "Figure 5-5, the shape factors of that section and the depth factors d_q and d_c given there. The",
              "surcharge and the unit weight in the failure term are corrected for the position of the",
              "stabilised groundwater table following the three cases of Figure 5-6, using the piezometer",
              "depths of the grading and groundwater record. The net allowable pressure is",
              "q_allow = (q_ult - q_sur)/FS, with FS the STRUCTURE-row value of UFC 3-220-01 Table 2-3 for the",
              "occupancy of that pad: **3.5** for the four Light Industrial, Public pads (CR-P1, CR-P2, CR-P3,",
              "CR-P6), **3.0** for the Apartments, Office pad (CR-P4) and **2.5** for the Warehouse (CR-P5). The",
              "Warehouse row carries a footnote directing an FS above 3 for super-flat warehouse floors; no",
              "floor-flatness requirement is imposed anywhere in this data room, so the tabulated 2.5 governs.",
              "As UFC 3-220-01 paragraph 2-4.7.1 requires, two further widely accepted methods - the Meyerhof",
              "and the Brinch Hansen forms of the general equation of EM 1110-1-1905 Chapter 4 - were computed",
              "at every foundation as checks; the reported value is the Vesic value the design relies on, and",
              "the least of the three is never more than 6 % below it. The 3000 psf presumptive value was not",
              "used anywhere.", "",
              "The bearing stratum of each foundation was taken from the interpolated profile: the base of",
              "Stratum I is interpolated linearly between the two borings of the pad at the station of the",
              "foundation along column line A and rounded to 0.1 ft, and the thickness of Stratum II is uniform",
              "within the pad (Geotechnical Data Report Rev 2 Section 4). Each footing is reported against the",
              "stratum in which its bearing surface sits.", "",
              "## 4. Settlement method and the tolerable-movement criteria", "",
              "Settlement is **layered elastic compression**. The soil below each bearing surface is divided",
              "into uniform layers 0.25 ft thick; the net stress increment in each layer is the 2 vertical to 1",
              "horizontal approximate distribution for a rectangular loaded area; and the compressions",
              "s = (delta sigma)(H)/Es are summed with the pad-specific elastic moduli of the geotechnical data",
              "report. The integral is carried to four times the footing width below the bearing surface and in",
              "no case less than 40 ft. That method, its depth of influence and its slice thickness are fixed by",
              "RFI-019, and the equation is Equation 5-14 of FHWA GEC 13 Vol I, which is also the lower-zone",
              "term of the aggregate-pier method - so the improved and unimproved cases are computed the same",
              "way.", "",
              "The tolerable-movement criteria adopted are those of UFC 3-220-01 paragraph 2-4.7.1, which is",
              "the governing geotechnical criteria for this project: **total post-construction settlement of",
              "1 in** and an **angular distortion limit of 1/500** between adjacent foundation units - the",
              "denominator of the adopted limit is 500 (equivalently 0.002) - measured as the difference of",
              "settlement between neighbouring units divided by the distance between them. The competing",
              "tolerable-movement criterion of the FHWA shallow-foundations manual for highway bridges (FHWA",
              "GEC 6), which allows an angular distortion of 0.004 for continuous-span bridges, is explicitly",
              "**rejected and not adopted**: it is a bridge serviceability criterion written for a different",
              "class of structure, and it is more permissive than the criteria governing this building project,",
              "which state 1/500. For the record, the 0.004 criterion was reviewed and set aside as not",
              "governing; the adopted limit is 1/500, i.e. a maximum angular distortion of 0.002.", "",
              "## 5. Ground improvement: parameters and their authority", "",
              "The piers are rammed aggregate piers installed by Kettleridge Ground Systems (proposal",
              "KGS-26-0917): 30 in diameter, minimum clear spacing 1.0 ft, treatment depth between 8 ft and 25 ft",
              "below the footing soffit in whole feet, and a maximum design top-of-pier stress of 18000 psf.",
              "The **stress concentration ratio adopted is ns = 10**. That is the value the governing public",
              "ground-modification reference, FHWA GEC 13 Vol I Section 4.2.1, gives for structure foundation",
              "support under rigid footings - and it is the value RFI-011 directs to be taken from that",
              "reference. The higher ratio of 20 or more quoted in the proprietary Geopier vendor design manual",
              "is not accepted (RFI-011 excludes vendor manuals), and neither is the 5 to 10 band the same",
              "reference gives for flexible embankment loading: these are rigid spread footings under building",
              "columns, not an embankment. The adopted value for every improved pad is therefore 10.", "",
              "The area replacement ratio follows from the pier count: Ra = n A_pier/(B L) with A_pier the",
              "area of a 30 in pier, and it is held between the minimum 0.33 of GEC 13 Section 4.2.1 and the",
              "geometric ceiling the subcontractor's minimum clear spacing imposes on a staggered grid.",
              "Top-of-pier stress comes from Equation 5-12, upper-zone settlement from Equation 5-13 with the",
              "pad's own as-tested stiffness modulus (165, 140, 210, 195, 230 and 155 pci for CR-P1 ... CR-P6,",
              "all inside the 75-360 pci range of GEC 13), and the lower-zone settlement from Equation 5-14",
              "below the treatment depth. Total settlement is their sum (Equation 5-11). One production",
              "modulus test is provided per improved pad, at 9500 USD each.", "",
              "## 6. Conflicts between documents, and the governing value", "",
              "| conflict | documents | governing value adopted |", "|---|---|---|"]
    lines += [
        "| frost depth | AHJ Amendment 3 (42 in for AFI > 500) vs the 18 in minimum depth of UFC 3-220-01 2-4.8.1 | 42 in - the municipal value the criteria require to be used |",
        "| AFI edition | 1981-2010 product (556 F-days) vs 1951-1980 tables (416 F-days) | 556 F-days - the current product, per Amendment 3 and RFI-007 |",
        "| settlement method | EM 1110-1-1904 and DM 7.1 Chapter 5 (not shipped; the shipped DM 7.1 is cancelled) vs GEC 13 Eq. 5-14 | layered elastic compression per RFI-019 |",
        "| stress ratio | GEC 13 rigid-footing value 10 vs Geopier vendor manual 20+ vs GEC 13 embankment band 5-10 | 10, per RFI-011 |",
        "| bearing capacity | three methods disagree; presumptive 3000 psf | the Vesic general-equation value, not more permissive than it, per RFI-021 |",
        "| footing spacing | UFC 3-220-01 2-4.8.1 requires 1.5B; the grid does not achieve it | RFI-017: individual units, no reduction for overlapping zones |",
        "| occupancy FS | Warehouse 2.5 vs the super-flat-floor footnote above 3 | 2.5 - no floor-flatness criterion exists in this data room |",
        "| exposure classes | owner-assigned F/W/C vs the measured sulfate | the most restrictive of all assigned classes per pad (BOD Section 3) |",
        "| cost basis | bid schedule Rev 1 unit prices vs Kettleridge proposal | both, each for the work it prices; no other source |",
    ]
    lines += ["",
              "## 7. The campus programme: which pads are improved, and how many rigs", "",
              f"The programme improves **{len(basis['campus']['pads_improved'])} of the six pads** - "
              f"{', '.join(basis['campus']['pads_improved'])} - and carries",
              f"**{basis['campus']['rigs_mobilised']} mobilised rigs (rigs mobilised = {basis['campus']['rigs_mobilised']})** at "
              f"{fmt(basis['campus']['mobilisation_cost_usd'], 0)} USD. The number of rigs is not a free choice:",
              "Kettleridge proposal KGS-26-0917 Section 4 limits one mobilised rig to **at most 2 building pads**",
              "inside the Phase 1 milestone window and charges 40000 USD per rig as a lump sum, so four improved",
              "pads necessarily buy two rigs - not one rig per improved pad (which would cost 160000 USD) and not",
              "one rig for the whole campus (which the subcontractor's limit does not permit). Each rig is",
              "assigned two pads.", "",
              "Why these four pads, stated the way the numbers actually run. On the four improved pads the",
              "soft residual silt of Stratum I is thick, and on a plain spread scheme the 1 in settlement limit",
              "and the 1/500 drift limit between neighbouring units force plan sizes far above what bearing",
              "alone needs - the shear-wall footing of CR-P1 would have to be 38.75 ft wide, and five of the",
              "six footings of CR-P6 would be 18.5 ft to 24 ft. The piers cut those settlements by a factor of",
              "two to three, the plan sizes fall back to what bearing capacity requires, and the saving in",
              "concrete, reinforcement and excavation exceeds the piers, the working platform and the share of",
              "the mobilisation. At CR-P3 and CR-P5 Stratum I is only 4.5 ft to 7 ft thick, the spread scheme",
              "already meets both movement limits with compact footings, and improvement would add the piers,",
              "the modulus test and the platform without saving anything; those two pads are carried on plain",
              "spread footings. The campus total is",
              f"**{fmt(basis['campus']['total_cost_usd'], 0)} USD**.", "",
              "The comparison behind each decision, with the cost of both alternatives, is in the table above",
              "and in foundation_feasibility_matrix.md; reinforcement is priced at the ratio the design",
              "actually requires.", ""]
    (PKG / "design_basis.md").write_text("\n".join(lines))


def write_matrix():
    chosen = PROG["chosen"]
    out = ["# Foundation-type feasibility and optimisation matrix", "",
           "Every pad's six foundation units, the demand, the bearing check, the predicted settlement,",
           "the stability checks on the shear-wall footing, the constraint that governs, and the",
           "shallow-versus-improved decision with the cost of both alternatives.", ""]
    for pad in sorted(chosen):
        sol = chosen[pad]
        pb = json.loads((PKG / "foundation_geometry.json").read_text())["pads"][pad]
        spread_c = OPT[pad]["spread"]["pad_cost"]
        imp_c = OPT[pad]["improved"]["pad_cost"] if OPT[pad]["improved"] else None
        out += [f"## {pad} - {INP['pads'][pad]['building']}", "",
                f"Occupancy **{pb['occupancy_class']}** (FS {pb['fs_bearing']:.1f}), sulfate "
                f"**{pb['sulfate_exposure_class']}** from {pb['sulfate_pct']:.3f} % SO4, exposure classes "
                f"{', '.join(pb['exposure_classes'])}, f'c = {pb['fc_psi']} psi at w/cm {pb['max_wcm']:.2f}, "
                f"bearing elevation **{pb['bearing_depth_in']:.0f} in** below finished grade "
                f"(frost minimum 42 in), groundwater at {INP['gw_depth_ft'][pad]:.1f} ft.", "",
                "| foundation | type | B x L (ft) | t (in) | stratum | q_net (ksf) | q_allow (ksf) | utilisation | settlement (in) | piers | Ra | qg (psf) | governing |",
                "|---|---|---|---|---|---|---|---|---|---|---|---|---|"]
        for tag in TAGS:
            f = pb["foundations"][tag]
            util = f["q_net_ksf"] / f["q_allow_net_ksf"]
            pier = f"{f['pier_count']} @ {f['pier_depth_ft']} ft" if f["pier_count"] else "-"
            ra = f"{f['area_replacement_ratio']:.3f}" if f["area_replacement_ratio"] else "-"
            qg = str(round(f["top_of_pier_stress_psf"])) if f["top_of_pier_stress_psf"] else "-"
            out.append(f"| {tag} | {f['foundation_type']} | {f['B_in'] / 12:.2f} x {f['L_in'] / 12:.2f} | "
                       f"{f['thickness_in']:.0f} | {f['bearing_stratum']} | {f['q_net_ksf']:.3f} | "
                       f"{f['q_allow_net_ksf']:.3f} | {util * 100:.0f} % | {f['settlement_in']:.3f} | "
                       f"{pier} | {ra} | {qg} | {f['governing_constraint']} |")
        w = pb["foundations"]["W1"]
        out += ["",
                f"Shear-wall footing stability: sliding FS **{w['sliding_fs']:.3f}** against the required 2.0; "
                f"resultant eccentricity **{w['eccentricity_in']:.2f} in** against the middle-third limit of "
                f"{w['B_in']/6:.2f} in; uplift FS **{w['uplift_fs']:.3f}** against 1.0.", "",
                f"Angular distortion between adjacent units: "
                + "; ".join(f"{a}-{b} {abs(pb['foundations'][a]['settlement_in'] - pb['foundations'][b]['settlement_in']):.3f} in"
                            for a, b in zip(TAGS, TAGS[1:]))
                + " (limits 0.576, 0.480, 0.384, 0.288 and 0.120 in for the five bays of the column line).", "",
                f"**Decision: {'IMPROVED_SPREAD' if pb['improved'] else 'SPREAD'}.** Shallow spread footings alone "
                f"cost {fmt(spread_c, 0)} USD; the same pads on rammed aggregate piers cost {fmt(imp_c, 0)} USD, "
                f"so the {'improved' if pb['improved'] else 'spread'} scheme is cheaper by "
                f"{fmt(abs(spread_c - imp_c), 0)} USD. Governing constraint: **{pb['governing_constraint']}**.", ""]
    (PKG / "foundation_feasibility_matrix.md").write_text("\n".join(out))


if __name__ == "__main__":
    write_register()
    write_basis()
    write_matrix()
    print("written")
