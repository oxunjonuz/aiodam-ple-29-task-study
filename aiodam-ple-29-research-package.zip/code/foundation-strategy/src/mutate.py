#!/usr/bin/env python3
"""Mutation campaign: break the package in one way at a time and make the REAL grader notice."""
from __future__ import annotations
import json, shutil, subprocess, zipfile
from pathlib import Path

OUT = Path("/work/ple-solve/foundation-strategy/out")
PKG = OUT / "pkg"
GRAD = Path("/work/ple-dataset/tasks/foundation-strategy/tests/grading")
WORK = OUT / "mut"
WORK.mkdir(exist_ok=True)
PY = "/work/venv-verifier/bin/python"


def load():
    return (json.loads((PKG / "foundation_geometry.json").read_text()),
            json.loads((PKG / "ground_improvement_plan.json").read_text()))


def run(name, geo, plan, reg=None):
    d = WORK / name
    shutil.rmtree(d, ignore_errors=True)
    d.mkdir(parents=True)
    (d / "foundation_geometry.json").write_text(json.dumps(geo, indent=1))
    (d / "ground_improvement_plan.json").write_text(json.dumps(plan, indent=1))
    for f in ("foundation_schedule.xlsx", "foundation_feasibility_matrix.md", "design_basis.md"):
        shutil.copy(PKG / f, d / f)
    shutil.copy(reg or (PKG / "constraint_register.xlsx"), d / "constraint_register.xlsx")
    z = d / "submission.zip"
    with zipfile.ZipFile(z, "w") as f:
        for p in sorted(d.iterdir()):
            if p.suffix != ".zip":
                f.write(p, p.name)
    subprocess.run([PY, str(GRAD / "verification/run_grade.py"), str(z),
                    "--metrics-out", str(d / "metrics.json"), "--artifacts-out", str(d / "art.json"),
                    "--no-judge"], cwd=GRAD, capture_output=True, text=True)
    m = json.loads((d / "metrics.json").read_text())
    a = json.loads((d / "art.json").read_text())
    red = sorted(k for k, v in a.get("family_pass_rate", {}).items() if v < 1.0)
    print(f"{name:28s} p={m['mean_p']:.3f} h={m['physical_hard_pass_rate']:.2f} "
          f"O={m['mean_objective']:.4f} red={red}")
    return m, a


if __name__ == "__main__":
    print("baseline:")
    run("baseline", *load())
    print("mutants:")
    geo, plan = load()
    g = json.loads(json.dumps(geo))
    for f in g["pads"]["CR-P1"]["foundations"].values():
        f["thickness_in"] -= 3.0
    run("m1_thickness_minus_3in", g, plan)

    g = json.loads(json.dumps(geo))
    for p in g["pads"].values():
        p["bearing_depth_in"] = 30.0
        for f in p["foundations"].values():
            f["bearing_depth_in"] = 30.0
    run("m2_bearing_depth_30in", g, plan)

    g = json.loads(json.dumps(geo))
    f3 = g["pads"]["CR-P4"]["foundations"]["F3"]
    f3["B_in"] -= 3.0
    f3["L_in"] -= 3.0
    run("m3_p4_f3_plan_minus_3in", g, plan)

    g = json.loads(json.dumps(geo))
    g["pads"]["CR-P6"]["sulfate_exposure_class"] = "S1"     # CR-P6 is in the scored (heldout) split
    run("m4_sulfate_class_S1", g, plan)

    g = json.loads(json.dumps(geo))
    g["pads"]["CR-P1"]["fs_bearing"] = 3.0
    run("m5_fs_3_0", g, plan)

    g = json.loads(json.dumps(geo))
    pl = json.loads(json.dumps(plan))
    for f in g["pads"]["CR-P6"]["foundations"].values():
        if f["pier_depth_ft"]:
            f["pier_depth_ft"] = 5
    pl["pads"]["CR-P6"]["treatment_depth_ft"] = 5
    run("m6_pier_depth_5ft", g, pl)

    # a register missing the aggregate-pier clauses: the families are satisfied but not registered
    import openpyxl
    wb = openpyxl.load_workbook(PKG / "constraint_register.xlsx")
    ws = wb["CONSTRAINT REGISTER"]
    keep = []
    for r in ws.iter_rows(min_row=2, values_only=True):
        if r[1] and ("GEC 13" in str(r[1]) or "Kettleridge" in str(r[1])):
            continue
        keep.append(r)
    for i in range(ws.max_row, 1, -1):
        ws.delete_rows(i)
    for r in keep:
        ws.append(list(r))
    wb.save(WORK / "reg_no_piers.xlsx")
    run("m7_register_without_piers", geo, plan, reg=WORK / "reg_no_piers.xlsx")

    # a basis that never gives both alternatives a cost: D3 must go red
    bas = (PKG / "design_basis.md").read_text()
    dd = WORK / "m8"
    d = WORK / "m8_d3"
    shutil.rmtree(d, ignore_errors=True)
    d.mkdir(parents=True)
    (d / "foundation_geometry.json").write_text(json.dumps(geo, indent=1))
    (d / "ground_improvement_plan.json").write_text(json.dumps(plan, indent=1))
    for f in ("foundation_schedule.xlsx", "foundation_feasibility_matrix.md"):
        shutil.copy(PKG / f, d / f)
    shutil.copy(PKG / "constraint_register.xlsx", d / "constraint_register.xlsx")
    ob = json.loads(__import__("re").search(r"```json\s*(\{.*?\})\s*```", bas, 16).group(1))
    for p_ in ob["pads"].values():
        p_["spread_only_cost_usd"] = 0
    (d / "design_basis.md").write_text("```json\n" + json.dumps(ob, indent=1) + "\n```\n\n" + bas.split("```", 2)[2])
    z = d / "submission.zip"
    with zipfile.ZipFile(z, "w") as f:
        for p_ in sorted(d.iterdir()):
            if p_.suffix != ".zip":
                f.write(p_, p_.name)
    subprocess.run([PY, str(GRAD / "verification/run_grade.py"), str(z),
                    "--metrics-out", str(d / "metrics.json"), "--artifacts-out", str(d / "art.json"),
                    "--no-judge"], cwd=GRAD, capture_output=True, text=True)
    m = json.loads((d / "metrics.json").read_text())
    a = json.loads((d / "art.json").read_text())
    red = sorted(k for k, v in a.get("family_pass_rate", {}).items() if v < 1.0)
    print(f"{'m8_d3_no_alternative_costs':28s} p={m['mean_p']:.3f} h={m['physical_hard_pass_rate']:.2f} "
          f"O={m['mean_objective']:.4f} red={red}")
