import sys, os, docx
W = "/work/ple-dataset/tasks/heat-rejection-life-cycle-cost/environment/filesystem/final_batch4__mechanical_task3_ct_heat_lcc__blind"
out = "/work/ple-solve/heat-rejection-life-cycle-cost/docs"
def dump_docx(rel):
    p = os.path.join(W, rel)
    d = docx.Document(p)
    lines = []
    for para in d.paragraphs:
        t = para.text.rstrip()
        if t.strip():
            lines.append(t)
    for ti, tb in enumerate(d.tables):
        lines.append(f"[[TABLE {ti+1}]]")
        for row in tb.rows:
            lines.append(" | ".join(c.text.strip().replace("\n"," / ") for c in row.cells))
    name = os.path.basename(rel).replace(".docx", ".txt")
    open(os.path.join(out, name), "w").write("\n".join(lines))
    print(name, len(lines), "lines")
for rel in sys.argv[1:]:
    dump_docx(rel)
