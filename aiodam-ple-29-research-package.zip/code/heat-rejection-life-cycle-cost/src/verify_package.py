"""verify_package.py - an independent reader of the delivered package.

This does not import the grader.  It re-reads the zip with ezdxf and openpyxl, reconstructs the
scheduled design with its own parser, and checks the contract of the brief and the geometry of the
M-401 Rev C zones with its own arithmetic.
"""
from __future__ import annotations

import csv
import io
import json
import math
import os
import re
import sys
import zipfile

import ezdxf
from ezdxf import recover
import openpyxl

import plantdata as P

ZIP = "/work/ple-solve/heat-rejection-life-cycle-cost/out/submission.zip"
REQUIRED = {"DesignPoint": ["DesignWetBulb_F", "DesignLoad_tons", "HeatRejection_BTUH", "CWFlow_gpm",
                            "Range_F", "Approach_F", "CWS_F", "CWR_F", "WaterFlowRatio", "CellsInService",
                            "RedundancyWetBulb_F", "RedundancyCapacity_tons", "DryBulb996_F"],
            "WaterBalance": ["EvaporationMethod", "AnnualEvaporation_kgal", "AnnualDrift_kgal",
                             "AnnualBlowdown_kgal", "AnnualMakeup_kgal", "PeakDayMakeup_gal",
                             "CyclesOfConcentration", "MaxAllowableCOC", "ScalingIndexAtCWR"],
            "Energy": ["AnnualChillerEnergy_kWh", "AnnualFanEnergy_kWh", "AnnualPumpEnergy_kWh",
                       "AnnualPlantEnergy_kWh", "PeakCoincidentDemand_kW", "MCCSpareCapacity_kW"],
            "LifeCycleCost": ["DiscountRate", "StudyPeriod_yr", "ConstructionPeriod_yr",
                              "UPVStarElectricity", "UPVStarWater", "UPVNonFuel", "Investment_USD",
                              "AnnualEnergyCost_USD", "AnnualWaterCost_USD", "AnnualOMCost_USD",
                              "PVEnergy_USD", "PVWater_USD", "PVOM_USD", "PVReplacement_USD",
                              "PVSalvage_USD", "LCC_USD", "BasicDesignLCC_USD", "NetSavings_USD"]}
OFFCOLS = ["wetbulbf", "drybulbf", "hours", "loadtons", "chillerson", "cellson", "cwflowgpm",
           "airflowratio", "fanplr", "rangef", "cwsf", "cwrf", "chillerkw", "fankw", "pumpkw",
           "totalkw", "makeupgpm"]

fails, checks = [], 0

def check(cond, msg):
    global checks
    checks += 1
    if not cond:
        fails.append(msg)

def norm(s):
    return re.sub(r"[^a-z0-9]", "", str(s).lower())

def read_schedule(texts):
    sched = {}
    for t in texts:
        for part in re.split(r"\s*;\s*", t):
            toks = part.split()
            if len(toks) < 3:
                continue
            tag = toks[0].upper()
            key = toks[1].upper()
            val = " ".join(toks[2:])
            sched.setdefault(tag, {})[key] = val
    return sched

def main():
    zf = zipfile.ZipFile(ZIP)
    names = sorted(zf.namelist())
    check(len(names) == 8, f"zip holds {len(names)} files: {names}")
    check(len(set(n.lower() for n in names)) == len(names), "duplicate deliverable names")
    plants = P.plants()
    summary = json.load(open("/work/ple-solve/heat-rejection-life-cycle-cost/out/summary.json"))
    for pid in ("CUP", "ANNEX", "LAB"):
        # ---- DXF
        raw = zf.read(f"CT_SCHEDULE_{pid}.dxf")
        doc, auditor = recover.read(io.BytesIO(raw))
        errs = [e for e in auditor.errors]
        check(not errs, f"{pid}: ezdxf auditor reports {errs[:3]}")
        texts = []
        pads = []
        for e in doc.modelspace():
            layer = e.dxf.layer
            if e.dxftype() == "TEXT":
                if layer == "M-CTWR-SCHD":
                    texts.append(e.dxf.text)
                elif layer == "G-TBLK":
                    texts.append("")  # title block, revision checked below
                if layer == "G-TBLK":
                    texts_tblk = e.dxf.text
                    if "REVISION" in texts_tblk.upper():
                        texts.append("REVISION")
            elif e.dxftype() == "LWPOLYLINE" and layer == "M-CTWR-PLAN":
                pts = [(round(p[0], 6), round(p[1], 6)) for p in e.get_points("xy")]
                check(e.closed, f"{pid}: a pad outline is not closed")
                xs = sorted({p[0] for p in pts}); ys = sorted({p[1] for p in pts})
                check(len(pts) in (4, 5) and len(xs) == 2 and len(ys) == 2,
                      f"{pid}: pad outline is not a rectangle ({len(pts)} vertices)")
                pads.append((min(xs), min(ys), max(xs), max(ys)))
        check("REVISION" in texts, f"{pid}: no revision in the title block")
        sched = read_schedule([t for t in texts if t and t != "REVISION"])
        check("PLANT" in sched, f"{pid}: no PLANT rows")
        pl = sched["PLANT"]
        d = summary[pid]["design"]
        check(int(float(pl["CELLS"])) == d["cells"], f"{pid}: CELLS {pl['CELLS']} != {d['cells']}")
        check(float(pl["GPMTOTAL"]) == d["gpm_total"], f"{pid}: GPMTOTAL")
        check(abs(float(pl["COC"]) - d["coc"]) < 1e-9, f"{pid}: COC")
        check(abs(float(pl["CWSDESIGN"]) - d["cws_design_f"]) < 1e-9, f"{pid}: CWSDESIGN")
        check(pl["EVAPMETHOD"].upper() == "SATURATED-EXIT", f"{pid}: EVAPMETHOD")
        for k in ("BASINHEATER", "BLOWDOWNCTRL", "EQUALIZING", "BASINCLR", "WBDESIGN", "CWSMIN",
                  "CWSOFFSET", "RANGEDESIGN", "APPROACHDESIGN"):
            check(k in pl, f"{pid}: PLANT key {k} missing")
        cell_tags = [t for t in sched if t.startswith("CT-")]
        check(len(cell_tags) == d["cells"], f"{pid}: {len(cell_tags)} cell rows for {d['cells']} cells")
        for k in ("MODEL", "GPM", "FANHP", "MOTOREFF", "MOTORPOLES", "MOTORENCL", "ELIMINATOR", "DRIFT",
                  "MATERIAL", "OPWEIGHT", "SOUNDLW"):
            check(k in sched[cell_tags[0]], f"{pid}: cell key {k} missing")
            vals = {sched[t][k] for t in cell_tags}
            check(len(vals) == 1, f"{pid}: cell rows differ in {k}: {vals}")
        check(abs(float(sched[cell_tags[0]]["GPM"]) - d["gpm_total"] / d["cells"]) <=
              max(1.0, 0.02 * d["gpm_total"] / d["cells"]), f"{pid}: cell GPM != GPMTOTAL/CELLS")
        # ---- geometry, checked against the Rev C drawings
        plant = plants[pid]
        zx0, zy0, zx1, zy1 = plant["roof_zone"]
        cat = P.M.catalogue()[0][d["model"]]
        c = cat["clearance_ft"]
        check(len(pads) == d["cells"], f"{pid}: {len(pads)} pad outlines for {d['cells']} cells")
        for i, p in enumerate(pads, 1):
            w, l = p[2] - p[0], p[3] - p[1]
            check((w >= cat["plan_w_ft"] - 1e-6 and l >= cat["plan_l_ft"] - 1e-6) or
                  (l >= cat["plan_w_ft"] - 1e-6 and w >= cat["plan_l_ft"] - 1e-6),
                  f"{pid}: pad {i} {w}x{l} smaller than the {cat['plan_w_ft']}x{cat['plan_l_ft']} frame")
            check(p[0] >= zx0 + c - 1e-6 and p[1] >= zy0 + c - 1e-6 and p[2] <= zx1 - c + 1e-6
                  and p[3] <= zy1 - c + 1e-6, f"{pid}: pad {i} breaks the {c} ft clearance in the zone")
            for (ix, iy) in plant["intakes"]:
                dx = max(p[0] - ix, ix - p[2], 0.0); dy = max(p[1] - iy, iy - p[3], 0.0)
                dist = math.hypot(dx, dy)
                check(dist >= 25.0 - 1e-6, f"{pid}: pad {i} {dist:.1f} ft from an intake")
            fz = [z for z in plant["framing_zones"] if z["rect"][0] <= p[0] and z["rect"][1] <= p[1]
                  and z["rect"][2] >= p[2] and z["rect"][3] >= p[3]]
            check(bool(fz), f"{pid}: pad {i} spans two framing zones")
            if fz:
                psf = cat["op_weight_lb"] / (cat["plan_w_ft"] * cat["plan_l_ft"])
                check(psf <= max(z["allow_psf"] for z in fz) + 1e-6,
                      f"{pid}: pad {i} {psf:.1f} psf over {fz[0]['allow_psf']} psf")
        for i in range(len(pads)):
            for j in range(i + 1, len(pads)):
                a, b = pads[i], pads[j]
                dx = max(b[0] - a[2], a[0] - b[2], 0.0); dy = max(b[1] - a[3], a[1] - b[3], 0.0)
                gap = math.hypot(dx, dy) if dx > 0 and dy > 0 else max(dx, dy)
                check(gap >= c - 1e-6, f"{pid}: pads {i + 1} and {j + 1} only {gap:.1f} ft apart")
        # ---- XLSX
        wb = openpyxl.load_workbook(io.BytesIO(zf.read(f"CT_CALC_{pid}.xlsx")), data_only=True)
        check(set(wb.sheetnames) >= set(REQUIRED) | {"OffDesign"}, f"{pid}: sheets {wb.sheetnames}")
        kv = {}
        for sheet, keys in REQUIRED.items():
            vals = {}
            for row in wb[sheet].iter_rows(values_only=True):
                if row and row[0] is not None:
                    vals[norm(row[0])] = row[1] if len(row) > 1 else None
            for k in keys:
                check(norm(k) in vals, f"{pid}: {sheet}.{k} missing")
                if norm(k) in vals and k != "EvaporationMethod":
                    check(isinstance(vals[norm(k)], (int, float)),
                          f"{pid}: {sheet}.{k} is not numeric ({vals[norm(k)]!r})")
            kv[sheet] = vals
        od = list(wb["OffDesign"].iter_rows(values_only=True))
        hdr = [norm(h) for h in od[0]]
        for col in OFFCOLS:
            check(col in hdr, f"{pid}: OffDesign column {col} missing")
        body = [r for r in od[1:] if r and any(v is not None for v in r)]
        check(len(body) >= 40, f"{pid}: OffDesign has {len(body)} rows")
        blanks = sum(1 for r in body for i, h in enumerate(hdr) if h in OFFCOLS and
                     not isinstance(r[i], (int, float)))
        check(blanks == 0, f"{pid}: {blanks} non-numeric OffDesign cells")
        hsum = sum(r[hdr.index("hours")] for r in body)
        check(abs(hsum - 8760.0) <= 0.02 * 8760.0, f"{pid}: OffDesign hours {hsum:.1f}")
        # component energies and the LCC identities, recomputed from the sheets
        e = kv["Energy"]
        parts = sum(e[norm(k)] for k in ("AnnualChillerEnergy_kWh", "AnnualFanEnergy_kWh",
                                          "AnnualPumpEnergy_kWh"))
        check(abs(parts - e[norm("AnnualPlantEnergy_kWh")]) <= max(1.0, 0.02 * parts),
              f"{pid}: component energies {parts:.0f} do not sum to the plant energy")
        tot_kw = [r[hdr.index("totalkw")] for r in body]
        check(abs(max(tot_kw) - e[norm("PeakCoincidentDemand_kW")]) <= 0.01,
              f"{pid}: reported peak {e[norm('PeakCoincidentDemand_kW')]} is not the maximum of the "
              f"off-design rows ({max(tot_kw)}) beyond rounding")
        l = kv["LifeCycleCost"]; g = lambda k: l[norm(k)]
        lcc_id = g("Investment_USD") + g("PVEnergy_USD") + g("PVWater_USD") + g("PVOM_USD") + \
            g("PVReplacement_USD") - abs(g("PVSalvage_USD"))
        check(abs(lcc_id - g("LCC_USD")) <= max(1000.0, 0.01 * g("LCC_USD")), f"{pid}: LCC identity")
        check(abs(g("BasicDesignLCC_USD") - g("LCC_USD") - g("NetSavings_USD")) <=
              max(1000.0, 0.01 * g("BasicDesignLCC_USD")), f"{pid}: net savings identity")
        check(g("PVEnergy_USD") / g("AnnualEnergyCost_USD") == g("UPVStarElectricity") or
              abs(g("PVEnergy_USD") / g("AnnualEnergyCost_USD") - g("UPVStarElectricity")) < 1e-4,
              f"{pid}: PV energy is not annual x UPV*")
        # ---- schedule vs workbook agreement (my own arithmetic)
        rep_cws = kv["DesignPoint"][norm("CWS_F")]
        app = kv["DesignPoint"][norm("Approach_F")]
        check(float(pl["CWSDESIGN"]) - max(0.8, 0.10 * abs(rep_cws)) <= rep_cws <= float(pl["CWSDESIGN"]) + 0.5,
              f"{pid}: DesignPoint CWS {rep_cws} not inside the achieved-to-scheduled band under "
              f"CWSDESIGN {pl['CWSDESIGN']}")
        check(g("NetSavings_USD") > 0, f"{pid}: no net savings")
        print(f"{pid}: {len(pads)} pads, {len(body)} off-design rows, hours {hsum:.1f}, "
              f"COC {pl['COC']}, LCC {g('LCC_USD'):,.0f}, NS {g('NetSavings_USD'):,.0f}")
    # ---- register and basis
    reg = zf.read("constraint_register.csv").decode("utf-8")
    rows = list(csv.DictReader(io.StringIO(reg)))
    check(len(rows) >= 40, f"register has {len(rows)} rows")
    check(all({"id", "document", "clause", "requirement", "value"} <= set(r) and
              ("items bound" in r or "items_bound" in r) for r in rows), "register columns")
    check(len({r["id"] for r in rows}) == len(rows), "register ids are not unique")
    basis = zf.read("design_basis.md").decode("utf-8")
    gov = re.findall(r"^GOVERNING CONSTRAINT (CUP|ANNEX|LAB): (.+?) \(relative margin (-?[\d.]+)\)",
                     basis, re.M)
    check(len(gov) == 3, f"design basis has {len(gov)} governing lines")
    for pid, nm, mg in gov:
        check(nm.strip() in {"water allocation", "electrical capacity", "roof area", "structural capacity",
                             "condenser flow limit", "tower capability"}, f"{pid}: bad name {nm!r}")
        check(abs(float(mg) - summary[pid]["margins"][nm.strip()]) <= 0.004, f"{pid}: stated margin")
    check(len(re.findall(r"^CONFLICT [123]:", basis, re.M)) == 3, "three conflict lines")
    check("3-410-01" in basis and "2-4.2.4" in basis, "weather clause not stated")
    check("saturated-exit" in basis, "evaporation formulation not stated")
    check(re.search(r"99\.6\s*(%|percent)?[^\n]{0,80}41\.0", basis) is not None, "99.6 % DB not stated")
    check(re.search(r"basin\s+heat", basis, re.I) is not None, "basin heater determination not stated")
    print(f"register rows {len(rows)}, governing lines {len(gov)}")
    print(f"\n{checks} checks, {len(fails)} failures")
    for f in fails:
        print("  FAIL:", f)
    return 0 if not fails else 1

if __name__ == "__main__":
    sys.exit(main())
