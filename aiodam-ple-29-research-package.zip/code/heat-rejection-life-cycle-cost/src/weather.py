"""weather.py - the climatic basis of DC-02 5.1-5.4, computed from the NCEI LCD record.

Only FM-15 / FM-16 rows are observations (5.1).  Where the record does not report a wet bulb it is
computed from the dry bulb and the reported humidity with the psychrometric relations of DC-02 5.5
(dew point when present, relative humidity otherwise), at the mean station pressure of the POR.
"""
from __future__ import annotations

import csv
import math
import os

import ctmodel as M

FILES = ["LCD_72278023183_PHOENIX_AIRPORT_AZ_2022.csv",
         "LCD_72278023183_PHOENIX_AIRPORT_AZ_2023.csv",
         "LCD_72278023183_PHOENIX_AIRPORT_AZ_2024.csv"]

_FLAG = __import__("re").compile(r"[A-Za-z*]+$")

def _f(x):
    """An NCEI LCD value, tolerating the quality flag the record appends to it ('85s', '50s', '*')."""
    if x is None:
        return None
    t = str(x).strip()
    if not t or t == "*":
        return None
    t = _FLAG.sub("", t)
    try:
        return float(t)
    except (TypeError, ValueError):
        return None

def _read():
    rows = []
    for fn in FILES:
        with open(os.path.join(M.WB, "climate", fn), newline="") as fh:
            for r in csv.DictReader(fh):
                if r["REPORT_TYPE"] not in ("FM-15", "FM-16"):
                    continue
                rows.append(r)
    return rows

def observations():
    rows = _read()
    ps = [_f(r["HourlyStationPressure"]) for r in rows]
    ps = [p * 3386.389 for p in ps if p is not None]      # inHg -> Pa
    p_mean = sum(ps) / len(ps)
    obs = []
    for r in rows:
        tdb = _f(r["HourlyDryBulbTemperature"])
        if tdb is None:
            continue
        p = _f(r["HourlyStationPressure"])
        p = p * 3386.389 if p is not None else p_mean
        twb = _f(r["HourlyWetBulbTemperature"])
        if twb is None:
            tdp = _f(r["HourlyDewPointTemperature"])
            rh = _f(r["HourlyRelativeHumidity"])
            if tdp is not None:
                w = M.w_from_dewpoint(M.f2c(tdp), p)
            elif rh is not None:
                wsat = M.w_sat(M.f2c(tdb), p)
                w = max(rh / 100.0 * wsat, 1e-5)
            else:
                continue
            twb = M.c2f(M.twb_from_tdb_w(M.f2c(tdb), w, p))
        obs.append({"twb_f": twb, "tdb_f": tdb, "pressure_pa": p})
    return obs, p_mean

def percentile_exceeded(vals, pct):
    """The value exceeded pct percent of the observations over the whole POR."""
    v = sorted(vals)
    n = len(v)
    k = min(max(int(round(n * (1.0 - pct / 100.0))), 0), n - 1)
    return v[k]

def bins(obs, wb_w=2.0, db_w=5.0, hours_year=8760.0):
    counts = {}
    for o in obs:
        wb_lo = math.floor(o["twb_f"] / wb_w) * wb_w
        db_lo = math.floor(o["tdb_f"] / db_w) * db_w
        counts[(wb_lo, db_lo)] = counts.get((wb_lo, db_lo), 0) + 1
    scale = hours_year / len(obs)
    out = []
    for (wb_lo, db_lo), c in sorted(counts.items()):
        wb_m = wb_lo + wb_w / 2.0
        db_m = max(db_lo + db_w / 2.0, wb_m)             # 5.3: DB not below the WB mid-point
        out.append({"twb_f": wb_m, "tdb_f": db_m, "hours": c * scale})
    return out

def weather_basis():
    obs, p_mean = observations()
    wb1 = percentile_exceeded([o["twb_f"] for o in obs], 1.0)
    wb04 = percentile_exceeded([o["twb_f"] for o in obs], 0.4)
    db996 = percentile_exceeded([o["tdb_f"] for o in obs], 99.6)
    return {"n_obs": len(obs), "pressure_pa": p_mean, "wb_1pct": wb1, "wb_04pct": wb04,
            "db_996": db996,
            "design_wb_f": wb1 + 5.0,        # UFC 3-410-01 2-4.2.4: +5 deg F for open cooling towers
            "redundancy_wb_f": wb04 + 5.0}   # P100 5.1.3 with the same adder (RFI-031 Response 1)

if __name__ == "__main__":
    w = weather_basis()
    print({k: (round(v, 4) if isinstance(v, float) else v) for k, v in w.items()})
    obs, _ = observations()
    b = bins(obs)
    print("bins:", len(b), "hours: %.2f" % sum(x["hours"] for x in b))
