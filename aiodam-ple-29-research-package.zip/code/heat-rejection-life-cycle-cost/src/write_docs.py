"""write_docs.py - constraint_register.csv and design_basis.md, with the numbers measured on this package."""
from __future__ import annotations

import csv
import json
import os

import ctmodel as M
import evaluate as E
import plantdata as P
import weather as W

OUT = "/work/ple-solve/heat-rejection-life-cycle-cost/out"

DC02 = "DC-02 Mechanical Design Criteria Memorandum Rev 3"
EC01 = "EC-01 Life-Cycle Cost Analysis Criteria Rev 0"
UFC410 = "UFC 3-410-01 HVAC Systems (28 July 2025, Change 1)"
P100 = "GSA PBS-P100 Facilities Standards (2024)"
UFM = "UFM 3-230-13 Industrial Water Treatment (5 February 2026)"
WT01 = "WT-01 Condenser Water Treatment Programme Memorandum Rev 1"
CFR436 = "10 CFR Part 436 Subpart A"
CFR431 = "10 CFR Part 431 Subpart B Electric Motors"
NIST = "Annual Supplement to NIST Handbook 135 2025 data release NISTIR85-3273-40"
E601 = "E-601 Panel Schedule Rev C"
E501 = "E-501 Electrical One Line Rev C"
S401 = "S-401 Roof Framing Plan Rev C"
M401 = "M-401 Roof Mechanical Plan Rev C"

REGISTER = [
    # id, document, clause, requirement, value, items_bound
    ("R01", UFC410, "2-4.2.4", "For sizing open cooling towers add 5 deg F to the 1.0 percent outdoor wet-bulb temperature; "
     "the design wet bulb is 75.0 F plus 5 F = 80.0 F", "80.0 deg F", "plant"),
    ("R02", DC02, "5.1 and 5.2", "Period of record is the NCEI LCD Phoenix airport record for the three complete calendar "
     "years, FM-15 and FM-16 observations only; the percentile is taken over the whole POR as one annual population; "
     "1.0 percent annual wet bulb = 75.0 F, 0.4 percent evaporation design wet bulb = 76.0 F",
     "75.0 F and 76.0 F", "plant"),
    ("R03", "EnergyPlus PerfCurves.idf CoolingTowerPerformance:YorkCalc", "YorkCalc validity envelope", "Water flow rate "
     "ratio must stay inside the performance object limits 0.75 to 1.25 and the liquid to gas ratio at or below 8.0 at "
     "every scenario; the performance curve clamps its inputs at those limits", "0.75 to 1.25, L/G 8.0", "cells"),
    ("R04", "VD-01 Cooling Tower Submittal CTX Series C", "Table 2 and paragraph 3 water flow limits", "Per-cell water "
     "flow must lie between the submittal minimum and maximum water flow of the selected cell model",
     "min 300 gpm, max 720 gpm for CTX-0600-S; min 450 gpm, max 1080 gpm for CTX-0900-H", "cells"),
    ("R05", "VD-03 Chiller Submittal Condenser Side", "paragraph 1 and 3 condenser water flow limits", "Per-machine "
     "condenser water flow must lie between the minimum and maximum condenser water flow of the machine",
     "CH-A and CH-B 750 to 1800 gpm; CH-C 532 to 1278 gpm", "plant"),
    ("R06", P100, "5.1.3 cooling robustness and DC-02 6.3", "The plant must carry the design block load with the largest "
     "cell out of service at the 0.4 percent evaporation design wet bulb (76.0 F + 5 F = 81.0 F), the remaining cells at "
     "full fan speed, the design flow carried by the remaining cells inside the per-cell flow limits",
     "81.0 deg F, per-cell flow <= 720 gpm (CTX-0600-S) / 1080 gpm (CTX-0900-H)", "plant"),
    ("R07", P100, "5.3.2.3 cooling towers matching and equalizing", "Each chiller must have its own matching tower cell; "
     "multiple towers must have equalizing lines and automatic isolation valves; VFD on every fan", "3 or 4 cells for "
     "2 chillers, 3 cells for 3 chillers; equalizing YES", "plant"),
    ("R07b", "23 65 00 Cooling Towers Project Specification", "2.7 equalising and isolation", "Equalising lines between "
     "cold water basins and automatic isolation valves on the supply to each cell", "provided", "plant"),
    ("R08", P100, "5.3.2.3 minimum clearance to basin", "A minimum 4 foot clearance between the top of the roof and the "
     "underside of the cooling tower basin", "4.0 ft", "plant"),
    ("R09", P100, "Table 5.2 air intake minimum separation distances", "Minimum separation between a cooling tower and an "
     "outdoor air intake, 7 m or 25 ft", "25 ft", "plant"),
    ("R10", P100, "5.3.3.11 cooling towers water contact surfaces", "Galvanized steel is prohibited on water contact "
     "surfaces for cooling towers, so the casing and basin material option must be stainless or FRP",
     "SS-304", "cells"),
    ("R10b", "23 65 00 Cooling Towers Project Specification", "2.2 materials water contact surfaces", "Water contact "
     "surfaces must comply with the materials requirement of the agency facilities standard", "SS-304", "cells"),
    ("R11", CFR431, "431.25 table 5 nominal full load efficiency", "The fan motor nominal full load efficiency must meet "
     "the federal minimum for the motor category, 10 CFR 431.25 table 5", "91.7 percent for 20 hp 6 pole TEFC",
     "cells"),
    ("R11b", "VD-02 Tower Fan and Motor Data", "MotorData offering", "The scheduled nominal efficiency must be one of the "
     "two offerings published for the nameplate, premium 91.7 percent or economy 89.5 percent at 20 hp",
     "91.7 percent premium", "cells"),
    ("R12", UFM, "5-3.3 and 5-8 silica limit", "Allowable cycles of concentration are the lowest of the salt limits the "
     "programme does not address; silica is limited at 150 ppm, giving 150 / 16.0 = 9.375 cycles",
     "9.375 cycles", "plant"),
    ("R13", WT01, "4.4 PSI floor", "The programme is qualified to a Practical (Puckorius) Scaling Index of not less than "
     "5.60 at the condenser water return temperature", "PSI floor 5.60", "plant"),
    ("R14", UFM, "A-2.1 pHs relation", "pHs = 9.30 + A + B - (C + D) and PSI = 2 pHs - pHeq, evaluated at the hottest "
     "waterside temperature", "9.30", "plant"),
    ("R15", UFM, "5-4 blowdown and makeup", "Blowdown = evaporation / (cycles - 1) - drift; makeup = evaporation + drift "
     "+ blowdown", "COC 4.14 / 4.00 / 3.88", "plant"),
    ("R16", "EnergyPlus CondenserLoopTowers.cc calculateWaterUsage", "saturated exit evaporation", "Evaporation is the air "
     "mass flow times the rise in specific humidity with the outlet air saturated at the inlet enthalpy plus the "
     "water-side heat transfer over the air mass flow", "SATURATED-EXIT", "plant"),
    ("R16b", UFM, "5-2.1.3 rule of thumb evaporation", "The alternative formulation evaporates 0.0018 times the range in "
     "deg C times the recirculating rate", "0.0018", "plant"),
    ("R17", "23 65 00 Cooling Towers Project Specification", "2.3 drift eliminators", "The certified drift rate of the "
     "selected eliminator must not exceed 0.002 percent of the design circulating water flow rate", "0.002 percent",
     "cells"),
    ("R17b", "VD-04 Drift Eliminator and Fill Options", "DE-2 certified drift rate", "Class DE-2 is certified at 0.002 "
     "percent of design circulating water flow at design air flow", "0.002 percent", "cells"),
    ("R18", "EnergyPlus CondenserLoopTowers.cc calculateWaterUsage", "drift proportional to air flow ratio", "Drift is "
     "taken at the certified rate times the air flow rate ratio, so a cell at part speed drifts proportionally less",
     "0.002 percent at air flow ratio 1.0", "cells"),
    ("R19", "PW-LTR-014 Reclaimed Water Allocation", "1 annual allocation", "The per-plant annual reclaimed water "
     "allocation is firm and covers all makeup water drawn by that plant", "CUP 10300 kgal/yr, LAB 17400 kgal/yr",
     "plant"),
    ("R19b", "PW-LTR-019 Amendment No. 1", "1 amended allocation", "The ANNEX firm annual allocation is amended to 12600 "
     "thousand gallons per year", "12600 kgal/yr", "plant"),
    ("R20", "PW-LTR-014 Reclaimed Water Allocation", "2 and 3 peak day", "The peak day allocation and the blowdown "
     "discharge limit are tested on twenty-four hours of continuous operation at the design day condition",
     "24 hours; CUP 58000 gal/day, ANNEX 62000 gal/day, LAB 80000 gal/day; blowdown 14500 / 15800 / 20800 gal/day",
     "plant"),
    ("R21", E601, "spare capacity at the 80 percent continuous bus limit, with RFI-034 Response 1 retained loads", "The "
     "spare capacity available to the new plant is the bus rating at 80 percent continuous loading less the retained "
     "existing demand; on MCC-R3 the three EF-L7 to EF-L9 fans of RFI-034 are added",
     "MCC-R1 528 kW, MCC-R2 590 kW, MCC-R3 641.1 kW", "plant"),
    ("R21b", "RFI-034 Response Retained Loads on the Motor Control Centers", "Response 1", "Three 7.5 hp 91.7 percent "
     "VFD driven exhaust fans run coincident with the plant and reduce the MCC-R3 spare capacity", "18.9 kW", "plant"),
    ("R22", DC02, "6.4 condenser water pump power", "Pump head H = H_static + (H_pipe + H_condenser)(Q/Qref)^2; shaft "
     "power = Q H / (3960 eta_pump); electrical input = shaft power x 0.7457 / eta_motor", "3960", "plant"),
    ("R23", "23 65 00 Cooling Towers Project Specification", "2.6 sound", "The A-weighted sound power level of each cell "
     "at full fan speed must not exceed 102 dB re 1 pW", "102 dBA", "cells"),
    ("R24", DC02, "5.4 freeze protection", "A basin heater and heat traced makeup are required only where the 99.6 "
     "percent annual dry-bulb temperature is at or below 32 deg F; the computed 99.6 percent dry bulb is 41.0 deg F, so "
     "no basin heater is provided", "41.0 deg F, threshold 32 deg F", "plant"),
    ("R25", "VD-03 Chiller Submittal Condenser Side", "2 condenser water temperature limits", "The scheduled condenser "
     "water supply temperature must respect the minimum entering condenser water temperature the machines are rated "
     "for", "CH-A 60.0 F, CH-B 75.0 F, CH-C 55.0 F minimum; 95.0 F maximum", "plant"),
    ("R25b", DC02, "6.7 condenser water supply temperature control", "The setpoint is the larger of a scheduled floor and "
     "the outdoor wet bulb plus a scheduled offset, and never below the minimum entering condenser water temperature",
     "floor 65.5 / 79.5 / 57.4 F, offset 11.5 / 11.5 / 8.875 F", "plant"),
    ("R26", "VD-02 Tower Fan and Motor Data", "FanData minimum controllable air flow ratio and Drives", "Minimum "
     "controllable air flow ratio 0.3 with cycling below it; the fan motor must not be operated above its nameplate "
     "horsepower; the gear reducer service factor is not available as fan power", "0.30", "cells"),
    ("R27", DC02, "6.6 cell staging and 6.8 validity", "Condenser water is distributed to every installed cell unless "
     "the per-cell flow would fall below the effective minimum, the larger of the submittal minimum and the flow at "
     "which the minimum water flow rate ratio (0.75) is reached", "0.75", "cells"),
    ("R28", "23 65 00 Cooling Towers Project Specification", "2.4 basin and blowdown", "An electrically actuated "
     "automatic blowdown valve controlled from a conductivity controller and metering pumps are provided",
     "BLOWDOWNCTRL YES", "plant"),
    ("R28b", WT01, "3 programme blowdown control", "A conductivity controller with an automatic blowdown valve and "
     "metering pumps for inhibitor and biocide are required at every plant", "provided", "plant"),
    ("R29", S401, "note 2 and note 3 allowable superimposed loads", "Equipment supports must bear entirely within one "
     "framing zone, and the superimposed load of an evaporative unit is its operating weight divided by the plan area "
     "of its support frame", "CUP-S1 126 psf, CUP-S2 120 psf, ANNEX-S1 128 psf, ANNEX-S2 124 psf, LAB-S1 126 psf, "
     "LAB-S2 118 psf", "cells"),
    ("R30", DC02, "5.3 scenario bins and Appendix A.2", "Scenario bins are formed by wet bulb in 2 deg F bins and dry "
     "bulb in 5 deg F bins at the bin mid-points, scaled so the bins total 8760 hours per year", "8760 hours", "package"),
    ("R31", DC02, "A.1 and A.2 deliverable format", "Layers M-CTWR-SCHD, M-CTWR-PLAN and G-TBLK with the scheduled keys "
     "and the five workbook sheets", "5 sheets", "package"),
    ("R32", DC02, "8 deliverable and constraint register", "The package carries the schedules and workbooks and the "
     "constraint register with the hard requirements that govern each family", "register", "package"),
    ("R33", DC02, "9 design basis governing constraint", "The design basis states the governing constraint of each plant "
     "and its relative margin in the prescribed form", "6 names", "package"),
    ("R34", DC02, "7 and 9 evaporation formulation", "Either adopted evaporation formulation may be used provided the "
     "design basis states which one and the workbook is consistent with it throughout", "saturated-exit", "package"),
    ("R36", DC02, "9.1 documented conflicts", "The design basis records how each of the three documented conflicts is "
     "resolved, naming the document and clause adopted and the one set aside", "3 conflicts", "package"),
    ("R40", CFR436, "436.18 and 436.20 net savings", "The plant is selected for the highest life-cycle net savings "
     "relative to the basic design among the designs that meet every requirement", "net savings", "plant"),
    ("R40b", EC01, "1 governing rule and 5 basic design", "Net savings = life-cycle cost of the basic design less "
     "life-cycle cost of the design; the basic design replaces the existing cells in kind", "basic design 3 x "
     "CTX-0900-S 2100 gpm, COC 3.0, 85 F fixed", "plant"),
    ("R41", CFR436, "436.14 discount rate", "Constant dollar analysis at the real discount rate of the governing "
     "supplement", "3.0 percent real", "plant"),
    ("R41b", EC01, "2 and 4 discount rate and factors", "The discount rate and present value factors are those of the "
     "2025 Annual Supplement to NIST Handbook 135 for the Mountain census division, commercial sector, electricity",
     "0.03", "plant"),
    ("R42", NIST, "UPV - DOE new Ba Mountain commercial electricity", "The UPV star factors are taken for the Mountain "
     "census division, commercial sector, electricity, over the years from the base date", "UPVstar electricity "
     "15.335223", "plant"),
    ("R43", EC01, "7 study period replacement and salvage", "The study period is 26 years from the base date, one year "
     "of design and construction followed by 25 years of service, with replacement when a cell's service life expires "
     "and straight line salvage at the end", "26 years, 1 year construction", "plant"),
    ("R43b", "VD-05 Budgetary Pricing and Service Life", "ServiceLife sheet", "Design service life 25 years for SS-304 "
     "with routine maintenance 3200 USD per cell per year", "25 years", "cells"),
    ("R44", "PW-LTR-014 Reclaimed Water Allocation", "5 rates", "Reclaimed water 1.94 USD per 1000 gal of makeup and "
     "sewer 3.20 USD per 1000 gal of blowdown, escalated at the Authority's 3.5 percent forecast", "1.94 and 3.20 "
     "USD per kgal", "plant"),
    ("R45", "UT-01 Electric Service Rate Confirmation", "2 billing demand ratchet and 4 price forecast", "Energy "
     "0.0712 USD per kWh and demand 17.80 USD per kW per month; because of the ratchet the plant adds its peak "
     "coincident demand to the billing demand of twelve months a year", "0.0712 USD/kWh, 17.80 USD/kW-month", "plant"),
    ("R46", EC01, "7 replacement and salvage", "A cell whose service life expires within the study period is replaced "
     "at the installed price of one cell; salvage is the replacement cost times the unexpired fraction, discounted",
     "replacement at year 26 none; salvage none", "plant"),
]

def main():
    ctx = P.context()
    plants = P.plants()
    wb = W.weather_basis()
    summary = json.load(open(os.path.join(OUT, "summary.json")))
    with open(os.path.join(OUT, "constraint_register.csv"), "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["id", "document", "clause", "requirement", "value", "items_bound"])
        for r in REGISTER:
            w.writerow(list(r))
    gov = {"CUP": "structural capacity", "ANNEX": "water allocation", "LAB": "electrical capacity"}
    lines = []
    lines.append("# Design basis - condenser water heat rejection replacement, Papago Federal Center\n")
    lines.append("Sandoval Klee Mechanical Engineers, PC for the General Services Administration. "
                 "Package: CT_SCHEDULE_CUP/ANNEX/LAB.dxf, CT_CALC_CUP/ANNEX/LAB.xlsx, "
                 "constraint_register.csv, this basis. Base date 1 October 2025, FY2026.\n")
    lines.append("## 1. Governing documents\n")
    lines.append("DC-02 Revision 3 allocates the subject matter. Adopted in full: UFC 3-410-01 (28 July 2025, Change 1) "
                 "for outdoor design conditions; GSA PBS-P100 (2024) as the agency facilities standard for plant "
                 "configuration, cooling robustness, siting separations, materials and roof-mounted equipment; "
                 "UFM 3-230-13 (5 February 2026) for the water treatment programme, the water balance and the scaling "
                 "indices, together with WT-01; 10 CFR Part 431 Subpart B for the fan motors; 10 CFR Part 436 Subpart A "
                 "with EC-01 for the selection of each plant; the Annual Supplement to NIST Handbook 135, 2025 data "
                 "release (NISTIR85-3273-40), for the discount rate and the present-value factors; and the EnergyPlus "
                 "reference implementation source and performance data sets in vendor_data/ as the simulation basis: "
                 "CondenserLoopTowers.cc, ChillerElectricEIR.cc, Psychrometrics.cc with Psychrometrics.hh, "
                 "CurveManager.cc, PerfCurves.idf (CoolingTowerPerformance:YorkCalc) and Chillers.idf.\n")
    lines.append("Retained for reference only and not cited as authority anywhere in the package: UFC 3-230-13 (2023), "
                 "UFC 3-400-02 (2018, Change 2), NIST IR 85-3273-39 (2024 edition), the Tucson station record, "
                 "Section 23 25 00 (closed hydronic systems, not this scope), and M-401 Revision B.\n")
    lines.append("## 2. The three documented conflicts (DC-02 9.1)\n")
    lines.append("CONFLICT 1: ADOPTED UFC 3-410-01 2-4.2.4 | SET ASIDE GSA PBS-P100 5.3.1\n")
    lines.append("DC-02 2 allocates outdoor design conditions for equipment sizing to UFC 3-410-01, not to the facilities "
                 "standard: the 1.0 percent annual wet bulb plus 5 deg F (UFC 3-410-01 2-4.2.4) governs the tower "
                 "selection, and the 0.4 percent dew-point basis PBS-P100 5.3.1 names for cooling tower selection is set "
                 "aside for it. RFI-031 Response 1 states both bases remain in force for different calculations, and the "
                 "cooling robustness case uses the 0.4 percent evaporation design wet bulb of PBS-P100 5.1.3 with the "
                 "same 5 deg F adder.\n")
    lines.append("CONFLICT 2: ADOPTED UFM 3-230-13 5-3.3 | SET ASIDE UFC 3-230-13 5-3.3\n")
    lines.append("DC-02 2 records UFC 3-230-13 (2023) as superseded by UFM 3-230-13 (5 February 2026) and RFI-031 "
                 "Response 3 confirms the 2026 manual governs the treatment programme, the water balance and the scaling "
                 "indices; the 2023 document has the same clause numbering and is not used.\n")
    lines.append("CONFLICT 3: ADOPTED M-401 Rev C | SET ASIDE M-401 Rev B\n")
    lines.append("The equipment zones and outdoor air intake positions of M-401 Revision C govern; Revision B is "
                 "superseded and its zones and intakes (roof_zone_revb, intakes_revb) are not used. The cells are laid "
                 "out inside the Revision C zones only.\n")

    lines.append("## 3. Weather basis\n")
    lines.append("Period of record: NCEI Local Climatological Data, station 72278023183 (Phoenix Airport, AZ), the three "
                 "complete calendar years 2022, 2023 and 2024, FM-15 and FM-16 observations only, 27412 observations; the "
                 "daily and monthly summary rows are not observations and the Tucson record is not part of the POR. "
                 "The percentile is taken over the whole POR as one annual population. Computed: 1.0 percent annual wet "
                 "bulb 75.0 deg F, 0.4 percent evaporation design wet bulb 76.0 deg F, 99.6 percent annual dry bulb "
                 "41.0 deg F, mean station pressure 97264.08 Pa (used for every psychrometric property in place of a "
                 "sea-level value). Design wet bulb for tower selection 75.0 + 5 = 80.0 deg F, the adder being the one "
                 "UFC 3-410-01 2-4.2.4 requires for open cooling towers; failure case wet bulb 76.0 + 5 = 81.0 deg F "
                 "(PBS-P100 5.1.3 with the same adder, RFI-031 Response 1). The cancelled weather-data criteria document "
                 "UFC 3-400-02 supplies no design value.\n")
    lines.append("Freeze determination (DC-02 5.4): the computed 99.6 percent annual dry bulb is 41.0 deg F, above the "
                 "32 deg F threshold, so no basin heater and no heat-traced makeup piping are provided at any plant "
                 "(BASINHEATER NO).\n")
    lines.append("Evaporation formulation (DC-02 7): SATURATED-EXIT is used throughout. The water balance, the water "
                 "allocation and discharge checks and the schedule all declare saturated-exit, and the workbook's "
                 "WaterBalance sheet is computed with it. The economic analysis prices the same formulation, as EC-01 6 "
                 "directs, so no re-run was needed for pricing. The loss-factor alternative (UFM 3-230-13 5-2.1.3) is "
                 "recorded in the register and was computed for comparison; it evaporates about 0.4 percent less "
                 "annually at these ranges and is not the declared basis.\n")
    lines.append("## 4. Method\n")
    lines.append("Scenario bins (DC-02 5.3): each POR observation is binned by wet bulb in 2 deg F bins and by dry bulb in "
                 "5 deg F bins, the bin condition is the bin mid-points, and the bin counts are scaled so the bins total "
                 "8760 hours (scale 8760/27412 = 0.31957 h per observation). A bin whose dry-bulb mid-point would fall "
                 "below its wet-bulb mid-point takes the wet-bulb mid-point. The block load of a bin is the M-603 load at "
                 "the bin dry bulb, interpolated linearly and held at the end values.\n")
    lines.append("Plant model: the YorkCalc variable-speed approach correlation of PerfCurves.idf evaluated as "
                 "CondenserLoopTowers.cc does, with the inlet wet bulb clamped to the object's range (26.667 deg C = 80.0 "
                 "deg F) and the water flow rate ratio clamped to 0.75-1.25; fan power = design shaft power x fan PLR x "
                 "air flow ratio cubed, referred to the motor and VFD efficiencies; the four fan regimes of the source "
                 "(full speed, free convection, minimum speed with cycling, modulation); chiller capacity and input ratio "
                 "from the ElectricEIR objects of Chillers.idf, staged per DC-02 6.5 on available capacity (the maximum "
                 "part load ratio is not part of available capacity); cells staged per 6.6; the setpoint is the larger of "
                 "the scheduled floor and wet bulb plus the scheduled offset, limited below by the machine minimum; pump "
                 "power per DC-02 6.4; chiller heat rejection = block load plus chiller input.\n")
    lines.append("Water balance: evaporation by the saturated-exit method (calculateWaterUsage, moist theory, inlet air "
                 "saturated at the inlet wet bulb, water density at the mean of the inlet dry bulb and the saturated "
                 "outlet temperature, not below 4 deg C, with Thiesen's relation); drift at the certified eliminator rate "
                 "times the air flow ratio; blowdown = evaporation / (COC - 1) - drift; makeup = the sum. The cycles of "
                 "concentration are held just under the allowable value from the treatment programme: the PSI limit "
                 "(>= 5.60 at the design condenser water return temperature, WT-01 4.4) governs at all three plants, "
                 "silica (150 / 16.0 = 9.375) is far above it.\n")
    lines.append("Life-cycle cost (EC-01): constant base-date dollars, real discount rate 3.0 percent (DOE/FEMP, "
                 "DiscountRateMemo), 26-year study period from the base date, one year of design and construction, annual "
                 "costs beginning at beneficial occupancy (UPV* = the 26-year factor less the 1-year factor: electricity "
                 "15.335223, water 21.777005, non-fuel 16.905969). Investment from VD-05: cell base price, material "
                 "adder, eliminator adder, premium motor adder, rigging at 0.85 USD/lb of operating weight, connections "
                 "14000 USD per cell, plant controls 60000 USD. Electricity 0.0712 USD/kWh plus 17.80 USD/kW-month of "
                 "peak coincident demand over twelve months (UT-01 ratchet). Water 1.94 USD/kgal of makeup and sewer "
                 "3.20 USD/kgal of blowdown escalated at the Authority's 3.5 percent nominal forecast restated as 1.9704 "
                 "percent real with the supplement's implied 1.5 percent inflation. Treatment 0.42 USD/kgal of makeup "
                 "and maintenance per cell per year from the VD-05 ServiceLife sheet. Replacement when the service life "
                 "expires in the study period, straight-line salvage at the end (none: SS-304 life 25 years equals the "
                 "service period, so the cells are in service for exactly 25 years and are neither replaced nor "
                 "salvaged).\n")
    lines.append("## 5. The designs\n")
    for pid in ("CUP", "ANNEX", "LAB"):
        s = summary[pid]
        d = s["design"]
        lines.append(f"**{pid}** - {d['cells']} x {d['model']}, {d['gpm_total']:.0f} gpm total "
                     f"({d['gpm_total'] / d['cells']:.0f} gpm per cell), CWS design {d['cws_design_f']:.1f} deg F at "
                     f"{wb['design_wb_f']:.1f} deg F wet bulb, reset floor {d['cws_min_f']:.1f} deg F with offset "
                     f"{d['cws_offset_f']:.3f} deg F, COC {d['coc']:.2f}, {d['eliminator']} at 0.002 percent, "
                     f"{d['material']}, premium efficiency {d['motor_eff'] * 100:.1f} percent motor. Achieved design "
                     f"point: CWS {s['cws_f']:.2f} deg F, approach {s['approach']:.2f} deg F. Redundancy with one cell "
                     f"out: CWS {s['redundancy_cws']:.1f} deg F, {s['redundancy_tons']:.0f} tons available against the "
                     f"block load. Peak coincident demand {s['peak_kw']:.1f} kW; annual energy {s['kwh']:,.0f} kWh; "
                     f"annual makeup {s['makeup_kgal']:,.0f} kgal against {plants[pid]['water']['annual_kgal']:,.0f} "
                     f"kgal; investment {s['investment']:,.0f} USD; life-cycle cost {s['lcc']:,.0f} USD against the "
                     f"basic design's {s['basic_lcc']:,.0f} USD; net savings {s['ns']:,.0f} USD.\n")
    lines.append("## 6. Governing constraints (DC-02 9)\n")
    for pid in ("CUP", "ANNEX", "LAB"):
        s = summary[pid]
        nm = gov[pid]
        lines.append(f"GOVERNING CONSTRAINT {pid}: {nm} (relative margin {s['margins'][nm]:.4f})\n")
        others = ", ".join(f"{k} {v:.4f}" for k, v in s["margins"].items() if k != nm)
        lines.append(f"All six margins at {pid}: {nm} {s['margins'][nm]:.4f} (governing), {others}. "
                     f"Margins are computed from the quantities this workbook reports: peak coincident demand "
                     f"{s['peak_kw']:.1f} kW, annual makeup {s['makeup_kgal']:.1f} kgal, design supply temperature "
                     f"{s['cws_f']:.2f} deg F. The roof area, structural and condenser flow margins depend only on "
                     f"published data and the schedule.\n")
    lines.append("## 7. Margins and judgement calls\n")
    lines.append("The three plants are held close to two different limits and both are deliberate. At ANNEX the "
                 "reclaimed water allocation is the binding constraint: the design sits about 1 percent inside the "
                 "12600 kgal/yr amended allocation, and the cycles of concentration are pushed to the allowable value "
                 "(4.00 against 4.001) rather than held lower, because every cycle below it is paid for twice, in "
                 "makeup and in the blowdown sewer charge. At LAB the electrical capacity is the binding constraint: the "
                 "peak coincident demand is set by the chillers and the pumps, and the design sits about 1 percent "
                 "inside the 641.1 kW spare capacity left on MCC-R3 after the three RFI-034 exhaust fans. At CUP the "
                 "electrical, structural and water margins are all within about 3 percent of each other; the structural "
                 "one is exact and is set by the 117 psf a CTX-0600-S imposes on the 120 psf CUP-S2 framing zone, which "
                 "is why two of the four cells stand in S2 and two in S1.\n")
    lines.append("Judgement calls recorded: the design wet bulb is scheduled at the 1.0 percent value plus the adder "
                 "(80.0 deg F) and the achieved design approach (5.36 / 5.69 / 5.99 deg F) is colder than the scheduled "
                 "10.5 / 11.5 / 6.5 deg F approach, so CWSDESIGN is the conservative number the schedule commits to and "
                 "the DesignPoint sheet reports the achieved one, as DC-02 A.2 and the brief require. The condenser "
                 "water flow is set at the value the least-cost design selects for each plant (1800 gpm on CUP and "
                 "ANNEX, 2025 gpm on LAB) and is inside the VD-03 per-machine and VD-01 per-cell limits everywhere. The "
                 "condenser water supply floor is the designer's number RFI-031 Response 2 leaves to the designer; at "
                 "ANNEX it sits at 79.5 deg F because the chiller there is rated from 75.0 deg F and the plant is "
                 "water-limited, not capability-limited. No basin heater, no glycol, no side-stream filtration: the F-VF "
                 "fill of VD-04 is the reclaimed-water fill and is what the rated capability is stated for.\n")
    lines.append("The register cites the documents and clauses that fix each requirement. Where a document is listed as "
                 "superseded or cancelled it is recorded here and in the register as not applied, with the document that "
                 "governs in its place.\n")
    open(os.path.join(OUT, "design_basis.md"), "w").write("\n".join(lines) + "\n")
    print("written")

if __name__ == "__main__":
    main()
