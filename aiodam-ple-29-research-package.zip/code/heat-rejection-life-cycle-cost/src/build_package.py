"""build_package.py - write the deliverables: CT_SCHEDULE_P.dxf and CT_CALC_P.xlsx for each plant,
then constraint_register.csv and design_basis.md, then submission.zip."""
from __future__ import annotations

import csv
import json
import os
import zipfile

import ezdxf
import openpyxl

import ctmodel as M
import evaluate as E
import plantdata as P
import weather as W

OUT = "/work/ple-solve/heat-rejection-life-cycle-cost/out"

PADS = {  # (x0, y0, x1, y1) in the plan coordinates of M-401 Rev C, one per cell
    "CUP": [(14, 16, 24, 36), (30, 16, 40, 36), (46, 16, 56, 36), (62, 16, 72, 36)],
    "ANNEX": [(16, 218, 26, 238), (32, 218, 42, 238), (48, 218, 58, 238), (64, 218, 74, 238)],
    "LAB": [(18, 419, 30, 451), (36, 419, 48, 451), (54, 419, 66, 451)],
}

def write_dxf(path, pid, design, ctx, res, wb, pads):
    m = ctx["cat"][design["model"]]
    doc = ezdxf.new("R2010", setup=True)
    doc.layers.add("M-CTWR-SCHD", color=7)
    doc.layers.add("M-CTWR-PLAN", color=3)
    doc.layers.add("G-TBLK", color=7)
    msp = doc.modelspace()
    dp = res["design_point"]
    cell_rows = [("MODEL", design["model"]), ("GPM", round(design["gpm_total"] / design["cells"], 1)),
                 ("FANHP", m["fan_hp"]), ("MOTOREFF", design["motor_eff"] * 100.0),
                 ("MOTORPOLES", design["motor_poles"]), ("MOTORENCL", design["enclosure"]),
                 ("ELIMINATOR", design["eliminator"]), ("DRIFT", design["drift_pct"]),
                 ("MATERIAL", design["material"]), ("OPWEIGHT", m["op_weight_lb"]),
                 ("SOUNDLW", m["sound_lw_dba"])]
    plant_rows = [("CELLS", design["cells"]), ("GPMTOTAL", design["gpm_total"]),
                  ("WBDESIGN", wb["design_wb_f"]), ("CWSDESIGN", design["cws_design_f"]),
                  ("RANGEDESIGN", round(dp["range_f"], 2)),
                  ("APPROACHDESIGN", round(design["cws_design_f"] - wb["design_wb_f"], 2)),
                  ("CWSMIN", design["cws_min_f"]), ("CWSOFFSET", design["cws_offset_f"]),
                  ("COC", design["coc"]), ("BASINCLR", 4.0), ("EVAPMETHOD", "SATURATED-EXIT"),
                  ("BASINHEATER", "NO"), ("BLOWDOWNCTRL", "YES"), ("EQUALIZING", "YES")]
    y = 20.0
    for i in range(1, design["cells"] + 1):
        for k, v in cell_rows:
            msp.add_text(f"CT-{i} {k} {v}", dxfattribs={"layer": "M-CTWR-SCHD", "height": 0.8,
                                                        "insert": (90.0, y)})
            y -= 2.2
    y -= 4.0
    for k, v in plant_rows:
        msp.add_text(f"PLANT {k} {v}", dxfattribs={"layer": "M-CTWR-SCHD", "height": 0.8,
                                                  "insert": (90.0, y)})
        y -= 2.2
    for p in pads:
        msp.add_lwpolyline([(p[0], p[1]), (p[2], p[1]), (p[2], p[3]), (p[0], p[3])], close=True,
                           dxfattribs={"layer": "M-CTWR-PLAN"})
    msp.add_text(f"CT_SCHEDULE_{pid} - COOLING TOWER SCHEDULE AND ROOF LAYOUT", dxfattribs={
        "layer": "G-TBLK", "height": 1.6, "insert": (0.0, -32.0)})
    msp.add_text("PAPAGO FEDERAL CENTER - CONDENSER WATER HEAT REJECTION REPLACEMENT", dxfattribs={
        "layer": "G-TBLK", "height": 1.2, "insert": (0.0, -36.0)})
    msp.add_text("SHEET CT-401 - PLAN UNITS FEET - COORDINATES OF M-401 REVISION C", dxfattribs={
        "layer": "G-TBLK", "height": 1.2, "insert": (0.0, -40.0)})
    msp.add_text("REVISION C   DATE 2026-11-10   SCALE 1/8in = 1ft-0in", dxfattribs={
        "layer": "G-TBLK", "height": 1.2, "insert": (0.0, -44.0)})
    doc.saveas(path)

def write_xlsx(path, pid, design, ctx, res, wb, sim, dp, lc, basic, coc):
    wb_ = openpyxl.Workbook()
    dp_sheet = wb_.active
    dp_sheet.title = "DesignPoint"
    rows = [("DesignWetBulb_F", wb["design_wb_f"]), ("DesignLoad_tons", res["design_load_tons"]),
            ("HeatRejection_BTUH", round(dp["q_btuh"], 1)), ("CWFlow_gpm", design["gpm_total"]),
            ("Range_F", round(dp["range_f"], 3)), ("Approach_F", round(dp["approach_f"], 3)),
            ("CWS_F", round(dp["cws_f"], 3)), ("CWR_F", round(dp["cws_f"] + dp["range_f"], 3)),
            ("WaterFlowRatio", round(dp["fr_water"], 4)), ("CellsInService", dp["cells"]),
            ("RedundancyWetBulb_F", wb["redundancy_wb_f"]),
            ("RedundancyCapacity_tons", round(res["redundancy"]["avail_tons"], 1)),
            ("DryBulb996_F", wb["db_996"])]
    for r in rows:
        dp_sheet.append(list(r))
    od = wb_.create_sheet("OffDesign")
    cols = ["WetBulb_F", "DryBulb_F", "Hours", "Load_tons", "ChillersOn", "CellsOn", "CWFlow_gpm",
            "AirFlowRatio", "FanPLR", "Range_F", "CWS_F", "CWR_F", "ChillerkW", "FankW", "PumpkW",
            "TotalkW", "Makeup_gpm"]
    od.append(cols)
    for r in sim["rows"]:
        od.append([r["twb_f"], r["tdb_f"], round(r["hours"], 4), round(r["load_tons"], 3),
                   r["n_chillers"], r["n_cells"], round(r["gpm"], 1), round(r["fr_air"], 4),
                   round(r["fan_plr"], 4), round(r["range_f"], 3), round(r["cws_f"], 3),
                   round(r["cwr_f"], 3), round(r["kw_chiller"], 3), round(r["kw_fan"], 3),
                   round(r["kw_pump"], 3), round(r["kw_total"], 3), round(r["makeup_gpm"], 4)])
    wat = wb_.create_sheet("WaterBalance")
    for r in [("EvaporationMethod", "saturated-exit"),
              ("AnnualEvaporation_kgal", round(res["annual"]["evap_kgal"], 1)),
              ("AnnualDrift_kgal", round(res["annual"]["drift_kgal"], 2)),
              ("AnnualBlowdown_kgal", round(res["annual"]["blowdown_kgal"], 1)),
              ("AnnualMakeup_kgal", round(res["annual"]["makeup_kgal"], 1)),
              ("PeakDayMakeup_gal", round(res["peak_day"]["makeup_gal"], 0)),
              ("CyclesOfConcentration", design["coc"]),
              ("MaxAllowableCOC", round(coc["max"], 3)),
              ("ScalingIndexAtCWR", round(res["coc"]["psi_at_cwr"], 3))]:
        wat.append(list(r))
    en = wb_.create_sheet("Energy")
    e = res["energy"]
    for r in [("AnnualChillerEnergy_kWh", round(e["chiller"], 1)),
              ("AnnualFanEnergy_kWh", round(e["fan"], 1)),
              ("AnnualPumpEnergy_kWh", round(e["pump"], 1)),
              ("AnnualPlantEnergy_kWh", round(e["total"], 1)),
              ("PeakCoincidentDemand_kW", round(res["annual"]["peak_kw"], 3)),
              ("MCCSpareCapacity_kW", res["mcc_spare"])]:
        en.append(list(r))
    lcs = wb_.create_sheet("LifeCycleCost")
    for r in [("DiscountRate", lc["factors"]["discount_real"]),
              ("StudyPeriod_yr", lc["factors"]["study_years"]),
              ("ConstructionPeriod_yr", lc["factors"]["construction_years"]),
              ("UPVStarElectricity", round(lc["factors"]["upv_star_electricity"], 8)),
              ("UPVStarWater", round(lc["factors"]["upv_star_water"], 8)),
              ("UPVNonFuel", round(lc["factors"]["upv_nonfuel"], 8)),
              ("Investment_USD", round(lc["investment"], 0)),
              ("AnnualEnergyCost_USD", round(lc["energy_annual"], 0)),
              ("AnnualWaterCost_USD", round(lc["water_annual"], 0)),
              ("AnnualOMCost_USD", round(lc["om_annual"], 0)),
              ("PVEnergy_USD", round(lc["pv_energy"], 0)),
              ("PVWater_USD", round(lc["pv_water"], 0)),
              ("PVOM_USD", round(lc["pv_om"], 0)),
              ("PVReplacement_USD", round(lc["pv_replacement"], 0)),
              ("PVSalvage_USD", round(lc["pv_salvage"], 0)),
              ("LCC_USD", round(lc["lcc"], 0)),
              ("BasicDesignLCC_USD", round(basic["lcc"], 0)),
              ("NetSavings_USD", round(basic["lcc"] - lc["lcc"], 0))]:
        lcs.append(list(r))
    wb_.save(path)

def main():
    os.makedirs(OUT, exist_ok=True)
    ctx = P.context()
    plants = P.plants()
    wb = W.weather_basis()
    obs, _ = W.observations()
    bins0 = W.bins(obs)
    ep = M.econ_params()
    summary = {}
    for pid in ("CUP", "ANNEX", "LAB"):
        design = E.make_design(pid, ctx)
        bins = [dict(r, load_tons=P.load_at(pid, r["tdb_f"])) for r in bins0]
        res = E.evaluate(pid, design, ctx, plants, bins, wb)
        plant = plants[pid]
        model = ctx["cat"][design["model"]]
        dp = M.design_point(design, plant, ctx, wb["design_wb_f"], plant["design_load_tons"])
        sim = M.simulate(design, plant, ctx, bins)
        coc = M.coc_allowable(ctx["makeup"], dp["cws_f"] + dp["range_f"], ctx["wt"])
        premium = abs(design["motor_eff"] * 100 - ctx["motors"][model["fan_hp"]]["premium"]) <= 0.05
        lc = M.lcc(ep, ctx["pricing"], design["model"], design["cells"], design["material"],
                   design["eliminator"], premium, model["op_weight_lb"], sim["kwh"], sim["peak_kw"],
                   sim["makeup_gal"] / 1000.0, sim["blowdown_gal"] / 1000.0)
        lc["factors"] = {"discount_real": ep["discount_real"], "study_years": ep["study_years"],
                         "construction_years": ep["construction_years"],
                         "upv_star_electricity": ep["upv_star_electricity"],
                         "upv_star_water": ep["upv_star_water"], "upv_nonfuel": ep["upv_nonfuel"]}
        basic = E.basic_lcc(pid, ctx, plants, bins, ep)
        res["design_load_tons"] = plant["design_load_tons"]
        res["mcc_spare"] = plant["mcc"]["spare_kw"]
        res["energy"] = {"chiller": sum(r["kw_chiller"] * r["hours"] for r in sim["rows"]),
                         "fan": sum(r["kw_fan"] * r["hours"] for r in sim["rows"]),
                         "pump": sum(r["kw_pump"] * r["hours"] for r in sim["rows"]),
                         "total": sim["kwh"]}
        res["ns"] = basic["lcc"] - lc["lcc"]
        res["lcc_full"] = lc
        res["basic"] = basic
        write_dxf(os.path.join(OUT, f"CT_SCHEDULE_{pid}.dxf"), pid, design, ctx, res, wb, PADS[pid])
        write_xlsx(os.path.join(OUT, f"CT_CALC_{pid}.xlsx"), pid, design, ctx, res, wb, sim, dp, lc,
                   basic, coc)
        summary[pid] = {"design": design, "ns": round(res["ns"], 0), "peak_kw": round(sim["peak_kw"], 2),
                        "kwh": round(sim["kwh"], 0), "makeup_kgal": round(sim["makeup_gal"] / 1000, 1),
                        "cws_f": round(dp["cws_f"], 3), "approach": round(dp["approach_f"], 3),
                        "coc_max": round(coc["max"], 3), "margins": res["margins"],
                        "governing": res["governing"],
                        "investment": round(lc["investment"], 0), "lcc": round(lc["lcc"], 0),
                        "basic_lcc": round(basic["lcc"], 0),
                        "peak_day_makeup": res["peak_day"]["makeup_gal"],
                        "peak_day_blowdown": res["peak_day"]["blowdown_gal"],
                        "redundancy_tons": res["redundancy"]["avail_tons"],
                        "redundancy_cws": res["redundancy"]["cws_f"]}
    json.dump(summary, open(os.path.join(OUT, "summary.json"), "w"), indent=1)
    print(json.dumps(summary, indent=1))

if __name__ == "__main__":
    main()
