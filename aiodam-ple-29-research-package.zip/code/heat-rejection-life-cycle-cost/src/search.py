"""search.py - my own design search, with no reference design and no grader data.

Screens, in the order the documents allow them cheaply:
  fit      the cells and their air inlet clearances must fit the Rev C equipment zone, and every pad
           must sit inside one framing zone at or above the operating weight per support area (S-401)
  flow     per-machine VD-03 limits and per-cell VD-01 limits
  redund   DC-02 6.3: cells-1 at the failure wet bulb, per-cell flow inside VD-01 and the fw limit
  sound    23 65 00 2.6: 102 dBA
  design   DC-02 6.9: the design point must make CWSDESIGN and carry the block load
then, for the survivors, the annual run and its hard screens (peak <= MCC spare, annual and peak-day
water inside PW-LTR-014 as amended, no envelope violation), the cycles of concentration at the
allowable value, and the life-cycle net savings.

usage: search.py [CUP ANNEX LAB] [--quick]
"""
from __future__ import annotations

import itertools
import json
import math
import sys

import ctmodel as M
import evaluate as E
import plantdata as P
import weather as W

MODELS = ["CTX-0600-H", "CTX-0600-S", "CTX-0900-H", "CTX-0900-S", "CTX-1350-H", "CTX-1350-S",
          "CTX-1800-H", "CTX-1800-S"]

def fits_zone(plant, cat, cells):
    """Can `cells` pads of this model be laid out in the zone with the air inlet clearance, row by row,
    each wholly inside one framing zone?"""
    zx0, zy0, zx1, zy1 = plant["roof_zone"]
    c = cat["clearance_ft"]
    w, l = cat["plan_w_ft"], cat["plan_l_ft"]
    psf = cat["op_weight_lb"] / (w * l)
    usable_w, usable_h = (zx1 - zx0) - 2 * c, (zy1 - zy0) - 2 * c
    for nw, nl in ((w, l), (l, w)):
        need_w = cells * nw + (cells - 1) * c
        if need_w <= usable_w + 1e-9 and nl <= usable_h + 1e-9:
            # a row along x, centred in the zone
            y0 = zy0 + c + (usable_h - nl) / 2.0
            for i in range(cells):
                x0 = zx0 + c + i * (nw + c)
                rect = (x0, y0, x0 + nw, y0 + nl)
                zones = [fz for fz in plant["framing_zones"]
                         if fz["rect"][0] <= rect[0] + 1e-6 and fz["rect"][1] <= rect[1] + 1e-6
                         and fz["rect"][2] >= rect[2] - 1e-6 and fz["rect"][3] >= rect[3] - 1e-6]
                if not zones or psf > max(z["allow_psf"] for z in zones) + 1e-6:
                    continue
                if any(dist_rect_point(rect, ix, iy) < 25.0 - 1e-6 for ix, iy in plant["intakes"]):
                    continue
            else:
                return True
    return False

def dist_rect_point(r, px, py):
    dx = max(r[0] - px, px - r[2], 0.0)
    dy = max(r[1] - py, py - r[3], 0.0)
    return math.hypot(dx, dy)

def design_of(pid, ctx, model, cells, gpm, floor, offset, coc):
    m = ctx["cat"][model]
    return {"model": model, "cells": cells, "gpm_total": gpm, "cws_design_f": 0.0,
            "cws_min_f": floor, "cws_offset_f": offset, "coc": coc, "drift_pct": 0.002,
            "fan_hp": m["fan_hp"], "motor_eff": ctx["motors"][m["fan_hp"]]["premium"] / 100.0,
            "motor_poles": 6, "enclosure": "TEFC", "material": "SS-304", "eliminator": "DE-2",
            "evap_method": "saturated-exit"}

def screen_static(pid, ctx, plant, d, ch, wb):
    m = ctx["cat"][d["model"]]
    lo_pub, hi_pub = M.published_cond_flow(ch)
    gpm_ch = d["gpm_total"] / plant["n_chillers"]
    if not (lo_pub - 0.5 <= gpm_ch <= hi_pub + 0.5):
        return None
    gpm_cell = d["gpm_total"] / d["cells"]
    if not (m["gpm_min"] <= gpm_cell <= m["gpm_max"]):
        return None
    # redundancy: the same total flow carried by one fewer cell
    lim = min(m["gpm_max"], m["gpm_nominal"] * 1.25)
    if d["gpm_total"] / (d["cells"] - 1) > lim + 1e-9:
        return None
    if m["sound_lw_dba"] > 102:
        return None
    if not fits_zone(plant, m, d["cells"]):
        return None
    # design point with a provisional CWSDESIGN; the caller refines it
    d = dict(d)
    dp = M.design_point(d, plant, ctx, wb["design_wb_f"], plant["design_load_tons"])
    if not dp["feasible"] or dp["avail_tons"] < plant["design_load_tons"] - 1e-6:
        return None
    d["cws_design_f"] = round(dp["cws_f"] + 0.4, 2)          # conservative by 0.4 deg F
    if d["cws_design_f"] > M.chiller_max_entering_f(ch) + 0.05:
        return None
    dp = M.design_point(d, plant, ctx, wb["design_wb_f"], plant["design_load_tons"])
    if dp["cws_f"] > d["cws_design_f"] + 0.5:
        return None
    red = M.design_point(d, plant, ctx, wb["redundancy_wb_f"], plant["design_load_tons"],
                         cells_available=d["cells"] - 1)
    if not red["feasible"] or red["avail_tons"] < plant["design_load_tons"] - 1e-6:
        return None
    if red["cws_f"] > M.chiller_max_entering_f(ch) + 1e-6:
        return None
    return d, dp

def evaluate_candidate(pid, ctx, plant, d, dp, bins, wb, ep, pr, ch, m):
    sim = M.simulate(d, plant, ctx, bins)
    v = sim["violations"]
    if v["flow"] or v["envelope"] or v["setpoint"] or v["fanpower"] or v["capacity"]:
        return None
    if sim["peak_kw"] > plant["mcc"]["spare_kw"] + 1e-6:
        return None
    makeup_kgal = sim["makeup_gal"] / 1000.0
    if makeup_kgal > plant["water"]["annual_kgal"] + 1e-6:
        return None
    tdb_pk = max(wb["design_wb_f"], P.M603[pid][-1][0])
    pk = M.simulate(d, plant, ctx, [{"twb_f": wb["design_wb_f"], "tdb_f": tdb_pk, "hours": 24.0,
                                     "load_tons": plant["design_load_tons"]}])
    if pk["makeup_gal"] > plant["water"]["peak_day_gal"] + 1e-6:
        return None
    if pk["blowdown_gal"] > plant["water"]["blowdown_day_gal"] + 1e-6:
        return None
    coc = M.coc_allowable(ctx["makeup"], dp["cws_f"] + dp["range_f"], ctx["wt"])
    if d["coc"] > coc["max"] + 0.01:
        return None
    premium = abs(d["motor_eff"] * 100 - ctx["motors"][m["fan_hp"]]["premium"]) <= 0.05
    lc = M.lcc(ep, pr, d["model"], d["cells"], d["material"], d["eliminator"], premium,
               m["op_weight_lb"], sim["kwh"], sim["peak_kw"], makeup_kgal, sim["blowdown_gal"] / 1000.0)
    return {"ns": None, "lcc": lc, "peak": sim["peak_kw"], "kwh": sim["kwh"], "makeup": makeup_kgal,
            "coc_max": coc["max"], "dp": dp, "sim": sim, "pk": pk}

def search(pid, ctx, plants, bins, wb, quick=False):
    plant = plants[pid]
    ch = ctx["chil"][plant["chiller"]]
    ep = M.econ_params()
    pr = ctx["pricing"]
    basic = E.basic_lcc(pid, ctx, plants, bins, ep)["lcc"]
    best = None
    n_static = n_ann = 0
    floors = [round(M.chiller_min_entering_f(ch) + k, 2) for k in (0, 2, 4, 6, 8, 10, 12, 14, 16)]
    offsets = [round(o, 2) for o in (6.0, 7.0, 8.0, 9.0, 10.0, 11.0, 12.0, 13.0, 14.0, 15.0, 16.0)]
    lo_pub, hi_pub = M.published_cond_flow(ch)
    for model in MODELS:
        m = ctx["cat"][model]
        for mult in range(1, 4):
            cells = plant["n_chillers"] * mult
            if cells > 6 or not fits_zone(plant, m, cells):
                continue
            gpm_lo = max(lo_pub * plant["n_chillers"], m["gpm_min"] * cells,
                         m["gpm_nominal"] * 0.75 * cells)
            gpm_hi = min(hi_pub * plant["n_chillers"], m["gpm_max"] * cells)
            if gpm_lo > gpm_hi:
                continue
            step = 100.0 if quick else 50.0
            gpm = gpm_lo
            while gpm <= gpm_hi + 1e-9:
                gpm_r = round(gpm / 5.0) * 5.0
                d0 = design_of(pid, ctx, model, cells, gpm_r, floors[0], offsets[0], 2.0)
                s = screen_static(pid, ctx, plant, d0, ch, wb)
                if s is None:
                    gpm += step
                    continue
                n_static += 1
                d_static, dp0 = s
                # the cycles of concentration: the allowable value at the design CWR, two decimals
                coc = math.floor(M.coc_allowable(ctx["makeup"], dp0["cws_f"] + dp0["range_f"],
                                                 ctx["wt"])["max"] * 100.0) / 100.0
                local = None
                for floor in floors:
                    for off in offsets:
                        d = dict(d_static)
                        d["cws_min_f"] = min(floor, d_static["cws_design_f"] - 0.4)
                        d["cws_offset_f"] = off
                        d["coc"] = coc
                        dp = M.design_point(d, plant, ctx, wb["design_wb_f"],
                                            plant["design_load_tons"])
                        if dp["cws_f"] > d["cws_design_f"] + 0.5:
                            continue
                        r = evaluate_candidate(pid, ctx, plant, d, dp, bins, wb, ep, pr, ch, m)
                        if r is None:
                            continue
                        n_ann += 1
                        local = local or []
                        local.append((r["lcc"]["lcc"], d, r))
                if local:
                    lcc_min, d_best, r_best = min(local, key=lambda t: t[0])
                    if best is None or lcc_min < best[0]:
                        best = (lcc_min, d_best, r_best)
                gpm += step
    return {"pid": pid, "best": best, "n_static": n_static, "n_annual": n_ann, "basic_lcc": basic}

def main():
    ctx = P.context()
    plants = P.plants()
    wb = W.weather_basis()
    obs, _ = W.observations()
    bins0 = W.bins(obs)
    wh = [a for a in sys.argv[1:] if not a.startswith("--")]
    quick = "--quick" in sys.argv
    out = {}
    for pid in (wh or ["CUP", "ANNEX", "LAB"]):
        bins = [dict(r, load_tons=P.load_at(pid, r["tdb_f"])) for r in bins0]
        r = search(pid, ctx, plants, bins, wb, quick)
        best = r["best"]
        if best is None:
            print(pid, "no feasible design found")
            continue
        lcc, d, res = best
        out[pid] = {"design": {k: v for k, v in d.items()}, "lcc": lcc,
                    "basic_lcc": round(r["basic_lcc"], 0), "ns": round(r["basic_lcc"] - lcc, 0),
                    "peak": round(res["peak"], 2), "kwh": round(res["kwh"], 0),
                    "makeup": round(res["makeup"], 1), "coc_max": round(res["coc_max"], 3),
                    "cws_f": round(res["dp"]["cws_f"], 3),
                    "n_static": r["n_static"], "n_annual": r["n_annual"]}
        print(f"{pid}: {d['cells']} x {d['model']} {d['gpm_total']:.0f} gpm floor {d['cws_min_f']:.1f} "
              f"offset {d['cws_offset_f']:.2f} COC {d['coc']:.2f} -> LCC {lcc:,.0f} "
              f"NS {r['basic_lcc'] - lcc:,.0f} (peak {res['peak']:.1f} kW, {res['kwh']:,.0f} kWh, "
              f"makeup {res['makeup']:,.0f} kgal) "
              f"[{r['n_static']} static, {r['n_annual']} annual candidates]", flush=True)
    json.dump(out, open("/work/ple-solve/heat-rejection-life-cycle-cost/out/search.json", "w"), indent=1)

if __name__ == "__main__":
    main()
