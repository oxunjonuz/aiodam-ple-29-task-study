"""recheck_anx.py - turn 493: recompute the ANNEX water margin and the floor-78.75 claim
from the same code path build_package.py uses, so the corrected report quotes measured
numbers rather than remembered ones."""
from __future__ import annotations

import json
import sys

sys.path.insert(0, "/work/ple-solve/heat-rejection-life-cycle-cost/src")

import ctmodel as M
import evaluate as E
import plantdata as P
import weather as W

ALLOC = {"CUP": 10300.0, "ANNEX": 12600.0, "LAB": 17400.0}
GRADER = {  # grade/g4/logs/artifacts.json recomputed + S27 notes
    "ANNEX": {"makeup_kgal": 12598.341423252266, "ns": 253206.0, "lcc": 7640590.0},
    "LAB": {"makeup_kgal": 16966.54447826063, "ns": 295689.0, "lcc": 7770104.0},
    "CUP": {"makeup_kgal": 9590.0, "ns": 242663.0, "lcc": 5647207.0},
}

CTX = P.context()
PLANTS = P.plants()
WB = W.weather_basis()
OBS, _ = W.observations()
BINS0 = W.bins(OBS)


def run(pid, **over):
    design = E.make_design(pid, CTX)
    design.update(over)
    bins = [dict(r, load_tons=P.load_at(pid, r["tdb_f"])) for r in BINS0]
    return design, E.evaluate(pid, design, CTX, PLANTS, bins, WB, verbose=False)


out = {}
for pid in ("CUP", "ANNEX", "LAB"):
    design, res = run(pid)
    mine = res["annual"]["makeup_kgal"]
    g = GRADER[pid]["makeup_kgal"]
    out[pid] = {
        "design": {k: design[k] for k in ("model", "cells", "gpm_total", "cws_min_f", "cws_offset_f")},
        "mine_makeup_kgal": mine,
        "grader_makeup_kgal": round(g, 2),
        "alloc_kgal": ALLOC[pid],
        "spare_mine_kgal": round(ALLOC[pid] - mine, 2),
        "spare_grader_kgal": round(ALLOC[pid] - g, 2),
        "margin_mine_pct": round(100 * (ALLOC[pid] - mine) / ALLOC[pid], 4),
        "margin_grader_pct": round(100 * (ALLOC[pid] - g) / ALLOC[pid], 4),
        "mine_ns": res["ns"], "grader_ns": GRADER[pid]["ns"],
        "mine_lcc": res["lcc"]["lcc"], "grader_lcc": GRADER[pid]["lcc"],
        "ns_diff_pct": round(100 * (res["ns"] - GRADER[pid]["ns"]) / GRADER[pid]["ns"], 2),
    }
    print(pid, json.dumps(out[pid], indent=1))

design, res = run("ANNEX", cws_min_f=78.75)
mine = res["annual"]["makeup_kgal"]
print("\nANNEX floor 78.75: mine makeup", mine, "kgal; allocation", ALLOC["ANNEX"],
      "; over by", round(mine - ALLOC["ANNEX"], 2))
out["ANNEX_floor_78_75"] = {"mine_makeup_kgal": mine, "alloc_kgal": ALLOC["ANNEX"],
                            "over_allocation_kgal": round(mine - ALLOC["ANNEX"], 2),
                            "ns": res["ns"]}
json.dump(out, open("/work/ple-solve/heat-rejection-life-cycle-cost/out/recheck_493.json", "w"), indent=1)
print("\nwrote out/recheck_493.json")
