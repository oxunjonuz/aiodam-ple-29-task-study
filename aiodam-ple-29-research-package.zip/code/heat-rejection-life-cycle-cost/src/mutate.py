"""mutate.py - sensitivity campaign: break one thing at a time in the built package and run the REAL
grader on it, recording which families turn red.  A mutation that changes nothing is a hole in the
package's own evidence, not a pass.

usage: mutate.py [names...]
"""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
import zipfile

import openpyxl

HERE = "/work/ple-solve/heat-rejection-life-cycle-cost"
OUT = os.path.join(HERE, "out")
TMP = os.path.join(HERE, "mut")

def _dxf_text_edit(path, old, new):
    b = open(path, encoding="utf-8", errors="replace").read()
    assert old in b, f"{old!r} not in {path}"
    open(path, "w", encoding="utf-8").write(b.replace(old, new, 1))

def _xlsx_set(path, sheet, key, value):
    wb = openpyxl.load_workbook(path)
    ws = wb[sheet]
    for row in ws.iter_rows():
        if row[0].value is not None and str(row[0].value).strip().lower() == key.lower():
            row[1].value = value
            wb.save(path)
            return
    raise KeyError(key)

def _csv_drop(path, row_id):
    lines = open(path).read().splitlines()
    out = [ln for ln in lines if not ln.startswith(row_id + ",")]
    assert len(out) == len(lines) - 1, row_id
    open(path, "w").write("\n".join(out) + "\n")

def _csv_doc_change(path, row_id, new_doc):
    rows = open(path).read().splitlines()
    for i, ln in enumerate(rows):
        if ln.startswith(row_id + ","):
            parts = ln.split(",", 2)
            rows[i] = parts[0] + "," + new_doc + "," + parts[2]
            break
    open(path, "w").write("\n".join(rows) + "\n")

def _basis_edit(path, old, new):
    b = open(path).read()
    assert old in b
    open(path, "w").write(b.replace(old, new, 1))

MUTATIONS = {}

def mutation(name):
    def deco(fn):
        MUTATIONS[name] = fn
        return fn
    return deco

@mutation("M01_material_galvanised")
def m01(d):
    for pid in ("CUP", "ANNEX", "LAB"):
        _dxf_text_edit(f"{d}/CT_SCHEDULE_{pid}.dxf", " MATERIAL SS-304", " MATERIAL G-235")

@mutation("M02_coc_too_high")
def m02(d):
    for pid in ("CUP", "ANNEX", "LAB"):
        _dxf_text_edit(f"{d}/CT_SCHEDULE_{pid}.dxf", " COC ", " COC ")
        # every COC line, plant row only
        b = open(f"{d}/CT_SCHEDULE_{pid}.dxf", encoding="utf-8", errors="replace").read()
        b = re.sub(r"(PLANT COC )([0-9.]+)", lambda m: m.group(1) + "6.5", b)
        open(f"{d}/CT_SCHEDULE_{pid}.dxf", "w", encoding="utf-8").write(b)

@mutation("M03_cells_not_multiple")
def m03(d):
    """ANNEX is in the graded (held-out) split: 3 cells for 2 chillers is not a whole multiple."""
    b = open(f"{d}/CT_SCHEDULE_ANNEX.dxf", encoding="utf-8", errors="replace").read()
    b = re.sub(r"(PLANT CELLS )([0-9.]+)", r"\g<1>3", b)
    open(f"{d}/CT_SCHEDULE_ANNEX.dxf", "w", encoding="utf-8").write(b)

@mutation("M04_no_equalizing")
def m04(d):
    for pid in ("CUP", "ANNEX", "LAB"):
        _dxf_text_edit(f"{d}/CT_SCHEDULE_{pid}.dxf", " EQUALIZING YES", " EQUALIZING NO")

@mutation("M05_register_drop_hard")
def m05(d):
    """drop every row that can bind R21 - dropping one of two leaves the requirement registered"""
    _csv_drop(f"{d}/constraint_register.csv", "R21")
    _csv_drop(f"{d}/constraint_register.csv", "R21b")

@mutation("M13_cell_gpm_wrong")
def m13(d):
    for pid in ("ANNEX", "LAB"):
        b = open(f"{d}/CT_SCHEDULE_{pid}.dxf", encoding="utf-8", errors="replace").read()
        b = re.sub(r"(CT-1 GPM )([0-9.]+)", r"\g<1>900.0", b)
        open(f"{d}/CT_SCHEDULE_{pid}.dxf", "w", encoding="utf-8").write(b)

@mutation("M14_pad_missing")
def m14(d):
    import ezdxf
    doc = ezdxf.readfile(f"{d}/CT_SCHEDULE_LAB.dxf")
    for e in doc.modelspace():
        if e.dxftype() == "LWPOLYLINE" and e.dxf.layer == "M-CTWR-PLAN":
            doc.modelspace().delete_entity(e)
            break
    doc.saveas(f"{d}/CT_SCHEDULE_LAB.dxf")

@mutation("M06_register_superseded_authority")
def m06(d):
    _csv_doc_change(f"{d}/constraint_register.csv", "R24",
                    "UFC 3-400-02 Engineering Weather Data (2018, Change 2)")

@mutation("M07_design_wetbulb_wrong")
def m07(d):
    for pid in ("CUP", "ANNEX", "LAB"):
        b = open(f"{d}/CT_SCHEDULE_{pid}.dxf", encoding="utf-8", errors="replace").read()
        b = re.sub(r"(PLANT WBDESIGN )([0-9.]+)", r"\g<1>85.0", b)
        open(f"{d}/CT_SCHEDULE_{pid}.dxf", "w", encoding="utf-8").write(b)

@mutation("M08_pad_outside_zone")
def m08(d):
    import ezdxf
    doc = ezdxf.readfile(f"{d}/CT_SCHEDULE_LAB.dxf")
    for e in doc.modelspace():
        if e.dxftype() == "LWPOLYLINE" and e.dxf.layer == "M-CTWR-PLAN":
            pts = [(p[0], p[1]) for p in e.get_points("xy")]
            if min(p[0] for p in pts) > 50:
                # move the last pad 25 ft east, outside the Rev C equipment zone
                e.set_points([(p[0] + 25, p[1]) for p in pts])
                break
    doc.saveas(f"{d}/CT_SCHEDULE_LAB.dxf")

@mutation("M09_basin_heater_yes")
def m09(d):
    for pid in ("CUP", "ANNEX", "LAB"):
        _dxf_text_edit(f"{d}/CT_SCHEDULE_{pid}.dxf", " BASINHEATER NO", " BASINHEATER YES")

@mutation("M10_evap_method_mismatch")
def m10(d):
    for pid in ("CUP", "ANNEX", "LAB"):
        _dxf_text_edit(f"{d}/CT_SCHEDULE_{pid}.dxf", " EVAPMETHOD SATURATED-EXIT",
                       " EVAPMETHOD LOSS-FACTOR")

@mutation("M11_ckwh_understated")
def m11(d):
    for pid in ("CUP", "ANNEX", "LAB"):
        _xlsx_set(f"{d}/CT_CALC_{pid}.xlsx", "Energy", "AnnualPlantEnergy_kWh", 1000.0)

@mutation("M12_basis_drop_conflict")
def m12(d):
    _basis_edit(f"{d}/design_basis.md", "CONFLICT 2: ADOPTED", "CONFLICT 2 was ADOPTED")

def run(name, fn):
    d = os.path.join(TMP, name)
    shutil.rmtree(d, ignore_errors=True)
    shutil.copytree(OUT, d)
    for f in ("submission.zip", "summary.json"):
        p = os.path.join(d, f)
        if os.path.exists(p):
            os.remove(p)
    fn(d)
    zpath = os.path.join(d, "submission.zip")
    with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as zf:
        for f in sorted(os.listdir(d)):
            if f.endswith((".dxf", ".xlsx", ".csv", ".md")):
                zf.write(os.path.join(d, f), f)
    work = os.path.join(HERE, "grade", "mut_" + name)
    shutil.rmtree(work, ignore_errors=True)
    os.makedirs(work, exist_ok=True)
    env = dict(os.environ)
    subprocess.run(["bash", "/work/ple-rig/offline_grade.sh", "heat-rejection-life-cycle-cost", zpath, work],
                   env=env, capture_output=True, text=True)
    art = json.load(open(os.path.join(work, "logs", "artifacts.json")))
    out = {"mutation": name, "combined": art.get("combined_score"), "package_hard_pass": art.get("package_hard_pass"),
           "register": {k: art.get("register", {}).get(k) for k in
                        ("recall_hard", "wrong_rows", "missing_hard_binding")},
           "plants": {}}
    for pid, r in art.get("items", {}).items():
        fams = [f for f, v in r.get("families", {}).items() if not v]
        out["plants"][pid] = {"p": r.get("p"), "G": r.get("G"), "A": r.get("A"), "O": r.get("O"),
                              "score": r.get("score"), "failed": fams}
    return out

def main():
    os.makedirs(TMP, exist_ok=True)
    names = sys.argv[1:] or list(MUTATIONS)
    res = []
    for name in names:
        r = run(name, MUTATIONS[name])
        res.append(r)
        failed = {pid: v["failed"] for pid, v in r["plants"].items() if v["failed"]}
        print(f"{name:34s} combined={r['combined']:.4f} register={r['register']} "
              f"failed={json.dumps(failed)[:220]}", flush=True)
    json.dump(res, open(os.path.join(TMP, "mutations.json"), "w"), indent=1)

if __name__ == "__main__":
    main()
