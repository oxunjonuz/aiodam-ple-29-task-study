"""ctmodel.py - my own forward model of the condenser-water plant, built from the shipped project
documents and the adopted simulation basis in vendor_data/:

  * psychrometrics          - Psychrometrics.cc / .hh (PsyPsatFnTemp, PsyTwbFnTdbWPb relation,
                              PsyHFnTdbW, PsyTsatFnHPb, PsyRhoAirFnPbTdbW)
  * tower approach          - CoolingTowerPerformance:YorkCalc object of PerfCurves.idf, evaluated as
                              CondenserLoopTowers.cc calculateVariableSpeedApproach / checkModelBounds
  * fan power / regimes     - CondenserLoopTowers.cc calculateVariableSpeedTower (four regimes)
  * tower water use         - calculateWaterUsage: EvapLoss::MoistTheory (saturated exit), drift, blowdown
  * chiller                 - ChillerElectricEIR.cc calculate(), curves from Chillers.idf
  * pump and staging rules  - DC-02 6.4, 6.5, 6.6, 6.7
  * water balance           - UFM 3-230-13 5-2.1.3 (loss factor), 5-4, Appendix A (PSI)
  * economics               - EC-01 and the NIST Handbook 135 2025 data tables

Nothing here reads the grader; every constant comes from a shipped file or from DC-02.
"""
from __future__ import annotations

import math
import os
import re

WB = ("/work/ple-dataset/tasks/heat-rejection-life-cycle-cost/environment/filesystem/"
      "final_batch4__mechanical_task3_ct_heat_lcc__blind")

# ------------------------------------------------------------------ units
def f2c(t): return (t - 32.0) / 1.8
def c2f(t): return t * 1.8 + 32.0
def dF2dC(d): return d / 1.8

GPM_TO_M3S = 6.30902e-5
BTUH_PER_TON = 12000.0
CP_WATER_BTU = 500.0            # DC-02 5.5: 500 x gpm x deg F
HP_TO_KW = 0.7457               # DC-02 6.4

# ------------------------------------------------------------------ psychrometrics
def psat_pa(tc):
    """Saturation vapour pressure (Pa), Hyland-Wexler form as in PsyPsatFnTemp."""
    tk = tc + 273.15
    if tk < 273.15:                                     # over ice (Hyland-Wexler, 7 constants)
        return math.exp(-5674.5359 / tk + 6.3925247 - 0.9677843e-2 * tk + 0.62215701e-6 * tk ** 2
                        + 0.20747825e-8 * tk ** 3 - 0.9484024e-12 * tk ** 4 + 4.1635019 * math.log(tk))
    if tk <= 473.15:                                    # over liquid water
        return math.exp(-5800.2206 / tk + 1.3914993 - 0.048640239 * tk + 0.41764768e-4 * tk ** 2
                        - 0.14452093e-7 * tk ** 3 + 6.5459673 * math.log(tk))
    return 1555073.745669147

def w_sat(tc, p):
    pw = min(psat_pa(tc), p * 0.9999)
    return 0.62198 * pw / max(p - pw, 1.0)

def w_from_twb(tdb_c, twb_c, p):
    """Humidity ratio from dry and wet bulb: the relation inside PsyTwbFnTdbWPb_raw."""
    twb_c = min(twb_c, tdb_c)
    ws = w_sat(twb_c, p)
    w = ((2501.0 - 2.326 * twb_c) * ws - 1.006 * (tdb_c - twb_c)) / (2501.0 + 1.86 * tdb_c - 4.186 * twb_c)
    return max(w, 1e-5)

def enthalpy(tdb_c, w):
    """Moist air enthalpy J/kg dry air, PsyHFnTdbW."""
    return 1.00484e3 * tdb_c + max(w, 1e-5) * (2.50094e6 + 1.85895e3 * tdb_c)

def w_from_tdb_h(tdb_c, h):
    return max((h - 1.00484e3 * tdb_c) / (2.50094e6 + 1.85895e3 * tdb_c), 1e-5)

def rho_air(p, tdb_c, w):
    return p / (287.0 * (tdb_c + 273.15) * (1.0 + 1.6077687 * w))

def tsat_from_h(h, p):
    lo, hi = -50.0, 120.0
    for _ in range(60):
        mid = 0.5 * (lo + hi)
        if enthalpy(mid, w_sat(mid, p)) < h:
            lo = mid
        else:
            hi = mid
    return 0.5 * (lo + hi)

def twb_from_tdb_w(tdb_c, w, p):
    lo, hi = -60.0, tdb_c
    for _ in range(60):
        mid = 0.5 * (lo + hi)
        if w_from_twb(tdb_c, mid, p) < w:
            lo = mid
        else:
            hi = mid
    return 0.5 * (lo + hi)

def w_from_dewpoint(tdp_c, p):
    pw = min(psat_pa(tdp_c), p * 0.9999)
    return 0.62198 * pw / max(p - pw, 1.0)

def water_density(t_c):
    """DC-02 7: Thiesen's relation (kg/m3), valid 0-40 C."""
    return 1000.0 * (1.0 - (t_c + 288.9414) / (508929.2 * (t_c + 68.12963)) * (t_c - 3.9863) ** 2)

# ------------------------------------------------------------------ IDF objects
def _idf_objects(path):
    """Yield (type, fields) for every object in an EnergyPlus IDF file."""
    text = open(path, encoding="utf-8", errors="replace").read()
    text = re.sub(r"!.*", "", text)                      # strip comments
    for chunk in text.split(";"):
        fields = [f.strip() for f in chunk.split(",")]
        fields = [f for f in fields if f != ""]
        if len(fields) >= 2:
            yield fields[0], fields[1:]

def load_tower_curve(path=None):
    path = path or os.path.join(WB, "vendor_data", "EnergyPlus_datasets_PerfCurves.idf")
    for typ, f in _idf_objects(path):
        if typ == "CoolingTowerPerformance:YorkCalc" and f[0].startswith("YorkCalc Default"):
            nums = [float(x) for x in f[1:10]]
            coeff = [float(x) for x in f[10:37]]
            return {"name": f[0], "wb_min_c": nums[0], "wb_max_c": nums[1], "range_min_c": nums[2],
                    "range_max_c": nums[3], "approach_min_c": nums[4], "approach_max_c": nums[5],
                    "fw_min": nums[6], "fw_max": nums[7], "lg_max": nums[8], "coeff": coeff}
    raise KeyError("YorkCalc object not found")

def _curve(path, objs, name, kind):
    for typ, f in objs:
        if typ == "Curve:" + kind and f[0].strip() == name:
            return [float(x) for x in f[1:]]
    raise KeyError(name)

def load_chiller(name, path=None):
    path = path or os.path.join(WB, "vendor_data", "EnergyPlus_datasets_Chillers.idf")
    objs = list(_idf_objects(path))
    for typ, f in objs:
        if typ == "Chiller:Electric:EIR" and f[0].strip() == name:
            ref_cap = float(f[1]); ref_cop = float(f[2])
            ref_tchws_c = float(f[3]); ref_tcond_c = float(f[4])
            ref_chw = float(f[5]); ref_cond = float(f[6])
            capft_name, eirft_name, eirfplr_name = f[7], f[8], f[9]
            minplr = float(f[10]); maxplr = float(f[11]); minunl = float(f[13])
            return {"name": name, "ref_cap_w": ref_cap, "ref_cop": ref_cop,
                    "ref_tchws_c": ref_tchws_c, "ref_tcond_c": ref_tcond_c,
                    "ref_chw_m3s": ref_chw, "ref_cond_m3s": ref_cond,
                    "capft": _curve(path, objs, capft_name, "Biquadratic"),
                    "eirft": _curve(path, objs, eirft_name, "Biquadratic"),
                    "eirfplr": _curve(path, objs, eirfplr_name, "Quadratic"),
                    "min_plr": minplr, "max_plr": maxplr, "min_unload": minunl}
    raise KeyError(name)

def _biquad(c, x, y):
    x = min(max(x, c[6]), c[7]); y = min(max(y, c[8]), c[9])
    return c[0] + c[1] * x + c[2] * x * x + c[3] * y + c[4] * y * y + c[5] * x * y

def _quad(c, x):
    x = min(max(x, c[3]), c[4])
    return c[0] + c[1] * x + c[2] * x * x

# ------------------------------------------------------------------ tower
def approach_c(cv, twb_c, range_c, fr_water, fr_air):
    """YorkCalc approach, deg C.  checkModelBounds clamps the inlet wet bulb and the water flow ratio."""
    t = min(max(twb_c, cv["wb_min_c"]), cv["wb_max_c"])
    fw = min(max(fr_water, cv["fw_min"]), cv["fw_max"])
    fa = max(fr_air, 1e-6)
    ff = fw / fa
    r = range_c
    c = cv["coeff"]
    t2, r2 = t * t, r * r
    return (c[0] + c[1] * t + c[2] * t2 + c[3] * r + c[4] * t * r + c[5] * t2 * r + c[6] * r2
            + c[7] * t * r2 + c[8] * t2 * r2
            + c[9] * ff + c[10] * t * ff + c[11] * t2 * ff + c[12] * r * ff + c[13] * t * r * ff
            + c[14] * t2 * r * ff + c[15] * r2 * ff + c[16] * t * r2 * ff + c[17] * t2 * r2 * ff
            + c[18] * ff * ff + c[19] * t * ff * ff + c[20] * t2 * ff * ff + c[21] * r * ff * ff
            + c[22] * t * r * ff * ff + c[23] * t2 * r * ff * ff + c[24] * r2 * ff * ff
            + c[25] * t * r2 * ff * ff + c[26] * t2 * r2 * ff * ff)

def approach_f(cv, twb_f, range_f, fr_water, fr_air):
    return approach_c(cv, f2c(twb_f), dF2dC(range_f), fr_water, fr_air) * 1.8

def fr_air_for_setpoint(cv, twb_f, range_f, fr_water, target_cws, fr_min):
    lo, hi = fr_min, 1.0
    if twb_f + approach_f(cv, twb_f, range_f, fr_water, hi) > target_cws:
        return 1.0
    if twb_f + approach_f(cv, twb_f, range_f, fr_water, lo) <= target_cws:
        return lo
    for _ in range(60):
        mid = 0.5 * (lo + hi)
        if twb_f + approach_f(cv, twb_f, range_f, fr_water, mid) <= target_cws:
            hi = mid
        else:
            lo = mid
    return hi

# ------------------------------------------------------------------ catalogue (VD-01 / VD-02 / VD-05)
def catalogue():
    """Cell data, read from the VD-01 table in the submittal PDF text and VD-02/VD-05 workbooks."""
    import openpyxl
    cat = {}
    txt = os.popen(f'pdftotext -layout "{os.path.join(WB, "vendor_data/VD-01_Cooling_Tower_Submittal_CTX_Series_C.pdf")}" -').read()
    for line in txt.splitlines():
        m = re.match(r"\s*(CTX-\d{3,4}-[SH])\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+([\d.]+)\s+([\d,]+)\s+"
                     r"(\d+)\s*x\s*(\d+)\s+([\d,]+)\s+([\d,]+)\s+([\d.]+)\s+(\d+)\s*$", line)
        if m:
            cat[m.group(1)] = {
                "gpm_nominal": int(m.group(2)), "gpm_min": int(m.group(3)), "gpm_max": int(m.group(4)),
                "fan_hp": int(m.group(5)), "fan_bhp": float(m.group(6)),
                "cfm_nominal": int(m.group(7).replace(",", "")),
                "plan_w_ft": float(m.group(8)), "plan_l_ft": float(m.group(9)),
                "op_weight_lb": int(m.group(10).replace(",", "")),
                "ship_weight_lb": int(m.group(11).replace(",", "")),
                "clearance_ft": float(m.group(12)), "sound_lw_dba": int(m.group(13))}
    wb = openpyxl.load_workbook(os.path.join(WB, "vendor_data/VD-02_Tower_Fan_and_Motor_Data.xlsx"),
                                data_only=True)
    for row in list(wb["FanData"].iter_rows(values_only=True))[1:]:
        if row[0] in cat:
            cat[row[0]]["fr_air_min"] = float(row[5])
            cat[row[0]]["free_conv_frac"] = float(row[6])
            assert cat[row[0]]["fan_bhp"] == float(row[3]) and cat[row[0]]["cfm_nominal"] == int(row[2])
    motors = {}
    for row in list(wb["MotorData"].iter_rows(values_only=True))[1:]:
        if isinstance(row[0], (int, float)):
            motors.setdefault(int(row[0]), {})[str(row[3]).split()[0].lower()] = float(row[4])
    return cat, motors

def pricing():
    import openpyxl
    wb = openpyxl.load_workbook(os.path.join(WB, "vendor_data/VD-05_Budgetary_Pricing_and_Service_Life.xlsx"),
                                data_only=True)
    base, mat, elim, prem = {}, {}, {}, {}
    for row in list(wb["BudgetPricing"].iter_rows(values_only=True))[1:]:
        if isinstance(row[1], (int, float)):
            base[row[0]] = float(row[1])
    for row in list(wb["Options"].iter_rows(values_only=True))[1:]:
        if row[0] is None:
            continue
        if str(row[0]).startswith("Casing"):
            mat[row[1]] = float(row[2])
        elif str(row[0]).startswith("Drift"):
            elim[row[1]] = float(row[2])
        elif str(row[0]).startswith("Premium"):
            prem[row[1]] = float(row[2])
    inst = {r[0]: r[1] for r in list(wb["Installation"].iter_rows(values_only=True))[1:] if r[0]}
    life = {}
    for row in list(wb["ServiceLife"].iter_rows(values_only=True))[1:]:
        if row[0] and row[0] in ("G-235", "SS-304", "SS-316", "FRP-PV"):
            life[row[0]] = {"years": int(row[1]), "maint": float(row[2])}
    return {"base": base, "material_adder_frac": mat, "eliminator_adder": elim,
            "premium_motor_adder": prem, "rigging_per_lb": float(inst["Crane, rigging and setting"]),
            "connection_per_cell": float(inst["Condenser water piping, electrical and controls connection"]),
            "plant_fixed": float(inst["Plant controls, sequence programming, testing and start-up"]),
            "service_life": life}

# ------------------------------------------------------------------ chiller
def published_cond_flow(ch):
    ref_gpm = ch["ref_cond_m3s"] / GPM_TO_M3S
    return round(0.5 * ref_gpm), round(1.2 * ref_gpm)

def chiller_capacity_tons(ch, tchws_f, tcond_f):
    return ch["ref_cap_w"] / 3516.85 * _biquad(ch["capft"], f2c(tchws_f), f2c(tcond_f))

def chiller_kw(ch, tchws_f, tcond_f, load_tons):
    avail = max(chiller_capacity_tons(ch, tchws_f, tcond_f), 1e-6)
    plr = min(max(load_tons / avail, 0.0), ch["max_plr"])
    if plr <= 0.0:
        return 0.0, 0.0, avail
    frac = min(1.0, plr / ch["min_plr"]) if plr < ch["min_plr"] else 1.0
    plr_used = max(plr, ch["min_unload"])
    eirft = _biquad(ch["eirft"], f2c(tchws_f), f2c(tcond_f))
    eirfplr = _quad(ch["eirfplr"], plr_used)
    power_w = (avail * 3516.85) / ch["ref_cop"] * eirfplr * eirft * frac
    return power_w / 1000.0, plr, avail

def chiller_min_entering_f(ch):
    return c2f(max(ch["capft"][8], ch["eirft"][8]))

def chiller_max_entering_f(ch):
    return c2f(min(ch["capft"][9], ch["eirft"][9]))

# ------------------------------------------------------------------ plant simulation
def pump_kw(gpm, pump):
    ratio = gpm / pump["gpm_ref"]
    head = pump["h_static_ft"] + (pump["h_pipe_ft"] + pump["h_cond_ft"]) * ratio * ratio
    bhp = gpm * head / (3960.0 * pump["eta_pump"])
    return bhp * HP_TO_KW / pump["eta_motor"]

def cells_in_service(n_installed, model, gpm):
    """DC-02 6.6: effective minimum = max(submittal minimum, nominal x minimum water flow ratio)."""
    lo = max(model["gpm_min"], model["gpm_nominal"] * 0.75)
    for n in range(n_installed, 0, -1):
        if gpm / n >= lo - 1e-9:
            return n
    return 0

def evaporation_gpm(method, gpm, range_f, fr_air, n_cells_on, model, twb_f, tdb_f, press_pa):
    if method == "loss-factor":
        return gpm * dF2dC(range_f) * 0.0018          # UFM 3-230-13 5-2.1.3
    q_w = CP_WATER_BTU * gpm * range_f / 3.412142
    w_in = w_from_twb(f2c(tdb_f), f2c(twb_f), press_pa)
    rho = rho_air(press_pa, f2c(tdb_f), w_in)
    air_m3s = model["cfm_nominal"] * n_cells_on * fr_air * 0.000471947
    m_air = air_m3s * rho
    if m_air <= 0.0:
        return 0.0
    twb_c = f2c(twb_f)
    h_in = enthalpy(twb_c, w_sat(twb_c, press_pa))
    h_out = h_in + q_w / m_air
    t_out = tsat_from_h(h_out, press_pa)
    w_out = w_from_tdb_h(t_out, h_out)
    rho_w = water_density(max(0.5 * (f2c(tdb_f) + t_out), 4.0))
    return max(m_air * (w_out / (1.0 + w_out) - w_in / (1.0 + w_in)) / rho_w, 0.0) / GPM_TO_M3S

def simulate(design, plant, ctx, bins):
    """Annual simulation over the scenario bins.  design is a dict; plant is the plant record."""
    model = ctx["cat"][design["model"]]
    cv = ctx["cv"]
    ch = ctx["chil"][plant["chiller"]]
    press = ctx["pressure_pa"]
    tchws = plant["chws_f"]
    n_ch_max = plant["n_chillers"]
    gpm_ch = design["gpm_total"] / n_ch_max
    fr_min = model["fr_air_min"]
    frac_free = model["free_conv_frac"]
    fan_kw_design = model["fan_bhp"] * HP_TO_KW / (design["motor_eff"] * ctx["vfd_eff"])
    rows, kwh, makeup, blow, peak = [], 0.0, 0.0, 0.0, 0.0
    viol = {"flow": [], "envelope": [], "setpoint": [], "fanpower": [], "capacity": []}
    for b in bins:
        twb, tdb, load, hours = b["twb_f"], b["tdb_f"], b["load_tons"], b["hours"]
        if load <= 0 or hours <= 0:
            continue
        tcond = max(design["cws_min_f"], twb + design["cws_offset_f"])
        cws = tcond
        ok = True
        for _ in range(8):
            n_ch = n_ch_max
            for k in range(1, n_ch_max + 1):
                if chiller_capacity_tons(ch, tchws, tcond) * k >= load:
                    n_ch = k
                    break
            kw_ch1, plr, avail = chiller_kw(ch, tchws, tcond, load / n_ch)
            kw_ch = kw_ch1 * n_ch
            q_btuh = load * BTUH_PER_TON + kw_ch * 3412.142
            gpm = gpm_ch * n_ch
            n_on = cells_in_service(design["cells"], model, gpm)
            if n_on == 0:
                viol["flow"].append(round(twb, 1)); ok = False; break
            fr_water = (gpm / n_on) / model["gpm_nominal"]
            rng = q_btuh / (CP_WATER_BTU * gpm)
            sp = max(design["cws_min_f"], twb + design["cws_offset_f"], chiller_min_entering_f(ch))
            a_full = approach_f(cv, twb, rng, fr_water, 1.0)
            t_on = twb + a_full
            if t_on > sp:
                fr_air = fr_power = fr_corr = 1.0; fan_plr = 1.0; cws = t_on
            else:
                t_in = tcond + rng
                cws_free = t_in - frac_free * (t_in - t_on)
                if cws_free <= sp:
                    fr_air, fr_power, fr_corr = frac_free, 0.0, 1.0
                    fan_plr, cws = 0.0, max(cws_free, sp)
                else:
                    t_min = twb + approach_f(cv, twb, rng, fr_water, fr_min)
                    if t_min < sp:
                        denom = cws_free - t_min
                        fan_plr = min(max((cws_free - sp) / denom, 0.0), 1.0) if denom > 1e-9 else 1.0
                        fr_power = fr_corr = fr_min
                        fr_air = fan_plr * fr_min + (1.0 - fan_plr) * frac_free
                        cws = sp
                    else:
                        fr_air = fr_power = fr_corr = fr_air_for_setpoint(cv, twb, rng, fr_water, sp, fr_min)
                        fan_plr = 1.0
                        cws = twb + approach_f(cv, twb, rng, fr_water, fr_corr)
            if abs(cws - tcond) < 0.02:
                tcond = cws
                break
            tcond = 0.5 * (tcond + cws)
        if not ok:
            continue
        tcond = cws
        kw_ch1, plr, avail = chiller_kw(ch, tchws, tcond, load / n_ch)
        kw_ch = kw_ch1 * n_ch
        if load > avail * n_ch * ch["max_plr"] + 1e-6:
            viol["capacity"].append((round(twb, 1), round(load, 1)))
        q_btuh = load * BTUH_PER_TON + kw_ch * 3412.142
        rng = q_btuh / (CP_WATER_BTU * gpm)
        kw_fan = n_on * fan_kw_design * fan_plr * fr_power ** 3
        kw_pu = n_ch * pump_kw(gpm_ch, plant["pump"])
        kw_tot = kw_ch + kw_fan + kw_pu
        cwr = cws + rng
        app = cws - twb
        if not (cv["range_min_c"] - 1e-9 <= dF2dC(rng) <= cv["range_max_c"] + 1e-9):
            viol["envelope"].append(("range", round(rng, 2)))
        if not (cv["approach_min_c"] - 1e-9 <= dF2dC(app) <= cv["approach_max_c"] + 1e-9):
            viol["envelope"].append(("approach", round(app, 2)))
        lg = min(max(fr_water, cv["fw_min"]), cv["fw_max"]) / max(fr_corr, 1e-6)
        if lg > cv["lg_max"] + 1e-9:
            viol["envelope"].append(("lg", round(lg, 2)))
        if not (cv["fw_min"] - 1e-9 <= fr_water <= cv["fw_max"] + 1e-9):
            viol["envelope"].append(("frwater", round(fr_water, 3)))
        if gpm / n_on > min(model["gpm_max"], model["gpm_nominal"] * cv["fw_max"]) + 1e-6:
            viol["flow"].append(round(gpm / n_on, 1))
        if cws > chiller_max_entering_f(ch) + 1e-6:
            viol["setpoint"].append(round(cws, 2))
        bhp = model["fan_bhp"] * fan_plr * fr_power ** 3
        if bhp > design["fan_hp"] + 1e-6:
            viol["fanpower"].append(round(bhp, 2))
        ev = evaporation_gpm(design["evap_method"], gpm, rng, fr_air, n_on, model, twb, tdb, press)
        dr = design["gpm_total"] * (n_on / max(design["cells"], 1)) * (design["drift_pct"] / 100.0) * fr_air
        bd = max(ev / (design["coc"] - 1.0) - dr, 0.0)
        mk = ev + dr + bd
        rows.append({"twb_f": twb, "tdb_f": tdb, "hours": hours, "load_tons": load, "n_chillers": n_ch,
                     "n_cells": n_on, "gpm": gpm, "fr_water": fr_water, "fr_air": fr_air,
                     "fan_plr": fan_plr, "range_f": rng, "cws_f": cws, "cwr_f": cwr,
                     "kw_chiller": kw_ch, "kw_fan": kw_fan, "kw_pump": kw_pu, "kw_total": kw_tot,
                     "evap_gpm": ev, "drift_gpm": dr, "blowdown_gpm": bd, "makeup_gpm": mk,
                     "approach_f": app})
        kwh += kw_tot * hours
        makeup += mk * 60.0 * hours
        blow += bd * 60.0 * hours
        peak = max(peak, kw_tot)
    return {"kwh": kwh, "makeup_gal": makeup, "blowdown_gal": blow, "peak_kw": peak, "rows": rows,
            "violations": viol}

def design_point(design, plant, ctx, wb_f, load_tons, cells_available=None):
    model = ctx["cat"][design["model"]]
    cv = ctx["cv"]
    ch = ctx["chil"][plant["chiller"]]
    cells = cells_in_service(design["cells"], model, design["gpm_total"]) if cells_available is None \
        else cells_available
    if cells <= 0:
        return {"feasible": False}
    gpm = design["gpm_total"]
    tcond = design["cws_design_f"]
    rng = 0.0
    for _ in range(20):
        kw_ch, plr, avail = chiller_kw(ch, plant["chws_f"], tcond, load_tons / plant["n_chillers"])
        kw_ch *= plant["n_chillers"]
        q = load_tons * BTUH_PER_TON + kw_ch * 3412.142
        rng = q / (CP_WATER_BTU * gpm)
        fr_water = (gpm / cells) / model["gpm_nominal"]
        cws = wb_f + approach_f(cv, wb_f, rng, fr_water, 1.0)
        if abs(cws - tcond) < 0.005:
            tcond = cws
            break
        tcond = 0.5 * (tcond + cws)
    kw_ch, plr, avail = chiller_kw(ch, plant["chws_f"], tcond, load_tons / plant["n_chillers"])
    return {"feasible": True, "cws_f": tcond, "range_f": rng, "approach_f": tcond - wb_f,
            "fr_water": fr_water, "q_btuh": q, "avail_tons": avail * plant["n_chillers"],
            "kw_chiller": kw_ch * plant["n_chillers"], "plr": plr, "cells": cells}

# ------------------------------------------------------------------ scaling index / cycles (UFM 3-230-13)
_TBL_A1 = [(50, 0.07), (75, 0.08), (100, 0.10), (150, 0.11), (200, 0.13), (300, 0.14), (400, 0.16),
           (600, 0.18), (800, 0.19), (1000, 0.20), (1500, 0.21), (2000, 0.22), (2500, 0.23),
           (3000, 0.24), (4000, 0.25), (5000, 0.26)]
_TBL_A2 = {30: [None, 2.60, 2.57, 2.54, 2.51], 40: [2.48, 2.45, 2.43, 2.40, 2.37],
           50: [2.34, 2.31, 2.28, 2.25, 2.22], 60: [2.20, 2.17, 2.14, 2.11, 2.09],
           70: [2.06, 2.04, 2.03, 2.00, 1.97], 80: [1.95, 1.92, 1.90, 1.88, 1.86],
           90: [1.84, 1.82, 1.80, 1.78, 1.76], 100: [1.74, 1.72, 1.71, 1.69, 1.67],
           110: [1.65, 1.64, 1.62, 1.60, 1.58], 120: [1.57, 1.55, 1.53, 1.51, 1.50],
           130: [1.48, 1.46, 1.44, 1.43, 1.41], 140: [1.40, 1.38, 1.37, 1.35, 1.34],
           150: [1.32, 1.31, 1.29, 1.28, 1.27], 160: [1.26, 1.24, 1.23, 1.22, 1.21],
           170: [1.19, 1.18, 1.17, 1.16, None]}
_B_PTS = sorted((t + 2 * j, v) for t, vals in _TBL_A2.items() for j, v in enumerate(vals) if v is not None)

def _interp(pairs, x):
    xs = [p[0] for p in pairs]; ys = [p[1] for p in pairs]
    if x <= xs[0]:
        return ys[0]
    if x >= xs[-1]:
        return ys[-1]
    for i in range(len(xs) - 1):
        if xs[i] <= x <= xs[i + 1]:
            return ys[i] + (ys[i + 1] - ys[i]) * (x - xs[i]) / (xs[i + 1] - xs[i])
    return ys[-1]

def factor_B(temp_f):
    return _interp(_B_PTS, temp_f)

def psi_index(tds, temp_f, ca, alk):
    A = (math.log10(max(tds, 1.0)) - 1.0) / 10.0          # WT-01 4.1 closed forms
    C = math.log10(max(ca, 1.0)) - 0.4
    D = math.log10(max(alk, 1.0))
    phs = 9.30 + A + factor_B(temp_f) - (C + D)
    pheq = 1.485 * math.log10(max(alk, 1.0)) + 4.54
    return 2.0 * phs - pheq

def coc_allowable(makeup, hot_water_f, wt):
    """Lowest of the salt limits the programme does not address and the PSI limit (WT-01 4)."""
    silica = 150.0 / max(makeup["sio2"], 1e-9)            # UFM Eq. 5-8, 150 ppm as the manual states
    def psi(c):
        return psi_index(makeup["tds"] * c, hot_water_f, makeup["ca"] * c, wt["alk_controlled_ppm"])
    lo, hi = 1.0, 15.0
    if psi(lo) < wt["psi_floor"]:
        psi_coc = 1.0
    elif psi(hi) >= wt["psi_floor"]:
        psi_coc = hi
    else:
        for _ in range(60):
            mid = 0.5 * (lo + hi)
            if psi(mid) >= wt["psi_floor"]:
                lo = mid
            else:
                hi = mid
        psi_coc = lo
    return {"silica": silica, "psi": psi_coc, "max": min(silica, psi_coc),
            "governing": "silica" if silica <= psi_coc else "psi"}

# ------------------------------------------------------------------ economics (EC-01, NIST 2025 tables)
def nist_factors():
    """DOE real discount rate and the UPV* factors for Mountain / Commercial / Electricity, 2025 release."""
    import openpyxl
    wb = openpyxl.load_workbook(os.path.join(WB, "economics", "NISTIR85-3273-40 - V2.xlsx"), data_only=True)
    memo = wb["DiscountRateMemo"]
    d = None
    for row in memo.iter_rows(values_only=True):
        if row and row[0] and "DOE Real Discount Rate" in str(row[0]):
            d = float(row[1])
    upv_elec = None
    ws = wb["UPV - DOE (new Ba)"]
    rows = list(ws.iter_rows(values_only=True))
    hdr = rows[0]
    for r in rows[1:]:
        if r[3] == "Mountain" and r[4] == "Commercial" and r[5] == "Electricity":
            upv_elec = {int(hdr[i]): float(r[i]) for i in range(6, len(hdr)) if hdr[i] not in (None, "")}
            break
    return {"discount_real": d, "upv_star_electricity": upv_elec}

def upv(d, n):
    return (1.0 - (1.0 + d) ** -n) / d if n > 0 else 0.0

def upv_star(d, e, n):
    if n <= 0:
        return 0.0
    if abs(d - e) < 1e-12:
        return float(n)
    return (1.0 + e) / (d - e) * (1.0 - ((1.0 + e) / (1.0 + d)) ** n)

def spv(d, t):
    return (1.0 + d) ** -t

def econ_params():
    f = nist_factors()
    d = f["discount_real"]
    upv_e = f["upv_star_electricity"]
    study, construction = 26, 1
    inflation = 0.015
    water_nom = 0.035
    water_real = (1.0 + water_nom) / (1.0 + inflation) - 1.0
    return {"discount_real": d, "study_years": study, "construction_years": construction,
            "upv_star_electricity": upv_e[study] - upv_e[construction],
            "upv_star_water": upv_star(d, water_real, study) - upv_star(d, water_real, construction),
            "upv_nonfuel": upv(d, study) - upv(d, construction),
            "water_escalation_real": water_real,
            "energy_per_kwh": 0.0712, "demand_per_kw_month": 17.80,
            "reclaimed_per_kgal": 1.94, "sewer_per_kgal": 3.20,
            "treatment_per_kgal_makeup": 0.42}

def investment(pr, model, cells, material, eliminator, premium, op_weight_lb):
    base = pr["base"][model]
    per_cell_equipment = (base + base * pr["material_adder_frac"].get(material, 0.0)
                          + pr["eliminator_adder"].get(eliminator, 0.0)
                          + (pr["premium_motor_adder"].get(model, 0.0) if premium else 0.0))
    rig = pr["rigging_per_lb"] * op_weight_lb
    per_cell = per_cell_equipment + rig + pr["connection_per_cell"]
    return {"per_cell": per_cell, "per_cell_equipment": per_cell_equipment,
            "replaceable": cells * per_cell, "total": cells * per_cell + pr["plant_fixed"]}

def lcc(ep, pr, model, cells, material, eliminator, premium, op_weight_lb, kwh, peak_kw,
        makeup_kgal, blowdown_kgal):
    d = ep["discount_real"]
    inv = investment(pr, model, cells, material, eliminator, premium, op_weight_lb)
    energy_annual = kwh * ep["energy_per_kwh"] + 12.0 * ep["demand_per_kw_month"] * peak_kw
    water_annual = makeup_kgal * ep["reclaimed_per_kgal"] + blowdown_kgal * ep["sewer_per_kgal"]
    om_annual = makeup_kgal * ep["treatment_per_kgal_makeup"] + cells * pr["service_life"][material]["maint"]
    life = pr["service_life"][material]["years"]
    n, c = ep["study_years"], ep["construction_years"]
    at = c
    repl = 0.0
    while at + life < n - 1e-9:
        at += life
        repl += inv["replaceable"] * spv(d, at)
    used = n - at
    salvage = inv["replaceable"] * (max(life - used, 0.0) / life) * spv(d, n) if life > used else 0.0
    pv_e = energy_annual * ep["upv_star_electricity"]
    pv_w = water_annual * ep["upv_star_water"]
    pv_om = om_annual * ep["upv_nonfuel"]
    total = inv["total"] + pv_e + pv_w + pv_om + repl - salvage
    return {"investment": inv["total"], "energy_annual": energy_annual, "water_annual": water_annual,
            "om_annual": om_annual, "pv_energy": pv_e, "pv_water": pv_w, "pv_om": pv_om,
            "pv_replacement": repl, "pv_salvage": salvage, "lcc": total, "replaceable": inv["replaceable"]}
