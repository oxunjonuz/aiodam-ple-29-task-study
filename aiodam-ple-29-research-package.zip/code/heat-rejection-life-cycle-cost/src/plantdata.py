"""plantdata.py - the project data, read from the shipped documents (not from the grader).

Sources, by field:
  chillers            M-601 Rev C (tags, data set names, max PLR) and VD-03 (flow and temperature limits)
  catalogue, motors   VD-01 table 2, VD-02 FanData/MotorData/Drives
  pricing, lives      VD-05 BudgetPricing / Options / Installation / ServiceLife
  roof zones, intakes M-401 Rev C (M-EQPM-ZONE / M-EQPM-INTK)
  framing zones       S-401 Rev C (S-ROOF-ZONE)
  MCC spare           E-601 Rev C less RFI-034 Response 1 (LAB)
  water allocation    PW-LTR-014 Table 1 and PW-LTR-019 (ANNEX)
  pump constants      DC-02 Table 3
  block loads         M-603
"""
from __future__ import annotations

import os
import re

import ctmodel as M

DRAW = os.path.join(M.WB, "drawings")

def dxf_text(fn):
    import ezdxf
    doc = ezdxf.readfile(os.path.join(DRAW, fn))
    out = []
    for e in doc.modelspace():
        if e.dxftype() in ("TEXT", "MTEXT"):
            t = e.dxf.text if e.dxftype() == "TEXT" else e.text
            p = (e.dxf.insert.x, e.dxf.insert.y)
            out.append((e.dxf.layer, p, t))
    return out

def dxf_polys(fn):
    import ezdxf
    doc = ezdxf.readfile(os.path.join(DRAW, fn))
    out = []
    for e in doc.modelspace():
        if e.dxftype() == "LWPOLYLINE":
            pts = [(p[0], p[1]) for p in e.get_points("xy")]
            out.append((e.dxf.layer, pts))
    return out

def _num(pattern, text):
    m = re.search(pattern, text, re.I)
    return float(m.group(1)) if m else None

def roof_geometry():
    """Roof zones, intake points and framing zones, read off the Rev C drawings."""
    zones, intakes = {}, {}
    for layer, (x, y), t in dxf_text("M-401_ROOF_MECHANICAL_PLAN_RevC.dxf"):
        if layer == "M-EQPM-INTK":
            m = re.search(r"OAI-([A-Z]+)-\d.*AT \(([-\d.]+),\s*([-\d.]+)\)", t)
            if m:
                intakes.setdefault(m.group(1), []).append((float(m.group(2)), float(m.group(3))))
    zone_polys = [p for l, p in dxf_polys("M-401_ROOF_MECHANICAL_PLAN_RevC.dxf") if l == "M-EQPM-ZONE"]
    annos = [t for l, (x, y), t in dxf_text("M-401_ROOF_MECHANICAL_PLAN_RevC.dxf")
             if l == "M-EQPM-ZONE" and "ZONE" in t and "REV C" in t]
    names = [re.search(r"ZONE ([A-Z]+) \(REV C\)", t).group(1) for t in annos]
    for nm, poly in zip(names, zone_polys):
        xs = [p[0] for p in poly]; ys = [p[1] for p in poly]
        zones[nm] = [min(xs), min(ys), max(xs), max(ys)]
    framing = {}
    polys = [p for l, p in dxf_polys("S-401_ROOF_FRAMING_PLAN_RevC.dxf") if l == "S-ROOF-ZONE"]
    stext = [(l, p, t) for l, p, t in dxf_text("S-401_ROOF_FRAMING_PLAN_RevC.dxf") if l == "S-ROOF-ZONE"]
    allow = [_num(r"ALLOWABLE SUPERIMPOSED LOAD ([\d.]+) PSF", t) for l, p, t in stext if "ALLOWABLE" in t]
    tags = [re.search(r"FRAMING ZONE ([A-Z0-9-]+)", t).group(1) for l, p, t in stext if "FRAMING ZONE" in t]
    for tag, poly, a in zip(tags, polys, allow):
        xs = [p[0] for p in poly]; ys = [p[1] for p in poly]
        pid = tag.split("-")[0]
        framing.setdefault(pid, []).append({"tag": tag, "rect": [min(xs), min(ys), max(xs), max(ys)],
                                            "allow_psf": a})
    return zones, intakes, framing

M603 = {"CUP": [(55, 190), (70, 300), (85, 500), (95, 650), (105, 780), (112, 830)],
        "ANNEX": [(55, 560), (70, 610), (85, 700), (95, 780), (105, 850), (112, 890)],
        "LAB": [(55, 520), (70, 650), (85, 830), (95, 950), (105, 1040), (112, 1090)]}

def load_at(pid, tdb):
    """M-603: block load vs outdoor dry bulb, linear between points, end values held."""
    pts = M603[pid]
    if tdb <= pts[0][0]:
        return pts[0][1]
    if tdb >= pts[-1][0]:
        return pts[-1][1]
    for (x0, y0), (x1, y1) in zip(pts, pts[1:]):
        if x0 <= tdb <= x1:
            return y0 + (y1 - y0) * (tdb - x0) / (x1 - x0)
    return pts[-1][1]

def makeup_water():
    """WT-01 2: the most recent COMPLETE analysis of the reclaimed supply (WQP result set)."""
    import csv
    path = os.path.join(M.WB, "water", "WQP_USGS-332255112182101_results.csv")
    rows = list(csv.DictReader(open(path)))
    need = {"Calcium": "Dissolved", "Alkalinity": "Dissolved", "Total dissolved solids": "Dissolved",
            "Sulfate": "Dissolved", "Silica": "Dissolved"}
    by_date = {}
    for r in rows:
        by_date.setdefault(r["ActivityStartDate"], []).append(r)
    for date in sorted(by_date, reverse=True):
        rs = by_date[date]
        got = {}
        for r in rs:
            ch = r["CharacteristicName"]
            if ch in need and r["ResultSampleFractionText"] == need[ch]:
                unit = r.get("ResultMeasure/MeasureUnitCode", "")
                try:
                    v = float(r["ResultMeasureValue"])
                except (TypeError, ValueError):
                    continue
                if ch == "Total dissolved solids":
                    if "tons" in unit:
                        continue
                    if r.get("ResultAnalyticalMethod/MethodIdentifier", "").startswith("ROE"):
                        got["tds"] = v                     # residue on evaporation is the value of record
                    else:
                        got.setdefault("tds_calc", v)
                elif ch == "Alkalinity":
                    got.setdefault("alk", v)
                elif ch == "Calcium":
                    got["ca_mgl"] = v
                elif ch == "Sulfate":
                    got["so4"] = v
                elif ch == "Silica":
                    got["sio2"] = v
        if all(k in got for k in ("tds", "alk", "ca_mgl", "so4", "sio2")):
            return {"date": date, "tds": got["tds"], "ca_mgl": got["ca_mgl"],
                    "ca": got["ca_mgl"] * 2.497, "alk": got["alk"], "so4": got["so4"],
                    "sio2": got["sio2"], "tds_calc": got.get("tds_calc")}
    raise KeyError("no complete analysis")

def plants():
    zones, intakes, framing = roof_geometry()
    p = {
        "CUP": {"chiller": "CH-A", "n_chillers": 2, "chws_f": 44.0, "design_load_tons": 820.0,
                "mcc": {"panel": "MCC-R1", "spare_kw": 528.0},
                "pump": {"gpm_ref": 1500.0, "h_static_ft": 24.0, "h_pipe_ft": 26.0, "h_cond_ft": 21.0,
                         "eta_pump": 0.78, "eta_motor": 0.945},
                "water": {"annual_kgal": 10300.0, "peak_day_gal": 58000.0, "blowdown_day_gal": 14500.0}},
        "ANNEX": {"chiller": "CH-B", "n_chillers": 2, "chws_f": 44.0, "design_load_tons": 880.0,
                  "mcc": {"panel": "MCC-R2", "spare_kw": 590.0},
                  "pump": {"gpm_ref": 1500.0, "h_static_ft": 21.0, "h_pipe_ft": 23.0, "h_cond_ft": 21.0,
                           "eta_pump": 0.77, "eta_motor": 0.945},
                  "water": {"annual_kgal": 12600.0, "peak_day_gal": 62000.0, "blowdown_day_gal": 15800.0}},
        "LAB": {"chiller": "CH-C", "n_chillers": 3, "chws_f": 45.0, "design_load_tons": 1070.0,
                "mcc": {"panel": "MCC-R3", "spare_kw": 641.1},
                "pump": {"gpm_ref": 1065.0, "h_static_ft": 27.0, "h_pipe_ft": 29.0, "h_cond_ft": 19.0,
                         "eta_pump": 0.77, "eta_motor": 0.945},
                "water": {"annual_kgal": 17400.0, "peak_day_gal": 80000.0, "blowdown_day_gal": 20800.0}},
    }
    for nm, rec in p.items():
        rec["roof_zone"] = zones[nm]
        rec["intakes"] = intakes[nm]
        rec["framing_zones"] = framing[nm]
        rec["load_curve"] = M603[nm]
    # MCC-R3: E-601 states 660 kW; RFI-034 Response 1 adds three 7.5 hp, 91.7 %, VFD 0.97 fans
    fan_kw = 3 * 7.5 * M.HP_TO_KW / (0.917 * 0.97)
    p["LAB"]["mcc"]["spare_kw"] = round(660.0 - fan_kw, 1)
    p["LAB"]["mcc"]["rfi034_fan_kw"] = fan_kw
    return p

CHILLER_TAGS = {"CH-A": "ElectricEIRChiller York YT 1758kW/6.28COP/Vanes",
                "CH-B": "ElectricEIRChiller Trane CVHE 1758kW/5.96COP/Vanes",
                "CH-C": "ElectricEIRChiller York YT 1495kW/7.51COP/VSD"}

def context():
    cat, motors = M.catalogue()
    pr = M.pricing()
    obs_pressure = 97264.07925910968          # mean station pressure of the POR, DC-02 5.5
    return {"cat": cat, "motors": motors, "pricing": pr, "cv": M.load_tower_curve(),
            "chil": {k: M.load_chiller(v) for k, v in CHILLER_TAGS.items()},
            "pressure_pa": obs_pressure, "vfd_eff": 0.97, "makeup": makeup_water(),
            "wt": {"psi_floor": 5.6, "alk_controlled_ppm": 120.0},
            "eliminators": {"DE-1": 0.005, "DE-2": 0.002, "DE-3": 0.0005},
            "water_contact_ok": ["FRP-PV", "SS-304", "SS-316"],
            "drift_limit_pct": 0.002}
