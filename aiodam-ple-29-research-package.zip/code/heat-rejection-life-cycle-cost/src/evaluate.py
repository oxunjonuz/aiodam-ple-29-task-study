"""evaluate.py - design point, annual simulation, water balance, LCC and the six margins for a design."""
from __future__ import annotations

import json
import sys

import ctmodel as M
import plantdata as P
import weather as W

REFERENCE = {
    "CUP": {"model": "CTX-0600-S", "cells": 4, "gpm_total": 1800.0, "cws_design_f": 86.0,
            "cws_min_f": 65.5, "cws_offset_f": 11.5, "coc": 4.14, "drift_pct": 0.002,
            "material": "SS-304", "eliminator": "DE-2", "motor_eff": 0.917},
    "ANNEX": {"model": "CTX-0600-S", "cells": 4, "gpm_total": 1800.0, "cws_design_f": 86.5,
              "cws_min_f": 79.5, "cws_offset_f": 11.5, "coc": 4.0, "drift_pct": 0.002,
              "material": "SS-304", "eliminator": "DE-2", "motor_eff": 0.917},
    "LAB": {"model": "CTX-0900-H", "cells": 3, "gpm_total": 2025.0, "cws_design_f": 86.5,
            "cws_min_f": 57.4, "cws_offset_f": 8.875, "coc": 3.88, "drift_pct": 0.002,
            "material": "SS-304", "eliminator": "DE-2", "motor_eff": 0.917},
}

def make_design(pid, ctx, **kw):
    d = dict(REFERENCE[pid])
    d.update(kw)
    m = ctx["cat"][d["model"]]
    d.setdefault("fan_hp", m["fan_hp"])
    d.setdefault("motor_poles", 6)
    d.setdefault("enclosure", "TEFC")
    d.setdefault("evap_method", "saturated-exit")
    return d

def evaluate(pid, design, ctx, plants, bins, wb, verbose=True):
    plant = plants[pid]
    m = ctx["cat"][design["model"]]
    ch = ctx["chil"][plant["chiller"]]
    dp = M.design_point(design, plant, ctx, wb["design_wb_f"], plant["design_load_tons"])
    sim = M.simulate(design, plant, ctx, bins)
    # redundancy: one cell out
    dp_red = M.design_point(design, plant, ctx, wb["redundancy_wb_f"], plant["design_load_tons"],
                            cells_available=design["cells"] - 1)
    coc = M.coc_allowable(ctx["makeup"], dp["cws_f"] + dp["range_f"], ctx["wt"])
    makeup_kgal = sim["makeup_gal"] / 1000.0
    blow_kgal = sim["blowdown_gal"] / 1000.0
    ep = M.econ_params()
    premium = abs(design["motor_eff"] * 100 - ctx["motors"][m["fan_hp"]]["premium"]) <= 0.05
    lc = M.lcc(ep, ctx["pricing"], design["model"], design["cells"], design["material"],
               design["eliminator"], premium, m["op_weight_lb"], sim["kwh"], sim["peak_kw"],
               makeup_kgal, blow_kgal)
    # peak day (PW-LTR-014 2): design WB, design block load, highest DB the schedule tabulates
    tdb_pk = max(wb["design_wb_f"], P.M603[pid][-1][0])
    pk = M.simulate(design, plant, ctx, [{"twb_f": wb["design_wb_f"], "tdb_f": tdb_pk, "hours": 24.0,
                                          "load_tons": plant["design_load_tons"]}])
    base = basic_lcc(pid, ctx, plants, bins, ep)
    # margins (DC-02 9)
    psf = m["op_weight_lb"] / (m["plan_w_ft"] * m["plan_l_ft"])
    zones = plant["framing_zones"]
    margins = {
        "water allocation": (plant["water"]["annual_kgal"] - makeup_kgal) / plant["water"]["annual_kgal"],
        "electrical capacity": (plant["mcc"]["spare_kw"] - sim["peak_kw"]) / plant["mcc"]["spare_kw"],
        "structural capacity": min((fz["allow_psf"] - psf) / fz["allow_psf"]
                                   for fz in zones if fz["allow_psf"] >= psf),
        "condenser flow limit": min(
            (design["gpm_total"] / plant["n_chillers"] - (M.published_cond_flow(ch)[0] - 0.5))
            / (M.published_cond_flow(ch)[0] - 0.5),
            ((M.published_cond_flow(ch)[1] + 0.5) - design["gpm_total"] / plant["n_chillers"])
            / (M.published_cond_flow(ch)[1] + 0.5),
            (design["gpm_total"] / design["cells"] - m["gpm_min"]) / m["gpm_min"],
            (m["gpm_max"] - design["gpm_total"] / design["cells"]) / m["gpm_max"]),
        "tower capability": (design["cws_design_f"] - dp["cws_f"])
                            / (design["cws_design_f"] - wb["design_wb_f"]),
    }
    out = {"pid": pid, "design": design,
           "design_point": {k: (round(v, 4) if isinstance(v, float) else v) for k, v in dp.items()},
           "redundancy": {"cws_f": round(dp_red["cws_f"], 3), "avail_tons": round(dp_red["avail_tons"], 1),
                          "cells": dp_red["cells"]},
           "annual": {"kwh": round(sim["kwh"], 1), "peak_kw": round(sim["peak_kw"], 2),
                      "makeup_kgal": round(makeup_kgal, 1), "blowdown_kgal": round(blow_kgal, 1),
                      "makeup_gal": round(sim["makeup_gal"], 0),
                      "drift_kgal": round(sum(r["drift_gpm"] * 60 * r["hours"] for r in sim["rows"]) / 1000, 1),
                      "evap_kgal": round(sum(r["evap_gpm"] * 60 * r["hours"] for r in sim["rows"]) / 1000, 1)},
           "peak_day": {"makeup_gal": round(pk["makeup_gal"], 0), "blowdown_gal": round(pk["blowdown_gal"], 0)},
           "coc": {"max": round(coc["max"], 3), "silica": round(coc["silica"], 3),
                   "psi": round(coc["psi"], 3), "governing": coc["governing"],
                   "psi_at_cwr": round(M.psi_index(ctx["makeup"]["tds"] * design["coc"],
                                                   dp["cws_f"] + dp["range_f"],
                                                   ctx["makeup"]["ca"] * design["coc"],
                                                   ctx["wt"]["alk_controlled_ppm"]), 3)},
           "lcc": {k: round(v, 0) for k, v in lc.items()},
           "basic_lcc": round(base["lcc"], 0),
           "ns": round(base["lcc"] - lc["lcc"], 1),
           "margins": {k: round(v, 4) for k, v in margins.items()},
           "governing": min(margins, key=margins.get),
           "violations": {k: (len(v), v[:3]) for k, v in sim["violations"].items()}}
    return out

_BASIC = {}

def basic_lcc(pid, ctx, plants, bins, ep):
    """EC-01 5: replace the existing cells in kind, fixed 85 F setpoint, COC 3, DE-2, SS-304, premium."""
    if pid in _BASIC:
        return _BASIC[pid]
    plant = plants[pid]
    model = "CTX-0900-S"
    m = ctx["cat"][model]
    d = {"model": model, "cells": 3, "gpm_total": 2100.0, "cws_design_f": 85.0, "cws_min_f": 85.0,
         "cws_offset_f": 0.0, "coc": 3.0, "drift_pct": 0.002, "fan_hp": m["fan_hp"], "motor_eff": 0.936,
         "motor_poles": 6, "enclosure": "TEFC", "material": "SS-304", "eliminator": "DE-2",
         "evap_method": "saturated-exit"}
    sim = M.simulate(d, plant, ctx, bins)
    lc = M.lcc(ep, ctx["pricing"], model, 3, "SS-304", "DE-2", True, m["op_weight_lb"], sim["kwh"],
               sim["peak_kw"], sim["makeup_gal"] / 1000.0, sim["blowdown_gal"] / 1000.0)
    lc["kwh"], lc["peak_kw"] = sim["kwh"], sim["peak_kw"]
    _BASIC[pid] = lc
    return lc

if __name__ == "__main__":
    ctx = P.context()
    plants = P.plants()
    wb = W.weather_basis()
    obs, _ = W.observations()
    bins = W.bins(obs)
    which = sys.argv[1:] or ["CUP", "ANNEX", "LAB"]
    for pid in which:
        pbins = [dict(r, load_tons=P.load_at(pid, r["tdb_f"])) for r in bins]
        res = evaluate(pid, make_design(pid, ctx), ctx, plants, pbins, wb)
        print(json.dumps(res, indent=1))
