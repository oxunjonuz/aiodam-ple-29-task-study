"""Scenario bins from the NCEI LCD Phoenix record (DC-02 5.1/5.3)."""
import csv, math, os, json
W = "/work/ple-dataset/tasks/heat-rejection-life-cycle-cost/environment/filesystem/final_batch4__mechanical_task3_ct_heat_lcc__blind"
FILES = ["climate/LCD_72278023183_PHOENIX_AIRPORT_AZ_2022.csv",
         "climate/LCD_72278023183_PHOENIX_AIRPORT_AZ_2023.csv",
         "climate/LCD_72278023183_PHOENIX_AIRPORT_AZ_2024.csv"]

def _f(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return None

def observations():
    obs = []
    for rel in FILES:
        with open(os.path.join(W, rel), newline="") as fh:
            for row in csv.DictReader(fh):
                if row["REPORT_TYPE"] not in ("FM-15", "FM-16"):
                    continue
                wb = _f(row["HourlyWetBulbTemperature"]); db = _f(row["HourlyDryBulbTemperature"])
                st = _f(row["HourlyStationPressure"])
                if wb is None or db is None:
                    continue
                obs.append((wb, db, st))
    return obs

def percentile_exceeded(vals, pct):
    """The value exceeded pct percent of the observations (single annual population)."""
    v = sorted(vals)
    n = len(v)
    k = int(round(n * (1.0 - pct / 100.0)))     # index of the value with pct% above it
    k = min(max(k, 0), n - 1)
    return v[k]

def mean_pressure(obs):
    ps = [p for _, _, p in obs if p is not None]
    return sum(ps) / len(ps) if ps else None

def bins(obs, wb_w=2.0, db_w=5.0, hours_year=8760.0):
    counts = {}
    for wb, db, _ in obs:
        wb_lo = math.floor(wb / wb_w) * wb_w
        db_lo = math.floor(db / db_w) * db_w
        counts[(wb_lo, db_lo)] = counts.get((wb_lo, db_lo), 0) + 1
    n = len(obs)
    scale = hours_year / n
    out = []
    for (wb_lo, db_lo), c in sorted(counts.items()):
        wb_m = wb_lo + wb_w / 2.0
        db_m = db_lo + db_w / 2.0
        if db_m < wb_m:
            db_m = wb_m
        out.append({"twb_f": wb_m, "tdb_f": db_m, "hours": c * scale})
    return out

def load_curve(pid):
    """M-603 block load vs outdoor dry bulb, linear interpolation, end values held."""
    pts = {"CUP": [(55,190),(70,300),(85,500),(95,650),(105,780),(112,830)],
           "ANNEX": [(55,560),(70,610),(85,700),(95,780),(105,850),(112,890)],
           "LAB": [(55,520),(70,650),(85,830),(95,950),(105,1040),(112,1090)]}[pid]
    return pts

def load_at(pid, tdb):
    pts = load_curve(pid)
    if tdb <= pts[0][0]:
        return pts[0][1]
    if tdb >= pts[-1][0]:
        return pts[-1][1]
    for (x0, y0), (x1, y1) in zip(pts, pts[1:]):
        if x0 <= tdb <= x1:
            return y0 + (y1 - y0) * (tdb - x0) / (x1 - x0)
    return pts[-1][1]

if __name__ == "__main__":
    obs = observations()
    print("observations:", len(obs))
    wbs = [o[0] for o in obs]; dbs = [o[1] for o in obs]
    print("mean station pressure Pa: %.3f" % mean_pressure(obs))
    for p in (1.0, 0.4):
        print(f"WB exceeded {p}%: {percentile_exceeded(wbs, p)}")
    print("DB 99.6%% (not exceeded): %.1f" % sorted(dbs)[int(0.996*len(dbs))])
    b = bins(obs)
    print("bins:", len(b), "hours total: %.2f" % sum(x["hours"] for x in b))
    inst = json.load(open("/work/ple-dataset/tasks/heat-rejection-life-cycle-cost/tests/corrino/mechanical_task3_ct_heat_lcc/grading/data/instance.json"))
    ib = {(round(x["twb_f"],2), round(x["tdb_f"],2)): x["hours"] for x in inst["plants"]["CUP"]["bins"]}
    mine = {(round(x["twb_f"],2), round(x["tdb_f"],2)): x["hours"] for x in b}
    print("their bins:", len(ib), "mine:", len(mine), "same keys:", set(ib)==set(mine))
    diff = max(abs(ib[k]-mine[k]) for k in ib if k in mine) if set(ib)==set(mine) else None
    print("max hours diff:", diff)
    miss = set(ib) ^ set(mine)
    if miss: print("first mismatches:", sorted(miss)[:8])
