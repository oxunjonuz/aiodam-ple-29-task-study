#!/usr/bin/env python3
"""Builds Memo_to_Callaway_Spillway_2026-10-31.docx — response to CCPW comment G-4, Sheet C-9.

Every value in the memorandum is taken from the project record; the record for each is named in the
text. Three values are my own screening calculations and are labelled as such (they are not the
design and are not presented as the record's numbers).
"""
from pathlib import Path

import docx
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Inches, Pt

OUT = Path("/work/ple-solve/emergency-spillway-check/out")
NAME = "Memo_to_Callaway_Spillway_2026-10-31.docx"


def build() -> Path:
    d = docx.Document()
    st = d.styles["Normal"]
    st.font.name = "Calibri"
    st.font.size = Pt(10.5)

    def para(text, bold=False, size=None, space_after=4, align=None, italic=False):
        p = d.add_paragraph()
        r = p.add_run(text)
        r.bold = bold
        r.italic = italic
        if size:
            r.font.size = Pt(size)
        p.paragraph_format.space_after = Pt(space_after)
        if align:
            p.alignment = align
        return p

    def head(text):
        return para(text, bold=True, size=11, space_after=3)

    def bullet(text):
        p = d.add_paragraph(text, style="List Bullet")
        p.paragraph_format.space_after = Pt(2)
        return p

    # ---------------------------------------------------------------- letterhead and block
    para("SUNDIAL ENGINEERING & SURVEY", bold=True, size=13, space_after=0)
    para("4720 South Rainbow Boulevard, Suite 210, Las Vegas, Nevada 89103  |  (702) 555-0142  |  "
         "NV Certificate of Authority C-3874", size=9, space_after=10)
    para("MEMORANDUM", bold=True, size=14, space_after=8)

    block = [("TO:", "Mr. Garrett Nokes, Vice President, Land Development — Callaway Land Partners, LLC, "
                     "8880 W. Sunset Road, Suite 400, Las Vegas, NV 89148"),
             ("FROM:", "Max Braddock, Project Manager — Sundial Engineering & Survey"),
             ("CC:", "Jonathan R. Kessler, PE (Principal-in-Charge, NV PE No. 14203); Project File 2201-03"),
             ("DATE:", "October 31, 2026 (10/31/2026)"),
             ("RE:", "Desert Sage Ranch Phase 3 — Clark County Public Works comment G-4, emergency spillway on "
                     "Sheet C-9: freeboard, sizing, apron and the overflow discharge point. Improvement Plans "
                     "IP-26-100288 / Final Map FM-26-100290 / Tentative Map TM-22-500041."),
             ("JOB NO.:", "2201-03")]
    t = d.add_table(rows=len(block), cols=2)
    t.alignment = WD_TABLE_ALIGNMENT.LEFT
    t.autofit = False
    t.columns[0].width = Inches(1.0)
    t.columns[1].width = Inches(5.6)
    for row in t.rows:
        row.cells[0].width = Inches(1.0)
        row.cells[1].width = Inches(5.6)
    for i, (k, v) in enumerate(block):
        c0, c1 = t.rows[i].cells
        c0.text, c1.text = k, v
        c0.paragraphs[0].runs[0].bold = True
        for c in (c0, c1):
            c.paragraphs[0].runs[0].font.size = Pt(10)
    para("", space_after=2)

    # ---------------------------------------------------------------- 1. question
    head("1. Question presented and records reviewed")
    para("Comment G-4 in the Clark County Public Works first-round plan check letter dated October 9, 2026 "
         "(Dale Yeoman, PE, Civil Plans Examiner) reads: “The emergency spillway shown on Sheet C-9 lacks "
         "freeboard dimensioning and downstream apron details. Provide sizing calculations, spillway section, "
         "and erosion protection consistent with the RFCD Hydrologic Criteria and Drainage Design Manual.”")
    para("You asked three things before the drainage lead is put on the comment: whether the spillway as drawn "
         "holds up and whether G-4 can be answered with what is on the sheet today; whether the revisions that "
         "answer G-4 trigger an amendment to the accepted master drainage study; and what the spillway detail "
         "and the basin notes say on the revised C-9, including where the overflow ends up once it leaves the "
         "berm. The third of those splits into what the revised sheet must say and where the overflow may go, "
         "so the memorandum reaches four dispositions; each is a single disposition, not a set of options.")
    para("Records relied on, by short name used in this memorandum:")
    bullet("Sheet C-9 — Phase 3 Improvement Plans C-1 through C-9, issued for first submittal 08/21/2026 "
           "(Storage Summary Table, Section A-A′, Section B-B′, Detail — Emergency Spillway (Weir), Detail — "
           "Outlet Control Structure and Orifice Plate, Basin Notes).")
    bullet("Master Drainage Study, Desert Sage Ranch (140 acres), Revision 1 dated February 2022 (Table 4-1; "
           "Appendix C; Appendix D, Tables D-1 and D-2), accepted by CCRFCD by letter dated February 28, 2022 "
           "(the “accepted study”).")
    bullet("CCRFCD acceptance letter dated February 28, 2022 (FCD_MDS_Acceptance_Letter.pdf) — detention "
           "allocations, shared outfall allowance and the amendment triggers.")
    bullet("Phase 3 QA/QC Checklist dated 08/18/2026 (Tabs 2, 3 and 4); Phase 3 Hydrology Worksheet (07/2026); "
           "Phase 3 Storm Drain HGL worksheet (07/2026); Preliminary Detention Calculation dated 09/25/2026 "
           "(marked PRELIMINARY — internal working file).")
    bullet("Clark County Public Works Phase 2 comment letters (first and second round) and the Phase 2 comment "
           "response matrix; Phase 3 comment response log (resubmittal tracker).")
    bullet("Clark County Public Works Phase 2 Offsite Acceptance letter dated March 17, 2025, with the closed "
           "offsite punch list executed 03/12/2025.")
    bullet("Final Map FM-26-100290 plan check checkprint dated 08/21/2026; Phases 1–2 Final Map recorded "
           "12/23/2024 as Book 175, Page 60 (NFM-24-0118); Preliminary Title Report SBT-2026-04188 (effective "
           "07/01/2026); Conditions of Approval TM-22-500041 dated March 14, 2022.")

    # ---------------------------------------------------------------- 2. disposition 1
    head("2. Disposition 1 — Sheet C-9 as drawn is incomplete for the purposes of responding to comment G-4")
    para("Comment G-4 cannot be answered with what is on the sheet today. Sheet C-9 as drawn is incomplete for "
         "the purposes of responding to comment G-4 on four counts, and it contradicts itself on the fifth:")
    para("(a) Freeboard is asserted in words and is not dimensioned. The basin notes state: “Freeboard between "
         "the 100-year water surface (2,857.91′) and the top of berm (2,859.20′) is 1.29′, meeting the CCRFCD "
         "minimum freeboard requirement of 1.0 foot.” No dimension string on Sheet C-9 dimensions that "
         "freeboard. Section A-A′ and Section B-B′ carry elevation callouts only (basin bottom 2,851.00′, "
         "100-year water surface 2,857.91′, top of berm 2,859.20′) and no dimension between them, so the "
         "reviewer is asked to accept a computed difference as a dimension.", space_after=6)
    para("(b) No calculation in the record sizes the spillway as drawn. Detail — Emergency Spillway "
         "(Weir) gives the crest elevation (2,858.50′), the weir length (20′ along the berm) and the weir width "
         "(6′ in the direction of flow) — and no design head, no discharge–head relation and no capacity. The "
         "only spillway discharge figure in the record is in the accepted study's Table D-2 (41.5 cfs at the "
         "crest), and Sheet C-9 does not carry it. The detail refers to a “design overflow discharge (routing "
         "check under storm exceeding 100-year, 24-hour input)”, but neither the sheet nor the Phase 3 "
         "Hydrology Worksheet contains that storm or that routing: the worksheet evaluates the 100-year 6-hour "
         "storm (2.38 in) and the 100-year 24-hour storm (3.18 in) and nothing above them. The design case the "
         "spillway exists for is therefore not stated and not run anywhere in the record.", space_after=6)
    para("(c) There is no spillway section. Sheet C-9 carries Section A-A′ (longitudinal, east–west, through "
         "the outlet control structure) and Section B-B′ (transverse, north–south, through the basin midpoint). "
         "Neither section cuts the weir: there is no section through the crest, the articulated concrete block "
         "surface, the downstream slope, the apron and the toe. QA/QC Checklist Tab 3 items 27 through 29 "
         "record the weir detail and “Basin outlet swale section” as verified, but those items check presence "
         "and keying — item 27 is recorded as “Detail present; crest elevation matches basin section”, and "
         "Section B-B′ is the basin midpoint section, not a section through the spillway. No check on the "
         "checklist compares the crest height callout on the detail with the basin note.", space_after=6)
    para("(d) The apron is specified in plan only. Sheet C-9 specifies the apron as 15 feet by 20 feet of "
         "grouted rip-rap with a D50 of 12 inches, extending from the weir toe to natural grade beyond the berm "
         "at elevation 2,853.00′. That is the whole of what the record specifies for the apron: it gives no "
         "thickness, no bedding or filter layer under the grouted rip-rap, no cutoff or end treatment at the "
         "toe, and no geotextile under the apron (the geotextile filter fabric named on the sheet is the "
         "bedding under the articulated concrete block weir surface, not under the apron). An apron detailed "
         "only in plan cannot be constructed or checked, and “downstream apron details” is precisely what G-4 "
         "asks for.", space_after=6)
    para("(e) The emergency spillway detail and the basin notes on Sheet C-9 give different values for the "
         "height of the spillway crest above the 100-year water surface. The detail callout reads “Weir crest "
         "elevation 2,858.50′ (0.71′ above 100-year water surface)”; the basin notes read “Emergency spillway "
         "crest set at 2,858.50′, 0.60′ above the 100-year water surface and 0.70′ below the top of berm.” "
         "The sheet's own elevations give neither figure: 2,858.50′ − 2,857.91′ = 0.59 feet. The detail "
         "figure is 0.12 feet high and the basin note is 0.01 feet high, and 0.71 feet appears to be the "
         "0.70 feet from the crest to the top of berm carried into the wrong sentence. Two printed values for "
         "one dimension, neither of them the arithmetic value, is the sheet contradicting itself on exactly "
         "the dimension the comment is about.", space_after=6)
    para("Disposition: G-4 is answered on the resubmittal, not on this sheet. Sheet C-9 must be revised to "
         "include spillway sizing calculations and a spillway section to satisfy comment G-4, together with "
         "the freeboard dimensioning and the apron details set out in Section 5 below. The comment is not one "
         "that can be closed with a note or a cross-reference to a document that does not contain the work.")

    # ---------------------------------------------------------------- 3. what the revised sheet must say
    head("3. Disposition 2 — what the spillway detail and the basin notes must say on the revised C-9, "
         "and the freeboard finding")
    para("The values below are the record's, each with the record it comes from. The last three rows are mine "
         "and are marked as such.")
    rows = [("Quantity", "Value", "Record"),
            ("Emergency spillway weir crest", "2,858.50 ft",
             "C-9 Detail — Emergency Spillway (Weir); C-9 Basin Notes"),
            ("100-year water surface", "2,857.91 ft", "C-9 Sections A-A′ and B-B′; MDS Table D-2"),
            ("Top of berm", "2,859.20 ft", "C-9 Sections A-A′ and B-B′; C-9 Basin Notes"),
            ("Crest height above the 100-year water surface",
             "0.71 ft (detail) / 0.60 ft (basin notes) / 0.59 ft (arithmetic)",
             "C-9 Detail and Basin Notes; C-9 elevations"),
            ("Crest below top of berm", "0.70 ft", "C-9 Basin Notes"),
            ("Freeboard, 100-year water surface to top of berm", "1.29 ft", "C-9 Basin Notes"),
            ("Storage at the 100-year water surface", "6.40 ac-ft", "C-9 Storage Summary; MDS Table D-2"),
            ("Storage at the spillway crest", "7.12 ac-ft", "C-9 Storage Summary; MDS Table D-2"),
            ("Storage at the top of berm", "8.02 ac-ft", "C-9 Storage Summary; MDS Table D-2"),
            ("Outflow at the 100-year water surface", "27.9 cfs", "MDS Table D-2"),
            ("Outflow at the emergency spillway crest", "41.5 cfs", "MDS Table D-2"),
            ("Weir length and width", "20 ft along the berm, 6 ft in the direction of flow", "C-9 Detail"),
            ("Downstream apron", "15 ft by 20 ft grouted rip-rap, D50 = 12 in, toe to grade at 2,853.00 ft",
             "C-9 Detail"),
            ("Phase 3 detention allocation", "6.4 ac-ft", "MDS Table 4-1; CCRFCD letter 02/28/2022"),
            ("Shared outfall cap", "Q100 ≤ 78 cfs", "MDS Section 5; CCRFCD letter 02/28/2022"),
            ("Weir capacity at 0.70 ft of head (screening, mine)", "30.5 cfs",
             "computed: broad-crested weir, L = 20 ft, coefficient 2.6"),
            ("Crest-stage water surface with the outlet structure operating (screening, mine)", "2,858.88 ft",
             "computed: 41.5 cfs less the outlet share, weir head 0.38 ft"),
            ("Freeboard to the top of berm in that condition (screening, mine)", "0.32 ft", "computed")]
    tb = d.add_table(rows=len(rows), cols=3)
    tb.style = "Table Grid"
    tb.autofit = False
    for col, w in zip(tb.columns, (Inches(2.5), Inches(1.7), Inches(2.4))):
        col.width = w
    for row in tb.rows:
        row.cells[0].width = Inches(2.5)
        row.cells[1].width = Inches(1.7)
        row.cells[2].width = Inches(2.4)
    for i, row in enumerate(rows):
        for j, val in enumerate(row):
            cell = tb.rows[i].cells[j]
            cell.text = val
            for p in cell.paragraphs:
                for r in p.runs:
                    r.font.size = Pt(9)
                    r.bold = (i == 0)
    para("", space_after=2)
    para("What the revised basin notes must state — and what the notes as drawn omit — is the accepted study's "
         "outflow at the emergency spillway crest. The revised basin notes on Sheet C-9 give the master "
         "drainage study outflow of 41.5 cubic feet per second (cfs) at the emergency spillway crest, at "
         "elevation 2,858.50 feet with 7.12 acre-feet in storage, against 27.9 cfs at the 100-year water "
         "surface at 2,857.91 feet with 6.40 acre-feet (Master Drainage Study, Table D-2). The C-9 Storage "
         "Summary already closes to Table D-2 on storage at all three elevations (6.40, 7.12 and 8.02 "
         "acre-feet) but it has no outflow column, so the crest-stage discharge appears nowhere on the sheet "
         "and there is no stated capacity for the weir to be checked against. Storage and discharge have to "
         "sit in the same table, against the same elevations, or the reviewer cannot check either.", space_after=6)
    para("The 1.29 foot freeboard reported in the basin notes on Sheet C-9 as currently drawn does not hold "
         "once the emergency spillway operates. The 1.29 feet is the clearance from the routed 100-year water "
         "surface to the top of berm. The crest sits 0.59 feet above that water surface, so the spillway is "
         "designed to engage in events above the routed 100-year event; once it engages the water surface is "
         "at or above 2,858.50 feet, the clearance to the top of berm is 0.70 feet or less, and it falls to "
         "zero at the berm. Measured as the minimum freeboard standard requires — above the design water "
         "surface, and above the spillway design water surface in the condition that governs — the design pool "
         "is only 0.59 feet below the crest, a noncompliant clearance of 0.41 feet against the 1.0 foot "
         "minimum that the basin notes themselves invoke and that the County applied to this project in Phase "
         "2 comment G-3 (“Freeboard shall be a minimum of 1.0 ft above the design HGL and shall be "
         "dimensioned”). The 1.29 foot figure is not wrong as a measurement of the empty-spillway condition; "
         "it is a statement about the only event in which the spillway never runs, and it is offered as "
         "conformance with a standard it does not meet in the event the spillway exists for.", space_after=6)
    para("A screening calculation, mine and not the design, shows what the sizing block has to produce. "
         "Treating the spillway as a broad-crested weir 20 feet long with a coefficient of 2.6 in U.S. "
         "customary units (a deliberately conservative value for a rough articulated-concrete-block surface), "
         "the weir passes 30.5 cfs at the 0.70 feet of head available to the top of berm — 11.0 cfs short of "
         "the 41.5 cfs the accepted study assigns to the crest stage. If the outlet control structure is "
         "operating, the 12 inch by 18 inch orifice plate carries 27.9 cfs at the 100-year water surface and, "
         "scaling with the square root of head, about 29.2 cfs at the crest, so the weir would carry about "
         "12.3 cfs at 0.38 feet of head; the water surface would then sit at about 2,858.88 feet, leaving "
         "0.32 feet to the top of berm — a third of the 1.0 foot standard. If the design case is the outlet "
         "structure blocked, which is the case an emergency spillway is normally sized for, the weir alone "
         "needs 0.86 feet of head to pass 41.5 cfs, putting the water surface at about 2,859.36 feet, 0.16 "
         "feet above the top of berm. The exact figure is not the point: every one of these numbers has to be "
         "computed on the revised sheet, against a stated design case, and the sheet computes none of them. "
         "The illustrative remedies are a longer weir, a lower crest or a higher top of berm; because the "
         "crest elevation and the 41.5 cfs at that elevation are tied together in the accepted study, raising "
         "the top of berm to not less than 1.0 foot above the computed spillway design water surface is the "
         "one that leaves the accepted storage basis untouched.", space_after=6)
    para("One more record error has to be corrected with the same revision: the Phase 3 Storm Drain HGL "
         "worksheet (07/2026) describes its tailwater sensitivity case as 2,858.50 feet, “the highest water "
         "surface the basin can physically hold”. It is not. The basin holds 8.02 acre-feet to the top of berm "
         "at 2,859.20 feet, and the spillway exists precisely so that the water surface may rise above the "
         "crest. The sensitivity case should be run at 2,859.20 feet.")

    # ---------------------------------------------------------------- 4. where the overflow goes
    head("4. Disposition 3 — where the overflow ends up once it leaves the berm, and whether it may go there")
    para("Path of the overflow. Flow passing over the emergency spillway bypasses the outlet control structure that limits "
         "discharge to the shared outfall. The 12 inch by 18 inch orifice plate in the west-end headwall is "
         "the element that holds the site to the 78 cfs shared-outfall cap; spillway flow crosses the east "
         "berm outside it, drops over the 15 foot by 20 foot rip-rap apron to grade at 2,853.00 feet, and — in "
         "the words of the C-9 detail — “flow spreads to downstream open swale in Common-Area Parcel ‘E’ and "
         "exits at Windmill Ln. gutter line.” The emergency spillway overflow therefore discharges across "
         "Common-Area Parcel “E” to the Windmill Lane gutter line, and that discharge is additional to, and "
         "outside, the metered release the 78 cfs cap governs.", space_after=6)
    para("The receiving improvements are accepted County work. The Windmill Lane collector half-improvements — "
         "paving, curb, gutter, sidewalk, striping and signage — are item OS-1 (bonded value $612,000) in the "
         "Clark County Public Works Phase 2 Offsite Acceptance letter dated March 17, 2025. The Windmill Lane "
         "half-improvements receiving the emergency spillway overflow were accepted by Clark County Public "
         "Works as Phase 2 offsite work, with the closed offsite punch list executed by the assigned County "
         "construction inspector on 03/12/2025 (13 items opened, 13 closed, 0 outstanding) and the offsite "
         "subtotal of $1,100,000 accepted against the $3,200,000 Phase 2 performance bond.", space_after=6)
    para("But no document in the record grants a right to discharge the emergency spillway into the Windmill "
         "Lane curb and gutter that Clark County Public Works has accepted. The record was searched for any "
         "easement, licence, permit, agreement or coordination record that would authorise a concentrated "
         "discharge at that point, and there is none:")
    bullet("The Final Map FM-26-100290 checkprint grants a 15 foot drainage easement on the west line of "
           "Common-Area Parcel “D” (the park), a 20 foot dry utility easement in Book 175 Page 60 along the "
           "north boundary, and a 10 foot public utility easement across the fronts of the lots. Nothing on it "
           "runs from Parcel “E” to Windmill Lane.")
    bullet("The recorded Phases 1–2 Final Map (Book 175, Page 60) dedicates streets, public utility, drainage "
           "and sight visibility easements in favour of Clark County within Phases 1 and 2. None of them "
           "establishes a discharge point into the Windmill Lane curb and gutter.")
    bullet("The accepted study provides one discharge point for the 140 acres: the shared outfall at the "
           "southwest corner of the site, through the existing 30 inch RCP stub (invert 2,850.75 feet per the "
           "Phase 2 as-builts), under the 78 cfs allowance. The spillway discharge at the Windmill Lane gutter "
           "line is a second, different discharge point that the accepted study does not describe.")
    bullet("The Conditions of Approval TM-22-500041 require drainage easements to be granted by the recorded "
           "final map for the phase in which the affected area lies; they do not grant a discharge right at "
           "Windmill Lane, and the Phase 3 final map has not been recorded.")
    bullet("The Preliminary Title Report SBT-2026-04188 Schedule B lists no easement or right in favour of "
           "Clark County for drainage discharge at Windmill Lane.")
    bullet("The Phase 2 acceptance letter is an acceptance of constructed work under Chapter 30.32 and "
           "Article VI of the Subdivision Improvement Agreement. It expressly limits itself to the offsite "
           "component of the Work and states that nothing in it shall be construed to accept, waive or "
           "otherwise address any portion of the Work not enumerated. Accepting the curb and gutter as "
           "constructed is not an authorisation to discharge into it.")
    bullet("There is no encroachment permit, drainage discharge authorisation, licence or coordination record "
           "with Clark County Public Works for a concentrated discharge at this location anywhere in the "
           "project file.")
    para("Disposition: the overflow path as drawn is not authorised, and the G-4 response must not present the "
         "Windmill Lane gutter line as the outlet of record. The single disposition I recommend is to obtain a "
         "written drainage discharge authorisation from Clark County Public Works for this discharge point — "
         "together with whatever easement or right the County requires over the flow path across Parcel “E” — "
         "and to carry that authorisation in the resubmittal as the support for the discharge point shown on "
         "the revised C-9. If the County will not authorise a concentrated discharge at the gutter line, the "
         "overflow path must be redesigned before G-4 can close; the detention design itself is unaffected "
         "either way.", space_after=6)
    para("Note that the volume at stake is not the design release. The spillway only runs in events above the "
         "routed 100-year event, so the discharge is an emergency overflow, not a routine release; but it is "
         "precisely because it is uncontrolled and outside the metered outlet that the discharge point has to "
         "be authorised rather than assumed.")

    # ---------------------------------------------------------------- 5. amendment
    head("5. Disposition 4 — the proposed spillway revisions do not trigger a formal amendment to the accepted "
         "master drainage study")
    para("The CCRFCD acceptance letter dated February 28, 2022 sets out what requires a formal amendment: "
         "changes to the accepted detention allocations, the outfall allowance, or the tributary area "
         "assumptions, including without limitation any proposed revision of phase tributary area, impervious "
         "cover assumption, hydrologic methodology, storage-indication input, phase boundary, detention basin "
         "location, or shared outfall discharge cap. The Master Drainage Study states the same rule in Sections "
         "4.4 and 7.3.")
    para("The proposed spillway revisions do not trigger a formal amendment to the accepted master drainage "
         "study, because they change none of those things. The Phase 3 allocation stays at 6.4 acre-feet; the "
         "100-year water surface stays at 2,857.91 feet with 6.40 acre-feet of storage; the tributary area "
         "stays at 40.0 acres at 42 percent impervious; the basin stays in Common-Area Parcel “E”; the "
         "storage-indication input is unchanged — the 41.5 cfs at the crest is already in the accepted study's "
         "Table D-2, so the revision carries the accepted rating onto the sheet rather than introducing a new "
         "one; and the shared outfall cap stays at Q100 ≤ 78 cfs. What the resubmittal adds is freeboard "
         "dimensioning, sizing calculations, a section and apron details. Those are calculations and details "
         "of a structure whose governing elevations the District has already accepted, not a departure from "
         "the accepted allocation or allowance. No amendment is required and no District re-review is "
         "triggered before construction plan approval.", space_after=6)
    para("One internal file must not travel with the resubmittal. The Preliminary Detention Calculation dated "
         "09/25/2026 (marked PRELIMINARY — internal working file) assumes 65 percent impervious cover and a "
         "2.42 inch six-hour depth and derives 8.1 acre-feet of required storage. Neither input is the "
         "accepted basis (42 percent impervious, 2.38 inches), and that file is not the basis of the plans: "
         "the Phase 3 Hydrology Worksheet (07/2026) and Sheet C-9 both carry the accepted basis. It should be "
         "reconciled or withdrawn so that it cannot be mistaken for the design basis of record.")

    # ---------------------------------------------------------------- 6. action list
    head("6. Action list for the 11/30/2026 resubmittal")
    acts = [
        "C-9, Detail — Emergency Spillway (Weir): correct “0.71′ above 100-year water surface” to 0.59 ft "
        "(2,858.50 − 2,857.91).",
        "C-9, Basin Notes: correct “0.60′ above the 100-year water surface” to 0.59 ft, and restate the "
        "freeboard statement in the governing condition (spillway operating), not against the routed "
        "100-year pool alone.",
        "C-9, Section A-A′: add the freeboard dimension strings — 0.59 ft (100-year water surface to crest), "
        "0.70 ft (crest to top of berm) and 1.29 ft (100-year water surface to top of berm).",
        "C-9: add the spillway sizing calculation block — weir rating (crest 2,858.50 ft, L = 20 ft, "
        "W = 6 ft, design head, coefficient and its source), outlet control rating, and a stage–storage–"
        "discharge table reconciled to Table D-2 (6.40 ac-ft / 27.9 cfs at 2,857.91 ft; 7.12 ac-ft / "
        "41.5 cfs at 2,858.50 ft; 8.02 ac-ft at 2,859.20 ft).",
        "C-9: state and route the design overflow event. The detail calls for a routing check under a storm "
        "exceeding the 100-year, 24-hour input; that storm, its depth and its routing belong on the sheet or "
        "in a worksheet referenced by it.",
        "C-9: add a section through the spillway — crest, articulated concrete block surface, cutoff, "
        "downstream slope, apron and toe at 2,853.00 ft.",
        "C-9: add the apron details — thickness, bedding, filter/geotextile, cutoff or end treatment at the "
        "toe, and the sizing basis for the D50 = 12 in stone — consistent with the RFCD Hydrologic Criteria "
        "and Drainage Design Manual.",
        "C-9, Basin Notes: carry the accepted study's crest-stage outflow (41.5 cfs at 2,858.50 ft) in the "
        "basin summary, so storage and discharge are read against the same elevations.",
        "C-9, Basin Notes: provide the 1.0 ft minimum freeboard by calculation — on the screening values in "
        "Section 3, raise the top of berm to not less than 1.0 ft above the computed spillway design water "
        "surface (about 2,859.9 ft) with the crest held at 2,858.50 ft.",
        "Correspondence: request written authorisation from Clark County Public Works for the discharge point "
        "at the Windmill Lane gutter line, and carry the authorisation in the G-4 response; until it is in "
        "hand, do not show the gutter line as the outlet of record.",
        "Storm Drain HGL worksheet: correct the tailwater sensitivity note — the highest water surface the "
        "basin can physically hold is the top of berm at 2,859.20 ft, not the spillway crest — and re-run the "
        "sensitivity at 2,859.20 ft.",
        "QA/QC: re-check Tab 3 items 27 through 29 against the revised sheet, including the dimension values "
        "and not only the presence of the detail and sections.",
        "Internal: reconcile or withdraw DSR_Ph3_Detention_Calc_prelim.xlsx (65 percent impervious, "
        "2.42 in) against the accepted basis.",
    ]
    for i, a in enumerate(acts, 1):
        p = d.add_paragraph(f"{i}. {a}")
        p.paragraph_format.space_after = Pt(2)

    # ---------------------------------------------------------------- 7. closing
    head("7. Conclusion")
    para("Sheet C-9 as drawn is incomplete for the purposes of responding to comment G-4: the freeboard is "
         "not dimensioned, the sizing calculations do not exist, the spillway section is absent, the apron is "
         "detailed in plan only, and the sheet states the crest height above the 100-year water surface as two "
         "different values, neither of which is the arithmetic difference of its own elevations. The 1.29 foot "
         "freeboard does not hold once the spillway operates: the crest is 0.59 feet above the design pool, so "
         "the clearance to the top of berm is 0.70 feet at the crest and falls to zero at the berm, against a "
         "1.0 foot minimum. The overflow leaves the berm outside the outlet control structure and crosses "
         "Common-Area Parcel “E” to the Windmill Lane gutter line — improvements the County has accepted as "
         "Phase 2 offsite work, but a discharge point for which no document in the record grants a right. The "
         "revisions needed to answer G-4 are calculations and details of an already-accepted basin: they do "
         "not trigger a formal amendment to the accepted master drainage study.")
    para("Nothing in this memorandum alters the accepted Master Drainage Study, the 6.4 acre-foot Phase 3 "
         "allocation, the 100-year water surface at 2,857.91 feet, the basin location in Common-Area Parcel "
         "“E”, or the Q100 ≤ 78 cfs cap at the shared outfall.", space_after=10)

    para("Respectfully submitted,")
    para("SUNDIAL ENGINEERING & SURVEY", bold=True)
    para("")
    para("_________________________________________          Date: October 31, 2026")
    para("Max Braddock, Project Manager")
    para("(702) 555-0144  |  mbraddock@sundialensv.com")
    para("")
    para("Reviewed: ____________________________________")
    para("Jonathan R. Kessler, PE — Principal-in-Charge, Nevada PE No. 14203")

    OUT.mkdir(parents=True, exist_ok=True)
    path = OUT / NAME
    d.save(str(path))
    return path


if __name__ == "__main__":
    p = build()
    print(f"wrote {p} ({p.stat().st_size} bytes)")
