import os, sys, json
from pathlib import Path
import fitz, openpyxl, docx, email, email.policy

ROOT = Path('/work/ple-dataset/tasks/emergency-spillway-check/environment/files')
OUT = Path('/work/ple-solve/emergency-spillway-check/corpus')
OUT.mkdir(parents=True, exist_ok=True)

def pdf_text(p):
    d = fitz.open(p)
    parts = []
    for i, page in enumerate(d):
        parts.append(f"\n===== PAGE {i+1} =====\n" + page.get_text("text"))
    return "".join(parts)

def xlsx_text(p):
    wb = openpyxl.load_workbook(p, data_only=True)
    parts = []
    for ws in wb.worksheets:
        parts.append(f"\n===== SHEET {ws.title} ({ws.max_row}x{ws.max_column}) =====")
        for row in ws.iter_rows(values_only=True):
            if row is None: continue
            cells = ["" if c is None else str(c) for c in row]
            if not any(c.strip() for c in cells): continue
            parts.append(" | ".join(cells))
    return "".join(parts)

def docx_text(p):
    d = docx.Document(p)
    parts = []
    for para in d.paragraphs:
        if para.text.strip(): parts.append(para.text)
    for ti, t in enumerate(d.tables):
        parts.append(f"\n--- TABLE {ti+1} ---")
        for r in t.rows:
            parts.append(" | ".join(c.text.strip() for c in r.cells))
    return "\n".join(parts)

def eml_text(p):
    msg = email.message_from_bytes(p.read_bytes(), policy=email.policy.default)
    parts = [f"From: {msg.get('From')}", f"To: {msg.get('To')}", f"Date: {msg.get('Date')}",
             f"Subject: {msg.get('Subject')}", ""]
    for part in msg.walk():
        if part.get_content_type() == 'text/plain':
            try:
                parts.append(part.get_content())
            except Exception as e:
                parts.append(f"[decode failed {e}]")
    return "\n".join(parts)

manifest = []
for p in sorted(ROOT.rglob('*')):
    if not p.is_file(): continue
    rel = p.relative_to(ROOT)
    ext = p.suffix.lower()
    try:
        if ext == '.pdf': t = pdf_text(p)
        elif ext in ('.xlsx','.xlsm'): t = xlsx_text(p)
        elif ext == '.docx': t = docx_text(p)
        elif ext == '.eml': t = eml_text(p)
        elif ext in ('.txt','.csv','.md'): t = p.read_text(errors='replace')
        else:
            t = None
    except Exception as e:
        t = f"!! EXTRACT FAILED: {e}"
    name = str(rel).replace('/', '__') + '.txt'
    if t is None:
        manifest.append((str(rel), 'SKIP', 0)); continue
    (OUT/name).write_text(t, encoding='utf-8')
    manifest.append((str(rel), 'ok', len(t)))

for m in manifest: print(m)
print('FILES EXTRACTED:', sum(1 for m in manifest if m[1]=='ok'), 'skipped', sum(1 for m in manifest if m[1]=='SKIP'))
