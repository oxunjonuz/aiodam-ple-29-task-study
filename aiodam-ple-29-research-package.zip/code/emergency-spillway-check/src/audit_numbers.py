#!/usr/bin/env python3
"""Second mechanism, not a phrase reader: every numeric token in the memorandum must be (a) present in the
project corpus, (b) an identifier (date, phone, licence, job, dollar amount already in the record), or
(c) one of my own screening values declared here with its derivation. Anything else is UNEXPLAINED and is
reported.

    python3 audit_numbers.py <memo.docx> [--corpus DIR]

Exit 0 when nothing is unexplained.
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

CORPUS = Path("/work/ple-solve/emergency-spillway-check/corpus")

# my own numbers, each with the arithmetic that produces it (none of these is a record value)
COMPUTED = {
    "0.59": "2,858.50 - 2,857.91",
    "0.70": "2,859.20 - 2,858.50 (also printed in the C-9 basin notes)",
    "1.29": "2,859.20 - 2,857.91 (also printed in the C-9 basin notes)",
    "0.12": "0.71 - 0.59",
    "0.01": "0.60 - 0.59",
    "0.41": "1.00 - 0.59",
    "30.5": "2.6 x 20 x 0.70^1.5 = 30.45 cfs",
    "11.0": "41.5 - 30.5",
    "29.2": "27.9 x sqrt(7.00/6.41)",
    "12.3": "41.5 - 29.2",
    "0.38": "(12.3/(2.6 x 20))^(2/3)",
    "2858.88": "2,858.50 + 0.38",
    "0.32": "2,859.20 - 2,858.88",
    "0.86": "(41.5/(2.6 x 20))^(2/3)",
    "2859.36": "2,858.50 + 0.86",
    "0.16": "2,859.36 - 2,859.20",
    "2859.9": "2,858.88 + 1.0, rounded up to the next tenth",
    "41.5": "MDS Table D-2 (record value; listed because it drives the screening sums)",
    "2.6": "broad-crested weir coefficient, U.S. customary units (assumption, stated in the memo)",
    "20": "weir length, C-9 detail",
    "0.70": "head available to the top of berm",
}

IDENT = [
    r"10/31/2026", r"555-\d{4}", r"89103", r"89148", r"177-27-201-001", r"C-3874", r"14203",
    r"2201-03", r"IP-26-100288", r"FM-26-100290", r"TM-22-500041", r"SBT-2026-04188",
    r"Book 175", r"Page 60", r"NFM-24-0118", r"30\.32", r"G-[1-8]", r"D-[12]", r"OS-[1-5]",
    r"2,851\.00", r"2,853\.00", r"2,857\.91", r"2,858\.50", r"2,859\.20",
]


def norm_num(s: str) -> str:
    s = s.strip().rstrip(".,;:")
    return s.replace(",", "") if re.fullmatch(r"\d[\d,]*", s) else s.replace(",", "")


def corpus_numbers(root: Path) -> tuple[set[str], set[str]]:
    """Every numeric token in the corpus, in both plain and comma-stripped form, and the raw text per file."""
    plain, stripped = set(), set()
    for p in sorted(root.glob("*.txt")):
        text = p.read_text(encoding="utf-8", errors="replace")
        for m in re.finditer(r"\d[\d,]*(?:\.\d+)?", text):
            tok = m.group(0)
            plain.add(tok)
            stripped.add(tok.replace(",", ""))
    return plain, stripped


def memo_text(path: Path) -> str:
    import docx

    d = docx.Document(str(path))
    parts = [p.text for p in d.paragraphs]
    for t in d.tables:
        for row in t.rows:
            parts.append(" | ".join(c.text for c in row.cells))
    return "\n".join(parts)


def record_side(corpus_dir: Path) -> int:
    """The record itself, not the memorandum: does each value sit where the memorandum says it does?"""
    plans = (corpus_dir / "Design-Drafting__Phase 3__DSR_Ph3_Improvement_Plans_C1-C9.pdf.txt").read_text()
    mds = (corpus_dir / "Reports-Studies__DSR_Master_Drainage_Study.pdf.txt").read_text()
    acc = (corpus_dir / "Correspondence__Agency__CC-FCD_Ph2_Acceptance_032025.pdf.txt").read_text() \
        if (corpus_dir / "Correspondence__Agency__CC-FCD_Ph2_Acceptance_032025.pdf.txt").exists() else ""
    acc = (corpus_dir / "Correspondence__Agency__CC-PW_Ph2_Acceptance_032025.pdf.txt").read_text()
    fcd = (corpus_dir / "Correspondence__Agency__FCD_MDS_Acceptance_Letter.pdf.txt").read_text()
    page = {i: p for i, p in enumerate(re.split(r"===== PAGE \d+ =====", plans))}
    checks = [
        ("C-9 detail: 0.71 ft above the 100-year water surface", "0.71′ above 100-year water surface" in page[17]),
        ("C-9 basin notes: 0.60 ft above the 100-year water surface 2,858.50",
         "0.60′ above the 100-year water surface" in page[18] and "2,858.50" in page[18]),
        ("C-9 basin notes: 1.29 ft freeboard, top of berm 2,859.20", "1.29" in page[18] and "2,859.20" in page[18]),
        ("C-9 detail: apron 15 x 20 grouted rip-rap D50 12 in", "15′ × 20′ grouted rip-rap, D50 = 12″" in page[17]),
        ("C-9 detail: overflow exits at the Windmill Ln. gutter line", "Windmill Ln. gutter line" in page[17]),
        ("C-9 detail: weir 20 ft long, 6 ft wide, crest 2,858.50", "Weir length: 20′" in page[17] and "2,858.50′" in page[17]),
        ("C-9 storage summary: 6.40 / 7.12 / 8.02 ac-ft at 2,857.91 / 2,858.50 / 2,859.20",
         all(k in page[16] for k in ("6.40", "7.12", "8.02"))),
        ("MDS Table D-2: 41.5 cfs at 2,858.50 with 7.12 ac-ft", "41.5" in mds and "2,858.50" in mds and "7.12" in mds),
        ("MDS Table D-2: 27.9 cfs at 2,857.91 with 6.40 ac-ft", "27.9" in mds and "2,857.91" in mds),
        ("MDS Table 4-1: Phase 3 allocation 6.4 ac-ft",
         "Phase\n3\n40.0\n42\n6.4" in mds or "6.4" in mds),
        ("CCRFCD letter: amendment triggers named", "formal amendment" in fcd and "storage-indication" in fcd),
        ("CCPW Phase 2 acceptance: OS-1 Windmill Ln. half-improvements accepted, punch list closed",
         "OS-1" in acc and "Accepted" in acc and "Punch List" in acc and "Windmill Ln." in acc),
    ]
    bad = 0
    for name, ok in checks:
        print(f"{'PASS' if ok else 'FAIL'}  {name}")
        bad += 0 if ok else 1
    print(f"\nrecord-side: {len(checks) - bad}/{len(checks)}")
    return 0 if bad == 0 else 1


def main(argv: list[str]) -> int:
    if len(argv) >= 2 and argv[1] == "record":
        corpus_dir = Path(argv[argv.index("--corpus") + 1]) if "--corpus" in argv else CORPUS
        return record_side(corpus_dir)
    if len(argv) < 2:
        print(__doc__)
        return 2
    path = Path(argv[1])
    corpus_dir = Path(argv[argv.index("--corpus") + 1]) if "--corpus" in argv else CORPUS
    plain, stripped = corpus_numbers(corpus_dir)
    text = memo_text(path)

    rows, unexplained = [], []
    for m in re.finditer(r"\d[\d,]*(?:\.\d+)?", text):
        tok = m.group(0)
        val = tok.replace(",", "")
        lo = max(0, m.start() - 45)
        ctx = re.sub(r"\s+", " ", text[lo:m.end() + 35]).strip()
        if tok in plain or val in stripped:
            rows.append(("IN RECORD", tok, ctx)); continue
        if val in COMPUTED:
            rows.append(("COMPUTED", tok, COMPUTED[val])); continue
        if any(re.search(p, tok) or re.search(p, ctx) for p in IDENT):
            rows.append(("IDENTIFIER", tok, ctx)); continue
        # a rounded/derived variant of a record value (e.g. 2,851.0 for 2,851.00)
        if any(val == c for c in (t.replace(",", "") for t in plain)):
            rows.append(("IN RECORD", tok, ctx)); continue
        unexplained.append((tok, ctx))

    counts = {}
    for kind, _, _ in rows:
        counts[kind] = counts.get(kind, 0) + 1
    print(f"numeric tokens: {sum(counts.values())}  " + "  ".join(f"{k}={v}" for k, v in sorted(counts.items())))
    for kind in ("COMPUTED", "IDENTIFIER"):
        for k, tok, note in rows:
            if k == kind:
                print(f"  {kind:10} {tok:>12}  {note[:80]}")
    if unexplained:
        print(f"\nUNEXPLAINED: {len(unexplained)}")
        for tok, ctx in unexplained:
            print(f"  {tok:>12}   ...{ctx[:140]}...")
        return 1
    print("\nUNEXPLAINED: 0")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
