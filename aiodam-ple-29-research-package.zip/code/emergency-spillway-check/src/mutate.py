#!/usr/bin/env python3
"""Mutation campaign on the delivered .docx.

Each mutant breaks ONE thing the rubric or my closure checks read, everywhere it is stated in the
memorandum (a fact stated twice is only broken when both statements are broken — otherwise the mutant is
testing redundancy, not the checks). A mutant counts as CAUGHT only when checks.py returns a non-empty
failure list; a crash or a technical failure (exit 2) is never a catch.

    python3 mutate.py <memo.docx> [--out DIR]
"""
from __future__ import annotations

import json
import re
import subprocess
import sys
from pathlib import Path

import docx

HERE = Path(__file__).resolve().parent
CHECKS = HERE / "checks.py"

# (name, [(pattern, replacement), ...]) — every pattern is applied with re.sub over every paragraph and cell
MUTATIONS = [
    ("M01_crest_outflow_37.5", [(r"41\.5", "37.5")]),
    ("M02_detail_0.71_to_0.70", [(r"0\.71", "0.70")]),
    ("M03_notes_0.60_to_0.59", [(r"0\.60", "0.59")]),
    ("M04_freeboard_conforms", [
        (r"The 1\.29 foot freeboard reported in the basin notes on Sheet C-9 as currently drawn does not hold "
         r"once the emergency spillway operates\.",
         "The 1.29 foot freeboard reported in the basin notes on Sheet C-9 meets the 1.0 foot minimum and conforms."),
        (r"does not hold once the emergency spillway operates", "holds once the emergency spillway operates"),
        (r"a noncompliant clearance of 0\.41 feet", "a compliant clearance of 0.41 feet"),
        (r"a standard it does not meet", "a standard it meets")]),
    ("M06_apron_12x20", [(r"15 feet by 20 feet", "12 feet by 20 feet"), (r"15 ft by 20 ft", "12 ft by 20 ft")]),
    ("M07_apron_d50_18", [(r"D50 of 12 inches", "D50 of 18 inches"), (r"D50 = 12 in", "D50 = 18 in")]),
    ("M08_discharge_right_asserted", [
        (r"But no document in the record grants a right to discharge the emergency spillway into the Windmill "
         r"Lane curb and gutter that Clark County Public Works has accepted\.",
         "The record grants a right to discharge the emergency spillway into the Windmill Lane curb and gutter "
         "that Clark County Public Works has accepted."),
        (r"there is none", "each of them does"),
        (r"lists no easement or right in favour of Clark County", "lists an easement and right in favour of Clark County"),
        (r"None of them establishes a discharge point", "Each of them establishes a discharge point"),
        (r"they do not grant a discharge right at Windmill Lane", "they grant a discharge right at Windmill Lane"),
        (r"Nothing on it runs from Parcel .E. to Windmill Lane", "It runs from Parcel E to Windmill Lane"),
        (r"There is no encroachment permit", "The encroachment permit is in the file:"),
        (r"the overflow path as drawn is not authorised", "the overflow path as drawn is authorised"),
        (r"but a discharge point for which no document in the record grants a right",
         "and a discharge point for which the record grants a right")]),
    ("M09_amendment_required", [
        (r"(?i)do not trigger a formal amendment", "do trigger a formal amendment"),
        (r"change none of those things", "change the accepted basis"),
        (r"No amendment is required and no District re-review is triggered",
         "A formal amendment is required and District re-review is triggered")]),
    ("M10_phase2_accepted_stripped", [
        (r"were accepted by Clark County Public Works as Phase 2 offsite work", "are shown on the Phase 1-2 final map"),
        (r"The receiving improvements are accepted County work", "The receiving improvements are as-built County work"),
        (r"Phase 2 Offsite Acceptance letter", "Phase 2 closeout correspondence"),
        (r"accepted against the \$3,200,000", "bonded against the $3,200,000"),
        (r"improvements the County has accepted as Phase 2 offsite work",
         "improvements the County has constructed under the Phase 2 contract")]),
    ("M11_wrong_date", [(r"October 31, 2026", "November 1, 2026"), (r"10/31/2026", "11/01/2026")]),
    ("M12_wrong_recipient", [(r"Mr\. Garrett Nokes, Vice President, Land Development — Callaway Land Partners, LLC",
                              "Mr. Dale Yeoman, PE — Clark County Public Works")]),
    ("M13_no_signature", [(r"Max Braddock, Project Manager", "The Project Manager")]),
    ("M14_through_outlet", [(r"bypasses the outlet control structure", "passes through the outlet control structure"),
                            (r"additional to, and outside, the metered release", "part of the metered release")]),
    ("M15_parcel_d", [(r"Common-Area Parcel .E.", "Common-Area Parcel D"),
                      (r"Common-Area Parcel .E. and exits", "Common-Area Parcel D and exits")]),
    ("M16_no_section_required", [
        (r"Sheet C-9 must be revised to include spillway sizing calculations and a spillway section to satisfy "
         r"comment G-4",
         "Sheet C-9 may be supported by a note referring the reviewer to the master drainage study to satisfy "
         "comment G-4"),
        (r"\d+\. C-9: add the spillway sizing calculation block[^\n]*", ""),
        (r"\d+\. C-9: add a section through the spillway[^\n]*", ""),
        (r"Sheet C-9 as drawn is incomplete for the purposes[^\n]*", "Sheet C-9 as drawn is substantially complete for the purposes of responding to comment G-4.")]),
    ("M17_wsel_2857.88", [(r"2,857\.91", "2,857.88")]),
    ("M18_apron_thickness_invented", [
        (r"it gives no thickness, no bedding or filter layer under the grouted rip-rap",
         "it gives a 12-inch thickness with 6-inch bedding under the grouted rip-rap")]),
    ("M19_storage_7.20", [(r"7\.12", "7.20")]),
    ("M20_outflow_29.7", [(r"27\.9 cfs", "29.7 cfs")]),
    ("M21_crest_2858.60", [(r"2,858\.50", "2,858.60")]),
]


def rewrite(path_in: Path, path_out: Path, pairs: list[tuple[str, str]]) -> int:
    d = docx.Document(str(path_in))
    hits = 0

    def apply(par):
        nonlocal hits
        text = par.text
        new = text
        for pat, rep in pairs:
            new, n = re.subn(pat, rep, new)
            hits += n
        if new != text:
            if par.runs:
                par.runs[0].text = new
                for r in par.runs[1:]:
                    r.text = ""
            else:
                par.add_run(new)

    for p in d.paragraphs:
        apply(p)
    for t in d.tables:
        for row in t.rows:
            for cell in row.cells:
                for p in cell.paragraphs:
                    apply(p)
    d.save(str(path_out))
    return hits


def main(argv: list[str]) -> int:
    if len(argv) < 2:
        print(__doc__)
        return 2
    src = Path(argv[1])
    out = Path(argv[argv.index("--out") + 1]) if "--out" in argv else HERE.parent / "mut"
    out.mkdir(parents=True, exist_ok=True)

    base = subprocess.run([sys.executable, str(CHECKS), "json", str(src)], capture_output=True, text=True)
    if base.returncode != 0 or not base.stdout.strip():
        print(f"BASELINE NOT GREEN (exit {base.returncode}) — refusing to run: {base.stderr[:300]}")
        return 2
    b = json.loads(base.stdout)
    print(f"baseline: {b['passed']}/{b['total']} checks pass\n")

    survived, caught, broken = 0, 0, 0
    for name, pairs in MUTATIONS:
        dst = out / f"{name}.docx"
        hits = rewrite(src, dst, pairs)
        if not hits:
            print(f"{name:32} NOT APPLIED — the text to mutate was not found")
            broken += 1
            continue
        r = subprocess.run([sys.executable, str(CHECKS), "json", str(dst)], capture_output=True, text=True)
        if r.returncode == 2 or not r.stdout.strip():
            print(f"{name:32} TECHNICAL FAILURE (exit {r.returncode}) — not a catch: {r.stderr[:140]}")
            broken += 1
            continue
        result = json.loads(r.stdout)
        if result["failures"]:
            caught += 1
            print(f"{name:32} CAUGHT   [{hits} edit(s)] red: {', '.join(f.split()[0] for f in result['failures'])}")
        else:
            survived += 1
            print(f"{name:32} SURVIVED [{hits} edit(s)] — no check noticed")
    print(f"\ncaught {caught}/{len(MUTATIONS)}; survived {survived}; not applied or broken {broken}")
    return 0 if caught == len(MUTATIONS) else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv))
