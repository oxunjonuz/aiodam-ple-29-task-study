#!/usr/bin/env python3
"""Every number in the memorandum that is not a direct quotation is recomputed here from the record texts.

Reads: the C-9 pages of the improvement plans, and Table D-2 of the accepted master drainage study.
Writes: the derived quantities, and whether the memorandum's own statements agree to 0.01.
"""
from __future__ import annotations

import json
import math
import re
from pathlib import Path

CORPUS = Path("/work/ple-solve/emergency-spillway-check/corpus")
PLANS = CORPUS / "Design-Drafting__Phase 3__DSR_Ph3_Improvement_Plans_C1-C9.pdf.txt"
MDS = CORPUS / "Reports-Studies__DSR_Master_Drainage_Study.pdf.txt"


def pages(path: Path) -> dict[int, str]:
    return {i: p for i, p in enumerate(re.split(r"===== PAGE \d+ =====", path.read_text(encoding="utf-8")))}


def c9_storage(p16: str) -> dict[float, float]:
    """C-9 Storage Summary: elevation -> cumulative storage (ac-ft). The text layer puts every cell on its own
    line, so a row is elevation, area, incremental, cumulative."""
    out = {}
    for m in re.finditer(r"2,(\d{3})\.\s*\n\s*(\d{2})\s*\n(?:\s*\([^)]*\)[^\n]*\n)*\s*([\d,]+)\s*\n"
                         r"\s*([\d.]+|—)\s*\n\s*([\d.]+)[^\n]*\n", p16):
        out[float(f"2{m.group(1)}.{m.group(2)}")] = float(m.group(5))
    return out


def table_d2(mds: str) -> dict[float, tuple[float, float | None]]:
    """MDS Table D-2: elevation -> (storage ac-ft, outflow cfs), cells one per line."""
    out = {}
    block = mds[mds.index("D-2. Phase 3 Basin"):mds.index("Design tailwater at the Phase 3")]
    for m in re.finditer(r"(2,\d{3}\.\d{2})\s*\n\s*([\d.]+)\s*\n\s*([\d.]+|—)\s*\n", block):
        out[float(m.group(1).replace(",", ""))] = (
            float(m.group(2)), None if m.group(3) == "—" else float(m.group(3)))
    return out


def main() -> int:
    pg = pages(PLANS)
    st = c9_storage(pg[16])
    # the three rows whose elevation cell is split mid-number by the sheet's own line breaks are read by label
    p16 = pg[16]
    for elev, label, want in ((2857.91, r"\(100-yr\s*\n\s*WSEL\)", r"6\.40"),
                              (2858.50, r"spil\s*\n?\s*lway\s*\n?\s*crest\)", r"7\.12"),
                              (2859.20, r"top\s*\n\s*of\s*\n\s*berm\)", r"8\.02")):
        m = re.search(label + r"[\s\S]{0,400}?" + want, p16)
        if m:
            st[elev] = float(want.replace("\\", ""))
        else:
            print(f"  label {label!r} not found next to {want}")
    d2 = table_d2(MDS.read_text(encoding="utf-8"))
    with open(Path(__file__).with_name("compute.json"), "w", encoding="utf-8") as fh:
        json.dump({"c9_storage": st, "table_d2": d2}, fh, indent=1, default=str)

    wsel, crest, berm = 2857.91, 2858.50, 2859.20
    print(f"C-9 storage summary parsed: {len(st)} elevations -> {st}")
    print(f"MDS Table D-2 parsed:       {len(d2)} elevations -> {d2}")
    checks = []

    def chk(name, got, want, tol=0.005):
        ok = abs(got - want) <= tol
        checks.append((name, got, want, ok))
        print(f"  {'PASS' if ok else 'FAIL'}  {name}: {got:.4f} (memorandum says {want})")

    chk("crest above the 100-year water surface", round(crest - wsel, 2), 0.59)
    chk("crest below the top of berm", round(berm - crest, 2), 0.70)
    chk("freeboard, 100-year water surface to top of berm", round(berm - wsel, 2), 1.29)
    chk("detail callout error (0.71 - 0.59)", round(0.71 - (crest - wsel), 2), 0.12)
    chk("basin note error (0.60 - 0.59)", round(0.60 - (crest - wsel), 2), 0.01)
    chk("noncompliant clearance against 1.0 ft (1.0 - 0.59)", round(1.0 - (crest - wsel), 2), 0.41)

    stor_wsel, q_wsel = d2[wsel]
    stor_crest, q_crest = d2[crest]
    stor_berm, _ = d2[berm]
    chk("Table D-2 storage at the 100-yr water surface", stor_wsel, 6.40)
    chk("Table D-2 storage at the crest", stor_crest, 7.12)
    chk("Table D-2 storage at the top of berm", stor_berm, 8.02)
    chk("Table D-2 outflow at the 100-yr water surface", q_wsel, 27.9, 0.05)
    chk("Table D-2 outflow at the crest", q_crest, 41.5, 0.05)
    for elev, cum in ((wsel, 6.40), (crest, 7.12), (berm, 8.02)):
        if abs(st.get(elev, -1) - cum) > 0.005:
            print(f"  FAIL  C-9 storage summary disagrees with Table D-2 at {elev}: {st.get(elev)} vs {cum}")

    # the screening calculation, from the geometry on the sheet
    L, cw = 20.0, 2.6
    h_berm = berm - crest
    q_weir_at_berm = cw * L * h_berm ** 1.5
    chk("weir capacity at 0.70 ft of head", q_weir_at_berm, 30.5, 0.05)
    chk("weir capacity shortfall against 41.5 cfs", round(q_crest - q_weir_at_berm, 1), 11.0, 0.05)

    # outlet share, scaling the Table D-2 rating with the square root of head over the orifice centre (2,851.50)
    q_out_crest = q_wsel * math.sqrt((crest - 2851.50) / (wsel - 2851.50))
    chk("outlet structure discharge at the crest (sqrt-head scaling)", q_out_crest, 29.2, 0.05)
    q_weir_share = q_crest - q_out_crest
    chk("weir share of the crest-stage outflow", q_weir_share, 12.3, 0.05)
    h = (q_weir_share / (cw * L)) ** (2 / 3)
    chk("head over the crest for that share", h, 0.38, 0.005)
    chk("crest-stage water surface", round(crest + h, 2), 2858.88, 0.005)
    chk("freeboard to the top of berm in that condition", round(berm - (crest + h), 2), 0.32, 0.005)

    h_blocked = (q_crest / (cw * L)) ** (2 / 3)
    chk("head the weir alone needs for 41.5 cfs", h_blocked, 0.86, 0.005)
    chk("water surface with the outlet blocked", round(crest + h_blocked, 2), 2859.36, 0.005)
    chk("overtopping depth in that case", round(crest + h_blocked - berm, 2), 0.16, 0.005)

    bad = [c for c in checks if not c[3]]
    print(f"\n{len(checks) - len(bad)}/{len(checks)} derived quantities agree with the memorandum; "
          f"failed: {[c[0] for c in bad] or 'none'}")
    return 0 if not bad else 1


if __name__ == "__main__":
    raise SystemExit(main())
