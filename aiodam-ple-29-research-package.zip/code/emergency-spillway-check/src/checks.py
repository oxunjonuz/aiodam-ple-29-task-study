#!/usr/bin/env python3
"""Criteria of emergency-spillway-check as code, written BEFORE the memorandum text.

The 15 rubric criteria are read off the delivered .docx text (paragraphs, in order, and every
table cell), plus five closure checks of my own that the rubric does not make: the arithmetic of
the elevations quoted in the memorandum, the storage/discharge closure against Table D-2, and two
negative checks (no apron thickness asserted as a record value; the 1.29 ft figure not restated as
conforming).

    python3 checks.py read  <memo.docx>   -> PASS/FAIL per criterion + evidence
    python3 checks.py json  <memo.docx>   -> machine-readable result (used by mutate.py)

Exit 0 when every check passes, 1 otherwise, 2 on a technical failure (never counted as a catch).
"""
from __future__ import annotations

import json
import re
import sys
import zipfile
from pathlib import Path

PASS, FAIL = "PASS", "FAIL"


def docx_text(path: Path) -> str:
    """Paragraphs in document order, then every table cell in row order."""
    import docx  # python-docx

    d = docx.Document(str(path))
    out = [p.text for p in d.paragraphs]
    for t in d.tables:
        for row in t.rows:
            out.append(" | ".join(c.text.replace("\n", " ") for c in row.cells))
    return "\n".join(out)


def norm(s: str) -> str:
    s = s.replace("\u2032", "'").replace("\u2033", '"').replace("\u2019", "'")
    s = s.replace("\u2014", "-").replace("\u2013", "-").replace("\u00a0", " ")
    s = s.replace("\u00d7", "x")
    return re.sub(r"\s+", " ", s)


def near(text: str, a: str, b: str, window: int = 300) -> bool:
    """True when some match of regex `a` has a match of regex `b` within `window` characters."""
    for m in re.finditer(a, text, re.I):
        lo, hi = max(0, m.start() - window), min(len(text), m.end() + window)
        if re.search(b, text[lo:hi], re.I):
            return True
    return False


def find(text: str, pattern: str, window: int = 220) -> str:
    m = re.search(pattern, text, re.I)
    if not m:
        return ""
    lo, hi = max(0, m.start() - window // 2), min(len(text), m.end() + window // 2)
    return text[lo:hi].strip()


def num(s: str) -> float:
    return float(s.replace(",", ""))


# ------------------------------------------------------------------ the 15 rubric criteria
def c0(text: str, path: Path) -> tuple[str, str]:
    """No document in the record grants a right to discharge into the accepted Windmill Lane curb and gutter."""
    deny = (r"no (?:document|record|easement|right|permit|licen[cs]e|authoris\w*|authoriz\w*|agreement|instrument"
            r"|coordination record)|does not grant|do not grant|not grant|without (?:a |any )?(?:right|authoris\w*"
            r"|authoriz\w*|easement|permit|licen[cs]e)|none of the (?:records|documents)|is not authorised"
            r"|is not authorized|no legal right")
    ok, ev = False, ""
    for m in re.finditer(deny, text, re.I):
        win = text[max(0, m.start() - 320):m.end() + 320]
        if (re.search(r"windmill", win, re.I) and re.search(r"curb|gutter", win, re.I)
                and re.search(r"discharg\w*|outfall", win, re.I)):
            ok, ev = True, win.strip()
            break
    return (PASS if ok else FAIL), ev


def c1(text: str, path: Path) -> tuple[str, str]:
    """Sheet C-9 as drawn is incomplete for the purposes of responding to comment G-4."""
    ok = (re.search(r"g-4", text, re.I) is not None
          and near(text, r"g-4", r"incomplete|cannot be answered|cannot answer|cannot respond|not complete", 400)
          and re.search(r"c-9", text, re.I) is not None)
    return (PASS if ok else FAIL), find(text, r"incomplete|cannot be answered", 500)


def c2(text: str, path: Path) -> tuple[str, str]:
    """The detail and the basin notes give different values for crest height above the 100-year WSEL."""
    ok = (re.search(r"0\.71", text) is not None and re.search(r"0\.60", text) is not None
          and near(text, r"0\.71", r"0\.60", 250)
          and near(text, r"0\.71|0\.60", r"differ\w*|inconsist\w*|conflict\w*|disagree\w*", 350)
          and re.search(r"basin notes", text, re.I) is not None and re.search(r"detail", text, re.I) is not None)
    return (PASS if ok else FAIL), find(text, r"0\.71", 600)


def c3(text: str, path: Path) -> tuple[str, str]:
    """The revised basin notes give the accepted study's 41.5 cfs at the emergency spillway crest."""
    ok = (re.search(r"41\.5", text) is not None
          and near(text, r"41\.5", r"cfs|cubic feet per second", 120)
          and near(text, r"41\.5", r"crest", 350)
          and near(text, r"41\.5", r"2,858\.50|2858\.50", 700)
          and re.search(r"table d-2|master drainage study", text, re.I) is not None
          and re.search(r"revised basin notes", text, re.I) is not None)
    return (PASS if ok else FAIL), find(text, r"41\.5", 700)


def c4(text: str, path: Path) -> tuple[str, str]:
    """The apron is 15 ft by 20 ft of grouted rip-rap, D50 12 in."""
    ok = (near(text, r"grouted rip-?rap", r"\b15\b(?=[^.]{0,60}\b20\b)|\b20\b(?=[^.]{0,60}\b15\b)", 200)
          and near(text, r"grouted rip-?rap", r"d50", 300)
          and near(text, r"d50", r"\b12\b", 120))
    return (PASS if ok else FAIL), find(text, r"grouted rip-?rap", 400)


def c5(text: str, path: Path) -> tuple[str, str]:
    """Spillway flow bypasses the outlet control structure that limits discharge to the shared outfall."""
    ok = (near(text, r"bypass\w*|outside the outlet|additional to|not metered|unmetered",
               r"outlet control|orifice", 300)
          and near(text, r"bypass\w*|outside the outlet|additional to|not metered|unmetered", r"\b78\b", 500))
    return (PASS if ok else FAIL), find(text, r"bypass\w*", 500)


def c6(text: str, path: Path) -> tuple[str, str]:
    """Overflow discharges across Common-Area Parcel E to the Windmill Lane gutter line."""
    ok = (near(text, r"parcel\W{0,3}e\b|common-area parcel \"e\"", r"swale", 350)
          and near(text, r"swale|parcel\W{0,3}e\b", r"windmill", 350)
          and re.search(r"gutter", text, re.I) is not None)
    return (PASS if ok else FAIL), find(text, r"windmill lane gutter|swale", 450)


def c7(text: str, path: Path) -> tuple[str, str]:
    """C-9 must be revised to include spillway sizing calculations and a spillway section."""
    ok = (near(text, r"must be revised", r"sizing calculation", 350)
          and near(text, r"must be revised", r"section", 350)
          and near(text, r"must be revised", r"c-9", 400))
    return (PASS if ok else FAIL), find(text, r"must be revised", 600)


def c8(text: str, path: Path) -> tuple[str, str]:
    """A delivered, openable Word document with the required name."""
    if path.suffix.lower() != ".docx" or not path.is_file():
        return FAIL, f"{path.name}: not a docx"
    try:
        with zipfile.ZipFile(path) as z:
            ok = "word/document.xml" in z.namelist() and z.testzip() is None
    except Exception as e:  # noqa: BLE001
        return FAIL, f"{path.name}: {e}"
    return (PASS if ok else FAIL), f"{path.name}, {path.stat().st_size} bytes, openable={ok}"


def c9(text: str, path: Path) -> tuple[str, str]:
    """The 1.29 ft freeboard does not hold once the emergency spillway operates."""
    ok = (re.search(r"1\.29", text) is not None
          and near(text, r"1\.29", r"does not hold|not hold|no longer holds|fails|noncompliant|not met"
                     r"|does not satisfy|cannot be claimed|holds only", 500)
          and near(text, r"1\.29", r"spillway", 600))
    return (PASS if ok else FAIL), find(text, r"1\.29", 600)


def c10(text: str, path: Path) -> tuple[str, str]:
    """Addressed to Callaway."""
    ok = near(text, r"\bto:\s*\|?\s*", r"callaway", 150)
    return (PASS if ok else FAIL), find(text, r"\bto:\s*\|?\s*", 220)


def c11(text: str, path: Path) -> tuple[str, str]:
    """Dated 10/31/2026."""
    ok = re.search(r"10/31/2026|october 31,? 2026", text, re.I) is not None
    return (PASS if ok else FAIL), find(text, r"10/31/2026|october 31", 160)


def c12(text: str, path: Path) -> tuple[str, str]:
    """Signature block for the requester at the close."""
    tail = text[-2500:]
    ok = (re.search(r"max braddock", tail, re.I) is not None and re.search(r"_{5,}|signature", tail, re.I) is not None)
    return (PASS if ok else FAIL), tail[-400:].strip()


def c13(text: str, path: Path) -> tuple[str, str]:
    """The spillway revisions do not trigger a formal amendment to the accepted master study."""
    ok = (near(text, r"amendment", r"do(?:es)? not trigger|not trigger\w*|no formal amendment|no amendment"
               r"|is not required|are not required", 300)
          and near(text, r"amendment", r"detention allocation|outfall allowance|tributary area|shared outfall cap"
                     r"|storage-indication", 900))
    bad = re.search(r"(?:an?|the) (?:formal )?amendment (?:to the (?:accepted )?(?:master )?(?:drainage )?study )?"
                    r"(?:is|will be|would be) (?:required|triggered)", text, re.I)
    if bad and not re.search(r"\bno\b|\bnot\b", text[max(0, bad.start() - 60):bad.start()], re.I):
        return FAIL, f"asserts an amendment is required: {bad.group(0)!r}"
    return (PASS if ok else FAIL), find(text, r"amendment", 500)


def c14(text: str, path: Path) -> tuple[str, str]:
    """The Windmill Lane half-improvements receiving the overflow were accepted as Phase 2 offsite work."""
    acc = r"accepted by (?:Clark County Public Works|the County|CCPW)|accepted as Phase 2 offsite work"
    ok = (near(text, r"windmill", acc, 600) and near(text, r"windmill", r"phase 2", 600)
          and near(text, r"windmill", r"offsite", 600))
    return (PASS if ok else FAIL), find(text, acc, 600)


RUBRIC = [("C0  no right to discharge to the accepted Windmill Lane curb and gutter", c0),
          ("C1  C-9 as drawn is incomplete for G-4", c1),
          ("C2  detail 0.71 ft vs basin notes 0.60 ft", c2),
          ("C3  41.5 cfs at the crest in the revised basin notes", c3),
          ("C4  apron 15 x 20 ft grouted rip-rap, D50 12 in", c4),
          ("C5  spillway flow bypasses the outlet control", c5),
          ("C6  overflow across Parcel E to the Windmill Lane gutter line", c6),
          ("C7  C-9 to add sizing calculations and a spillway section", c7),
          ("C8  openable Memo_to_Callaway_Spillway_2026-10-31.docx", c8),
          ("C9  1.29 ft freeboard does not hold while the spillway runs", c9),
          ("C10 addressed to Callaway", c10),
          ("C11 dated 10/31/2026", c11),
          ("C12 signature block at the close", c12),
          ("C13 no formal amendment triggered", c13),
          ("C14 Windmill Lane accepted as Phase 2 offsite work", c14)]


# ------------------------------------------------------------------ my own closure checks
def k_arith(text: str, path: Path) -> tuple[str, str]:
    """The elevations the memorandum itself quotes must close: crest-WSEL, berm-crest, berm-WSEL."""
    vals = {}
    for key, pat in (("crest", r"2,858\.50"), ("wsel", r"2,857\.91"), ("berm", r"2,859\.20")):
        if re.search(pat, text) is None:
            return FAIL, f"{key} not quoted"
        vals[key] = num(pat.replace("\\", "").replace(",", "") if False else re.search(pat, text).group(0))
    d1 = round(vals["crest"] - vals["wsel"], 2)
    d2 = round(vals["berm"] - vals["crest"], 2)
    d3 = round(vals["berm"] - vals["wsel"], 2)
    miss = [f"{v:.2f}" for v in (d1, d2, d3) if f"{v:.2f}" not in text]
    ok = not miss
    return (PASS if ok else FAIL), (f"crest-WSEL {d1:.2f}, berm-crest {d2:.2f}, berm-WSEL {d3:.2f}; "
                                    f"missing {miss}")


def k_storage(text: str, path: Path) -> tuple[str, str]:
    """Storage and discharge closure against Table D-2: 6.40/27.9, 7.12/41.5, 8.02 ac-ft."""
    need = ["6.40", "7.12", "8.02", "27.9", "41.5"]
    miss = [n for n in need if n not in text]
    ok = not miss and near(text, r"7\.12", r"41\.5", 250) and near(text, r"6\.40", r"27\.9", 250)
    return (PASS if ok else FAIL), f"missing {miss}"


def k_no_invented_apron(text: str, path: Path) -> tuple[str, str]:
    """No apron thickness, bedding or filter value is stated (the record gives none), and the memorandum says so."""
    says_none = (near(text, r"apron", r"no thickness|no bedding|no filter|bedding or filter|not specified", 200)
                 and near(text, r"apron", r"record", 300))
    invented = re.search(r"\b\d+(?:\.\d+)?\s*[- ]\s*(?:inch|in)\s+(?:thick\w*|bedding)|"
                         r"(?:thickness of|bedded on|bedding of)\s*\d", text, re.I)
    if invented:
        return FAIL, f"states an apron dimension the record does not give: {invented.group(0)!r}"
    return (PASS if says_none else FAIL), ("the memorandum states the record gives no apron thickness/bedding"
                                           if says_none else "does not say the apron construction is absent from the record")


def k_no_conforming_freeboard(text: str, path: Path) -> tuple[str, str]:
    """The 1.29 ft figure must not be restated as conforming without the spillway condition."""
    for m in re.finditer(r"1\.29", text):
        seg = text[max(0, m.start() - 220):m.end() + 220]
        if re.search(r"\bmeets\b|\bconforms\b|\bsatisf\w+", seg, re.I) and \
           not re.search(r"does not|only|never runs|not met|fails", seg, re.I):
            return FAIL, f"restates 1.29 ft as conforming: {seg.strip()[:200]}"
    return PASS, "1.29 ft not restated as conforming"


def k_no_amendment_claim(text: str, path: Path) -> tuple[str, str]:
    """No affirmative statement that an amendment IS required for the spillway revisions."""
    for m in re.finditer(r"amendment", text, re.I):
        seg = text[max(0, m.start() - 120):m.end() + 120]
        if re.search(r"\b(?:an?|the) (?:formal )?amendment (?:to [^.]{0,60})?(?:is|will be|would be) "
                     r"(?:required|triggered)", seg, re.I) and not re.search(r"\bno\b|\bnot\b|never", seg, re.I):
            return FAIL, seg.strip()[:200]
    return PASS, "no affirmative amendment claim"


CLOSURE = [("K1 elevations quoted in the memorandum close arithmetically", k_arith),
           ("K2 storage/discharge close to Table D-2", k_storage),
           ("K3 no apron construction invented", k_no_invented_apron),
           ("K4 1.29 ft not restated as conforming", k_no_conforming_freeboard),
           ("K5 no affirmative amendment claim", k_no_amendment_claim)]


def run(path: Path) -> dict:
    text = norm(docx_text(path))
    rows = []
    for name, fn in RUBRIC + CLOSURE:
        status, ev = fn(text, path)
        rows.append({"check": name, "status": status, "evidence": ev})
    failed = [r["check"] for r in rows if r["status"] != PASS]
    return {"file": str(path), "chars": len(text), "checks": rows, "passed": len(rows) - len(failed),
            "total": len(rows), "failures": failed}


def run_text(text_path: Path, docx_path: Path | None) -> dict:
    """Grade a text twin (the judge's view) but test C8 on the delivered docx."""
    text = norm(text_path.read_text(encoding="utf-8", errors="replace"))
    rows = []
    for name, fn in RUBRIC + CLOSURE:
        arg = docx_path if (docx_path is not None and fn is c8) else text_path
        if fn is c8:
            status, ev = c8(text, arg if docx_path is not None else text_path.with_suffix(".docx"))
        else:
            status, ev = fn(text, arg)
        rows.append({"check": name, "status": status, "evidence": ev})
    failed = [r["check"] for r in rows if r["status"] != PASS]
    return {"file": str(text_path), "chars": len(text), "checks": rows, "passed": len(rows) - len(failed),
            "total": len(rows), "failures": failed}


def main(argv: list[str]) -> int:
    if len(argv) >= 3 and argv[1] == "text":
        text_path = Path(argv[2])
        docx_path = Path(argv[argv.index("--docx") + 1]) if "--docx" in argv else None
        try:
            result = run_text(text_path, docx_path)
        except Exception as e:  # noqa: BLE001
            print(f"TECHNICAL FAILURE: {e}", file=sys.stderr)
            return 2
        for r in result["checks"]:
            print(f"{r['status']:4} {r['check']}")
            if r["status"] != PASS:
                print(f"       evidence: {r['evidence'][:300]}")
        print(f"\n{result['passed']}/{result['total']} checks pass on {text_path.name}; "
              f"failures: {result['failures'] or 'none'}")
        return 0 if not result["failures"] else 1
    if len(argv) < 3 or argv[1] not in ("read", "json"):
        print(__doc__)
        return 2
    path = Path(argv[2])
    try:
        result = run(path)
    except Exception as e:  # noqa: BLE001  technical failure, never a catch
        print(f"TECHNICAL FAILURE: {e}", file=sys.stderr)
        return 2
    if argv[1] == "json":
        print(json.dumps(result))
    else:
        for r in result["checks"]:
            print(f"{r['status']:4} {r['check']}")
            if r["status"] != PASS:
                print(f"       evidence: {r['evidence'][:300]}")
        print(f"\n{result['passed']}/{result['total']} checks pass; failures: {result['failures'] or 'none'}")
    return 0 if not result["failures"] else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv))
