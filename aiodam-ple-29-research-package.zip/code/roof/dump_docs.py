"""Dump the roof-deck project's schedules, site study and USGS maps in a compact readable form."""
import json
import os
import zipfile

import openpyxl
import ezdxf

BASE = ("/work/ple-dataset/tasks/roof-deck-design/environment/filesystem/"
        "final_batch4__structural_task7_roof_deck_design__blind")


def dump_xlsx(rel, max_rows=60):
    p = os.path.join(BASE, rel)
    wb = openpyxl.load_workbook(p, data_only=True)
    print(f"\n######## {rel}  sheets={wb.sheetnames}")
    for ws in wb.worksheets:
        print(f"--- sheet {ws.title!r} dims={ws.dimensions}")
        n = 0
        for row in ws.iter_rows(values_only=True):
            if all(c is None or str(c).strip() == "" for c in row):
                continue
            print("   ", [c for c in row if c is not None])
            n += 1
            if n >= max_rows:
                print("    ... (truncated)")
                break


def dump_docx(rel):
    p = os.path.join(BASE, rel)
    with zipfile.ZipFile(p) as z:
        xml = z.read("word/document.xml").decode("utf-8", "replace")
    import re
    xml = re.sub(r"</w:p>", "\n", xml)
    txt = re.sub(r"<[^>]+>", "", xml)
    print(f"\n######## {rel}")
    print(txt)


for rel in ["project/70_procurement/Cost_Plan_CP-RD-2026_Roof_Deck.xlsx",
            "project/70_procurement/Deck_Stock_Availability_2026-07.xlsx",
            "project/30_structural/Joist_and_Joist_Girder_Schedule.xlsx",
            "project/40_mechanical/Rooftop_Equipment_Schedule.xlsx"]:
    dump_xlsx(rel)

print("\n######## USGS files")
for rel in ["project/20_site/usgs_design_maps/USGS_ASCE7-22_RC-III_SiteClass-D_46.6832_-111.9756.json",
            "project/20_site/usgs_design_maps/USGS_ASCE7-16_RC-II_SiteClass-C_46.6832_-111.9756_(2019_preliminary).json"]:
    d = json.load(open(os.path.join(BASE, rel)))
    print(rel)
    print(json.dumps(d, indent=1)[:1500])


def dump_dxf(rel, layers=None, max_items=40):
    p = os.path.join(BASE, rel)
    doc = ezdxf.readfile(p)
    msp = doc.modelspace()
    print(f"\n######## DXF {rel}")
    print("  layers:", sorted(l.dxf.name for l in doc.layers))
    print("  header units $INSUNITS:", doc.header.get("$INSUNITS"))
    counts = {}
    for e in msp:
        counts[(e.dxftype(), e.dxf.layer)] = counts.get((e.dxftype(), e.dxf.layer), 0) + 1
    for k, v in sorted(counts.items()):
        print(f"  {k} x{v}")
    shown = 0
    for e in msp:
        if layers and not any(e.dxf.layer.upper().startswith(L.upper()) for L in layers):
            continue
        if e.dxftype() == "LWPOLYLINE":
            pts = [(round(x, 2), round(y, 2)) for x, y in e.get_points("xy")]
            print(f"  [{e.dxf.layer}] LWPOLYLINE closed={e.closed} n={len(pts)} {pts[:8]}")
        elif e.dxftype() in ("TEXT", "MTEXT"):
            print(f"  [{e.dxf.layer}] {e.dxftype()} at {tuple(round(v,2) for v in e.dxf.insert[:2])} "
                  f"text={e.dxf.text!r}" if e.dxftype() == "TEXT" else
                  f"  [{e.dxf.layer}] MTEXT at {tuple(round(v,2) for v in e.dxf.insert[:2])} text={e.text!r}")
        elif e.dxftype() == "LINE":
            print(f"  [{e.dxf.layer}] LINE {tuple(round(v,2) for v in e.dxf.start[:2])} -> "
                  f"{tuple(round(v,2) for v in e.dxf.end[:2])}")
        else:
            continue
        shown += 1
        if shown > max_items:
            print("  ... (truncated)")
            break


for rel in ["project/10_drawings/architectural/A-201_Roof_Plan_REVC.dxf",
            "project/10_drawings/architectural/archive/A-201_Roof_Plan_REVB.dxf",
            "project/10_drawings/mechanical/M-401_Roof_Equipment_Plan_REVC.dxf",
            "project/10_drawings/structural/S-101_Roof_Framing_Plan_REV3.dxf"]:
    dump_dxf(rel, max_items=25)

dump_docx("project/00_admin/OBD-DC2-A_Owners_Basis_of_Design_excerpt.docx")
