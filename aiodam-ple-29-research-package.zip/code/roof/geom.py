"""Plan geometry of every roof obstruction and opening, in feet, straight out of the Rev C IFC.

World-coordinate tessellation (USE_WORLD_COORDS) so the placement tree is applied by ifcopenshell
itself; millimetres -> feet by the model note's factor 304.8.
"""
import ifcopenshell
import ifcopenshell.geom as g
import ifcopenshell.util.element as ue

P = ("/work/ple-dataset/tasks/roof-deck-design/environment/filesystem/"
     "final_batch4__structural_task7_roof_deck_design__blind/15_model/"
     "DC2-A-STR_Roof_Structure_Model_RevC.ifc")
MM = 304.8
f = ifcopenshell.open(P)
st = g.settings()
st.set("use-world-coords", True)
st.set("weld-vertices", False)


def bbox(el):
    try:
        sh = g.create_shape(st, el)
    except Exception as e:  # noqa: BLE001
        return None, f"geom failed: {type(e).__name__}: {e}"
    v = sh.geometry.verts
    xs, ys, zs = v[0::3], v[1::3], v[2::3]
    return (min(xs) / MM, min(ys) / MM, max(xs) / MM, max(ys) / MM,
            min(zs) / MM, max(zs) / MM), None


print(f"{'tag':10s} {'x0':>7s} {'y0':>7s} {'x1':>7s} {'y1':>7s} {'h':>6s}  type")
for kind, cls in (("obstruction", "IfcBuildingElementProxy"), ("opening", "IfcOpeningElement"),
                  ("parapet", "IfcWall")):
    for el in f.by_type(cls):
        bb, err = bbox(el)
        ps = ue.get_psets(el)
        h = None
        for k, v in ps.items():
            if "HeightAboveRoof" in v:
                h = v["HeightAboveRoof"] / MM
        if bb is None:
            print(f"{el.Name!r:10s} {err}")
            continue
        x0, y0, x1, y1, z0, z1 = bb
        print(f"{el.Name!r:10s} {x0:7.2f} {y0:7.2f} {x1:7.2f} {y1:7.2f} "
              f"{(z1 - z0):6.2f}  {kind} top_z={z1:.2f} pset_h={h}")
