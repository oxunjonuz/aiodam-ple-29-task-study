"""Read the roof structure IFC (Rev C) and print the obstruction / opening / parapet geometry in feet.

The model note says: millimetres, origin at grid 1-A, +X east (grids 1-9 at 30 ft), +Y north (A-G at
30 ft), +Z up from the storey at 32 ft.  Feet = mm / 304.8.
"""
import ifcopenshell
import ifcopenshell.util.element as ue

P = ("/work/ple-dataset/tasks/roof-deck-design/environment/filesystem/"
     "final_batch4__structural_task7_roof_deck_design__blind/15_model/"
     "DC2-A-STR_Roof_Structure_Model_RevC.ifc")
MM = 304.8
f = ifcopenshell.open(P)

print("schema:", f.schema)
storeys = f.by_type("IfcBuildingStorey")
for s in storeys:
    print("storey:", s.Name, "elev mm", s.Elevation)

# units
for u in f.by_type("IfcUnitAssignment"):
    for x in u.Units:
        if x.is_a("IfcSIUnit"):
            print("unit:", x.UnitType, x.Prefix, x.Name)


def plan_extent(el):
    """Plan bounding box (x0, y0, x1, y1) in model mm from the extruded solid geometry."""
    xs, ys, zs = [], [], []
    for rel in getattr(el, "Representation", []) or []:
        for item in rel.Representations or []:
            for g in ue.get_flat_geometry(item) if hasattr(ue, "get_flat_geometry") else [item]:
                pass
    return None


def bbox_from_verts(el):
    xs, ys, zs = [], [], []
    for rep in getattr(el, "Representation", []) or []:
        for item in rep.Representations or []:
            stack = [item]
            while stack:
                it = stack.pop()
                if it is None:
                    continue
                if it.is_a("IfcExtrudedAreaSolid"):
                    depth = it.Depth
                    prof = it.SweptArea
                    pts = []
                    if prof.is_a("IfcRectangleProfileDef"):
                        pts = [(-prof.XDim / 2, -prof.YDim / 2), (prof.XDim / 2, -prof.YDim / 2),
                               (prof.XDim / 2, prof.YDim / 2), (-prof.XDim / 2, prof.YDim / 2)]
                    elif prof.is_a("IfcArbitraryClosedProfileDef"):
                        pts = [(p.Coordinates[0], p.Coordinates[1]) for p in prof.OuterCurve.Points]
                    for (px, py) in pts:
                        for zz in (0.0, depth):
                            p = it.Position
                            if p and p.Location:
                                x = px * (p.RefDirection.DirectionRatios[0] if False else 1.0)
                                pass
                            xs.append(px)
                            ys.append(py)
                            zs.append(zz)
                for attr in ("Objects", "Elements", "CfsFaces"):
                    stack.extend(getattr(it, attr, []) or [])
    return xs, ys, zs


print("\n=== proxies (rooftop obstructions) ===")
for el in f.by_type("IfcBuildingElementProxy"):
    psets = ue.get_psets(el)
    obs = psets.get("Pset_RoofObstruction", {})
    pl = el.ObjectPlacement
    loc = pl.RelativePlacement.Location.Coordinates if pl and pl.RelativePlacement else None
    print(f"{el.Name!r:12s} tag={el.Tag!r:8s} type={el.ObjectType!r:20s} placement={loc} pset={obs}")

print("\n=== openings ===")
for el in f.by_type("IfcOpeningElement"):
    psets = ue.get_psets(el)
    print(f"{el.Name!r} tag={el.Tag!r} psets={psets}")

print("\n=== walls ===")
for el in f.by_type("IfcWall"):
    print(f"{el.Name!r} tag={el.Tag!r} type={el.PredefinedType} pset={ue.get_psets(el)}")

print("\n=== slabs ===")
for el in f.by_type("IfcSlab"):
    print(f"{el.Name!r} tag={el.Tag!r} type={el.PredefinedType}")

print("\n=== grid ===")
for g in f.by_type("IfcGrid"):
    print("grid", g.Name)
    for ax in g.UAxes or []:
        print("  U", ax.AxisTag, ax.AxisCurve.Points[0].Coordinates if ax.AxisCurve else None)
    for ax in g.VAxes or []:
        print("  V", ax.AxisTag, ax.AxisCurve.Points[0].Coordinates if ax.AxisCurve else None)

print("\n=== members (braced frames) ===")
for el in f.by_type("IfcMember"):
    ps = ue.get_psets(el)
    print(f"{el.Name!r} tag={el.Tag!r} psets={ps}")
