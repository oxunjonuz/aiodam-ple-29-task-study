"""Tiling of the roof into zone rectangles that respect the framed openings, and the search over
combinations.  Zone rectangles must lie on the 6 ft x 6 ft checking grid and may not cover a deck
cell that a framed opening touches (criteria 10.5 and the checking conventions)."""
from __future__ import annotations

import itertools
import json
import math
import sys

import numpy as np

from . import design as DS
from . import model as M


def to_cells(x0, y0, x1, y1):
    """Cell index range [i0, i1) x [j0, j1) for a rectangle on the 6 ft grid."""
    i0, i1 = int(round(x0 / M.ZONE_GRID)), int(round(x1 / M.ZONE_GRID))
    j0, j1 = int(round(y0 / M.ZONE_GRID)), int(round(y1 / M.ZONE_GRID))
    return i0, i1, j0, j1


def decompose(mask):
    """Maximal-rectangle decomposition of a boolean cell mask (greedy horizontal runs, stacked)."""
    nx, ny = mask.shape
    used = np.zeros_like(mask, dtype=bool)
    rects = []
    for j in range(ny):
        for i in range(nx):
            if not mask[i, j] or used[i, j]:
                continue
            i2 = i
            while i2 + 1 < nx and mask[i2 + 1, j] and not used[i2 + 1, j]:
                i2 += 1
            j2 = j
            while j2 + 1 < ny and all(mask[i:i2 + 1, j2 + 1]) and not any(used[i:i2 + 1, j2 + 1]):
                j2 += 1
            used[i:i2 + 1, j:j2 + 1] = True
            rects.append((i, i2 + 1, j, j2 + 1))
    return rects


def rects_ft(rects):
    return [(i0 * M.ZONE_GRID, j0 * M.ZONE_GRID, i1 * M.ZONE_GRID, j1 * M.ZONE_GRID)
            for i0, i1, j0, j1 in rects]


def tiles_from_cuts(xcuts, ycuts):
    """Cell masks of each tile of a rectangular partition; tiles are flattened row-major."""
    tiles = []
    for a, b in zip(xcuts[:-1], xcuts[1:]):
        for c, d in zip(ycuts[:-1], ycuts[1:]):
            m = np.zeros((M.NX, M.NY), dtype=bool)
            m[int(round(a / 6)):int(round(b / 6)), int(round(c / 6)):int(round(d / 6))] = True
            m &= M.deck_mask()
            if m.any():
                tiles.append(m)
    return tiles


def edge_mask():
    b, e = DS.boundary_cells()
    return b | e


def build_zones(tiles, combos, edge_required=True, ids=None):
    """One zone per tile (all of its rectangles share the tile's combination)."""
    zones = []
    for k, (m, c) in enumerate(zip(tiles, combos)):
        rects = rects_ft(decompose(m))
        zid = f"Z{k+1}" if ids is None else ids[k]
        zones.append(DS.zone(zid, rects, c["gage"], c["pattern"], c["sidelap"], c["ns"]))
    return zones


def perimeter_ok(c):
    return M.PATTERNS[c["pattern"]] >= M.PATTERNS[M.PERIMETER_MIN_PATTERN] and c["ns"] >= M.MIN_SIDELAP_AT_BOUNDARY


def candidates():
    out = M.combinations()
    for c in out:
        c["perimeter"] = perimeter_ok(c)
    return out


def feasible_locally(c, cells, edge):
    """Cheapest per-cell feasibility: gravity (all four cases at the cell), deflection, reaction, uplift."""
    wcell = float(M.GAGES[c["gage"]]["wt"])
    for sid in ("S01", "S02", "S03", "S04"):
        dem = M.gravity_demand(sid, wcell)
        if (dem[cells] > c["grav"] + 1e-6).any():
            return False
        live = M.live_component(sid)
        lim = M.JOIST_SPACING * 12.0 / 240.0
        if (c["defl"] * live[cells] > lim + 1e-9).any():
            return False
        if (1.1 * dem[cells] * M.JOIST_SPACING > c["reac"] + 1e-6).any():
            return False
    up = M.uplift_demand(wcell)
    if (up[cells] > c["upl"] + 1e-6).any():
        return False
    if (edge & cells).any() and not c["perimeter"]:
        return False
    return True


def cheapest_local(cells, edge, cands):
    best = None
    for c in cands:
        if not feasible_locally(c, cells, edge):
            continue
        if best is None or c["cost"] < best["cost"]:
            best = c
    return best


def merge_zones(zones):
    """One zone per distinct combination: tiles with the same gage, pattern, sidelap and count share
    a zone with several rectangles, which the criteria allow and which halves the zone set-ups."""
    groups = {}
    for z in zones:
        key = (z["gage"], z["pattern"], z["sidelap"], z["ns"])
        g = groups.setdefault(key, dict(rects=[], combo=z))
        g["rects"].extend(z["rects"])
    out = []
    for n, (key, g) in enumerate(groups.items(), start=1):
        z = g["combo"]
        out.append(DS.zone(f"Z{n}", g["rects"], z["gage"], z["pattern"], z["sidelap"], z["ns"]))
    return out
