"""Hand-built zone layout for the DC-2 roof deck, driven by the demand maps.

The layout follows the physics the documents create:
  * the SCR-N screen wall (y = 164 ft) throws a 2 ft deep, ~104 psf drift band across the whole
    width -> that band, and the north parapet band, are 18 gage;
  * the MEP-PH-1 enclosure (x 60..180, y 60..120) throws drifts OUTSIDE its four faces, so the roof
    it stands on is drift-free: the cheapest deck on the roof;
  * the rooftop units put local drifts in the south band (y 24..48) and beside RO-3;
  * the framed openings RO-1..RO-3 and the perimeter force the 36/7 + 3 sidelap minimum on any zone
    that touches them, which is why the pattern is uniform over the roof;
  * the stiff braced frames on grid 9 (BF-Y3/Y4, k = 68 kip/in each) concentrate the seismic-Y shear
    at the east edge -> the east band is the strongest deck on the roof.
"""
from __future__ import annotations

import numpy as np

from . import model as M
from . import tiling as T


def rect_mask(x0, y0, x1, y1):
    m = np.zeros((M.NX, M.NY), dtype=bool)
    i0 = int(round(x0 / M.ZONE_GRID)); i1 = int(round(x1 / M.ZONE_GRID))
    j0 = int(round(y0 / M.ZONE_GRID)); j1 = int(round(y1 / M.ZONE_GRID))
    m[i0:i1, j0:j1] = True
    return m


def layout():
    """Tile masks (before opening cut-out) in y-band order, split where the demand splits."""
    tiles = []
    deck = M.deck_mask()
    # south clear band
    tiles.append(rect_mask(0, 0, 240, 24))
    # south band with the rooftop-unit drifts
    tiles.append(rect_mask(0, 24, 240, 48))
    # band at the south face of the enclosure (and RO-1)
    tiles.append(rect_mask(0, 48, 96, 60))
    tiles.append(rect_mask(96, 48, 108, 60))
    tiles.append(rect_mask(108, 48, 240, 60))
    # the enclosure band: west strip, roof under the enclosure, east strip
    tiles.append(rect_mask(0, 60, 60, 120))
    tiles.append(rect_mask(60, 60, 180, 120))
    tiles.append(rect_mask(180, 60, 240, 120))
    # north face of the enclosure (and RO-2)
    tiles.append(rect_mask(0, 120, 240, 132))
    # between the enclosure and the screen wall
    tiles.append(rect_mask(0, 132, 240, 150))
    # the screen-wall drift band and the north parapet
    tiles.append(rect_mask(0, 150, 216, 180))
    # the east band, strongest deck where BF-Y3/Y4 sit
    return [t & deck for t in tiles]


def layout_with_east_band():
    """Same, but the east 24 ft is its own zone (the shear concentration at grid 9)."""
    tiles = []
    deck = M.deck_mask()
    def add(x0, y0, x1, y1, east=False):
        m = rect_mask(x0, y0, x1, y1) & deck
        if east:
            m &= ~rect_mask(216, 0, 240, 180)
        if m.any():
            tiles.append(m)
    add(0, 0, 240, 24, east=True)
    add(0, 24, 240, 48, east=True)
    add(0, 48, 96, 60, east=True)
    add(96, 48, 108, 60, east=True)
    add(108, 48, 240, 60, east=True)
    add(0, 60, 60, 120, east=True)
    add(60, 60, 180, 120, east=True)
    add(180, 60, 240, 120, east=True)
    add(0, 120, 240, 132, east=True)
    add(0, 132, 240, 150, east=True)
    add(0, 150, 216, 180, east=True)
    tiles.append(rect_mask(216, 0, 240, 180) & deck)
    return tiles


if __name__ == "__main__":
    for name, fn in (("layout", layout), ("layout_with_east_band", layout_with_east_band)):
        tiles = fn()
        rects = [T.decompose(m) for m in tiles]
        n = sum(len(r) for r in rects)
        cover = np.zeros((M.NX, M.NY), dtype=int)
        for m in tiles:
            cover += m.astype(int)
        print(f"{name}: {len(tiles)} tiles, {n} rectangles, cells covered once: "
              f"{int(((cover == 1) & M.deck_mask()).sum())} of {int(M.deck_mask().sum())}, "
              f"twice: {int((cover > 1).sum())}, missing: {int(((cover == 0) & M.deck_mask()).sum())}")
        for k, r in enumerate(rects):
            print(f"   tile {k}: {int(tiles[k].sum()):4d} cells -> {len(r)} rects {T.rects_ft(r)}")
