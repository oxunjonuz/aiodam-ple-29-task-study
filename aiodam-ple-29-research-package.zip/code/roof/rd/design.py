"""Zone model, per-cell fields, scenario evaluation and the zone search for the DC-2 roof deck."""
from __future__ import annotations

import itertools

import numpy as np

from . import fem as FM
from . import model as M

FAMILIES_HARD = 21


def cells_of(rect):
    """Cells whose centre lies inside the rectangle (the grader assigns by cell centre)."""
    x0, y0, x1, y1 = rect
    m = np.zeros((M.NX, M.NY), dtype=bool)
    idx = (M.CELL_X > x0) & (M.CELL_X < x1)
    idy = (M.CELL_Y > y0) & (M.CELL_Y < y1)
    m |= idx & idy
    return m


def assign_from_zones(zones):
    assign = np.full((M.NX, M.NY), -1, dtype=int)
    overlap = np.zeros((M.NX, M.NY), dtype=int)
    for zi, z in enumerate(zones):
        for r in z["rects"]:
            m = cells_of(r)
            assign = np.where(m & (assign < 0), zi, assign)
            overlap += m.astype(int)
    return assign, overlap


def fields(zones, assign):
    nx, ny = M.NX, M.NY
    out = {k: np.zeros((nx, ny)) for k in ("gt", "shear_cap", "uplift_cap", "gravity_cap", "weight", "defl")}
    for zi, z in enumerate(zones):
        m = assign == zi
        if not m.any():
            continue
        n = M.PATTERNS[z["pattern"]]
        out["gt"][m] = M.gp_stiffness(z["gage"], n, z["sidelap"], z["ns"])
        out["shear_cap"][m] = M.PHI_D * M.sn_nominal(z["gage"], n, z["sidelap"], z["ns"])
        out["uplift_cap"][m] = M.uplift_capacity(z["gage"], z["pattern"])
        out["gravity_cap"][m] = M.gravity_capacity(z["gage"])
        out["weight"][m] = M.GAGES[z["gage"]]["wt"]
        out["defl"][m] = M.deflection_per_psf(z["gage"])
    return out


def valid_zone(z):
    return M.valid_combination(z["gage"], z["pattern"], z["sidelap"], z["ns"])


def cardinality_ok(zones, assign):
    used = [zi for zi in range(len(zones)) if (assign == zi).any()]
    gages = {zones[zi]["gage"] for zi in used}
    pats = {(zones[zi]["pattern"], zones[zi]["sidelap"], zones[zi]["ns"]) for zi in used}
    nrect = sum(len(zones[zi]["rects"]) for zi in used)
    return (len(gages) <= M.MAX_GAGES, len(pats) <= M.MAX_PATTERNS,
            len(used) <= M.MAX_ZONES, nrect <= M.MAX_RECTS,
            len(gages), len(pats), len(used), nrect)


def boundary_cells():
    b = np.zeros((M.NX, M.NY), dtype=bool)
    b[0, :] = b[-1, :] = True
    b[:, 0] = b[:, -1] = True
    op = M.opening_mask()
    edge = np.zeros((M.NX, M.NY), dtype=bool)
    edge[1:, :] |= op[:-1, :]
    edge[:-1, :] |= op[1:, :]
    edge[:, 1:] |= op[:, :-1]
    edge[:, :-1] |= op[:, 1:]
    edge &= ~op
    return b, edge & ~op


def evaluate(zones, verbose=False):
    """Run every scenario the way the criteria demand.  Returns dict with the worst cases."""
    assign, overlap = assign_from_zones(zones)
    need = M.deck_mask()
    f = fields(zones, assign)
    m = need & (assign >= 0)
    wcell = np.where(f["weight"] > 0, f["weight"], 2.5)

    res = dict(assign=assign, overlap=overlap, fields=f, cost=M.installed_cost(zones, assign),
               problems=[], zone_worst={zi: dict(shear=0.0, grav=0.0, uplift=0.0, gov="", ratio=0.0)
                                        for zi in range(len(zones))},
               lateral={}, gravity={}, uplift={})

    if (overlap > 1).any():
        res["problems"].append(f"{int((overlap > 1).sum())} cells covered twice")
    if (need & (assign < 0)).any():
        res["problems"].append(f"{int((need & (assign < 0)).sum())} deck cells with no zone")
    if (~need & (assign >= 0)).any():
        res["problems"].append(f"{int((~need & (assign >= 0)).sum())} zone cells inside an opening")

    # gravity
    for sid in FM.GRAVITY_SCEN:
        dem = M.gravity_demand(sid, wcell)
        live = M.live_component(sid)
        cap = f["gravity_cap"]
        d_in = f["defl"] * live
        lim = M.JOIST_SPACING * 12.0 / 240.0
        reac = 1.1 * dem * M.JOIST_SPACING
        rcap = np.zeros_like(reac)
        for zi, z in enumerate(zones):
            rcap[assign == zi] = M.GAGES[z["gage"]]["Rn_end"]
        over = m & (dem > cap + 1e-6)
        bad = m & (d_in > lim + 1e-9)
        rbad = m & (reac > rcap + 1e-6)
        if over.any():
            res["problems"].append(f"{sid} gravity {dem[over].max():.1f} > {cap[over].min():.1f} psf "
                                   f"({int(over.sum())} cells)")
        if bad.any():
            res["problems"].append(f"{sid} deflection {d_in[bad].max():.3f} > {lim:.3f} in")
        if rbad.any():
            res["problems"].append(f"{sid} end reaction {reac[rbad].max():.0f} > {rcap[rbad].min():.0f} plf")
        res["gravity"][sid] = dict(dem_max=float(dem[m].max()), margin=float((cap - dem)[m].min()))
        for zi in range(len(zones)):
            mm = (assign == zi) & need
            if not mm.any():
                continue
            v = float(dem[mm].max())
            c = float(cap[mm].min())
            res["zone_worst"][zi]["grav"] = max(res["zone_worst"][zi]["grav"], v)
            if c > 0 and v / c > res["zone_worst"][zi]["ratio"]:
                res["zone_worst"][zi].update(gov=sid, ratio=v / c)

    # uplift
    dem_u = M.uplift_demand(wcell)
    bad = m & (dem_u > f["uplift_cap"] + 1e-6)
    if bad.any():
        res["problems"].append(f"S09 uplift {dem_u[bad].max():.1f} > {f['uplift_cap'][bad].min():.1f} psf")
    res["uplift"]["dem_max"] = float(dem_u[m].max())
    for zi in range(len(zones)):
        mm = (assign == zi) & need
        if not mm.any():
            continue
        v = float(dem_u[mm].max())
        c = float(f["uplift_cap"][mm].min())
        res["zone_worst"][zi]["uplift"] = v
        if c > 0 and v / c > res["zone_worst"][zi]["ratio"]:
            res["zone_worst"][zi].update(gov="S09", ratio=v / c)

    # lateral
    D = FM.Diaphragm()
    gt_el, cap_el = D.element_deck(f["gt"], f["shear_cap"])
    ratios = []
    for sid in FM.LATERAL_SCEN:
        dirn, F, ecc, pat, om = FM.lateral_case(sid)
        r = D.solve(gt_el, cap_el, dirn, F, ecc, pat, om)
        if r is None:
            res["problems"].append(f"{sid}: no solution")
            continue
        v = r["v_plf"]
        over = v > cap_el + 25.0
        if over.any():
            res["problems"].append(f"{sid} shear {v[over].max():.0f} > {cap_el[over].min():.0f} plf "
                                   f"({int(over.sum())} panels)")
        if r["reg_share"] > FM.REG_SHARE_LIMIT:
            res["problems"].append(f"{sid} regularisation {100*r['reg_share']:.1f} %")
        if r["diaphragm_defl_in"] > 1.6:
            res["problems"].append(f"{sid} deflection {r['diaphragm_defl_in']:.3f} in > 1.6")
        chord = D.chord_force_kip(r, dirn)
        coll = D.collector_force_kip(r, dirn) * om
        chord_lim = min(FM.CHORD_CAP, FM.CHORD_SPLICE)
        coll_lim = min(FM.COLLECTOR_CAP, FM.COLLECTOR_SPLICE)
        if chord > chord_lim * 1.05:
            res["problems"].append(f"{sid} chord {chord:.1f} > {chord_lim}")
        if coll > coll_lim * 1.05:
            res["problems"].append(f"{sid} collector {coll:.1f} > {coll_lim}")
        if r["avg_frame_disp_in"] > 1e-9:
            ratios.append(r["diaphragm_defl_in"] / r["avg_frame_disp_in"])
        res["lateral"][sid] = dict(dirn=dirn, vmax=float(v.max()), defl=r["diaphragm_defl_in"],
                                   chord=chord, coll=coll, om=om, F=F,
                                   avg_frame=r["avg_frame_disp_in"], reg=r["reg_share"])
        ncy = int(round((D.ys_ft[1] - D.ys_ft[0]) / M.ZONE_GRID))
        for zi in range(len(zones)):
            em = (assign == zi).reshape(D.nel_x, D.nel_y, ncy).any(axis=2)
            if not em.any():
                continue
            vv = float(v[em].max())
            res["zone_worst"][zi]["shear"] = max(res["zone_worst"][zi]["shear"], vv)
            pos = cap_el[em] > 0
            if pos.any():
                cmin = float(cap_el[em][pos].min())
                if cmin > 0 and vv / cmin > res["zone_worst"][zi]["ratio"]:
                    res["zone_worst"][zi].update(gov=sid, ratio=vv / cmin)
    res["flexible_ratio"] = max(ratios) if ratios else 0.0
    res["classification"] = "FLEXIBLE" if res["flexible_ratio"] > 2.0 else "SEMI-RIGID"
    res["ok"] = not res["problems"]
    if verbose:
        for p in res["problems"]:
            print("  !", p)
        print(f"  cost ${res['cost']:,.0f}  class {res['classification']} "
              f"({res['flexible_ratio']:.2f})")
    return res


def zone(gid, rects, gage, pattern, sidelap, ns):
    return dict(zone_id=gid, rects=rects, gage=gage, pattern=pattern, sidelap=sidelap, ns=ns)


def uniform(combo):
    return [zone("Z1", [(0.0, 0.0, M.LX, M.LY)], combo["gage"], combo["pattern"],
                 combo["sidelap"], combo["ns"])]


def by_combo(combo):
    return dict(gage=combo["gage"], pattern=combo["pattern"], sidelap=combo["sidelap"], ns=combo["ns"])


if __name__ == "__main__":
    combos = M.combinations()
    combos.sort(key=lambda c: c["cost"])
    print("cheapest combinations:")
    for c in combos[:6]:
        print(f"  {c['gage']} {c['pattern']} {c['sidelap']} ns={c['ns']} ${c['cost']:.0f}/cell "
              f"G'={c['gt']} cap={c['cap']:.0f} upl={c['upl']:.1f}")
    print("strongest:")
    for c in sorted(combos, key=lambda c: -c["gt"])[:6]:
        print(f"  {c['gage']} {c['pattern']} {c['sidelap']} ns={c['ns']} ${c['cost']:.0f}/cell "
              f"G'={c['gt']} cap={c['cap']:.0f} upl={c['upl']:.1f}")

    print("\nuniform 18 ga 36/9 SCREW ns=5:")
    z = uniform(dict(gage=18, pattern="36/9", sidelap="SCREW-10", ns=5))
    r = evaluate(z, verbose=True)
    for sid, d in r["lateral"].items():
        print(f"  {sid}: vmax={d['vmax']:.0f} plf defl={d['defl']:.3f} in chord={d['chord']:.1f} "
              f"collector={d['coll']:.1f} kip")
