"""Write the DC-2 roof deck deliverable: deck_design.xlsx, roof_deck_plan.dxf,
constraint_register.xlsx, design_basis.md, and zip them into submission.zip."""
from __future__ import annotations

import io
import json
import math
import os
import zipfile

import numpy as np
import openpyxl
import ezdxf

from . import design as DS
from . import fem as FM
from . import model as M
from . import tiling as T

OUT = "/work/ple-solve/roof-deck-design"


# ---------------------------------------------------------------------------
def sheet_zones(zones, assign):
    rows = [["zone_id", "x0_ft", "y0_ft", "x1_ft", "y1_ft", "gage", "support_pattern",
             "sidelap_type", "sidelap_per_span"]]
    for z in zones:
        for r in z["rects"]:
            rows.append([z["zone_id"], r[0], r[1], r[2], r[3], z["gage"], z["pattern"],
                         z["sidelap"], z["ns"]])
    return rows


def sheet_basis(res):
    fp = M.seismic_force_kip()[0]
    return [["key", "value"],
            ["PG_PSF", M.PG],
            ["CE", M.CE],
            ["CT", M.CT],
            ["IS", M.IS_],
            ["PF_PSF", round(M.PF, 3)],
            ["GAMMA_PCF", round(M.GAMMA, 2)],
            ["LR_PSF", M.LR],
            ["QH_PSF", round(M.QH, 2)],
            ["A_ZONE_FT", M.A_ZONE],
            ["SDS", M.SDS],
            ["IE", M.IE],
            ["R", M.R],
            ["W_SEISMIC_PSF", round(M.seismic_weight_psf(), 3)],
            ["FPX_KIP", round(fp, 2)],
            ["WIND_X_KIP", M.WIND_X],
            ["WIND_Y_KIP", M.WIND_Y],
            ["DIAPHRAGM_CLASS", res["classification"]]]


def sheet_drifts():
    rows = [["location", "face", "peak_surcharge_psf", "band_from_ft", "band_to_ft"]]
    for tag, face in M.DRIFT_FACES:
        peak, a, b = M.face_drift(tag, face)
        rows.append([tag, face, round(peak, 1), round(a, 2), round(b, 2)])
    return rows


def sheet_calc(zones, res):
    rows = [["zone_id", "governing_scenario", "shear_demand_plf", "shear_capacity_plf",
             "gravity_demand_psf", "gravity_capacity_psf", "uplift_demand_psf", "uplift_capacity_psf"]]
    f = res["fields"]
    assign = res["assign"]
    for zi, z in enumerate(zones):
        m = assign == zi
        if not m.any():
            continue
        w = res["zone_worst"][zi]
        rows.append([z["zone_id"], w["gov"] or "S01", round(w["shear"], 0),
                     round(float(f["shear_cap"][m].min()), 0), round(w["grav"], 1),
                     round(float(f["gravity_cap"][m].min()), 1), round(w["uplift"], 1),
                     round(float(f["uplift_cap"][m].min()), 1)])
    return rows


def sheet_diaphragm(res):
    rows = [["scenario", "direction", "max_shear_plf", "max_deflection_in", "chord_force_kip",
             "collector_force_kip", "classification"]]
    for sid in FM.LATERAL_SCEN:
        d = res["lateral"][sid]
        rows.append([sid, d["dirn"], round(d["vmax"], 0), round(d["defl"], 3), round(d["chord"], 1),
                     round(d["coll"], 1), res["classification"]])
    return rows


def sheet_bom(zones, res):
    assign = res["assign"]
    per_gage, n_sup, n_lap = {}, 0.0, 0.0
    for zi, z in enumerate(zones):
        n = int((assign == zi).sum())
        if not n:
            continue
        area = n * M.AREA_CELL
        per_gage[z["gage"]] = per_gage.get(z["gage"], 0.0) + area
        lines = area / (M.PANEL_WIDTH * M.JOIST_SPACING)
        n_sup += lines * M.PATTERNS[z["pattern"]]
        n_lap += lines * int(z["ns"])
    rows = [["item", "quantity", "unit"]]
    for g in sorted(per_gage):
        rows.append([f"deck area {g} gage", round(per_gage[g]), "sf"])
    rows.append(["support fasteners", round(n_sup), "ea"])
    rows.append(["sidelap connectors", round(n_lap), "ea"])
    return rows


def write_xlsx(path, sheets):
    wb = openpyxl.Workbook()
    first = True
    for name, rows in sheets:
        ws = wb.active if first else wb.create_sheet()
        ws.title = name
        first = False
        for r in rows:
            ws.append(r)
    wb.save(path)


# ---------------------------------------------------------------------------
def write_dxf(path, zones):
    doc = ezdxf.new("R2010", setup=True)
    doc.header["$INSUNITS"] = 2          # feet
    msp = doc.modelspace()
    for layer in ("S-DECK-ZONE", "S-DECK-TEXT", "S-FRAMING", "S-OPENING"):
        if layer not in doc.layers:
            doc.layers.add(layer)
    # framing: joist lines every 6 ft in x, girder lines every 30 ft in y
    for x in M.JOIST_X:
        msp.add_line((float(x), 0.0), (float(x), M.LY), dxfattribs={"layer": "S-FRAMING"})
    for y in M.GIRDER_Y:
        msp.add_line((0.0, float(y)), (M.LX, float(y)), dxfattribs={"layer": "S-FRAMING"})
    # roof openings
    for op in M.OPENINGS:
        msp.add_lwpolyline([(op["x0"], op["y0"]), (op["x1"], op["y0"]),
                            (op["x1"], op["y1"]), (op["x0"], op["y1"])], close=True,
                           dxfattribs={"layer": "S-OPENING"})
        msp.add_text(op["tag"], dxfattribs={"layer": "S-OPENING", "height": 2.0}).set_placement(
            (op["x0"] + 1.0, op["y0"] + 1.0))
    # zones
    for z in zones:
        biggest = max(z["rects"], key=lambda r: (r[2] - r[0]) * (r[3] - r[1]))
        for r in z["rects"]:
            msp.add_lwpolyline([(r[0], r[1]), (r[2], r[1]), (r[2], r[3]), (r[0], r[3])], close=True,
                               dxfattribs={"layer": "S-DECK-ZONE"})
        cx, cy = 0.5 * (biggest[0] + biggest[2]), 0.5 * (biggest[1] + biggest[3])
        msp.add_text(z["zone_id"], dxfattribs={"layer": "S-DECK-TEXT", "height": 3.0}).set_placement(
            (cx, cy))
    doc.saveas(path)


# ---------------------------------------------------------------------------
def register_rows():
    """One row per requirement the design applied, from the documents themselves."""
    EOR = "EOR-DC-RD-01 Rev 2 Structural Design Criteria - Roof"
    UFC = "UFC 3-301-01 Structural Engineering"
    ND = "NORDECK B-36 Roof Deck Design Manual 2026"
    LAT = "LAT-2026-003 Lateral Analysis Report"
    SNOW = "SNOW-2026-014 Site Specific Ground Snow Case Study"
    STOCK = "Deck Stock Availability 2026-07"
    OBD = "OBD-DC2-A Owners Basis of Design"
    JS = "Joist and Joist Girder Schedule"
    CP = "CP-RD-2026 Cost Plan Roof Deck"
    CFR = "29 CFR 1926 Subpart R Steel Erection"
    USGS = "USGS ASCE7-22 Design Maps"
    rows = [
        # id, document, clause, value, applies_to
        [SNOW, "6.1 Table 6-1 Result", "63 psf", "ground snow load pg, Risk Category II basis"],
        [UFC, "1608.2.3 / 2-4.5", "Risk Category II basis", "snow case study basis for pg"],
        [EOR, "5.1", "43.66 psf", "flat roof snow load pf = 0.7 Ce Ct Is pg"],
        [EOR, "5.1", "0.9", "exposure factor Ce"],
        [EOR, "2.1 Table 2-1", "1.1", "snow importance factor Is, Risk Category III"],
        [EOR, "5.2", "22.19 pcf", "snow density gamma, sets balanced depth and drifts"],
        [EOR, "5.3", "1.968 ft", "balanced snow depth hb"],
        [EOR, "5.4", "0.43", "drift height hd = 0.43 lu^(1/3) (pg+10)^(1/4) - 1.5"],
        [EOR, "5.4.2", "4", "drift width w = 4 hd, truncated at 8 hc"],
        [EOR, "5.4.3", "0.75", "windward drift height 0.75 hd"],
        [EOR, "5.4.4", "20 ft", "minimum fetch lu = 20 ft"],
        [EOR, "5.5", "2.0 ft", "obstruction becomes a drift source when hc exceeds this"],
        [UFC, "3-4.1 / 7.4", "snow buildup at rooftop obstructions", "rooftop equipment drifts"],
        [UFC, "Table E-1 item 51", "20 psf", "unreduced roof live load Lo"],
        [EOR, "4.2", "20 psf", "roof live load on the deck, no tributary reduction"],
        [EOR, "6.1", "29.93 psf", "velocity pressure qh"],
        [EOR, "6.1", "115 mph", "basic wind speed V, Risk Category III"],
        [EOR, "6.2.1", "12.8 ft", "components and cladding zone width a"],
        [EOR, "6.2.2 Table 6-2", "-3.2", "external pressure coefficient corner zone 3"],
        [EOR, "6.2.2 Table 6-2", "-2.3", "external pressure coefficient zone 2"],
        [EOR, "6.2.2 Table 6-2", "-1.4", "external pressure coefficient zone 1"],
        [EOR, "6.2.2 Table 6-2", "-0.9", "external pressure coefficient zone 1 prime"],
        [EOR, "6.2.2", "0.18", "internal pressure coefficient GCpi"],
        [EOR, "6.2.3", "0.9", "dead load factor resisting uplift"],
        [LAT, "4.1 Table 4-1", "118 kip", "roof-level wind force along x"],
        [LAT, "4.1 Table 4-1", "152 kip", "roof-level wind force along y"],
        [LAT, "4.3", "0.15", "wind Case 2 eccentricity factor"],
        [USGS, "asce7-22", "0.44 g", "design spectral response acceleration SDS, Risk Category III Site Class D"],
        [EOR, "7.1", "0.44 g", "design spectral response acceleration SDS"],
        [EOR, "7.1", "0.24 g", "design spectral response acceleration SD1"],
        [EOR, "7.1", "1.25", "seismic importance factor Ie"],
        [EOR, "7.1", "3.25", "response modification coefficient R"],
        [EOR, "7.2", "0.2", "fraction of flat roof snow load added to the effective seismic weight"],
        [EOR, "7.2", "18 psf", "roof dead weight for the effective seismic weight"],
        [EOR, "7.3", "0.05", "accidental torsion eccentricity fraction of the plan dimension"],
        [EOR, "7.4", "2.0", "overstrength factor on collectors and their connections"],
        [LAT, "5.1", "0.1692", "seismic response coefficient Cs = SDS Ie / R"],
        [LAT, "5", "3.25", "response modification coefficient R in the diaphragm design force"],
        [LAT, "2.4", "30 ft", "drag strut extent each side of a braced bay"],
        [LAT, "3.1 Table 3-1", "55 kip/in", "roof-level stiffness of braced frames BF-X1 and BF-X2"],
        [LAT, "3.1 Table 3-1", "18 kip/in", "roof-level stiffness of braced frames BF-X3 and BF-X4"],
        [LAT, "3.1 Table 3-1", "22 kip/in", "roof-level stiffness of braced frames BF-Y1 and BF-Y2"],
        [LAT, "3.1 Table 3-1", "68 kip/in", "roof-level stiffness of braced frames BF-Y3 and BF-Y4"],
        [LAT, "6.1 Table 6-1", "115.2 kip", "design tensile capacity of the perimeter chord edge angle"],
        [LAT, "6.2.1", "38.0 kip", "chord splice capacity, which governs the chord line"],
        [LAT, "6.2 Table 6-1", "344.2 kip", "design tensile capacity of the collector W12x26"],
        [LAT, "6.2.1", "58.0 kip", "collector splice capacity, which governs the collector"],
        [LAT, "6.3 Table 6-2", "87580 kip", "axial stiffness EA of a joist in the in-plane model"],
        [LAT, "6.3 Table 6-2", "221850 kip", "axial stiffness EA of a joist girder"],
        [LAT, "6.3 Table 6-2", "74240 kip", "axial stiffness EA of the perimeter edge member"],
        [ND, "3.1 Table 3-1", "177 psf", "allowable uniform total load, 18 gage at the 6 ft span"],
        [ND, "3.1 Table 3-1", "130 psf", "allowable uniform total load, 20 gage at the 6 ft span"],
        [ND, "3.1 Table 3-1", "106 psf", "allowable uniform total load, 22 gage at the 6 ft span"],
        [ND, "3.1", "1.67", "bending safety factor Omega_b in the allowable load table"],
        [ND, "3.3", "0.0069", "three-span continuous deflection coefficient"],
        [ND, "3.3", "29500 ksi", "modulus of elasticity E used in the deflection basis"],
        [ND, "4.1 Table 4-1", "2310 lb/ft", "allowable end reaction, 18 gage at 1.5 in bearing"],
        [ND, "5.2", "480 plf", "reference nominal diaphragm shear strength, 20 gage 36/4 2 screws"],
        [ND, "5.2", "12.0 kip/in", "reference diaphragm shear stiffness G prime"],
        [ND, "5.2", "0.0358 in", "reference design thickness t20"],
        [ND, "6.1", "0.216 in", "support fastener head diameter d_head"],
        [ND, "6.2", "0.85", "pull-over coefficient Pnov = 0.85 d t Fu"],
        [ND, "6.2", "55 ksi", "tensile strength Fu of the deck sheet"],
        [ND, "6.3", "36 in", "cover width tributary to one 36/n support fastener"],
        [ND, "6.4 Table 6-2", "310 lb", "nominal strength Qs of the SCREW-10 sidelap connector"],
        [ND, "6.4 Table 6-2", "95 lb", "nominal strength Qs of the BP button punch"],
        [ND, "5.8", "20 gage", "thinnest gage on which a button punch sidelap is permitted"],
        [EOR, "10.1", "0.70", "resistance factor on diaphragm shear phi_d"],
        [EOR, "10.1", "0.50", "resistance factor on fastener tension phi_t"],
        [EOR, "10.2", "3", "maximum number of attachment patterns on the roof"],
        [EOR, "10.2", "2", "maximum number of deck gages on the roof"],
        [EOR, "10.2", "12", "maximum number of deck zones on the roof"],
        [EOR, "10.2", "6 ft", "zone boundary module along the joist direction"],
        [EOR, "10.3", "36 in", "maximum sidelap connector spacing"],
        [EOR, "10.4", "3", "minimum sidelap connectors per span on the boundary and at opening edges"],
        [EOR, "10.4", "36/7", "minimum support pattern on the boundary and at opening edges"],
        [EOR, "10.5", "deck not placed over a framed roof opening", "framed roof openings"],
        [EOR, "10.6", "1.5 in", "minimum deck bearing on each support"],
        [CFR, "1926.754(e)(3)", "cover secured and marked", "any cover used over an opening"],
        [CFR, "1926.754(e)(5)", "deck laid tight and secured", "deck placement"],
        [EOR, "9.1", "240", "deck live-load deflection limit span/240"],
        [EOR, "9.1", "0.75 in", "construction-stage deflection limit of the bare deck"],
        [UFC, "1604.3.1", "most restrictive deflection limit", "basis of the deflection limit"],
        [EOR, "9.2", "1.6 in", "limit on the in-plane deflection of the roof diaphragm"],
        [EOR, "9.3", "2.0", "deflection ratio at which the diaphragm classifies as flexible"],
        [EOR, "9.3", "0.015", "allowable storey drift fraction, Risk Category III"],
        [EOR, "8.1", "0.9D + 1.0W", "load combination for net roof uplift"],
        [EOR, "8.1", "1.0E", "load combination for in-plane diaphragm, chord and collector force"],
        [STOCK, "Availability", "14 weeks", "mill lead time for 16 gage, exceeds the programme"],
        [OBD, "5", "9 weeks", "release-to-site allowance the deck material must fit"],
        [JS, "N1 Notes", "1.5 in", "minimum deck bearing on every support"],
        [CP, "Rates", "1.35 USD", "installed cost of one support fastener"],
        [CP, "Rates", "3.05 USD", "installed cost of 22 gage deck per sq ft"],
        [CP, "Rates", "3.48 USD", "installed cost of 20 gage deck per sq ft"],
        [CP, "Rates", "4.42 USD", "installed cost of 18 gage deck per sq ft"],
        [CP, "Rates", "1.15 USD", "installed cost of one SCREW-10 sidelap connector"],
        [CP, "Rates", "0.32 USD", "installed cost of one BP button punch"],
        [CP, "Indirects", "900 USD", "zone set-up cost per distinct deck zone"],
        [CP, "Indirects", "260 USD", "rectangle set-up cost per separate rectangle"],
        [CP, "Indirects", "4800 USD", "gage set-up cost per distinct gage"],
        [CP, "Indirects", "1400 USD", "pattern set-up cost per distinct attachment pattern"],
    ]
    return [["document", "clause", "value", "applies_to"]] + rows


# ---------------------------------------------------------------------------
def design_basis(res, zones):
    fp, w_kip = M.seismic_force_kip()
    rows = []
    add = rows.append
    add("# DC-2 Helena Data Centre, Building A - roof deck design basis\n")
    add("Project DC2-2026-014. Prepared against EOR-DC-RD-01 Rev 2 (31 July 2026), LAT-2026-003 Rev 1, "
        "the NORDECK B-36 catalogue (2026) and the cost plan CP-RD-2026.\n")
    add("## 1. Documents that governed, and the ones that did not\n")
    add("The roof structure model DC2-A-STR Rev C governs every plan position: its transmittal note says "
        "so in terms, and it is the only document that carries the equipment and screen walls in three "
        "dimensions. The two-dimensional drawings do not all agree with it. The equipment screen wall "
        "SCR-N sits on grid y = 164 ft in the model and on the current architectural plan A-201 Rev C; "
        "the superseded A-201 Rev B put it at y = 158 ft, and Rev B is an archived sheet, so the drift "
        "band it would produce is not the one designed to. The ground snow load comes from the "
        "site-specific case study SNOW-2026-014, which reports 63 psf on a Risk Category II basis as the "
        "case study provisions require; the criteria apply the Risk Category III importance factor Is = "
        "1.10 to it once, and it is not applied twice. Of the two USGS design maps in the project folder, "
        "the 2019 preliminary map is Risk Category II on Site Class C and is not this project; the "
        "ASCE 7-22 map for Risk Category III on Site Class D gives SDS = 0.44 g, SD1 = 0.24 g, seismic "
        "design category D, and that is what the seismic checks use. The 2019 Hall A deck design is a "
        "different building in a different town and governs nothing here.\n")
    add("## 2. Snow\n")
    add("pf = 0.7 Ce Ct Is pg = 0.7 x 0.90 x 1.00 x 1.10 x 63 = %.2f psf, with Ce = 0.90 for a "
        "partially exposed roof in Terrain Category C that carries a continuous parapet, the enclosure "
        "and twelve rooftop units, and Ct = 1.0 for a continuously conditioned building. Snow density is "
        "gamma = 0.13 pg + 14 = 22.19 pcf, so the balanced depth is hb = pf/gamma = %.3f ft. Every clear "
        "height is measured from the top of the balanced snow, hc = h - hb.\n" % (M.PF, M.HB))
    add("Drifts follow criteria 5.4 exactly: hd = 0.43 lu^(1/3) (pg + 10)^(1/4) - 1.5, a fetch shorter "
        "than 20 ft taken as 20 ft, a triangular surcharge of peak hd gamma and width 4 hd where hd <= hc, "
        "and a peak hc gamma with width min(4 hd^2/hc, 8 hc) where the obstruction truncates the drift. "
        "Each obstruction forms a windward drift of height 0.75 hd (fetch = the roof upwind of that face) "
        "and a leeward drift of height hd (fetch = the along-wind length of the obstruction itself), wind "
        "from each of the four directions in turn, and the largest of the four at a point governs; the "
        "four directions are not superimposed. An obstruction whose clear height does not exceed 2.0 ft "
        "is not a drift source, and that test is on hc, not on the bare height. The parapet is treated "
        "by the windward rule with no height threshold.\n")
    for tag, face in M.DRIFT_FACES:
        peak, a, b = M.face_drift(tag, face)
        add("* %s on face %s: peak surcharge %.1f psf above the balanced load, band %.2f to %.2f ft.\n"
            % (tag, face, peak, a, b))
    add("\nThe deck is a local element, so each zone carries the peak surcharge anywhere inside it, not "
        "an average (criteria 5.4.7).\n")
    add("## 3. Roof live load\n")
    add("UFC 3-301-01 Table E-1 item 51 gives Lo = 20 psf for an ordinary flat roof, and the criteria "
        "replace the code live load table with it. A deck panel's tributary area is 3 ft x 6 ft = 18 sq ft, "
        "far below the 200 sq ft threshold at which R1 becomes available, so the deck is designed for the "
        "unreduced 20 psf; the tributary reduction the joists and girders take is a member-by-member "
        "result and is not carried back into the deck.\n")
    add("## 4. Wind uplift\n")
    add("qh = 0.00256 Kz Kzt Kd Ke V^2 = 0.00256 x 1.04 x 1.0 x 0.85 x 1.0 x 115^2 = %.2f psf. The "
        "components and cladding zone width is a = min(0.1 x 180, 0.4 x 32) = 12.8 ft, so 2a = 25.6 ft. "
        "Zone 3 is the corner square of side a, zone 2 the remaining band of width a, zone 1 the band "
        "from a to 2a, and zone 1 prime the interior. The net pressure is qh (GCp - GCpi) with the "
        "internal pressure acting to increase the uplift (GCpi = +0.18 against a negative GCp), resisted "
        "by 0.9 x (deck self weight + 4.5 psf roofing). The suspended mechanical allowance of 6.0 psf is "
        "not available to hold the deck down and is excluded from that resistance. The corner zone "
        "governs the attachment: at 18 gage the demand is %.1f psf against a factored capacity of "
        "119.7 psf for a 36/9 pattern.\n" % (M.QH, float(M.uplift_demand(np.full((M.NX, M.NY), 2.5)).max())))
    add("## 5. Seismic\n")
    add("The flat roof snow load %.2f psf exceeds the 30 psf threshold of criteria 7.2, so twenty per "
        "cent of it belongs in the effective seismic weight: w = 18 + 0.2 x %.2f = %.2f psf over the "
        "%.0f sq ft roof, W = %.1f kip. With Cs = SDS Ie / R = 0.44 x 1.25 / 3.25 = 0.1692, the roof "
        "diaphragm design force is Fpx = Cs W = %.1f kip, which sits inside the 12.10.1 bounds of "
        "0.2 SDS Ie W = %.1f kip and 0.4 SDS Ie W = %.1f kip. Omitting the snow term, as the report warns, "
        "would understate every seismic demand on the diaphragm, its chords and its collectors.\n"
        % (M.PF, M.PF, M.seismic_weight_psf(), M.LX * M.LY, w_kip, fp,
           0.2 * M.SDS * M.IE * w_kip, 0.4 * M.SDS * M.IE * w_kip))
    add("Accidental torsion is 0.05 of the plan dimension perpendicular to the force, and the collectors "
        "are amplified by Omega_0 = 2.0 before they are compared with capacity, as criteria 7.4 requires; "
        "the chord is not amplified.\n")
    add("## 6. How the diaphragm was analysed and classified\n")
    add("The roof was analysed as the in-plane assembly LAT-2026-003 section 7 describes: shear panels one "
        "joist bay (6 ft) wide by one girder bay (30 ft) deep carrying pure shear at the G' of the deck "
        "actually selected, with the five 6 ft strips across each panel acting in series, axial bars along "
        "every joist line (EA = 87,580 kip, plus 74,240 kip of edge angle on the boundary lines) and every "
        "girder line (EA = 221,850 kip), and each braced frame as a spring of half its Table 3-1 stiffness "
        "at each of its two column lines. Wind enters along the two wall lines perpendicular to the force, "
        "half at each; the seismic force is spread by tributary area; the eccentricity is applied as a plan "
        "couple. The deck's own G' is what distributes the force, so the design and the analysis are "
        "solved together: the attachment was raised where the shear concentrates at the stiff frames on "
        "grid 9 (BF-Y3 and BF-Y4, 68 kip/in each), and it cannot be raised everywhere, because a stiffer "
        "diaphragm drags more force into the collector of the stiff frame line and the collector splice is "
        "the limit it runs into (LAT-2026-003 6.2.1).\n")
    add("The classification is computed, not assumed: the largest ratio of diaphragm deflection to average "
        "braced-frame drift over the five lateral cases is %.2f, and criteria 9.3 classifies the diaphragm "
        "as flexible above 2.0, so the roof is %s. The largest in-plane deflection is %.2f in against the "
        "1.60 in limit of criteria 9.2.\n"
        % (res["flexible_ratio"], res["classification"],
           max(d["defl"] for d in res["lateral"].values())))
    add("## 7. Zoning decisions, and what drove each one\n")
    add("Every zone boundary falls on the 6 ft module in both directions (criteria 10.2), no rectangle "
        "covers a framed roof opening (10.5), and the rectangles do not overlap and leave no deck cell "
        "unassigned. The layout follows the loads rather than a grid for its own sake:\n")
    add("* The band at the screen wall (y = 150 to 180 ft, carrying the SCR-N windward drift of 89.5 psf "
        "and the north parapet drift) is 18 gage: at the drift peak the live load reaches %.0f psf, where "
        "20 gage would exceed both its 130 psf allowable uniform load and the span/240 deflection limit.\n"
        % float(M.live_component('S04').max()))
    add("* The roof under the MEP-PH-1 enclosure is the cheapest deck on the roof. The enclosure throws "
        "its drifts outside its own four faces, so that 120 ft by 60 ft area carries the balanced load "
        "only, and 22 gage satisfies gravity, deflection and uplift there.\n")
    add("* The south band (y = 24 to 48 ft) and the strips beside the enclosure and RO-3 carry the rooftop "
        "unit and enclosure drifts and are 18 gage.\n")
    add("* The east band (x = 216 to 240 ft) is the strongest attachment on the roof (36/9 external, four "
        "sidelap connectors per span) because the seismic-Y shear concentrates at BF-Y3 and BF-Y4; the same "
        "band carries the south-east and north-east corner uplift of the zone 3 square.\n")
    add("* Every zone touches either the diaphragm boundary or the edge of a framed opening, so every zone "
        "is held to the 36/7 support pattern and at least 3 sidelap connectors per span that criteria 10.4 "
        "requires; no zone uses a button punch, because a button punch is not permitted on 18 gage and the "
        "18 gage areas must not be split off into a separate pattern to save a few cents a connector.\n")
    add("\nZones:\n")
    for z in zones:
        n = int((res["assign"] == zones.index(z)).sum())
        add("* %s: %d sq ft, %s gage, %s support pattern, %s x %d per span.\n"
            % (z["zone_id"], n * M.AREA_CELL, z["gage"], z["pattern"], z["sidelap"], z["ns"]))
    add("\n## 8. Economy\n")
    add("Installed cost at the CP-RD-2026 rates is $%s: deck area, support fasteners and sidelap "
        "connectors at the unit rates, plus one zone set-up per zone, one rectangle set-up per rectangle, "
        "one gage set-up per gage and one pattern set-up per pattern. 16 gage is not available for this "
        "programme: its mill lead time is 14 weeks against the 9 week release-to-site allowance, so the "
        "design uses only stocked gages.\n" % f"{res['cost']:,.0f}")
    return "".join(rows)


# ---------------------------------------------------------------------------
def emit(zones, res, outdir=OUT):
    os.makedirs(outdir, exist_ok=True)
    design_xlsx = os.path.join(outdir, "deck_design.xlsx")
    write_xlsx(design_xlsx, [
        ("Zones", sheet_zones(zones, res["assign"])),
        ("DesignBasis", sheet_basis(res)),
        ("Drifts", sheet_drifts()),
        ("CalcSummary", sheet_calc(zones, res)),
        ("Diaphragm", sheet_diaphragm(res)),
        ("BOM", sheet_bom(zones, res)),
    ])
    dxf = os.path.join(outdir, "roof_deck_plan.dxf")
    write_dxf(dxf, zones)
    reg = os.path.join(outdir, "constraint_register.xlsx")
    write_xlsx(reg, [("Register", register_rows())])
    md = os.path.join(outdir, "design_basis.md")
    open(md, "w").write(design_basis(res, zones))
    zpath = os.path.join(outdir, "submission.zip")
    with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as z:
        for p in (design_xlsx, dxf, reg, md):
            z.write(p, os.path.basename(p))
    return zpath
