"""Semi-rigid roof diaphragm FE, built from the description in the deck instruction / LAT-2026-003 7.

Shear panels one joist bay (6 ft) wide by one girder bay (30 ft) deep carrying pure shear at the
deck's G'; the five 6 ft strips across a panel act in series (harmonic mean of G', smallest capacity).
Axial bars along every joist line and every girder line with the EA of LAT Table 6-2, the perimeter
edge member added on the boundary lines, and each braced frame as a spring of half its stiffness at
each of its two column lines.  A 1e-3 kip/in spring on every free dof regularises the solution; a
scenario where those springs carry more than 2 % of the applied force has no load path.
"""
from __future__ import annotations

import numpy as np

from . import model as M

REG_SPRING = 1.0e-3
REG_SHARE_LIMIT = 0.02

# LAT-2026-003 Table 6-2 and Table 6-1
JOIST_EA = 87580.0
GIRDER_EA = 221850.0
EDGE_EA = 74240.0
CHORD_CAP = 115.2
CHORD_SPLICE = 38.0
COLLECTOR_CAP = 344.25
COLLECTOR_SPLICE = 58.0

# LAT-2026-003 Table 3-1
FRAMES = [
    dict(tag="BF-X1", dir="X", line=0.0, lo=30.0, hi=60.0, k=55.0),
    dict(tag="BF-X2", dir="X", line=0.0, lo=180.0, hi=210.0, k=55.0),
    dict(tag="BF-X3", dir="X", line=180.0, lo=60.0, hi=90.0, k=18.0),
    dict(tag="BF-X4", dir="X", line=180.0, lo=150.0, hi=180.0, k=18.0),
    dict(tag="BF-Y1", dir="Y", line=0.0, lo=30.0, hi=60.0, k=22.0),
    dict(tag="BF-Y2", dir="Y", line=0.0, lo=120.0, hi=150.0, k=22.0),
    dict(tag="BF-Y3", dir="Y", line=240.0, lo=60.0, hi=90.0, k=68.0),
    dict(tag="BF-Y4", dir="Y", line=240.0, lo=90.0, hi=120.0, k=68.0),
]


class Diaphragm:
    def __init__(self):
        self.xs_ft = M.JOIST_X.copy()
        self.ys_ft = M.GIRDER_Y.copy()
        self.xs = self.xs_ft * 12.0
        self.ys = self.ys_ft * 12.0
        self.nxn, self.nyn = len(self.xs_ft), len(self.ys_ft)
        self.nel_x, self.nel_y = self.nxn - 1, self.nyn - 1
        self.ndof = 2 * self.nxn * self.nyn
        self._build_static()

    def idx(self, i, j):
        return j * self.nxn + i

    def _elem_dofs(self, i, j):
        n = [self.idx(i, j), self.idx(i + 1, j), self.idx(i + 1, j + 1), self.idx(i, j + 1)]
        return np.array([d for k in n for d in (2 * k, 2 * k + 1)])

    def _shear_B(self, i, j):
        a = self.xs[i + 1] - self.xs[i]
        b = self.ys[j + 1] - self.ys[j]
        B = np.array([-1 / (2 * b), -1 / (2 * a),
                      -1 / (2 * b), 1 / (2 * a),
                      1 / (2 * b), 1 / (2 * a),
                      1 / (2 * b), -1 / (2 * a)])
        return B, a * b

    def _build_static(self):
        K = np.zeros((self.ndof, self.ndof))
        bars = []
        for i in range(self.nxn):
            edge = i in (0, self.nxn - 1)
            EA = JOIST_EA + (EDGE_EA if edge else 0.0)
            for j in range(self.nyn - 1):
                L = self.ys[j + 1] - self.ys[j]
                k = EA / L
                di, dj = 2 * self.idx(i, j) + 1, 2 * self.idx(i, j + 1) + 1
                bars.append((di, dj, k, f"JY-{i}-{j}", "Y", i, j))
        for j in range(self.nyn):
            edge = j in (0, self.nyn - 1)
            EA = GIRDER_EA + (EDGE_EA if edge else 0.0)
            for i in range(self.nxn - 1):
                L = self.xs[i + 1] - self.xs[i]
                k = EA / L
                di, dj = 2 * self.idx(i, j), 2 * self.idx(i + 1, j)
                bars.append((di, dj, k, f"GX-{i}-{j}", "X", i, j))
        for di, dj, k, *_ in bars:
            K[di, di] += k
            K[dj, dj] += k
            K[di, dj] -= k
            K[dj, di] -= k
        self.bars = bars
        self.frame_dofs = {}
        for fr in FRAMES:
            if fr["dir"] == "X":
                j = int(np.argmin(np.abs(self.ys_ft - fr["line"])))
                nodes = [self.idx(int(np.argmin(np.abs(self.xs_ft - c))), j) for c in (fr["lo"], fr["hi"])]
                dofs = [2 * n for n in nodes]
            else:
                i = int(np.argmin(np.abs(self.xs_ft - fr["line"])))
                nodes = [self.idx(i, int(np.argmin(np.abs(self.ys_ft - c)))) for c in (fr["lo"], fr["hi"])]
                dofs = [2 * n + 1 for n in nodes]
            for d in dofs:
                K[d, d] += 0.5 * fr["k"]
            self.frame_dofs[fr["tag"]] = (dofs, fr["k"], fr["dir"])
        K[np.diag_indices_from(K)] += REG_SPRING
        self.K_static = K

    # -- deck contribution ---------------------------------------------------
    def element_deck(self, gt_cells, cap_cells):
        ncy = int(round((self.ys_ft[1] - self.ys_ft[0]) / M.ZONE_GRID))
        g = gt_cells.reshape(self.nel_x, self.nel_y, ncy)
        c = cap_cells.reshape(self.nel_x, self.nel_y, ncy)
        with np.errstate(divide="ignore"):
            inv = np.where(g > 1e-9, 1.0 / np.maximum(g, 1e-9), np.inf)
        gt_el = np.where(np.isinf(inv).any(axis=2), 0.0,
                         ncy / np.where(np.isinf(inv), 1.0, inv).sum(axis=2))
        return gt_el, c.min(axis=2)

    def assemble(self, gt_el):
        K = self.K_static.copy()
        for i in range(self.nel_x):
            for j in range(self.nel_y):
                gt = gt_el[i, j]
                if gt <= 1e-9:
                    continue
                B, A = self._shear_B(i, j)
                d = self._elem_dofs(i, j)
                K[np.ix_(d, d)] += gt * A * np.outer(B, B)
        return K

    def load_vector(self, direction, total_kip, ecc_ft, pattern):
        F = np.zeros(self.ndof)
        comp = 0 if direction == "X" else 1
        w = np.zeros((self.nxn, self.nyn))
        if pattern == "mass":
            for i in range(self.nxn):
                fx = 0.5 if i in (0, self.nxn - 1) else 1.0
                for j in range(self.nyn):
                    fy = 0.5 if j in (0, self.nyn - 1) else 1.0
                    w[i, j] = fx * fy
        else:
            if direction == "X":
                for i in (0, self.nxn - 1):
                    for j in range(self.nyn):
                        w[i, j] = 0.5 if j in (0, self.nyn - 1) else 1.0
            else:
                for j in (0, self.nyn - 1):
                    for i in range(self.nxn):
                        w[i, j] = 0.5 if i in (0, self.nxn - 1) else 1.0
        w /= w.sum()
        for i in range(self.nxn):
            for j in range(self.nyn):
                F[2 * self.idx(i, j) + comp] += total_kip * w[i, j]
        if abs(ecc_ft) > 1e-9:
            Mm = total_kip * ecc_ft * 12.0
            cx, cy = 0.5 * M.LX * 12.0, 0.5 * M.LY * 12.0
            rx = np.array([self.xs[i] - cx for i in range(self.nxn)])
            ry = np.array([self.ys[j] - cy for j in range(self.nyn)])
            J = 0.0
            for i in range(self.nxn):
                for j in range(self.nyn):
                    J += w[i, j] * (rx[i] ** 2 + ry[j] ** 2)
            if J > 0:
                for i in range(self.nxn):
                    for j in range(self.nyn):
                        s = Mm * w[i, j] / J
                        F[2 * self.idx(i, j)] += -s * ry[j]
                        F[2 * self.idx(i, j) + 1] += s * rx[i]
        return F

    def solve(self, gt_el, cap_el, direction, total_kip, ecc_ft, pattern, omega=1.0):
        K = self.assemble(gt_el)
        F = self.load_vector(direction, total_kip, ecc_ft, pattern)
        try:
            u = np.linalg.solve(K, F)
        except np.linalg.LinAlgError:
            return None
        if not np.all(np.isfinite(u)):
            return None
        q = np.zeros((self.nel_x, self.nel_y))
        for i in range(self.nel_x):
            for j in range(self.nel_y):
                if gt_el[i, j] <= 1e-9:
                    continue
                B, _ = self._shear_B(i, j)
                q[i, j] = gt_el[i, j] * float(B @ u[self._elem_dofs(i, j)])
        v_plf = np.abs(q) * 12000.0
        bar_force = {tag: k * (u[dj] - u[di]) for di, dj, k, tag, *_ in self.bars}
        react = {tag: sum(0.5 * k * u[d] for d in dofs)
                 for tag, (dofs, k, dr) in self.frame_dofs.items()}
        reg = REG_SPRING * u
        comp = 0 if direction == "X" else 1
        applied = np.abs(F[comp::2]).sum()
        reg_share = float(np.abs(reg[comp::2]).sum() / applied) if applied > 0 else 1.0
        frame_disp = [abs(sum(u[d] for d in dofs) / len(dofs))
                      for tag, (dofs, k, dr) in self.frame_dofs.items() if dr == direction]
        avg_frame = float(np.mean(frame_disp)) if frame_disp else 0.0
        max_disp = float(np.abs(u[comp::2]).max())
        return dict(v_plf=v_plf, cap_plf=cap_el, bar_force=bar_force, reactions=react,
                    reg_share=reg_share, max_disp_in=max_disp, avg_frame_disp_in=avg_frame,
                    diaphragm_defl_in=max(max_disp - avg_frame, 0.0), omega=omega, u=u)

    def chord_force_kip(self, res, direction):
        if direction == "X":
            tags = [t for t in res["bar_force"]
                    if t.startswith("JY-") and int(t.split("-")[1]) in (0, self.nxn - 1)]
        else:
            tags = [t for t in res["bar_force"]
                    if t.startswith("GX-") and int(t.split("-")[2]) in (0, self.nyn - 1)]
        return max((abs(res["bar_force"][t]) for t in tags), default=0.0)

    def collector_force_kip(self, res, direction):
        best = 0.0
        for fr in FRAMES:
            if fr["dir"] != direction:
                continue
            if direction == "X":
                j = int(np.argmin(np.abs(self.ys_ft - fr["line"])))
                for i in range(self.nel_x):
                    x0, x1 = self.xs_ft[i], self.xs_ft[i + 1]
                    if x1 <= fr["lo"] or x0 >= fr["hi"]:
                        continue
                    best = max(best, abs(res["bar_force"].get(f"GX-{i}-{j}", 0.0)))
                for i in range(self.nel_x):
                    x0, x1 = self.xs_ft[i], self.xs_ft[i + 1]
                    if (fr["lo"] - M.ZONE_GRID * 5 <= x1 <= fr["lo"]
                            or fr["hi"] <= x0 <= fr["hi"] + M.ZONE_GRID * 5):
                        best = max(best, abs(res["bar_force"].get(f"GX-{i}-{j}", 0.0)))
            else:
                i = int(np.argmin(np.abs(self.xs_ft - fr["line"])))
                for j in range(self.nel_y):
                    y0, y1 = self.ys_ft[j], self.ys_ft[j + 1]
                    if y1 <= fr["lo"] - 30.0 or y0 >= fr["hi"] + 30.0:
                        continue
                    best = max(best, abs(res["bar_force"].get(f"JY-{i}-{j}", 0.0)))
        return best


# ---------------------------------------------------------------------------
# scenarios
# ---------------------------------------------------------------------------
GRAVITY_SCEN = ["S01", "S02", "S03", "S04"]
LATERAL_SCEN = ["S05", "S06", "S07", "S08", "S10"]


def lateral_case(scenario):
    fp, _ = M.seismic_force_kip()
    if scenario == "S05":
        return "X", M.WIND_X, M.WIND_ECC * M.LY, "edge", 1.0
    if scenario == "S06":
        return "Y", M.WIND_Y, M.WIND_ECC * M.LX, "edge", 1.0
    if scenario == "S07":
        return "X", fp, M.ACC_ECC * M.LY, "mass", 1.0
    if scenario == "S08":
        return "Y", fp, M.ACC_ECC * M.LX, "mass", 1.0
    if scenario == "S10":
        return "X", fp, M.ACC_ECC * M.LY, "mass", M.OMEGA0
    raise ValueError(scenario)
