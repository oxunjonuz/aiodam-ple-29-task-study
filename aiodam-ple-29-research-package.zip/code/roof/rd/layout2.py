"""Second layout: horizontal bands with the drift bands merged, fewer set-ups, cheaper patterns.

Same physics as layout.layout_with_east_band, but the enclosure band is split only where the drift
is: the two vertical drift strips beside MEP-PH-1 rather than the whole 60 ft band.
"""
from __future__ import annotations

import numpy as np

from . import model as M
from . import tiling as T
from .layout import rect_mask


def layout_bands():
    deck = M.deck_mask()
    tiles = []
    # south band (contains the south corners -> must carry the corner uplift attachment)
    tiles.append(rect_mask(0, 0, 240, 24))
    # rooftop-unit drift band together with the south face of the enclosure (RO-1 cut out)
    tiles.append(rect_mask(0, 24, 240, 48))
    tiles.append(rect_mask(0, 48, 96, 60))
    tiles.append(rect_mask(108, 48, 240, 60))
    # enclosure band: west clearance, the drift strip on the west face, the roof under the
    # enclosure, the drift strip on the east face (RO-3 cut out below)
    tiles.append(rect_mask(0, 60, 42, 120))
    tiles.append(rect_mask(42, 60, 60, 120))
    tiles.append(rect_mask(60, 60, 180, 120))
    tiles.append(rect_mask(180, 60, 192, 120))
    tiles.append(rect_mask(192, 60, 240, 120))
    # north face of the enclosure (RO-2 cut out)
    tiles.append(rect_mask(0, 120, 240, 132))
    # screen-wall drift band and the north parapet, with the north corners inside it
    tiles.append(rect_mask(0, 132, 240, 180))
    return [t & deck for t in tiles]


if __name__ == "__main__":
    tiles = layout_bands()
    n = 0
    cover = np.zeros((M.NX, M.NY), dtype=int)
    for k, m in enumerate(tiles):
        r = T.decompose(m)
        n += len(r)
        cover += m.astype(int)
        print(f"tile {k}: {int(m.sum()):4d} cells -> {len(r)} rects {T.rects_ft(r)}")
    print(f"{len(tiles)} tiles, {n} rectangles, twice={int((cover>1).sum())}, "
          f"missing={int(((cover==0)&M.deck_mask()).sum())}")
