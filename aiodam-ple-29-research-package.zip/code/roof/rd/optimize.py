"""Coordinate-descent search over the zone combinations of a fixed tiling.

Each tile of the layout gets one catalogue combination; the search tries, tile by tile, the cheapest
combination that keeps the whole design inside every check, and repeats until nothing improves.
The score the task pays for is  0.40 p^2 + 0.40 G O + 0.20 A O  with O = bound / installed cost, so
once every family passes the only thing left to move is the cost.
"""
from __future__ import annotations

import json
import sys
import time

import numpy as np

from . import design as DS
from . import layout as LY
from . import model as M
from . import tiling as T


def make_assign(tiles, combos):
    return list(combos)


def evaluate(tiles, combos):
    zones = T.build_zones(tiles, combos)
    res = DS.evaluate(zones)
    ok, npatt, nzone, nrect, *rest = DS.cardinality_ok(zones, res["assign"])
    res["card_ok"] = ok and npatt and nzone and nrect
    res["n_patterns"], res["n_zones"], res["n_rects"] = rest[1], rest[2], rest[3]
    res["n_gages"] = rest[0]
    res["ok_all"] = res["ok"] and res["card_ok"]
    res["zones"] = zones
    return res


def search(tiles, start, cands, verbose=True, max_passes=6):
    combos = list(start)
    best = evaluate(tiles, combos)
    if verbose:
        print(f"start: ${best['cost']:,.0f} ok={best['ok_all']} problems={len(best['problems'])}")
        for p in best["problems"][:8]:
            print("   !", p)
    for p in range(max_passes):
        improved = False
        for k in range(len(tiles)):
            cur = combos[k]
            for c in cands[k]:
                if c is cur or (c["cost"] >= cur["cost"] and best["ok_all"]):
                    continue
                trial = list(combos)
                trial[k] = c
                r = evaluate(tiles, trial)
                if not r["ok_all"]:
                    continue
                if r["cost"] < best["cost"] - 1e-6:
                    combos, best, improved = trial, r, True
                    if verbose:
                        print(f"  pass {p} tile {k}: {cur['gage']}/{cur['pattern']}/{cur['sidelap']}/{cur['ns']}"
                              f" -> {c['gage']}/{c['pattern']}/{c['sidelap']}/{c['ns']}  ${r['cost']:,.0f}")
        if not improved:
            break
    return combos, best


def candidates_per_tile(tiles, cands, edge):
    out = []
    for m in tiles:
        loc = [c for c in cands if T.feasible_locally(c, m, edge)]
        if not loc:
            loc = [c for c in cands if T.perimeter_ok(c)]
        out.append(sorted(loc, key=lambda c: c["cost"]))
    return out


def main():
    cands = T.candidates()
    edge = T.edge_mask()
    tiles = LY.layout_with_east_band()
    per_tile = candidates_per_tile(tiles, cands, edge)
    for k, lst in enumerate(per_tile):
        print(f"tile {k}: {len(lst)} locally feasible candidates, cheapest "
              f"{lst[0]['gage']}/{lst[0]['pattern']}/{lst[0]['ns']} ${lst[0]['cost']:.0f}")
    strongest = [sorted(per_tile[k], key=lambda c: (-c["cap"], -c["gt"]))[0] for k in range(len(tiles))]
    t0 = time.time()
    combos, best = search(tiles, strongest, per_tile)
    print(f"\nsearch {time.time()-t0:.1f}s  cost ${best['cost']:,.0f} ok={best['ok_all']} "
          f"gages={best['n_gages']} patterns={best['n_patterns']} zones={best['n_zones']} rects={best['n_rects']}")
    for k, c in enumerate(combos):
        print(f"  tile {k}: {c['gage']} {c['pattern']} {c['sidelap']} ns={c['ns']} "
              f"G'={c['gt']} cap={c['cap']:.0f}")
    for p in best["problems"]:
        print("   !", p)
    json.dump([{k: v for k, v in c.items()} for c in combos], open("/work/ple-solve/roof/best_combos.json", "w"),
              indent=1, default=float)


if __name__ == "__main__":
    main()
