"""DC-2 roof deck: project model (geometry, loads, catalogue, cost) derived from the governing documents.

Sources, by document:
  geometry     15_model/DC2-A-STR_Roof_Structure_Model_RevC.ifc  (model note: Rev C governs over 2D)
  loads        project/30_structural/EOR-DC-RD-01_..._Rev2.pdf  clauses 2-9
  catalogue    project/70_procurement/NORDECK_B-36_Steel_Deck_Catalogue_2026.pdf
  cost         project/70_procurement/Cost_Plan_CP-RD-2026_Roof_Deck.xlsx
  stock        project/70_procurement/Deck_Stock_Availability_2026-07.xlsx (+ OBD section 5: 9 weeks)
  framing      project/30_structural/Joist_and_Joist_Girder_Schedule.xlsx + LAT-2026-003 section 6
  frames       project/30_structural/LAT-2026-003_Lateral_Analysis_Report.pdf Table 3-1
"""
from __future__ import annotations

import json
import math

import numpy as np

BASE = ("/work/ple-dataset/tasks/roof-deck-design/environment/filesystem/"
        "final_batch4__structural_task7_roof_deck_design__blind")
MM_PER_FT = 304.8                            # model note section 1: 1 ft = 304.8 mm
M_TO_FT = 3.280839895013123                  # tessellated world coordinates come back in metres


def _snap(v_m):
    """Metres -> feet, snapped to 0.0001 ft so that a grid coincidence stays exact."""
    return round(v_m * M_TO_FT, 4)

# ---------------------------------------------------------------------------
# geometry
# ---------------------------------------------------------------------------
LX, LY = 240.0, 180.0
JOIST_SPACING = 6.0        # S-101: joists at 6 ft-0 in o.c.
JOIST_SPAN = 30.0          # S-101: joists span 30 ft between joist girders
PANEL_WIDTH = 3.0          # 36 in cover width (catalogue clause 1.1)


def _ifc_geometry():
    """Plan rectangles (ft) of the rooftop obstructions and the framed openings, plus parapet height.

    Extruded solids are tessellated in world coordinates by ifcopenshell; the shape vertices come
    back in metres (the model is authored in mm and the unit scale is applied), so metres x 3.28084
    gives feet.
    """
    import ifcopenshell
    import ifcopenshell.geom as geom
    import ifcopenshell.util.element as ue

    path = f"{BASE}/15_model/DC2-A-STR_Roof_Structure_Model_RevC.ifc"
    f = ifcopenshell.open(path)
    st = geom.settings()
    st.set("use-world-coords", True)
    st.set("weld-vertices", False)

    def bbox(el):
        sh = geom.create_shape(st, el)
        v = sh.geometry.verts
        xs, ys, zs = v[0::3], v[1::3], v[2::3]
        # metres -> feet through the model note's 1 ft = 304.8 mm, snapped to 0.0001 ft (0.03 mm):
        # the conversion leaves 1e-14 noise, and with strict cell-overlap tests a coordinate that is
        # 96.000000000000014 instead of 96 drags in an extra row of removed deck cells.
        return dict(x0=_snap(min(xs)), y0=_snap(min(ys)), x1=_snap(max(xs)), y1=_snap(max(ys)),
                    z0=round(min(zs) * M_TO_FT, 4), z1=round(max(zs) * M_TO_FT, 4))

    def height(el):
        for k, v in ue.get_psets(el).items():
            if "HeightAboveRoof" in v:
                return v["HeightAboveRoof"] / MM_PER_FT
        return None

    ph, screens, rtus, openings = None, [], [], []
    for el in f.by_type("IfcBuildingElementProxy"):
        b = bbox(el)
        b.update(tag=el.Name, height_ft=height(el),
                 weight_lb=(ue.get_psets(el).get("Pset_RoofObstruction", {}).get("OperatingWeight")))
        if el.ObjectType and "ENCLOSURE" in el.ObjectType:
            ph = b
        elif el.ObjectType and "SCREEN" in el.ObjectType:
            screens.append(b)
        else:
            rtus.append(b)
    for el in f.by_type("IfcOpeningElement"):
        b = bbox(el)
        b.update(tag=el.Name)
        openings.append(b)
    parapet_h = None
    for el in f.by_type("IfcWall"):
        if el.PredefinedType == "PARAPET":
            parapet_h = height(el)
    for r in rtus:
        r["wt_lb"] = r.pop("weight_lb", None) or 0.0
    return dict(penthouse=ph, screen_walls=screens, rtus=rtus, openings=openings,
                parapet_ht_ft=parapet_h)


GEOM = _ifc_geometry()
PENTHOUSE = GEOM["penthouse"]
SCREENS = GEOM["screen_walls"]
RTUS = GEOM["rtus"]
OPENINGS = GEOM["openings"]
PARAPET_HT = GEOM["parapet_ht_ft"]


def screen_rect(w):
    """A screen wall is a line on the plan with a nominal thickness: M-401 schedules SCR-N and SCR-E
    as 204 x 0.5 ft and 120 x 0.5 ft, so the wall is the IFC centre line thickened to 0.5 ft.

    The IFC body is centred on the placement point, so the centre of the short axis is exact; its
    modelled thickness (203.2 mm) is replaced by the scheduled 0.5 ft.
    """
    x0, x1 = min(w["x0"], w["x1"]), max(w["x0"], w["x1"])
    y0, y1 = min(w["y0"], w["y1"]), max(w["y0"], w["y1"])
    if (y1 - y0) <= (x1 - x0):
        c = 0.5 * (y0 + y1)
        y0, y1 = c - 0.25, c + 0.25
    else:
        c = 0.5 * (x0 + x1)
        x0, x1 = c - 0.25, c + 0.25
    return x0, y0, x1, y1


# cell grid: 6 ft x 6 ft (joist spacing by sidelap module), criteria "checking conventions"
ZONE_GRID = 6.0
XS = np.arange(0.0, LX + 0.5 * ZONE_GRID, ZONE_GRID)      # 41 lines
YS = np.arange(0.0, LY + 0.5 * ZONE_GRID, ZONE_GRID)      # 31 lines
NX, NY = len(XS) - 1, len(YS) - 1                          # 40 x 30 cells
JOIST_X = XS.copy()                                        # every 6 ft
GIRDER_Y = np.arange(0.0, LY + 0.5 * JOIST_SPAN, JOIST_SPAN)   # 0,30,...,180

_CCX = 0.5 * (XS[:-1] + XS[1:])
_CCY = 0.5 * (YS[:-1] + YS[1:])
CELL_X, CELL_Y = np.meshgrid(_CCX, _CCY, indexing="ij")


def _cells_touched(x0, y0, x1, y1):
    """Cells any part of which lies inside the rectangle (a cell must carry the worst inside it)."""
    m = np.zeros((NX, NY), dtype=bool)
    m[(XS[:-1] < x1) & (XS[1:] > x0), :] = True
    col = (YS[:-1] < y1) & (YS[1:] > y0)
    m[:, ~col] = False
    return m


def opening_mask():
    m = np.zeros((NX, NY), dtype=bool)
    for op in OPENINGS:
        m |= _cells_touched(op["x0"], op["y0"], op["x1"], op["y1"])
    return m


def deck_mask():
    """Every cell carries deck except those a framed opening touches (criteria 10.5)."""
    return ~opening_mask()


# ---------------------------------------------------------------------------
# loads (EOR-DC-RD-01 Rev 2)
# ---------------------------------------------------------------------------
PG = 63.0            # snow case study SNOW-2026-014, RC II basis (clause 5.1)
CE, CT, IS_ = 0.90, 1.0, 1.10
PF = 0.7 * CE * CT * IS_ * PG                  # 43.659
GAMMA = min(0.13 * PG + 14.0, 30.0)            # 22.19 pcf (clause 5.2)
HB = PF / GAMMA                                # 1.9675 ft (clause 5.3)
LR = 20.0                                      # UFC 3-301-01 Table E-1 item 51, no reduction (4.2)
DL_COLLATERAL = 10.5                           # 4.5 roofing + 6.0 MEP (clause 3)
DL_ROOFING = 4.5
DRIFT_C = 0.43                                 # 5.4.1
DRIFT_WINDWARD = 0.75                          # 5.4.3
DRIFT_WIDTH = 4.0                              # 5.4.2
MIN_FETCH = 20.0                               # 5.4.1
OBSTRUCTION_MIN = 2.0                          # 5.5: hc > 2.0 ft

V_MPH, KZ, KZT, KD, KE = 115.0, 1.04, 1.0, 0.85, 1.0     # 6.1
QH = 0.00256 * KZ * KZT * KD * KE * V_MPH ** 2          # 29.9287 psf
A_ZONE = 12.8                                  # 6.2.1: a = min(0.1*180, 0.4*32) = 12.8 ft
ZONE2A = 2 * A_ZONE                            # 25.6 ft
GCPI = 0.18
CC_ZONES = {"3": -3.20, "2": -2.30, "1": -1.40, "1p": -0.90}      # Table 6-2
WIND_X = 118.0                                 # LAT-2026-003 Table 4-1
WIND_Y = 152.0
WIND_ECC = 0.15                                # LAT-2026-003 4.3

SDS, SD1, IE, R = 0.44, 0.24, 1.25, 3.25       # 7.1 (USGS ASCE7-22 RC III Class D)
OMEGA0, RHO = 2.0, 1.0
ACC_ECC = 0.05                                 # 7.3
W_ROOF = 18.0                                  # 7.2 / LAT Table 5-2
SNOW_SEISMIC_THRESHOLD = 30.0
SNOW_SEISMIC_FRACTION = 0.20
SDC = "D"


def seismic_weight_psf():
    w = W_ROOF
    if PF > SNOW_SEISMIC_THRESHOLD:
        w += SNOW_SEISMIC_FRACTION * PF
    return w


def seismic_force_kip():
    area = LX * LY
    w_kip = seismic_weight_psf() * area / 1000.0
    cs = SDS * IE / R
    v = cs * w_kip
    lo, hi = 0.2 * SDS * IE * w_kip, 0.4 * SDS * IE * w_kip
    return min(max(v, lo), hi), w_kip


# --- snow ------------------------------------------------------------------
FINE = 1.0      # the fields are evaluated on a 1 ft grid and reduced to cells by MAXIMUM
FX = (np.arange(int(NX * ZONE_GRID / FINE)) + 0.5) * FINE
FY = (np.arange(int(NY * ZONE_GRID / FINE)) + 0.5) * FINE
FINE_X, FINE_Y = np.meshgrid(FX, FY, indexing="ij")
NFX = int(ZONE_GRID / FINE)


def reduce_max(fine):
    return fine.reshape(NX, NFX, NY, NFX).max(axis=(1, 3))


def leeward_hd(lu):
    lu = max(float(lu), MIN_FETCH)
    return max(DRIFT_C * lu ** (1.0 / 3.0) * (PG + 10.0) ** 0.25 - 1.5, 0.0)


def drift_profile(hd, hc, dist):
    if hc <= 0.0 or hd <= 0.0:
        return np.zeros_like(dist)
    if hd <= hc:
        peak, w = hd * GAMMA, DRIFT_WIDTH * hd
    else:
        peak, w = hc * GAMMA, min(DRIFT_WIDTH * hd * hd / hc, 8.0 * hc)
    if w <= 0.0:
        return np.zeros_like(dist)
    return np.clip(peak * (1.0 - dist / w), 0.0, None)


def _obstruction_drift(field, x0, y0, x1, y1, height):
    """Criteria 5.4: windward 0.75 hd on the face the wind arrives at, leeward hd on the sheltered
    face, from each of the four directions, largest wins."""
    hc = height - HB
    if hc <= OBSTRUCTION_MIN:
        return
    X, Y = FINE_X, FINE_Y
    len_x, len_y = x1 - x0, y1 - y0
    faces = [
        (x0 - X, x0, len_x, (Y >= y0 - 1e-9) & (Y <= y1 + 1e-9)),          # west face
        (X - x1, LX - x1, len_x, (Y >= y0 - 1e-9) & (Y <= y1 + 1e-9)),     # east face
        (y0 - Y, y0, len_y, (X >= x0 - 1e-9) & (X <= x1 + 1e-9)),          # south face
        (Y - y1, LY - y1, len_y, (X >= x0 - 1e-9) & (X <= x1 + 1e-9)),     # north face
    ]
    for dist, lu_w, lu_l, band in faces:
        hd = max(DRIFT_WINDWARD * leeward_hd(lu_w), leeward_hd(lu_l))
        d = np.where(band & (dist > 0), dist, 1e9)
        np.maximum(field, PF + drift_profile(hd, hc, d), out=field)


def snow_field(case):
    field = np.full(FINE_X.shape, PF, dtype=float)
    if case == "balanced":
        return reduce_max(field)
    if case == "penthouse":
        p = PENTHOUSE
        _obstruction_drift(field, p["x0"], p["y0"], p["x1"], p["y1"], p["height_ft"])
        return reduce_max(field)
    if case == "parapet":
        hc = PARAPET_HT - HB
        if hc > 0.0:
            for dist, lu in [(FINE_Y - 0.0, LY), (LY - FINE_Y, LY), (FINE_X - 0.0, LX), (LX - FINE_X, LX)]:
                hd = DRIFT_WINDWARD * leeward_hd(lu)
                d = np.where(dist > 0, dist, 1e9)
                np.maximum(field, PF + drift_profile(hd, hc, d), out=field)
        return reduce_max(field)
    if case == "equipment":
        for r in RTUS:
            _obstruction_drift(field, r["x0"], r["y0"], r["x1"], r["y1"], r["height_ft"])
        for w in SCREENS:
            x0, y0, x1, y1 = screen_rect(w)
            _obstruction_drift(field, x0, y0, x1, y1, w["height_ft"])
        return reduce_max(field)
    raise ValueError(case)


def gravity_demand(scenario, deck_weight):
    dl = DL_COLLATERAL + np.asarray(deck_weight, dtype=float)
    if scenario == "S01":
        live = np.full((NX, NY), LR)
    else:
        live = snow_field({"S02": "penthouse", "S03": "parapet", "S04": "equipment"}[scenario])
    live = np.maximum(live, LR)
    return dl + live


def live_component(scenario):
    if scenario == "S01":
        return np.full((NX, NY), LR)
    return np.maximum(snow_field({"S02": "penthouse", "S03": "parapet",
                                  "S04": "equipment"}[scenario]), LR)


# --- C&C uplift -------------------------------------------------------------
def cc_zone_field():
    dx = np.minimum(FINE_X, LX - FINE_X)
    dy = np.minimum(FINE_Y, LY - FINE_Y)
    d = np.minimum(dx, dy)
    zone = np.full(FINE_X.shape, "1p", dtype=object)
    zone[d <= ZONE2A] = "1"
    zone[d <= A_ZONE] = "2"
    zone[(dx <= A_ZONE) & (dy <= A_ZONE)] = "3"
    return zone


CC_ZONE = cc_zone_field()


def uplift_demand(deck_weight):
    gcp = np.vectorize(lambda z: CC_ZONES[z])(CC_ZONE).astype(float)
    p = QH * (gcp - GCPI)
    resist = 0.9 * (np.asarray(deck_weight, dtype=float) + DL_ROOFING)
    return np.maximum(reduce_max(np.maximum(-p, 0.0)) - resist, 0.0)


# --- drift report (criteria 5.4, one named face per obstruction) ------------
DRIFT_FACES = [("MEP-PH-1", "W"), ("SCR-N", "S"), ("PARAPET", "N"), ("RTU-1", "E")]


def _face_rect(tag):
    if tag == PENTHOUSE["tag"]:
        p = PENTHOUSE
        return p["x0"], p["y0"], p["x1"], p["y1"], p["height_ft"]
    for w in SCREENS:
        if w["tag"] == tag:
            x0, y0, x1, y1 = screen_rect(w)
            return x0, y0, x1, y1, w["height_ft"]
    for r in RTUS:
        if r["tag"] == tag:
            return r["x0"], r["y0"], r["x1"], r["y1"], r["height_ft"]
    raise ValueError(tag)


def face_drift(tag, face):
    if tag == "PARAPET":
        h = PARAPET_HT
        coord = {"N": LY, "S": 0.0, "E": LX, "W": 0.0}[face]
        lu_w = LY if face in "NS" else LX
        lu_l = 0.0
        outward = -1 if face in ("N", "E") else +1
    else:
        x0, y0, x1, y1, h = _face_rect(tag)
        len_x, len_y = x1 - x0, y1 - y0
        if face == "W":
            coord, lu_w, lu_l, outward = x0, x0, len_x, -1
        elif face == "E":
            coord, lu_w, lu_l, outward = x1, LX - x1, len_x, +1
        elif face == "S":
            coord, lu_w, lu_l, outward = y0, y0, len_y, -1
        else:
            coord, lu_w, lu_l, outward = y1, LY - y1, len_y, +1
    hc = h - HB
    floor = 0.0 if tag == "PARAPET" else OBSTRUCTION_MIN
    if hc <= floor:
        return 0.0, coord, coord
    hd = max(DRIFT_WINDWARD * leeward_hd(lu_w), leeward_hd(lu_l))
    if hd <= hc:
        peak, w = hd * GAMMA, DRIFT_WIDTH * hd
    else:
        peak, w = hc * GAMMA, min(DRIFT_WIDTH * hd * hd / hc, 8.0 * hc)
    far = coord + outward * w
    return float(peak), float(min(coord, far)), float(max(coord, far))


# ---------------------------------------------------------------------------
# deck catalogue (NORDECK B-36 2026, clauses 2, 3, 4, 5, 6)
# ---------------------------------------------------------------------------
E_STEEL = 29500.0      # ksi
FY_DECK, FU_DECK = 40.0, 55.0
D_HEAD = 0.216
PHI_D, PHI_T = 0.70, 0.50
OMEGA_B = 1.67
GAGES = {
    22: dict(t=0.0295, wt=1.6, Ix=0.169, Sp=0.184, Sn=0.192, Rn_end=1180.0, buckling=1350.0),
    20: dict(t=0.0358, wt=1.9, Ix=0.208, Sp=0.226, Sn=0.235, Rn_end=1520.0, buckling=1750.0),
    18: dict(t=0.0474, wt=2.5, Ix=0.285, Sp=0.309, Sn=0.319, Rn_end=2310.0, buckling=2600.0),
    16: dict(t=0.0598, wt=3.1, Ix=0.361, Sp=0.386, Sn=0.400, Rn_end=3080.0, buckling=3400.0),
}
PATTERNS = {"36/4": 4, "36/5": 5, "36/7": 7, "36/9": 9}
SIDELAPS = {"SCREW-10": dict(Qs=310.0, min_gage=16), "BP": dict(Qs=95.0, min_gage=20)}
SIDELAP_COUNTS = [2, 3, 4, 5]
T_REF, N_REF, QS_REF = 0.0358, 4, 310.0
PERIMETER_MIN_PATTERN = "36/7"        # criteria 10.4
MIN_SIDELAP_AT_BOUNDARY = 3
SIDELAP_MAX_SPACING_IN = 36.0         # criteria 10.3
MAX_GAGES, MAX_PATTERNS, MAX_ZONES, MAX_RECTS = 2, 3, 12, 14


def sn_nominal(gage, n, sidelap, ns):
    t = GAGES[gage]["t"]
    qs = SIDELAPS[sidelap]["Qs"]
    raw = 480.0 * (t / T_REF) ** 0.85 * (n / N_REF) ** 0.55 * (1 + 0.28 * (ns - 2) * (qs / QS_REF))
    return min(round(raw), GAGES[gage]["buckling"])


def gp_stiffness(gage, n, sidelap, ns):
    t = GAGES[gage]["t"]
    qs = SIDELAPS[sidelap]["Qs"]
    raw = 12.0 * (t / T_REF) ** 0.90 * (n / N_REF) ** 0.45 * (1 + 0.35 * (ns - 2) * (qs / QS_REF))
    return round(raw, 1)


def valid_combination(gage, pattern, sidelap, ns):
    if gage not in GAGES:
        return f"gage {gage} not in the catalogue"
    if pattern not in PATTERNS:
        return f"pattern {pattern} not tabulated"
    if sidelap not in SIDELAPS:
        return f"sidelap {sidelap} not tabulated"
    if ns not in SIDELAP_COUNTS:
        return f"{ns} sidelap connectors per span not tabulated"
    if gage < SIDELAPS[sidelap]["min_gage"]:
        return f"{sidelap} not permitted on {gage} gage (catalogue 6.4)"
    return None


def gravity_capacity(gage):
    """Allowable uniform TOTAL load at the 6 ft span, catalogue 3.1 basis (ASD)."""
    fb = FY_DECK / OMEGA_B
    sn = GAGES[gage]["Sn"]
    L = JOIST_SPACING
    return 1000.0 * fb * sn / (L * L * 12.0 / 10.0)


def deflection_per_psf(gage):
    """delta = 0.0069 w L^4 / (E I), catalogue 3.3, per psf of pressure on a 1 ft wide strip."""
    L = JOIST_SPACING * 12.0
    return 0.0069 * (L ** 4) / (E_STEEL * 1000.0 * GAGES[gage]["Ix"]) / 12.0


def uplift_capacity(gage, pattern):
    pnov = 0.85 * D_HEAD * GAGES[gage]["t"] * FU_DECK          # ksi x in x in = kip
    n = PATTERNS[pattern]
    trib_sf = (36.0 / n) * (JOIST_SPACING * 12.0) / 144.0
    return PHI_T * pnov * 1000.0 / trib_sf


STOCKED = {22: 2, 20: 3, 18: 4}       # Deck_Stock_Availability_2026-07, weeks
PROJECT_LEAD_WEEKS = 9                # OBD section 5


def stocked(gage):
    return STOCKED.get(gage, 99) <= PROJECT_LEAD_WEEKS


# ---------------------------------------------------------------------------
# cost (Cost Plan CP-RD-2026)
# ---------------------------------------------------------------------------
DECK_PSF = {22: 3.05, 20: 3.48, 18: 4.42, 16: 5.61}
COST_SUPPORT_FASTENER = 1.35
COST_SIDELAP = {"SCREW-10": 1.15, "BP": 0.32}
COST_ZONE, COST_RECT, COST_GAGE, COST_PATTERN = 900.0, 260.0, 4800.0, 1400.0
AREA_CELL = ZONE_GRID * ZONE_GRID


def cell_cost(gage, pattern, sidelap, ns):
    area = AREA_CELL
    lines = area / (PANEL_WIDTH * JOIST_SPACING)
    return (DECK_PSF[gage] * area + COST_SUPPORT_FASTENER * lines * PATTERNS[pattern]
            + COST_SIDELAP[sidelap] * lines * ns)


def installed_cost(zones, assign):
    total = 0.0
    gages, patterns = set(), set()
    n_zones = n_rects = 0
    for zi, z in enumerate(zones):
        n = int((assign == zi).sum())
        if n == 0:
            continue
        n_zones += 1
        n_rects += len(z["rects"])
        gages.add(z["gage"])
        patterns.add((z["pattern"], z["sidelap"], z["ns"]))
        area = n * AREA_CELL
        lines = area / (PANEL_WIDTH * JOIST_SPACING)
        total += DECK_PSF[z["gage"]] * area
        total += COST_SUPPORT_FASTENER * lines * PATTERNS[z["pattern"]]
        total += COST_SIDELAP[z["sidelap"]] * lines * z["ns"]
    total += COST_ZONE * n_zones + COST_RECT * n_rects
    total += COST_GAGE * len(gages) + COST_PATTERN * len(patterns)
    return total


def combinations():
    out = []
    for gage in GAGES:
        if not stocked(gage):
            continue
        for pattern, n in PATTERNS.items():
            for sl in SIDELAPS:
                for ns in SIDELAP_COUNTS:
                    if valid_combination(gage, pattern, sl, ns):
                        continue
                    if (JOIST_SPACING * 12.0) / ns > SIDELAP_MAX_SPACING_IN + 1e-6:
                        continue
                    out.append(dict(gage=gage, pattern=pattern, n=n, sidelap=sl, ns=ns,
                                    gt=gp_stiffness(gage, n, sl, ns),
                                    sn=sn_nominal(gage, n, sl, ns),
                                    cap=PHI_D * sn_nominal(gage, n, sl, ns),
                                    upl=uplift_capacity(gage, pattern),
                                    grav=gravity_capacity(gage),
                                    defl=deflection_per_psf(gage),
                                    reac=GAGES[gage]["Rn_end"],
                                    wt=GAGES[gage]["wt"],
                                    cost=cell_cost(gage, pattern, sl, ns)))
    return out


def summary():
    out = {
        "geometry": {k: GEOM[k] if not isinstance(GEOM[k], list) else GEOM[k] for k in GEOM},
        "loads": dict(PG=PG, PF=PF, GAMMA=GAMMA, HB=HB, LR=LR, QH=QH, A_ZONE=A_ZONE,
                      SDS=SDS, IE=IE, R=R, W_SEISMIC=seismic_weight_psf(),
                      FPX=seismic_force_kip()[0], WIND_X=WIND_X, WIND_Y=WIND_Y),
    }
    return out


if __name__ == "__main__":
    print(json.dumps(summary(), indent=1, default=str))
    print("\ndrifts:")
    for t, fa in DRIFT_FACES:
        print(" ", t, fa, [round(v, 3) for v in face_drift(t, fa)])
    print("\ngravity capacities:", {g: round(gravity_capacity(g), 2) for g in GAGES})
    print("defl/psf:", {g: round(deflection_per_psf(g), 9) for g in GAGES})
    print("uplift cap:", {(g, p): round(uplift_capacity(g, p), 2) for g in GAGES for p in PATTERNS})
    print("n combinations:", len(combinations()))
