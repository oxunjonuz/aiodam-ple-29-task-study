"""Pick a zone tiling: enumerate rectangular partitions, keep those under the 14-rectangle limit,
and rank them by a local proxy cost (cheapest locally feasible combination per tile).

The proxy ignores the global diaphragm checks on purpose - it is only used to choose the *geometry*
of the partition; the combinations themselves are then searched with the full model.
"""
from __future__ import annotations

import itertools
import json

import numpy as np

from . import model as M
from . import tiling as T

XS_CUTS = [[0, 48, 240], [0, 60, 180, 240], [0, 48, 186, 240], [0, 240],
           [0, 30, 120, 210, 240], [0, 60, 120, 180, 240]]
YS_CUTS = [[0, 24, 48, 120, 150, 180], [0, 24, 48, 60, 120, 126, 180],
           [0, 24, 48, 84, 126, 150, 180], [0, 24, 48, 126, 150, 168, 180],
           [0, 30, 60, 120, 150, 180], [0, 24, 48, 120, 132, 150, 180],
           [0, 48, 120, 180], [0, 36, 60, 120, 150, 180], [0, 24, 48, 54, 120, 126, 180]]


def evaluate_tiling(xcuts, ycuts, cands, edge):
    tiles = T.tiles_from_cuts(xcuts, ycuts)
    rects = sum(len(T.decompose(m)) for m in tiles)
    if rects > M.MAX_RECTS:
        return None
    cost = 0.0
    gages, patterns = set(), set()
    info = []
    for m in tiles:
        c = T.cheapest_local(m, edge, cands)
        if c is None:
            return None
        cost += c["cost"] * int(m.sum())
        gages.add(c["gage"])
        patterns.add((c["pattern"], c["sidelap"], c["ns"]))
        info.append((tuple(c[k] for k in ("gage", "pattern", "sidelap", "ns")), int(m.sum())))
    cost += (M.COST_ZONE * len(tiles) + M.COST_RECT * rects
             + M.COST_GAGE * len(gages) + M.COST_PATTERN * len(patterns))
    return dict(xcuts=xcuts, ycuts=ycuts, tiles=len(tiles), rects=rects, cost=cost,
                gages=sorted(gages), patterns=sorted(str(p) for p in patterns), info=info,
                n_gages=len(gages))


def main():
    cands = T.candidates()
    edge = T.edge_mask()
    out = []
    for xs in XS_CUTS:
        for ys in YS_CUTS:
            r = evaluate_tiling(xs, ys, cands, edge)
            if r:
                out.append(r)
    out.sort(key=lambda r: r["cost"])
    print(f"{len(out)} admissible tilings (<= {M.MAX_RECTS} rectangles)")
    for r in out[:12]:
        print(f"  ${r['cost']:>9,.0f} tiles={r['tiles']:2d} rects={r['rects']:2d} gages={r['gages']} "
              f"x={r['xcuts']} y={r['ycuts']}")
    print("\nbest tiling detail:")
    b = out[0]
    for combo, n in b["info"]:
        print(f"   {n:4d} cells  {combo}")
    json.dump(out[:12], open("/work/ple-solve/roof/tilings.json", "w"), indent=1)


if __name__ == "__main__":
    main()
