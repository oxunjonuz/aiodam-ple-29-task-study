"""Cell-level requirement map and a rectangle cover under the 14-rectangle budget.

For every deck cell, which catalogue combination is the cheapest that satisfies the checks that do not
depend on the rest of the design (gravity, live-load deflection, end reaction, uplift, and the 10.4
minimum for cells on the boundary or beside an opening).  The map is then covered with rectangles.
"""
from __future__ import annotations

import numpy as np

from . import design as DS
from . import model as M
from . import tiling as T

LIM_DEFL = M.JOIST_SPACING * 12.0 / 240.0


def _fields():
    grav = {}
    live = np.max([M.live_component(s) for s in ("S01", "S02", "S03", "S04")], axis=0)
    for g in (22, 20, 18):
        w = M.GAGES[g]["wt"]
        grav[g] = np.max([M.gravity_demand(s, w) for s in ("S01", "S02", "S03", "S04")], axis=0)
    upl = {g: M.uplift_demand(M.GAGES[g]["wt"]) for g in (22, 20, 18)}
    return grav, live, upl


GRAV, LIVE, UPL = _fields()
EDGE = T.edge_mask()


def combo_feasible(c):
    """Boolean cell mask where this combination satisfies the design-independent checks."""
    g = c["gage"]
    ok = (GRAV[g] <= c["grav"] + 1e-6)
    ok &= (c["defl"] * LIVE <= LIM_DEFL + 1e-9)
    ok &= (1.1 * GRAV[g] * M.JOIST_SPACING <= c["reac"] + 1e-6)
    ok &= (UPL[g] <= c["upl"] + 1e-6)
    if not c["perimeter"]:
        ok &= ~EDGE
    return ok


def target_map(cands):
    """Cheapest feasible combination per cell (by cell cost), and the map of which one."""
    best = np.full((M.NX, M.NY), np.inf)
    idx = np.full((M.NX, M.NY), -1, dtype=int)
    masks = [combo_feasible(c) for c in cands]
    for k, c in enumerate(cands):
        m = masks[k] & (c["cost"] < best)
        best[m] = c["cost"]
        idx[m] = k
    return idx, best, masks


def cover(idx, cands, budget=M.MAX_RECTS):
    """Cover the class map with rectangles; classes give way (stronger combinations) until it fits."""
    live = M.deck_mask() & (idx >= 0)
    classes = sorted({int(idx[i, j]) for i, j in zip(*np.where(live))})
    # order classes by how many cells want them, biggest first
    counts = {k: int((idx == k).sum()) for k in classes}
    order = sorted(classes, key=lambda k: -counts[k])
    while True:
        groups = {k: (idx == k) & live for k in order}
        rects = []
        for k in order:
            rects.extend([(k,) + r for r in T.decompose(groups[k])])
        if len(rects) <= budget or len(order) == 1:
            return rects, order
        # merge the smallest class into the next cheapest class that is not itself
        smallest = min(order[1:], key=lambda k: counts[k]) if len(order) > 1 else order[0]
        others = [k for k in order if k != smallest]
        others.sort(key=lambda k: abs(cands[k]["cost"] - cands[smallest]["cost"]))
        target = others[0]
        move = idx == smallest
        idx = np.where(move, target, idx)
        order = [k for k in order if k != smallest]
        counts[target] += counts[smallest]


def main():
    cands = T.candidates()
    cands = sorted(cands, key=lambda c: c["cost"])
    idx, best, masks = target_map(cands)
    live = M.deck_mask()
    print("cells with no feasible combination:", int((live & (idx < 0)).sum()))
    print("cheapest-imaginable deck cost: $%.0f" % float(np.where(live, best, 0).sum()))
    from collections import Counter
    cnt = Counter(int(idx[i, j]) for i, j in zip(*np.where(live)))
    for k, n in cnt.most_common():
        c = cands[k]
        print(f"  {n:4d} cells  {c['gage']} {c['pattern']} {c['sidelap']} ns={c['ns']} ${c['cost']:.1f}")
    idx2, _, _ = target_map(cands)
    rects, order = cover(idx2, cands)
    print(f"\ncover: {len(rects)} rectangles over {len(order)} classes")
    tot = 0.0
    for (k, i0, i1, j0, j1) in rects:
        n = (i1 - i0) * (j1 - j0)
        tot += n * cands[k]["cost"]
        c = cands[k]
        print(f"  {c['gage']}/{c['pattern']}/{c['sidelap']}/{c['ns']} rect "
              f"({i0*6},{j0*6})-({i1*6},{j1*6}) {n} cells")
    print(f"deck+fastener cost ${tot:,.0f}")


if __name__ == "__main__":
    main()
