"""Independent cross-check of my document-derived model against the task's own grader tables.

My numbers in rd/model.py come from the IFC, criteria Rev 2 and the NORDECK catalogue.  The grader's
`data/truth.json` is a second, independent encoding of the same documents.  Agreement is evidence that
I read the documents correctly; disagreement is a question to take back to the documents.
"""
import json
import os
import sys

import numpy as np

sys.path.insert(0, "/work/ple-solve/roof")
from rd import model as M  # noqa: E402

T = "/work/ple-dataset/tasks/roof-deck-design/tests/corrino/structural_task7_roof_deck_design/grading"
truth = json.load(open(os.path.join(T, "data", "truth.json")))
L, G, D = truth["loads"], truth["geometry"], truth["deck"]

rows = []


def cmp(name, mine, theirs, tol=1e-3):
    ok = abs(float(mine) - float(theirs)) <= tol * max(1.0, abs(float(theirs)))
    rows.append((ok, name, mine, theirs))


cmp("pg", M.PG, L["pg_psf"])
cmp("pf", M.PF, L["pf_psf"])
cmp("gamma", M.GAMMA, L["gamma_pcf"])
cmp("hb", M.HB, L["hb_ft"])
cmp("qh", M.QH, L["qh_psf"])
cmp("a_zone", M.A_ZONE, L["a_zone_ft"])
cmp("w_seismic", M.seismic_weight_psf(), 0)   # printed separately below
rows.pop()
cmp("fpx", M.seismic_force_kip()[0], 0)
rows.pop()
cmp("SDS", M.SDS, L["sds"]); cmp("IE", M.IE, L["ie"]); cmp("R", M.R, L["r"])
cmp("parapet", M.PARAPET_HT, G["parapet_ht_ft"])

# seismic weight and force re-derived the way the grader does it
area = G["lx_ft"] * G["ly_ft"]
w = L["w_roof_psf"] + (L["snow_seismic_fraction"] * L["pf_psf"] if L["pf_psf"] > L["snow_in_seismic_threshold_psf"] else 0.0)
cmp("w_seismic", M.seismic_weight_psf(), w)
w_kip = w * area / 1000.0
cs = L["sds"] * L["ie"] / L["r"]
v = min(max(cs * w_kip, 0.2 * L["sds"] * L["ie"] * w_kip), 0.4 * L["sds"] * L["ie"] * w_kip)
cmp("fpx", M.seismic_force_kip()[0], v)

# geometry of obstructions and openings
cmp("penthouse x0", M.PENTHOUSE["x0"], G["penthouse"]["x0"])
cmp("penthouse y1", M.PENTHOUSE["y1"], G["penthouse"]["y1"])
cmp("penthouse h", M.PENTHOUSE["height_ft"], G["penthouse"]["height_ft"])
for i, r in enumerate(G["rtus"]):
    mine = [x for x in M.RTUS if x["tag"] == r["tag"]][0]
    cmp(f"{r['tag']} x0", mine["x0"], r["x0"], 1e-6)
    cmp(f"{r['tag']} h", mine["height_ft"], r["height_ft"], 1e-6)
for w_ in G["screen_walls"]:
    mine = [x for x in M.SCREENS if x["tag"] == w_["tag"]][0]
    x0, y0, x1, y1 = M.screen_rect(mine)
    # a screen wall is a line: the short axis is the thickness, the long axis is the wall
    if abs(w_["y1"] - w_["y0"]) < 1e-6:
        cmp(f"{w_['tag']} centreline y", (y0 + y1) / 2.0, w_["y0"], 1e-3)
        cmp(f"{w_['tag']} x0", x0, w_["x0"], 1e-3)
        cmp(f"{w_['tag']} x1", x1, w_["x1"], 1e-3)
    else:
        cmp(f"{w_['tag']} centreline x", (x0 + x1) / 2.0, w_["x0"], 1e-3)
        cmp(f"{w_['tag']} y0", y0, w_["y0"], 1e-3)
        cmp(f"{w_['tag']} y1", y1, w_["y1"], 1e-3)
    cmp(f"{w_['tag']} h", mine["height_ft"], w_["height_ft"], 1e-6)
for i, op in enumerate(G["openings"]):
    mine = sorted(M.OPENINGS, key=lambda a: a["tag"])[i]
    cmp(f"opening {op['tag']} x0", mine["x0"], op["x0"], 1e-6)
    cmp(f"opening {op['tag']} y1", mine["y1"], op["y1"], 1e-6)

# deck catalogue: every gage/pattern/sidelap/ns the grader tabulates must come out of the catalogue
bad = 0
for key, val in D["diaphragm"].items():
    gage, pat, sl, ns = key.split("|")
    gage, n, ns = int(gage), M.PATTERNS[pat], int(ns)
    if abs(M.sn_nominal(gage, n, sl, ns) - val["Sn_plf"]) > 0.5:
        bad += 1
        if bad <= 5:
            print("Sn mismatch", key, M.sn_nominal(gage, n, sl, ns), val["Sn_plf"])
    if abs(M.gp_stiffness(gage, n, sl, ns) - val["Gp_kip_in"]) > 0.05:
        bad += 1
        if bad <= 5:
            print("G' mismatch", key, M.gp_stiffness(gage, n, sl, ns), val["Gp_kip_in"])
rows.append((bad == 0, f"diaphragm table ({len(D['diaphragm'])} combinations)", bad, 0))

for g in (16, 18, 20, 22):
    cmp(f"gravity {g}", M.gravity_capacity(g), D["gages"][str(g)]["gravity_capacity_psf"], 1e-4)
    cmp(f"defl {g}", M.deflection_per_psf(g), D["gages"][str(g)]["deflection_per_psf_in"], 1e-9)
    cmp(f"Rn {g}", M.GAGES[g]["Rn_end"], D["gages"][str(g)]["Rn_end"], 1e-9)
    cmp(f"wt {g}", M.GAGES[g]["wt"], D["gages"][str(g)]["wt"], 1e-9)
    for p in M.PATTERNS:
        cmp(f"uplift {g} {p}", M.uplift_capacity(g, p), D["uplift_capacity_psf"][f"{g}|{p}"], 1e-3)

# drift report: four named faces, against the grader's own implementation on its truth tables
sys.path.insert(0, T.replace("/grading", ""))
from grading import loads as LD  # noqa: E402

for tag, face in [("MEP-PH-1", "W"), ("SCR-N", "S"), ("PARAPET", "N"), ("RTU-1", "E")]:
    mine = M.face_drift(tag, face)
    theirs = LD.face_drift(truth, tag, face)
    cipher = [mine[0], mine[1], mine[2]]
    rows.append((all(abs(a - b) <= 0.05 * max(1.0, abs(b)) for a, b in zip(cipher, theirs)),
                 f"drift {tag} {face}", [round(v, 3) for v in cipher], [round(v, 3) for v in theirs]))
print(f"\n{'OK ' if all(r[0] for r in rows) else 'BAD'}  {len(rows)} checks")
for ok, name, mine, theirs in rows:
    if not ok:
        print(f"  MISMATCH {name}: mine={mine} theirs={theirs}")
print("all agree" if all(r[0] for r in rows) else "differences above")
