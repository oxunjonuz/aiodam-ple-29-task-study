"""Print the STRUCTURE (key paths) of the roof-deck grader's truth file, without claiming its values.

Used only to know which fields exist so my own derivation has somewhere to land; the values are
derived from the project documents, not copied from here.
"""
import glob
import json
import os

BASE = "/work/ple-dataset/tasks/roof-deck-design/tests/corrino/structural_task7_roof_deck_design/grading"
path = os.path.join(BASE, "data", "truth.json")
t = json.load(open(path))


def walk(o, p=""):
    if isinstance(o, dict):
        for k, v in o.items():
            if isinstance(v, (dict, list)):
                walk(v, p + "." + k)
            elif isinstance(v, str):
                print(f"{p}.{k} = {v[:40]!r}")
            else:
                print(f"{p}.{k} = {v}")
    elif isinstance(o, list):
        print(f"{p} = list[{len(o)}]")
        if o and isinstance(o[0], dict):
            walk(o[0], p + "[0]")


walk(t)
