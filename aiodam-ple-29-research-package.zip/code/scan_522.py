#!/usr/bin/env python3
"""Where the results of all 29 tasks actually live on disk.

Reads the task list from /work/ple-dataset/tasks (+ each task.toml's [metadata] grading), then looks
for evidence files under the known solve trees and prints, per task, every file whose name says it
holds a measurement (metrics/grade/paper/reward/verify/mutation), with the numbers inside when the
JSON has them. Nothing here is remembered: it is all read off the disk.
"""
import json
import os
import subprocess
from pathlib import Path

TASKS = Path("/work/ple-dataset/tasks")
ROOTS = [Path(p) for p in ("/work/ple-solve", "/work/lv-cable-sizing", "/work/cw", "/work/audit",
                           "/work/rerun_wds", "/work/fire", "/work/nb-claim")]
PAT = ("metrics.json", "grade.json", "paper_score.json", "paper_result.json", "reward.json",
       "grade.apply.json", "verify.json", "campaign.json", "mutations.json", "results.json")
SKIP = {"node_modules", ".git", "venv", "site-packages", "ws"}


def grading(toml: str) -> str:
    for line in toml.splitlines():
        if line.strip().startswith("grading"):
            return line.split("=", 1)[1].strip().strip('"')
    return "?"


def numbers(p: Path):
    if p.suffix != ".json" or p.stat().st_size > 4_000_000:
        return ""
    try:
        d = json.loads(p.read_text())
    except Exception:
        return ""
    if not isinstance(d, dict):
        return ""
    out = []
    for k in ("reward", "grader_reward", "combined_score", "mean_p", "hard_pass_rate", "judge_status",
              "split", "score", "n_items", "passed", "total"):
        if k in d and not isinstance(d[k], (dict, list)):
            out.append(f"{k}={d[k]}")
    if "metrics" in d and isinstance(d["metrics"], dict):
        m = d["metrics"]
        for k in ("combined_score", "split", "judge_status"):
            if k in m:
                out.append(f"{k}={m[k]}")
    return ", ".join(out)


rows = {}
for t in sorted(TASKS.iterdir()):
    if not t.is_dir():
        continue
    toml = (t / "task.toml").read_text() if (t / "task.toml").is_file() else ""
    rows[t.name] = {"grading": grading(toml), "files": []}

for root in ROOTS:
    if not root.is_dir():
        continue
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in SKIP]
        for fn in filenames:
            if fn not in PAT:
                continue
            p = Path(dirpath) / fn
            rel = str(p)
            hit = None
            for name in rows:
                if name in rel or name.replace("-", "_") in rel or name.replace("-", "") in rel:
                    hit = name
                    break
            if hit is None:
                # legacy names
                alias = {"roof": "roof-deck-design", "roof2": "roof-deck-design", "wind": "wind-diaphragm-shear",
                         "cw": "cooling-water-flush-plan", "fire": "fire-test-validation-memo"}
                for k, v in alias.items():
                    if f"/{k}/" in rel or rel.startswith(f"/work/{k}/"):
                        hit = v
                        break
            if hit:
                rows[hit]["files"].append({"path": rel, "mtime": p.stat().st_mtime, "numbers": numbers(p)})

for name, r in sorted(rows.items()):
    r["files"].sort(key=lambda x: x["mtime"], reverse=True)
    r["files"] = r["files"][:6]
out = {k: {"grading": v["grading"], "n_files": len(v["files"]), "newest": v["files"]} for k, v in rows.items()}
print(json.dumps(out, indent=1))
