#!/usr/bin/env python3
"""Build ALN-108_PreApplication_Response.docx. Every number is interpolated from computed.json."""
import json
import sys
from pathlib import Path

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor

C = json.loads(Path("/work/pac/computed.json").read_text())
OUT = Path(sys.argv[1] if len(sys.argv) > 1 else "/work/pac/out/ALN-108_PreApplication_Response.docx")

rows = C["queue_rows"]
R = {r["id"]: r for r in C["readings"]}
grantwyck = next(r for r in rows if r["project"] == "PXA-2024-0231")
cindermere = next(r for r in rows if r["project"] == "PXA-2025-0044")
ravenford = next(r for r in rows if r["project"] == "PXA-2023-0894")
fenwyn = next(r for r in rows if r["project"] == "PXA-2024-0091")
assert grantwyck["capacity_mw"] == C["study_netted_mw"]
assert cindermere["queue_date"] == "2025-02-06"
assert R["A"]["value_mw"] == "0.8" and R["B"]["value_mw"] == "1.8" and R["C"]["value_mw"] == "-0.99"
assert C["sis_match_count"] == 0, C["sis_matches"]


def fmw(v) -> str:
    """'1.0' -> '1.0 MW', '0.69' -> '0.69 MW': one decimal at least, two where the record has them."""
    t = f"{float(v):.2f}".rstrip("0")
    if t.endswith("."):
        t += "0"
    return t + " MW"


def dmy(iso: str) -> str:
    y, m, d = iso.split("-")
    return f"{m}/{d}/{y}"


def shade(cell, hexcolor):
    tcPr = cell._tc.get_or_add_tcPr()
    el = OxmlElement("w:shd")
    el.set(qn("w:val"), "clear")
    el.set(qn("w:color"), "auto")
    el.set(qn("w:fill"), hexcolor)
    tcPr.append(el)


doc = Document()

# ---- page and base styles
sec = doc.sections[0]
sec.top_margin = sec.bottom_margin = Inches(0.9)
sec.left_margin = sec.right_margin = Inches(1.0)
normal = doc.styles["Normal"]
normal.font.name = "Calibri"
normal.font.size = Pt(10.5)
normal.paragraph_format.space_after = Pt(6)
normal.paragraph_format.line_spacing = 1.06
for name, size, color in (("Heading 1", 12.5, (0x1F, 0x3B, 0x57)), ("Heading 2", 11, (0x1F, 0x3B, 0x57))):
    st = doc.styles[name]
    st.font.name = "Calibri"
    st.font.size = Pt(size)
    st.font.bold = True
    st.font.color.rgb = RGBColor(*color)
    st.paragraph_format.space_before = Pt(12)
    st.paragraph_format.space_after = Pt(4)
    st.paragraph_format.keep_with_next = True

cp = doc.core_properties
cp.title = "Response to Pre-Application Request — Feeder ALN-108 (3 MW, Northline Renewables LLC)"
cp.author = "DER Program Office, Alleniom Utilities"
cp.subject = "Pre-application request dated 07/02/2025 — feeder capacity confirmation"
cp.comments = "Issued 07/14/2025. Capacity confirmation withheld pending confirmation of current feeder state."


def para(text="", style=None, bold=False, italic=False, size=None, space_after=None, align=None):
    p = doc.add_paragraph(style=style)
    if text:
        run = p.add_run(text)
        run.bold = bold
        run.italic = italic
        if size:
            run.font.size = Pt(size)
    if space_after is not None:
        p.paragraph_format.space_after = Pt(space_after)
    if align:
        p.alignment = align
    return p


def labelled(label, text, space_after=6):
    p = doc.add_paragraph()
    r = p.add_run(label + " ")
    r.bold = True
    p.add_run(text)
    p.paragraph_format.space_after = Pt(space_after)
    return p


def bullet(text, bold_lead=None):
    p = doc.add_paragraph(style="List Bullet")
    if bold_lead:
        r = p.add_run(bold_lead + " ")
        r.bold = True
    p.add_run(text)
    p.paragraph_format.space_after = Pt(3)
    return p


def table(headers, body, widths, header_fill="DCE6F1", font_size=9.5, bold_first_col=False):
    t = doc.add_table(rows=1, cols=len(headers))
    t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    t.autofit = False
    hdr = t.rows[0].cells
    for i, h in enumerate(headers):
        hdr[i].text = ""
        p = hdr[i].paragraphs[0]
        r = p.add_run(h)
        r.bold = True
        r.font.size = Pt(font_size)
        p.paragraph_format.space_after = Pt(2)
        shade(hdr[i], header_fill)
    for row in body:
        cells = t.add_row().cells
        for i, v in enumerate(row):
            cells[i].text = ""
            p = cells[i].paragraphs[0]
            r = p.add_run(str(v))
            r.font.size = Pt(font_size)
            if bold_first_col and i == 0:
                r.bold = True
            p.paragraph_format.space_after = Pt(2)
    for row in t.rows:                      # widths must be set on every cell, not only the columns
        for i, w in enumerate(widths):
            row.cells[i].width = Inches(w)
    doc.add_paragraph().paragraph_format.space_after = Pt(2)
    return t


# ------------------------------------------------------------------ letterhead
p = para("ALLENIOM UTILITIES", bold=True, size=13, space_after=0)
for r in p.runs:
    r.font.color.rgb = RGBColor(0x1F, 0x3B, 0x57)
para("DER Program Office", bold=True, size=11, space_after=0)
para("4200 Veldmere Boulevard, Halston, Alleron 01HA  ·  (612) 555-0100  ·  der.program@alleniom.com",
     size=9, space_after=10)

para("RESPONSE TO PRE-APPLICATION REQUEST", bold=True, size=14, space_after=0)
para("Feeder ALN-108 — 3 MW pure-generation project, Northline Renewables LLC", size=11.5, space_after=10)

table(
    ["Field", "Entry"],
    [
        ["Document", "ALN-108_PreApplication_Response.docx — the single written response issued under this request"],
        ["Issued by", "DER Program Office, Alleniom Utilities"],
        ["Date of issuance", dmy(C["as_of"])],
        ["To", "Peter Ashford, Director of Project Development, Northline Renewables LLC, "
               "1840 Ferngate Parkway, Suite 210, Halston, Alleron 02HA"],
        ["Request responded to", f"Pre-application request dated {dmy(C['request_date'])} — feeder capacity "
                                 "confirmation, Feeder ALN-108, 3 MW pure generation"],
        ["Subject", "Written confirmation of available capacity, conditions and restrictions, and pre-application "
                    "dialogue — 3 MW front-of-the-meter, export-only project at the Elderpine substation service area"],
        ["Records reviewed as of", f"{dmy(C['as_of'])} — the published hosting capacity map, the Distribution "
                                   "Planning interim memorandum for this feeder, the active queue register, the "
                                   "system impact study backlog, and the program's current tasking"],
        ["Prepared with", "Distribution Planning (hosting capacity map; feeder planning studies) and "
                          "Interconnection Studies (active queue register)"],
    ],
    widths=[1.45, 5.05], font_size=9.5, bold_first_col=True)

# ------------------------------------------------------------------ 1
doc.add_heading("1. Purpose", level=1)
para("This letter is the DER Program Office's written response to the pre-application request Northline "
     "Renewables LLC submitted on " + dmy(C["request_date"]) + " for feeder capacity confirmation on Feeder "
     "ALN-108 (Elderpine substation, 13.2 kV, pure-generation category). The project as submitted is a 3 MW "
     "front-of-the-meter, export-only photovoltaic facility, working name Elderpine Solar I, approximately "
     "3.9 MW-DC against 3 MW-AC at the requested interconnection capacity. The letter answers the three items "
     "of the request in the order they were put: confirmation of currently available capacity, known conditions, "
     "restrictions and upgrade indications, and scheduling of a pre-application dialogue. Each determination is "
     "given with the records it rests on, and section 6 sets out the records themselves.")
para("The letter is issued on " + dmy(C["as_of"]) + ", before the 08/15/2025 date on which the program's current "
     "queue accounting is to be reported externally, so that Northline can plan on the correct basis rather than "
     "on a figure the Program Office cannot stand behind. Nothing in it is a commitment of interconnection timing.")

# ------------------------------------------------------------------ 2
doc.add_heading("2. Determinations", level=1)
para("Six determinations follow. Determination 1 is the call on the capacity figure; determinations 2 to 6 answer "
     "the remainder of the request and the office actions the request requires.")

doc.add_heading("Determination 1 — Confirmation of currently available capacity is withheld", level=2)
para("The DER Program Office does not confirm that 3.0 MW, or any other figure, is currently available on Feeder "
     "ALN-108 for Northline's 3 MW pure-generation project as of " + dmy(C["as_of"]) + ". Confirmation of currently "
     "available capacity for Northline Renewables on Feeder ALN-108 is withheld pending confirmation of current "
     "feeder state by Distribution Planning. The published 3.0 MW is the figure Northline sized against and the "
     "figure the request asks the Program Office to endorse; the Program Office cannot endorse it, and it does not "
     "substitute a different confirmed figure in its place. Section 3 sets out what the records produce when netted "
     "— arithmetic, offered as an illustration only, and expressly not a capacity determination.")
labelled("Basis.",
         "The published map states that applicants should consult Distribution Planning for confirmation before "
         "finalizing project sizing decisions, and that a pre-application capacity response is prepared against the "
         "published value as adjusted for queue entries added since publication. " + C["ra_doc"] + " section 3.7 "
         "requires, before any capacity figure from the published map is communicated externally, that the figure "
         "be confirmed to reflect the current state of the affected feeder. That confirmation has not been obtained "
         "for Feeder ALN-108, and the program record does not itself supply it: the map edition of record was "
         "published on " + dmy(C["map_published"]) + " and is " + str(C["map_age_days"]) + " days old, the interim "
         "memorandum of " + dmy(C["study_date"]) + " has been overtaken by queue activity its own section 5 says "
         "requires it to be reissued, and the queue register of " + dmy(C["as_of"]) + " carries four active entries "
         "on the feeder, two of them added after that memorandum.")

doc.add_heading("Determination 2 — All sizing reliance on a capacity figure is conditional on Distribution Planning",
                level=2)
para("All project-sizing reliance by Northline Renewables on a capacity figure for Feeder ALN-108 is conditional "
     "on Distribution Planning first confirming the current interim position. This applies to every figure in this "
     "letter without exception, including the illustrative arithmetic of section 3: none of them is a basis for "
     "project sizing until Distribution Planning confirms the current interim position for the feeder.")
labelled("Basis.",
         "The interim memorandum's recommendation 4 directs applicants inquiring about Feeder ALN-108 to Distribution "
         "Planning for confirmation of the interim position before finalizing project sizing decisions, consistent "
         "with the applicability note carried in the front matter of the map; recommendation 3 requires the "
         "memorandum to be reissued or superseded if further queue activity arises before the next map refresh. The "
         "superseding position and the confirmation before sizing are both assigned to Distribution Planning, not to "
         "the Program Office, and this letter does not stand in their place.")

doc.add_heading("Determination 3 — Feasibility and reinforcement determinations remain pending", level=2)
para("Project-specific feasibility, thermal, voltage and protection performance, and any reinforcement "
     "determination for Northline's proposed 3 MW project — or for a project resized on Northline's own decision — "
     "remain pending a current feeder-level assessment. This letter makes no feasibility finding, no overload "
     "finding and no reinforcement finding, in either direction, and Northline should draw no inference from the "
     "absence of any such finding. It should equally draw no favourable inference from the alignment of the "
     "project's technology with the feeder's published DER category: pure generation is the category recorded for "
     "Feeder ALN-108, and that alignment is a classification fact, not a capacity or feasibility result.")
labelled("Basis.",
         "The interim memorandum states in its section 1 that it does not substitute for a formal feeder-level "
         "planning study in support of any specific interconnection application, and its section 4 limitation "
         "records that the interim figure applies a straight-line nameplate netting which is not a thermal, voltage "
         "or protection assessment. Nameplate subtraction cannot support a feasibility or an overload conclusion, "
         "and the Program Office will not offer one in its absence.")

doc.add_heading("Determination 4 — A full feeder-level planning study is required", level=2)
para("A full feeder-level planning study, under the standard Alleniom Distribution Planning methodology, is "
     "required on Feeder ALN-108 before any capacity figure, condition set or upgrade indication for a project of "
     "this size on this feeder can be given. This is a condition of any further capacity guidance Northline "
     "receives, not a preliminary step the Program Office can waive: the request asks for 3.0 MW against a "
     "published available figure of 3.0 MW, that is " + f"{C['request_share_of_published_pct']:.0f}" + " % of the "
     "published headroom of record, and a request of that size is the case the interim memorandum addresses as "
     "requiring a full study.")
labelled("Basis.",
         "The interim memorandum's section 1 states that any project of consequential size on Feeder ALN-108 will "
         "require a full feeder-level planning study following the standard Alleniom Distribution Planning "
         "methodology, and its section 5 recommendation 2 calls for a refreshed feeder-level planning study to be "
         "scheduled in advance of the next full refresh of the map. The map itself records that its published "
         "values rest on a feeder-level planning study using recorded peak and minimum load, existing interconnected "
         "DER of record, and standard thermal, voltage and protection screens — none of which the interim netting "
         "performs for this project.")

doc.add_heading("Determination 5 — Pre-application dialogue meeting", level=2)
para("The Program Office will convene the pre-application dialogue Northline requested, with Distribution Planning "
     "and the DER Program Office at the table. The Program Office proposes to hold it once Distribution Planning has "
     "confirmed the current interim position, so that the dialogue opens on the current feeder state rather than on "
     "the published figure; if Northline prefers to meet earlier, the Program Office will convene it on that basis, "
     "with the understanding that capacity is not on the table until Distribution Planning's confirmation is in "
     "hand. Northline is asked to send availability windows for the following three weeks in the next ten business "
     "days, and the Program Office will confirm the date and the agenda in writing within three business days of "
     "receiving them. Convening the dialogue does not produce a capacity figure and does not reserve capacity or "
     "queue position.")
labelled("Basis.",
         "Request item 3 asks for the scheduling of a pre-application dialogue meeting with Distribution Planning and "
         "the DER Program Office; the map's applicability note and the interim memorandum's recommendation 4 both "
         "route pre-application capacity discussion on this feeder through Distribution Planning, which is why that "
         "group is a participant and not merely a consulted party.")

doc.add_heading("Determination 6 — A priority hosting-capacity refresh has been requested for Feeder ALN-108", level=2)
para("The DER Program Office has requested a priority hosting-capacity refresh for Feeder ALN-108 from Distribution "
     "Planning, as " + C["ra_doc"] + " section 3.7 requires before any published capacity figure is communicated "
     "externally. On the map's published refresh-prioritization criteria, this feeder meets all three rankings: on "
     "application date, the request of " + dmy(C["request_date"]) + " is the most recent intake event on this "
     "feeder; on capacity requested relative to published headroom, " + fmw(C["request_mw"]) + " is "
     f"{C['request_share_of_published_pct']:.0f}" + " % of the published available figure; and on DER category, the "
     "feeder carries pure generation, which the criteria weight more heavily against feeder headroom than "
     "net-metering behind-the-meter interconnections at equivalent nameplate. The refresh is what converts the "
     "withholding in Determination 1 into a figure Northline can use; until it is issued, no figure is available "
     "from the Program Office for sizing.")
labelled("Basis.",
         C["ra_doc"] + " section 3.7: \u201c" + C["ra_37"] + "\u201d The map's title block sets out the "
         "refresh-prioritization criteria applied above and the quarterly refresh commitment the request exposes; "
         "the map's applicability note directs pre-application requesters to the active-queue register as the "
         "record of queue activity, which section 3 uses.")

# ------------------------------------------------------------------ 3
doc.add_heading("3. The figure — what the records produce, and why none of it is a confirmation", level=1)
para("The request asks the Program Office for written confirmation of 3.0 MW and, in the alternative, for any "
     "updated feeder figures or study results that post-date the map. What follows is what the program's own "
     "records produce when read together. It is arithmetic on those records: illustrative only, not a "
     "determination of available capacity, not a substitute for Distribution Planning's confirmation, and not to be "
     "used for project sizing.")

doc.add_heading("3.1 The published figure and the queue as it stands", level=2)
para("The published figure of record for Feeder ALN-108 is " + C["published_mw"] + ".0 MW, category "
     + C["map_category"].lower() + ", derived from a planning study completed " + C["map_last_study"] +
     " and published on " + dmy(C["map_published"]) + ". That edition is " + str(C["map_age_days"]) + " days old at "
     "the date of this letter — more than four quarterly refresh cycles under the map's own refresh commitment — "
     "and no later edition of the map is on the file for this request.")
para("The active queue register as of " + dmy(C["as_of"]) + " carries " + str(C["queue_row_count"]) +
     " active entries on Feeder ALN-108, out of " + f"{C['queue_active_total']:,}" + " active applications "
     "program-wide. None of the four is on hold, and none appears in the notices-of-impending-withdrawal log:")

table(
    ["Project (queue date)", "Customer", "Capacity", "Status", "Before / after the map"],
    [[f"{r['project']} ({dmy(r['queue_date'])})", r["customer"], fmw(r["capacity_mw"]),
      r["status"],
      "before" if r["queue_date"] <= C["map_published"] else "after"]
     for r in rows],
    widths=[1.55, 1.75, 0.75, 1.35, 1.10], font_size=9)

para("Two of the four entries post-date the map: " + grantwyck["customer"] + " (" + grantwyck["capacity_mw"] +
     " MW, queued " + dmy(grantwyck["queue_date"]) + ") and " + cindermere["customer"] + " (" +
     cindermere["capacity_mw"] + " MW, queued " + dmy(cindermere["queue_date"]) + "). Together they are " +
     C["post_pub_mw"] + " MW, or " + f"{C['post_pub_share_of_published_pct']:.1f}" + " % of the published available "
     "figure. The two earlier entries — " + ravenford["customer"] + " (" + ravenford["capacity_mw"] + " MW, " +
     ravenford["status"] + ") and " + fenwyn["customer"] + " (" + fenwyn["capacity_mw"] + " MW, " +
     fenwyn["status"] + ") — were queued before the map was published and are not reflected in a published figure "
     "that counts interconnected DER of record rather than queued requests.")

doc.add_heading("3.2 The interim memorandum, and why it cannot be the figure either", level=2)
para("Distribution Planning issued an interim update for this feeder on " + dmy(C["study_date"]) + " (" +
     C["study_doc"] + "). It nets one post-publication queue entry against the published figure: " +
     C["study_baseline_mw"] + " MW \u2212 " + C["study_netted_mw"] + " MW = " + C["study_interim_mw"] + " MW, and "
     "presents that as a working interim figure for pre-application dialogue. Its own limitations defeat its use "
     "here. First, it reflects the queue as of its date only: any subsequent queue addition requires Distribution "
     "Planning to reassess the interim position. " + cindermere["customer"] + "'s " + cindermere["capacity_mw"] +
     " MW entry, queued " + dmy(cindermere["queue_date"]) + " — " + str(C["newest_queue_age_days"]) + " days before "
     "the register date — is exactly such an addition, and no reassessment is on the record. Second, its "
     "recommendation 3 requires it to be reissued or superseded on any further queue activity before the next map "
     "refresh, which has not happened in the " + str(C["study_age_days"]) + " days since issue. Third, it is not a "
     "thermal, voltage or protection assessment, as its section 4 states. The 1.8 MW is therefore a figure that "
     "was correct on the day it was written and is not current now — on the memorandum's own terms, not the "
     "Program Office's.")

doc.add_heading("3.3 Three readings of the same records", level=2)
para("Applying the three defensible readings of the record to the same published figure and the same queue gives "
     "the results below. They are shown together because the spread between them is the point: the record does not "
     "contain a single figure it can stand behind, which is why Determination 1 withholds rather than picks one.")

table(
    ["Reading", "Arithmetic from the record", "Result", "Shortfall against 3.0 MW"],
    [
        ["A — the map's own rule: published value adjusted for queue entries added since publication",
         f"3.0 \u2212 ({R['A']['addends'][0]} + {R['A']['addends'][1]}) = {R['A']['value_mw']}",
         R["A"]["value_mw"] + " MW", R["A"]["shortfall_mw"] + " MW"],
        ["B — the interim memorandum as it stands, un-updated",
         f"3.0 \u2212 {R['B']['subtrahend_mw']} = {R['B']['value_mw']}",
         R["B"]["value_mw"] + " MW", R["B"]["shortfall_mw"] + " MW"],
        ["C — every active queue entry on the feeder netted against the published figure",
         f"3.0 \u2212 ({' + '.join(sorted(R['C']['addends'], key=float, reverse=True))}) = "
         + ("\u2212" + R["C"]["value_mw"].lstrip("-") if R["C"]["value_mw"].startswith("-") else R["C"]["value_mw"]),
         "\u2212" + R["C"]["value_mw"].lstrip("-") + " MW", R["C"]["shortfall_mw"] + " MW"],
    ],
    widths=[2.05, 1.75, 0.85, 1.20], font_size=9)

para("Reading A is the map's stated method and gives " + R["A"]["value_mw"] + " MW. Reading B takes the Program's "
     "own interim memorandum at face value and gives " + R["B"]["value_mw"] + " MW, on terms its author has already "
     "said are no longer met. Reading C nets the entire active queue on the feeder against the published figure and "
     "gives \u2212" + R["C"]["value_mw"].lstrip("-") + " MW, because the four entries at filed capacity total " +
     C["all_mw"] + " MW, or " + f"{C['all_share_of_published_pct']:.0f}" + " % of the published figure. The spread "
     "across the three readings is " + C["spread_mw"] + " MW. None of the three readings supports 3.0 MW: the "
     "smallest shortfall between the request and any reading of the record is " + R["B"]["shortfall_mw"] + " MW, on "
     "the most generous reading in the set.")
para("Two cautions on reading C, because a negative number invites the wrong conclusion. First, it does not mean "
     "Feeder ALN-108 is overloaded, or that any of these projects is infeasible. The published available figure was "
     "never a reservation ledger: it derives from a study of recorded load, existing interconnected DER and the "
     "standard screens, and queue entries are requests rather than commitments, may be withdrawn or resized, and "
     "have not been studied against this feeder. A queue population larger than the published figure is a statement "
     "about the records, not about the wires. Second, whether the feeder can host any of this capacity, and how "
     "much, is precisely the question the feeder-level study in Determination 4 answers, and nothing in this letter "
     "answers it.")
para("The published figure's own inputs cannot be checked from the program's files either. The map's basis field "
     "records that the figure incorporates recorded peak and minimum load, existing interconnected DER of record and "
     "the standard screens as of the underlying study; the existing-DER register extract carries no feeder field and "
     "excludes applications in queue, so the existing-DER input behind the published 3.0 MW cannot be reconciled to "
     "a feeder-level figure from the record held here. That is one more item for the refresh, not a finding against "
     "the figure.")

# ------------------------------------------------------------------ 4
doc.add_heading("4. Conditions and restrictions on the record", level=1)
para("This answers request item 2. The known conditions fall into one program-level requirement, one honest "
     "statement about upgrade indications, and the standard requirements that attach to a project of this class "
     "irrespective of the feeder.")

bullet("A full feeder-level planning study is required on Feeder ALN-108 for a project of this size, as set out in "
       "Determination 4. Northline should plan on providing the project data that study requires — point of "
       "interconnection, inverters and their certified models, plant controller, and the protection scheme — as "
       "part of any formal application.", bold_lead="Feeder-level study.")
bullet("No upgrade indications for Feeder ALN-108 are identified on the program's record, and the Program Office "
       "will not manufacture any. The only Distribution Planning output for this feeder on the record is the "
       "interim nameplate netting, which its own section 4 says is not a thermal, voltage or protection assessment. "
       "The absence of identified upgrades is therefore not a finding that no upgrades will be required, and it "
       "should not be read as one.",
       bold_lead="Upgrade indications.")
bullet("The project is a medium-scale interconnection under tariff section 12.2(b) — a 3 MW export facility falls in "
       "the 1 MW to 5 MW band — and a Category 3 site under DIS-01 Rev 4 (effective 03/01/2024), Table 5-1. As the "
       "standard stands, that class carries a dedicated protection relay, a utility-owned POI recloser, transfer "
       "trip where protection engineering requires it, a bidirectional revenue meter, and a utility RTU with SCADA "
       "telemetry as a condition of permission to operate under TCS-02; inverters and other equipment must be "
       "certified on CEL-2025-Q2. These are the standard's requirements for the class, not a determination on this "
       "project, and protection engineering may specify further site requirements through ERP-9.",
       bold_lead="Standard requirements.")
bullet("No queue position is created by this pre-application or by this response. Under tariff section 12.3 a queue "
       "position is established as of the date the Company determines a complete application to be complete; "
       "nothing in this letter reserves capacity, queue position or a study slot, and the dialogue in "
       "Determination 5 is not a substitute for an application.",
       bold_lead="No queue position.")
bullet("If Northline files a formal application before Distribution Planning's confirmation is issued, the "
       "application will be processed in queue order on its own facts under tariff section 12.7; it will not be "
       "processed on the basis of the published 3.0 MW, and this letter will not be treated as a finding in its "
       "favour or against it.", bold_lead="A formal application.")

# ------------------------------------------------------------------ 5
doc.add_heading("5. What Northline should do next", level=1)
bullet("Do not finalize project sizing on the published 3.0 MW figure, and do not treat any figure in section 3 as "
       "a sizing basis. All sizing reliance is conditional on Distribution Planning's confirmation "
       "(Determination 2).")
bullet("Send availability windows for a pre-application dialogue in the next ten business days, addressed to the "
       "Program Office at der.program@alleniom.com, with a copy to Distribution Planning (June Halloway, "
       "june.halloway@alleniom.com). The Program Office will confirm the date and agenda in writing within three "
       "business days of receiving them (Determination 5).")
bullet("Route sizing questions on this feeder to Distribution Planning, which owns the interim position and the "
       "refresh, rather than to the Program Office, which does not issue either.")
bullet("Keep the project data current with the Program Office, so that the refreshed position and the feeder-level "
       "study can be run against this project's actual parameters rather than against the published figure.")

# ------------------------------------------------------------------ 6
doc.add_heading("6. Basis of record", level=1)
para("Each determination above rests on the records listed here. The third column says what the record establishes; "
     "the fourth says which determination it supports.")
table(
    ["Record", "Date / identifier", "What it establishes", "Supports"],
    [
        ["Pre-application request, Northline Renewables LLC (Peter Ashford)",
         dmy(C["request_date"]),
         "The three items answered here: confirmation of currently available capacity on Feeder ALN-108 at 3 MW; "
         "known conditions, restrictions and upgrade indications; scheduling of a pre-application dialogue. Records "
         "that the project was sized at the published 3.0 MW.",
         "1, 4, 5"],
        ["Feeder Hosting Capacity Map, HCM-2024-Q2 (published edition of record)",
         dmy(C["map_published"]) + "; last study " + C["map_last_study"],
         "ALN-108 published available capacity 3.0 MW, pure generation, 13.2 kV. The applicability note requiring "
         "confirmation by Distribution Planning before sizing and the queue adjustment rule; the refresh "
         "commitment and the refresh-prioritization criteria; the basis field showing what a published figure rests "
         "on.",
         "1, 2, 4, 6"],
        ["Distribution Planning interim memorandum, " + C["study_doc"],
         dmy(C["study_date"]),
         "Interim netting 3.0 \u2212 1.2 = 1.8 MW; the limitations that make it a working reference only; "
         "recommendation 3 requiring reissue on further queue activity; recommendation 4 directing applicants to "
         "Distribution Planning for confirmation before sizing; sections 1 and 4 limiting what nameplate netting "
         "can support.",
         "1, 2, 3, 4"],
        ["Active Queue Report, weekly export of the interconnection queue",
         "as of " + dmy(C["as_of"]),
         "Four active entries on Feeder ALN-108 totalling " + C["all_mw"] + " MW at filed capacity, with queue dates "
         "and statuses: " + "; ".join(f"{r['project']} {r['capacity_mw']} MW {dmy(r['queue_date'])}" for r in rows)
         + ". Two entries post-date the interim memorandum, which is the queue activity its recommendation 3 "
           "addresses.",
         "1, 3, 6"],
        ["System Impact Study backlog status report, DPG-SIS-BL-2025-07 Rev 1",
         "as of " + dmy(C["as_of"]),
         "Lists " + str(C["sis_total_rows"]) + " study rows and no study row for " + grantwyck["project"] + ", whose "
         "queue status is recorded as \u201c" + grantwyck["status"] + "\u201d; the study posture of the feeder's "
         "largest queued entry cannot be corroborated from the program's study record, which is one more reason the "
         "feeder state cannot be confirmed from the desk.",
         "1"],
        ["Regulatory Affairs tasking memorandum, " + C["ra_doc"] + ", section 3.7 (hosting-capacity corrections)",
         "07/01/2025",
         "Requires confirmation that a published figure reflects the current state of the affected feeder before it "
         "is communicated externally, and requires a priority refresh to be requested from Distribution Planning "
         "under the published refresh-prioritization criteria.",
         "1, 6"],
        ["APUC Energy Resources Division information request, " + C["apuc_docket"] + " (ERD-IR-2025-07-014)",
         "07/07/2025",
         "Asks the Company to address \u201c" + C["apuc_sufficiency_question"] + "\u201d — the sufficiency of the "
         "hosting-capacity information available to prospective applicants is already a question on the regulatory "
         "record, which is why the refresh in Determination 6 is requested as priority rather than routine.",
         "6"],
        ["DER Interconnection Standard DIS-01 Rev 4 (Table 5-1, Category 3) and Tariff section 12 (12.2(b), 12.3, "
         "12.7)",
         "effective 03/01/2024",
         "The standard protective, metering and telemetry requirements for a 1 to 5 MW export site; the medium-scale "
         "classification; the rule that queue position arises on a complete application and that applications are "
         "processed in queue order.",
         "3, 4"],
        ["Existing-DER register extract",
         "as of " + dmy(C["as_of"]),
         "In-service DER at or above the 500 kW reporting floor, with no feeder field and an express exclusion of "
         "queue applications; the existing-DER input behind the published figure therefore cannot be reconciled to "
         "this feeder from the record held by the Program Office.",
         "1, 3"],
    ],
    widths=[1.55, 1.05, 2.60, 0.65], font_size=8.5)

# ------------------------------------------------------------------ 7
doc.add_heading("7. Status of this response", level=1)
para("This response is issued by the DER Program Office on " + dmy(C["as_of"]) + ". It is the single written "
     "response to the pre-application request of " + dmy(C["request_date"]) + ". It disposes of all three items of "
     "the request: the capacity confirmation is withheld under Determination 1, the conditions and restrictions on "
     "the record are stated under section 4, and the dialogue is convened under Determination 5. The office action "
     "the request requires — a priority hosting-capacity refresh for Feeder ALN-108 from Distribution Planning — is "
     "requested under Determination 6 and is the item that will change this answer. When Distribution Planning "
     "issues the refreshed position, the Program Office will send Northline the current figure in writing and will "
     "notify the dialogue date set under Determination 5.")
para("It is not an interconnection agreement, does not create a queue position, does not reserve capacity, and does "
     "not constitute a finding on the feasibility of the project as proposed or on any resized alternative.")

para("", space_after=6)
para("Issued by the DER Program Office, Alleniom Utilities", bold=True, space_after=2)
para("Program Manager, DER Program Office", space_after=2)
para("4200 Veldmere Boulevard, Halston, Alleron 01HA  ·  der.program@alleniom.com  ·  (612) 555-0100",
     size=9, space_after=2)
para("Date of issuance: " + dmy(C["as_of"]), space_after=8)
para("Copy: June Halloway, Distribution Planning Engineer (hosting capacity map and feeder planning studies); "
     "Meera Vellanki, Manager, Interconnection Studies (queue register).", size=9, space_after=0)

OUT.parent.mkdir(parents=True, exist_ok=True)
doc.save(OUT)
print("wrote", OUT, OUT.stat().st_size, "bytes")
