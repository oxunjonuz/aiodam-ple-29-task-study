#!/usr/bin/env python3
"""The task's 14 rubric criteria as code, read from the rendered PDF text (what the judge reads).

Criteria 3-6 read db_diff.txt, which exists only where the task's apps run; they are reported
UNREACHABLE here and never counted as passed. Everything else is a positive test for the
determination plus, where the criterion is a negative one, a scan for a contradiction.
"""
import json
import re
import sys
from datetime import datetime
from pathlib import Path

RENDER = Path(sys.argv[1] if len(sys.argv) > 1 else "/work/pac/render/ALN-108_PreApplication_Response.pdf.txt")
COMMENTS = Path(str(RENDER).replace(".pdf.txt", "_comments.txt"))
RAW = RENDER.read_text(encoding="utf-8")
N = re.sub(r"\s+", " ", RAW)
SENTS = [s.strip() for s in re.split(r"(?<=[.!?])\s+(?=[A-Z0-9\u2014(“])", N) if s.strip()]


def has(pattern, flags=0):
    return re.search(pattern, N, flags) is not None


def sents_with(*patterns):
    out = []
    for s in SENTS:
        if all(re.search(p, s, re.I) for p in patterns):
            out.append(s)
    return out


NEG_BEFORE = re.compile(r"\b(not|no|never|cannot|whether|without|pending|neither|nor|remains?|does not|do not|is not|are not|none of)\b")
NEG_AFTER = re.compile(r"\b(not|never|cannot|pending|rather than|is not|are not)\b")


def fail_over(patterns, pre=70, post=30):
    """Sentences making an assertion of one of `patterns` with no negation next to it.

    The hedge must sit beside the assertion (within `pre` characters before it or `post` after), not
    somewhere else in the sentence: "no overload expected" elsewhere in a sentence does not make
    "the project is feasible" a hedge.
    """
    hits = []
    for s in SENTS:
        low = s.lower()
        for pat in patterns:
            for m in re.finditer(pat, low):
                before = low[max(0, m.start() - pre):m.start()]
                after = low[m.end():m.end() + post]
                if NEG_BEFORE.search(before) or NEG_AFTER.search(after):
                    continue
                hits.append(s)
                break
            else:
                continue
            break
    return hits


results = []


def check(index, weight, criterion, fn):
    try:
        passed, evidence = fn()
    except Exception as exc:                                  # a crashing check is a failing check
        passed, evidence = False, f"check raised {type(exc).__name__}: {exc}"
    results.append({"index": index, "weight": weight, "criterion": criterion,
                    "passed": bool(passed), "evidence": evidence})


def c0():
    a = sents_with(r"withheld", r"current feeder state", r"ALN-108")
    b = sents_with(r"does not confirm", r"ALN-108", r"available")
    claimed = fail_over([r"\b(3\.0 mw|0\.8 mw|1\.8 mw)\b.{0,60}\b(is|remains|are)\b.{0,20}\b(available|confirmed|current)\b",
                         r"\b(confirms?|confirmed|verified)\b.{0,80}\b(3\.0 mw|0\.8 mw|1\.8 mw)\b",
                         r"available capacity (on|for) feeder aln-108 is"])
    ok = bool(a) and bool(b) and not claimed
    ev = (a[0] if a else "no withholding sentence") + (" | " + b[0] if b else " | no non-confirmation sentence")
    if claimed:
        ev += " | CONTRADICTION: " + claimed[0]
    return ok, ev


def c1():
    hits = sents_with(r"conditional on Distribution Planning", r"interim position", r"sizing")
    return bool(hits), (hits[0] if hits else "no sentence makes sizing conditional on Distribution Planning")


def c2():
    names = set(m.group(0) for m in re.finditer(r"[A-Za-z0-9_][A-Za-z0-9_.\-]*\.docx", N))
    beside = sorted(q.name for q in RENDER.parent.iterdir()
                    if q.is_file() and q.name.startswith("ALN-108_PreApplication_Response"))
    ok = names == {"ALN-108_PreApplication_Response.docx"}
    return ok, f"docx names in the text: {sorted(names)}; delivered artefacts beside the text: {beside or 'none'}"


def c7():
    m = re.search(r"Issued by[^.]{0,60}DER Program Office", N)
    return bool(m), (("issuer: " + m.group(0)) if m else "the issuing office is not named as the DER Program Office")


def c8():
    hits = sents_with(r"full feeder-level planning study", r"\brequired\b")
    return bool(hits), (hits[0] if hits else "no sentence requires a full feeder-level planning study")


def c9():
    body = blocks().get("5", "")
    ok = bool(re.search(r"convene", body, re.I)) and bool(re.search(r"dialogue", body, re.I)) \
        and bool(re.search(r"(availability|confirm the date|date and the agenda)", body, re.I))
    first = re.search(r"The Program Office will convene[^.]*\.", body)
    return ok, (first.group(0) if first else "no disposition of the dialogue-meeting request")


def c10():
    pend = sents_with(r"remain pending", r"feeder-level assessment")
    contradict = fail_over([r"\bis feasible\b", r"\bare feasible\b", r"can accommodate",
                            r"will require (an )?upgrade", r"no upgrades (are|will be) required",
                            r"overload(s|ed)? the feeder", r"feeder (can|will) host", r"feeder has (sufficient|adequate)",
                            r"3 mw\b.{0,30}\b(is|would be) (available|acceptable|feasible)"])
    ok = bool(pend) and not contradict
    ev = pend[0] if pend else "no pending-feasibility sentence"
    if contradict:
        ev += " | CONTRADICTION: " + contradict[0]
    return ok, ev


def c11():
    hits = sents_with(r"Date of issuance", r"\d{2}/\d{2}/\d{4}")
    if not hits:
        return False, "no issuance date"
    m = re.search(r"(\d{2})/(\d{2})/(\d{4})", hits[0])
    issued = datetime(int(m.group(3)), int(m.group(1)), int(m.group(2)))
    deadline = datetime(2025, 8, 15)
    return issued < deadline, f"issued {issued:%m/%d/%Y} < 08/15/2025: {issued < deadline}"


DETS = ["1", "2", "3", "4", "5", "6"]
RECORDS = r"(HCM-2024-Q2|PLN-ALN-108-2024-10|Active Queue Report|RA-2025-07-01|DIS-01|tariff section|" \
          r"DPG-SIS-BL-2025-07|request item|interim memorandum|map)"


def blocks():
    """Determination sections keyed by their number, from the heading to the next heading."""
    idx = [(m.start(), m.group(1)) for m in re.finditer(r"Determination ([1-6]) \u2014", N)]
    out = {}
    for i, (pos, num) in enumerate(idx):
        end = idx[i + 1][0] if i + 1 < len(idx) else N.find("3. The figure", pos)
        out[num] = N[pos:end if end > pos else len(N)]
    return out


def c12():
    bs = blocks()
    missing = [d for d in DETS if d not in bs]
    if missing:
        return False, f"missing determination sections: {missing}"
    bad = []
    for d, body in bs.items():
        if "Basis." not in body:
            bad.append(d + " has no stated basis")
        elif not re.search(RECORDS, body, re.I):
            bad.append(d + " names no record")
    rows = N[N.find("6. Basis of record"):]
    for n in "123456":
        if not re.search(rf"(?<![\d/]){n}(?![\d/])", rows):
            bad.append(f"basis table does not cite determination {n}")
    return not bad, ("all six determinations state a record-grounded basis; the basis table cites all six"
                     if not bad else "; ".join(bad))


REFRESH_STATED = [r"(?:has )?requested a priority hosting-capacity refresh",
                  r"priority hosting-capacity refresh for feeder aln-108 from distribution planning[^.]{0,60}"
                  r"\bis (?:being )?requested"]


def c13():
    body = blocks().get("6", "")
    stated = [s for s in SENTS if re.search(r"(?:has )?requested a priority hosting-capacity refresh", s, re.I)
              or re.search(REFRESH_STATED[1], s, re.I)]
    complete = [s for s in stated if re.search(r"feeder aln-108", s, re.I) and re.search(r"distribution planning", s, re.I)]
    cited = bool(re.search(r"RA-2025-07-01 section 3\.7", body))
    ok = bool(complete) and cited
    return ok, ((complete[0] if complete else "no statement that a priority hosting-capacity refresh is requested")
                + f" | RA-2025-07-01 3.7 cited in the section: {cited}")


def unreachable(index, weight):
    def fn():
        return False, "UNREACHABLE: reads db_diff.txt, which exists only where the task's apps run"
    return fn


check(0, 10.0, "capacity confirmation withheld pending current feeder state", c0)
check(1, 6.0, "sizing reliance conditional on Distribution Planning's interim-position confirmation", c1)
check(2, 1.0, "exactly one delivered Word document under the required name", c2)
check(3, 1.0, "work package 'Respond to the Feeder ALN-108 pre-application request' closed  [db_diff]", unreachable(3, 1.0))
check(4, 1.0, "journal note recording the withholding decision  [db_diff]", unreachable(4, 1.0))
check(5, 1.0, "journal note assigning Distribution Planning a follow-up  [db_diff]", unreachable(5, 1.0))
check(6, 1.0, "document-store copy in Correspondence matching the deliverable  [db_diff]", unreachable(6, 1.0))
check(7, 1.0, "issued by the DER Program Office", c7)
check(8, 2.0, "a full feeder-level planning study is required", c8)
check(9, 1.0, "disposition of the dialogue-meeting request", c9)
check(10, 10.0, "feasibility and reinforcement remain pending, consistently", c10)
check(11, 1.0, "issued before 08/15/2025", c11)
check(12, 2.0, "a supporting basis for each determination", c12)
check(13, 1.0, "priority hosting-capacity refresh requested, citing RA-2025-07-01 s.3.7", c13)

total = sum(r["weight"] for r in results)
reachable = sum(r["weight"] for r in results if not r["evidence"].startswith("UNREACHABLE"))
passed = sum(r["weight"] for r in results if r["passed"])
print(f"{'#':>2} {'w':>5} {'pass':>5}  criterion")
for r in results:
    print(f"{r['index']:>2} {r['weight']:>5.0f} {str(r['passed']):>5}  {r['criterion']}")
print(f"\nweight {passed:.0f}/{total:.0f} passed; reachable on this host {reachable:.0f}/{total:.0f}; "
      f"ceiling {(reachable / total):.6f}")
print("\n--- evidence ---")
for r in results:
    print(f"c{r['index']}: {r['evidence'][:600]}")
Path("/work/pac/checks.json").write_text(json.dumps({"results": results, "weight_total": total,
                                                     "weight_passed": passed, "weight_reachable": reachable},
                                                    indent=1, ensure_ascii=False))
sys.exit(0 if passed == reachable else 1)
