#!/usr/bin/env python3
"""Mutation campaign over the delivered docx.

Each mutation breaks one determination in EVERY place the document states it, the mutated file is
rendered by the task's own transform.py (so the reader sees what the judge would see), and the
criterion checks are run again. A mutation is caught when its intended criterion turns red and no
other criterion changes state.
"""
import json
import re
import shutil
import subprocess
import sys
from pathlib import Path

import docx

SRC = Path("/work/pac/out/ALN-108_PreApplication_Response.docx")
WORK = Path("/work/pac/mut")
TASK = Path("/work/ple-dataset/tasks/pre-application-capacity-response")
TR = TASK / "tests/tools/verifiers/deps/transform.py"
PY = "/work/venv-verifier/bin/python"

MUTATIONS = [
    ("M00", "c0", "withholding replaced by confirmation of the published figure", [
        ("Confirmation of currently available capacity for Northline Renewables on Feeder ALN-108 is withheld "
         "pending confirmation of current feeder state by Distribution Planning.",
         "Confirmation of currently available capacity for Northline Renewables on Feeder ALN-108 is given as "
         "3.0 MW, the published figure of record."),
        ("The DER Program Office does not confirm that 3.0 MW, or any other figure, is currently available",
         "The DER Program Office confirms that 3.0 MW is currently available"),
        ("confirmation of currently available capacity is withheld", "confirmation of currently available capacity is given"),
        ("the capacity confirmation is withheld under Determination 1", "the capacity confirmation is given under Determination 1"),
    ]),
    ("M01", "c1", "sizing reliance no longer routed through Distribution Planning", [
        ("conditional on Distribution Planning first confirming the current interim position", "supported by the published figure of record"),
        ("All project-sizing reliance by Northline Renewables on a capacity figure for Feeder ALN-108 is",
         "Project sizing by Northline Renewables on Feeder ALN-108 is"),
        ("until Distribution Planning confirms the current interim position for the feeder", "on the basis of the published figure"),
        ("conditional on Distribution Planning's confirmation (Determination 2)", "on the published figure (Determination 2)"),
        ("All sizing reliance is conditional on Distribution Planning's confirmation", "All sizing reliance is on the published figure"),
    ]),
    ("M02", "c2", "a second delivered document named in the text", [
        ("ALN-108_PreApplication_Response.docx — the single written response issued under this request",
         "ALN-108_PreApplication_Response.docx — accompanied by ALN-108_Capacity_Note.docx"),
    ]),
    ("M03", "c7", "issuing office reduced to the utility", [
        ("Issued by", "Prepared by"),
        ("DER Program Office, Alleniom Utilities", "Alleniom Utilities"),
        ("Issued by the DER Program Office, Alleniom Utilities", "Prepared by Alleniom Utilities"),
        ("This response is issued by the DER Program Office on", "This response is prepared by Alleniom Utilities on"),
    ]),
    ("M04", "c8", "full feeder-level study softened to a possibility", [
        ("A full feeder-level planning study, under the standard Alleniom Distribution Planning methodology, is "
         "required on Feeder ALN-108", "A full feeder-level planning study may be advisable on Feeder ALN-108"),
        ("A full feeder-level planning study is required on Feeder ALN-108 for a project of this size",
         "A full feeder-level planning study may be advisable on Feeder ALN-108 for a project of this size"),
        ("A full feeder-level planning study is required", "A full feeder-level planning study may be advisable"),
    ]),
    ("M05", "c9", "dialogue request left unanswered", [
        ("The Program Office will convene the pre-application dialogue Northline requested, with Distribution "
         "Planning and the DER Program Office at the table.",
         "The Program Office has noted the dialogue Northline requested."),
        ("The Program Office proposes to hold it once Distribution Planning has confirmed the current interim "
         "position", "That is noted"),
        ("Northline is asked to send availability windows for the following three weeks in the next ten business "
         "days, and the Program Office will confirm the date and the agenda in writing within three business days "
         "of receiving them.", "The matter is noted."),
        ("the dialogue is convened under Determination 5", "the dialogue request is noted under Determination 5"),
        ("will notify the dialogue date set under Determination 5", "will be in touch"),
        ("Send availability windows for a pre-application dialogue in the next ten business days",
         "Await further correspondence"),
    ]),
    ("M06", "c10", "a definite feasibility conclusion inserted", [
        ("It is not an interconnection agreement",
         "The 3 MW project is feasible on Feeder ALN-108 as proposed, with no overload expected. It is not an "
         "interconnection agreement"),
    ]),
    ("M07", "c11", "issued on the wrong side of the deadline", [
        ("07/14/2025", "08/20/2025"),
    ]),
    ("M08", "c12", "one determination loses its basis", [
        ("Basis. The interim memorandum's section 1 states that any project of consequential size",
         "Note. The interim memorandum's section 1 states that any project of consequential size"),
    ]),
    ("M09", "c13", "refresh request downgraded in every place the document states it", [
        ("The DER Program Office has requested a priority hosting-capacity refresh for Feeder ALN-108 from "
         "Distribution Planning, as RA-2025-07-01 section 3.7 requires before any published capacity figure is "
         "communicated externally.",
         "Hosting-capacity information is refreshed from time to time by Distribution Planning."),
        ("Determination 6 \u2014 A priority hosting-capacity refresh has been requested for Feeder ALN-108",
         "Determination 6 \u2014 Hosting-capacity information"),
        ("The office action the request requires \u2014 a priority hosting-capacity refresh for Feeder ALN-108 from "
         "Distribution Planning \u2014 is requested under Determination 6",
         "The office action the request requires \u2014 a routine map review \u2014 is noted under Determination 6"),
        ("the refresh in Determination 6 is requested as priority rather than routine",
         "the refresh in Determination 6 is noted"),
    ]),
    ("M13", "c13", "refresh statement left only in the heading", [
        ("The DER Program Office has requested a priority hosting-capacity refresh for Feeder ALN-108 from "
         "Distribution Planning, as RA-2025-07-01 section 3.7 requires before any published capacity figure is "
         "communicated externally.",
         "The DER Program Office will continue to follow the map's refresh process."),
        ("The office action the request requires \u2014 a priority hosting-capacity refresh for Feeder ALN-108 from "
         "Distribution Planning \u2014 is requested under Determination 6",
         "The office action the request requires \u2014 a routine map review \u2014 is noted under Determination 6"),
    ]),
    ("M10", "none", "harmless wording change (control)", [
        ("This letter is the DER Program Office's written response", "This letter is the written response"),
    ]),
    ("M11", "none", "harmless date change inside the deadline (control)", [
        ("Records reviewed as of", "Records reviewed through"),
    ]),
    ("M12", "c0", "PARTIAL mutation: one occurrence of the withholding changed", [
        ("The DER Program Office does not confirm that 3.0 MW, or any other figure, is currently available",
         "The DER Program Office confirms that 3.0 MW is currently available"),
    ]),
]


def para_replace(p, old, new):
    if old not in p.text:
        return 0
    full = p.text.replace(old, new)
    for r in list(p.runs):
        r.text = ""
    if p.runs:
        p.runs[0].text = full
    else:
        p.add_run(full)
    return 1


def apply(doc, pairs):
    n = 0
    for old, new in pairs:
        for p in doc.paragraphs:
            n += para_replace(p, old, new)
        for t in doc.tables:
            for row in t.rows:
                for cell in row.cells:
                    for p in cell.paragraphs:
                        n += para_replace(p, old, new)
    return n


def run_checks(txt: Path):
    out = subprocess.run([PY, "/work/pac/src/checks.py", str(txt)], capture_output=True, text=True)
    data = json.loads(Path("/work/pac/checks.json").read_text())
    return {r["index"]: r["passed"] for r in data["results"]}, out.returncode


def render(docx_path: Path, outdir: Path):
    outdir.mkdir(parents=True, exist_ok=True)
    pdf = outdir / "ALN-108_PreApplication_Response.pdf"
    subprocess.run(["python3", str(TR), "--input", str(docx_path), "--output", str(pdf),
                    "--transformation", "docx_to_pdf"], check=True, capture_output=True,
                   env={"PYTHONPATH": "/work/venv-verifier/lib/python3.12/site-packages", "PATH": "/usr/bin:/bin"})
    txt = outdir / "ALN-108_PreApplication_Response.pdf.txt"
    subprocess.run(["python3", str(TR), "--input", str(pdf), "--output", str(txt),
                    "--transformation", "pdf_to_text"], check=True, capture_output=True,
                   env={"PYTHONPATH": "/work/venv-verifier/lib/python3.12/site-packages", "PATH": "/usr/bin:/bin"})
    return txt


baseline, _ = run_checks(Path("/work/pac/render/ALN-108_PreApplication_Response.pdf.txt"))
print("baseline:", {k: v for k, v in baseline.items() if not v} or "all reachable pass")

rows, problems = [], []
for mid, target, label, pairs in MUTATIONS:
    d = docx.Document(str(SRC))
    hits = apply(d, pairs)
    md = WORK / mid
    md.mkdir(parents=True, exist_ok=True)
    path = md / "ALN-108_PreApplication_Response.docx"
    d.save(str(path))
    txt = render(path, md / "render")
    state, rc = run_checks(txt)
    changed = sorted(i for i in state if state[i] != baseline[i])
    caught = bool(changed)
    rows.append({"id": mid, "target": target, "label": label, "replacements": hits,
                 "changed": changed, "caught": caught})
    want = set() if target == "none" else {int(target[1:])}
    if target != "none":
        if not want <= set(changed):
            problems.append(f"{mid}: intended c{want} did not turn red (changed={changed}, replacements={hits})")
    else:
        if changed:
            problems.append(f"{mid}: control mutation changed {changed}")

print(f"\n{'id':>4} {'target':>6} {'repl':>5} {'caught':>6}  changed")
for r in rows:
    print(f"{r['id']:>4} {r['target']:>6} {r['replacements']:>5} {str(r['caught']):>6}  {r['changed']}  {r['label']}")
Path("/work/pac/mut/results.json").write_text(json.dumps(rows, indent=1))
print("\nproblems:" if problems else "\nno problems")
for p in problems:
    print(" -", p)
sys.exit(1 if problems else 0)
