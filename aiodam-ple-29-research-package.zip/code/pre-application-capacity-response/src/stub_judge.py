#!/usr/bin/env python3
"""Stub judge on loopback for the wiring test of the task's own verifier path.

It reads the candidate text the grader actually sends, runs the criterion checks on it, and answers
one row per criterion index in the request. It is my reader, not a judge: a 1.0 from it means the
staging, the renderings, the grouping and the weights work — never that the document is good.
"""
import json
import re
import subprocess
import sys
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

PORT = int(sys.argv[1] if len(sys.argv) > 1 else 8790)
PY = "/work/venv-verifier/bin/python"

DBDIFF_RULES = {
    3: [r"Respond to the Feeder ALN-108 pre-application request", r"status[_a-z]*[:=][^|\n]*Closed"],
    4: [r"(?i)withh(eld|olding)", r"ALN-108", r"(?i)capacity"],
    5: [r"(?i)distribution planning", r"ALN-108", r"(?i)follow-?up"],
    6: [r"ALN-108_PreApplication_Response\.docx", r"(?i)correspondence"],
}


def rows_for(text: str, indices: list) -> list:
    rows = []
    dbgroup = [i for i in indices if i in DBDIFF_RULES]
    docgroup = [i for i in indices if i not in DBDIFF_RULES]
    if docgroup:
        cand = Path("/work/pac/stub_candidate.txt")
        cand.write_text(text, encoding="utf-8")
        subprocess.run([PY, "/work/pac/src/checks.py", str(cand)], capture_output=True, text=True)
        state = json.loads(Path("/work/pac/checks.json").read_text())
        by = {r["index"]: r for r in state["results"]}
        for i in docgroup:
            r = by.get(i, {"passed": False, "evidence": "no such check"})
            rows.append({"index": i, "score": 1.0 if r["passed"] else 0.0, "passed": bool(r["passed"]),
                         "evidence": (r["evidence"] or "")[:400] or "none",
                         "reason": "criterion met by the staged text" if r["passed"] else "criterion not met"})
    for i in dbgroup:
        ok = all(re.search(p, text) for p in DBDIFF_RULES[i])
        rows.append({"index": i, "score": 1.0 if ok else 0.0, "passed": bool(ok),
                     "evidence": text[:300].replace("\n", " "), "reason": "db_diff rows present" if ok else "db_diff rows absent"})
    return rows


class H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def do_POST(self):
        n = int(self.headers.get("Content-Length") or 0)
        body = json.loads(self.rfile.read(n) or b"{}")
        payload = ""
        for m in body.get("messages", []):
            if m.get("role") == "user":
                c = m.get("content")
                payload = c if isinstance(c, str) else " ".join(p.get("text", "") for p in c)
        # the criteria block of this call, and the candidate text that follows it
        idx = sorted({int(x) for x in re.findall(r'"index":\s*(\d+)', payload)})
        # the candidate is the staged text that follows the criteria and schema blocks
        marker = payload.find("\n===== ")
        candidate = payload[marker:] if marker >= 0 else payload
        rows = rows_for(candidate, idx)
        out = json.dumps({"choices": [{"message": {"content": json.dumps({"grades": rows})}}]})
        data = out.encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)


HTTPServer(("127.0.0.1", PORT), H).serve_forever()
