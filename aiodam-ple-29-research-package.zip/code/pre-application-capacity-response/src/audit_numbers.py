#!/usr/bin/env python3
"""Every numeric token in the delivered text must come from the record or from a computation over it.

Explained three ways, each independent of the document:
  * the same token occurs in the pristine corpus (pdf/docx/xlsx text dumped to /work/pac/raw);
  * the token is a value computed in computed.json (any formatting of it);
  * the token is a structural identifier (project, document, standard, section, date, phone, address).
Anything else is reported as unexplained. `--control` builds a document with three invented numbers and
shows the audit catches them, so a clean pass is not a vacuum.
"""
import json
import re
import subprocess
import sys
from decimal import Decimal
from pathlib import Path

import docx

COMPUTED = json.loads(Path("/work/pac/computed.json").read_text())
ARGS = [a for a in sys.argv[1:] if not a.startswith("--")]
TXT = Path(ARGS[0] if ARGS else "/work/pac/render/ALN-108_PreApplication_Response.pdf.txt")
RAW = Path("/work/pac/raw")

text = re.sub(r"\s+", " ", TXT.read_text(encoding="utf-8"))
TOKEN = re.compile(r"(?<![\w.])(?:\d[\d,]*(?:\.\d+)?)(?![\w])")
tokens = TOKEN.findall(text)

# ------------------------------------------------------------------ explained: the record itself
corpus = " ".join(p.read_text(encoding="utf-8", errors="replace") for p in RAW.glob("*.txt"))
corpus_tokens = set(TOKEN.findall(re.sub(r"\s+", " ", corpus)))

# ------------------------------------------------------------------ explained: computed values
computed = set()


def add(v):
    try:
        d = Decimal(str(v))
    except Exception:
        return
    computed.add(format(d.normalize(), "f"))
    computed.add(f"{d:.2f}")
    computed.add(f"{d:.1f}")
    computed.add(f"{d:.0f}")
    computed.add(str(abs(d)))
    computed.add(f"{abs(d):.2f}")


def walk(o):
    if isinstance(o, dict):
        for v in o.values():
            walk(v)
    elif isinstance(o, list):
        for v in o:
            walk(v)
    elif isinstance(o, (int, float, str)):
        for m in TOKEN.finditer(str(o)):
            add(m.group(0))


walk(COMPUTED)

# ------------------------------------------------------------------ explained: identifiers and structure
IDENT = [
    r"PXA-\d{4}-\d{4}", r"ALN-\d{3}", r"HCM-2024-Q2", r"PLN-ALN-108-2024-10", r"RA-2025-07-01",
    r"DPG-SIS-BL-2025-07", r"APUC-2025-ER-014", r"ERD-IR-2025-07-014", r"DIR-2025-0627", r"TCS-02",
    r"ERP-9", r"DIS-01", r"CEL-2025-Q2", r"§\s?\d+(\.\d+)*", r"section\s+\d+(\.\d+)*", r"\d{2}/\d{2}/\d{4}",
    r"\(\d{3}\) \d{3}-\d{4}", r"\b1[0-9]{3} [A-Z]", r"Suite \d+", r"Rev \d+", r"page \d+",
]
ident_tokens = set()
for pat in IDENT:
    for m in re.finditer(pat, text):
        ident_tokens.update(TOKEN.findall(m.group(0)))
# section/heading numbers, table row numbers, and the "1 to 5 MW" band are structure, not values
structure = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "12", "02", "03", "01", "2024", "2025", "2023",
             "13.2", "2026"}

unexplained, in_record, in_computed, structural = [], [], [], []
for t in tokens:
    key = t.replace(",", "")
    if key in computed:
        in_computed.append(t)
    elif key in corpus_tokens:
        in_record.append(t)
    elif t in ident_tokens or key in structure:
        structural.append(t)
    else:
        unexplained.append(t)

print(f"numeric tokens: {len(tokens)}   distinct: {len(set(tokens))}")
print(f"  from the record:  {len(in_record)}")
print(f"  computed:         {len(in_computed)}")
print(f"  identifiers:      {len(structural)}")
print(f"  UNEXPLAINED:      {len(unexplained)}  {sorted(set(unexplained))}")
if unexplained:
    for t in sorted(set(unexplained)):
        for m in re.finditer(re.escape(t), text):
            print("   context:", text[max(0, m.start() - 90):m.end() + 90].replace("\n", " "))
            break

if "--control" in sys.argv:
    d = docx.Document("/work/pac/out/ALN-108_PreApplication_Response.docx")
    d.add_paragraph("Pending confirmation, the feeder supports an illustrative headroom of 2.47 MW, "
                    "a study cost of $184,500.00 and 7.31 MW of latent capacity.")
    ctrl = Path("/work/pac/audit/control.docx")
    ctrl.parent.mkdir(parents=True, exist_ok=True)
    d.save(str(ctrl))
    subprocess.run(["python3", "/work/ple-dataset/tasks/pre-application-capacity-response/tests/tools/verifiers/"
                    "deps/transform.py", "--input", str(ctrl), "--output", "/work/pac/audit/control.pdf",
                    "--transformation", "docx_to_pdf"], check=True, capture_output=True,
                   env={"PYTHONPATH": "/work/venv-verifier/lib/python3.12/site-packages", "PATH": "/usr/bin:/bin"})
    subprocess.run(["python3", "/work/ple-dataset/tasks/pre-application-capacity-response/tests/tools/verifiers/"
                    "deps/transform.py", "--input", "/work/pac/audit/control.pdf", "--output",
                    "/work/pac/audit/control.pdf.txt", "--transformation", "pdf_to_text"], check=True,
                   capture_output=True,
                   env={"PYTHONPATH": "/work/venv-verifier/lib/python3.12/site-packages", "PATH": "/usr/bin:/bin"})
    out = subprocess.run([sys.executable, __file__, "/work/pac/audit/control.pdf.txt"], capture_output=True, text=True)
    tail = [ln for ln in out.stdout.splitlines() if "UNEXPLAINED" in ln][0]
    caught = all(v in tail for v in ("2.47", "184,500.00", "7.31"))
    print(f"\ncontrol document: {tail}\ncontrol numbers caught: {caught}")
    sys.exit(0 if (not unexplained and caught) else 1)

sys.exit(0 if not unexplained else 1)
