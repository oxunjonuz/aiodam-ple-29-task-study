#!/usr/bin/env python3
"""Two things, kept apart:

QUOTES   — a fragment the response puts in quotation marks, or reproduces word for word, must stand in the
           record it is attributed to, byte for byte after whitespace normalisation.
SUBSTANCE — a claim the response attributes to a record must have that record's own vocabulary behind it:
           every listed word has to occur in the source.

Both sides are independent of the builder: the delivered PDF text against the pristine corpus.
"""
import re
import sys
from pathlib import Path

RAW = Path("/work/pac/raw")
DOC = re.sub(r"\s+", " ", Path("/work/pac/render/ALN-108_PreApplication_Response.pdf.txt").read_text())


def norm(s):
    return re.sub(r"\s+", " ", s).strip()


def src(name):
    return norm((RAW / name).read_text(encoding="utf-8"))


MAP = "Planning__Hosting_Capacity_Map_Export_2024-05-15.txt"
STUDY = "Planning__2024-10-15_ALN-108_Planning_Study.txt"
QUEUE = "Queue__2025-07-14_Active_Queue_Report.txt"
RA = "Correspondence__2025-07-01_RegAffairs_Tasking_Memo.txt"
APUC = "Correspondence__2025-07-07_APUC_Information_Request.txt"
SIS = "Studies__SIS_Backlog_Status_2025-07.txt"
REG = "Screening__Existing_DER_Register_Extract.txt"
DIS = "DIS-01_Rev4_DER_Interconnection_Standard.txt"
TARIFF = "Tariff_Excerpt_S12_Interconnection.txt"
REQ = "Planning__2025-07-02_PreApp_Request_ALN-108.txt"

QUOTES = [
    ("RA-2025-07-01 section 3.7 quoted in full",
     "Before any capacity figure from the published hosting-capacity map is communicated externally, confirm that "
     "the figure reflects the current state of the affected feeder. A priority refresh is to be requested from "
     "Distribution Planning under the published refresh-prioritization criteria.", RA),
    ("the APUC information request's own phrase",
     "the sufficiency of hosting-capacity information made available to prospective applicants", APUC),
    ("the interim memorandum's section 1 sentence",
     "any project of consequential size on Feeder ALN-108 will require a full feeder-level planning study following "
     "the standard Alleniom Distribution Planning methodology", STUDY),
    ("the map's queue-adjustment rule",
     "prepared against the published value as adjusted for queue entries added since publication", MAP),
    ("the queue status of the feeder's largest queued entry", "system impact study", QUEUE),
    ("the interim arithmetic as the memorandum prints it", "3.0 MW \u2212 1.2 MW = 1.8 MW", STUDY),
]

SUBSTANCE = [
    ("map: the figure is published, per feeder, from a planning study", MAP,
     ["published available capacity", "feeder-level planning study", "recorded peak and minimum load", "existing interconnected DER"]),
    ("map: applicants must confirm with Distribution Planning before sizing", MAP,
     ["consult Distribution Planning for confirmation before finalizing project sizing decisions"]),
    ("map: published values exclude post-publication queue activity", MAP,
     ["do not reflect interconnection queue activity recorded after the publication date", "active-queue register"]),
    ("map: quarterly refresh and its prioritisation criteria", MAP,
     ["quarterly refresh", "application date", "capacity requested", "DER category"]),
    ("study: interim netting is a working reference, not a substitute", STUDY,
     ["working reference", "does not supersede", "not a substitute"]),
    ("study: named limitations", STUDY,
     ["reflects the state of the queue as of the date of this document only", "straight-line nameplate netting",
      "withdrawn or should its final capacity change"]),
    ("study: recommendation 4 routes sizing to Distribution Planning", STUDY,
     ["directed to Distribution Planning for confirmation of the interim position before finalizing project sizing decisions"]),
    ("study: recommendation 3 requires reissue on further queue activity", STUDY,
     ["reissued or superseded if any further queue activity"]),
    ("study: recommendation 2 asks for a refreshed feeder-level study", STUDY,
     ["refreshed feeder-level planning study for Feeder ALN-108 should be scheduled"]),
    ("queue: the four feeder rows and their statuses", QUEUE,
     ["PXA-2023-0894", "PXA-2024-0077" if False else "PXA-2024-0091", "PXA-2024-0231", "PXA-2025-0044",
      "Ravenford Data Services", "Fenwyn Industries Corp", "Grantwyck Solar LLC", "Cindermere Renewables LLC",
      "ISA executed", "construction", "system impact study", "technical screening"]),
    ("queue: program-wide active count", QUEUE, ["Active applications", "380"]),
    ("RA: section 3.7 sits under the Program Manager tasking", RA,
     ["3.7 Hosting-capacity corrections", "priority refresh is to be requested from Distribution Planning"]),
    ("RA: the 08/15/2025 external reporting date", RA, ["08/15/2025", "Alleron Municipal League"]),
    ("APUC: the docket and its sufficiency question", APUC, ["APUC-2025-ER-014", "hosting-capacity information"]),
    ("SIS backlog: no study row for the largest queued entry", SIS, ["SIS-2024-088", "PXA-2024-0117"]),
    ("register: no feeder field, queue applications excluded", REG,
     ["Extract does not include applications currently in queue", "Nameplate (kW)", "Commissioned"]),
    ("DIS-01: Category 3 requirements", DIS,
     ["Dedicated protection relay", "POI recloser", "transfer trip", "Bidirectional revenue meter", "Utility RTU and SCADA"]),
    ("tariff: medium-scale band and queue position on a complete application", TARIFF,
     ["Medium-scale DER", "one megawatt to five megawatts", "determines the application to be complete"]),
    ("request: the three items and the project's parameters", REQ,
     ["Written confirmation of currently available capacity on Feeder ALN-108",
      "Any known conditions, restrictions, or upgrade indications identified by Distribution Planning",
      "Scheduling of a pre-application dialogue meeting", "approximately 3.9 MW-DC", "3 MW-AC"]),
]

bad = []
for label, frag, source in QUOTES:
    d, s = norm(frag), src(source)
    if not (d in DOC and d in s):
        bad.append(("QUOTE", label, f"in document={d in DOC}", f"in source={d in s}"))

for label, source, words in SUBSTANCE:
    s = src(source).lower()
    missing = [w for w in words if norm(w).lower() not in s]
    if missing:
        bad.append(("SUBSTANCE", label, "missing from source", str(missing)))

print(f"{len(QUOTES)} verbatim fragments and {len(SUBSTANCE)} attributed claims checked")
for kind, label, a, b in bad:
    print(f"  FAIL [{kind}] {label}: {a}; {b}")
print("every quote stands in its record and every attribution has that record's vocabulary behind it"
      if not bad else f"{len(bad)} item(s) do not stand")
sys.exit(0 if not bad else 1)
