#!/usr/bin/env python3
"""Derive every number in the ALN-108 response from the record itself.

Sources (pristine task corpus):
  Planning/Hosting_Capacity_Map_Export_2024-05-15.xlsx   -> published available capacity, title-block terms
  Planning/2024-10-15_ALN-108_Planning_Study.docx        -> interim netted figure and its stated limitations
  Queue/2025-07-14_Active_Queue_Report.xlsx              -> every active queue row on Feeder ALN-108
  Studies/SIS_Backlog_Status_2025-07.xlsx                -> whether the feeds' study posture is corroborated
  Correspondence/2025-07-01_RegAffairs_Tasking_Memo.docx -> RA-2025-07-01 section 3.7
No number of the response is typed by hand: they are all built here and read from computed.json.
"""
import json
import re
import subprocess
from datetime import date, datetime
from decimal import Decimal
from pathlib import Path

import docx
import openpyxl

ROOT = Path("/work/ple-dataset/tasks/pre-application-capacity-response/environment/files")
AS_OF = date(2025, 7, 14)          # the record date of the Active Queue Report / the issuance date
REQ_DATE = date(2025, 7, 2)
PUBLICATION = date(2024, 5, 15)
STUDY_DATE = date(2024, 10, 15)


def mw(cell) -> Decimal:
    """'1.2 MW' / '690 kW' -> Decimal MW."""
    s = str(cell).strip()
    m = re.fullmatch(r"([0-9.]+)\s*(MW|kW)", s)
    if not m:
        raise ValueError(f"capacity as filed is not parseable: {cell!r}")
    v = Decimal(m.group(1))
    return v if m.group(2) == "MW" else v / Decimal(1000)


def d(cell) -> date:
    if isinstance(cell, datetime):
        return cell.date()
    if isinstance(cell, date):
        return cell
    return datetime.strptime(str(cell).strip(), "%Y-%m-%d").date()


# ---------------------------------------------------------------- hosting capacity map
wb = openpyxl.load_workbook(ROOT / "Planning/Hosting_Capacity_Map_Export_2024-05-15.xlsx", data_only=True)
tb = {r[0].strip(): (r[1] if len(r) > 1 else None) for r in wb["Title Block"].iter_rows(values_only=True)
      if r and isinstance(r[0], str)}
map_row = None
for r in wb["Feeder Capacity"].iter_rows(values_only=True):
    if r and isinstance(r[0], str) and r[0].strip() == "ALN-108":
        map_row = r
        break
assert map_row, "ALN-108 is not on the published map"
published_mw = Decimal(str(map_row[3]))
map_category = map_row[4]
map_last_study = map_row[5]
map_published = datetime.strptime(str(tb["Published"]), "%m/%d/%Y").date()
assert map_published == PUBLICATION, (map_published, PUBLICATION)
applicability = str(tb["Applicability"])
refresh_criteria = str(tb["Refresh prioritization criteria"])
refresh_commitment = str(tb["Refresh commitment"])
assert "consult Distribution Planning for confirmation before finalizing project sizing" in applicability
assert "prepared against the published value as adjusted for queue entries added since publication" in applicability

# ---------------------------------------------------------------- planning interim memorandum
sd = docx.Document(ROOT / "Planning/2024-10-15_ALN-108_Planning_Study.docx")
study_paras = [p.text.strip() for p in sd.paragraphs]
study_text = "\n".join(study_paras)
m = re.search(r"Interim available capacity: ([0-9.]+) MW [−-] ([0-9.]+) MW = ([0-9.]+) MW", study_text)
assert m, "the interim netted figure is not stated in the study"
study_baseline, study_netted, study_interim = (Decimal(m.group(i)) for i in (1, 2, 3))
assert study_baseline == published_mw
assert study_baseline - study_netted == study_interim
study_queue_table = sd.tables[1]
assert len(study_queue_table.rows) == 2, "the study's queue table should carry exactly one post-publication entry"
sq = [c.text.strip() for c in study_queue_table.rows[1].cells]
study_entry = {"queue_date": datetime.strptime(sq[0], "%m/%d/%Y").date(), "feeder": sq[1],
               "capacity_mw": mw(sq[2]), "category": sq[3]}
assert study_entry["capacity_mw"] == study_netted, (study_entry, study_netted)

# ---------------------------------------------------------------- active queue report
wbq = openpyxl.load_workbook(ROOT / "Queue/2025-07-14_Active_Queue_Report.xlsx", data_only=True)
ws = wbq["Active Queue"]
hdr = [c.value for c in ws[1]]
rows = []
for r in ws.iter_rows(min_row=2, values_only=True):
    rec = dict(zip(hdr, r))
    if rec.get("Feeder") == "ALN-108":
        rows.append({"project": rec["Project ID"], "customer": rec["Customer"], "site": rec["Site"],
                     "capacity_mw": mw(rec["Capacity"]), "status": rec["Status"],
                     "queue_date": d(rec["Queue Date"])})
rows.sort(key=lambda x: x["queue_date"])
totals_sheet = {r[0].strip(): r[1] for r in wbq["Totals"].iter_rows(values_only=True)
                if r and isinstance(r[0], str)}
queue_as_of = datetime.strptime(str(totals_sheet["As of:"]), "%m/%d/%Y").date()
assert queue_as_of == AS_OF, (queue_as_of, AS_OF)
active_total = int(totals_sheet["Active applications"])

post_pub = [r for r in rows if r["queue_date"] > PUBLICATION]
pre_pub = [r for r in rows if r["queue_date"] <= PUBLICATION]
post_pub_mw = sum((r["capacity_mw"] for r in post_pub), Decimal(0))
pre_pub_mw = sum((r["capacity_mw"] for r in pre_pub), Decimal(0))
all_mw = sum((r["capacity_mw"] for r in rows), Decimal(0))
assert post_pub_mw + pre_pub_mw == all_mw

# the study's single post-publication entry must be one of the queue rows, at the same capacity
match = [r for r in rows if r["queue_date"] == study_entry["queue_date"]]
assert len(match) == 1 and match[0]["capacity_mw"] == study_entry["capacity_mw"], (match, study_entry)

# ---------------------------------------------------------------- SIS backlog corroboration
wbs = openpyxl.load_workbook(ROOT / "Studies/SIS_Backlog_Status_2025-07.xlsx", data_only=True)
wss = wbs["SIS Backlog"]
sis_rows, sis_total = [], 0
for r in wss.iter_rows(values_only=True):
    if r and isinstance(r[1], str) and re.fullmatch(r"PXA-\d{4}-\d{4}", r[1].strip()):
        sis_total += 1
        sis_rows.append({"study": r[0], "project": r[1].strip(), "feeder": r[4], "status": r[10]})
sis_matches = [s for s in sis_rows if s["project"] in {r["project"] for r in rows}]
assert sis_total > 40, sis_total

# ---------------------------------------------------------------- RA-2025-07-01 section 3.7
ra = docx.Document(ROOT / "Correspondence/2025-07-01_RegAffairs_Tasking_Memo.docx")
ra_text = "\n".join(p.text.strip() for p in ra.paragraphs)
m = re.search(r"3\.7 Hosting-capacity corrections\. (.+)", ra_text)
assert m, "RA-2025-07-01 section 3.7 is not found"
ra_37 = " ".join(m.group(1).split())
assert ra_37.startswith("Before any capacity figure from the published hosting-capacity map is communicated externally")
ra_docno = [c.text.strip() for c in ra.tables[0].rows[0].cells][1]
assert ra_docno == "RA-2025-07-01", ra_docno

# ---------------------------------------------------------------- APUC information request
apuc_txt = subprocess.run(["pdftotext", "-layout",
                           str(ROOT / "Correspondence/2025-07-07_APUC_Information_Request.pdf"), "-"],
                          capture_output=True, text=True).stdout
apuc_sufficiency = "the sufficiency of hosting-capacity information made available to prospective applicants"
assert apuc_sufficiency in " ".join(apuc_txt.split())
m = re.search(r"Docket:\s*(APUC-\S+)", apuc_txt)
apuc_docket = m.group(1)

# ---------------------------------------------------------------- readings of the same records
readings = [
    {"id": "A", "rule": "published value adjusted for queue entries added since publication (the map's own rule)",
     "minuend_mw": published_mw, "subtrahend_mw": post_pub_mw,
     "value_mw": published_mw - post_pub_mw,
     "addends": [str(r["capacity_mw"]) for r in post_pub]},
    {"id": "B", "rule": "the Program's interim memorandum as it stands, un-updated",
     "minuend_mw": study_baseline, "subtrahend_mw": study_netted,
     "value_mw": study_interim, "addends": [str(study_netted)]},
    {"id": "C", "rule": "every active queue entry on the feeder netted against the published figure",
     "minuend_mw": published_mw, "subtrahend_mw": all_mw,
     "value_mw": published_mw - all_mw,
     "addends": [str(r["capacity_mw"]) for r in sorted(rows, key=lambda x: -x["capacity_mw"])]},
]
REQUEST_MW = Decimal("3")
for r in readings:
    r["shortfall_mw"] = REQUEST_MW - r["value_mw"]
    r["value_str"] = f"{r['value_mw']:.2f}" if r["value_mw"] >= 0 else f"\u2212{abs(r['value_mw']):.2f}"

computed = {
    "as_of": AS_OF.isoformat(), "request_date": REQ_DATE.isoformat(),
    "published_mw": str(published_mw), "map_category": map_category, "map_last_study": map_last_study,
    "map_published": PUBLICATION.isoformat(), "map_age_days": (AS_OF - PUBLICATION).days,
    "map_age_cycles": round((AS_OF - PUBLICATION).days / 91.25, 1),
    "study_date": STUDY_DATE.isoformat(), "study_age_days": (AS_OF - STUDY_DATE).days,
    "study_baseline_mw": str(study_baseline), "study_netted_mw": str(study_netted),
    "study_interim_mw": str(study_interim), "study_doc": "PLN-ALN-108-2024-10 Rev 1",
    "queue_rows": [{**r, "queue_date": r["queue_date"].isoformat(), "capacity_mw": str(r["capacity_mw"])}
                   for r in rows],
    "queue_row_count": len(rows), "queue_active_total": active_total,
    "post_pub_count": len(post_pub), "post_pub_mw": str(post_pub_mw),
    "pre_pub_count": len(pre_pub), "pre_pub_mw": str(pre_pub_mw), "all_mw": str(all_mw),
    "post_pub_share_of_published_pct": round(float(post_pub_mw / published_mw * 100), 1),
    "all_share_of_published_pct": round(float(all_mw / published_mw * 100), 1),
    "request_mw": str(REQUEST_MW),
    "request_share_of_published_pct": round(float(REQUEST_MW / published_mw * 100), 1),
    "newest_queue_age_days": (AS_OF - max(r["queue_date"] for r in rows)).days,
    "readings": [{**r, "minuend_mw": str(r["minuend_mw"]), "subtrahend_mw": str(r["subtrahend_mw"]),
                  "value_mw": str(r["value_mw"]), "shortfall_mw": str(r["shortfall_mw"])} for r in readings],
    "spread_mw": str(max(r["value_mw"] for r in readings) - min(r["value_mw"] for r in readings)),
    "sis_total_rows": sis_total, "sis_matches": sis_matches, "sis_match_count": len(sis_matches),
    "ra_doc": ra_docno, "ra_37": ra_37,
    "apuc_docket": apuc_docket, "apuc_sufficiency_question": apuc_sufficiency,
    "applicability": applicability, "refresh_criteria": refresh_criteria,
    "refresh_commitment": refresh_commitment,
}
Path("/work/pac/computed.json").write_text(json.dumps(computed, indent=1, ensure_ascii=False))
print(json.dumps(computed, indent=1, ensure_ascii=False))
