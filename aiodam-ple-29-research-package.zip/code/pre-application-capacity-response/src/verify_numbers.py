#!/usr/bin/env python3
"""Second path over the same numbers: parse the raw text dumps (not the xlsx/docx objects) with
different code, recompute with Fraction, and require each result to appear in the delivered text."""
import json
import re
import sys
from datetime import date
from fractions import Fraction
from pathlib import Path

RAW = Path("/work/pac/raw")
DOC = re.sub(r"\s+", " ", Path("/work/pac/render/ALN-108_PreApplication_Response.pdf.txt").read_text())


def num(s: str) -> Fraction:
    return Fraction(s)


# published figure: the ALN-108 row of the map dump
map_txt = (RAW / "Planning__Hosting_Capacity_Map_Export_2024-05-15.txt").read_text()
row = [ln for ln in map_txt.splitlines() if ln.startswith("ALN-108 |")][0]
published = num(row.split("|")[3].strip())
assert published == 3

# queue rows: every line of the active-queue dump carrying ALN-108
queue_txt = (RAW / "Queue__2025-07-14_Active_Queue_Report.txt").read_text()
entries = []
for ln in queue_txt.splitlines():
    if "| ALN-108 |" in ln:
        parts = [p.strip() for p in ln.split("|")]
        cap = parts[3]
        m = re.fullmatch(r"([0-9.]+) (MW|kW)", cap)
        v = num(m.group(1)) / (1 if m.group(2) == "MW" else 1000)
        qd = date.fromisoformat(parts[5][:10])
        entries.append((parts[0], v, qd, parts[6]))
assert len(entries) == 4, entries
post = sum((v for _, v, qd, _ in entries if qd > date(2024, 5, 15)), Fraction(0))
allq = sum((v for _, v, _, _ in entries), Fraction(0))
assert post == Fraction(22, 10) and allq == Fraction(399, 100), (post, allq)

# interim figure: the arithmetic line in the study dump
study_txt = (RAW / "Planning__2024-10-15_ALN-108_Planning_Study.txt").read_text()
line = [ln for ln in study_txt.splitlines() if "Interim available capacity" in ln][0]
m = re.search(r"([0-9.]+) MW \u2212 ([0-9.]+) MW = ([0-9.]+) MW", line)
interim = num(m.group(3))
assert interim == published - num(m.group(2)) == Fraction(18, 10)

req = Fraction(3)
values = {"A": published - post, "B": interim, "C": published - allq}
assert values == {"A": Fraction(8, 10), "B": Fraction(18, 10), "C": Fraction(-99, 100)}, values
spread = max(values.values()) - min(values.values())
assert spread == Fraction(279, 100), spread
shares = {"post": round(float(post / published * 100), 1), "all": round(float(allq / published * 100), 1)}
ages = {"map": (date(2025, 7, 14) - date(2024, 5, 15)).days,
        "study": (date(2025, 7, 14) - date(2024, 10, 15)).days,
        "newest": (date(2025, 7, 14) - max(qd for _, _, qd, _ in entries)).days}
assert ages == {"map": 425, "study": 272, "newest": 158}, ages
assert shares == {"post": 73.3, "all": 133.0}, shares

# the active-queue count program-wide, from the Totals block of the same dump
tot = [ln for ln in queue_txt.splitlines() if ln.startswith("Active applications |")][0]
active_total = int(tot.split("|")[1])

checks = {
    "published 3.0": "3.0 MW",
    "post-publication 2.2": "2.2 MW",
    "all queued 3.99": "3.99 MW",
    "reading A 0.8": "0.8 MW",
    "reading B 1.8": "1.8 MW",
    "reading C -0.99": "\u22120.99",
    "spread 2.79": "2.79 MW",
    "shortfall A 2.2": "2.2 MW",
    "shortfall B 1.2": "1.2 MW",
    "share post 73.3": "73.3",
    "share all 133": "133",
    "map age 425": "425 days",
    "study age 272": "272 days",
    "newest 158": "158 days",
    "active total 380": "380 active applications",
    "interim line": "3.0 MW \u2212 1.2 MW = 1.8 MW",
}
missing = [k for k, s in checks.items() if s not in DOC]
for k, s in checks.items():
    print(f"{'ok ' if s in DOC else 'MISSING'} {k}: {s!r}")
print(f"\nactive applications program-wide, re-read: {active_total}")
print("all fifteen recomputed quantities present" if not missing else f"MISSING: {missing}")
sys.exit(0 if not missing else 1)
