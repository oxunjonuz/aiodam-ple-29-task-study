"""Randomised descent around the feasible corner of the deck-assignment space."""
import json
import random
import sys
import time

sys.argv = ['x']
exec(open('/work/ple-solve/wind-diaphragm-shear/opt.py').read().split("if __name__")[0])

CHEAP = sorted(DECKS, key=lambda c: DECKS[c]['cost_per_sf'])
CHORD0 = {ln: 'PL3x3/8' for ln in LINES}


def slack(r):
    """Smallest relative headroom over the binding checks (1.0 = one of them is exactly at limit)."""
    s = []
    for m, v in r['vmax'].items():
        s.append(BASE * WIDTH[m] / max(v, 1e-9))
    s.append(DRIFT / max(r['drift'], 1e-9))
    s.append((ROOFZ * 12.0 * PIER_RATIO) / max(r['pier_drift'], 1e-9))
    return min(s)


def descend(dm, cm, log=print, tag=''):
    best = evaluate(dm, cm)
    improved = True
    while improved:
        improved = False
        for z in ZONES:
            for code in CHEAP:
                if code == dm[z]:
                    continue
                trial = dict(dm)
                trial[z] = code
                if len(set(trial.values())) > MAXTYPES:
                    continue
                r = evaluate(trial, cm)
                if r['ok_struct'] and r['cost']['total'] < best['cost']['total'] - 1e-6:
                    dm, best, improved = trial, r, True
                    break
            if improved:
                break
    return dm, best


def main():
    rnd = random.Random(int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].isdigit() else 7)
    t0 = time.time()
    start = {z: 'D16-36/9-4' for z in ZONES}
    dm, best = descend(dict(start), dict(CHORD0), tag='seed')
    print('seed descent $%.0f slack %.3f' % (best['cost']['total'], slack(best)))
    keep = [(best['cost']['total'], dict(best['deck_map']), slack(best), best['drift'],
             len(best['ties']))]
    for k in range(14):
        trial = dict(start)
        # perturb: two or three zones to a random deck
        for z in rnd.sample(ZONES, rnd.choice([2, 3, 4])):
            trial[z] = rnd.choice(CHEAP[:10])
        try:
            d2, b2 = descend(trial, dict(CHORD0))
        except Exception as exc:  # noqa: BLE001
            print('restart %d failed: %s' % (k, exc))
            continue
        if b2['ok_struct']:
            keep.append((b2['cost']['total'], dict(b2['deck_map']), slack(b2), b2['drift'],
                         len(b2['ties'])))
            print('restart %d $%.0f slack %.3f drift %.3f ties %d  %.0fs' % (
                k, b2['cost']['total'], slack(b2), b2['drift'], len(b2['ties']),
                time.time() - t0))
    keep.sort(key=lambda t: t[0])
    print('\n=== top feasible designs (cost, slack) ===')
    seen = set()
    out = []
    for cost, dmx, sl, dr, nt in keep:
        key = tuple(sorted(dmx.items()))
        if key in seen:
            continue
        seen.add(key)
        print('$%.0f slack %.3f drift %.3f ties %d  types %s' % (
            cost, sl, dr, nt, sorted(set(dmx.values()))))
        out.append(dict(cost=cost, deck=dmx, slack=sl, drift=dr, ties=nt))
    with open('/work/ple-solve/wind-diaphragm-shear/cands_search.json', 'w') as f:
        json.dump(out, f, indent=1)


main()
