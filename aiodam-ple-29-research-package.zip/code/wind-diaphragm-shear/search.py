"""Coordinate-descent cost search over the deck field with the real constraint set."""
import json
import math
import build as B
import sweep as S

AREAS = B.zone_areas()
CHEAP = 'D22-36/4-2'


def cost_of(assign):
    return sum(AREAS[z] * B.DECK[assign[z]]['cost'] for z in AREAS)


def check(assign):
    r = S.evaluate(assign)
    ok = (r['drift'] <= 0.55 and r['base'] <= 1.40 and r['pier_max'] <= 0.84 and
          all(r['zs'][z] <= B.DECK[assign[z]]['cap'] for z in AREAS) and
          len(set(assign.values())) <= 4)
    return ok, r


if __name__ == '__main__':
    cur = {z: 'D16-36/9-4' for z in AREAS}
    best_cost = cost_of(cur)
    print('start %.0f' % best_cost, flush=True)
    order = sorted(AREAS, key=lambda z: -AREAS[z])
    trials = [CHEAP, 'D22-36/7-2', 'D22-36/7-4', 'D20-36/7-4', 'D18-36/9-4']
    for sweep_i in range(3):
        improved = False
        for z in order:
            for code in trials:
                if B.DECK[code]['cost'] >= B.DECK[cur[z]]['cost']:
                    continue
                t = dict(cur)
                t[z] = code
                if len(set(t.values())) > 4:
                    continue
                if cost_of(t) >= best_cost:
                    continue
                ok, r = check(t)
                print('  %s -> %s : %s cost %.0f drift %.3f base %.2f' % (z, code, ok, cost_of(t), r['drift'], r['base']), flush=True)
                if ok:
                    cur = t
                    best_cost = cost_of(t)
                    improved = True
                    break
        print('pass %d best %.0f %s' % (sweep_i, best_cost, cur), flush=True)
        if not improved:
            break
    ok, r = check(cur)
    print('FINAL ok=%s cost=%.0f %s' % (ok, cost_of(cur), cur), flush=True)
    print('drift %.3f base %.2f pier %.3f' % (r['drift'], r['base'], r['pier_max']), flush=True)
    json.dump(dict(assign=cur, ok=ok, deck_cost=cost_of(cur), drift=r['drift'], base=r['base']),
              open('deck_best.json', 'w'), indent=1)
