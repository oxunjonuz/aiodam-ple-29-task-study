"""Building A2 lateral package: DIAPH-MT analysis and design (EOR-NDDC-A2-S01 Rev 2)."""
import json
import math
import numpy as np
import ifcopenshell
import ifcopenshell.util.element as ue
import csv

WS = 'ws/final_batch4__structural_task5_wind_diaphragm_shear__blind'
H_DECK = 28.0          # roof deck elevation, ft (SR-2026-118 s3, IFC Pset_RoofCommon)
OUTLINE = [(0, 0), (240, 0), (240, 140), (180, 140), (180, 180), (0, 180)]
OPENINGS = [[(100, 100), (140, 100), (140, 130), (100, 130)]]
EC = 4030.0            # ksi
G_MOD = 0.40 * EC      # ksi
OMEGA_D = 2.35
RHO = 0.150            # kcf
STEEL_RATE = 2.85      # $/lb installed
EMBED_CAP = 4.20       # kip ASD per E1 embed
EMBED_COST = 185.0
TIEDOWN_CAP = 88.0
TIEDOWN_COST = 2450.0
BASE_CAP = 1.40        # kip/ft ASD panel base connection
DEFL_LIMIT = 0.55      # in

DECKS = [  # code, nominal_plf, G' kip/in @6ft, $/sf
    ('D22-36/4-2', 980, 17.8, 3.05), ('D22-36/4-4', 1240, 22.9, 3.34),
    ('D22-36/7-2', 1610, 25.4, 3.62), ('D22-36/7-4', 1980, 32.6, 3.95),
    ('D20-36/4-2', 1290, 21.6, 3.48), ('D20-36/7-2', 2050, 30.9, 4.06),
    ('D20-36/7-4', 2530, 39.7, 4.43), ('D20-36/9-4', 2980, 46.1, 4.77),
    ('D18-36/7-2', 2640, 38.2, 4.62), ('D18-36/7-4', 3280, 49.4, 5.03),
    ('D18-36/9-4', 3870, 57.8, 5.41), ('D18-36/9-5', 4210, 63.5, 5.72),
    ('D16-36/7-4', 3910, 58.9, 5.58), ('D16-36/9-4', 4620, 69.3, 6.02),
    ('D16-36/9-5', 5060, 76.4, 6.38), ('D16-36/9-6', 5390, 82.1, 6.71),
]
DECK = {d[0]: dict(code=d[0], nom=d[1], g=d[2], cost=d[3], cap=d[1] / OMEGA_D) for d in DECKS}

SECTIONS = [  # code, area, weight_plf, allow_T, allow_C
    ('PL3x3/8', 1.125, 3.83, 33.8, 20.3), ('PL4x3/8', 1.5, 5.1, 45.0, 27.0),
    ('PL5x1/2', 2.5, 8.5, 75.0, 45.0), ('PL6x1/2', 3.0, 10.2, 90.0, 54.0),
    ('PL8x1/2', 4.0, 13.6, 120.0, 72.0), ('PL8x5/8', 5.0, 17.0, 150.0, 90.0),
    ('PL10x5/8', 6.25, 21.25, 187.5, 112.5), ('PL10x3/4', 7.5, 25.5, 225.0, 135.0),
    ('PL12x3/4', 9.0, 30.6, 270.0, 162.0), ('PL12x1', 12.0, 40.8, 360.0, 216.0),
]

LINES = {  # line: (p0, p1, inward normal, axis of in-plane direction)
    'S':  ((0.0, 0.0), (240.0, 0.0), (0, 1), 0),
    'E':  ((240.0, 0.0), (240.0, 140.0), (-1, 0), 1),
    'N1': ((0.0, 180.0), (180.0, 180.0), (0, -1), 0),
    'N2': ((180.0, 140.0), (240.0, 140.0), (0, -1), 0),
    'E2': ((180.0, 140.0), (180.0, 180.0), (1, 0), 1),
    'W':  ((0.0, 0.0), (0.0, 180.0), (1, 0), 1),
}
# station origin of each line (the coordinate at which its station 0 lies)
S_ORIGIN = {'S': 0.0, 'E': 0.0, 'N1': 0.0, 'W': 0.0, 'N2': 180.0, 'E2': 140.0}


def line_xy(line, s):
    p0, p1, nrm, axis = LINES[line]
    d = np.array(p1) - np.array(p0)
    d = d / np.linalg.norm(d)
    return np.array(p0) + d * (s - S_ORIGIN[line])

ZONES = {}
for zi, zx in enumerate(['Z1', 'Z2', 'Z3', 'Z4']):
    for zj, zy in enumerate(['1', '2', '3']):
        ZONES[f'{zx}{zy}'] = (60.0 * zi, 60.0 * zj, 60.0 * zi + 60.0, 60.0 * zj + 60.0)
# zone label of S-201: Z11 Z12 Z13 / Z21 Z22 Z23 / Z31.. / Z41..
ZONES = {'Z11': (0, 0, 60, 60), 'Z12': (0, 60, 60, 120), 'Z13': (0, 120, 60, 180),
         'Z21': (60, 0, 120, 60), 'Z22': (60, 60, 120, 120), 'Z23': (60, 120, 120, 180),
         'Z31': (120, 0, 180, 60), 'Z32': (120, 60, 180, 120), 'Z33': (120, 120, 180, 180),
         'Z41': (180, 0, 240, 60), 'Z42': (180, 60, 240, 120), 'Z43': (180, 120, 240, 180)}

CHORD_LINES = [
    ('C-S', (0, 0), (240, 0)), ('C-N1', (0, 180), (180, 180)), ('C-N2', (180, 140), (240, 140)),
    ('C-E', (240, 0), (240, 140)), ('C-E2', (180, 140), (180, 180)), ('C-W', (0, 0), (0, 180)),
    ('K-N2', (0, 140), (180, 140)), ('K-E2', (180, 0), (180, 140)),
    ('O-S', (100, 100), (140, 100)), ('O-N', (100, 130), (140, 130)),
    ('O-W', (100, 100), (100, 130)), ('O-E', (140, 100), (140, 130)),
]


# ------------------------------------------------------------------ geometry
def clip(subject, rect):
    """Sutherland-Hodgman clip of a polygon by an axis-aligned rectangle."""
    x0, y0, x1, y1 = rect
    def clip_edge(pts, inside, inter):
        out = []
        for i in range(len(pts)):
            a, b = pts[i], pts[(i + 1) % len(pts)]
            ia, ib = inside(a), inside(b)
            if ia:
                out.append(a)
                if not ib:
                    out.append(inter(a, b))
            elif ib:
                out.append(inter(a, b))
        return out
    pts = list(subject)
    for (inside, inter) in [
        (lambda p: p[0] >= x0, lambda a, b: (x0, a[1] + (b[1] - a[1]) * (x0 - a[0]) / (b[0] - a[0]))),
        (lambda p: p[0] <= x1, lambda a, b: (x1, a[1] + (b[1] - a[1]) * (x1 - a[0]) / (b[0] - a[0]))),
        (lambda p: p[1] >= y0, lambda a, b: (a[0] + (b[0] - a[0]) * (y0 - a[1]) / (b[1] - a[1]), y0)),
        (lambda p: p[1] <= y1, lambda a, b: (a[0] + (b[0] - a[0]) * (y1 - a[1]) / (b[1] - a[1]), y1)),
    ]:
        if not pts:
            return []
        pts = clip_edge(pts, inside, inter)
    return pts


def area(poly):
    a = 0.0
    for i in range(len(poly)):
        x1, y1 = poly[i]
        x2, y2 = poly[(i + 1) % len(poly)]
        a += x1 * y2 - x2 * y1
    return abs(a) / 2.0


def zone_areas():
    out = {}
    for z, rect in ZONES.items():
        a = area(clip(OUTLINE, rect))
        for op in OPENINGS:
            a -= area(clip(op, rect))
        out[z] = a
    return out


def load_panels():
    f = ifcopenshell.open(f'{WS}/project/20_survey/NDDC-A2_Federated_Model_2026.ifc')
    panels = []
    for w in f.by_type('IfcWall'):
        p = ue.get_psets(w)['Pset_PrecastPanel']
        panels.append(dict(mark=w.Name, line=p['WallLine'], s0=p['StartStationMm'] / 304.8,
                           s1=p['EndStationMm'] / 304.8, t=p['ThicknessMm'] / 25.4,
                           top=p['TopElevationMm'] / 304.8, openings=[]))
    pmap = {p['mark']: p for p in panels}
    for rel in f.by_type('IfcRelVoidsElement'):
        mark = rel.RelatingBuildingElement.Name
        q = ue.get_psets(rel.RelatedOpeningElement)['Pset_OpeningCommon']
        pmap[mark]['openings'].append(dict(id=rel.RelatedOpeningElement.Name,
                                           a=q['StartStationMm'] / 304.8, b=q['EndStationMm'] / 304.8,
                                           sill=q['SillElevationMm'] / 304.8, head=q['HeadElevationMm'] / 304.8,
                                           prov=q['Provenance']))
    return panels


def legs_of(panel):
    """legs between opening edges and panel edges, in panel station coordinates"""
    cuts = []
    for o in sorted(panel['openings'], key=lambda o: o['a']):
        cuts.append((o['a'], o['b']))
    legs = []
    y = panel['s0']
    for (a, b) in cuts:
        if a > y:
            legs.append((y, a))
        y = max(y, b)
    if y < panel['s1']:
        legs.append((y, panel['s1']))
    return [(a, b) for (a, b) in legs if b - a >= 2.0 - 1e-9]


def pier_stiffness(t_in, L_ft, h_in=H_DECK * 12.0):
    L = L_ft * 12.0
    I = t_in * L ** 3 / 12.0
    A = t_in * L
    return 1.0 / (h_in ** 3 / (3 * EC * I) + 1.2 * h_in / (G_MOD * A))


def build_piers(panels):
    piers = []
    for p in panels:
        p0, p1, nrm, axis = LINES[p['line']]
        d = np.array(p1) - np.array(p0)
        d = d / np.linalg.norm(d)
        legs = legs_of(p)
        for k, (a, b) in enumerate(legs):
            mid = np.array(p0) + d * ((a + b) / 2.0 - S_ORIGIN[p['line']])
            kstiff = pier_stiffness(p['t'], b - a)
            pid = f"{p['mark']}-{k+1}" if len(legs) > 1 else p['mark']
            piers.append(dict(id=pid, panel=p['mark'], line=p['line'],
                              s0=a, s1=b, width=b - a, t=p['t'], top=p['top'], k=kstiff,
                              xy=(float(mid[0]), float(mid[1])), dir=(float(d[0]), float(d[1]))))
    return piers


# -------------------------------------------------------------------- wind
def qz(z):
    z = max(z, 15.0)
    Kz = 2.01 * (z / 900.0) ** (2.0 / 9.5)
    return 0.00256 * Kz * 1.19 * 0.85 * math.exp(-0.0000362 * 3940.0) * 115.0 ** 2


BANDS = [('B1', 0.0, 7.0), ('B2', 7.0, 14.0), ('B3', 14.0, 21.0), ('B4', 21.0, 28.0)]


def read_cp():
    cp = {}
    with open(f'{WS}/project/40_wind/WT-2026-07_Cp_by_azimuth.csv') as fh:
        for row in csv.DictReader(fh):
            cp[(row['patch_id'], int(row['azimuth_deg']))] = float(row['cp'])
    return cp


SCEN = [('W01', 0), ('W02', 45), ('W03', 90), ('W04', 135), ('W05', 180), ('W06', 225),
        ('W07', 270), ('W08', 315), ('W09', 0), ('W10', 0), ('W11', 90), ('W12', 90)]
TORSION = {'W09': (+0.15, 'X'), 'W10': (-0.15, 'X'), 'W11': (+0.15, 'Y'), 'W12': (-0.15, 'Y')}


def panel_patches(panels, cp, az):
    """roof-level reaction R_roof of every patch, per panel, at strength level, and its line"""
    out = []
    qh = qz(H_DECK)
    for p in panels:
        L = p['s1'] - p['s0']
        # wall bands
        for (bn, z0, z1) in BANDS:
            c = cp.get((f"{p['mark']}-{bn}", az))
            if c is None:
                continue
            zc = 0.5 * (z0 + z1)
            F = qh * c * (L * (z1 - z0))
            out.append(dict(panel=p['mark'], line=p['line'], patch=f"{p['mark']}-{bn}",
                            F=F, z=zc, R=F * zc / H_DECK, zone='wall'))
        # parapet / screen band
        if p['top'] > H_DECK:
            c = cp.get((f"{p['mark']}-P", az))
            if c is None:
                continue
            qp = qz(p['top'])
            z0, z1 = H_DECK, p['top']
            zc = 0.5 * (z0 + z1)
            F = qp * c * (L * (z1 - z0))
            out.append(dict(panel=p['mark'], line=p['line'], patch=f"{p['mark']}-P",
                            F=F, z=zc, R=F * zc / H_DECK, zone='parapet'))
    return out


def line_loads(panels, cp, az, asd=0.6):
    patches = panel_patches(panels, cp, az)
    tot = {ln: 0.0 for ln in LINES}
    for p in patches:
        tot[p['line']] += p['R']
    out = {}
    for ln, (p0, p1, nrm, axis) in LINES.items():
        L = math.dist(p0, p1)
        out[ln] = asd * tot[ln] / L / 1000.0   # kip/ft along the line, signed along the inward normal
    return out, patches


def line_load_segments(panels, cp, az, asd=0.6):
    """Roof-level line load of criteria 6.4 as a piecewise load per panel, kip/ft ASD, inward positive."""
    h = H_DECK
    qh = qz(H_DECK)
    out = {}
    for p in panels:
        w = 0.0
        for (bn, z0, z1) in BANDS:
            c = cp.get((f"{p['mark']}-{bn}", az))
            if c is None:
                continue
            zc = 0.5 * (z0 + z1)
            w += qh * c / 1000.0 * (z1 - z0) * zc / h
        if p['top'] > H_DECK:
            c = cp.get((f"{p['mark']}-P", az))
            if c is not None:
                z0, z1 = H_DECK, p['top']
                zc = 0.5 * (z0 + z1)
                w += qz(p['top']) * c / 1000.0 * (z1 - z0) * zc / h
        a = p['s0'] - S_ORIGIN[p['line']]
        b = p['s1'] - S_ORIGIN[p['line']]
        out.setdefault(p['line'], []).append((a, b, asd * w))
    return out


if __name__ == '__main__':
    panels = load_panels()
    print('panels', len(panels))
    piers = build_piers(panels)
    print('piers', len(piers), 'k range %.0f..%.0f' % (min(p['k'] for p in piers), max(p['k'] for p in piers)))
    za = zone_areas()
    print('zone areas', {k: round(v) for k, v in za.items()}, 'total', round(sum(za.values())))
    cp = read_cp()
    print('patches in csv', len(set(k[0] for k in cp)))
    print('q_h %.3f psf   q(31) %.3f  q(36) %.3f' % (qz(28), qz(31), qz(36)))
    for sc, az in SCEN[:8]:
        ll, _ = line_loads(panels, cp, az)
        print(sc, az, {k: round(v, 1) for k, v in ll.items()})
