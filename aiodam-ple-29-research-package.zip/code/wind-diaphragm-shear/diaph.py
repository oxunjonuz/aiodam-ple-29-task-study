"""DIAPH-MT: semi-rigid roof diaphragm analysis per EOR-NDDC-A2-S01 Rev 2 section 9.

Units: lengths ft, forces kip, membrane stiffness kip/ft, pier springs kip/in, displacements ft.
"""
import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as spla


def point_in_poly(x, y, poly):
    inside = False
    n = len(poly)
    for i in range(n):
        x1, y1 = poly[i]
        x2, y2 = poly[(i + 1) % n]
        if ((y1 > y) != (y2 > y)) and (x < (x2 - x1) * (y - y1) / (y2 - y1) + x1):
            inside = not inside
    return inside


class Model:
    def __init__(self, outline, openings, H, eax, eay, gprime_fn, chords, piers):
        self.outline = outline
        self.openings = openings
        self.H = H
        self.eax = eax
        self.eay = eay
        self.gprime_fn = gprime_fn
        self.chords = chords
        self.piers = piers
        self._mesh()

    def _mesh(self):
        H = self.H
        xs = np.arange(0, max(p[0] for p in self.outline) + 1e-9, H)
        ys = np.arange(0, max(p[1] for p in self.outline) + 1e-9, H)
        cells = []
        for i in range(len(xs) - 1):
            for j in range(len(ys) - 1):
                cx, cy = xs[i] + H / 2, ys[j] + H / 2
                if not point_in_poly(cx, cy, self.outline):
                    continue
                if any(point_in_poly(cx, cy, op) for op in self.openings):
                    continue
                cells.append((i, j))
        used = set()
        for (i, j) in cells:
            used.update([(i, j), (i + 1, j), (i, j + 1), (i + 1, j + 1)])
        nodes = sorted(used)
        nid = {n: k for k, n in enumerate(nodes)}
        self.xs, self.ys = xs, ys
        self.nodes = np.array([[xs[i], ys[j]] for (i, j) in nodes], float)
        self.node_ij = nodes
        self.elems = [(nid[(i, j)], nid[(i + 1, j)], nid[(i + 1, j + 1)], nid[(i, j + 1)]) for (i, j) in cells]
        self.cells = cells

    def _D(self, x, y):
        eax = self.eax(x, y) if callable(self.eax) else self.eax
        eay = self.eay(x, y) if callable(self.eay) else self.eay
        g = 12.0 * self.gprime_fn(x, y)
        return np.diag([eax, eay, g])

    def assemble(self):
        ndof = 2 * len(self.nodes)
        rows, cols, vals = [], [], []
        self.ghat_e = np.zeros(len(self.elems))
        gq = 1 / np.sqrt(3.0)
        gp = [(-gq, -gq), (gq, -gq), (gq, gq), (-gq, gq)]
        for e, conn in enumerate(self.elems):
            xy = self.nodes[list(conn)]
            D = self._D(xy[:, 0].mean(), xy[:, 1].mean())
            Ke = np.zeros((8, 8))
            for (xi, eta) in gp:
                dN = 0.25 * np.array([[-(1 - eta), (1 - eta), (1 + eta), -(1 + eta)],
                                      [-(1 - xi), -(1 + xi), (1 + xi), (1 - xi)]])
                J = dN @ xy
                dNxy = np.linalg.inv(J) @ dN
                B = np.zeros((3, 8))
                B[0, 0::2] = dNxy[0]; B[1, 1::2] = dNxy[1]
                B[2, 0::2] = dNxy[1]; B[2, 1::2] = dNxy[0]
                Ke += B.T @ D @ B * np.linalg.det(J)
            self.ghat_e[e] = D[2, 2]
            for a in range(4):
                for b in range(4):
                    rows += [2 * conn[a], 2 * conn[a], 2 * conn[a] + 1, 2 * conn[a] + 1]
                    cols += [2 * conn[b], 2 * conn[b] + 1, 2 * conn[b], 2 * conn[b] + 1]
                    vals += [Ke[2 * a, 2 * b], Ke[2 * a, 2 * b + 1], Ke[2 * a + 1, 2 * b], Ke[2 * a + 1, 2 * b + 1]]
        # chord / collector bars: one bar per mesh interval on the line
        self.bars = []
        for c in self.chords:
            p0 = np.array(c['p0'], float); p1 = np.array(c['p1'], float)
            L = np.linalg.norm(p1 - p0); d = (p1 - p0) / L
            nseg = max(1, int(round(L / self.H)))
            for s in range(nseg):
                na = self.nearest_node(p0 + d * (s * L / nseg))
                nb = self.nearest_node(p0 + d * ((s + 1) * L / nseg))
                if na is None or nb is None or na == nb:
                    continue
                self.bars.append([na, nb, c['A'] * 29000.0, c['A'], c['id']])
        for (na, nb, EA, A, cid) in self.bars:
            P0, P1 = self.nodes[na], self.nodes[nb]
            Lb = np.linalg.norm(P1 - P0)
            if Lb < 1e-9:
                continue
            cs = (P1 - P0) / Lb
            kb = EA / Lb
            T = np.array([-cs[0], -cs[1], cs[0], cs[1]])
            ke = kb * np.outer(T, T)
            idx = [2 * na, 2 * na + 1, 2 * nb, 2 * nb + 1]
            for a in range(4):
                for b in range(4):
                    rows.append(idx[a]); cols.append(idx[b]); vals.append(ke[a, b])
        K = sp.coo_matrix((vals, (rows, cols)), shape=(ndof, ndof)).tocsr()
        return K

    def nearest_node(self, p):
        d = np.hypot(self.nodes[:, 0] - p[0], self.nodes[:, 1] - p[1])
        k = int(np.argmin(d))
        return k if d[k] < 1e-6 else None

    def node_within(self, p, tol):
        d = np.hypot(self.nodes[:, 0] - p[0], self.nodes[:, 1] - p[1])
        k = int(np.argmin(d))
        return k if d[k] <= tol + 1e-9 else None

    def attach_piers(self):
        """each pier attaches to the mesh node nearest the mid-point of its leg"""
        self.pier_node = []
        for p in self.piers:
            k = self.node_within(np.array(p['xy'], float), self.H / 2 + 1e-6)
            if k is None:
                k = self.node_within(np.array(p['xy'], float), self.H)
            self.pier_node.append(k)

    def add_line_segments(self, F, p0, p1, segs, nrm):
        """Consistent nodal loads of the piecewise-linear hat functions on a wall line (criteria 9.5)."""
        p0 = np.array(p0, float); p1 = np.array(p1, float)
        L = np.linalg.norm(p1 - p0)
        d = (p1 - p0) / L
        n = max(1, int(round(L / self.H)))
        nodes = []
        for k in range(n + 1):
            nd = self.nearest_node(p0 + d * (k * self.H))
            if nd is None:
                nd = self.node_within(p0 + d * (k * self.H), self.H)
            nodes.append(nd)
        inward = np.array(nrm, float); inward = inward / np.linalg.norm(inward)
        for k, nd in enumerate(nodes):
            if nd is None:
                continue
            sk = k * self.H
            lo = (k - 1) * self.H if k > 0 else sk
            hi = (k + 1) * self.H if k < n else sk
            total = 0.0
            for (a, b, w) in segs:
                for (q0, q1) in ((lo, sk), (sk, hi)):
                    if q1 <= q0:
                        continue
                    aa, bb = max(a, q0), min(b, q1)
                    if bb <= aa:
                        continue
                    far = q0 if q1 == sk else q1
                    span = abs(sk - far)
                    if span < 1e-12:
                        continue
                    h0 = 1.0 - abs(aa - sk) / span
                    h1 = 1.0 - abs(bb - sk) / span
                    total += w * 0.5 * (h0 + h1) * (bb - aa)
            F[2 * nd] += total * inward[0]
            F[2 * nd + 1] += total * inward[1]
        return F

    def solve(self, line_loads=None, torsion_force_nodes=None, line_segments=None):
        K = self.assemble()
        ndof = 2 * len(self.nodes)
        F = np.zeros(ndof)
        for (p0, p1, segs, nrm) in (line_segments or []):
            self.add_line_segments(F, p0, p1, segs, nrm)
        for (p0, p1, w, dv) in (line_loads or []):
            self.add_line_segments(F, p0, p1, [(0.0, np.linalg.norm(np.array(p1, float) - np.array(p0, float)), w)], dv)
        if torsion_force_nodes is not None:
            for (k, fx, fy) in torsion_force_nodes:
                F[2 * k] += fx; F[2 * k + 1] += fy
        self.attach_piers()
        for p, k in zip(self.piers, self.pier_node):
            if k is None:
                raise RuntimeError('pier %s not attached' % p.get('id'))
            dv = np.array(p['dir'], float); dv = dv / np.linalg.norm(dv)
            kk = p["k"] * 12.0
            ke = kk * np.outer(dv, dv)
            for a in range(2):
                for b in range(2):
                    K[2 * k + a, 2 * k + b] += ke[a, b]
        U = spla.spsolve(K.tocsc(), F)
        self.U, self.K, self.F = U, K, F
        return U

    # ---------------------------------------------------------------- recovery
    def elem_strain(self, e):
        xy = self.nodes[list(self.elems[e])]
        dN = 0.25 * np.array([[-1, 1, 1, -1], [-1, -1, 1, 1]], float)
        J = dN @ xy
        dNxy = np.linalg.inv(J) @ dN
        B = np.zeros((3, 8))
        B[0, 0::2] = dNxy[0]; B[1, 1::2] = dNxy[1]
        B[2, 0::2] = dNxy[1]; B[2, 1::2] = dNxy[0]
        ue = np.zeros(8)
        for a, n in enumerate(self.elems[e]):
            ue[2 * a] = self.U[2 * n]; ue[2 * a + 1] = self.U[2 * n + 1]
        return B @ ue

    def unit_shears(self):
        return np.array([self.ghat_e[e] * self.elem_strain(e)[2] for e in range(len(self.elems))])

    def elem_centre(self, e):
        i, j = self.cells[e]
        return (self.xs[i] + self.H / 2, self.ys[j] + self.H / 2)

    def station_shear(self, line_pts, station):
        """element with an edge on the line (both nodes on the line) whose centre is nearest the station"""
        p0 = np.array(line_pts[0], float); p1 = np.array(line_pts[1], float)
        L = np.linalg.norm(p1 - p0); d = (p1 - p0) / L
        S = p0 + d * station
        us = self.unit_shears()
        best, bd = None, 1e18
        for e, conn in enumerate(self.elems):
            P = self.nodes[list(conn)]
            on = sum(1 for q in P if abs(np.cross(d, q - p0)) < 1e-6)
            if on < 2:
                continue
            c = np.array(self.elem_centre(e))
            dd = np.linalg.norm(c - S)
            if dd < bd:
                bd, best = dd, e
        return (us[best] if best is not None else float('nan')), best

    def reactions(self):
        out = {}
        for p, k in zip(self.piers, self.pier_node):
            dv = np.array(p['dir'], float); dv = dv / np.linalg.norm(dv)
            u = np.array([self.U[2 * k], self.U[2 * k + 1]])
            f = p["k"] * 12.0 * (dv @ u)
            out[p.get('line', '?')] = out.get(p.get('line', '?'), 0.0) + f
        return out

    def bar_forces(self):
        out = {}
        for (na, nb, EA, A, cid) in self.bars:
            P0, P1 = self.nodes[na], self.nodes[nb]
            Lb = np.linalg.norm(P1 - P0)
            cs = (P1 - P0) / Lb
            u = np.array([self.U[2 * na], self.U[2 * na + 1], self.U[2 * nb], self.U[2 * nb + 1]])
            N = EA / Lb * (cs @ (u[2:] - u[:2]))
            if abs(N) > abs(out.get(cid, 0.0)):
                out[cid] = N
        return out

    def axis_deflection(self, axis):
        """largest nodal displacement in axis from the stiffness-weighted mean pier displacement"""
        piers = [(p, k) for p, k in zip(self.piers, self.pier_node)
                 if abs(np.array(p['dir'], float)[axis]) > 0.5]
        num = sum(p['k'] * self.U[2 * k + axis] for p, k in piers)
        den = sum(p['k'] for p, k in piers)
        mean = num / den
        return float(np.abs(self.U[axis::2] - mean).max()), mean
