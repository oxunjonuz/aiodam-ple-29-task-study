#!/usr/bin/env python3
"""Verify the DIAPH-MT implementation against the criteria's published example VE-1."""
import numpy as np
from diaph import Model

outline = [(0, 0), (100, 0), (100, 60), (0, 60)]
piers = []
for x in (12.5, 37.5, 62.5, 87.5):
    piers.append(dict(id=f'S{x}', xy=(x, 0.0), dir=(1, 0), k=500.0, line='S'))
    piers.append(dict(id=f'N{x}', xy=(x, 60.0), dir=(1, 0), k=500.0, line='N'))
for y in (15, 45):
    piers.append(dict(id=f'W{y}', xy=(0.0, y), dir=(0, 1), k=500.0, line='W'))
    piers.append(dict(id=f'E{y}', xy=(100.0, y), dir=(0, 1), k=500.0, line='E'))
chords = [dict(id='C-S', p0=(0, 0), p1=(100, 0), A=3.0), dict(id='C-N', p0=(0, 60), p1=(100, 60), A=3.0),
          dict(id='C-W', p0=(0, 0), p1=(0, 60), A=3.0), dict(id='C-E', p0=(100, 0), p1=(100, 60), A=3.0)]
m = Model(outline, [], 5.0, 2900.0, 13920.0, lambda x, y: 30.0, chords, piers)
loads = [((0, 0), (100, 0), 0.50, (0, 1)), ((0, 60), (100, 60), 0.30, (0, -1))]
U = m.solve(loads)
print('elements %d (target 240)   nodes %d (target 273)' % (len(m.elems), len(m.nodes)))
r = m.reactions()
print('reaction x=0  %.4f (target 10.00)' % r.get('W', 0))
print('reaction x=100 %.4f (target 10.00)' % r.get('E', 0))
us = m.unit_shears()
i = int(np.argmax(np.abs(us)))
print('largest unit shear %.1f plf (target 185.2)' % (abs(us[i]) * 1000.0))
bf = m.bar_forces()
print('largest chord force %.3f kip (target 2.57)' % max(abs(v) for v in bf.values()))
print('largest disp Y %.4f in (target 0.1669)' % (np.abs(U[1::2]).max() * 12))
print('bars:', len(m.bars))
