"""Sweep the sixteen catalogue decks uniformly to find the design space."""
import math
import build as B
import analyze as A

panels = B.load_panels()
piers = B.build_piers(panels)
CH = {cid: 'PL3x3/8' for (cid, _, _) in B.CHORD_LINES}
areas = B.zone_areas()


def evaluate(assign, H=5.0):
    rig = A.Rig(panels, piers, assign, CH, H)
    res = rig.run()
    drift = max(r['drift'][a] for r in res.values() for a in ('X', 'Y'))
    base = 0.0
    worst_panel = None
    for sc, r in res.items():
        d = {}
        for p in piers:
            d[p['panel']] = d.get(p['panel'], 0.0) + r['pier_force'][p['id']]
        for m, v in d.items():
            w = [x for x in panels if x['mark'] == m][0]
            ratio = abs(v) / (w['s1'] - w['s0'])
            if ratio > base:
                base, worst_panel = ratio, (m, round(v, 2), sc)
    pier_max = max(max(r['pier_disp'].values()) for r in res.values())
    zs = {}
    for e in range(len(rig.model.elems)):
        cx, cy = rig.model.elem_centre(e)
        for z, (x0, y0, x1, y1) in B.ZONES.items():
            if x0 - 1e-9 <= cx <= x1 + 1e-9 and y0 - 1e-9 <= cy <= y1 + 1e-9:
                zs[z] = max(zs.get(z, 0.0), max(abs(r['us'][e]) * 1000.0 for r in res.values()))
                break
    cost = sum(areas[z] * B.DECK[assign[z]]['cost'] for z in areas)
    return dict(drift=drift, base=base, worst=worst_panel, pier_max=pier_max, zs=zs, deck_cost=cost)


if __name__ == '__main__':
    for code in [d[0] for d in B.DECKS]:
        a = {z: code for z in B.ZONES}
        r = evaluate(a)
        ok = r['drift'] <= 0.55 and r['base'] <= 1.40 and r['pier_max'] <= 0.84 and \
            max(r['zs'].values()) <= B.DECK[code]['cap']
        print("%-14s G'=%5.1f $%.2f  drift %.3f  base %.2f  pier %.3f  maxshear %4.0f cap %4.0f  deckcost %7.0f  %s  %s" % (
            code, B.DECK[code]['g'], B.DECK[code]['cost'], r['drift'], r['base'], r['pier_max'],
            max(r['zs'].values()), B.DECK[code]['cap'], r['deck_cost'], 'FEASIBLE' if ok else '', r['worst']))
