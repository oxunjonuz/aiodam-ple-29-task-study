"""Repair-then-descend from a cheap random start; saves every improvement immediately."""
import json
import random
import sys
import time

sys.argv = ['x']
exec(open('/work/ple-solve/wind-diaphragm-shear/opt.py').read().split("if __name__")[0])

CM = {ln: 'PL3x3/8' for ln in LINES}
BYCOST = sorted(DECKS, key=lambda c: DECKS[c]['cost_per_sf'])
OUTP = '/work/ple-solve/wind-diaphragm-shear/best_design2.json'
t0 = time.time()
rnd = random.Random(int(sys.argv[1]) if len(sys.argv) > 1 else 4242)
cache = {}
best = {'cost': 1e9, 'deck': None}


def viol(r):
    v = 0.0
    for m, val in r['vmax'].items():
        v += max(0.0, val - BASE * WIDTH[m]) / (BASE * WIDTH[m])
    v += max(0.0, r['drift'] - DRIFT) / DRIFT
    v += max(0.0, r['pier_drift'] - ROOFZ * 12 * PIER_RATIO) / (ROOFZ * 12 * PIER_RATIO)
    v += max(0.0, len(set(r['deck_map'].values())) - MAXTYPES)
    v += len(r['f1']) / 10.0 + len(r['f2']) / 10.0
    return v


def ev(dm):
    k = tuple(sorted(dm.items()))
    if k not in cache:
        cache[k] = evaluate(dm, CM)
    return cache[k]


def remember(dm, r, tag):
    if r['ok_struct'] and r['cost']['total'] < best['cost'] - 1e-6:
        best['cost'] = r['cost']['total']
        best['deck'] = dict(dm)
        json.dump({'deck': dict(dm), 'cost': r['cost']['total'], 'drift': r['drift'],
                   'ties': sorted(r['ties']), 'tag': tag,
                   'secs': round(time.time() - t0)},
                  open(OUTP, 'w'), indent=1)
        print('SAVED $%.0f drift %.3f ties %d %s' % (r['cost']['total'], r['drift'],
                                                    len(r['ties']), tag), flush=True)


pool = rnd.sample(BYCOST[:8], rnd.randint(1, 4))
dm = {z: rnd.choice(pool) for z in ZONES}
cur = ev(dm)
print('start $%.0f viol %.3f' % (cur['cost']['total'], viol(cur)), flush=True)
for it in range(40):
    if cur['ok_struct']:
        break
    cands = []
    for z in ZONES:
        for code in BYCOST:
            if code == dm[z]:
                continue
            t = dict(dm)
            t[z] = code
            if len(set(t.values())) > MAXTYPES:
                continue
            r = ev(t)
            dv = viol(cur) - viol(r)
            if dv > 1e-9:
                cands.append(((r['cost']['total'] - cur['cost']['total']) / dv, r, t))
    if not cands:
        break
    cands.sort(key=lambda x: x[0])
    _, cur, dm = cands[0]
    remember(dm, cur, 'repaired-%d' % it)
improved = True
while improved:
    improved = False
    for z in ZONES:
        for code in BYCOST:
            if code == dm[z]:
                continue
            t = dict(dm)
            t[z] = code
            if len(set(t.values())) > MAXTYPES:
                continue
            r = ev(t)
            if r['ok_struct'] and r['cost']['total'] < cur['cost']['total'] - 1e-6:
                dm, cur, improved = t, r, True
                remember(dm, cur, 'descend')
                break
        if improved:
            break
print('finished $%.0f ok=%s evals %d %.0fs' % (cur['cost']['total'], cur['ok_struct'],
                                               len(cache), time.time() - t0), flush=True)
