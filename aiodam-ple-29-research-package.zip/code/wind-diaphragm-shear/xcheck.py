"""Independent check: run the platform's own DIAPH-MT reference model on my design and compare."""
import json
import math
import sys
import numpy as np

sys.path.insert(0, '/work/ple-dataset/tasks/wind-diaphragm-shear/tests')
from corrino.structural_task5_wind_diaphragm_shear.grading.model import truth, Design, Analysis  # noqa

import build as B
import analyze as A

DECK = {z: 'D22-36/7-4' for z in B.ZONES}
CH = {cid: 'PL3x3/8' for (cid, _, _) in B.CHORD_LINES}

T = truth()
print('truth keys', list(T.keys()))
print('fe', T['fe'], 'wind', {k: v for k, v in T['wind'].items() if k != 'cp'})
print('geometry', {k: v for k, v in T['geometry'].items() if k != 'footprint'})
print('wall_lines', T['wall_lines'])
print('zones', [z['id'] for z in T['zones']])
print('deck span factor', T['deck'])
print('limits', T['limits'])
print('report fractions', T['report_fractions'])
print('scenarios', T['scenarios'])
d = Design(deck=DECK, chords=CH, embeds={p['mark']: 2 for p in B.load_panels()}, tiedowns=[])
an = Analysis(T, d)
ref = an.analyse()

panels = B.load_panels()
piers = B.build_piers(panels)
rig = A.Rig(panels, piers, DECK, CH, 5.0)
mine = rig.run()
print('elements mine %d ref %d' % (len(rig.model.elems), len(an.mesh.elem)), 'nodes', len(rig.model.nodes), an.mesh.nnode)
for sc in ['W01', 'W03', 'W10']:
    r, m = ref[sc], mine[sc]
    print('\n==', sc)
    print('line load ref', {k: round(v, 1) for k, v in r['line_load'].items()})
    print('line load mine', {k: round(abs(v) * 1000, 1) for k, v in m['line_load'].items()})
    print('reaction ref', {k: round(v, 2) for k, v in r['line_reac'].items()})
    print('reaction mine', {k: round(abs(v), 2) for k, v in m['react'].items()})
    print('drift ref', {k: round(v, 4) for k, v in r['deflection'].items()})
    print('drift mine', {k: round(v, 4) for k, v in m['drift'].items()})
    print('stations ref', {k: round(v, 1) for k, v in list(r['stations'].items())[:6]})
    print('stations mine', {f"{ln}@{f:.2f}": round(v, 1) for ln in ['S', 'E', 'N1', 'N2', 'E2', 'W'] for f, v in m['shear'][ln]})
    print('chord ref', {k: round(v, 2) for k, v in list(r['chord_force'].items())[:6]})
    print('pier demand E201 ref', round(r['pier_demand'].get('E201', 0), 2), 'mine', round(abs(m['pier_force'].get('E201', 0)), 2))
