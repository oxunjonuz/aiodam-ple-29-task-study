"""Design iteration for Building A2: deck by zone, chords, with the drift limit enforced."""
import itertools
import math
import json
import numpy as np
import build as B
import analyze as A


def pick_decks_multi(req_cap, req_g, areas, max_types=4):
    codes = [d[0] for d in B.DECKS]
    best = None
    for n in range(1, max_types + 1):
        for combo in itertools.combinations(codes, n):
            assign, cost, ok = {}, 0.0, True
            for z, rcap in req_cap.items():
                cand = [c for c in combo if B.DECK[c]['cap'] >= rcap - 1e-9 and B.DECK[c]['g'] >= req_g - 1e-9]
                if not cand:
                    ok = False
                    break
                pick = min(cand, key=lambda c: (B.DECK[c]['cost'], -B.DECK[c]['g']))
                assign[z] = pick
                cost += areas[z] * B.DECK[pick]['cost']
            if ok and (best is None or cost < best[0] - 1e-6):
                best = (cost, assign)
        if best is not None:
            break
    return best


def design(H=5.0, iters=8, verbose=True, drift_limit=B.DEFL_LIMIT):
    panels = B.load_panels()
    piers = B.build_piers(panels)
    areas = B.zone_areas()
    deck = {z: 'D22-36/4-2' for z in B.ZONES}
    chord = {cid: 'PL3x3/8' for (cid, _, _) in B.CHORD_LINES}
    g_req = 0.0
    rig = res = zs = None
    for it in range(iters):
        rig = A.Rig(panels, piers, deck, chord, H)
        res = rig.run()
        zs = A.zone_shears(rig, res)
        drift = max(r['drift'][ax] for r in res.values() for ax in ('X', 'Y'))
        cost, newdeck = pick_decks_multi(zs, g_req, areas)
        cf = {}
        for (cid, _, _) in B.CHORD_LINES:
            T = max((r['chord'].get(cid, 0.0) for r in res.values()), default=0.0)
            C = min((r['chord'].get(cid, 0.0) for r in res.values()), default=0.0)
            cf[cid] = (float(T), float(C))
        newchord = A.pick_chords(cf)
        if verbose:
            print(f"iter {it} H={H}: maxdrift {drift:.3f} in  g_req {g_req:.1f}  zones {[ (z, round(v)) for z, v in zs.items() ]}")
            print("   deck", {k: v for k, v in sorted(newdeck.items())}, "%.0f" % cost, "sect", set(newchord.values()))
        if drift > drift_limit + 1e-6:
            # stiffness scales the drift almost linearly: raise the required G' and go again
            gmin = min(B.DECK[v]['g'] for v in newdeck.values())
            g_req = max(g_req, gmin) * min(2.0, (drift / drift_limit) ** 1.0) + 0.05
            deck = newdeck
            chord = newchord
            continue
        same = (newdeck == deck and newchord == chord)
        deck, chord = newdeck, newchord
        if same:
            break
    return dict(rig=rig, res=res, zones=zs, deck=deck, chord=chord, panels=panels, piers=piers, areas=areas)


if __name__ == '__main__':
    d = design(H=5.0)
    print('FINAL deck', d['deck'])
    print('FINAL chord', d['chord'])
    drift = max(r['drift'][ax] for r in d['res'].values() for ax in ('X', 'Y'))
    print('max drift %.3f in' % drift)
