"""Diagnostic: run the real grader's checks and print per-family detail (no scoring shortcuts)."""
import json
import sys
from pathlib import Path

ROOT = Path('/work/ple-dataset/tasks/wind-diaphragm-shear/tests/corrino/'
            'structural_task5_wind_diaphragm_shear')
sys.path.insert(0, str(ROOT))

from grading.checks import Checks                     # noqa: E402
from grading.grade import design_from_submission      # noqa: E402
from grading.model import Analysis, truth             # noqa: E402
from grading.register import RegisterMap              # noqa: E402
from grading.submission import Submission             # noqa: E402

zip_path = Path(sys.argv[1] if len(sys.argv) > 1 else
                '/work/ple-solve/wind-diaphragm-shear/out/submission.zip')
split = sys.argv[2] if len(sys.argv) > 2 else 'heldout'

T = truth()
sub = Submission.load(zip_path)
print('parse_ok', sub.parse_ok, 'errors', sub.errors[:5])
design = design_from_submission(T, sub)
A = Analysis(T, design)
res = A.analyse()
ck = Checks(T, sub, design, A, res)
model = ck.model_checks()
for k, v in model.items():
    flag = 'OK ' if v.get('ok') else 'BAD'
    print(f'{flag} {k}: {json.dumps(v)[:400]}')

reg = RegisterMap().score(sub.register)
print('\nregister: precision %.3f wrong %d filed %d neutral %d' % (
    reg['precision'], reg['wrong_rows'], reg['rows_filed'], reg['neutral_rows']))
print('registered families:', len(reg['registered_families']))
missing = [f for f in sorted({q['family'] for q in RegisterMap().reqs})
           if f not in reg['registered_families']]
print('NOT registered:', missing)
# which requirement ids are still unmatched, per family
for f in missing:
    ids = [q['id'] for q in RegisterMap().reqs if q['family'] == f]
    print('  ', f, 'needs', [i for i in ids if i not in reg['matched']])

print('\n--- per scenario ---')
scen = T['scenarios'] if isinstance(T['scenarios'], list) else list(T['scenarios'].values())
ids = [s['id'] for s in scen]
if split == 'heldout':
    ids = [i for i in ids if i in ('W02', 'W03', 'W05', 'W06', 'W08', 'W10', 'W11')]
for sid in ids:
    r = ck.scenario_checks(sid)
    bad = {k: v for k, v in r.items() if not v.get('ok')}
    print(sid, 'failed:', sorted(bad))
    for k, v in bad.items():
        print('    ', k, json.dumps(v)[:300])
