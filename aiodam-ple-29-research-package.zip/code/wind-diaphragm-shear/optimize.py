"""Greedy cost reduction under the real constraint set (drift, base, capacity, four types)."""
import math
import json
import build as B
import sweep as S

AREAS = B.zone_areas()
CAND = ['D22-36/4-2', 'D22-36/7-2', 'D22-36/7-4', 'D20-36/7-4', 'D16-36/9-4']


def feasible(assign):
    r = S.evaluate(assign)
    ok = (r['drift'] <= 0.55 and r['base'] <= 1.40 and r['pier_max'] <= 0.84 and
          max(r['zs'][z] <= B.DECK[assign[z]]['cap'] for z in AREAS) and
          len(set(assign.values())) <= 4)
    return ok, r


if __name__ == '__main__':
    cur = {z: 'D16-36/9-4' for z in AREAS}
    ok, r = feasible(cur)
    print('start feasible', ok, 'deck cost %.0f' % r['deck_cost'], 'drift %.3f base %.2f' % (r['drift'], r['base']))
    order = sorted(AREAS, key=lambda z: -AREAS[z])
    improved = True
    it = 0
    while improved and it < 40:
        improved = False
        it += 1
        for z in order:
            for code in CAND:
                if code == cur[z]:
                    continue
                if B.DECK[code]['cost'] >= B.DECK[cur[z]]['cost']:
                    continue
                trial = dict(cur)
                trial[z] = code
                ok, rr = feasible(trial)
                if ok:
                    cur = trial
                    improved = True
                    print('zone %s -> %-13s deckcost %.0f drift %.3f base %.2f' % (z, code, rr['deck_cost'], rr['drift'], rr['base']))
                    break
    ok, r = feasible(cur)
    print('FINAL', ok, cur)
    print('deck cost %.0f drift %.3f base %.2f pier %.3f shears %s' % (r['deck_cost'], r['drift'], r['base'], r['pier_max'], {k: round(v) for k, v in r['zs'].items()}))
    json.dump(cur, open('deck_final.json', 'w'), indent=1)
