"""Pair-move hill climb around the feasible corner; saves every improvement to disk immediately."""
import json
import random
import sys
import time

sys.argv = ['x']
exec(open('/work/ple-solve/wind-diaphragm-shear/opt.py').read().split("if __name__")[0])

CHEAP = sorted(DECKS, key=lambda c: DECKS[c]['cost_per_sf'])
CM = {ln: 'PL3x3/8' for ln in LINES}
OUTP = '/work/ple-solve/wind-diaphragm-shear/best_design.json'
t0 = time.time()


def slack(r):
    s = [BASE * WIDTH[m] / max(v, 1e-9) for m, v in r['vmax'].items()]
    s.append(DRIFT / max(r['drift'], 1e-9))
    s.append((ROOFZ * 12.0 * PIER_RATIO) / max(r['pier_drift'], 1e-9))
    return min(s)


def save(dm, r, tag):
    rec = dict(tag=tag, deck=dict(dm), cost=r['cost']['total'], drift=r['drift'],
               ties=sorted(r['ties']), slack=slack(r), types=sorted(set(dm.values())),
               n_embed=r['n_embed'])
    json.dump([rec], open(OUTP, 'w'), indent=1)
    print('SAVED $%.0f slack %.3f drift %.3f ties %d %s' % (
        rec['cost'], rec['slack'], rec['drift'], len(rec['ties']), tag), flush=True)


seed = {'Z11': 'D22-36/7-4', 'Z12': 'D18-36/9-5', 'Z13': 'D18-36/9-5', 'Z21': 'D22-36/7-4',
        'Z22': 'D18-36/9-5', 'Z23': 'D16-36/9-4', 'Z31': 'D22-36/7-4', 'Z32': 'D22-36/7-4',
        'Z33': 'D22-36/7-4', 'Z41': 'D20-36/9-4', 'Z42': 'D18-36/9-5', 'Z43': 'D22-36/7-4'}
best = evaluate(seed, CM)
print('seed $%.0f ok=%s slack %.3f drift %.3f ties %d' % (
    best['cost']['total'], best['ok_struct'], slack(best), best['drift'], len(best['ties'])),
    flush=True)
dm = dict(seed)
if best['ok_struct']:
    save(dm, best, 'greedy-seed')

# single-zone descent
improved = True
while improved:
    improved = False
    for z in ZONES:
        for code in CHEAP:
            if code == dm[z]:
                continue
            trial = dict(dm)
            trial[z] = code
            if len(set(trial.values())) > MAXTYPES:
                continue
            r = evaluate(trial, CM)
            if r['ok_struct'] and r['cost']['total'] < best['cost']['total'] - 1e-6:
                dm, best, improved = trial, r, True
                print('  Z %s -> %s $%.0f slack %.3f' % (z, code, r['cost']['total'], slack(r)),
                      flush=True)
                save(dm, best, 'single')
                break
        if improved:
            break

# pair moves: downgrade one zone, upgrade another
rnd = random.Random(11)
for it in range(120):
    z1, z2 = rnd.sample(ZONES, 2)
    c1 = rnd.choice(CHEAP[:8])
    c2 = rnd.choice(CHEAP[8:])
    trial = dict(dm)
    trial[z1], trial[z2] = c1, c2
    if len(set(trial.values())) > MAXTYPES:
        continue
    r = evaluate(trial, CM)
    if r['ok_struct'] and r['cost']['total'] < best['cost']['total'] - 1e-6:
        dm, best = trial, r
        print('PAIR %s->%s %s->%s $%.0f slack %.3f' % (z1, c1, z2, c2,
                                                       r['cost']['total'], slack(r)), flush=True)
        save(dm, best, 'pair')
print('done %.0fs' % (time.time() - t0), flush=True)
