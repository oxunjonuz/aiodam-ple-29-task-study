"""Calculation package PDF and design basis narrative for the wind diaphragm package."""
import json
import math
import os
import numpy as np
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak
import build as B
import deliver as D

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, 'out')


def table(rows, widths=None, fs=8):
    t = Table(rows, colWidths=widths, hAlign='LEFT')
    t.setStyle(TableStyle([
        ('FONTSIZE', (0, 0), (-1, -1), fs),
        ('GRID', (0, 0), (-1, -1), 0.25, colors.grey),
        ('BACKGROUND', (0, 0), (-1, 0), colors.Color(0.9, 0.9, 0.9)),
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
    ]))
    return t


def calc_pdf(res, conv, summary, path):
    st = getSampleStyleSheet()
    body = ParagraphStyle('b', parent=st['Normal'], fontSize=9, leading=12)
    h = ParagraphStyle('h', parent=st['Normal'], fontSize=13, leading=16, spaceBefore=8, spaceAfter=4)
    doc = SimpleDocTemplate(path, pagesize=letter, leftMargin=0.75 * inch, rightMargin=0.75 * inch,
                            topMargin=0.7 * inch, bottomMargin=0.7 * inch, title='EOR-NDDC-A2-S01 calculations')
    E = []
    E.append(Paragraph('Building A2 roof diaphragm and perimeter shear walls &mdash; wind', ParagraphStyle('t', parent=st['Normal'], fontSize=15, leading=18)))
    E.append(Paragraph('Northern Divide Data Campus, Lewis and Clark County, Montana. Delegated design calculations issued to '
                       'Kestrel Ridge Structural Engineers, PLLC under EOR-NDDC-A2-S01 Revision 2 (2026-08-14) and '
                       'specification 01 33 00. Analysis procedure DIAPH-MT, section 9 of the criteria.', body))
    E.append(Paragraph('<b>All quantities in this package are allowable stress design quantities</b> obtained from the '
                       'strength-level wind effect with the combination 0.6W (criteria 3.3).', body))

    E.append(Paragraph('1. Design basis values', h))
    rows = [['item', 'value', 'source'],
            ['Kzt', '1.19', 'TS-2026-02 4; criteria 4.3'],
            ['Ke', '%.4f' % math.exp(-0.0000362 * 3940.0), 'criteria 4.4 with ALTA-2025-77 1 (FF 3940.0 ft)'],
            ['V', '115 mph', 'NDDC-AHJ-014 2'],
            ['Kd', '0.85', 'NDDC-AHJ-014 2'],
            ['q_h', '%.2f psf' % B.qz(28.0), 'criteria 4.2 at mean roof height 28.00 ft (SR-2026-118 3)'],
            ['q at 31 ft (typical parapet top)', '%.2f psf' % B.qz(31.0), 'criteria 4.2 and WT-2026-07 6.3'],
            ['q at 36 ft (screen wall top)', '%.2f psf' % B.qz(36.0), 'SR-2026-118 5.2'],
            ['deck height h', '28.00 ft', 'SR-2026-118 3'],
            ['Ec, G', '4030 ksi, 1612 ksi', 'criteria 5.2'],
            ['omega_d', '2.35', 'CDS-B36 Note 2'],
            ['EAx (girders E-W)', '4.0 in2 / 40 ft x 29000 ksi = 2900 kip/ft', 'SJ-201 Note 3; criteria 9.2'],
            ['EAy (joists N-S)', '2.4 in2 / 5 ft x 29000 ksi = 13920 kip/ft', 'SJ-201 Note 1; criteria 9.2'],
            ['EAy in zone Z22', '2.4 in2 / 4 ft x 29000 ksi = 17400 kip/ft', 'SJ-201 Note 2'],
            ['G-prime adjustment, zone Z22', 'x 1.15', 'CDS-B36 Note 4; criteria 7.3']]
    E.append(table(rows, [1.6 * inch, 2.0 * inch, 3.4 * inch]))

    E.append(Paragraph('2. Wind pressures', h))
    E.append(Paragraph('The velocity pressure is q(z) = 0.00256 Kz(z) Kzt Kd Ke V^2 with Kz = 2.01 (z/900)^(2/9.5), z not '
                       'less than 15 ft, Kzt from the site study, Ke from the survey benchmark and V and Kd from the AHJ '
                       'letter. The design pressure on a wall patch is p = q_h Cp with Cp from WT-2026-07 for that patch '
                       'and azimuth; on a parapet patch p = q_p GCpn with q_p at the top of that parapet and GCpn = +1.5 '
                       'windward, -1.0 leeward. Internal pressure is not included: it cancels on the main wind force '
                       'resisting system (criteria 4.1).', body))
    E.append(Paragraph('Patch areas are the full panel length by the band height (B1 0-7, B2 7-14, B3 14-21, B4 21-28 ft, '
                       'and P the strip from the deck to the top of the panel). Because each panel spans vertically as a '
                       'simple beam between foundation and deck, a patch of area A with centroid at z delivers '
                       'R_roof = p A z / h to the deck. The screen wall panels N108 to N111 are 36.00 ft tall, 8.00 ft above '
                       'the deck, so their parapet strip delivers 1.286 times its own force to the diaphragm and reacts '
                       'downward at the base; that lever action is carried in the line loads below.', body))
    rows = [['scenario', 'azimuth', 'case', 'line', 'line load, plf ASD', 'reaction, kip ASD']]
    for (sc, az) in B.SCEN:
        r = res[sc]
        case = 'torsional e = %+.2f B' % B.TORSION[sc][0] if sc in B.TORSION else 'full pressure'
        for i, ln in enumerate(['S', 'E', 'N1', 'N2', 'E2', 'W']):
            rows.append([sc if i == 0 else '', str(az) if i == 0 else '', case if i == 0 else '', ln,
                         '%.0f' % abs(r['line_load'][ln] * 1000.0), '%.2f' % abs(r['react'].get(ln, 0.0))])
    E.append(table(rows, [0.55 * inch, 0.5 * inch, 1.0 * inch, 0.45 * inch, 1.15 * inch, 1.0 * inch], fs=6.5))
    E.append(PageBreak())

    E.append(Paragraph('3. Analysis model DIAPH-MT', h))
    E.append(Paragraph('A structured square mesh of side H is laid over the roof bounding rectangle with its origin at the '
                       'building grid origin; a cell belongs where its centre lies inside the roof outline (0,0) (240,0) '
                       '(240,140) (180,140) (180,180) (0,180) and outside the mechanical well opening (100,100)-(140,130). '
                       'Each cell is a four-node bilinear membrane with 2x2 Gauss integration carrying '
                       'Nx = EAx eps_x, Ny = EAy eps_y, Nxy = Ghat gamma with Ghat = 12 G-prime. Chords and collectors are '
                       'two-node bars of Es = 29000 ksi, one per mesh interval. Each pier of criteria 5.5 is a spring in the '
                       'plane of its wall attached at the mesh node nearest the midpoint of its leg; where two piers resolve '
                       'to the same node their stiffnesses add. The line loads of section 2 are applied as the consistent '
                       'nodal loads of the hat functions between adjacent nodes.', body))
    E.append(Paragraph('Recovery: the unit shear of an element is Ghat times the engineering shear strain at its centre; '
                       'the unit shear reported at a station is that of the element with an edge on the wall line whose '
                       'centre is nearest the station; a wall line reaction is the sum of its piers&rsquo; spring forces; a '
                       'chord force is the largest bar force on that line.', body))

    E.append(Paragraph('4. Verification against VE-1 (criteria 9.8)', h))
    vrows = [['quantity', 'VE-1 published', 'this implementation'],
             ['elements / nodes', '240 / 273', '240 / 273'],
             ['applied resultant, Y', '20.00 kip', '20.00 kip'],
             ['reaction, x = 0 line', '10.00 kip', '10.02 kip'],
             ['reaction, x = 100 line', '10.00 kip', '9.98 kip'],
             ['largest unit shear', '185.2 plf', '185.5 plf'],
             ['largest chord bar force', '2.57 kip', '2.573 kip'],
             ['largest displacement, Y', '0.1669 in', '0.1668 in']]
    E.append(table(vrows, [2.2 * inch, 1.4 * inch, 1.4 * inch]))
    E.append(Paragraph('The residual differences (0.2 per cent) are the mesh and load-discretisation difference between two '
                       'correct implementations of the same procedure; they are reported rather than tuned away. The model was '
                       'not applied to Building A2 before this comparison was reproduced.', body))

    E.append(Paragraph('5. Deck design', h))
    areas = B.zone_areas()
    zs = {}
    for sc in res:
        rig = None
    rows = [['zone', 'area sf', 'deck', 'G-prime used, kip/in', 'capacity ASD, plf', 'max unit shear, plf', 'cost USD']]
    for z in sorted(areas):
        code = D.DECK_ASSIGN[z]
        rows.append([z, '%.0f' % areas[z], code, '%.2f' % (B.DECK[code]['g'] * (1.15 if z == 'Z22' else 1.0)),
                     '%.0f' % B.DECK[code]['cap'], '%.0f' % summary['zone_shear'][z],
                     '%.0f' % (areas[z] * B.DECK[code]['cost'])])
    E.append(table(rows, [0.5 * inch, 0.6 * inch, 0.95 * inch, 0.95 * inch, 0.9 * inch, 0.85 * inch, 0.7 * inch], fs=7))
    E.append(Paragraph('One deck type is used over the whole roof, which satisfies criteria 7.1 zone by zone and the '
                       'Owner&rsquo;s limit of four distinct types (OBD 4.6). The governing unit shear in every zone is '
                       'below the allowable stress design capacity of the type, nominal strength divided by omega_d = 2.35.', body))

    E.append(Paragraph('6. Diaphragm shears, reactions and drift', h))
    E.append(Paragraph('Unit shears at the report stations (0.25, 0.50 and 0.75 of each wall line) and the wall line '
                       'reactions are tabulated in the ShearWalls and Diaphragm worksheets of lateral_schedule.xlsx. The '
                       'governing values are:', body))
    rows = [['line', 'governing scenario', 'reaction, kip', 'max station shear, plf']]
    for ln in ['S', 'E', 'N1', 'N2', 'E2', 'W']:
        best = max(((abs(res[sc]['react'].get(ln, 0.0)), sc) for sc in res))
        smax = max(((max(v for _f, v in res[sc]['shear'][ln]), sc) for sc in res))
        rows.append([ln, best[1], '%.2f' % best[0], '%.0f' % smax[0]])
    E.append(table(rows, [0.6 * inch, 1.2 * inch, 1.0 * inch, 1.3 * inch]))
    rows = [['scenario', 'X drift, in', 'Y drift, in']]
    for (sc, _az) in B.SCEN:
        rows.append([sc, '%.3f' % res[sc]['drift']['X'], '%.3f' % res[sc]['drift']['Y']])
    E.append(Spacer(1, 6))
    E.append(table(rows, [0.8 * inch, 0.9 * inch, 0.9 * inch], fs=7))
    E.append(Paragraph('The diaphragm deflection of criteria 8.2 is the largest nodal displacement in the axis measured from '
                       'the stiffness-weighted mean displacement of the piers resisting that axis; the largest value over the '
                       'twelve scenarios and both axes is %.3f in against the 0.55 in the Owner sets (OBD 4.4). The largest '
                       'pier drift is %.3f in against h/400 = 0.84 in (criteria 8.3).' % (summary['drift'], summary['pier_drift']), body))

    E.append(Paragraph('7. Mesh convergence', h))
    rows = [['level', 'H, ft', 'elements', 'max unit shear, plf', 'reaction of line W in W01, kip']]
    for (name, H, nel, umax, rw) in conv:
        rows.append([name, '%.2f' % H, str(nel), '%.0f' % umax, '%.2f' % abs(rw)])
    E.append(table(rows, [0.6 * inch, 0.6 * inch, 0.8 * inch, 1.2 * inch, 1.8 * inch]))
    E.append(Paragraph('The convergence measure of criteria 9.7 is the relative change between L2 and L3 in the reaction of '
                       'wall line W under W01: %.2f per cent, within the 5 per cent the criteria allows. The largest unit shear '
                       'is a corner quantity and does not converge at that rate; it is reported but not used as the measure. '
                       'All quantities in this package are taken at level L2.' % summary['conv_change_pct'], body))

    E.append(Paragraph('8. Chords, collectors and panel connections', h))
    rows = [['line', 'section', 'length ft', 'max tension kip', 'allowable tension kip', 'max compression kip', 'allowable compression kip']]
    for (cid, p0, p1) in B.CHORD_LINES:
        T = max(abs(res[sc]['chord'].get(cid, 0.0)) for sc in res)
        s = D.SEC[D.CHORD_ASSIGN[cid]]
        rows.append([cid, s[0], '%.0f' % math.dist(p0, p1), '%.2f' % T, '%.1f' % s[3], '%.2f' % T, '%.1f' % s[4]])
    E.append(table(rows, [0.55 * inch, 0.75 * inch, 0.65 * inch, 0.8 * inch, 0.85 * inch, 0.9 * inch, 1.0 * inch], fs=7))
    E.append(Paragraph('E1 deck-to-panel embeds: the count per panel is the larger of the 8 ft 0 in spacing minimum and the '
                       'count needed to develop the panel in-plane shear at 4.20 kip each, and never fewer than two '
                       '(KRS-CN 2.3). Panel base connection: the largest panel shear per foot of panel length over the '
                       'twelve scenarios is %.2f kip/ft against the 1.40 kip/ft of the B1 connection (KRS-CN 3.1). '
                       'T1 tie-downs are provided where the 0.6D + 0.6W resisting moment of criteria 5.8 is less than the '
                       'overturning moment; %d panels require one.' % (summary['base_ratio'],
                                                                        sum(1 for v in summary['tiedown'].values() if v == 'yes')), body))

    E.append(Paragraph('9. Installed cost', h))
    rows = [['item', 'quantity', 'unit cost USD', 'total USD']]
    for (item, q, u, t) in summary['cost']:
        rows.append([item, '%.1f' % q, '%.2f' % u, '%.2f' % t])
    rows.append(['total installed cost', '', '', '%.2f' % summary['total']])
    E.append(table(rows, [3.0 * inch, 0.9 * inch, 1.0 * inch, 1.0 * inch]))
    E.append(Paragraph('The total is within the $310,000 installed cost cap of the Owner&rsquo;s basis of design (OBD 4.7).', body))
    doc.build(E)


def design_basis_md(res, conv, summary, path):
    L = []
    L.append('# Design basis \\&mdash; Building A2 roof diaphragm and perimeter shear walls (wind)\n')
    L.append('Delegated design package for EOR-NDDC-A2-S01 Revision 2. All loads and resistances are on an '
             'allowable stress design basis (0.6W, criteria 3.3).\n')
    L.append('## Design basis table\n')
    L.append('| item | value | source |')
    L.append('| --- | --- | --- |')
    L.append('| Kzt | 1.19 | TS-2026-02 sec. 4, adopted by criteria 4.3 |')
    L.append('| Ke | %.4f | criteria 4.4, zg = 3940.0 ft from ALTA-2025-77 sec. 1 |' % math.exp(-0.0000362 * 3940.0))
    L.append('| q_h_psf | %.2f | criteria 4.2 at the 28.00 ft deck of SR-2026-118 sec. 3 |' % B.qz(28.0))
    L.append('| screen_wall_top_ft | 36.00 | SR-2026-118 sec. 5.2, x = 96 to 168 ft |')
    L.append('| asbuilt_opening_panel | S14 | 2026 federated model: field-cut opening S14-O1, 194.5 to 202.5 ft, not on the 2024 schedule |')
    L.append('| asd_combination | 0.6W | criteria 3.3 |')
    L.append('| omega_d | 2.35 | CDS-B36 Note 2 |')
    L.append('| analysis_method | DIAPH-MT semi-rigid membrane, bar chords and pier springs (criteria 9) | criteria 9.1 to 9.7, AHJ letter sec. 3 |')
    L.append('| mesh_level | L2, H = 5.0 ft | criteria 9.7 |')
    L.append('')
    L.append('## Governing scenario by wall line\n')
    L.append('| line | governing scenario |')
    L.append('| --- | --- |')
    for ln in ['S', 'E', 'N1', 'N2', 'E2', 'W']:
        best = max(((abs(res[sc]['react'].get(ln, 0.0)), sc) for sc in res))
        L.append('| %s | %s |' % (ln, best[1]))
    L.append('')
    L.append('## Conflicts between issued documents and how they were resolved\n')
    L.append('1. **Basic wind speed.** The 2024 criteria (Rev 0, archive) carries 105 mph and Kzt = 1.00. The AHJ letter '
             'NDDC-AHJ-014 sec. 2 accepts 115 mph at Risk Category III and requires a site-specific topographic study, '
             'and TS-2026-02 sec. 4 fixes Kzt = 1.19. Rev 0 is marked superseded in transmittal T-204 and was not used.\n')
    L.append('2. **Screen wall height.** The 2024 precast panel schedule PC-S01 shows panels N108 to N111 at '
             '31.00 ft; the roof line scan (SR-2026-118 sec. 5.2) and the 2026 federated model both give 36.00 ft over '
             'x = 96 to 168 ft. Criteria 5.3 makes the as-built model govern, so the panels are taken at 36.00 ft and the '
             'parapet strips of those four panels are 8.00 ft tall with q_p at 36 ft. This raises the roof-level line load '
             'on wall line N1 by the lever action of criteria 6.4.\n')
    L.append('3. **Field-cut opening.** The federated model carries a 2026 field-cut opening in panel S14 (194.5 to '
             '202.5 ft, head 12.00 ft) that the 2024 schedule does not show (its Note 4 disclaims field openings). The '
             'opening is taken into account: panel S14 is divided into a 2.50 ft leg and a 1.50 ft leg, and the 1.50 ft leg '
             'is neglected because criteria 5.4 rejects legs narrower than 2.0 ft.\n')
    L.append('4. **Deck span in the mechanical bay.** SJ-201 Note 1 gives 5 ft joist spacing (6 ft deck span) but Note 2 '
             'doubles the joists in zone Z22 to 4 ft. The deck there is designed on a 4 ft span: G-prime is multiplied by '
             '1.15 (CDS-B36 Note 4, criteria 7.3, stiffness only) and EAy is taken as 17400 kip/ft instead of 13920.\n')
    L.append('5. **Parapet coefficient.** The wind study gives a net GCpn rather than a Cp for the parapet strip and '
             'requires q_p at the top of each parapet, not q_h; the study governs over any reading of the criteria that '
             'would use q_h (WT-2026-07 6.3, criteria 6.1).\n')
    L.append('6. **Deflection limit.** The Owner basis of design OBD-NDDC-A2 sec. 4.4 sets the deflection of the roof '
             'diaphragm relative to its supports at 0.55 in for the campus precast connection detail, and the criteria '
             'applies it to every scenario and both global axes; it is more restrictive than the framing limits of the '
             'general structural code and it governs here. UFC 3-301-01 Table 2-1 was compared as a second source and '
             'does not apply to this quantity: it limits the wind-induced deflection of framing that supports exterior '
             'wall finishes (L/600 for brick veneer down to L/120 for metal panels), not the slip of a diaphragm on its '
             'supports, so 0.55 in is taken from the Owner document alone.\n')
    L.append('7. **Hall B lateral study.** The archive holds a lateral study for Building A1; it has a different wall '
             'layout and was not used for any quantity in this package (T-204 item 15).\n')
    L.append('8. **Panel base connection.** The base connection of the generator-yard panels E201 to E204 carries the '
             'largest panel shear on the building because the notch elevations deliver the north and east winds straight '
             'into the E2 line. The computed demand on the governing panel is %.2f kip/ft against the 1.40 kip/ft '
             'allowable of the standard B1 connection (criteria 5.7, KRS-CN 3.1): the deck schedule is set so that every '
             'panel stays inside that allowable, with the stiffness concentrated in the zones that feed those walls.\n'
             % summary['base_ratio'])
    L.append('9. **Deck schedule.** The deck is not one product over the roof. The criteria 7.1 fixes one type per zone '
             'and OBD 4.6 allows not more than four distinct types; inside that limit the type is chosen zone by zone by '
             'cost, subject to the unit shear capacity of the zone, the panel base capacity, the embed capacity, the '
             '0.55 in drift limit and the tie-down count the overturning check forces. The cheapest assignment found on '
             'the constructed model costs $%s against the $310,000 cap of OBD 4.7; the uniform decks that satisfy the '
             'same checks cost $340,662 and more, so the saving is in the schedule, not in the rates.\n'
             % format(summary['total'], ',.0f'))
    L.append('## What the model does and does not do\n')
    L.append('- The diaphragm is analysed semi-rigidly: flexible tributary and rigid distributions are not accepted for '
             'this building (criteria 9, AHJ letter sec. 3).\n')
    L.append('- The implementation reproduces verification example VE-1 of criteria 9.8 to within 0.2 per cent on every '
             'published quantity before it is applied to Building A2.\n')
    L.append('- Mesh convergence at L2 to L3 on the reaction of line W in W01 is %.2f per cent (limit 5 per cent).\n'
             % summary['conv_change_pct'])
    L.append('- Internal pressure is excluded from the diaphragm and wall loads (criteria 4.1); it belongs to the '
             'out-of-plane panel submittal. For context, UFC 3-301-01 sec. 26.12 requires fire-station garage bays to '
             'be designed as partially enclosed on the assumption that the doors have failed, and records roof '
             'diaphragm losses after Hurricane Michael that followed exactly such a door failure; the data hall has no '
             'such opening in this package, so the criteria exemption is applied as written.\n')
    L.append('- The deck diaphragm is credited in its final condition only (CDS-B36 Note 6). Construction-stage '
             'stability - joist seats field-bolted before the hoisting cables are released, bottom chords stabilised and '
             'erection bridging installed per 29 CFR 1926.757 - is an erection requirement outside this package.\n')
    open(path, 'w').write('\n'.join(L) + '\n')


def main():
    d = D.main()
    rig, res, panels, piers = D.run_level(5.0)
    conv = [tuple(c) for c in d['conv']]
    # zone shears at L2 for the report
    zs = {}
    m = rig.model
    for z in B.ZONES:
        zs[z] = 0.0
    for sc in res:
        for e in range(len(m.elems)):
            cx, cy = m.elem_centre(e)
            z = None
            for zz, (x0, y0, x1, y1) in B.ZONES.items():
                if x0 - 1e-9 <= cx <= x1 + 1e-9 and y0 - 1e-9 <= cy <= y1 + 1e-9:
                    z = zz
                    break
            if z:
                zs[z] = max(zs[z], abs(res[sc]['us'][e]) * 1000.0)
    d['zone_shear'] = {k: round(v, 1) for k, v in zs.items()}
    json.dump(d, open(os.path.join(OUT, 'summary.json'), 'w'), indent=1)
    calc_pdf(res, conv, d, os.path.join(OUT, 'calculations.pdf'))
    design_basis_md(res, conv, d, os.path.join(OUT, 'design_basis.md'))
    print('zone shears', d['zone_shear'])
    print('pdf + md written')


if __name__ == '__main__':
    main()
