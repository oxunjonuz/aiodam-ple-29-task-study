"""Cost optimisation of the A2 lateral package against the task's own DIAPH-MT model and checks.

Free variables: deck type per zone (<= 4 distinct), chord section per line.
Embeds and tie-downs are not free: embeds = max(vendor minimum, ceil(panel shear / 4.20 kip)),
tie-downs only where 0.6D cannot resist overturning (a tie that is not needed is money burnt,
a tie that is needed and missing fails F6).
"""
import itertools
import json
import math
import random
import sys
import time
from collections import defaultdict
from pathlib import Path

ROOT = Path('/work/ple-dataset/tasks/wind-diaphragm-shear/tests/corrino/'
            'structural_task5_wind_diaphragm_shear')
sys.path.insert(0, str(ROOT))

from grading.cost import design_cost, min_embeds               # noqa: E402
from grading.model import Analysis, Design, truth             # noqa: E402

T = truth()
ZONES = [z['id'] for z in T['zones']]
AREA = {z['id']: z['area_sf'] for z in T['zones']}
DECKS = {c['code']: c for c in T['deck_catalogue']}
CHORDS = {c['code']: c for c in T['chord_catalogue']}
LINES = [c['id'] for c in T['chord_lines']]
CH_LINE = {c['id']: c for c in T['chord_lines']}
MARKS = [p['mark'] for rows in T['panels'].values() for p in rows]
WIDTH = {p['mark']: p['s1'] - p['s0'] for rows in T['panels'].values() for p in rows}
TOPZ = {p['mark']: p['top_z'] for rows in T['panels'].values() for p in rows}
TIN = {p['mark']: p['t_in'] for rows in T['panels'].values() for p in rows}
DENS = T['materials']['panel_density_pcf']
ROOFZ = T['geometry']['roof_z']
EMB = T['connections']['embed_asd_kips']
EMB_COST = T['connections']['embed_cost']
TD_CAP = T['connections']['tiedown_asd_kips']
TD_COST = T['connections']['tiedown_cost']
BASE = T['connections']['base_asd_kips_per_ft']
DRIFT = T['limits']['diaphragm_drift_in']
PIER_RATIO = T['limits']['pier_drift_ratio']
MAXTYPES = T['deck']['max_types']
CAP_USD = T['costs']['capital_cap']
SPAN4 = T['deck']['span_factor_4ft']
WEIGHT = {m: (TIN[m] / 12.0) * WIDTH[m] * TOPZ[m] * DENS / 1000.0 for m in MARKS}


def panel_shear(res, piers):
    out = defaultdict(float)
    for i, p in enumerate(piers):
        out[p['panel']] = max(out[p['panel']], abs(res['reac'][i]))
    return dict(out)


def evaluate(deck_map, chord_map, want_res=False):
    d0 = Design(deck_map, chord_map, {}, [])
    A = Analysis(T, d0)
    res = A.analyse()
    # panel shear per scenario, embeds and ties sized on the worst scenario
    vmax = defaultdict(float)
    drift = 0.0
    pier_drift = 0.0
    f1 = []
    for sid, r in res.items():
        for m, v in panel_shear(r, A.piers).items():
            vmax[m] = max(vmax[m], v)
        drift = max(drift, max(r['deflection'].values()))
        pier_drift = max(pier_drift, max(r['pier_drift'].values()) if r['pier_drift'] else 0.0)
        q = [abs(x) * 1000.0 for x in r['q']]
        for e, val in enumerate(q):
            if val > A.cap_plf[e] + 1e-6:
                f1.append((sid, A.elem_zone[e], round(val, 1), round(float(A.cap_plf[e]), 1)))
    embeds = {}
    for m in MARKS:
        v = vmax.get(m, 0.0)
        embeds[m] = max(min_embeds(T, WIDTH[m]), int(math.ceil(v / EMB - 1e-9)))
    ties = []
    f6 = []
    for m in MARKS:
        v = vmax.get(m, 0.0)
        M_ot = v * ROOFZ
        M_r = 0.6 * WEIGHT[m] * WIDTH[m] / 2.0
        if M_ot > M_r + 1e-6:
            if M_ot <= M_r + TD_CAP * WIDTH[m] + 1e-6:
                ties.append(m)
            else:
                f6.append((m, round(M_ot), round(M_r + TD_CAP * WIDTH[m])))
    f4 = [(m, round(v, 2), round(BASE * WIDTH[m], 2)) for m, v in vmax.items()
          if v > BASE * WIDTH[m] + 1e-6]
    f2 = []
    for sid, r in res.items():
        for cl in T['chord_lines']:
            t, cc = r['chord_signed'][cl['id']]
            c = CHORDS[chord_map[cl['id']]]
            if t > c['allow_t_kips'] + 1e-6 or -cc > c['allow_c_kips'] + 1e-6:
                f2.append((sid, cl['id'], round(t, 1), round(-cc, 1)))
    d = Design(deck_map, chord_map, embeds, ties)
    cost = design_cost(T, d)
    plim = ROOFZ * 12.0 * PIER_RATIO
    ok_struct = (not f1 and not f2 and not f4 and not f6
                 and drift <= DRIFT + 1e-9 and pier_drift <= plim + 1e-9
                 and len(set(deck_map.values())) <= MAXTYPES)
    ok = ok_struct and cost['total'] <= CAP_USD
    out = dict(ok=ok, ok_struct=ok_struct, cost=cost, drift=drift, pier_drift=pier_drift,
               embeds=embeds, ties=sorted(ties), f1=f1[:4], f2=f2[:4], f4=f4[:4], f6=f6[:4],
               n_embed=sum(embeds.values()), vmax=vmax, chord_map=chord_map,
               deck_map=deck_map, types=sorted(set(deck_map.values())))
    if want_res:
        out['res'] = res
        out['A'] = A
        out['design'] = d
    return out


def uniform_scan():
    rows = []
    for code in DECKS:
        dm = {z: code for z in ZONES}
        r = evaluate(dm, {ln: 'PL3x3/8' for ln in LINES})
        rows.append((r['cost']['total'], code, r['ok'], round(r['drift'], 3), len(r['ties']),
                     r['f4'][:1], len(r['f1'])))
    return sorted(rows)


def greedy(start_deck, start_chord, order=None, seed=0, iters=4, log=print):
    """Zone-by-zone descent: try every deck in each zone, keep the cheapest feasible step."""
    dm = dict(start_deck)
    cm = dict(start_chord)
    rnd = random.Random(seed)
    best = evaluate(dm, cm)
    log('  start %.0f ok=%s drift %.3f ties %d' % (best['cost']['total'], best['ok'],
                                                   best['drift'], len(best['ties'])))
    for it in range(iters):
        improved = False
        zones = list(ZONES)
        if order == 'random':
            rnd.shuffle(zones)
        for z in zones:
            for code in sorted(DECKS, key=lambda c: DECKS[c]['cost_per_sf']):
                if code == dm[z]:
                    continue
                trial = dict(dm)
                trial[z] = code
                r = evaluate(trial, cm)
                if r['ok_struct'] and r['cost']['total'] < best['cost']['total'] - 1e-6:
                    dm, best, improved = trial, r, True
                    log('  Z %s -> %s  cost %.0f drift %.3f ties %d types %s' % (
                        z, code, r['cost']['total'], r['drift'], len(r['ties']), r['types']))
                    break
        # chord pass
        for ln in LINES:
            for code in sorted(CHORDS, key=lambda c: CHORDS[c]['weight_plf']):
                if code == cm[ln]:
                    continue
                trial = dict(cm)
                trial[ln] = code
                r = evaluate(dm, trial)
                if r['ok_struct'] and r['cost']['total'] < best['cost']['total'] - 1e-6:
                    cm, best, improved = trial, r, True
                    log('  chord %s -> %s cost %.0f' % (ln, code, r['cost']['total']))
                    break
        if not improved:
            break
    return best


if __name__ == '__main__':
    t0 = time.time()
    print('=== uniform scan ===')
    for row in uniform_scan():
        print('  $%9.0f %-12s ok=%-5s drift %.3f ties %2d typ %d  f4 %s nf1 %d' % (
            row[0], row[1], row[2], row[3], row[4], 1, row[5], row[6]))
    print('seconds %.1f' % (time.time() - t0))
