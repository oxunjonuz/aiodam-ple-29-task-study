"""Greedy mixed deck assignment under the drift limit, at H = 5 (level L2)."""
import build as B
import analyze as A
from design import pick_decks_multi

HI = 'D20-36/9-4'   # G' 46.1, cap 2980/2.35 = 1268
LO = 'D20-36/7-4'   # G' 39.7, cap 2530/2.35 = 1077

panels = B.load_panels()
piers = B.build_piers(panels)
areas = B.zone_areas()
chs = {cid: 'PL3x3/8' for (cid, _, _) in B.CHORD_LINES}


def evaluate(assign, H=5.0):
    rig = A.Rig(panels, piers, assign, chs, H)
    res = rig.run()
    drift = max(r['drift'][ax] for r in res.values() for ax in ('X', 'Y'))
    zs = A.zone_shears(rig, res)
    return drift, zs, rig, res


if __name__ == '__main__':
    base = {z: LO for z in B.ZONES}
    drift, zs, rig, res = evaluate(base)
    print('all LO: drift %.3f' % drift)
    incr = sorted(B.ZONES, key=lambda z: areas[z] * (B.DECK[HI]['cost'] - B.DECK[LO]['cost']))
    cur = dict(base)
    disc = {z: B.DECK[HI]['cost'] - B.DECK[LO]['cost'] for z in B.ZONES}
    order = sorted(B.ZONES, key=lambda z: areas[z] * disc[z])
    for z in order:
        if drift <= B.DEFL_LIMIT:
            break
        cur[z] = HI
        drift, zs, rig, res = evaluate(cur)
        print('upgrade %s -> drift %.3f  cost %.0f' % (z, drift, sum(areas[q] * B.DECK[cur[q]]['cost'] for q in cur)))
    if drift > B.DEFL_LIMIT:
        cur = {z: HI for z in B.ZONES}
        drift, zs, rig, res = evaluate(cur)
        print('all HI: drift %.3f' % drift)
    print('FINAL', cur, 'drift %.3f' % drift)
    print('zone shears', {k: round(v) for k, v in zs.items()})
