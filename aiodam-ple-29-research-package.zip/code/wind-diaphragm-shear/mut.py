"""Sensitivity campaign: break one thing at a time in the packaged submission and see whether the
real grader reddens the family that owns it. Mutants are written to /tmp and graded with the
task's own grading.grade; the delivered zip is never touched."""
import json
import shutil
import sys
import zipfile
from pathlib import Path

import openpyxl

ROOT = Path('/work/ple-dataset/tasks/wind-diaphragm-shear/tests/corrino/'
            'structural_task5_wind_diaphragm_shear')
sys.path.insert(0, str(ROOT))
from grading.grade import grade                                    # noqa: E402

SRC = Path('/work/ple-solve/wind-diaphragm-shear/out/submission.zip')
TMP = Path('/tmp/wind_mut')


def load():
    shutil.rmtree(TMP, ignore_errors=True)
    TMP.mkdir(parents=True)
    with zipfile.ZipFile(SRC) as z:
        z.extractall(TMP)


def repack(path):
    files = ['lateral_schedule.xlsx', 'diaphragm_plan.dxf', 'constraint_register.xlsx',
             'calculations.pdf', 'design_basis.md']
    with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED) as z:
        for f in files:
            z.write(TMP / f, f)


def tweak_wb(fn):
    p = TMP / 'lateral_schedule.xlsx'
    wb = openpyxl.load_workbook(p)
    fn(wb)
    wb.save(p)


def tweak_reg(fn):
    p = TMP / 'constraint_register.xlsx'
    wb = openpyxl.load_workbook(p)
    fn(wb)
    wb.save(p)


def set_deck(wb, zone, code):
    ws = wb['DeckZones']
    hdr = [c.value for c in ws[1]]
    for row in ws.iter_rows(min_row=2):
        if row[hdr.index('zone_id')].value == zone:
            row[hdr.index('deck_code')].value = code


def drop_tie(wb, mark):
    ws = wb['Piers']
    hdr = [c.value for c in ws[1]]
    for row in ws.iter_rows(min_row=2):
        if row[hdr.index('panel')].value == mark:
            row[hdr.index('tiedown')].value = 'no'


def set_embed(wb, mark, n):
    ws = wb['Piers']
    hdr = [c.value for c in ws[1]]
    for row in ws.iter_rows(min_row=2):
        if row[hdr.index('panel')].value == mark:
            row[hdr.index('embeds')].value = n


def drop_register_row(wb, doc_prefix):
    ws = wb['Register'] if 'Register' in wb.sheetnames else wb.worksheets[0]
    for row in list(ws.iter_rows(min_row=2)):
        if str(row[0].value or '').startswith(doc_prefix):
            ws.delete_rows(row[0].row, 1)
            return
    raise SystemExit('register row not found: ' + doc_prefix)


MUTS = [
    ('deck Z23 -> D22-36/4-2 (weakest)', tweak_wb, lambda wb: set_deck(wb, 'Z23', 'D22-36/4-2')),
    ('tie-down removed on E201', tweak_wb, lambda wb: drop_tie(wb, 'E201')),
    ('embeds on E201 cut to 2', tweak_wb, lambda wb: set_embed(wb, 'E201', 2)),
    ('register row A-101 note 1 deleted', tweak_reg, lambda wb: drop_register_row(wb, 'A-101 Roof Plan Rev C')),
    ('register row KRS-CH Table 1 deleted', tweak_reg, lambda wb: drop_register_row(wb, 'KRS-CH')),
]

base = grade(SRC)
b_fail = set(base['scenarios']['W02']['failed'])
b_unreg = set(base['scenarios']['W02']['unregistered'])
print('baseline: score %.4f p %.3f failed %s unreg %s' % (
    base['combined_score'], base['mean_p'], sorted(b_fail), sorted(b_unreg)))
rows = []
for name, apply_to, fn in MUTS:
    load()
    apply_to(fn)
    out = Path('/tmp/mut.zip')
    repack(out)
    m = grade(out)
    sc = m['scenarios'].get('W02', {})
    new = set(sc.get('failed') or []) | set(sc.get('unregistered') or [])
    delta = sorted(new - b_fail - b_unreg)
    print('%-38s score %.4f  p %.3f  new red: %s' % (name, m['combined_score'], m['mean_p'],
                                                     delta or 'NONE'))
    rows.append(dict(mutation=name, score=m['combined_score'], p=m['mean_p'], new_red=delta))
json.dump(rows, open('/work/ple-solve/wind-diaphragm-shear/mutations.json', 'w'), indent=1)
