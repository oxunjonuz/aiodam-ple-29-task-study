"""Zip the five deliverables into output/submission.zip (deterministic order, no mtime noise)."""
import os
import zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, 'out')
FILES = ['lateral_schedule.xlsx', 'diaphragm_plan.dxf', 'constraint_register.xlsx',
         'calculations.pdf', 'design_basis.md']

with zipfile.ZipFile(os.path.join(OUT, 'submission.zip'), 'w', zipfile.ZIP_DEFLATED) as z:
    for f in FILES:
        p = os.path.join(OUT, f)
        zi = zipfile.ZipInfo(f, date_time=(2026, 11, 10, 0, 0, 0))
        zi.compress_type = zipfile.ZIP_DEFLATED
        zi.external_attr = 0o644 << 16
        z.writestr(zi, open(p, 'rb').read())
print('packed', FILES)
