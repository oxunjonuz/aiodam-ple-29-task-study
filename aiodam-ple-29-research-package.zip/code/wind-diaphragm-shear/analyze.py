"""Run DIAPH-MT on Building A2 for the twelve scenarios and iterate the design."""
import math
import json
import numpy as np
import scipy.sparse.linalg as spla
from diaph import Model, point_in_poly
import build as B

ASD = 0.6


def zone_of(x, y):
    for z, (x0, y0, x1, y1) in B.ZONES.items():
        if x0 - 1e-9 <= x <= x1 + 1e-9 and y0 - 1e-9 <= y <= y1 + 1e-9:
            return z
    return None


class Rig:
    def __init__(self, panels, piers, deck_assign, chord_assign, H):
        self.panels = panels
        self.piers = piers
        self.deck = deck_assign
        self.chords = chord_assign
        self.H = H
        areas = B.zone_areas()
        self.areas = areas

        def gprime(x, y):
            z = zone_of(x, y)
            code = self.deck[z]
            g = B.DECK[code]['g']
            if z == 'Z22':
                g *= 1.15
            return g

        def eay(x, y):
            return 13920.0

        self.props = (gprime, eay)
        chords = [dict(id=cid, p0=p0, p1=p1, A=dict(B.SECTIONS and {s[0]: s[1] for s in B.SECTIONS})[self.chords[cid]])
                  for (cid, p0, p1) in B.CHORD_LINES]
        self.model = Model(B.OUTLINE, B.OPENINGS, H, 2900.0, eay, gprime, chords, piers)
        self.cp = B.read_cp()

    def torsional_forces(self, direction, Mt):
        m = self.model
        cx = sum(p[0] for p in B.OUTLINE) / len(B.OUTLINE)  # replaced below by area centroid
        # area centroid of the belonging cells
        cents = []
        areas = []
        for e in range(len(m.elems)):
            c = m.elem_centre(e)
            a = m.H * m.H
            # clip cell area roughly: full cell (all belong fully by construction)
            cents.append(c); areas.append(a)
        A = sum(areas)
        cx = sum(c[0] * a for c, a in zip(cents, areas)) / A
        cy = sum(c[1] * a for c, a in zip(cents, areas)) / A
        # nodal tributary area
        na = np.zeros(len(m.nodes))
        for e, conn in enumerate(m.elems):
            for n in conn:
                na[n] += m.H * m.H / 4.0
        out = []
        rad = np.hypot(m.nodes[:, 0] - cx, m.nodes[:, 1] - cy)
        den = float(np.sum(na * rad * rad))
        c = Mt / den if den > 1e-12 else 0.0
        # in-plane force perpendicular to the radius
        tx = -(m.nodes[:, 1] - cy)
        ty = (m.nodes[:, 0] - cx)
        rn = np.where(rad > 1e-9, rad, 1.0)
        for k in range(len(m.nodes)):
            fx = c * na[k] * rn[k] * tx[k] / rn[k]
            fy = c * na[k] * rn[k] * ty[k] / rn[k]
            out.append((k, fx, fy))
        return out, (cx, cy)

    def run(self, torsion_sign=1.0, factor=1.0):
        """returns dict scenario -> results"""
        res = {}
        m = self.model
        for (sc, az) in B.SCEN:
            factor = 0.75 if sc in B.TORSION else 1.0
            segs = B.line_load_segments(self.panels, self.cp, az)
            loads = []
            ll = {}
            for ln, (p0, p1, nrm, axis) in B.LINES.items():
                sg = segs.get(ln, [])
                L = math.dist(p0, p1)
                ll[ln] = sum(w * (b - a) for (a, b, w) in sg) / L if L else 0.0
                loads.append((p0, p1, [(x, y, w * factor) for (x, y, w) in sg], nrm))
            tn = None
            if sc in B.TORSION:
                e, direc = B.TORSION[sc]
                # resultant magnitude in the wind direction, factored
                F = 0.0
                for ln, (p0, p1, nrm, axis) in B.LINES.items():
                    L = math.dist(p0, p1)
                    axis_want = 1 if direc == 'X' else 0
                    F += ll[ln] * factor * L * nrm[axis_want]
                # 6.6: B is the building dimension perpendicular to the wind: 240 ft for wind on the
                # north or south face (wind blowing along Y), 180 ft for wind on the east or west face.
                Bdim = 240.0 if direc == 'X' else 180.0
                Mt = abs(e) * Bdim * abs(F) * (1.0 if e > 0 else -1.0) * torsion_sign
                tn, ctr = self.torsional_forces(direc, Mt)
            U = m.solve([], torsion_force_nodes=tn, line_segments=loads)
            us = m.unit_shears()
            pf, pd = {}, {}
            for p, k in zip(self.piers, m.pier_node):
                u = np.array([U[2 * k], U[2 * k + 1]])
                dv = np.array(p['dir'], float)
                f = p['k'] * 12.0 * (dv @ u)
                pf[p['id']] = float(f)
                pd[p['id']] = abs(float(f)) / p['k']
            stat = {}
            for ln, (p0, p1, nrm, axis) in B.LINES.items():
                L = math.dist(p0, p1)
                rows = []
                for frac in (0.25, 0.5, 0.75):
                    v, e = m.station_shear((p0, p1), frac * L)
                    rows.append((frac, abs(v) * 1000.0))
                stat[ln] = rows
            res[sc] = dict(
                az=az,
                line_load={ln: ll[ln] * factor for ln in ll},
                react=m.reactions(),
                shear=stat,
                chord=m.bar_forces(),
                drift={'X': m.axis_deflection(0)[0] * 12.0, 'Y': m.axis_deflection(1)[0] * 12.0},
                umax=float(np.abs(us).max() * 1000.0),
                pier_force=pf, pier_disp=pd,
                us=us.copy(),
            )
        return res


def zone_shears(rig, res):
    """max |unit shear| per zone over all scenarios"""
    m = rig.model
    zs = {}
    for z in B.ZONES:
        zs[z] = 0.0
    for sc, r in res.items():
        for e in range(len(m.elems)):
            cx, cy = m.elem_centre(e)
            z = zone_of(cx, cy)
            if z is None:
                continue
            zs[z] = max(zs[z], abs(r['us'][e]) * 1000.0)
    return zs


def pick_decks(req, areas, max_types=4):
    """cheapest set of at most max_types deck codes covering every zone requirement"""
    codes = [d[0] for d in B.DECKS]
    best = None
    import itertools
    for n in range(1, max_types + 1):
        for combo in itertools.combinations(codes, n):
            ok = True
            assign = {}
            cost = 0.0
            for z, r in req.items():
                pick = None
                for c in combo:
                    if B.DECK[c]['cap'] >= r - 1e-9:
                        if pick is None or B.DECK[c]['cost'] < B.DECK[pick]['cost']:
                            pick = c
                if pick is None:
                    ok = False
                    break
                assign[z] = pick
                cost += areas[z] * B.DECK[pick]['cost']
            if ok and (best is None or cost < best[0]):
                best = (cost, assign)
        if best is not None:
            break
    return best


def pick_chords(chord_forces):
    sec = {s[0]: s for s in B.SECTIONS}
    out = {}
    for cid, (T, C) in chord_forces.items():
        pick = None
        for (code, a, w, tcap, ccap) in B.SECTIONS:
            if tcap + 1e-9 >= abs(T) and ccap + 1e-9 >= abs(C):
                pick = code
                break
        out[cid] = pick or 'PL12x1'
    return out


def run_design(H=5.0, iters=6, verbose=True):
    panels = B.load_panels()
    piers = B.build_piers(panels)
    areas = B.zone_areas()
    deck = {z: 'D22-36/4-2' for z in B.ZONES}
    chord = {cid: 'PL3x3/8' for (cid, _, _) in B.CHORD_LINES}
    hist = []
    for it in range(iters):
        rig = Rig(panels, piers, deck, chord, H)
        res = rig.run()
        zs = zone_shears(rig, res)
        cost, newdeck = pick_decks(zs, areas)
        cf = {}
        for (cid, _, _) in B.CHORD_LINES:
            T = max((r['chord'].get(cid, 0.0) for r in res.values()), default=0.0)
            C = min((r['chord'].get(cid, 0.0) for r in res.values()), default=0.0)
            cf[cid] = (T, C)
        newchord = pick_chords(cf)
        same = (newdeck == deck and newchord == chord)
        if verbose:
            print(f"iter {it}: H={H} zones={ {k: round(v) for k,v in zs.items()} }")
            print("   deck", {k: v for k, v in sorted(newdeck.items())}, "deck cost %.0f" % cost)
            print("   chord", {k: (round(v[0], 1), round(v[1], 1)) for k, v in cf.items()})
            print("   sect", newchord, "changed" if not same else "converged")
        deck, chord = newdeck, newchord
        if same:
            break
    return rig, res, deck, chord, zs


if __name__ == '__main__':
    rig, res, deck, chord, zs = run_design(H=5.0)
    print('=== scenario summary (H=5) ===')
    for sc in res:
        r = res[sc]
        print(sc, 'react', {k: round(v, 1) for k, v in r['react'].items()},
              'drift', {k: round(v, 3) for k, v in r['drift'].items()}, 'umax %.0f' % r['umax'])
