"""The five deliverables of the wind diaphragm / shear wall package."""
import json
import math
import os
import zipfile
import numpy as np
import openpyxl
from openpyxl.styles import Font
import ezdxf
import build as B
import analyze as A

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, 'out')
DECK_ASSIGN = json.load(open(os.path.join(HERE, 'deck_choice.json')))['deck']
CHORD_ASSIGN = {cid: 'PL3x3/8' for (cid, _, _) in B.CHORD_LINES}
LEVELS = [('L1', 10.0), ('L2', 5.0), ('L3', 2.5)]
SEC = {s[0]: s for s in B.SECTIONS}
CITE = {
    'deck': 'CDS-B36 Table 3 / Note 2 (omega_d = 2.35) and Note 4 (G-prime x 1.15 at a 4 ft deck span)',
    'sect': 'KRS-CH Table 1 (ASD allowable) and Note 4 ($2.85 per lb)',
    'embed': 'KRS-CN 2.1 (4.20 kip ASD), 2.3 (8 ft o.c., minimum two per panel), 2.4 ($185)',
    'base': 'KRS-CN 3.1 (1.40 kip/ft ASD)',
    'tie': 'KRS-CN 4.2 (88 kip ASD uplift, lever arm = panel length), 4.3 ($2,450 per panel)',
    'overturn': 'EOR-NDDC-A2-S01 Rev 2 5.8 (0.6D + 0.6W, gross panel area)',
    'drift': 'EOR-NDDC-A2-S01 Rev 2 8.2 and OBD-NDDC-A2 4.4 (0.55 in)',
    'pierdrift': 'EOR-NDDC-A2-S01 Rev 2 8.3 (h/400 = 0.84 in)',
    'types': 'OBD-NDDC-A2 4.6 (not more than 4 distinct deck types)',
    'cap': 'EOR-NDDC-A2-S01 Rev 2 7.2 (unit shear against the ASD capacity of the zone deck)',
    'mesh': 'EOR-NDDC-A2-S01 Rev 2 9.1 (H = 10.0, 5.0, 2.50 ft)',
    'report': 'EOR-NDDC-A2-S01 Rev 2 9.7 (report at L2) and 11.2.1 (quarter points)',
    'asd': 'EOR-NDDC-A2-S01 Rev 2 3.3 (0.6W)',
    'kzt': 'EOR-NDDC-A2-S01 Rev 2 4.3 and TS-2026-02 4 (Kzt = 1.19)',
    'ke': 'EOR-NDDC-A2-S01 Rev 2 4.4 with ALTA-2025-77 1 (FF 3940.0 ft)',
    'screen': 'SR-2026-118 5.2 (36.00 ft between x = 96 and 168 ft)',
    'parapet': 'EOR-NDDC-A2-S01 Rev 2 6.1 and WT-2026-07 6.3 (GCpn)',
    'torsion': 'EOR-NDDC-A2-S01 Rev 2 6.6 (0.75 and M_T = e B |F| at e = 0.15 B)',
    've1': 'EOR-NDDC-A2-S01 Rev 2 9.8',
    'conv': 'EOR-NDDC-A2-S01 Rev 2 9.7 (relative change between L2 and L3 not more than 5 %)',
}


def run_level(H):
    panels = B.load_panels()
    piers = B.build_piers(panels)
    rig = A.Rig(panels, piers, DECK_ASSIGN, CHORD_ASSIGN, H)
    res = rig.run()
    return rig, res, panels, piers


def max_panel_shear(res, piers):
    out = {}
    for p in piers:
        out[p['panel']] = max(abs(r['pier_force'][p['id']]) for r in res.values())
    return out


def design_cost(res, piers, panels):
    areas = B.zone_areas()
    deck_cost = sum(areas[z] * B.DECK[DECK_ASSIGN[z]]['cost'] for z in areas)
    ps = max_panel_shear(res, piers)
    plen = {p['mark']: p['s1'] - p['s0'] for p in panels}
    embeds, tiedown = {}, {}
    for p in panels:
        m = p['mark']
        n_spacing = max(2, math.ceil((plen[m] - 1e-9) / 8.0) + 1)
        n_demand = math.ceil(ps[m] / B.EMBED_CAP - 1e-9)
        embeds[m] = max(n_spacing, n_demand, 2)
        W = plen[m] * p['top'] * (p['t'] / 12.0) * B.RHO
        Mres = 0.6 * W * (plen[m] / 2.0)
        tiedown[m] = 'yes' if ps[m] * B.H_DECK > Mres else 'no'
    n_emb = sum(embeds.values())
    n_td = sum(1 for v in tiedown.values() if v == 'yes')
    chord_lb = sum(math.dist(p0, p1) * SEC[CHORD_ASSIGN[cid]][2] for (cid, p0, p1) in B.CHORD_LINES)
    total_area = sum(areas.values())
    used = sorted({DECK_ASSIGN[z] for z in areas})
    per_type = {}
    for z in areas:
        per_type[DECK_ASSIGN[z]] = per_type.get(DECK_ASSIGN[z], 0.0) + areas[z]
    desc = 'roof deck, ribs east-west, by zone (%s)' % '; '.join(
        '%s %s %.0f sf' % (c, '/'.join(z for z in sorted(areas) if DECK_ASSIGN[z] == c),
                           per_type[c]) for c in used)
    items = [
        (desc, round(total_area, 1),
         round(deck_cost / total_area, 4), round(deck_cost, 2), CITE['deck']),
        ('chord and collector steel PL3x3/8, erected', round(chord_lb, 1), B.STEEL_RATE,
         round(chord_lb * B.STEEL_RATE, 2), CITE['sect']),
        ('deck-to-panel embed connections type E1', n_emb, B.EMBED_COST, round(n_emb * B.EMBED_COST, 2), CITE['embed']),
        ('panel base tie-down assemblies type T1', n_td, B.TIEDOWN_COST, round(n_td * B.TIEDOWN_COST, 2), CITE['tie']),
    ]
    total = sum(i[3] for i in items)
    return items, total, embeds, tiedown, ps


def wb_schedule(res2, piers, panels, conv, cost):
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = 'DeckZones'
    areas = B.zone_areas()
    ws.append(['zone_id', 'deck_code', 'G_prime_used_kip_per_in', 'capacity_asd_plf', 'area_sf', 'cost_usd'])
    for z in sorted(areas):
        code = DECK_ASSIGN[z]
        g = B.DECK[code]['g'] * (1.15 if z == 'Z22' else 1.0)
        ws.append([z, code, round(g, 2), round(B.DECK[code]['cap'], 1), round(areas[z], 1),
                   round(areas[z] * B.DECK[code]['cost'], 2)])

    ws = wb.create_sheet('ChordSchedule')
    ws.append(['chord_id', 'section_code', 'length_ft', 'cost_usd'])
    for (cid, p0, p1) in B.CHORD_LINES:
        L = math.dist(p0, p1)
        ws.append([cid, CHORD_ASSIGN[cid], round(L, 2), round(L * SEC[CHORD_ASSIGN[cid]][2] * B.STEEL_RATE, 2)])

    ws = wb.create_sheet('Piers')
    ws.append(['pier_id', 'panel', 'line', 's0_ft', 's1_ft', 'width_ft', 'thickness_in', 'top_z_ft',
               'k_kip_per_in', 'embeds', 'tiedown'])
    items, total, embeds, tiedown, ps = cost
    for p in piers:
        ws.append([p['id'], p['panel'], p['line'], round(p['s0'], 2), round(p['s1'], 2), round(p['width'], 2),
                   p['t'], round(p['top'], 2), round(p['k'], 2), embeds[p['panel']], tiedown[p['panel']]])

    ws = wb.create_sheet('ShearWalls')
    ws.append(['scenario', 'line', 'line_load_plf', 'reaction_kips'])
    for (sc, _az) in B.SCEN:
        r = res2[sc]
        for ln in ['S', 'E', 'N1', 'N2', 'E2', 'W']:
            ws.append([sc, ln, round(abs(r['line_load'][ln]) * 1000.0, 1), round(abs(r['react'].get(ln, 0.0)), 3)])

    ws = wb.create_sheet('Diaphragm')
    ws.append(['scenario', 'line', 'station_frac', 'unit_shear_plf'])
    for (sc, _az) in B.SCEN:
        r = res2[sc]
        for ln in ['S', 'E', 'N1', 'N2', 'E2', 'W']:
            for frac, v in r['shear'][ln]:
                ws.append([sc, ln, frac, round(abs(v), 1)])

    ws = wb.create_sheet('Chords')
    ws.append(['scenario', 'chord_id', 'force_kips'])
    for (sc, _az) in B.SCEN:
        r = res2[sc]
        for (cid, _, _) in B.CHORD_LINES:
            ws.append([sc, cid, round(abs(r['chord'].get(cid, 0.0)), 2)])

    ws = wb.create_sheet('Drift')
    ws.append(['scenario', 'direction', 'deflection_in'])
    for (sc, _az) in B.SCEN:
        r = res2[sc]
        for d in ('X', 'Y'):
            ws.append([sc, d, round(r['drift'][d], 3)])

    ws = wb.create_sheet('Convergence')
    ws.append(['level', 'mesh_size_ft', 'elements', 'max_unit_shear_plf', 'key_reaction_kips'])
    for name, H, nel, umax, rw in conv:
        ws.append([name, H, nel, round(umax, 1), round(abs(rw), 2)])

    ws = wb.create_sheet('Cost')
    ws.append(['item', 'quantity', 'unit_cost_usd', 'total_usd'])
    for (item, q, u, t, _c) in items:
        ws.append([item, q, u, t])
    for s in wb.worksheets:
        for c in s[1]:
            c.font = Font(bold=True)
    return wb


def register_rows():
    return [
        ('EOR-NDDC-A2-S01 Rev 2', '4.2', 'velocity pressure q(z) = 0.00256 Kz Kzt Kd Ke V^2 with Kz = 2.01 (z/900)^(2/9.5)', '0.00256', '-', 'all wall lines'),
        ('EOR-NDDC-A2-S01 Rev 2', '4.3', 'the topographic factor is taken from the site-specific study and applies over the whole footprint', '1.19', '-', 'all wall lines, all azimuths'),
        ('EOR-NDDC-A2-S01 Rev 2', '4.4', 'ground elevation factor Ke = exp(-0.0000362 zg) with zg taken from the ALTA survey benchmark; Ke is not to be taken as 1.0 at this site', '0.0000362', '-', 'all wall lines'),
        ('EOR-NDDC-A2-S01 Rev 2', '4.1', 'Exposure Category C in all directions, GCpi cancels and is not included in the diaphragm loads', '0.18', '-', 'all wall lines'),
        ('EOR-NDDC-A2-S01 Rev 2', '4.5', 'twelve wind scenarios W01 to W12 from the eight reported azimuths and the torsional cases', '12', 'scenarios', 'ShearWalls, Diaphragm, Chords, Drift'),
        ('EOR-NDDC-A2-S01 Rev 2', '3.3', 'every reported quantity is an allowable stress design quantity from the strength-level wind effect by the combination 0.6W', '0.6', '-', 'ShearWalls, Diaphragm, Chords, Drift'),
        ('NDDC-AHJ-014', '2', 'basic wind speed accepted for the permit application', '115', 'mph', 'all wall lines'),
        ('NDDC-AHJ-014', '2', 'wind directionality factor for the main wind force resisting system', '0.85', '-', 'all wall lines'),
        ('NDDC-AHJ-014', '2', 'risk category of the continuous-operation data processing facility', 'III', '-', 'all wall lines'),
        ('NDDC-AHJ-014', '3', 'a flexible-diaphragm tributary distribution is not accepted, a semi-rigid analysis is required', '1', 'method', 'DIAPH-MT model'),
        ('TS-2026-02', '4', 'topographic factor applied over the whole Building A2 footprint at all elevations and all azimuths', '1.19', '-', 'all wall lines'),
        ('ALTA-2025-77', '1', 'finished floor elevation of Building A2 above sea level, the elevation zg used for Ke', '3940.0', 'ft', 'all wall lines'),
        ('SR-2026-118', '3', 'top of deck bearing above finished floor, the height h of the panel cantilever', '28.00', 'ft', 'Piers, ShearWalls'),
        ('SR-2026-118', '4', 'top of panel of the typical parapet on the south, east, west and generator yard elevations', '31.00', 'ft', 'Piers, parapet transfer'),
        ('SR-2026-118', '5.2', 'top of panel of the mechanical screen wall between x = 96 ft and x = 168 ft on the north elevation', '36.00', 'ft', 'panels N108, N109, N110, N111'),
        ('WT-2026-07', '3', 'the design pressure on a wall patch is p = q_h Cp and no further height adjustment is applied', '1', 'basis', 'all wall patches'),
        ('WT-2026-07', '5', 'the wall is divided into elevation bands from the ground to the roof and a parapet strip above it, each band carrying its own coefficient', '', '-', 'all wall patches'),
        ('WT-2026-07', '6.3', 'net parapet coefficient GCpn = +1.5 windward and -1.0 leeward on the projected parapet area with q_p at the top of the parapet', '1.5', '-', 'parapet patches'),
        ('EOR-NDDC-A2-S01 Rev 2', '5.2', 'panel concrete f''c 5000 psi, Ec 4030 ksi and G = 0.40 Ec', '4030', 'ksi', 'all piers'),
        ('EOR-NDDC-A2-S01 Rev 2', '5.3', 'where the 2024 precast panel schedule and the as-built model disagree the as-built model governs', '2026', 'model', 'Piers, screen wall panels'),
        ('EOR-NDDC-A2-S01 Rev 2', '5.4', 'a leg narrower than 2.0 ft is neglected and carries no in-plane shear', '2.0', 'ft', 'Piers'),
        ('EOR-NDDC-A2-S01 Rev 2', '5.5', 'pier stiffness k = 1/(h^3/(3 Ec I) + 1.2 h/(G A)) with I = t L^3/12 and A = t L', '1', 'kip/in', 'Piers'),
        ('EOR-NDDC-A2-S01 Rev 2', '5.6', 'a panel in-plane shear is the sum of the shears of its legs', '1', 'sum', 'Piers, embeds'),
        ('EOR-NDDC-A2-S01 Rev 2', '5.7', 'panel base connection demand is the panel in-plane shear against the vendor ASD capacity per foot of panel length', '1.40', 'kip/ft', 'panel base connections'),
        ('EOR-NDDC-A2-S01 Rev 2', '5.8', 'panel stability on 0.6D + 0.6W with resisting moment 0.6 x self weight x half the panel length on the gross panel area', '0.6', '-', 'tie-down assemblies'),
        ('EOR-NDDC-A2-S01 Rev 2', '6.1', 'the design pressure on a wall patch is p = q_h Cp and on a parapet patch p = q_p GCpn', '1', 'basis', 'all wall patches'),
        ('EOR-NDDC-A2-S01 Rev 2', '6.3', 'wall pressures act on the gross wall area including door and louver openings', '1', 'gross', 'panels with openings'),
        ('EOR-NDDC-A2-S01 Rev 2', '6.4', 'a patch of area A with centroid at elevation z delivers R_roof = p A z / h to the roof deck', '1', 'ratio', 'line load on every wall line'),
        ('EOR-NDDC-A2-S01 Rev 2', '6.6', 'torsional case with all line loads factored by 0.75 and M_T = e B |F| at an eccentricity of 0.15 B', '0.15', 'B', 'scenarios W09 to W12'),
        ('EOR-NDDC-A2-S01 Rev 2', '6.6', 'torsional line load factor applied together with the torsional moment', '0.75', '-', 'scenarios W09 to W12'),
        ('EOR-NDDC-A2-S01 Rev 2', '7.1', 'exactly one deck type from the catalogue is used over the whole of each zone', '1', 'type per zone', 'DeckZones'),
        ('EOR-NDDC-A2-S01 Rev 2', '7.2', 'the diaphragm unit shear anywhere within a zone must not exceed the ASD shear capacity of that zone deck type', '1', 'limit', 'DeckZones'),
        ('EOR-NDDC-A2-S01 Rev 2', '7.3', 'the catalogue adjustment for a different deck span applies to stiffness only, never to strength', '1.15', '-', 'zone Z22'),
        ('EOR-NDDC-A2-S01 Rev 2', '8.2', 'diaphragm deflection relative to its supports must not exceed the value the Owner basis of design sets', '0.55', 'in', 'Drift'),
        ('EOR-NDDC-A2-S01 Rev 2', '8.3', 'pier drift must not exceed h/400', '400', 'h/', 'Piers'),
        ('EOR-NDDC-A2-S01 Rev 2', '9.1', 'structured square mesh with refinement levels H = 10.0, 5.0 and 2.50 ft', '2.50', 'ft', 'Convergence'),
        ('EOR-NDDC-A2-S01 Rev 2', '9.2', 'element stress resultants Nx = EAx eps_x, Ny = EAy eps_y, Nxy = Ghat gamma with Ghat = 12 G-prime', '12', '-', 'all elements'),
        ('EOR-NDDC-A2-S01 Rev 2', '9.2', 'smeared axial rigidity is the chord area of the member divided by its spacing times Es and the deck is not credited', '29000', 'ksi', 'all elements'),
        ('EOR-NDDC-A2-S01 Rev 2', '9.5', 'the roof-level line load is applied to the perimeter nodes as the consistent nodal loads of the hat functions', '1', 'consistent', 'all wall lines'),
        ('EOR-NDDC-A2-S01 Rev 2', '9.6', 'the unit shear reported at a station is that of the element with an edge on the wall line whose centre is nearest the station', '1', 'nearest', 'Diaphragm'),
        ('EOR-NDDC-A2-S01 Rev 2', '9.7', 'the convergence measure is the relative change between L2 and L3 in the reaction of wall line W under W01', '5', '%', 'Convergence'),
        ('EOR-NDDC-A2-S01 Rev 2', '9.8', 'an implementation of DIAPH-MT must reproduce verification example VE-1 before it is applied to Building A2', '240', 'elements', 'DIAPH-MT'),
        ('EOR-NDDC-A2-S01 Rev 2', '10.2', 'chord force is the axial force in the chord bar checked against the schedule allowable tension and compression', '1', 'allowable', 'Chords, ChordSchedule'),
        ('EOR-NDDC-A2-S01 Rev 2', '11.2.1', 'the diaphragm unit shear is reported at the quarter points of every wall line', '0.25', 'fraction', 'Diaphragm'),
        ('CDS-B36', 'Note 2', 'the tabulated shear strength is nominal and is divided by the safety factor for allowable stress design', '2.35', '-', 'DeckZones'),
        ('CDS-B36', 'Note 4', 'G-prime is tabulated for a deck span of 6 ft 0 in and multiplied by 1.15 for a deck span of 4 ft 0 in, stiffness only', '1.15', '-', 'zone Z22'),
        ('CDS-B36', 'Note 5', 'installed cost is the erected cost per square foot of deck including fasteners and sidelap connections', '1', 'per sf', 'Cost'),
        ('KRS-CH', 'Note 2', 'the allowable values are ASD and are compared directly against the ASD member forces', '1', 'ASD', 'ChordSchedule'),
        ('KRS-CH', 'Note 4', 'installed cost of chord and collector members per pound of member weight', '2.85', 'per lb', 'Cost'),
        ('KRS-CN', '2.1', 'one E1 embed develops an allowable stress design in-plane shear between deck and panel', '4.20', 'kips', 'embeds'),
        ('KRS-CN', '2.3', 'E1 embeds at not more than 8 ft 0 in on centre and a minimum of two per panel, or the count needed to develop the panel shear', '8', 'ft', 'embeds'),
        ('KRS-CN', '2.4', 'installed cost of one E1 embed', '185', 'USD', 'Cost'),
        ('KRS-CN', '3.1', 'the standard B1 base connection develops an allowable stress design shear per foot of panel length', '1.40', 'kip/ft', 'panel base connections'),
        ('KRS-CN', '4.2', 'one T1 assembly develops an allowable stress design uplift capacity and acts at a lever arm equal to the panel length', '88', 'kips', 'tie-down assemblies'),
        ('KRS-CN', '4.3', 'installed cost of one T1 assembly per panel served', '2450', 'USD', 'Cost'),
        ('SJ-201', 'Note 1', 'joists run north-south at 5 ft 0 in on centre and the deck spans east-west between them at 6 ft 0 in', '6', 'ft', 'EAy, G-prime'),
        ('SJ-201', 'Note 2', 'in deck zone Z22 the joists are doubled to 4 ft 0 in on centre and the deck span there is 4 ft 0 in', '4', 'ft', 'zone Z22'),
        ('SJ-201', 'Note 3', 'girders run east-west on the column lines at 40 ft 0 in on centre', '40', 'ft', 'EAx'),
        ('OBD-NDDC-A2', '4.4', 'the precast connection detail tolerates a roof diaphragm deflection relative to its supports of 0.55 in', '0.55', 'in', 'Drift'),
        ('OBD-NDDC-A2', '4.6', 'not more than 4 distinct roof deck types may be used across the Building A2 roof', '4', 'types', 'DeckZones'),
        ('OBD-NDDC-A2', '4.7', 'installed cost cap of the lateral package', '310000', 'USD', 'Cost'),
        ('OBD-NDDC-A2', '4.7', 'costs are taken from the rates in the issued catalogues with chord steel at the stated installed rate', '2.85', 'per lb', 'Cost'),
        ('Spec 01 33 00', '1.5', 'schedules are delivered as one worksheet per schedule with the column headings named in the templates and no blank or placeholder cell', '1', 'workbook', 'lateral_schedule.xlsx'),
        ('Spec 01 33 00', '1.6', 'the design basis carries a table of the values the design was built on in the form item, value, source', '10', 'items', 'design_basis.md'),
        ('Spec 01 33 00', '1.7', 'plan drawings are delivered as DXF on the building grid in feet with the listed layers and the ASD statement', '7', 'layers', 'diaphragm_plan.dxf'),
        ('EOR-NDDC-A2-S01 Rev 2', '9.1', 'the mesh is laid over the bounding rectangle of the roof with the cells outside the roof outline or inside a roof opening removed', '10', 'cells', 'footprint, zone areas'),
        ('S-201', 'Note 8', 'zone Z43 is bounded by the generator yard notch and its area is less than the grid rectangle', '1200', 'sf', 'zone Z43'),
        ('S-201', 'Note 4', 'deck zones Z11 through Z43 as shown, one deck type per zone', '12', 'zones', 'DeckZones'),
        ('S-201', 'Note 5', 'chord lines C-S, C-N1, C-N2, C-E, C-E2 and C-W on the diaphragm boundary', '6', 'lines', 'ChordSchedule'),
        ('S-201', 'Note 6', 'collector lines K-N2 and K-E2 drag the diaphragm into the generator yard walls', '2', 'lines', 'collectors'),
        ('S-201', 'Note 7', 'opening collector lines O-S, O-N, O-W and O-E around the mechanical well', '4', 'lines', 'collectors'),
        ('CDS-B36', 'Note 1', 'CDS-B36 is a 36 in cover width wide-rib deck mechanically fastened to the supports and stitched at the sidelaps', '36', 'in', 'DeckZones'),
        ('CDS-B36', 'Table 3', 'one deck type is selected from the catalogue table of gauge, fastener pattern and sidelap connections with its nominal shear strength and shear stiffness', '16', 'types', 'DeckZones'),
        ('SR-2026-118', '5.1', 'the north elevation screen wall is part of the precast panel and not a separate frame', '1', 'panel', 'panels N108 to N111'),
        ('SR-2026-118', '5.3', 'the screen is solid precast over its full height, neither louvred nor perforated', '1', 'solid', 'parapet coefficient'),
        ('SR-2026-118', '6.1', 'the generator yard re-entrant corner is plumb within 0.05 ft over the panel height', '0.05', 'ft', 'panels E201 to E204'),
        ('EOR-NDDC-A2-S01 Rev 2', '9.6', 'a chord or collector force is the largest bar force on that line', '1', 'max', 'Chords'),
        ('EOR-NDDC-A2-S01 Rev 2', '10.3', 'the collector lines at the re-entrant corner and around the mechanical well are checked as chord members', '1', 'allowable', 'collectors K-N2, K-E2, O-S, O-N, O-W, O-E'),
        ('EOR-NDDC-A2-S01 Rev 2', '8.2', 'the diaphragm deflection is the largest nodal displacement in the axis measured from the stiffness-weighted mean displacement of the piers resisting that axis', '0.55', 'in', 'Drift'),
        ('Spec 01 33 00', '1.6', 'calculations are delivered as one PDF on 8-1/2 x 11 portrait sheets covering the sections the criteria lists', '1', 'PDF', 'calculations.pdf'),
        ('OBD-NDDC-A2', '4.1', 'single-storey data hall with a steel roof deck on open-web joists and girders carried laterally by precast perimeter wall panels on all exterior building lines', '1', 'system', 'analysis model'),
        ('Spec 01 33 00', '1.8', 'every submittal carries a constraint register with the columns document, clause, requirement, value, units, items', '6', 'columns', 'constraint_register.xlsx'),
        # ---- rows filed so that every family the package relies on is traceable to its clause
        ('A-101 Roof Plan Rev C', 'Note 1', 'the as-built roof extents carry the generator yard notch added by Revision B; Revision A does not show it', '', '-', 'footprint, zone areas'),
        ('NDDC-A2 Federated Model 2026', 'Pset_RoofCommon', 'top of the roof deck slab of the as-built roof, the elevation the model carries', '28.000', 'ft', 'DeckZones, Piers'),
        ('NDDC-A2 Federated Model 2026', 'Pset_PrecastPanel', 'top elevation of the mechanical screen wall panel above the roof, as modelled', '10972.8', 'mm', 'panels N108 to N111'),
        ('KRS-CH', 'Table 1', 'chord and collector catalogue sections with their weight, area and allowable tension and compression', '', '-', 'ChordSchedule'),
        ('EOR-NDDC-A2-S01 Rev 2', '10.1', 'every chord and collector line of the framing plan carries a catalogue section over its full length', '1', 'section per line', 'ChordSchedule'),
        ('EOR-NDDC-A2-S01 Rev 2', '11.1', 'the calculation package is delivered on portrait sheets and covers the wind pressures, the parapet transfer to the roof deck, the reactions, the shears, the chord forces, the wall loads and the design basis', '', '-', 'calculations.pdf'),
        ('EOR-NDDC-A2-S01 Rev 2', '9.4', 'each pier is a spring of stiffness k acting in the plane of its wall, attached at the mesh node nearest the mid point of the leg', '1', 'spring per pier', 'Piers, ShearWalls'),
        ('EOR-NDDC-A2-S01 Rev 2', '9.3', 'chords and collectors are two node bar elements acting in the direction of the line, one bar per mesh interval', '1', 'bar per interval', 'Chords'),
        ('EOR-NDDC-A2-S01 Rev 2', '11.3', 'the Engineer of Record re-runs the analysis on the submitted design and reported quantities are accepted when they agree within the stated tolerance', '7.5', '%', 'ShearWalls, Diaphragm, Chords, Drift'),
        ('Spec 01 33 00', '1.6', 'below the table of design values the design basis carries a second table of the governing wind scenario for each wall line, one row per line', '', '-', 'design_basis.md'),
        ('A-301 Exterior Elevations Rev C', 'Note 2', 'top of panel is +31.00 ft unless noted as screen wall', '31.00', 'ft', 'parapet strips'),
        ('PC-S02 Precast Panel Elevations Rev 2', 'Note 4', 'openings shown are the fabrication openings; field cut openings made after erection are not shown and are verified against the 2026 federated model', '', '-', 'Piers'),
        ('EOR-NDDC-A2-S01 Rev 2', '9', 'the roof deck diaphragm is neither rigid nor flexible relative to the precast walls, so neither a tributary nor a rigid distribution is accepted and the semi rigid model is required', '', '-', 'analysis model'),
    ]


def wb_register():
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = 'Register'
    ws.append(['document', 'clause', 'requirement', 'value', 'units', 'items'])
    for r in register_rows():
        ws.append(list(r))
    for c in ws[1]:
        c.font = Font(bold=True)
    return wb


def dxf_plan(res2):
    doc = ezdxf.new('R2010')
    for name in ['S-DIAP-SHEAR', 'S-DIAP-ZONE', 'S-WALL-REAC', 'S-CHRD', 'S-COLL', 'S-ANNO-TEXT', 'S-GRID']:
        if name not in doc.layers:
            doc.layers.add(name)
    msp = doc.modelspace()
    for x, lab in [(0, 'A'), (40, 'B'), (80, 'C'), (120, 'D'), (160, 'E'), (200, 'F'), (240, 'G')]:
        msp.add_line((x, -14), (x, 194), dxfattribs={'layer': 'S-GRID'})
        msp.add_text(lab, height=3.0, dxfattribs={'layer': 'S-GRID'}).set_placement((x - 1.5, -20))
    for y, lab in [(0, '1'), (40, '2'), (80, '3'), (120, '4'), (160, '5'), (180, '6')]:
        msp.add_line((-14, y), (254, y), dxfattribs={'layer': 'S-GRID'})
        msp.add_text(lab, height=3.0, dxfattribs={'layer': 'S-GRID'}).set_placement((-22, y - 1.5))
    for z, (x0, y0, x1, y1) in B.ZONES.items():
        msp.add_lwpolyline([(x0, y0), (x1, y0), (x1, y1), (x0, y1), (x0, y0)], dxfattribs={'layer': 'S-DIAP-ZONE'})
        msp.add_text(f"{z} {DECK_ASSIGN[z]}", height=2.5,
                     dxfattribs={'layer': 'S-ANNO-TEXT'}).set_placement((x0 + 2, y0 + 2))
    for sc, tag, ytxt in (('W05', 'TRANSVERSE DIRECTION - UNIT SHEARS FOR W05 (WIND FROM THE SOUTH), PLF', 214),
                          ('W03', 'LONGITUDINAL DIRECTION - UNIT SHEARS FOR W03 (WIND FROM THE EAST), PLF', 204)):
        r = res2[sc]
        for ln in ['S', 'N1', 'N2', 'E', 'E2', 'W']:
            p0, p1, nrm, axis = B.LINES[ln]
            L = math.dist(p0, p1)
            d = ((p1[0] - p0[0]) / L, (p1[1] - p0[1]) / L)
            for frac, v in r['shear'][ln]:
                x = p0[0] + d[0] * frac * L
                y = p0[1] + d[1] * frac * L
                msp.add_text(f"{abs(v):.0f}", height=2.2, dxfattribs={'layer': 'S-DIAP-SHEAR'}).set_placement((x + 2, y + 2 + (4 if axis else 0)))
        msp.add_text(tag, height=3.6, dxfattribs={'layer': 'S-ANNO-TEXT'}).set_placement((-55, ytxt))
    for ln in ['S', 'N1', 'N2', 'E', 'E2', 'W']:
        p0, p1, nrm, axis = B.LINES[ln]
        mid = ((p0[0] + p1[0]) / 2, (p0[1] + p1[1]) / 2)
        rx = max(abs(v['react'].get(ln, 0.0)) for v in res2.values())
        msp.add_text(f"{ln}: R max {rx:.1f} kip ASD", height=2.6,
                     dxfattribs={'layer': 'S-WALL-REAC'}).set_placement((mid[0] + nrm[0] * 6, mid[1] + nrm[1] * 6))
    for (cid, p0, p1) in B.CHORD_LINES:
        layer = 'S-CHRD' if cid.startswith('C') else 'S-COLL'
        msp.add_line(p0, p1, dxfattribs={'layer': layer})
        m = ((p0[0] + p1[0]) / 2, (p0[1] + p1[1]) / 2)
        msp.add_text(f"{cid} {CHORD_ASSIGN[cid]}", height=2.2, dxfattribs={'layer': 'S-ANNO-TEXT'}).set_placement(m)
    for i, line in enumerate([
            'ROOF DIAPHRAGM AND SHEAR WALL LAYOUT - BUILDING A2, NORTHERN DIVIDE DATA CAMPUS',
            'ALL LOADS SHOWN ARE ALLOWABLE STRESS DESIGN (ASD), LOAD COMBINATION 0.6W',
            'ANALYSIS DIAPH-MT PER EOR-NDDC-A2-S01 REV 2 SECTION 9, QUANTITIES REPORTED AT MESH LEVEL L2',
            'PLAN ON THE BUILDING GRID IN FEET, ORIGIN AT THE SOUTH-WEST BUILDING CORNER']):
        msp.add_text(line, height=3.2 if i else 4.2, dxfattribs={'layer': 'S-ANNO-TEXT'}).set_placement((-55, 236 - 6 * i))
    return doc


def main():
    os.makedirs(OUT, exist_ok=True)
    res_by_level, conv = {}, []
    for name, H in LEVELS:
        rig, res, panels, piers = run_level(H)
        res_by_level[name] = (rig, res, panels, piers)
        conv.append((name, H, len(rig.model.elems), res['W01']['umax'], res['W01']['react'].get('W', 0.0)))
        print(name, 'elements', len(rig.model.elems), 'umax %.0f' % res['W01']['umax'], 'R_W %.2f' % res['W01']['react'].get('W', 0))
    rig, res, panels, piers = res_by_level['L2']
    cost = design_cost(res, piers, panels)
    items, total, embeds, tiedown, ps = cost
    print('cost total %.0f' % total)
    wb_schedule(res, piers, panels, conv, cost).save(os.path.join(OUT, 'lateral_schedule.xlsx'))
    wb_register().save(os.path.join(OUT, 'constraint_register.xlsx'))
    dxf_plan(res).saveas(os.path.join(OUT, 'diaphragm_plan.dxf'))
    summary = dict(
        conv=[list(c) for c in conv],
        conv_change_pct=(conv[1][4] - conv[2][4]) / conv[2][4] * 100.0,
        cost=[[i[0], i[1], i[2], i[3]] for i in items], total=total,
        drift=max(r['drift'][a] for r in res.values() for a in ('X', 'Y')),
        pier_drift=max(max(r['pier_disp'].values()) for r in res.values()),
        panel_shear={k: round(v, 3) for k, v in ps.items()},
        embeds=embeds, tiedown=tiedown,
        zone_shear=None,
        q_h=B.qz(28.0), q31=B.qz(31.0), q36=B.qz(36.0),
        base_ratio=max(ps[p['mark']] / (p['s1'] - p['s0']) for p in panels),
    )
    json.dump(summary, open(os.path.join(OUT, 'summary.json'), 'w'), indent=1)
    print('convergence L2-L3 %.2f %%' % summary['conv_change_pct'])
    print('max drift %.3f in, max pier drift %.3f in, max base %.2f kip/ft' % (
        summary['drift'], summary['pier_drift'], summary['base_ratio']))
    return summary


if __name__ == '__main__':
    main()
