"""Final analysis and the five deliverables for the wind diaphragm / shear wall package."""
import math
import os
import json
import numpy as np
import build as B
import analyze as A

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, 'out')
DECK_ASSIGN = {z: 'D22-36/7-4' for z in B.ZONES}     # one deck type, G' 32.6 kip/in (x1.15 in Z22)
CHORD_ASSIGN = {cid: 'PL3x3/8' for (cid, _, _) in B.CHORD_LINES}
LEVELS = [('L1', 10.0), ('L2', 5.0), ('L3', 2.5)]


def run(level_H, deck=None, chord=None):
    panels = B.load_panels()
    piers = B.build_piers(panels)
    rig = A.Rig(panels, piers, deck or DECK_ASSIGN, chord or CHORD_ASSIGN, level_H)
    res = rig.run()
    return rig, res, panels, piers


def panel_shears(rig, res):
    """max in-plane shear per panel over the scenarios: sum of its legs' spring forces"""
    out = {}
    for sc, r in res.items():
        for p in rig.piers:
            k = rig.model.pier_node[rig.piers.index(p)]
            u = np.array([rig.model.U[2 * k], rig.model.U[2 * k + 1]])
            dv = np.array(p['dir'], float)
            f = p['k'] * 12.0 * (dv @ u)
            out.setdefault(p['panel'], {}).setdefault(sc, 0.0)
            # accumulate per scenario: rebuild below instead
    # recompute cleanly scenario by scenario
    out = {}
    for sc, r in res.items():
        rig_res = rig.run_single(sc) if hasattr(rig, 'run_single') else None
    return out


def pier_forces(rig):
    """spring force of every pier in the current solved state"""
    f = {}
    for p, k in zip(rig.piers, rig.model.pier_node):
        u = np.array([rig.model.U[2 * k], rig.model.U[2 * k + 1]])
        dv = np.array(p['dir'], float)
        f[p['id']] = p['k'] * 12.0 * (dv @ u)
    return f


def all_results():
    out = {}
    for name, H in LEVELS:
        rig, res, panels, piers = run(H)
        # per-panel shear per scenario
        pshear = {}
        pdisp = {}
        for sc in res:
            rig_sc = A.Rig(panels, piers, DECK_ASSIGN, CHORD_ASSIGN, H)
            # re-solve this scenario alone to read the pier springs of it
            import copy
            m = rig_sc.model
            ll, _ = B.line_loads(panels, rig_sc.cp, dict(B.SCEN)[sc])
            factor = 0.75 if sc in B.TORSION else 1.0
            loads = [(p0, p1, ll[ln] * factor, nrm) for ln, (p0, p1, nrm, axis) in B.LINES.items()]
            tn = None
            if sc in B.TORSION:
                e, direc = B.TORSION[sc]
                F = sum(ll[ln] * factor * math.dist(p0, p1) * nrm[1 if direc == 'X' else 0]
                        for ln, (p0, p1, nrm, axis) in B.LINES.items())
                Bdim = 180.0 if direc == 'X' else 240.0
                Mt = abs(e) * Bdim * abs(F) * (1.0 if e > 0 else -1.0)
                tn, _c = rig_sc.torsional_forces(direc, Mt)
            m.solve(loads, torsion_force_nodes=tn)
            f = pier_forces(rig_sc)
            for p in piers:
                pshear.setdefault(sc, {})
                pshear[sc][p['panel']] = pshear[sc].get(p['panel'], 0.0) + f[p['id']]
                pdisp.setdefault(sc, {})
                pdisp[sc][p['panel']] = max(pdisp[sc].get(p['panel'], 0.0), abs(f[p['id']]) / p['k'])
        out[name] = dict(rig=rig, res=res, panels=panels, piers=piers, pshear=pshear, pdisp=pdisp, H=H)
        print(name, 'done: elements %d nodes %d umax %.0f' % (len(rig.model.elems), len(rig.model.nodes), res['W01']['umax']))
    return out


if __name__ == '__main__':
    os.makedirs(OUT, exist_ok=True)
    R = all_results()
    l2 = R['L2']
    print('W01 reaction W at each level:', [round(R[n]['res']['W01']['react']['W'], 2) for n, _ in LEVELS])
    json.dump({n: {sc: dict(react={k: float(v) for k, v in R[n]['res'][sc]['react'].items()},
                            drift=R[n]['res'][sc]['drift'],
                            umax=R[n]['res'][sc]['umax'],
                            line_load={k: float(v) for k, v in R[n]['res'][sc]['line_load'].items()},
                            shear={ln: [[f, float(v)] for f, v in R[n]['res'][sc]['shear'][ln]] for ln in B.LINES},
                            chord={k: float(v) for k, v in R[n]['res'][sc]['chord'].items()})
                for sc in R[n]['res']} for n, _ in LEVELS},
              open(os.path.join(OUT, 'results.json'), 'w'), indent=1)
    print('written results.json')
    print('max pier drift %.3f in' % max(max(v.values()) for v in l2['pdisp'].values()))
    print('panel shears max', {p: round(max(sc.get(p, 0) for sc in l2['pshear'].values()), 2) for p in list(l2['pshear']['W01'])[:6]})
