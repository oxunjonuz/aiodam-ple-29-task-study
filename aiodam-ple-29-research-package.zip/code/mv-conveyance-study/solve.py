import sys
sys.path.insert(0,"/work/ple-dataset/tasks/mv-conveyance-study/tests/corrino/electrical_task12_conveyance_study")
import check, est, routes as RT

def search(item, keys, sizes=("250","350","500","750"), setopts=(1,2,3)):
    R = RT.routes()
    out=[]
    for key in keys:
        r = R[key]
        ducts=[]
        for s in r["segments"]:
            if s["method"] in ("CE","UE"): ducts.append(("EB20", s.get("duct_in") or 5))
            elif s["method"]=="HDD": ducts.append(("HDPE-SDR11", s.get("duct_in") or 5))
            elif s["method"] in ("JB","JS"): ducts.append(("RGS", s.get("duct_in") or 5))
        for size in sizes:
            for sets in setopts:
                ok, why = check.feasible(item, size, sets, ducts)
                if not ok: continue
                u = max(2, sets+1)
                d = check.make(item, key, size, sets, u)
                a, w = check.route_ampacity(item, d)
                if a*sets < check.PICKUP[item]-0.5: continue
                c,_ = check.costs({item: d}, bond=0.0126)
                out.append((c[item]["rollup"]["tpc"], key, size, sets, u, a, w))
    out.sort()
    return out

if __name__ == "__main__":
    for item, keys in (("C01",["C01"]),("C02",["C02"]),("C03",["C03"]),("C04",["C04-OH","C04-CEDB"]),
                       ("C05",["C05"]),("C06",["C06"]),("C07",["C07"])):
        print("==",item)
        for tpc,key,size,sets,u,a,w in search(item,keys)[:5]:
            print(f"   {key:9s} {size:5s} x{sets} ducts {u}  amp {a:6.1f}/set  worst {w}  tpc {tpc:10.0f}")
