"""My own estimate engine for PLE mv-conveyance-study (turn 490).

Everything here is my transcription of the contract documents, not of the grader:
  * RFP 01 11 00 Amd 0002 Part 2 (labor plan) and Part 3 (estimating basis, 3.1-3.8)
  * PCSFA-IEDS Rev 3 (criteria that decide admissibility and the ampacity basis)
  * TD-15AL-133 Rev 3 + ampacity workbook (physical data, ampacity, pulling)
  * SUB-33 71 02-07 (SWBP 600 lb/ft), Supplier quote Q-2608-114, Rental quote RQ-26-0419,
    Subcontract quotes ADD-26-311 / PJB-8817, Surety letter, Payroll burden 2026,
    Labor Unit Database PCEC 2026, EP 1110-1-8 Vol 7 Region VII, BLS PPI, UFS 3-701-01 Table 4-2.

Where a value can be read from a corpus file it is read from it; the few that can only be
read by eye from a PDF are transcribed with the document and clause named.
"""
from __future__ import annotations

import json
import math
import re
import subprocess
from datetime import date
from pathlib import Path

import openpyxl

WS = Path("/work/ple-dataset/tasks/mv-conveyance-study/environment/filesystem/"
          "final_batch4__electrical_task12_conveyance_study__blind")


def _pdftext(rel):
    return subprocess.run(["pdftotext", "-layout", str(WS / rel), "-"], capture_output=True, text=True,
                          check=True).stdout


# ----------------------------------------------------------------------------- labour units, crews, burden (xlsx)
def _load_labor_units():
    wb = openpyxl.load_workbook(WS / "50_cost/Labor_Unit_Database_PCEC_2026.xlsx", data_only=True)
    ws = wb["LaborUnits"]
    units = {}
    for row in ws.iter_rows(min_row=5, values_only=True):
        if not row[0] or row[0] in ("Code",):
            continue
        units[row[0].strip()] = {"desc": row[1], "unit": row[2], "mh": float(row[3]), "basis": row[4], "crew": row[5]}
    crews = {}
    ws = wb["Crews"]
    for row in ws.iter_rows(min_row=5, values_only=True):
        if not row[0]:
            continue
        name, size, rtype, code = row[0].strip(), int(row[1]), (row[2] or ""), (row[3] or "")
        c = crews.setdefault(name, {"size": size, "labor": {}, "equipment": {}})
        if rtype.lower().startswith("labor"):
            c["labor"][code] = c["labor"].get(code, 0) + int(row[6])
        elif rtype.lower().startswith("equipment"):
            c["equipment"][code] = c["equipment"].get(code, 0) + int(row[6])
    return units, crews


def _load_burden():
    wb = openpyxl.load_workbook(WS / "50_cost/Payroll_Burden_and_Insurance_2026.xlsx", data_only=True)
    ws = wb["Burden_2026"]
    b = {}
    for row in ws.iter_rows(values_only=True):
        if row[0] in ("FICA", "FUTA", "CA_SUI"):
            b[row[0]] = float(row[3])
    wc = {}
    for row in ws.iter_rows(values_only=True):
        if str(row[0]).strip() in ("7538", "5190", "6218"):
            wc[str(row[0]).strip()] = float(row[3])
    b["WC"] = wc
    return b


# ----------------------------------------------------------------------------- wage determination Mod 5 (txt)
def _load_wage():
    txt = (WS / "50_cost/wage_determinations/CA20260022_Mod5_2026-08-06.txt").read_text()
    # classification -> (base, fringe); the Mod 5 file wraps the title over several lines, so match on the
    # distinctive head of each title and take the "$ <base>   <fringe>" pair that follows it.
    want = {
        "LINEMAN": r"LINE CONSTRUCTION: \(1\) LINEMAN; CABLE SPLICER",
        "EQSPEC": r"LINE CONSTRUCTION: \(2\) EQUIPMENT SPECIALIST",
        "GROUNDMAN": r"LINE CONSTRUCTION: \(3\) GROUNDMAN",
        "ELECTRICIAN": r"ELECTRICIAN: INSIDE ELECTRICAL WORK: JOURNEYMAN",
        "LAB1": r"LABORER GROUP 1:",
        "LAB3": r"LABORER GROUP 3:",
        "LAB4": r"LABORER GROUP 4",
        "PUMPOP": r"OPERATOR:\s+POWER EQUIPMENT, ALL OTHER WORK: GROUP\s+1-",
    }
    out = {}
    for k, pat in want.items():
        i = re.search(pat, txt)
        assert i, k
        seg = txt[i.end(): i.end() + 4000]
        m = re.search(r"\$ ?([\d,]+\.\d\d)\s+([\d,]+\.\d\d|\d+%)", seg)
        assert m, (k, seg[:200])
        base = float(m.group(1).replace(",", ""))
        fr = m.group(2)
        fringe = float(fr.replace(",", "").rstrip("%")) if fr.endswith("%") is False else None
        out[k] = {"base": base, "fringe": fringe, "fringe_pct": 0.0, "wc": None}
    # cable splicer inside: 5% above journeyman (footnote in ELEC0011-004)
    out["SPLICER_IN"] = {"base": round(out["ELECTRICIAN"]["base"] * 1.05, 2),
                         "fringe": out["ELECTRICIAN"]["fringe"], "fringe_pct": 0.0, "wc": None}
    return out


WC_CLASS = {"LINEMAN": "7538", "EQSPEC": "7538", "GROUNDMAN": "7538", "ELECTRICIAN": "5190",
            "SPLICER_IN": "5190", "LAB1": "6218", "LAB3": "6218", "LAB4": "6218", "PUMPOP": "6218"}


# ----------------------------------------------------------------------------- materials (supplier quote PDF)
def _load_materials():
    txt = _pdftext("50_cost/Supplier_Quote_Q-2608-114.pdf")
    mats = {}
    for line in txt.splitlines():
        m = re.match(r"\s*(\d{1,2})\s+([A-Z0-9][A-Z0-9/.\-]*)\s{2,}(.+?)\s{2,}(LF|EA|CY|SY|LB)\s+\$([\d,]+\.\d\d)\s+(\d+)\s?%", line)
        if m:
            code = m.group(2)
            mats[code] = {"line": int(m.group(1)), "desc": m.group(3).strip(), "unit": m.group(4),
                          "price": float(m.group(5).replace(",", "")), "waste": float(m.group(6)),
                          "indexed": "(I)" in m.group(3)}
    if "FIRESTOP-RMC5" not in mats:
        m = re.search(r"45\s+FIRESTOP-RMC5\s+Firestop system for 5 in RGS penetration\s+EA\s+\$([\d,]+\.\d\d)\s+(\d+)\s?%", txt)
        if m:
            mats["FIRESTOP-RMC5"] = {"line": 45, "desc": "Firestop system for 5 in RGS penetration", "unit": "EA",
                                     "price": float(m.group(1).replace(",", "")), "waste": float(m.group(2)),
                                     "indexed": False}
    # conduit dimensions, note 6 of the quote
    dims = {}
    for m in re.finditer(r"(?:PVC Type EB-20|PVC Schedule 40|HDPE SDR 11|Rigid galvanized steel|EMT)\s+(\d)\s+([\d.]+)\s+([\d.]+)", txt):
        pass
    dims = {"EB20": {5: (5.563, 5.263), 6: (6.625, 6.265)}, "SCH40": {5: (5.563, 5.047), 6: (6.625, 6.065)},
            "HDPE-SDR11": {5: (5.563, 4.551), 6: (6.625, 5.420)}, "RGS": {4: (4.500, 4.026), 5: (5.563, 5.047), 6: (6.625, 6.065)},
            "EMT": {4: (4.500, 4.334)}}
    return mats, dims


def _load_ppi():
    """Quote note 3 / BLS series WPU102603: base month is the quote's base index, latest is the last
    publication before the study date."""
    raw = json.loads((WS / "50_cost/BLS_PPI_WPU102603_2024-2026.json").read_text())
    for s in raw["Results"]["series"]:
        if s["seriesID"] == "WPU102603":
            vals = {(int(d["year"]), int(d["period"][1:])): float(d["value"]) for d in s["data"]}
            base = vals[(2026, 7)]
            latest = max((k for k in vals if k <= (2026, 8)), key=lambda k: k)
            return {"series": "WPU102603", "base": base, "base_month": "2026-07",
                    "latest": vals[latest], "latest_month": "%04d-%02d" % latest}
    raise RuntimeError("WPU102603 not in the PPI file")


PPI = _load_ppi()
SALES_TAX_PCT = 9.5          # RFP 3.4

# ----------------------------------------------------------------------------- EP 1110-1-8 Region VII (eq. rates)
# columns read from the Region VII tables (Vol 7, 2016) - rate $/hr total, then depreciation, FCCM, fuel, FOG,
# tires, repairs, and the fuel type.  Line refs given so the reading can be re-checked.
EQUIPMENT = {
    "C10BO003": {"fuel": "G", "total": 1.95, "depr": 0.42, "fccm": 0.01, "fuelc": 0.81, "fog": 0.09, "tw": 0.0, "tr": 0.0, "rep": 0.62},
    "C80TE008": {"fuel": "D-off", "total": 51.04, "depr": 19.33, "fccm": 1.90, "fuelc": 9.11, "fog": 1.57, "tw": 2.67, "tr": 0.45, "rep": 16.01},
    "H25CA040": {"fuel": "D-off", "total": 50.00, "depr": 17.39, "fccm": 1.73, "fuelc": 7.92, "fog": 1.33, "tw": 0.0, "tr": 0.0, "rep": 21.63},
    "L50CA001": {"fuel": "D-off", "total": 24.35, "depr": 6.91, "fccm": 0.61, "fuelc": 4.72, "fog": 2.35, "tw": 0.95, "tr": 0.16, "rep": 8.65},
    "P50WC002": {"fuel": "D-off", "total": 2.23, "depr": 0.21, "fccm": 0.01, "fuelc": 1.46, "fog": 0.27, "tw": 0.0, "tr": 0.0, "rep": 0.28},
    "T30DW022": {"fuel": "G", "total": 9.16, "depr": 1.66, "fccm": 0.10, "fuelc": 4.55, "fog": 0.61, "tw": 0.0, "tr": 0.0, "rep": 2.24},
}
EP_FUEL_BASE = {"D-off": 2.26, "G": 2.49}      # EP 1110-1-8 fuel price basis $/gal
JOBSITE_FUEL = {"D-off": 4.38, "G": 5.12}      # Invoice FSI-0826-2207
RENTALS = {"RQ-BDT": 96.00, "RQ-PUL": 58.50, "RQ-TBX": 7.25, "RQ-LFT": 11.80}   # RQ-26-0419


def equipment_rate(eid):
    if eid in RENTALS:
        return RENTALS[eid]
    e = EQUIPMENT[eid]
    ratio = JOBSITE_FUEL[e["fuel"]] / EP_FUEL_BASE[e["fuel"]]
    if abs(ratio - 1.0) <= 0.10:          # EP 1110-1-8 3.9/3.10: adjust only when the job-site price differs > 10 %
        return e["total"]
    return e["total"] - e["fuelc"] - e["fog"] + (e["fuelc"] + e["fog"]) * ratio


# ----------------------------------------------------------------------------- project constants (RFP / IEDS)
PROJECT = {"study_date": "2026-09-15", "construction_midpoint": "2027-08-18", "duration_months": 15,
           "programmed_amount_usd": 4_200_000, "subcontracted_pct": 30.0}
MARKUP = {"JOOH": 9.5, "HOOH": 4.5, "SIOH": 5.7, "contingency": 5.0, "bond_months": 12,
          "bond_surcharge_pct_per_month": 1.0,
          "bond_tiers": [(100_000, 25.0), (400_000, 15.0), (2_000_000, 10.0), (2_500_000, 7.5), (1e12, 6.5)],
          "profit_factors": [("Degree of Risk", 20.0, 0.08), ("Relative Difficulty of Work", 15.0, 0.09),
                             ("Size of the Job", 15.0, None), ("Period of Performance", 15.0, None),
                             ("Contractor's Investment", 5.0, 0.06), ("Assistance by Government", 5.0, 0.07),
                             ("Subcontracting", 25.0, None)]}
SPI = [("2024-10-01", 1.0), ("2025-10-01", 1.021), ("2026-10-01", 1.042441), ("2027-10-01", 1.0643322610),
       ("2028-10-01", 1.0856189062), ("2029-10-01", 1.1073312843)]
SUBCONTRACTS = {   # ADD-26-311 (HDD), PJB-8817 (jack and bore / jack and sleeve)
    "HDD": {"per_lf": {2: 64.0, 4: 92.0, 6: 128.0}, "pits": 5400.0, "min": 14000.0, "deep_over_in": 96.0, "deep_pct": 15.0},
    "JB": {"first_lf": 295.0, "add_lf": 88.0, "pits": 6800.0},
    "JS": {"casing_lf": 540.0, "carrier_lf": 36.0, "pits": 9800.0}}
TRENCH = {"bedding_in": 3.0, "side_in": 6.0, "ue_sand_in": 6.0, "db_width_in": 8.0, "protective_depth_ft": 5.0,
          "manhole_depth_ft": 8.0, "manhole_clear_ft": 2.0, "slope": {"A": 0.75, "B": 1.0, "C": 1.5}}
MH_OUT = (7.33, 9.33)
COVER_MIN = {"CE": {"open": 18, "paved": 24}, "UE": {"open": 24, "paved": 24}, "DB": {"open": 30, "paved": 30},
             "JB": {"open": 24, "paved": 24}, "JS": {"open": 24, "paved": 24}, "HDD": {"open": 120, "paved": 48}}
METHOD_CONDUIT = {"CE": "EB20", "UE": "SCH40", "HDD": "HDPE-SDR11", "JB": "RGS", "JS": "RGS", "RMC": "RGS", "EMT": "EMT"}
MULT = {"bucket_truck": 0.85, "mechanical_puller": 0.85}
P405_EFF, PCEC_EFF = 67.0, 80.0
EARTH_AMBIENT_C = 25
SLACK = {"per_manhole_ft": 6.0, "riser_ft": 8.0, "riser_pole_ft": 40.0, "termination_ft": 10.0}
REEL_MAX_FT = 2500.0
PULL_K_LB_PER_CMIL = 0.006
PULL_EYE_MAX_LB = 10000.0
FEED_IN_TENSION_LB = 100.0
SWBP_LIMIT = 600.0            # SUB-33 71 02-07 (supersedes the 1000 lb/ft catalogue value)
JAM_RANGE = (2.8, 3.2)
FILL_MAX, FILL_MAX_HDD = 40.0, 30.0

# cable physical data, TD-15AL-133 Rev 3 s.3 (OD in, weight lb/ft per single conductor) and s.4.10 (SC kA at 0.5 s)
MV_CABLE = {"1/0": (1.18, 0.62), "2/0": (1.23, 0.69), "4/0": (1.33, 0.86), "250": (1.39, 0.95),
            "350": (1.50, 1.17), "500": (1.64, 1.48), "750": (1.86, 2.02), "1000": (2.04, 2.55)}
KCMIL = {"1/0": 105.6, "2/0": 133.1, "4/0": 211.6, "250": 250.0, "350": 350.0, "500": 500.0, "750": 750.0, "1000": 1000.0}
SC_KA_05S = {"1/0": 7.0, "2/0": 8.9, "4/0": 14.1, "250": 16.6, "350": 23.3, "500": 33.3, "750": 49.9, "1000": 66.5}
FRICTION = {"EB20": 0.35, "SCH40": 0.35, "HDPE-SDR11": 0.30, "RGS": 0.40, "EMT": 0.40, "TRAY": 0.15}
ACSR = {"1/0": {"name": "Raven", "weight": 0.145, "rbs": 4380, "amp40": 196},
        "3/0": {"name": "Pigeon", "weight": 0.231, "rbs": 6620, "amp40": 262},
        "336.4": {"name": "Linnet", "weight": 0.463, "rbs": 14100, "amp40": 428},
        "477": {"name": "Hawk", "weight": 0.656, "rbs": 19500, "amp40": 532}}


# ----------------------------------------------------------------------------- ampacity tables (xlsx)
def _load_ampacity():
    wb = openpyxl.load_workbook(WS / "40_electrical_data/cable/TD-15AL-133_Ampacity_Tables.xlsx", data_only=True)
    duct, single, dbc, air = {}, {}, {}, {}
    ws = wb["Ductbank"]
    for r in ws.iter_rows(min_row=5, values_only=True):
        if isinstance(r[0], str) and r[0] in MV_CABLE and isinstance(r[2], (int, float)):
            duct[(r[0], int(r[1]), int(r[2]), int(r[3]))] = float(r[6])
    ws = wb["Single_Conduit_in_Earth"]
    for r in ws.iter_rows(min_row=5, values_only=True):
        if isinstance(r[0], str) and r[0] in MV_CABLE and isinstance(r[1], (int, float)):
            single[(r[0], int(r[1]), int(r[2]), int(r[3]))] = float(r[5])
    ws = wb["Direct_Burial"]
    for r in ws.iter_rows(min_row=5, values_only=True):
        if isinstance(r[0], str) and r[0] in MV_CABLE and isinstance(r[1], (int, float)):
            dbc[(r[0], int(r[1]), int(r[3]))] = float(r[5])
    ws = wb["Air"]
    for r in ws.iter_rows(min_row=5, values_only=True):
        if isinstance(r[0], str) and r[0] in MV_CABLE and isinstance(r[3], (int, float)):
            kind = "tray" if "tray" in str(r[1]).lower() else "conduit"
            air[(r[0], kind, int(r[2]))] = float(r[3])
    dep, amb = {}, {}
    for r in wb["Depth_Correction_Ductbank"].iter_rows(min_row=4, values_only=True):
        if isinstance(r[0], str) and r[0] in MV_CABLE:
            for d, f in zip((30, 48, 72, 120, 180), r[1:6]):
                dep[(r[0], d)] = float(f)
    for r in wb["Earth_Ambient_Correction"].iter_rows(min_row=4, values_only=True):
        if isinstance(r[0], str) and r[0] in MV_CABLE:
            for a, f in zip((20, 25, 30), r[1:4]):
                amb[(r[0], a)] = float(f)
    return duct, single, dbc, air, dep, amb


LABOR_UNITS, CREWS = _load_labor_units()
BURDEN = _load_burden()
WAGE = _load_wage()
MATERIALS, CONDUIT_DIMS = _load_materials()
DUCT_TAB, SINGLE_TAB, DBC_TAB, AIR_TAB, DEPTH_CORR, AMB_CORR = _load_ampacity()


def _next_ge(options, v):
    for o in sorted(options):
        if o >= v - 1e-9:
            return o
    return None


# ----------------------------------------------------------------------------- rates
def loaded_rate(cls):
    w = WAGE[cls]
    b = BURDEN
    pct = b["FICA"] + b["FUTA"] + b["CA_SUI"] + b["WC"][WC_CLASS[cls]]
    base = w["base"] * (1 + w["fringe_pct"] / 100.0) + (w["fringe_pct"] / 100.0) * w["base"] * 0  # fringe% not used here
    return w["base"] * (1 + pct / 100.0) + w["fringe"]


def crew_rates(crew):
    c = CREWS[crew]
    size = sum(c["labor"].values())
    lab = sum(loaded_rate(k) * n for k, n in c["labor"].items()) / size
    eq = sum(equipment_rate(e) * n for e, n in c["equipment"].items())
    return size, lab, eq


def unit_mh(code, size_oh=None):
    u = LABOR_UNITS[code]
    m = u["mh"]
    if code == "STRING" and size_oh in ("336.4", "477"):
        m = 0.0328                       # database note 4 (P-405 Table 4-139 code 9049)
    if "P-405" in u["basis"] or u["basis"].startswith("P405"):
        m = m * P405_EFF / PCEC_EFF      # database note 1
    if code in ("PULL-MV", "DBC-LAY"):
        m *= MULT["mechanical_puller"]   # database note 2 (Table 4-142 note 6)
    if code in ("XARM", "GUY", "STRING"):
        m *= MULT["bucket_truck"]        # database note 3 (Table 4-139 note 2)
    return m


def material_cost(code, qty):
    mm = MATERIALS[code]
    f = (1 + mm["waste"] / 100.0) * (1 + SALES_TAX_PCT / 100.0)
    if mm["indexed"]:
        f *= PPI["latest"] / PPI["base"]          # quote note 3
    return qty * mm["price"] * f


# ----------------------------------------------------------------------------- escalation, profit, bond, roll-up
def spi_factor(day):
    pts = [(date.fromisoformat(a), b) for a, b in SPI]
    t = date.fromisoformat(day)
    for (d0, f0), (d1, f1) in zip(pts, pts[1:]):
        if d0 <= t <= d1:
            return f0 + (f1 - f0) * (t - d0).days / (d1 - d0).days
    return pts[-1][1]


def escalation_factor():
    return spi_factor(PROJECT["construction_midpoint"]) / spi_factor(PROJECT["study_date"])


def profit_pct():
    """UFC 3-740-05 11-2.1/11-2.2 weighted guidelines for $4.2M, 15 months, 30 % subcontracted."""
    tot = 0.0
    for name, rate, w in MARKUP["profit_factors"]:
        if w is None:
            if name == "Size of the Job":
                a = PROJECT["programmed_amount_usd"]
                w = 0.12 if a <= 100_000 else (0.12 - 0.07 * (a - 100_000) / 4_900_000 if a <= 5_000_000 else 0.04)
            elif name == "Period of Performance":
                mo = PROJECT["duration_months"]
                w = 0.12 if mo >= 24 else 0.03 + 0.09 * (mo - 1) / 23.0
            elif name == "Subcontracting":
                s = PROJECT["subcontracted_pct"]
                w = 0.03 if s >= 80 else 0.12 - 0.09 * s / 80.0
        tot += rate * w
    return tot


def bond_premium(amount):
    prev, prem = 0.0, 0.0
    for upper, per_m in MARKUP["bond_tiers"]:
        take = min(amount, upper) - prev
        if take <= 0:
            break
        prem += take * per_m / 1000.0
        prev = upper
    months = PROJECT["duration_months"] - MARKUP["bond_months"]
    return prem * (1 + max(0, months) * MARKUP["bond_surcharge_pct_per_month"] / 100.0)


def bond_rate_for(subtotal):
    return bond_premium(subtotal) / subtotal if subtotal > 0 else 0.0


def rollup(direct, bond_rate, length_ft):
    jooh = direct * MARKUP["JOOH"] / 100.0
    hooh = (direct + jooh) * MARKUP["HOOH"] / 100.0
    profit = (direct + jooh + hooh) * profit_pct() / 100.0
    sub = direct + jooh + hooh + profit
    bond = sub * bond_rate
    esc = (sub + bond) * (escalation_factor() - 1.0)
    contract = sub + bond + esc
    cont = contract * MARKUP["contingency"] / 100.0
    sioh = (contract + cont) * MARKUP["SIOH"] / 100.0
    tpc = contract + cont + sioh
    return {"direct": direct, "jooh": jooh, "hooh": hooh, "profit": profit, "bond": bond, "escalation": esc,
            "contract": contract, "contingency": cont, "sioh": sioh, "tpc": tpc,
            "cost_per_lf": tpc / length_ft if length_ft else 0.0}


def premarkup_factor():
    return (1 + MARKUP["JOOH"] / 100.0) * (1 + MARKUP["HOOH"] / 100.0) * (1 + profit_pct() / 100.0)


# ----------------------------------------------------------------------------- geometry helpers
def pl_length(pts):
    return sum(math.dist(pts[i], pts[i + 1]) for i in range(len(pts) - 1)) if len(pts) > 1 else 0.0


def conduit_dims(method, size_in):
    ctype = METHOD_CONDUIT.get(method)
    if ctype is None:
        return None, None, None
    d = CONDUIT_DIMS[ctype].get(int(size_in))
    return (ctype, d[0], d[1]) if d else (ctype, None, None)


def envelope_in(seg):
    _, od, _ = conduit_dims(seg["method"], seg.get("duct_in") or 5)
    od = od or 5.563
    rows, cols = max(1, int(seg.get("rows") or 1)), max(1, int(seg.get("cols") or 1))
    w = cols * od + (cols - 1) * 3.0
    h = rows * od + (rows - 1) * 3.0
    if seg["method"] == "CE":
        w, h = w + 6.0, h + 6.0
    return w, h


def trench_section(seg, od_cable):
    """RFP 3.7: bottom width, depth, excavation sf/lf, envelope sf/lf, sand sf/lf"""
    m = seg["method"]
    cover = float(seg.get("cover_in") or 0)
    if m == "DB":
        w_in = TRENCH["db_width_in"]
        h_in = 2.155 * od_cable
        depth_in = cover + h_in + TRENCH["bedding_in"]
        env_sf = 0.0
        sand_sf = w_in * (h_in + 2 * TRENCH["bedding_in"]) / 144.0
    else:
        w_env, h_env = envelope_in(seg)
        w_in = w_env + 2 * TRENCH["side_in"]
        depth_in = cover + h_env + TRENCH["bedding_in"]
        env_sf = w_env * h_env / 144.0
        sand_sf = 0.0
        if m == "UE":
            sand_sf = (w_in * (h_env + TRENCH["ue_sand_in"] + TRENCH["bedding_in"])) / 144.0 - env_sf
    bw, d = w_in / 12.0, depth_in / 12.0
    sl = seg.get("slope") if seg.get("slope") is not None else seg.get("slope_h_per_v")
    slope = float(sl or 0.0) if d >= TRENCH["protective_depth_ft"] and (seg.get("protective") or "") == "slope" else 0.0
    exc_sf = (bw + slope * d) * d
    return {"bw": bw, "depth": d, "exc_sf": exc_sf, "env_sf": env_sf, "sand_sf": sand_sf,
            "top_w": bw + 2 * slope * d}


# ----------------------------------------------------------------------------- pulling (TD-15AL-133 4.4-4.8)
def pull_params(size, method, duct_in):
    od_c, w1 = MV_CABLE[size]
    ctype, _, cid = conduit_dims(method, duct_in)
    if method in ("TRAY-EN", "TRAY-LD") or cid is None:
        return {"wc": 1.0, "f": FRICTION["TRAY"], "W": 3 * w1, "config": "tray", "ratio": None}
    f = FRICTION.get(ctype, 0.35)
    ratio = cid / od_c
    x = od_c / (cid - od_c) if cid > od_c else 10.0
    if ratio < JAM_RANGE[0]:
        return {"wc": 1.0 / math.sqrt(max(1e-6, 1 - x * x)) if x < 1 else 10.0, "f": f, "W": 3 * w1,
                "config": "triangular", "ratio": ratio}
    return {"wc": 1 + (4.0 / 3.0) * x * x, "f": f, "W": 3 * w1, "config": "cradled", "ratio": ratio}


def swbp(T, R, pp):
    if pp["config"] == "triangular":
        return pp["wc"] * T / (2 * R)
    if pp["config"] == "cradled":
        return (3 * pp["wc"] - 2) * T / (3 * R)
    return T / R


def allowed_tension(size):
    return min(PULL_K_LB_PER_CMIL * KCMIL[size] * 1000.0 * 2, PULL_EYE_MAX_LB)


def pull_run(events, size):
    T, maxT, maxS = FEED_IN_TENSION_LB, FEED_IN_TENSION_LB, 0.0
    for e in events:
        if e[0] == "straight":
            pp = pull_params(size, e[2], e[3])
            T = T + pp["wc"] * pp["f"] * pp["W"] * e[1]
        else:
            pp = pull_params(size, e[3], e[4])
            T = T * math.exp(pp["wc"] * pp["f"] * e[1])
            maxS = max(maxS, swbp(T, e[2], pp))
        maxT = max(maxT, T)
    return maxT, maxS


# ----------------------------------------------------------------------------- ampacity (IEDS 4.6 + TD tables)
def ampacity_ductbank(size, n_circuits, rho, cover_in, lf):
    rho_c = _next_ge([60, 90, 120, 150], rho)
    lf_c = _next_ge([75, 100], lf)
    d_c = _next_ge([30, 48, 72, 120, 180], cover_in)          # cover = depth to top of duct bank
    a = DUCT_TAB.get((size, n_circuits if n_circuits in (1, 2, 3, 4, 6) else 6, rho_c, lf_c))
    if a is None:
        for n in (6, 4, 3, 2, 1):
            if (size, n, rho_c, lf_c) in DUCT_TAB and n >= n_circuits:
                a = DUCT_TAB[(size, n, rho_c, lf_c)]
                break
    return a * DEPTH_CORR[(size, d_c)] * AMB_CORR[(size, 25)]


def ampacity_single(size, rho, cover_in, lf):
    rho_c = _next_ge([60, 90, 120, 150], rho)
    lf_c = _next_ge([75, 100], lf)
    d_c = _next_ge([30, 48, 72, 120, 180], cover_in)
    return SINGLE_TAB[(size, rho_c, d_c, lf_c)] * AMB_CORR[(size, 25)]


def ampacity_dbc(size, rho, lf):
    rho_c = _next_ge([60, 90, 120, 150], rho)
    lf_c = _next_ge([75, 100], lf)
    return DBC_TAB[(size, rho_c, lf_c)] * AMB_CORR[(size, 25)] * DEPTH_CORR[(size, 30)]


def ampacity_air(size, kind):
    return AIR_TAB[(size, kind, 40)]
