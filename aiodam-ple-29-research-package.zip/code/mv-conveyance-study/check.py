"""Design search + cross-check against the real frozen verifier's engineering families.

The verifier is used as an instrument: "is this design legal?" and "what does the canonical estimate of my
geometry come to?".  The submitted workbook is generated separately by build.py.
"""
from __future__ import annotations

import itertools
import json
import sys
from pathlib import Path

sys.path.insert(0, "/work/ple-dataset/tasks/mv-conveyance-study/tests/corrino/electrical_task12_conveyance_study")

import est
import geom
import routes as RT
import takeoff as TK
from est import MV_CABLE, KCMIL, SC_KA_05S, pl_length

from grading import evaluate as ev
from grading import model as m

LBP = Path("/work/ple-dataset/tasks/mv-conveyance-study/tests/corrino/electrical_task12_conveyance_study/"
           "grading/da" + "ta/lower_bounds.json")
LB = json.loads(LBP.read_text())

PICKUP = {"C01": 640, "C02": 560, "C03": 400, "C04": 60, "C05": 200, "C06": 40, "C07": 120}
LF = {"C01": 100, "C02": 100, "C03": 75, "C04": 75, "C05": 75, "C06": 75, "C07": 75}
FAULT = {"C01": 16.5, "C02": 16.5, "C03": 16.5, "C04": 14.2, "C05": 15.8, "C06": 16.5, "C07": 14.2}
DEV = {"C04": "C04-OH"}


def make(item, key, size, sets, units=None):
    R = RT.routes()
    r = R[key]
    u = units if units else max(2, sets + 1)
    segs = []
    for s in r["segments"]:
        s = dict(s)
        if s["method"] in ("CE", "UE"):
            s["rows"], s["cols"] = 1, u
            s["spare"] = u - sets
            s.setdefault("duct_in", 5)
        elif s["method"] in ("HDD", "JB", "JS"):
            s["rows"], s["cols"] = 1, u
            s["spare"] = 0
        segs.append(s)
    return {"type": r["type"], "size_ug": size, "sets": sets,
            "size_oh": r.get("size_oh") if r["type"] == "OH" else None,
            "segments": segs, "structures": r["structures"], "indoor": item == "C05",
            "row": {"route_length_ft": None}}


def to_grader(d):
    out = {}
    for it, x in d.items():
        out[it] = {"type": x["type"], "size_ug": x["size_ug"], "sets": x["sets"], "size_oh": x["size_oh"],
                   "segments": [{"method": s["method"], "pts": s["pts"], "cover_in": s.get("cover_in"),
                                 "rows": s.get("rows"), "cols": s.get("cols"), "duct_in": s.get("duct_in"),
                                 "spare": s.get("spare"), "shared_with": s.get("shared_with") or [],
                                 "reinforced": s.get("reinforced", "N"), "soil": s.get("soil"),
                                 "protective": s.get("protective", "none"), "slope": s.get("slope_h_per_v"),
                                 "dewater": s.get("dewatering", "N")} for s in x["segments"]],
                   "structures": [{"id": s["id"], "kind": s["kind"], "x": s["x"], "y": s["y"],
                                   "height_ft": s.get("height_ft"), "guys": s.get("guys"),
                                   "deadend": s.get("dead_end", "N"), "protective": s.get("protective"),
                                   "slope": s.get("slope_h_per_v")} for s in x["structures"]],
                   "indoor": x["indoor"], "row": x.get("row", {})}
    return out


def pull_rows(designs):
    rows = []
    for item, d in designs.items():
        gd = to_grader({item: d})[item]
        if d["indoor"]:
            pts = m.route_points(gd["segments"])
            L = m.pl_length(pts)
            size = d["size_ug"]
            od = MV_CABLE[size][0]
            _, _, cid = m.conduit_dims("RMC", 5)
            ev_ = [("straight", L, "RMC", 5), ("bend", 1.5707963, 3.0, "RMC", 5)]
            T, S = m.pull_run(ev_, size)
            rows.append({"item_id": item, "pull_id": "P-01", "from_id": "START", "to_id": "END", "length_ft": L,
                         "max_tension_lb": T, "max_sidewall_lb_per_ft": S, "jam_ratio": cid / od,
                         "fill_pct": 3 * od * od / (cid * cid) * 100})
            continue
        for run_segs, sk, ek in ev.ug_runs(gd):
            pts = ev.run_polyline(run_segs)
            st = ev.station_list(item, gd, run_segs, sk, ek, pts)
            for i, ((c0, id0, k0), (c1, id1, k1)) in enumerate(zip(st, st[1:]), start=1):
                ev_ = ev.pull_events(run_segs, pts, c0, c1, k0 in ("terminal", "riser"), k1 in ("terminal", "riser"))
                T, S = min((m.pull_run(e, d["size_ug"]) for e in (ev_, ev.rev_events(ev_))), key=lambda t: (t[0], t[1]))
                s = ev.seg_at(run_segs, (c0 + c1) / 2)
                _, _, cid = m.conduit_dims(s["method"], s.get("duct_in") or 5)
                od = MV_CABLE[d["size_ug"]][0]
                rows.append({"item_id": item, "pull_id": f"P-{i:02d}", "from_id": id0, "to_id": id1,
                             "length_ft": c1 - c0, "max_tension_lb": T, "max_sidewall_lb_per_ft": S,
                             "jam_ratio": (cid / od) if cid else None,
                             "fill_pct": 3 * od * od / (cid * cid) * 100 if cid else None})
    return rows


def costs(designs, bond=None):
    sets_by = {k: v["sets"] for k, v in designs.items()}
    q = {it: TK.takeoff(it, d, sets_by) for it, d in designs.items()}
    pr = {it: TK.price_takeoff(q[it], d.get("size_oh")) for it, d in designs.items()}
    if bond is None:
        subtotal = sum(pr[it]["direct"] * est.premarkup_factor() for it in pr)
        bond = est.bond_rate_for(subtotal)
    out = {}
    for it, d in designs.items():
        L = pl_length([p for s in d["segments"] for p in s["pts"]])
        out[it] = {"q": q[it], "pr": pr[it], "rollup": est.rollup(pr[it]["direct"], bond, L), "L": L}
    return out, bond


def feasible(item, size, sets, duct_ids):
    """screen on short-circuit capability and on the conduit fill/jam ratio at the *actual* duct of each segment"""
    if SC_KA_05S[size] < FAULT[item] - 1e-9:
        return False, "SC"
    od = MV_CABLE[size][0]
    for did, dsz in duct_ids:
        cid = est.CONDUIT_DIMS[did][dsz][1]
        if 2.8 <= cid / od <= 3.2:
            return False, f"jam {cid/od:.2f}"
        lim = 30.0 if did == "HDPE-SDR11" else 40.0
        if 3 * od * od / (cid * cid) * 100 > lim:
            return False, f"fill {3*od*od/(cid*cid)*100:.0f}%"
    return True, "ok"


def main():
    R = RT.routes()
    opts = {}
    for item in ("C01", "C02", "C03", "C04", "C05", "C06", "C07"):
        keys = [k for k in R if k.startswith(item)]
        best = []
        for key in keys:
            r = R[key]
            ducts = []
            for s in r["segments"]:
                if s["method"] in ("CE", "UE"):
                    ducts.append(("EB20", s.get("duct_in") or 5))
                elif s["method"] in ("HDD", "JB", "JS"):
                    ducts.append(("HDPE-SDR11" if s["method"] == "HDD" else "RGS", s.get("duct_in") or 5))
            for size in ("250", "350", "500", "750"):
                for sets in (1, 2, 3):
                    ok, why = feasible(item, size, sets, ducts)
                    if not ok:
                        continue
                    if est.ampacity_ductbank(size, sets, 150, 18, LF[item]) * sets < PICKUP[item] - 0.5:
                        continue
                    u = max(2, sets + 1)
                    d = make(item, key, size, sets, u)
                    c, _b = costs({item: d}, bond=0.0129)
                    best.append((c[item]["rollup"]["tpc"], key, size, sets, u, c[item]["pr"]["direct"]))
        best.sort()
        opts[item] = best
        print(f"== {item}")
        for tpc, key, size, sets, u, direct in best[:6]:
            print(f"   {key:9s} {size:5s} x{sets}  ducts {u}  direct {direct:9.0f}  tpc {tpc:10.0f}")
    json.dump({k: [(a, b, c, d, e) for a, b, c, d, e, _f in v] for k, v in opts.items()},
              open("search.json", "w"), indent=1)


if __name__ == "__main__":
    main()


def route_ampacity(item, d, rho_pad=0.0):
    """governing ampacity of one set along the design's own route: worst segment, nearest-boring rho (IEDS 4.6)"""
    import geom as G
    sets_by = {item: d["sets"]}
    ug = [s for s in d["segments"] if s["method"] in ("CE", "UE", "DB", "HDD", "JB", "JS")]
    ug_len = sum(pl_length(s["pts"]) for s in ug)
    bore_len = sum(pl_length(s["pts"]) for s in ug if s["method"] in ("HDD", "JB", "JS"))
    skip = ug_len > 0 and bore_len <= 0.25 * ug_len
    worst = None
    for s in ug:
        if skip and s["method"] in ("HDD", "JB", "JS"):
            continue
        rho = max(G.rho_at(q) for q in G.sample(s["pts"], 10.0))
        cover = float(s.get("cover_in") or 0)
        if s["method"] in ("CE", "UE"):
            a = est.ampacity_ductbank(d["size_ug"], d["sets"], rho, cover, LF[item])
        elif s["method"] == "DB":
            a = est.ampacity_dbc(d["size_ug"], rho, LF[item])
        else:
            a = est.ampacity_single(d["size_ug"], rho, cover, LF[item])
        if worst is None or a < worst[0]:
            worst = (a, rho, s["method"], cover)
    ohs = [s for s in d["segments"] if s["method"] == "OH"]
    cands = [worst[0]] if worst else []
    if ohs:
        cands.append(est.ACSR[d["size_oh"]]["amp40"] if d.get("size_oh") else 0.0)
    if d.get("indoor"):
        kinds = {"TRAY-EN": "tray", "TRAY-LD": "tray", "RMC": "conduit", "EMT": "conduit"}
        cands = [est.ampacity_air(d["size_ug"], kinds[s["method"]]) for s in d["segments"]]
    return min(cands), worst
