"""Canonical take-off of one design, RFP 01 11 00 Part 3.7 (my transcription of the table in 3.7)."""
from __future__ import annotations

import math

import est
import geom
from est import (MATERIALS, TRENCH, MH_OUT, SLACK, REEL_MAX_FT, MV_CABLE, KCMIL, SUBCONTRACTS,
                 envelope_in, trench_section, conduit_dims, pl_length)


def add(q, k, v):
    if v:
        q[k] = q.get(k, 0.0) + v


def _paved_len(pts, polys):
    from shapely.geometry import LineString
    ls = LineString(pts)
    return sum(ls.intersection(p).length for p in polys)


def takeoff(item, d, sets_by_item=None):
    """q: {code: quantity}; SUB-* keys hold subcontract dollars."""
    sets_by_item = sets_by_item or {}
    q = {}
    if d.get("indoor"):
        return takeoff_indoor(item, d)
    size, sets = d.get("size_ug"), int(d.get("sets") or 1)
    g = geom.site()
    segs, structs = d["segments"], d.get("structures") or []
    ug_len = 0.0
    n_mh = 0
    riser_poles = 0
    for s in segs:
        m = s["method"]
        L = pl_length(s["pts"])
        if m == "OH":
            continue
        ug_len += L
        k = max(1, int(s.get("_k") or 1))

        def addk(code, v, _f=k):
            add(q, code, v / _f)
        n_d = max(1, int(s.get("rows") or 1) * int(s.get("cols") or 1)) if m != "DB" else 0
        dsz = int(s.get("duct_in") or 5)
        if m in ("CE", "UE", "DB"):
            od = MV_CABLE[size][0]
            ts = trench_section(s, od)
            addk("EX-TRCH" if m == "DB" else "EX-MACH", L if m == "DB" else ts["exc_sf"] * L / 27.0)
            addk("BF-COMP", (ts["exc_sf"] - ts["env_sf"] - ts["sand_sf"]) * L / 27.0)
            if ts["sand_sf"] > 0:
                addk("SAND-BED", ts["sand_sf"] * L / 27.0)
                addk("SAND", ts["sand_sf"] * L / 27.0)
            if m == "CE":
                _, od_c, _ = conduit_dims("CE", dsz)
                w_env, h_env = envelope_in(s)
                conc = (w_env * h_env - n_d * math.pi / 4 * od_c * od_c) / 144.0
                addk("CONC-PL", conc * L / 27.0)
                addk("CONC-3000", conc * L / 27.0)
                if str(s.get("reinforced", "")).upper().startswith("Y"):
                    bars = 4 if w_env <= 30 else 6
                    tie_ft = (2 * (w_env - 3) + 2 * (h_env - 3)) / 12.0
                    lb = bars * 0.668 * L + tie_ft * 0.376 * (math.floor(L / 3.0) + 1)
                    addk("REBAR", lb)
                    addk("REBAR-4", lb)
            if m in ("CE", "UE"):
                addk("DUCT-CE" if m == "CE" else "DUCT-UE", n_d * L)
                addk(f"{'EB20' if m == 'CE' else 'SCH40'}-{dsz}", n_d * L)
                addk("SPACER", n_d * (math.floor(L / 5.0) + 1))
                addk("GND-DB", L)
                addk("GND-4/0", L)
            addk("TAPE", L)
            addk("TAPE-DET", L)
            pl = _paved_len(s["pts"], g["may_cut"]) + _paved_len(s["pts"], g["no_cut"])
            if pl > 0:
                addk("PAVE-CUT", pl * (ts["top_w"] + 2.0) / 9.0)
                addk("ASPHALT", pl * (ts["top_w"] + 2.0) / 9.0)
            gw_len = 0.0
            for a, b in zip(s["pts"], s["pts"][1:]):
                mid = ((a[0] + b[0]) / 2, (a[1] + b[1]) / 2)
                gw = geom.groundwater_at(mid)
                if gw is not None and ts["depth"] > gw:
                    gw_len += math.dist(a, b)
            addk("DEWATER", gw_len)
            if (s.get("protective") or "") == "box" and ts["depth"] >= TRENCH["protective_depth_ft"]:
                addk("TBOX", L)
        elif m == "HDD":
            sc = SUBCONTRACTS["HDD"]
            nb = min([x for x in (2, 4, 6) if x >= n_d] or [6])
            cover = float(s.get("cover_in") or 0)
            footage = sc["per_lf"][nb] * L * (1 + (sc["deep_pct"] / 100.0 if cover > sc["deep_over_in"] else 0.0))
            addk("SUB-HDD", max(sc["min"], footage + sc["pits"]))
        elif m == "JB":
            sc = SUBCONTRACTS["JB"]
            addk("SUB-JB", sc["first_lf"] * L + sc["add_lf"] * (n_d - 1) * L + sc["pits"])
            addk(f"RGS-{dsz}", n_d * L)
        elif m == "JS":
            sc = SUBCONTRACTS["JS"]
            addk("SUB-JS", sc["casing_lf"] * L + sc["carrier_lf"] * n_d * L + sc["pits"])
            addk(f"RGS-{dsz}", n_d * L)
    for st in structs:
        kf = max(1, int(st.get("_k") or 1))

        def addk(code, v, _f=kf):
            add(q, code, v / _f)
        if st["kind"] == "MH":
            n_mh += 1
            addk("MH-SET", 1)
            addk("MH-PRECAST", 1)
            bw = MH_OUT[0] + 2 * TRENCH["manhole_clear_ft"]
            bl = MH_OUT[1] + 2 * TRENCH["manhole_clear_ft"]
            h = TRENCH["manhole_depth_ft"]
            sv = st.get("slope") if st.get("slope") is not None else st.get("slope_h_per_v")
            sl = float(sv or 0.0) if (st.get("protective") or "") == "slope" else 0.0
            tw, tl = bw + 2 * sl * h, bl + 2 * sl * h
            vol = h / 6.0 * (bw * bl + tw * tl + 4 * ((bw + tw) / 2) * ((bl + tl) / 2)) / 27.0
            base_cy = bw * bl * 0.5 / 27.0
            addk("EX-MACH", vol)
            addk("MH-BASE", base_cy)
            addk("ROCK-BASE", base_cy)
            addk("BF-COMP", vol - (MH_OUT[0] * MH_OUT[1] * h) / 27.0 - base_cy)
            gw = geom.groundwater_at((st["x"], st["y"]))
            if gw is not None and h > gw:
                addk("DEWATER", 25.0)
            if (st.get("protective") or "") == "box":
                addk("TBOX", 20.0)
        elif st["kind"] in ("POLE", "RISER_POLE"):
            hgt = int(st.get("height_ft") or 45)
            addk("POLE-SET", 1)
            addk(f"POLE-{50 if hgt >= 50 else 45}", 1)
            addk("POLE-HOLE", 1)
            xa = 2 if str(st.get("dead_end", "")).upper().startswith("Y") else 1
            addk("XARM", xa)
            addk("XARM-ASSY", xa)
            gy = int(st.get("guys") or 0)
            addk("GUY", gy)
            addk("GUY-ASSY", gy)
            if st["kind"] == "RISER_POLE":
                riser_poles += 1
                addk("RISER", sets)
                addk("RISER-ASSY", sets)
    oh_len = sum(pl_length(s["pts"]) for s in segs if s["method"] == "OH")
    if oh_len > 0 and d.get("size_oh"):
        add(q, "STRING", 3 * oh_len * 1.015)
        add(q, f"ACSR-{d['size_oh']}", 3 * oh_len * 1.015)
    if size and ug_len > 0:
        terminal_ends = int(segs[0]["method"] != "OH") + int(segs[-1]["method"] != "OH")
        circuit_ft = sets * (ug_len + n_mh * SLACK["per_manhole_ft"]
                             + terminal_ends * (SLACK["termination_ft"] + SLACK["riser_ft"])
                             + riser_poles * SLACK["riser_pole_ft"])
        db_circuit = sets * sum(pl_length(s["pts"]) for s in segs if s["method"] == "DB")
        code = "PULL-MV" if KCMIL[size] <= 211.6 else "PULL-MV-L"
        add(q, "DBC-LAY", min(db_circuit, circuit_ft))
        add(q, code, max(0.0, circuit_ft - db_circuit))
        add(q, f"CBL-{size}", 3 * circuit_ft)
        add(q, "TERM-MV", 3 * sets * terminal_ends)
        add(q, "TERM-KIT", 3 * sets * terminal_ends)
        splices = max(0, math.ceil(circuit_ft / sets / REEL_MAX_FT) - 1) * 3 * sets
        add(q, "SPLICE-MV", splices)
        add(q, "SPLICE-KIT", splices)
        add(q, "FIREPROOF", 3 * sets * 12.0 * n_mh)
        add(q, "FIRETAPE", 3 * sets * 12.0 * n_mh)
    return q


def wall_crossings(pts):
    from shapely.geometry import Point
    g = geom.site()
    rooms = {k: (v[0], v[3]) for k, v in INDOOR_ROOMS.items()}

    def room_of(q):
        for k, (poly, rating) in rooms.items():
            if poly.buffer(1e-6).contains(Point(q)):
                return k
        return None
    out, prev = [], None
    smp = geom.sample(pts, 0.5)
    prev = room_of(smp[0]) if smp else None
    for q in smp[1:]:
        r = room_of(q)
        if r is not None and prev is not None and r != prev:
            out.append(max(rooms[r][1], rooms[prev][1]))
        if r is not None:
            prev = r
    return out


INDOOR_ROOMS = {}


def _load_rooms():
    """A-501 MB-1 ceiling space schedule: room, available vertical space, fire rating"""
    import openpyxl
    wb = openpyxl.load_workbook(est.WS / "20_drawings/A-501_MB-1_Ceiling_Space_Schedule_Rev1.xlsx", data_only=True)
    from shapely.geometry import box
    for row in wb.worksheets[0].iter_rows(values_only=True):
        pass
    return wb


def takeoff_indoor(item, d):
    """RFP 3.7 'Building (C05)' row."""
    import openpyxl
    from shapely.geometry import box
    wb = openpyxl.load_workbook(est.WS / "20_drawings/A-501_MB-1_Ceiling_Space_Schedule_Rev1.xlsx", data_only=True)
    rooms = {}
    for row in wb.worksheets[0].iter_rows(min_row=1, values_only=True):
        if row[0] and str(row[0]).startswith(("ER-", "COR-", "MR-", "OF-", "IT-")):
            x0, y0, x1, y1 = float(row[1]), float(row[2]), float(row[3]), float(row[4])
            avail = float(row[6]) if row[6] is not None else 0.0
            rating = int(row[7]) if row[7] is not None else 0
            rooms[row[0]] = (box(x0, y0, x1, y1), rating, avail)
    q = {}
    size, sets = d.get("size_ug"), int(d.get("sets") or 1)
    pts = d["segments"][0]["pts"] if len(d["segments"]) == 1 else \
        [p for s in d["segments"] for p in s["pts"]]
    L = pl_length(pts)
    rise = 2 * 7.0                       # IEDS 5.1: 7 ft each end
    n_bends = sum(1 for i in range(1, len(pts) - 1)
                  if _defl(pts[i - 1], pts[i], pts[i + 1]) > 5.0)
    crossings = [r for r in _crossings(pts, rooms) if r >= 1]
    n_pbox = sum(1 for s in d.get("structures") or [] if s["kind"] == "PULLBOX")
    method = d["segments"][0]["method"]
    if method in ("RMC", "EMT"):
        code = "RMC-5" if method == "RMC" else "EMT-4"
        add(q, code, sets * (L + rise))
        add(q, "RGS-5" if method == "RMC" else "EMT-4IN", sets * (L + rise))
        add(q, "ELBOW-5", sets * (n_bends + 2))
        add(q, "ELBOW-RGS5", sets * (n_bends + 2))
        add(q, "FIRE-RMC", sets * len(crossings))
        add(q, "FIRESTOP-RMC5", sets * len(crossings))
    else:
        add(q, "TRAY-24", L)
        add(q, "TRAY-24-SB" if method == "TRAY-EN" else "TRAY-24-LD", L)
        if method == "TRAY-EN":
            add(q, "TRAY-COV", L)
            add(q, "TRAY-COV-24", L)
        add(q, "TRAY-BOND", L)
        add(q, "BOND-2", L)
        add(q, "RMC-5", sets * rise)
        add(q, "RGS-5", sets * rise)
        add(q, "ELBOW-5", sets * 2)
        add(q, "ELBOW-RGS5", sets * 2)
        if size:
            od = MV_CABLE[size][0]
            sleeve_id = est.CONDUIT_DIMS["RGS"][4][1]
            n_sl = math.ceil(3 * sets * math.pi / 4 * od * od / (40.0 / 100.0 * math.pi / 4 * sleeve_id ** 2))
            add(q, "FIRE-SLV", n_sl * sum(1 for r in crossings if r >= 2))
            add(q, "FIRE-SLV-4", n_sl * sum(1 for r in crossings if r >= 2))
            add(q, "FIRE-RMC", sets * sum(1 for r in crossings if r == 1))
            add(q, "FIRESTOP-RMC5", sets * sum(1 for r in crossings if r == 1))
    add(q, "PBOX", n_pbox)
    add(q, "PBOX-36", n_pbox)
    nb = math.ceil(L / 40.0) + math.ceil(L / 80.0)      # IEDS 5.3: transverse every 40 ft, longitudinal every 80 ft
    add(q, "SEISMIC", nb)
    add(q, "SEISMIC-BR", nb)
    if size:
        circuit_ft = sets * (L + rise + 2 * SLACK["termination_ft"])
        add(q, "PULL-IN", circuit_ft)
        add(q, f"CBL-{size}", 3 * circuit_ft)
        add(q, "TERM-IN", 6 * sets)
        add(q, "TERM-KIT", 6 * sets)
    return q


def _defl(a, b, c):
    v1 = (b[0] - a[0], b[1] - a[1])
    v2 = (c[0] - b[0], c[1] - b[1])
    n1, n2 = math.hypot(*v1), math.hypot(*v2)
    if n1 < 1e-9 or n2 < 1e-9:
        return 0.0
    cosang = max(-1.0, min(1.0, (v1[0] * v2[0] + v1[1] * v2[1]) / (n1 * n2)))
    return math.degrees(math.acos(cosang))


def _crossings(pts, rooms):
    from shapely.geometry import Point
    def room_of(q):
        for k, (poly, rating, _a) in rooms.items():
            if poly.buffer(1e-6).contains(Point(q)):
                return k
        return None
    out = []
    smp = geom.sample(pts, 0.5)
    prev = room_of(smp[0]) if smp else None
    for q in smp[1:]:
        r = room_of(q)
        if r is not None and prev is not None and r != prev:
            out.append(max(rooms[r][1], rooms[prev][1]))
        if r is not None:
            prev = r
    return out


def price_takeoff(q, size_oh=None):
    out = {"labor_mh": 0.0, "labor": 0.0, "equipment": 0.0, "material": 0.0, "subcontract": 0.0, "lines": {}}
    for code, qty in q.items():
        if code.startswith("SUB-"):
            out["subcontract"] += qty
            out["lines"][code] = {"sub": qty}
        elif code in est.LABOR_UNITS:
            size, lab, eq = est.crew_rates(est.LABOR_UNITS[code]["crew"])
            mh = qty * est.unit_mh(code, size_oh)
            out["labor_mh"] += mh
            out["labor"] += mh * lab
            out["equipment"] += mh / size * eq
            out["lines"][code] = {"mh": mh, "labor": mh * lab, "equipment": mh / size * eq}
        elif code in MATERIALS:
            c = est.material_cost(code, qty)
            out["material"] += c
            out["lines"][code] = {"material": c}
    out["direct"] = out["labor"] + out["equipment"] + out["material"] + out["subcontract"]
    return out
