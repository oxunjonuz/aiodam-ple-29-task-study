"""Build output/submission.zip: conveyance_study.xlsx (10 sheets, live formulas) + conveyance_study_report.md."""
from __future__ import annotations

import json
import math
import shutil
import zipfile
from pathlib import Path

import openpyxl
from openpyxl.styles import Font
from openpyxl.utils import get_column_letter

import est
import geom
import routes as RT
import takeoff as TK
from est import MV_CABLE, KCMIL, SC_KA_05S, pl_length

OUT = Path("/work/ple-solve/mv-conveyance-study/build")
CHOICE = {"C01": ("C01", "500", 2, 3), "C02": ("C02", "350", 2, 3), "C03": ("C03", "500", 1, 2),
          "C04": ("C04-OH", "250", 1, 2), "C05": ("C05", "350", 2, 3), "C06": ("C06", "250", 1, 2),
          "C07": ("C07", "250", 1, 2)}
PICKUP = {"C01": 640, "C02": 560, "C03": 400, "C04": 60, "C05": 200, "C06": 40, "C07": 120}
LF = {"C01": 100, "C02": 100, "C03": 75, "C04": 75, "C05": 75, "C06": 75, "C07": 75}
TYPES_SITE = ["CEDB", "UEDB", "DBC", "HDD", "OH"]
TYPES_IN = ["RMC", "EMT", "TRAY-EN", "TRAY-LD"]
ADM = {  # IEDS 4.1/4.2 + UFC 3-550-01 3-11: only concrete-encased ductbanks are permitted, and overhead only
        # outside the congested industrial area (C04, C06)
    "C01": {"CEDB": True, "UEDB": False, "DBC": False, "HDD": False, "OH": False},
    "C02": {"CEDB": True, "UEDB": False, "DBC": False, "HDD": False, "OH": False},
    "C03": {"CEDB": True, "UEDB": False, "DBC": False, "HDD": False, "OH": False},
    "C04": {"CEDB": True, "UEDB": False, "DBC": False, "HDD": False, "OH": True},
    "C05": {"RMC": True, "EMT": False, "TRAY-EN": False, "TRAY-LD": False},
    "C06": {"CEDB": True, "UEDB": False, "DBC": False, "HDD": False, "OH": True},
    "C07": {"CEDB": True, "UEDB": False, "DBC": False, "HDD": False, "OH": False},
}
CLAUSE = {
    ("CEDB", True): "IEDS Rev 3 4.2 and UFC 3-550-01 3-11.2.1 (UFGS 33 71 02 3.7.9): concrete-encased ductbank "
                    "between underground structures and equipment - permitted",
    ("UEDB", False): "IEDS Rev 3 4.2: conduit without concrete encasement is not permitted for the installation's "
                     "primary distribution (UFC 3-550-01 3-11.2.1; UFGS 33 71 02 3.7.9) - not permitted",
    ("DBC", False): "IEDS Rev 3 4.2: direct-buried cable is not permitted for the installation's primary "
                    "distribution (UFC 3-550-01 3-11.3.1) - not permitted",
    ("HDD", False): "UFC 3-550-01 3-11.4.1 with IEDS Rev 3 4.3: directional bores are used only for the listed "
                    "crossings (roads, parking lots, water bodies) and may not extend more than 50 ft beyond the "
                    "pavement edge, so a bore cannot be the predominant method of the run - not permitted",
    ("OH", False): "IEDS Rev 3 4.1 with UFC 3-550-01 3-11.1.1: overhead distribution is not permitted inside the "
                   "congested industrial area on C-101 or within the W-3 dock crane area, and the route cannot leave "
                   "it - not permitted",
    ("OH", True): "IEDS Rev 3 4.1 and 4.9 (UFC 3-550-01 3-10): overhead line outside the congested industrial area "
                  "with underground risers to pad-mounted equipment - permitted",
    ("RMC", True): "UFC 3-520-01 Table 3-1 with IEDS Rev 3 5.1 and UFGS 26 20 00 3.1.6: medium-voltage cable indoors "
                   "in rigid metal conduit, 6 in of required space against 14 in available - permitted",
    ("EMT", False): "UFGS 26 20 00 3.1.6.2 with UFC 3-520-01 Table 3-1: electrical metallic tubing is not permitted "
                    "for medium-voltage cable in this building - not permitted",
    ("TRAY-EN", False): "IEDS Rev 3 5.1 with A-501: a covered tray needs 6 in plus 12 in access headroom = 18 in, "
                        "but COR-1D has 14 in and MR-2 16 in available on every route to USS-A1 - not permitted",
    ("TRAY-LD", False): "IEDS Rev 3 5.1 with A-501: a ladder tray needs 18 in and COR-1D (14 in) and MR-2 (16 in) "
                        "are on every route from MSG-A to USS-A1 - not permitted",
}


# -------------------------------------------------------------------------------------------------- designs
def rec_design(item):
    key, size, sets, u = CHOICE[item]
    R = RT.routes()
    r = R[key]
    segs = []
    for s in r["segments"]:
        s = dict(s)
        if s["method"] in ("CE", "UE"):
            s["rows"], s["cols"], s["spare"] = 1, u, u - sets
            s.setdefault("duct_in", 5)
        elif s["method"] in ("HDD", "JB", "JS"):
            s["rows"], s["cols"], s["spare"] = 1, u, 0
        segs.append(s)
    return {"type": r["type"], "size_ug": size, "sets": sets,
            "size_oh": r.get("size_oh") if r["type"] == "OH" else None,
            "segments": segs, "structures": [dict(x) for x in r["structures"]], "indoor": item == "C05"}


def alt_design(item, typ):
    """a priced design of `typ` on the same corridor (used to price every type the study must evaluate)"""
    rec = rec_design(item)
    if typ == rec["type"]:
        return rec
    d = {"type": typ, "size_ug": rec["size_ug"], "sets": rec["sets"], "size_oh": rec.get("size_oh"),
         "structures": [dict(x) for x in rec["structures"]], "indoor": rec["indoor"]}
    if item == "C05":
        d["size_oh"] = None
        d["segments"] = [{"method": typ, "pts": rec["segments"][0]["pts"], "cover_in": None, "rows": None,
                          "cols": None, "duct_in": None, "spare": 0, "shared_with": None, "reinforced": "N",
                          "soil": None, "protective": "none", "slope_h_per_v": 0, "dewatering": "N"}]
        return d
    cover = {"CEDB": 18, "UEDB": 24, "DBC": 30, "HDD": 120, "OH": None}[typ]
    meth = {"CEDB": "CE", "UEDB": "UE", "DBC": "DB", "HDD": "HDD", "OH": "OH"}[typ]
    segs = []
    if typ == "OH":
        pts = [p for s in rec["segments"] for p in s["pts"]]
        d["size_oh"] = rec.get("size_oh") or "1/0"
        d["structures"] = [x for x in rec["structures"] if x["kind"] == "MH"]
        first, last = pts[0], pts[-1]
        mid1 = (first[0], first[1] + 60.0)
        mid2 = (last[0] - 60.0, last[1])
        segs.append({"method": "CE", "pts": [first, mid1], "cover_in": 18, "rows": 1, "cols": 2, "duct_in": 5,
                     "spare": 1, "reinforced": "N", "soil": None, "protective": "none", "slope_h_per_v": 0,
                     "dewatering": "N"})
        chain = [mid1]
        L = math.dist(mid1, mid2)
        n = max(1, math.ceil(L / 280.0))
        for i in range(1, n):
            t = i / n
            chain.append((mid1[0] + (mid2[0] - mid1[0]) * t, mid1[1] + (mid2[1] - mid1[1]) * t))
        chain.append(mid2)
        segs.append({"method": "OH", "pts": chain, "cover_in": None, "rows": None, "cols": None, "duct_in": None,
                     "spare": 0, "reinforced": "N", "soil": None, "protective": "none", "slope_h_per_v": 0,
                     "dewatering": "N"})
        segs.append({"method": "CE", "pts": [mid2, last], "cover_in": 18, "rows": 1, "cols": 2, "duct_in": 5,
                     "spare": 1, "reinforced": "N", "soil": None, "protective": "none", "slope_h_per_v": 0,
                     "dewatering": "N"})
        poles = []
        for i, q in enumerate(chain):
            riser = i in (0, len(chain) - 1)
            poles.append({"id": f"{'RP' if riser else 'P'}-{i:02d}", "kind": "RISER_POLE" if riser else "POLE",
                          "x": q[0], "y": q[1], "height_ft": 45, "guys": 1 if riser else 0,
                          "dead_end": "Y" if riser else "N", "protective": "none", "slope_h_per_v": 0})
        d["structures"] = d["structures"] + poles
        d["segments"] = segs
        return d
    for s in rec["segments"]:
        segs.append({"method": meth, "pts": s["pts"], "cover_in": cover, "rows": 1, "cols": rec["segments"][0].get("cols") or 2,
                     "duct_in": 5, "spare": rec["segments"][0].get("spare") or 1, "reinforced": "N",
                     "soil": s.get("soil"), "protective": "none", "slope_h_per_v": 0, "dewatering": s.get("dewatering", "N")})
    if typ == "HDD":
        pts = [p for s in rec["segments"] for p in s["pts"]]
        segs = [{"method": "HDD", "pts": pts, "cover_in": 120, "rows": 1, "cols": rec["segments"][0].get("cols") or 2,
                 "duct_in": 6, "spare": 0, "reinforced": "N", "soil": None, "protective": "none",
                 "slope_h_per_v": 0, "dewatering": "N"}]
        d["structures"] = []
    d["segments"] = segs
    return d


# -------------------------------------------------------------------------------------------------- priced table
def priced_all():
    designs = {it: rec_design(it) for it in CHOICE}
    sets_by = {k: v["sets"] for k, v in designs.items()}
    rec_q, rec_pr = {}, {}
    for it, d in designs.items():
        rec_q[it] = TK.takeoff(it, d, sets_by)
        rec_pr[it] = TK.price_takeoff(rec_q[it], d.get("size_oh"))
    subtotal = sum(rec_pr[it]["direct"] * est.premarkup_factor() for it in rec_pr)
    bond = est.bond_rate_for(subtotal)
    rows = []
    for it in CHOICE:
        types = TYPES_IN if it == "C05" else TYPES_SITE
        rec_type = designs[it]["type"]
        val = {}
        for t in types:
            d = alt_design(it, t)
            q = TK.takeoff(it, d, sets_by)
            pr = TK.price_takeoff(q, d.get("size_oh"))
            L = pl_length([p for s in d["segments"] for p in s["pts"]])
            val[t] = {"d": d, "q": q, "pr": pr, "L": L,
                      "tpc": est.rollup(pr["direct"], bond, L)["tpc"]}
        rec_tpc = val[rec_type]["tpc"]
        for t in types:
            v = val[t]
            rows.append({"item": it, "type": t, "admissible": ADM[it][t], "clause": CLAUSE[(t, ADM[it][t])],
                         "L": v["L"], "q": v["q"], "pr": v["pr"], "d": v["d"],
                         "recommended": "Y" if t == rec_type else "N", "tpc": v["tpc"]})
    return designs, rows, bond, rec_pr


def governing_ampacity(item, d):
    sets_by = {item: d["sets"]}
    import check as C
    a, w = C.route_ampacity(item, d)
    return a


# -------------------------------------------------------------------------------------------------- workbook
def build_workbook(designs, rows, bond, rec_pr):
    wb = openpyxl.Workbook()
    bold = Font(bold=True)
    ws = wb.active
    ws.title = "Items"
    ws.append(["item_id", "recommended_type", "cable_size", "sets", "overhead_conductor", "design_current_a",
               "ampacity_per_set_a", "route_length_ft", "total_project_cost_usd", "cost_per_lf_usd"])
    rec_row = {r["item"]: r for r in rows if r["recommended"] == "Y"}
    for it in CHOICE:
        d = designs[it]
        r = rec_row[it]
        L = r["L"]
        ws.append([it, d["type"], d["size_ug"], d["sets"], d["size_oh"] or "", PICKUP[it],
                   round(governing_ampacity(it, d), 1), round(L, 2), round(r["tpc"], 2),
                   round(r["tpc"] / L, 4)])

    ws = wb.create_sheet("Segments")
    ws.append(["item_id", "seg_no", "method", "route", "cover_in", "duct_rows", "duct_cols", "duct_size_in",
               "spare_ducts", "shared_with", "reinforced", "soil_type", "protective_system", "slope_h_per_v",
               "dewatering"])
    for it in CHOICE:
        for i, s in enumerate(designs[it]["segments"], start=1):
            route = "; ".join(f"{p[0]:.2f},{p[1]:.2f}" for p in s["pts"])
            ws.append([it, i, s["method"], route, ("" if s.get("cover_in") is None else s.get("cover_in")),
                       s.get("rows") or "", s.get("cols") or "", s.get("duct_in") or "",
                       (s.get("spare") if s["method"] in ("CE", "UE") else ""),
                       s.get("shared_with") or "", s.get("reinforced") or "N", s.get("soil") or "",
                       s.get("protective") or "none",
                       (s.get("slope_h_per_v") if (s.get("protective") or "") == "slope" else ""),
                       s.get("dewatering") or "N"])

    ws = wb.create_sheet("Structures")
    ws.append(["item_id", "structure_id", "kind", "x_ft", "y_ft", "pole_height_ft", "guys", "dead_end",
               "protective_system", "slope_h_per_v"])
    for it in CHOICE:
        for s in designs[it]["structures"]:
            ws.append([it, s["id"], s["kind"], s["x"], s["y"], s.get("height_ft") or "", s.get("guys") or "",
                       s.get("dead_end") or "N", s.get("protective") or "none",
                       (s.get("slope_h_per_v") if (s.get("protective") or "") == "slope" else "")])

    ws = wb.create_sheet("Pulls")
    ws.append(["item_id", "pull_id", "from_id", "to_id", "length_ft", "max_tension_lb",
               "max_sidewall_lb_per_ft", "jam_ratio", "fill_pct"])
    for r in pull_table(designs):
        ws.append([r["item_id"], r["pull_id"], r["from_id"], r["to_id"], round(r["length_ft"], 2),
                   round(r["max_tension_lb"], 1), round(r["max_sidewall_lb_per_ft"], 1),
                   round(r["jam_ratio"], 3) if r["jam_ratio"] else "", round(r["fill_pct"], 2) if r["fill_pct"] else ""])

    # ---- Alternatives with live formulas
    ws = wb.create_sheet("Alternatives")
    hdr = ["item_id", "type", "admissible", "governing_clause", "length_ft", "labor_mh", "labor_usd",
           "equipment_usd", "material_usd", "subcontract_usd", "direct_cost_usd", "jooh_usd", "hooh_usd",
           "profit_usd", "bond_usd", "escalation_usd", "contract_cost_usd", "contingency_usd", "sioh_usd",
           "total_project_cost_usd", "cost_per_lf_usd", "recommended"]
    ws.append(hdr)
    mk_row = {"jooh_pct": 2, "hooh_pct": 3, "profit_pct": 4, "bond_rate_pct": 5, "escalation_factor": 6,
              "contingency_pct": 7, "sioh_pct": 8}
    r = 2
    for x in rows:
        pr = x["pr"]
        ws.cell(row=r, column=1, value=x["item"])
        ws.cell(row=r, column=2, value=x["type"])
        ws.cell(row=r, column=3, value="Y" if x["admissible"] else "N")
        ws.cell(row=r, column=4, value=x["clause"])
        ws.cell(row=r, column=5, value=round(x["L"], 2))
        ws.cell(row=r, column=6, value=round(pr["labor_mh"], 3))
        ws.cell(row=r, column=7, value=round(pr["labor"], 2))
        ws.cell(row=r, column=8, value=round(pr["equipment"], 2))
        ws.cell(row=r, column=9, value=round(pr["material"], 2))
        ws.cell(row=r, column=10, value=round(pr["subcontract"], 2))
        f = r
        ws.cell(row=r, column=11, value=f"=G{f}+H{f}+I{f}+J{f}")
        ws.cell(row=r, column=12, value=f"=K{f}*Markups!$B${mk_row['jooh_pct']}/100")
        ws.cell(row=r, column=13, value=f"=(K{f}+L{f})*Markups!$B${mk_row['hooh_pct']}/100")
        ws.cell(row=r, column=14, value=f"=(K{f}+L{f}+M{f})*Markups!$B${mk_row['profit_pct']}/100")
        ws.cell(row=r, column=15, value=f"=(K{f}+L{f}+M{f}+N{f})*Markups!$B${mk_row['bond_rate_pct']}/100")
        ws.cell(row=r, column=16, value=f"=(K{f}+L{f}+M{f}+N{f}+O{f})*(Markups!$B${mk_row['escalation_factor']}-1)")
        ws.cell(row=r, column=17, value=f"=K{f}+L{f}+M{f}+N{f}+O{f}+P{f}")
        ws.cell(row=r, column=18, value=f"=Q{f}*Markups!$B${mk_row['contingency_pct']}/100")
        ws.cell(row=r, column=19, value=f"=(Q{f}+R{f})*Markups!$B${mk_row['sioh_pct']}/100")
        ws.cell(row=r, column=20, value=f"=Q{f}+R{f}+S{f}")
        ws.cell(row=r, column=21, value=f"=T{f}/E{f}")
        ws.cell(row=r, column=22, value=x["recommended"])
        r += 1

    # ---- Takeoff
    ws = wb.create_sheet("Takeoff")
    ws.append(["item_id", "type", "code", "quantity", "unit", "labor_mh", "labor_usd", "equipment_usd",
               "material_usd", "subcontract_usd"])
    for x in rows:
        for line in takeoff_lines(x["q"], x["pr"], x["d"].get("size_oh")):
            ws.append([x["item"], x["type"], line["code"], line["qty"], line["unit"], line["mh"], line["labor"],
                       line["equipment"], line["material"], line["subcontract"]])

    # ---- LaborRates (loaded_rate is a formula)
    ws = wb.create_sheet("LaborRates")
    ws.append(["class", "wd_group", "classification", "base_usd", "fringe_usd", "burden_pct", "loaded_rate_usd"])
    wd_group = {"LINEMAN": "ELEC1245-001", "EQSPEC": "ELEC1245-001", "GROUNDMAN": "ELEC1245-001",
                "ELECTRICIAN": "ELEC0011-004", "SPLICER_IN": "ELEC0011-004", "LAB1": "LABO0300-003",
                "LAB3": "LABO0300-003", "LAB4": "LABO0300-003", "PUMPOP": "ENGI0012-024"}
    title = {"LINEMAN": "LINE CONSTRUCTION: (1) LINEMAN; CABLE SPLICER",
             "EQSPEC": "LINE CONSTRUCTION: (2) EQUIPMENT SPECIALIST",
             "GROUNDMAN": "LINE CONSTRUCTION: (3) GROUNDMAN",
             "ELECTRICIAN": "ELECTRICIAN: INSIDE ELECTRICAL WORK: JOURNEYMAN ELECTRICIAN",
             "SPLICER_IN": "ELECTRICIAN: INSIDE ELECTRICAL WORK: CABLE SPLICER (5 % ADDITIONAL)",
             "LAB1": "LABORER GROUP 1", "LAB3": "LABORER GROUP 3",
             "LAB4": "LABORER GROUP 4 (PREFABRICATED MANHOLE INSTALLER)",
             "PUMPOP": "OPERATOR: POWER EQUIPMENT, ALL OTHER WORK: GROUP 1 (PUMP OPERATOR)"}
    r = 2
    for cls in ["LINEMAN", "EQSPEC", "GROUNDMAN", "ELECTRICIAN", "SPLICER_IN", "LAB1", "LAB3", "LAB4", "PUMPOP"]:
        w = est.WAGE[cls]
        pct = est.BURDEN["FICA"] + est.BURDEN["FUTA"] + est.BURDEN["CA_SUI"] + est.BURDEN["WC"][est.WC_CLASS[cls]]
        ws.append([cls, wd_group[cls], title[cls], w["base"], w["fringe"], round(pct, 4),
                   f"=D{r}*(1+F{r}/100)+E{r}"])
        r += 1

    ws = wb.create_sheet("EquipmentRates")
    ws.append(["equipment_id", "description", "source", "hourly_rate_usd"])
    desc = {"C10BO003": "Compactor, vibroplate, 14.2 x 22 in plate, 2,250 lb impact",
            "C80TE008": "Crane, hydraulic, truck mounted, rough terrain, 25 ton, 72 ft boom",
            "H25CA040": "Hydraulic excavator, crawler, 40,600 lb, 1.00 CY bucket",
            "L50CA001": "Loader / backhoe, wheel, 1.00 CY, 14.5 ft digging depth",
            "P50WC002": "Pump, water, centrifugal, trash, 3 in, 425 gpm",
            "T30DW022": "Trencher, chain type, 48 in depth, walk behind, crawler"}
    for eid in ("C10BO003", "C80TE008", "H25CA040", "L50CA001", "P50WC002", "T30DW022"):
        ws.append([eid, desc[eid], "EP 1110-1-8 Region VII (2016), fuel adjusted to FSI-0826-2207",
                   round(est.equipment_rate(eid), 2)])
    for rid, d in (("RQ-BDT", "Bucket / digger-derrick line truck, 47 ft, 4x4"),
                   ("RQ-PUL", "Cable puller, hydraulic capstan, 10,000 lb with dynamometer"),
                   ("RQ-TBX", "Trench shield (box), 8 ft x 20 ft, steel"),
                   ("RQ-LFT", "Scissor lift, 26 ft, electric (indoor)")):
        ws.append([rid, d, "Rental quote RQ-26-0419", round(est.RENTALS[rid], 2)])

    ws = wb.create_sheet("Markups")
    ws.append(["parameter", "value"])
    ws.append(["jooh_pct", est.MARKUP["JOOH"]])
    ws.append(["hooh_pct", est.MARKUP["HOOH"]])
    ws.append(["profit_pct", round(est.profit_pct(), 4)])
    ws.append(["bond_rate_pct", round(bond * 100, 6)])
    ws.append(["escalation_factor", round(est.escalation_factor(), 6)])
    ws.append(["contingency_pct", est.MARKUP["contingency"]])
    ws.append(["sioh_pct", est.MARKUP["SIOH"]])
    ws.append(["area_cost_factor_applied", 1])
    ws.append(["wage_determination", "CA20260022 Modification 5 (2026-08-06)"])

    ws = wb.create_sheet("Register")
    ws.append(["req_id", "document", "clause", "requirement", "value", "applies_to"])
    for row in REGISTER:
        ws.append(row)

    ws = wb.create_sheet("Findings")
    ws.append(["finding_id", "document", "location", "defect", "correction"])
    for row in FINDINGS:
        ws.append(row)

    for sh in wb.worksheets:
        for c in sh[1]:
            c.font = bold
        sh.freeze_panes = "A2"
    return wb


def takeoff_lines(q, pr, size_oh):
    out = []
    for code, qty in sorted(q.items()):
        if code.startswith("SUB-"):
            out.append({"code": code, "qty": round(qty, 2), "unit": "$", "mh": "", "labor": "",
                        "equipment": "", "material": "", "subcontract": round(qty, 2)})
            continue
        unit = est.LABOR_UNITS[code]["unit"] if code in est.LABOR_UNITS else (
            est.MATERIALS[code]["unit"] if code in est.MATERIALS else "EA")
        ln = pr["lines"].get(code, {})
        out.append({"code": code, "qty": round(qty, 3), "unit": unit,
                    "mh": round(ln.get("mh", 0.0), 4) if "mh" in ln else "",
                    "labor": round(ln.get("labor", 0.0), 2) if "labor" in ln else "",
                    "equipment": round(ln.get("equipment", 0.0), 2) if "equipment" in ln else "",
                    "material": round(ln.get("material", 0.0), 2) if "material" in ln else "",
                    "subcontract": ""})
    return out


def pull_table(designs):
    import check as C
    return C.pull_rows(designs)


# -------------------------------------------------------------------------------------------------- register
REGISTER = [
    ["R01", "UFC 3-550-01 (2016, Change 3)", "3-11.2.1", "Primary circuits between underground structures and "
     "equipment are concrete-encased ductbanks", "CEDB", "C01-C04, C06, C07"],
    ["R02", "UFC 3-550-01 (2016, Change 3)", "3-11.3.1", "Direct-buried wiring is not authorised for core "
     "distribution", "DBC not permitted", "C01-C04, C06, C07"],
    ["R03", "UFC 3-550-01 (2016, Change 3)", "3-11.4.1", "Directional bore only for the listed crossings, not "
     "solely on cost", "HDD for crossings only", "C01-C04, C06, C07"],
    ["R04", "UFC 3-550-01 (2016, Change 3)", "3-11.1.1", "Underground distribution in congested industrial areas; "
     "overhead not permitted there", "overhead excluded", "C01-C03, C07"],
    ["R05", "UFC 3-550-01 (2016, Change 3)", "3-11.2.2", "Type EB-20 ducts, spare capacity one third of the ducts, "
     "cover 24 in under pavement and 18 in in open ground", "18 in open / 24 in paved, spares 1/3", "C01-C04, C06, C07"],
    ["R06", "UFC 3-550-01 (2016, Change 3)", "3-11.6", "Underground structure locations and spacing: 400 ft, or "
     "600 ft where a pulling calculation is submitted for the pull", "400 / 600 ft", "C01-C04, C06, C07"],
    ["R07", "UFC 3-550-01 (2016, Change 3)", "3-11.5.5", "Air Force manhole distances: 50 ft from pavement and "
     "200 ft from fueling points", "50 and 200 ft", "C01-C04, C06, C07"],
    ["R08", "UFC 3-550-01 (2016, Change 3) Appendix B", "B-1.1", "Bore cover 120 in in open ground and 48 in under "
     "pavement, conduit fill 30 percent", "120 and 48 in", "C01, C02, C04, C07"],
    ["R09", "UFC 3-550-01 (2016, Change 3) Appendix B", "B-2.1", "Bores and jacked crossings are excluded from the "
     "governing ampacity where they are not more than 25 percent of the run", "25 percent", "C01, C02, C04, C07"],
    ["R10", "UFGS 33 71 02 (Underground Electrical Distribution)", "3.7.8.1", "Ductbank encasement under paving "
     "extends 5 ft beyond the paving edges and is reinforced", "5 ft", "C03, C04, C07"],
    ["R11", "UFGS 33 71 02 (Underground Electrical Distribution)", "3.7.4", "Conduits crossing the rail spur are "
     "jacked rigid galvanised steel where the crossing length is 50 ft or less", "50 ft", "C07"],
    ["R12", "UFGS 33 71 02 (Underground Electrical Distribution)", "3.7.9", "Ducts encased in concrete; burial "
     "depth and reinforcement", "concrete encasement", "C01-C04, C06, C07"],
    ["R13", "UFGS 33 71 02 with UFC 3-501-01", "3.3", "Pulling tension and sidewall bearing pressure calculations "
     "for every pull", "calculated", "C01-C05, C06, C07"],
    ["R14", "PCSFA-IEDS Installation Electrical Design Standard Rev 3", "1.3", "Order of precedence of the project "
     "documents", "IEDS first", "C01-C07"],
    ["R15", "PCSFA-IEDS Installation Electrical Design Standard Rev 3", "2.2", "Design current: the ampacity of the "
     "sets shall not be less than the phase pickup of the protective device", "pickup", "C01-C07"],
    ["R16", "PCSFA-IEDS Installation Electrical Design Standard Rev 3", "2.3", "Load factor 100 percent for F1 and "
     "F2 and 75 percent for all other feeders", "100 and 75 percent", "C01-C07"],
    ["R17", "PCSFA-IEDS Installation Electrical Design Standard Rev 3", "4.3", "No open cut of Mission Drive, "
     "Perimeter Road or the MB-1 access drive; bores not more than 50 ft beyond the pavement edge", "50 ft",
     "C01, C02, C04, C06, C07"],
    ["R18", "PCSFA-IEDS Installation Electrical Design Standard Rev 3", "4.4", "Bus A and bus B feeders do not "
     "share ductbanks and are at least 20 ft apart except within 50 ft of SS-1 or MB-1", "20 ft", "C01, C02, C03, C06"],
    ["R19", "PCSFA-IEDS Installation Electrical Design Standard Rev 3", "4.9", "Overhead line practice: maximum "
     "spans, pole class, guys and dead-ends, pole clearances", "span 300 ft", "C04, C06"],
    ["R20", "PCSFA-IEDS Installation Electrical Design Standard Rev 3", "4.10", "Underground structures per UFC "
     "3-550-01 3-11.5 and 3-11.6; changes of direction use 25 ft radius long-sweep bends", "25 ft radius",
     "C01-C04, C06, C07"],
    ["R21", "PCSFA-IEDS Installation Electrical Design Standard Rev 3", "4.12", "Excavations 5 ft or deeper require "
     "a protective system; soil classified from the nearest boring log", "5 ft", "C01-C04, C06, C07"],
    ["R22", "29 CFR 1926 Subpart P Appendix B", "Table B-1", "Maximum allowable slopes: 1.5:1 for Type C, 1:1 for "
     "Type B, 0.75:1 for Type A", "1.5:1", "C01-C04, C06, C07"],
    ["R23", "PCSFA-IEDS Installation Electrical Design Standard Rev 3", "4.13", "Existing utilities: 5 ft horizontal "
     "separation when parallel and 12 in vertical at crossings", "5 ft and 12 in", "C01-C04, C06, C07"],
    ["R24", "SUB-33 71 02-07 approved cable submittal (Cordillera Cable Co. letter 2026-08-14)", "2",
     "Maximum sidewall bearing pressure 600 lb/ft for the copper-tape-shielded construction", "600 lb/ft", "C01-C07"],
    ["R25", "Protective Device Settings Schedule E-PDS-001 Rev D (2026-06-30)", "Settings", "Feeder F1 phase "
     "pickup 640 A (increased for MB-1 Phase 2 load)", "640 A", "C01"],
    ["R26", "SUE-24-0117 Utility Survey (Quality Level B, test holes)", "Table 1", "W-12 water main top of pipe "
     "56 in below grade (record 72 in)", "56 in", "C01, C02, C04, C07"],
    ["R27", "UFC 3-520-01 (2025)", "Table 3-1", "Medium-voltage cable indoors in raceway or enclosed cable tray",
     "RMC", "C05"],
    ["R28", "UFGS 26 20 00 (Interior Electrical Distribution)", "3.1.8", "Cable tray stops 10 in from 2-hour walls "
     "with 4 in sleeves extending 12 in each side", "10 in, 4 in, 12 in", "C05"],
    ["R29", "UFGS 26 20 00 (Interior Electrical Distribution)", "3.1.6.2", "EMT is not permitted for medium-voltage "
     "cable", "EMT excluded", "C05"],
    ["R30", "PCSFA-IEDS Installation Electrical Design Standard Rev 3", "5.1", "Building distribution: required "
     "vertical space, penetrations and supports", "18 in tray / 6 in conduit", "C05"],
    ["R31", "29 CFR 1.6", "1.6(c)(2)(ii)(A)", "Wage determination modifications issued 10 days or more before bid "
     "opening govern", "10 days", "C01-C07"],
    ["R32", "EP 1110-1-8 (2021) Region VII", "3.9", "Equipment rates adjusted for fuel when the job-site fuel price "
     "differs by more than 10 percent", "10 percent", "C01-C07"],
    ["R33", "UFC 3-740-05 (2022, Change 1)", "11-2.1", "Profit by the weighted guidelines method (11-2.1 and 11-2.2)",
     "weighted guidelines", "C01-C07"],
    ["R34", "UFC 3-740-05 (2022, Change 1) with UFS 3-701-01 (2026)", "13-4", "Escalation to the midpoint of "
     "construction using the Table 4-2 factors", "Table 4-2", "C01-C07"],
    ["R35", "UFS 3-701-01 (2026)", "4-1.1", "The MILCON area cost factor is not applied to a detailed bottom-up "
     "take-off estimate", "ACF not applied", "C01-C07"],
    ["R36", "NAVFAC P-405 labor unit database (PCEC 2026)", "Table 4-1 note 5", "P-405 production efficiency 67 "
     "percent converted to the contractor's 80 percent", "67 and 80 percent", "C01-C07"],
    ["R37", "Section 01 11 00 Conveyance Study, Amendment 0002", "3.6", "Estimating basis: JOOH 9.5 percent, HOOH "
     "4.5 percent, SIOH 5.7 percent, design contingency 5 percent", "9.5, 4.5, 5.7", "C01-C07"],
    ["R38", "UFC 3-740-05 (2022, Change 1)", "13-3.2", "SIOH application", "5.7 percent", "C01-C07"],
    ["R39", "Section 01 11 00 Conveyance Study, Amendment 0002", "3.7", "Take-off conventions and the pairing of "
     "labor and material codes", "take-off per 3.7", "C01-C07"],
    ["R40", "PCSFA-IEDS Installation Electrical Design Standard Rev 3 with the settings schedule Rev D",
     "2.4", "Short-circuit withstand for the backup (breaker-failure) clearing time 0.5 s at the source bus fault "
     "current 16.5 kA (SS-1), 14.2 kA (SWG-C1), 15.8 kA (MSG-A)", "16.5, 14.2, 15.8 kA, 0.5 s", "C01-C07"],
    ["R41", "PCSFA-IEDS Installation Electrical Design Standard Rev 3 with the arborist tree survey TS-24-0117",
     "4.14", "Tree protection zone radius 1 ft per inch DBH; bores beneath a zone at not less than 48 in cover",
     "1 ft per inch, 48 in", "C01-C04, C06, C07"],
]

FINDINGS = [
    ["F-01", "Attachment J-3 Wage Determination CA20260022 as attached to the solicitation", "ELEC0011-004, "
     "Electrician inside electrical work, journeyman",
     "The attached wage determination is Modification 2 (01/30/2026: base 65.00 plus 3 percent plus fringe 35.62); "
     "Modification 5 was published 2026-08-06 with base 60.80 and fringe 31.59",
     "Used Modification 5 (60.80 + 31.59) because it was issued more than 10 days before the 2026-10-08 bid opening "
     "(29 CFR 1.6(c)(2)(ii)(A)); LaborRates and Markups wage_determination name CA20260022 Modification 5"],
    ["F-02", "Cable data sheet TD-15AL-133 Rev 3 against the approved submittal SUB-33 71 02-07 (Cordillera letter "
     "2026-08-14)", "TD-15AL-133 4.2 Maximum sidewall bearing pressure",
     "The catalogue states 1,000 lb/ft of bend radius; the project-specific letter limits the tape-shielded "
     "construction supplied to 600 lb/ft and supersedes the catalogue value",
     "Used 600 lb/ft for every bend, sweep and sheave in the pulling calculations and in the design check"],
    ["F-03", "Geotechnical report GEO-24-0117, Table 2 against boring logs B-07 and B-10", "Table 2 Summary of Soil "
     "Classification",
     "Table 2 classifies every boring as OSHA Type B, but B-7 is CL over SP (3-9 ft) over CL with groundwater at "
     "4.0 ft and B-10 is CL over SM (2-12 ft) with groundwater at 3.0 ft",
     "Classified per 29 CFR 1926 Subpart P Appendix A from the logs: B-7 and B-10 are Type C; excavations there use "
     "a 1.5:1 slope or a shield and are dewatered"],
    ["F-04", "C-101 Rev 4 general note 3 against SUE-24-0117 test holes TH-1 and TH-2", "UTIL-WATER W-12 top of pipe",
     "The drawing note gives top of pipe about 72 in; the SUE vacuum test holes measured 56 in, a 16 in difference",
     "Used 56 in (the SUE survey governs, IEDS 1.3(5)), and lowered every bore that crosses W-12 to 84 in cover"],
    ["F-05", "One-line diagram E-001 Rev B against the protective device settings schedule Rev D", "Feeder F1 relay "
     "51P phase pickup",
     "E-001 Rev B shows F1 phase pickup 560 A; the current settings schedule Rev D sets 640 A (raised for MB-1 "
     "Phase 2 load)",
     "Used 640 A (the current settings schedule governs, IEDS 1.3(4)); C01 is sized for 640 A, not 560 A"],
    ["F-06", "Government Estimate Template PCSFA FY26, Summary lines 2-3 (area cost factor 1.16, UFS 3-701-01 "
     "Table 4-1 LOS ANGELES AFB SITE # 1)", "Summary line 2 Area Cost Factor",
     "The template multiplies the bottom-up direct cost by the area cost factor 1.16 for a military construction "
     "location",
     "Not applied: UFS 3-701-01 4-1.1 prohibits the MILCON area cost factor on a detailed take-off; "
     "area_cost_factor_applied = 1 in Markups"],
    ["F-07", "Arborist tree survey TS-24-0117 against drawing C-101 Rev 4", "Retained tree T-208 (Jacaranda, DBH "
     "14 in) at (170,395)",
     "The tree survey lists T-208 as retained with a 14 ft protection zone, but C-101 Rev 4 does not show it",
     "Used the survey (it governs, IEDS 1.3(7)); the C06 route leaves SS-1 at x = 205 and clears T-208 by 35 ft"],
]


# -------------------------------------------------------------------------------------------------- report
def report_md(rows, designs):
    by = {}
    for x in rows:
        by.setdefault(x["item"], []).append(x)
    L = ["# Pacific Crest Space Force Annex - conveyance study, 13.8 kV site distribution",
         "", "Solicitation FA4610-26-R-0031, project PCSFA 24-0117. Study date 2026-09-15. "
         "Prepared from Section 01 11 00 Amendment 0002, PCSFA-IEDS Rev 3, the current drawings and surveys, the "
         "approved submittal and the cost documents.", "",
         "Estimating basis: direct cost from the take-off priced with wage determination CA20260022 Modification 5, "
         "the contractor labor-unit database, EP 1110-1-8 Region VII equipment rates adjusted for the job-site fuel "
         "price, the supplier and subcontract quotes indexed with PPI WPU102603 to August 2026 and 9.5 % sales tax; "
         "then JOOH 9.5 %, HOOH 4.5 %, weighted-guidelines profit 7.9494 %, bond per the 2026 Sierra Surety Class B "
         "schedule, escalation to the 2027-08-18 midpoint with UFS 3-701-01 Table 4-2, design contingency 5.0 % and "
         "SIOH 5.7 %. No area cost factor is applied (UFS 3-701-01 4-1.1).", "",
         "The tables below give, for every item, the labor hours and the cost per linear foot of every conveyance "
         "type the study evaluated, and the rates used.", ""]
    for it in CHOICE:
        xs = by[it]
        rec = [x for x in xs if x["recommended"] == "Y"][0]
        d = designs[it]
        L += [f"## {it} - {it_descr(it)}", "",
              f"Recommended conveyance: **{rec['type']}**. Route length {rec['L']:.0f} ft. Cable "
              f"{d['size_ug']} kcmil, {d['sets']} set(s)"
              + (f", overhead conductor ACSR {d['size_oh']}." if d.get("size_oh") else ".") +
              f" Design current {PICKUP[it]} A, ampacity of one set at the governing condition "
              f"{governing_ampacity(it, d):.0f} A. Total project cost ${rec['tpc']:,.0f}, "
              f"cost per linear foot ${rec['tpc']/rec['L']:,.2f}.", "",
              "| conveyance type | permitted | labor hours (MH) | cost per LF ($/ft) | total project cost ($) |",
              "|---|---|---|---|---|"]
        for x in xs:
            L.append(f"| {x['type']} | {'yes' if x['admissible'] else 'no'} | {x['pr']['labor_mh']:.1f} | "
                     f"{x['tpc']/x['L']:,.2f} | {x['tpc']:,.0f} |")
        L += ["", f"Rates used: labor ${rec['pr']['labor']/rec['pr']['labor_mh']:.2f} per man-hour (average loaded "
              f"rate of the crews of this item), equipment ${rec['pr']['equipment']/rec['pr']['labor_mh']:.2f} per "
              f"man-hour, material and subcontract as quoted. Direct cost ${rec['pr']['direct']:,.0f}.", ""]
        L += ["Route and design:", ""]
        for i, s in enumerate(d["segments"], start=1):
            pts = " - ".join(f"({p[0]:.0f},{p[1]:.0f})" for p in s["pts"])
            L.append(f"- segment {i}: {s['method']}, {pl_length(s['pts']):.0f} ft, {pts}"
                     + (f", cover {s.get('cover_in'):.0f} in, {s.get('cols')} ducts"
                        if s["method"] in ("CE", "UE", "HDD", "JB", "JS") else "")
                     + (", reinforced" if str(s.get("reinforced")).startswith("Y") else "")
                     + (", dewater" if str(s.get("dewatering")).startswith("Y") else ""))
        st = ", ".join(f"{s['id']} ({s['kind']}) at ({s['x']:.0f},{s['y']:.0f})" for s in d["structures"])
        if st:
            L.append(f"- structures: {st}")
        L.append("")
    L += ["## Errors found in the Government-furnished documents", "",
          "| id | document | defect | correction used |", "|---|---|---|---|"]
    for f in FINDINGS:
        L.append(f"| {f[0]} | {f[1]} - {f[2]} | {f[3]} | {f[4]} |")
    L.append("")
    return "\n".join(L)


DESCR = {"C01": "SS-1 feeder F1 to MB-1 MSG-A", "C02": "SS-1 feeder F2 to MB-1 MSG-B",
         "C03": "SS-1 feeder F3 to CUP-1 SWG-C1", "C04": "CUP-1 feeder CF-2 to the lift station TX-LS2",
         "C05": "MB-1 MSG-A feeder A-3 to USS-A1 (inside MB-1)", "C06": "SS-1 feeder F4 to the gate house TX-GH1",
         "C07": "CUP-1 feeder CF-1 to warehouse W-3"}


def it_descr(it):
    return DESCR[it]


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    designs, rows, bond, rec_pr = priced_all()
    wb = build_workbook(designs, rows, bond, rec_pr)
    xlsx = OUT / "conveyance_study.xlsx"
    wb.save(xlsx)
    rep = OUT / "conveyance_study_report.md"
    rep.write_text(report_md(rows, designs))
    zp = OUT / "submission.zip"
    with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
        z.write(xlsx, "conveyance_study.xlsx")
        z.write(rep, "conveyance_study_report.md")
    print(f"bond {bond*100:.4f}%  -> {zp} ({zp.stat().st_size} bytes)")
    for x in rows:
        if x["recommended"] == "Y":
            print(f"  {x['item']} {x['type']:9s} L {x['L']:7.1f} tpc {x['tpc']:10.0f} LB {est_lb(x['item']):9.0f} "
                  f"O {min(1.0, est_lb(x['item'])/x['tpc']):.3f}")


def est_lb(item):
    import check
    return check.LB[item]["tpc"]


if __name__ == "__main__":
    main()
