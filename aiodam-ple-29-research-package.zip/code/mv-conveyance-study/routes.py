"""Routes and designs, with the reason for each choice.

Geometry: C-101 Rev 4.  Method: PCSFA-IEDS Rev 3 4.1-4.14.  Cover: UFC 3-550-01 3-11.2.2 / UFGS 33 71 02 3.7.9.
Everything below is a *choice* (route, method, duct count, cable); all quantities and dollars come from takeoff.py.
"""
from __future__ import annotations

import math

import geom
from est import TRENCH, MV_CABLE
from takeoff import trench_section


def _soil(pts, method, cover, size="350"):
    s = {"method": method, "cover_in": cover, "rows": 1, "cols": 2, "duct_in": 5, "protective": "none", "slope_h_per_v": 0}
    ts = trench_section(s, MV_CABLE[size][0])
    worst = max((geom.osha_type(q, ts["depth"]) for q in geom.sample(pts, 5.0)), key=lambda t: "ABC".index(t))
    gw = any((geom.groundwater_at(q) is not None and ts["depth"] > geom.groundwater_at(q))
             for q in geom.sample(pts, 5.0))
    return ts, worst, gw


def ce(pts, cover, reinforced="N", duct=5):
    ts, soil, gw = _soil(pts, "CE", cover)
    slope = TRENCH["slope"][soil] if ts["depth"] >= TRENCH["protective_depth_ft"] else 0
    return {"method": "CE", "pts": pts, "cover_in": cover, "reinforced": reinforced, "soil": soil,
            "protective": "slope" if slope else "none", "slope_h_per_v": slope, "dewatering": "Y" if gw else "N",
            "duct_in": duct}


def hdd(pts, cover, duct=5):
    return {"method": "HDD", "pts": pts, "cover_in": cover, "reinforced": "N", "soil": None,
            "protective": "none", "slope_h_per_v": 0, "dewatering": "N", "duct_in": duct}


def jb(pts, cover, duct=5):
    return {"method": "JB", "pts": pts, "cover_in": cover, "reinforced": "N", "soil": None,
            "protective": "none", "slope_h_per_v": 0, "dewatering": "N", "duct_in": duct}


def oh(pts):
    return {"method": "OH", "pts": pts, "cover_in": None, "reinforced": "N", "soil": None,
            "protective": "none", "slope_h_per_v": 0, "dewatering": "N", "duct_in": None}


def mh(x, y):
    """precast manhole; the 8 ft pit is shielded rather than sloped open (29 CFR 1926.652(c))"""
    return {"id": None, "kind": "MH", "x": float(x), "y": float(y), "height_ft": None, "guys": 0, "dead_end": "N",
            "protective": "box", "slope_h_per_v": 0.0}


def pole(x, y, height=45, guys=0, dead_end="N", riser=False):
    return {"id": None, "kind": "RISER_POLE" if riser else "POLE", "x": float(x), "y": float(y), "height_ft": height,
            "guys": guys, "dead_end": dead_end, "protective": "none", "slope_h_per_v": 0.0}


def at_chainage(pts, s):
    """the point at distance s along a polyline (linear interpolation) - keeps manholes exactly on the route"""
    acc = 0.0
    for a, b in zip(pts, pts[1:]):
        d = math.dist(a, b)
        if acc + d >= s:
            t = (s - acc) / d if d else 0.0
            return (a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t)
        acc += d
    return pts[-1]


def _ids(structures):
    m = n = p = 0
    out = []
    for s in structures:
        s = dict(s)
        if s["kind"] == "MH":
            m += 1; s["id"] = f"MH-{m:02d}"
        elif s["kind"] == "RISER_POLE":
            p += 1; s["id"] = f"RP-{p:02d}"
        else:
            n += 1; s["id"] = f"P-{n:02d}"
        out.append(s)
    return out


def _finish(R):
    for k, r in R.items():
        r["structures"] = _ids(r["structures"])
    return R


# ------------------------------------------------------------------------------------------------------------------
def routes_c04_oh():
    """C04 as an overhead line.  IEDS 4.1 forbids overhead in the congested industrial area, so the riser pole
    stands at (1170,870), just outside the ADP boundary; the line runs below y = 880 until it is past x = 1560,
    crosses the channel overhead between poles outside the 25 ft buffer, and comes down east of it at (1700,1140).
    G-4 (gas, 36 in deep, 4.5 in OD) ends at x = 1150: the underground leg stays north of it until it is past
    the end of the main."""
    ug1 = [ce([(600, 1020), (750, 1035)], 24, reinforced="Y"),
           hdd([(750, 1035), (800, 1035)], 84),
           ce([(800, 1035), (1000, 1080), (1160, 930), (1170, 870)], 18)]
    line = [oh([(1170, 870), (1460, 873), (1568, 876), (1700, 920), (1700, 1140)])]
    ug2 = [ce([(1700, 1140), (1760, 1160)], 18)]
    pts_ug1 = [p for s in ug1 if s["method"] != "HDD" for p in s["pts"]]
    return {"type": "OH", "size_oh": "1/0", "segments": ug1 + line + ug2,
            "structures": [mh(1102.6, 984.1), mh(1727, 1151),
                           pole(1170, 870, 45, guys=1, dead_end="Y", riser=True),
                           pole(1460, 873, 45, guys=0), pole(1568, 876, 45, guys=1),
                           pole(1700, 920, 45, guys=2, dead_end="Y"),
                           pole(1700, 1140, 45, guys=1, dead_end="Y", riser=True)]}


def routes_c04_cedb():
    """C04 fully underground for comparison: bores at Mission Drive / W-12 and at the channel, three manholes."""
    return {"type": "CEDB", "size_oh": None,
            "segments": [ce([(600, 1020), (750, 1035)], 24, reinforced="Y"),
                         hdd([(750, 1035), (800, 1035)], 84),
                         ce([(800, 1035), (1000, 1080), (1155, 935), (1560, 1148)], 18),
                         hdd([(1560, 1148), (1700, 1155)], 120),
                         ce([(1700, 1155), (1760, 1160)], 18)],
            "structures": [mh(1000, 1080), mh(1400, 1125), mh(1730, 1157)]}


def routes():
    R = {}

    # ---------------- C01  SS-1 F1 -> MB-1 MSG-A.  Concrete-encased ductbank; the bore under Mission Drive must
    # pass under W-12 as well (SUE: top of pipe 56 in), so its cover is 84 in and its conduits are 6 in HDPE.
    # Route kept 23 ft clear of T-201 and 15 ft clear of T-207.  One manhole keeps both pulls under 600 ft.
    R["C01"] = {"type": "CEDB", "size_oh": None,
                "segments": [ce([(280, 640), (750, 715)], 18),
                             hdd([(750, 715), (800, 715)], 84, duct=6),
                             ce([(800, 715), (1100, 715)], 18)],
                "structures": [mh(850, 715)]}

    # ---------------- C02  SS-1 F2 -> MB-1 MSG-B.  T-2 (telecom ductbank, 30 in deep, 18 in wide) crosses the
    # whole site at y = 430 and a ductbank at 18 in cover passes 0.4 in under it, so the route goes round its west
    # end (x < 300) and stays south of it, crossing Mission Drive at y = 392 and entering the south wall from the
    # south.  Two manholes keep every pull inside 600 ft.
    R["C02"] = {"type": "CEDB", "size_oh": None,
                "segments": [ce([(280, 520), (280, 420)], 18),
                             ce([(280, 420), (750, 392)], 18),
                             hdd([(750, 392), (800, 392)], 84, duct=6),
                             ce([(800, 392), (1300, 392), (1300, 420)], 18)],
                "structures": [mh(578, 402), mh(1100, 392)]}

    # ---------------- C03  SS-1 F3 -> CUP-1 SWG-C1.  Crosses parking lot P-1 (may be saw-cut and patched,
    # IEDS 4.3): reinforced encasement at 24 in cover.  G-4 (gas, 36 in deep) runs along y = 920 right in front of
    # the CUP-1 south wall, so the last 70 ft is lowered to 56 in cover to pass 15 in under the gas main.
    R["C03"] = {"type": "CEDB", "size_oh": None,
                "segments": [ce([(240, 700), (330, 790), (470, 890)], 24, reinforced="Y"),
                             ce([(470, 890), (470, 960)], 56, reinforced="Y")],
                "structures": []}

    # ---------------- C04  CUP-1 -> lift station.  Recommended type chosen on cost (solve.py compares OH / CEDB).
    R["C04-OH"] = routes_c04_oh()
    R["C04-CEDB"] = routes_c04_cedb()

    # ---------------- C05  inside MB-1 : straight run through ER-A, the corridor, MR-2 and into MR-1, clear of the
    # SCIF keep-out (IEDS 5.1).  Two sets of 350 kcmil in 5 in rigid conduit: one set (350) is 195 A against the
    # 200 A pickup and 500 kcmil jams in a 5 in raceway (D/d = 3.08, TD-15AL-133 4.5).
    R["C05"] = {"type": "RMC", "size_oh": None,
                "segments": [{"method": "RMC", "pts": [(1130, 730), (1440, 640)], "cover_in": None,
                              "reinforced": "N", "soil": None, "protective": "none", "slope_h_per_v": 0,
                              "dewatering": "N", "duct_in": None}],
                "structures": []}

    # ---------------- C06  SS-1 F4 -> gate house.  Overhead outside the congested area (IEDS 4.1).  The line runs
    # from a riser pole south of SS-1 on a nearly straight diagonal to a riser pole 90 ft from GH-1, crossing
    # Mission Drive between two 50 ft poles.  A manhole within 100 ft of each riser pole (UFC 3-550-01 3-11.6).
    ohpts = [(205, 265), (500, 244.5), (745, 227.4), (815, 222.5), (1110, 202.0), (1405, 181.5),
                     (1700, 161.0), (1740, 160)]
    R["C06"] = {"type": "OH", "size_oh": "1/0",
                "segments": [ce([(180, 480), (205, 455), (205, 265)], 18),
                             oh(ohpts),
                             ce([(1740, 160), (1800, 130)], 18)],
                "structures": [mh(205, 320), mh(1770, 145),
                               pole(205, 265, 45, guys=1, dead_end="Y", riser=True),
                               pole(500, 244.5, 45), pole(745, 227.4, 50), pole(815, 222.5, 50),
                               pole(1110, 202.0, 45), pole(1405, 181.5, 45), pole(1700, 161.0, 45),
                               pole(1740, 160, 45, guys=1, dead_end="Y", riser=True)]}

    # ---------------- C07  CUP-1 -> warehouse W-3.  The rail spur RR-SPUR-2 is jacked (28.7 ft crossing -> jack
    # and bore, IEDS 4.5) at 42 in cover to keep 50 in under top of rail; Mission Drive is bored, again below
    # W-12.  Two manholes: one holds the spacing, one sits 50 ft off the pad (UFC 3-550-01 3-11.6).
    R["C07"] = {"type": "CEDB", "size_oh": None,
                "segments": [ce([(470, 1060), (470, 1080)], 18),
                             jb([(470, 1080), (470, 1120)], 42),
                             ce([(470, 1120), (750, 1136)], 18),
                             hdd([(750, 1136), (800, 1136)], 84, duct=6),
                             ce([(800, 1136), (1030, 1136), (1030, 1180)], 18)],
                "structures": [mh(990, 1136)]}
    return _finish(R)
