"""Independent check of the deliverable: change one thing at a time in MY OWN workbook and confirm the frozen
verifier notices.  A grader that keeps the same score would be reading nothing."""
import io, json, shutil, subprocess, sys, zipfile
from pathlib import Path
import openpyxl

ZIP = Path("/work/ple-solve/mv-conveyance-study/build/submission.zip")
GR = "/work/ple-dataset/tasks/mv-conveyance-study/tests/corrino/electrical_task12_conveyance_study/grading/verification/run_grade.py"


def grade(zp):
    out = Path("/tmp/mt.json")
    subprocess.run(["/work/venv-verifier/bin/python", GR, str(zp), "--metrics-out", str(out)],
                   capture_output=True, text=True, cwd=str(ZIP.parent))
    d = json.loads(out.read_text())
    return d["combined_score"], {k: v["failed"] for k, v in d["per_item"].items()}


def mutate(desc, fn, name):
    tmp = Path(f"/tmp/mut_{name}.zip")
    with zipfile.ZipFile(ZIP) as z:
        data = {n: z.read(n) for n in z.namelist()}
    wb = openpyxl.load_workbook(io.BytesIO(data["conveyance_study.xlsx"]))
    fn(wb)
    bio = io.BytesIO(); wb.save(bio)
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("conveyance_study.xlsx", bio.getvalue())
        z.writestr("conveyance_study_report.md", data["conveyance_study_report.md"])
    s, fails = grade(tmp)
    return s, fails


def drop_register(wb):
    ws = wb["Register"]
    for _ in range(6):
        ws.delete_rows(ws.max_row)


def cable_down(wb):
    ws = wb["Items"]
    for row in ws.iter_rows(min_row=2):
        if row[0].value == "C01":
            row[2].value = "250"


def takeoff_bump(wb):
    ws = wb["Takeoff"]
    for row in ws.iter_rows(min_row=2):
        if row[0].value == "C01" and row[2].value == "DUCT-CE":
            row[3].value = float(row[3].value) * 1.20
            return


def drop_finding(wb):
    ws = wb["Findings"]
    ws.delete_rows(6)      # F-06 area cost factor


def break_formula(wb):
    ws = wb["Alternatives"]
    for row in ws.iter_rows(min_row=2):
        if row[0].value == "C02" and row[21].value == "Y":
            row[19].value = 12345.0    # replace the total project cost formula with a constant
            return


print("baseline:", grade(ZIP)[0])
for name, desc, fn in (("reg", "drop 6 register rows", drop_register),
                       ("cable", "C01 cable 500 -> 250 kcmil", cable_down),
                       ("qty", "C01 DUCT-CE quantity +20 %", takeoff_bump),
                       ("find", "delete the area-cost-factor finding", drop_finding),
                       ("form", "C02 total project cost formula -> constant", break_formula)):
    s, fails = mutate(desc, fn, name)
    changed = {k: v for k, v in fails.items() if v}
    print(f"{name:6s} {desc:42s} score {s:.4f}  failures {changed}")
