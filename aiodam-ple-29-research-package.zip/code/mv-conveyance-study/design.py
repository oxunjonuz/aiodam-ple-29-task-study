"""Designs for the seven items: routes drawn on C-101, methods per IEDS 4.x, cover per UFC 3-550-01/UFGS 33 71 02.

Every choice is here with the reason it was made; the numbers are then computed by takeoff.py, never typed in.
"""
from __future__ import annotations

import math

import geom
from est import COVER_MIN, MV_CABLE

TERMINALS = {   # C-101 Rev 4 (duct stub-outs, wall entry zones, transformer pad centres)
    "SS1-F1": {"pt": (280.0, 640.0)}, "SS1-F2": {"pt": (280.0, 520.0)}, "SS1-F3": {"pt": (240.0, 700.0)},
    "SS1-F4": {"pt": (180.0, 480.0)},
    "MB1-ERA": {"wall": ((1100.0, 700.0), (1100.0, 760.0)), "side": "W"},
    "MB1-ERB": {"wall": ((1300.0, 420.0), (1360.0, 420.0)), "side": "S"},
    "CUP1-S": {"wall": ((440.0, 960.0), (500.0, 960.0)), "side": "S"},
    "CUP1-E": {"wall": ((600.0, 1000.0), (600.0, 1040.0)), "side": "E"},
    "CUP1-N": {"wall": ((440.0, 1060.0), (500.0, 1060.0)), "side": "N"},
    "TX-GH1": {"pt": (1800.0, 130.0)}, "TX-LS2": {"pt": (1760.0, 1160.0)}, "TX-W3": {"pt": (1030.0, 1180.0)},
}
ITEMS = {
    "C01": {"from": "SS1-F1", "to": "MB1-ERA", "pickup": 640, "lf": 100, "fault_bus": "SS-1"},
    "C02": {"from": "SS1-F2", "to": "MB1-ERB", "pickup": 560, "lf": 100, "fault_bus": "SS-1"},
    "C03": {"from": "SS1-F3", "to": "CUP1-S", "pickup": 400, "lf": 75, "fault_bus": "SS-1"},
    "C04": {"from": "CUP1-E", "to": "TX-LS2", "pickup": 60, "lf": 75, "fault_bus": "SWG-C1"},
    "C05": {"from": "MSG-A", "to": "USS-A1", "pickup": 200, "lf": 75, "fault_bus": "MSG-A"},
    "C06": {"from": "SS1-F4", "to": "TX-GH1", "pickup": 40, "lf": 75, "fault_bus": "SS-1"},
    "C07": {"from": "CUP1-N", "to": "TX-W3", "pickup": 120, "lf": 75, "fault_bus": "SWG-C1"},
}
FAULT_KA = {"SS-1": 16.5, "SWG-C1": 14.2, "MSG-A": 15.8}


def seg(method, pts, cover=None, rows=None, cols=None, duct=None, spare=None, reinforced="N", soil=None,
        protective="none", slope=None, dewater="N", shared=""):
    return {"method": method, "pts": [tuple(p) for p in pts], "cover_in": cover, "rows": rows, "cols": cols,
            "duct_in": duct, "spare": spare, "shared_with": shared, "reinforced": reinforced, "soil": soil,
            "protective": protective, "slope_h_per_v": slope, "dewatering": dewater}


def design(item, size, sets, units, routes):
    """units: number of ducts in the CE ductbank (rows x cols = 1 x units)"""
    r = routes[item]
    segs = []
    for s in r["segments"]:
        s = dict(s)
        if s["method"] in ("CE", "UE"):
            s["cols"] = units
            s["rows"] = 1
            s["duct_in"] = 5
            s["spare"] = units - sets
        if s["method"] in ("HDD", "JB", "JS"):
            s["cols"] = units
            s["rows"] = 1
            s["duct_in"] = 5
        segs.append(s)
    return {"type": r["type"], "size_ug": size, "sets": sets, "size_oh": r.get("size_oh") if r["type"] == "OH" else None,
            "segments": segs, "structures": r["structures"], "indoor": item == "C05", "item": item}
