"""Site geometry read from the drawings and surveys themselves (C-101 Rev 4, SUE-24-0117, TS-24-0117,
boring logs B-01..B-12) - no coordinates taken from anywhere else."""
from __future__ import annotations

import csv
import math
from functools import lru_cache

import ezdxf
from shapely.geometry import LineString, Point, Polygon, box

from est import WS


@lru_cache(maxsize=1)
def dxf_layers():
    doc = ezdxf.readfile(str(WS / "20_drawings/C-101_Site_Utility_Plan_Rev4.dxf"))
    out = {}
    for e in doc.modelspace():
        if e.dxftype() == "LWPOLYLINE":
            pts = [(float(p[0]), float(p[1])) for p in e.get_points("xy")]
            if e.closed:
                out.setdefault(e.dxf.layer, []).append(Polygon(pts))
        elif e.dxftype() == "LINE":
            a = (e.dxf.start.x, e.dxf.start.y)
            b = (e.dxf.end.x, e.dxf.end.y)
            out.setdefault(e.dxf.layer, []).append(LineString([a, b]))
    return out


PAVEMENT_KIND = {"PERIMETER-RD": ("road", False), "MISSION-DR": ("road", False), "MB1-DRIVE": ("road", False),
                 "P-1": ("parking", True), "CUP-YARD": ("paved yard", True)}
# order of the PAVEMENT polylines in C-101 (by their x-extent) -> which named area each one is
def _pavement():
    polys = [p for p in dxf_layers()["PAVEMENT"] if p.geom_type == "Polygon"]
    named = {}
    for p in polys:
        x0, y0, x1, y1 = p.bounds
        if y1 - y0 < 60 and x1 - x0 > 1500:
            named["PERIMETER-RD"] = p
        elif x1 - x0 < 60 and y1 - y0 > 500:
            named["MISSION-DR"] = p
        elif y1 - y0 < 40 and 100 < x1 - x0 < 400:
            named["MB1-DRIVE"] = p
        elif y0 > 700 and y1 < 950 and x1 - x0 > 300:
            named["P-1"] = p
        elif x0 > 590 and y0 > 900:
            named["CUP-YARD"] = p
    return named


@lru_cache(maxsize=1)
def site():
    L = dxf_layers()
    pav = _pavement()
    rail_lines = L["RAIL"]
    ys = sorted({round(l.coords[0][1], 1) for l in rail_lines if l.geom_type == "LineString" and l.length > 100})
    gauge = 4.708   # C-101 note: standard gauge 4.708 ft
    y_rail = sum(ys[:2]) / 2 if len(ys) >= 2 else 1100.0
    x0, x1 = 0.0, 1000.0
    for l in rail_lines:
        if l.geom_type == "LineString" and l.length > 100:
            x0 = min(x0, l.bounds[0]); x1 = max(x1, l.bounds[2])
    chan = [p for p in L["CHANNEL"] if p.geom_type == "Polygon"][0]
    g = {"buildings": {}, "pavement": {k: (v, *PAVEMENT_KIND[k]) for k, v in pav.items()},
         "rail": {"y": y_rail, "gauge": gauge, "x0": x0, "x1": x1},
         "channel": chan,
         "congested": [p for p in L["AREA-CONGESTED"] if p.geom_type == "Polygon"][0],
         "crane": [p for p in L["AREA-CRANE"] if p.geom_type == "Polygon"][0],
         "site": [p for p in L["SITE-BOUNDARY"] if p.geom_type == "Polygon"][0]}
    _BUILDING_CORNERS = {"SS-1": (80, 480), "MB-1": (1100, 420), "CUP-1": (420, 960), "W-3": (700, 1150),
                         "GH-1": (1830, 100), "LS-2": (1790, 1170)}
    for p in L["BLDG"]:
        x0b, y0b = p.bounds[0], p.bounds[1]
        nm = min(_BUILDING_CORNERS, key=lambda k: math.dist((x0b, y0b), _BUILDING_CORNERS[k]))
        g["buildings"][nm] = p
    g["no_cut"] = [v[0] for k, v in g["pavement"].items() if not v[2]]
    g["may_cut"] = [v[0] for k, v in g["pavement"].items() if v[2]]
    g["rail_zone"] = box(x0, y_rail - gauge / 2 - 12.0, x1, y_rail + gauge / 2 + 12.0)  # IEDS 4.5 / UFGS 33 71 02 3.7.4
    g["channel_buffer"] = chan.buffer(25.0, join_style=2)
    return g


@lru_cache(maxsize=1)
def trees():
    out = {}
    with open(WS / "20_drawings/site/TS-24-0117_Arborist_Tree_Survey.csv") as f:
        for r in csv.DictReader(f):
            out[r["tree_id"]] = {"x": float(r["x_ft"]), "y": float(r["y_ft"]), "dbh": float(r["dbh_in"]),
                                 "status": r["status"], "species": r["species"]}
    return out


def tree_zones():
    return {k: Point(v["x"], v["y"]).buffer(v["dbh"] * 1.0) for k, v in trees().items() if v["status"] == "retain"}


@lru_cache(maxsize=1)
def borings():
    """boring logs B-01..B-12 (Appendix A of GEO-24-0117) - rho from Table 3, groundwater and strata from the logs"""
    rho = {"B-1": 88, "B-2": 92, "B-3": 131, "B-4": 104, "B-5": 97, "B-6": 85, "B-7": 69, "B-8": 99,
           "B-9": 112, "B-10": 64, "B-11": 90, "B-12": 101}
    out = {}
    for k, v in rho.items():
        txt = (WS / f"30_geotech/boring_logs/B-{int(k[2:]):02d}.csv").read_text().splitlines()
        head = {}
        i = 0
        for i, line in enumerate(txt):
            if line.startswith("depth_top_ft"):
                break
            if "," in line:
                a, b = line.split(",", 1)
                head[a.strip()] = b.strip()
        rows = list(csv.DictReader(txt[i:]))
        gw_s = head.get("groundwater_depth_ft", "")
        gw = float(gw_s) if gw_s and gw_s[0].isdigit() else None
        layers = []
        for r in rows:
            ucs = float(r["pocket_pen_ucs_tsf"]) if r["pocket_pen_ucs_tsf"] not in ("", None) else None
            layers.append((float(r["depth_top_ft"]), float(r["depth_bottom_ft"]), r["USCS"], ucs))
        out[k] = {"x": float(head["x_ft"]), "y": float(head["y_ft"]), "rho": float(rho[k]), "gw": gw, "layers": layers}
    return out


def nearest_boring(q):
    b = borings()
    return min(b, key=lambda k: math.dist((b[k]["x"], b[k]["y"]), q))


def rho_at(q):
    return borings()[nearest_boring(q)]["rho"]


def groundwater_at(q):
    return borings()[nearest_boring(q)]["gw"]


def osha_type(q, depth_ft):
    """29 CFR 1926 Subpart P App. A: Type A UCS >= 1.5 tsf (never fill), B 0.5-1.5, C <= 0.5 tsf or granular or
    below groundwater; the least stable layer within the excavation depth governs."""
    b = borings()[nearest_boring(q)]
    order = {"A": 0, "B": 1, "C": 2}
    worst = "A"
    for top, bot, uscs, ucs in b["layers"]:
        if top >= depth_ft:
            continue
        granular = uscs.split()[0] in ("SP", "SM", "SW", "GP", "GW", "GM")
        if granular or ucs is None or ucs <= 0.5:
            t = "C"
        elif ucs >= 1.5 and "fill" not in uscs.lower():
            t = "A"
        else:
            t = "B"
        if b["gw"] is not None and depth_ft > b["gw"] and bot > b["gw"]:
            t = "C"
        worst = t if order[t] > order[worst] else worst
    return worst


@lru_cache(maxsize=1)
def utilities():
    """SUE-24-0117 Quality Level B designation + the QL-A test holes; SUE governs over the record depths on C-101
    (IEDS 1.3(5)).  Returns id -> (line, top-of-pipe depth in, outside diameter in)."""
    out = {}
    with open(WS / "20_drawings/survey/SUE-24-0117_Utility_Survey_QLB.csv") as f:
        rows = list(csv.DictReader(f))
    by = {}
    for r in rows:
        by.setdefault(r["utility_id"], []).append(r)
    for uid, rs in by.items():
        pts = [(float(r["x_ft"]), float(r["y_ft"])) for r in rs]
        # the CSVs give the designated points along each alignment; a point pair is enough for these straight runs
        depth = None
        for r in rs:
            if r.get("top_of_pipe_depth_in") not in ("", None):
                depth = float(r["top_of_pipe_depth_in"])
                break
        od = float(rs[0]["outside_diameter_in"])
        out[uid] = (LineString(pts), depth, od)
    # the record note on C-101 says W-12 top of pipe 72 in; the QL-A test holes measured 56 in -> SUE governs
    if "W-12" in out:
        out["W-12"] = (out["W-12"][0], 56.0, out["W-12"][2])
    return out


def sample(pts, step=5.0):
    out = []
    for i in range(len(pts) - 1):
        a, b = pts[i], pts[i + 1]
        n = max(1, int(math.dist(a, b) // step))
        for k in range(n + 1):
            out.append((a[0] + (b[0] - a[0]) * k / n, a[1] + (b[1] - a[1]) * k / n))
    return out


def rho_profile(pts):
    return [(q, rho_at(q)) for q in sample(pts, 10.0)]
