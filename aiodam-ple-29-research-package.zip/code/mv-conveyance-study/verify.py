import sys, json
sys.path.insert(0,"/work/ple-dataset/tasks/mv-conveyance-study/tests/corrino/electrical_task12_conveyance_study")
import check, est, takeoff as TK
from est import pl_length
from grading import evaluate as ev, model as m

CHOICE = {"C01": ("C01","500",2,3), "C02": ("C02","350",2,3), "C03": ("C03","500",1,2),
          "C04": ("C04-OH","250",1,2), "C05": ("C05","350",2,3), "C06": ("C06","250",1,2),
          "C07": ("C07","250",1,2)}

def built(choice=None):
    choice = choice or CHOICE
    return {it: check.make(it, key, size, sets, u) for it,(key,size,sets,u) in choice.items()}

def report(designs, rows=None, quiet=False):
    gd = check.to_grader(designs)
    rows = rows or {"Pulls": check.pull_rows(designs)}
    ev.annotate_shares(gd)
    cost, bond = check.costs(designs)
    tot = 0.0
    for it in designs:
        r = ev.evaluate_item(it, {"rows": rows}, gd)
        fails = [f for f, ok in r["families"].items() if not ok]
        tpc = cost[it]["rollup"]["tpc"]
        lb = check.LB[it]["tpc"]
        O = min(1.0, lb/tpc)
        hard = [f for f in fails if f in ev.HARD]
        score = 0.20*(1-len(fails)/len(ev.applicable(it)))**2 + 0.50*(0 if hard else 1)*O + 0.30*(0 if fails else 1)*O
        tot += score
        print(f"{it}: L {cost[it]['L']:7.1f} direct {cost[it]['pr']['direct']:9.0f} tpc {tpc:10.0f} LB {lb:9.0f} O {O:.3f}  hard_fail={hard}  other={[f for f in fails if f not in ev.HARD]}")
        for f in fails:
            print(f"     {f}: {r['notes'].get(f)}")
    print(f"bond {bond*100:.4f}%  mean item score {tot/len(designs):.4f}")
    return gd, cost, bond

if __name__ == "__main__":
    report(built())
