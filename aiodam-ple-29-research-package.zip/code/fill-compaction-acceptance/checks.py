#!/usr/bin/env python3
"""Deterministic reader for task `fill-compaction-acceptance` (Item 054).

Written from the 28 rubric criteria in tests/ce01-slab-on-grade-fill-compaction-acceptance-3d2c133e.json,
then run blind against the delivered record.  Exit 0 iff all 28 pass.
"""
import json
import re
import sys
import unicodedata
from pathlib import Path

RUB = Path("/work/ple-dataset/tasks/fill-compaction-acceptance/tests/"
           "ce01-slab-on-grade-fill-compaction-acceptance-3d2c133e.json")
DOC = "/work/ple-solve/fill-compaction-acceptance/output/Thelbridge_Materials_Acceptance_Fill_Compaction_2026-0708.docx"


def text_of(path):
    import docx
    d = docx.Document(path)
    parts = [p.text for p in d.paragraphs]
    for t in d.tables:
        for r in t.rows:
            parts.append(" | ".join(c.text for c in r.cells))
    s = "\n".join(parts)
    s = unicodedata.normalize("NFKC", s)
    return (s.replace("\u2019", "'").replace("\u201c", '"').replace("\u201d", '"')
             .replace("\u2013", "-").replace("\u2014", "-").replace("\u00a0", " "))


def win(text, anchor, size=520):
    out = []
    for m in re.finditer(anchor, text, re.I):
        out.append(text[max(0, m.start() - size): m.end() + size])
    return "\n...\n".join(out)


# index -> (short name, required patterns, forbidden patterns, window anchor)
SPEC = {
    0: ("D1557 on placed material yet to be performed",
        [r"D1557", r"yet to be performed", r"material (actually )?placed"], [], r"yet to be performed"),
    1: ("density floor and moisture window undetermined",
        [r"density floor", r"moisture window", r"undetermined", r"FD-14"], [], r"undetermined"),
    2: ("FD-14 to FD-17 rejected on the record",
        [r"FD-14", r"rejected"], [], r"rejected"),
    3: ("new D1557 required before evaluation",
        [r"D1557", r"required before|before .{0,40}can be evaluated|cannot be accepted against a valid"],
        [], r"cannot be accepted against a valid|cannot be evaluated"),
    4: ("Item 012 closed 09/22/2025", [r"Item 012", r"closed", r"09/22/2025"], [], r"Item 012"),
    5: ("Item 012 scope is Larchwood Pit only",
        [r"Item 012", r"scope", r"Larchwood Pit"], [], r"Item 012"),
    6: ("RFI 079 stocked reuse subject to gradation retest",
        [r"RFI 079", r"gradation retest", r"north of Block C"], [], r"RFI 079"),
    7: ("RFI 079 retest outstanding", [r"RFI 079", r"retest", r"outstanding"], [], r"RFI 079"),
    8: ("2.1.D per source and per material change",
        [r"2\.1\.D", r"source", r"material change", r"prior to placement"], [], r"2\.1\.D"),
    9: ("1.4.C and 3.4.D denominators from placed material",
        [r"1\.4\.C", r"3\.4\.D", r"material actually placed"], [], r"3\.4\.D"),
    10: ("VMT-25-0918-P04 is Larchwood Pit, different source",
         [r"VMT-25-0918-P04", r"Larchwood Pit", r"(different|rather than).{0,80}(Block C|stockpile)"],
         [], r"VMT-25-0918-P04"),
    11: ("SF-26-0708 to be reissued against new D1557",
         [r"SF-26-0708", r"reissued", r"D1557", r"material actually placed"], [], r"reissued"),
    12: ("lift non-conforming under Article 3.7.C",
         [r"3\.7\.C", r"non-conforming"], [], r"3\.7\.C"),
    13: ("1.2.A.1 D698 historical only",
         [r"1\.2\.A\.1", r"D698", r"historical"], [], r"1\.2\.A\.1"),
    14: ("1.2.A.2 D1557 governing",
         [r"1\.2\.A\.2", r"D1557", r"governing"], [], r"1\.2\.A\.2"),
    15: ("118.6 pcf D698 on Phase 1 Wexford Ridge borrow",
         [r"118\.6", r"D698", r"Wexford Ridge"], [], r"Wexford Ridge"),
    16: ("SF-26-0708 stated 95 % density only",
         [r"SF-26-0708", r"95 percent|95 %", r"density"], [], r"95 percent"),
    17: ("SF-26-0708 dispositioned all four PASS",
         [r"PASS", r"(all )?four"], [], r"PASS"),
    18: ("3.4.B requires both density and moisture",
         [r"3\.4\.B", r"both", r"moisture"], [], r"3\.4\.B"),
    19: ("Item 054 remains open", [r"Item 054", r"(remains )?open"], [], r"Item 054"),
    20: ("fill drawn from stockpile north of Block C",
         [r"stockpile north of Block C"], [], r"stockpile north of Block C"),
    21: ("frequency satisfied on each lift",
         [r"frequenc", r"3\.7\.A\.1|5,000 sf", r"satisf"], [], r"frequenc"),
    22: ("subgrade proof-rolled and accepted in writing first",
         [r"proof-roll", r"accepted", r"06/18/2026"], [], r"proof-roll"),
    23: ("construction only after new D1557 and acceptance",
         [r"construction over", r"only after|should not proceed until", r"D1557", r"3\.4\.B"], [],
         r"may proceed only after|should not proceed"),
    24: ("file name", [], [], None),
    25: ("template structure", [], [], None),
    26: ("Item 054 outstanding at 07/20/2026",
         [r"Item 054", r"07/20/2026", r"outstanding"], [], r"07/20/2026"),
    27: ("IBC continuous special inspection; 07:15-11:30 does not satisfy",
         [r"continuous special inspection", r"1705\.6", r"07:15", r"11:30", r"does not"], [], r"1705\.6"),
}


def main(argv):
    path = argv[1] if len(argv) > 1 else DOC
    text = text_of(path)
    crit = json.load(open(RUB))["rubrics"]
    fails = []
    print(f"reader on {Path(path).name} ({len(text)} chars), {len(crit)} criteria\n")
    for i, (name, req, forb, anchor) in SPEC.items():
        if i == 24:
            ok = Path(path).name == "Thelbridge_Materials_Acceptance_Fill_Compaction_2026-0708.docx"
            detail = Path(path).name
        elif i == 25:
            heads = ["PURPOSE", "DOCUMENTS REVIEWED", "BASIS OF REVIEW", "FINDINGS",
                     "CONCLUSION AND RECOMMENDATION"]
            ok = all(re.search(h, text) for h in heads) and all(k in text for k in ("To:", "From:", "Date:", "Subject:"))
            detail = "5 sections + header block" if ok else "missing section or header field"
        else:
            scope = win(text, anchor) if anchor else text
            missing = [p for p in req if not re.search(p, scope, re.I)]
            bad = [p for p in forb if re.search(p, scope, re.I)]
            ok = not missing and not bad
            detail = ("missing: " + "; ".join(missing[:3])) if missing else ("forbidden: " + "; ".join(bad)) if bad else "present"
        w = crit[i]["weight"]
        print(f"  [{'PASS' if ok else 'FAIL'}] {i:2d} w={w:<4} {name} — {detail}")
        if not ok:
            fails.append(i)
    # consistency checks of our own (not rubric items): the verdict line and the numbers it rests on
    cons = []
    det = re.search(r"Determination:\s*([A-Z]+)", text)
    cons.append(("C1 verdict line reads REJECTED",
                 bool(det) and det.group(1) == "REJECTED", det.group(0) if det else "no Determination: line"))
    cons.append(("C2 governing gamma_d,max 128.4 stated with D1557",
                 bool(re.search(r"128\.4", text)) and bool(re.search(r"D1557", text)) and not re.search(r"118\.6 pcf.*D1557", text),
                 "128.4 present" if re.search(r"128\.4", text) else "128.4 missing"))
    cons.append(("C3 moisture window 8.2-11.2 stated",
                 bool(re.search(r"8\.2 to 11\.2|8\.2.{0,20}11\.2", text)), "window"))
    cons.append(("C4 pad area 11,400 sf stated", bool(re.search(r"11,400", text)), "pad area"))
    for name, ok, detail in cons:
        print(f"  [{'PASS' if ok else 'FAIL'}] --  {name} — {detail}")
        if not ok:
            fails.append(name)
    weight = sum(crit[i]["weight"] for i in fails if isinstance(i, int))
    print(f"\nFAILURES: {len(fails)} criteria (weight {weight} of 108) {fails if fails else ''}")
    return 0 if not fails else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv))
