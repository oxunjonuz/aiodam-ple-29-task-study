#!/usr/bin/env python3
"""Independent checks for the Item 054 record: (a) every number/date traceable to the corpus or to arithmetic on it,
(b) mutations of the delivered docx that the reader must catch."""
import re
import subprocess
import sys
import unicodedata
from pathlib import Path

import docx

import checks

CORPUS = Path("/work/fca/txt")
PY = "/work/venv-verifier/bin/python"
CHECKS = "/work/ple-solve/fill-compaction-acceptance/checks.py"
MUT = Path("/work/ple-solve/fill-compaction-acceptance/mut")

DERIVED = {
    "122.0": "95 % of 128.4 pcf (Proctor VMT-25-0918-P04)",
    "8.2": "wopt 9.2 % minus 1 % (Article 3.4.B)",
    "11.2": "wopt 9.2 % plus 2 % (Article 3.4.B)",
    "97.2": "124.8 / 128.4 (FD-14)",
    "96.2": "123.5 / 128.4 (FD-15)",
    "95.7": "122.9 / 128.4 (FD-16)",
    "98.2": "126.1 / 128.4 (FD-17)",
    "3": "ceil(11,400 sf / 5,000 sf) = 3 tests per lift (Article 3.7.A.1)",
}
OWN = {"07/16/2026": "the record's own date (template Date: field)"}


def corpus_blob():
    parts = []
    for p in CORPUS.glob("*.txt"):
        parts.append(unicodedata.normalize("NFKC", p.read_text(errors="replace")))
    return "\n".join(parts)


def audit():
    text = checks.text_of(checks.DOC)
    blob = corpus_blob()
    nums = set(re.findall(r"\d[\d,]*\.?\d*", blob))
    nums = {n.replace(",", "") for n in nums}
    bad = []
    for m in re.finditer(r"(\d[\d,]*(?:\.\d+)?)\s*(sf|pcf|percent|%|tests?|in|ft|lifts?)?", text):
        v, unit = m.group(1).replace(",", ""), m.group(2)
        if not unit:
            continue
        ok = v in nums or v in DERIVED or v.rstrip("0").rstrip(".") in nums
        if not ok:
            bad.append((v, unit, text[max(0, m.start() - 45):m.end() + 25].replace("\n", " ")))
    dates = sorted(set(re.findall(r"\b\d{2}/\d{2}/\d{4}\b", text)))
    dmiss = [d for d in dates if d not in blob and d not in OWN]
    print(f"(a) numbers with a unit: {len(re.findall(r'[0-9]', text))} chars of digits; untraceable: {len(bad)}")
    for v, u, c in bad:
        print(f"    !! {v} {u} …{c}…")
    print(f"    dates: {len(dates)}, not in corpus and not declared: {dmiss or 'none'}")
    print("    arithmetic:", end=" ")
    assert round(0.95 * 128.4, 1) == 122.0
    assert round(9.2 - 1, 1) == 8.2 and round(9.2 + 2, 1) == 11.2
    assert (124.8 / 128.4, 123.5 / 128.4, 122.9 / 128.4, 126.1 / 128.4) == (0.9719626, 0.9619937, 0.9571651, 0.9820872) or True
    for rho, exp in [(124.8, 97.2), (123.5, 96.2), (122.9, 95.7), (126.1, 98.2)]:
        assert round(rho / 128.4 * 100, 1) == exp, (rho, exp)
    print("FD ratios recompute to the stated percentages; 95 % floor = 122.0 pcf")
    return 0 if (not bad and not dmiss) else 1


MUTANTS = [
    ("M01", r"128\.4", "118.6", "the governing maximum dry density"),
    ("M02", r"8\.2 to 11\.2", "7.0 to 11.0", "the moisture window"),
    ("M03", r"Determination: REJECTED", "Determination: ACCEPTED", "the determination"),
    ("M04", r"RFI 079", "RFI 065", "which RFI approved the stockpile"),
    ("M05", r"Wexford Ridge", "Larchwood Pit", "which borrow the D698 curve is from"),
    ("M06", r"continuous special inspection", "periodic special inspection",
     "whether special inspection is continuous"),
    ("M07", r"07/20/2026", "07/30/2026", "the register due date"),
    ("M08", r"3\.7\.C", r"3\.4\.C", "the non-conforming-work article"),
    ("M09", r"09/22/2025", "09/30/2025", "the Item 012 closure date"),
    ("M10", r"11,400", "11,900", "the pad area"),
]


def mutate(src, dst, pat, rep):
    d = docx.Document(str(src)); n = 0

    def do(par):
        nonlocal n
        for r in par.runs:
            new, k = re.subn(pat, rep, r.text)
            if k:
                r.text = new; n += k
    for p in d.paragraphs:
        do(p)
    for t in d.tables:
        for row in t.rows:
            for c in row.cells:
                for p in c.paragraphs:
                    do(p)
    d.save(str(dst)); return n


def mutations():
    MUT.mkdir(exist_ok=True)
    base = subprocess.run([PY, CHECKS], capture_output=True, text=True)
    if base.returncode != 0:
        print("(b) baseline not green"); print(base.stdout[-600:]); return 2
    print("(b) baseline green; mutations:")
    surv = []
    for mid, pat, rep, what in MUTANTS:
        dst = MUT / f"{mid}.docx"
        k = mutate(checks.DOC, dst, pat, rep)
        r = subprocess.run([PY, CHECKS, str(dst)], capture_output=True, text=True)
        failed = re.findall(r"\[FAIL\]\s+(\d+)", r.stdout)
        # #24 is the file name, which every mutant copy necessarily changes; it cannot carry a mutation verdict
        cons = re.findall(r"\[FAIL\] --  (C\d)", r.stdout)
        substantive = [f for f in failed if f != "24"] + cons
        caught = bool(substantive)
        print(f"    {'CAUGHT  ' if caught else 'SURVIVED'} {mid} ({what}, {k}x) -> {','.join('#'+f for f in substantive) or '—'}")
        if not caught:
            surv.append(mid)
    print(f"    {len(MUTANTS)-len(surv)}/{len(MUTANTS)} caught; survivors: {surv or 'none'}")
    return 0 if not surv else 1


if __name__ == "__main__":
    if "--mut" in sys.argv:
        sys.exit(mutations())
    sys.exit(audit())
