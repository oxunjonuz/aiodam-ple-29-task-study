#!/usr/bin/env python3
"""Materials Acceptance Record for Verification Register Item 054 (Block A slab-on-grade fill, Lift 6).

Sources, each quoted or computed from a file in environment/files (Birchwood/PackageA/...):
  Spec 31 20 00 Rev.3   1.2.A.1 / 1.2.A.2 / 1.4.C / 1.5.B.1 / 1.6.A-B / 2.1.A-D / 3.3 / 3.4.A-C
  SF-26-0708            Field_Density_Report_SF-26-0708.pdf  (D698 reference, 118.6 pcf / 12.1 %)
  Proctor VMT-25-0918-P04   Proctor_D1557_PackageA_Structural_Fill.pdf (128.4 pcf / 9.2 %, Larchwood Pit)
  Placement log         Fill_Placement_Records_BlockA_SlabOnGrade.xlsx (11,400 sf, 6 lifts, Block C stockpile)
  Register              Thelbridge_Verification_Register_PkgA.xlsx (Items 012, 054, schedule)
  RFI log               RFI_Log_PackageA.xlsx (RFI 065 frequency; RFI 079 stockpile reuse; RFI 125 open)
  Geotech report        Geotechnical_Investigation_Report_PkgA_Rev2.pdf §9.5 (95 % D1557, -1 %/+2 % window)
"""
import os
from docx import Document
from docx.shared import Pt, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH

OUT = "/work/ple-solve/fill-compaction-acceptance/output"
os.makedirs(OUT, exist_ok=True)
PATH = os.path.join(OUT, "Thelbridge_Materials_Acceptance_Fill_Compaction_2026-0708.docx")

GAMMA_D1557 = 128.4
WOPT = 9.2
FLOOR = round(0.95 * GAMMA_D1557, 1)          # 122.0 pcf
WLO, WHI = round(WOPT - 1.0, 1), round(WOPT + 2.0, 1)   # 8.2 / 11.2 %
TESTS = [("FD-14", 124.8, 6.1), ("FD-15", 123.5, 9.8), ("FD-16", 122.9, 10.4), ("FD-17", 126.1, 5.8)]
PAD_SF = 11400
REQ_TESTS = -(-PAD_SF // 5000)                 # one per 5,000 sf per lift -> 3


def p(doc, text, size=10.5, bold=False, italic=False, after=5, indent=None, style=None):
    par = doc.add_paragraph(style=style)
    r = par.add_run(text); r.font.size = Pt(size); r.bold = bold; r.italic = italic
    par.paragraph_format.space_after = Pt(after)
    if indent is not None:
        par.paragraph_format.left_indent = Inches(indent)
    return par


doc = Document()
sec = doc.sections[0]
sec.left_margin = sec.right_margin = Inches(1.0)
sec.top_margin = sec.bottom_margin = Inches(0.8)
doc.styles["Normal"].font.name = "Calibri"
doc.styles["Normal"].font.size = Pt(10.5)

p(doc, "THELBRIDGE PROJECT MANAGEMENT SERVICES", size=13, bold=True, after=0)
p(doc, "500 South High Street, Suite 720, Columbus, OH 43215  |  (614) 555-0125  |  thelbridgepm.com", size=8.5, after=8)
p(doc, "MATERIALS ACCEPTANCE RECORD", size=12, bold=True, after=8)

for label, value in [
    ("To:", "Adrian Vance, P.E. — Project Engineer (Structural/Geotechnical), Owner's Representative"),
    ("From:", "Karen Tarbray — Materials / QA Reviewer, Thelbridge Project Management Services"),
    ("Copy:", "Rachel Marlbeck, Thornbury State University — Office of Capital Programs; "
              "Rahul Nimkar, Geotechnical Reviewer, Thelbridge"),
    ("Date:", "July 16, 2026"),
    ("Subject:", "Verification Register Item 054 — Block A slab-on-grade structural fill, Lift 6: acceptance of "
                 "field density tests FD-14 through FD-17 (Vantree Report SF-26-0708) under Specification "
                 "Section 31 20 00, Earth Moving"),
]:
    par = doc.add_paragraph()
    r1 = par.add_run(label); r1.bold = True; r1.font.size = Pt(10)
    r2 = par.add_run(" " + value); r2.font.size = Pt(10)
    par.paragraph_format.space_after = Pt(2)

p(doc, "", size=6, after=2)

# ---------------------------------------------------------------- 1 purpose
p(doc, "1.  PURPOSE", size=11, bold=True, after=3)
p(doc, "This record closes out the technical review of Verification Register Item 054, which asks Thelbridge to "
       "accept or reject the slab-on-grade fill compaction tests FD-14 through FD-17 taken in the Block A "
       "slab-on-grade structural fill on 07/08/2026 and reported in Vantree Field Density Report SF-26-0708 "
       "issued 07/09/2026. The determination is on the density and moisture test results, and on whether the "
       "testing and the record behind it support acceptance of the lift under Specification Section 31 20 00. "
       f"Lift 6 is the upper 8 in loose of a 3.6 ft, six-lift structural fill pad of {PAD_SF:,} sf placed between "
       "06/22/2026 and 07/08/2026, on which the capillary break and the Block A slab-on-grade are next to be built.")

# ---------------------------------------------------------------- 2 documents
p(doc, "2.  DOCUMENTS REVIEWED", size=11, bold=True, after=3)
for d in [
    "Vantree Materials Testing, Field Density Test Report SF-26-0708, tested 07/08/2026, issued 07/09/2026 "
    "(In-Place Density and Moisture, ASTM D6938).",
    "Vantree Materials Testing, Laboratory Compaction Characteristics of Soil — Modified Proctor, Report "
    "VMT-25-0918-P04, dated 09/18/2025 (ASTM D1557-12(2021), Method C).",
    "Vantree Materials Testing, Report VMT-2024-0403-P1B dated 04/03/2024 — the ASTM D698 Method A curve of "
    "record named in SF-26-0708.",
    "Rowan Bay Constructors, Fill Placement and Grading Records — Block A Slab-on-Grade, Record RB-FPR-BA-2026, "
    "period 06/22/2026 – 07/08/2026, signed 07/09/2026.",
    "Specification Section 31 20 00 — Earth Moving, Rev.3 issued 03/06/2026 (supersedes Rev.2 of 11/14/2025).",
    "Thelbridge Review Comment and Verification Register — Package A, updated 07/15/2026 (Items 012 and 054; "
    "Schedule).",
    "Package A RFI Log (RFI 065 of 09/16/2025, RFI 079 of 10/06/2025, RFI 125 of 07/08/2026).",
    "Geotechnical Investigation Report — Package A, KGI-2024-0417 Rev.2, Section 9.5.",
]:
    p(doc, "•  " + d, size=10, after=2, indent=0.2)

# ---------------------------------------------------------------- 3 basis
p(doc, "3.  BASIS OF REVIEW", size=11, bold=True, after=3)
p(doc, "Article 3.4.B of Section 31 20 00 Rev.3 sets a dual criterion that must be satisfied at each test "
       f"location: dry density not less than 95 percent of the maximum dry density determined by ASTM D1557 "
       f"Method C for the placed material, and moisture content within −1 percent to +2 percent of the optimum "
       "moisture content determined by the same test. Article 1.2.A.2 names ASTM D1557 as the governing "
       "laboratory reference for Package A structural fill, and Article 1.2.A.1 states that ASTM D698 is cited "
       "for historical borrow characterization only and is not the acceptance basis. Article 2.1.D requires the "
       "laboratory maximum dry density and optimum moisture content for each source and each material change to "
       "be determined by ASTM D1557 Method C prior to placement, and Article 1.4.C — Placed-Material "
       "Correspondence — requires the denominators used for any test location to be those determined on the "
       "material actually placed at that location, and Article 3.4.D — Interpretation — forbids accepting any test "
       "location on density alone or on moisture alone and requires both criteria to be measured against the D1557 "
       "Method C values of the material actually placed at that location; with a new D1557 Method C test where the placed material "
       "differs materially from the previously characterized borrow. Article 1.5.B.1 requires each field density "
       "report to identify the D1557 maximum dry density and optimum moisture content used as denominators, the "
       "percent compaction, and the moisture deviation from optimum. Article 3.4.B fixes field density testing "
       f"at one test per 5,000 sf per lift, which on this {PAD_SF:,} sf pad is {REQ_TESTS} tests per lift. "
       "Article 3.4.C requires rework and retest of any location that fails either criterion. The Geotechnical "
       "Investigation Report, Section 9.5, states the same basis independently: compaction to 95 percent of the "
       "ASTM D1557 maximum dry density with a moisture window from −1 percent to +2 percent of the modified "
       "Proctor optimum, both to be satisfied for acceptance.")

# ---------------------------------------------------------------- 4 findings
p(doc, "4.  FINDINGS", size=11, bold=True, after=3)
F = [
    ("SF-26-0708 computes percent compaction against a standard Proctor, not a modified Proctor. Section 3 of "
     "the report names the reference method as ASTM D698 Method A, maximum dry density 118.6 pcf, optimum "
     "moisture content 12.1 percent, curve of record VMT-2024-0403-P1B dated 04/03/2024 — which is the Phase 1 "
     "Wexford Ridge borrow determination, a reddish-brown silty clay of low plasticity, and not a determination on "
     "the Block A structural fill material at all. Under Article 1.2.A.1 "
     "that standard is historical only and is not the acceptance basis for Package A structural fill. The "
     "percentages reported in Section 5 of SF-26-0708 — 105.2, 104.1, 103.6 and 106.3 percent — are therefore "
     "computed on a denominator that does not govern."),
    ("SF-26-0708 states the specification requirement as a density floor only. Section 4 of the report reads: "
     "\"minimum in-place dry density of the compacted fill shall be not less than 95 percent of the maximum dry "
     "density determined by the reference Proctor.\" Article 3.4.B requires both the density floor and the "
     "moisture window, and Article 1.5.B.1 requires the report to state the moisture deviation from optimum. "
     "The report states neither, and its Section 6 disposition of all four locations as PASS rests on the "
     "density floor alone."),
    ("The only ASTM D1557 Method C result on the project record for Package A structural fill was performed on a "
     "different borrow source. Report VMT-25-0918-P04 records the sample as LWP-PA-SF-2025-01, borrow source "
     "Larchwood Pit — Package A structural fill, sampled 09/10/2025, with γd,max 128.4 pcf and wopt 9.2 percent "
     "by Method C. That report was run on Larchwood Pit material, a different source from the stockpile north of "
     "Block C that was actually placed here; the material in this pad came from the stockpile north of Block C, approved "
     "for reuse under RFI 079 and identified as the borrow source on the placement record (note 4 of "
     "RB-FPR-BA-2026). Under Article 1.4.C the denominators for these test locations must be those determined "
     "on the material actually placed, and where the placed material differs materially from the characterized "
     "borrow a new D1557 Method C test is required before further fill placement is accepted. No D1557 Method C "
     "determination on the Block C stockpile material appears anywhere on the record."),
    ("The ASTM D1557 Method C determination that Article 3.4.B requires for test locations FD-14 through FD-17 "
     "has yet to be performed on the material placed there, and for that reason both the density floor and the "
     "moisture window of Article 3.4.B remain undetermined for those locations on the project record as it "
     "stands. No percent compaction and no moisture deviation on the record is measured against the material "
     "actually placed. Until an ASTM D1557 Method C determination on the material actually placed is obtained, "
     "FD-14 through FD-17 cannot be accepted against a valid denominator, and the lift cannot be released."),
    ("The contractor's own placement record applies the Larchwood Pit proctor to this pad. Note 5 of "
     "RB-FPR-BA-2026 carries VMT-25-0918-P04, ASTM D1557 Method C, γd,max 128.4 pcf, wopt 9.2 percent, as the "
     "governing laboratory proctor, and the cover sheet names the same report as the governing proctor "
     "reference and Article 3.4.B as the compaction acceptance basis. The laboratory's report SF-26-0708 was "
     "therefore not issued against the basis the Contractor's own record declares, which is an internal "
     "inconsistency in the record as well as a specification breach."),
    ("Verification Register Item 012 does not cover the material placed here. Item 012, raised 09/18/2025 and "
     "closed 09/22/2025 against the reference \"Proctor D1557 — Package A Structural Fill\", records acceptance "
     "of the modified Proctor result for the Larchwood Pit borrow identified in VMT-25-0918-P04. Its scope is "
     "the characterization of that borrow; it does not extend to the Block C stockpile and cannot be relied on "
     "to establish the basis for FD-14 through FD-17."),
    ("The material placed under RFI 079 has not been qualified as RFI 079 requires. RFI 079 (10/06/2025) "
     "approved the stockpile north of Block C for reuse subject to a gradation retest, reference letter "
     "TPM-25-079, closed 10/10/2025. No gradation retest of the stockpile material appears on the record. "
     "Without it the placed material's conformance to Article 2.1.B — no more than 12 percent passing the "
     "No. 200 sieve, plasticity index not exceeding 6 — and its correspondence to the characterized borrow are "
     "both unverified."),
    ("Screened against the best available modified-Proctor basis, the density criterion is met at all four "
     f"locations but the moisture criterion is not. Taking γd,max 128.4 pcf (95 percent = {FLOOR} pcf) and "
     f"wopt 9.2 percent (window {WLO} to {WHI} percent): FD-14 124.8 pcf = 97.2 percent and 6.1 percent "
     "moisture; FD-15 123.5 pcf = 96.2 percent and 9.8 percent; FD-16 122.9 pcf = 95.7 percent and 10.4 "
     "percent; FD-17 126.1 pcf = 98.2 percent and 5.8 percent. Density satisfies the floor everywhere. Moisture "
     "is below the lower limit at FD-14 (6.1 against 8.2) and at FD-17 (5.8 against 8.2), so two of the four "
     "locations fail the moisture criterion on that basis, and FD-15 and FD-16 satisfy both criteria. This is a "
     "screening and not an acceptance: the basis used for it was not established on the material actually "
     "placed, as Finding 3 records."),
    ("The moisture question is already open on the record. RFI 125, raised 07/08/2026 by the Contractor — "
     "interpretation of the moisture criterion on field density report SF-26-0708 — is carried open with the "
     "response pending and no disposition by Thelbridge or Kelbrook. Nothing in the record since closes it."),
    ("Testing frequency is satisfied and the lift-by-lift sequence is documented. Article 3.4.B and Article "
     f"3.7.A.1 require one test per 5,000 sf per lift and not fewer than {REQ_TESTS} tests per lift regardless of "
     f"lift area, hence {REQ_TESTS} per lift over the {PAD_SF:,} sf pad; SF-26-0708 provides "
     "four (FD-14 to FD-17) and lifts 1 through 5 are covered by FDR-BA-01 to FDR-BA-05 at three tests per "
     "lift. Article 3.3.A limits lifts to 12 in loose and the log records 8 in loose throughout. Article 3.4.A "
     "required a witnessed test strip, and the log records one executed 06/19/2026 establishing six coverage "
     "passes, which the log shows was met or exceeded on every lift. The frequency answer given in RFI 065 "
     "(09/16/2025, one test per 500 sf per lift) was given before Rev.3 of the section was issued on "
     "03/06/2026 and does not state the governing frequency."),
    ("Subgrade acceptance under Article 1.6.A and 3.1.A is documented. The placement record shows the subgrade "
     "stripped and proof-rolled at El. 745.0 on 06/18/2026 with a loaded tandem-axle dump truck in the presence "
     "of Vantree Materials Testing, and it was accepted in writing by Thelbridge before the first lift was placed; "
     "fill placement began 06/22/2026 on that subgrade."),
    ("The record does not show the special inspection the adopted building code requires for this work. The "
     "project's governing building code is the Ohio Building Code, 2024 edition, adopting the 2021 "
     "International Building Code (Design Basis Memorandum Rev.2; Specification Section 03 20 00 Article 1.2). "
     "IBC 2021 Section 1705.6 and Table 1705.6 require special inspection of soils, including verification of "
     "the placement of controlled fill and of in-place density, and specify continuous special inspection for "
     "fill placement. The record contains no statement of special inspections for the fill, no continuous "
     "special-inspection log, and no inspector's daily report of fill placement; it contains only the "
     "Laboratory's periodic density visits — on 07/08/2026 an 07:15 to 11:30 attendance by a single field "
     "technician for four tests. Vantree's services as the Owner's independent testing laboratory under Article "
     "1.4.A do not by themselves discharge a special inspection obligation that the code places on the "
     "statement of special inspections."),
    ("The scope of the defect is not confined to Lift 6. Lifts 1 through 5 were accepted lift-by-lift under "
     "FDR-BA-01 through FDR-BA-05. If those reports were computed on the same ASTM D698 basis as SF-26-0708 — "
     "and the record does not show otherwise — then the same denominator defect runs through the whole pad, "
     "and the earlier lifts were accepted on a basis that does not govern either. The reports themselves have "
     "not been produced with this item and must be reviewed."),
]
for i, txt in enumerate(F, 1):
    par = doc.add_paragraph(style="List Number")
    r = par.add_run(txt); r.font.size = Pt(10)
    par.paragraph_format.space_after = Pt(3)

# ---------------------------------------------------------------- 5 conclusion
p(doc, "5.  CONCLUSION AND RECOMMENDATION", size=11, bold=True, after=3)
p(doc, "Determination: REJECTED. Tests FD-14 through FD-17 in Vantree Field Density Report SF-26-0708 are "
       "rejected on the project record as it stands, and the Lift 6 fill they represent is not accepted under "
       "Specification Section 31 20 00 Article 3.4.B. The report is computed against an ASTM D698 standard "
       "Proctor that Article 1.2.A.1 excludes as an acceptance basis, it states and applies only the density "
       "floor and omits the moisture window entirely, and the modified Proctor that does govern on the record "
       "was run on Larchwood Pit borrow rather than on the Block C stockpile material actually placed. No ASTM "
       "D1557 Method C determination exists on the material placed in this pad, and the gradation retest that "
       "RFI 079 made a condition of reusing that stockpile is still outstanding. The lift covered by SF-26-0708 is "
       "therefore non-conforming under Specification Section 31 20 00 Article 3.7.C, which requires rework of any "
       "lift for which the ASTM D1557 Method C denominators used in reporting do not correspond to the material "
       "actually placed, before any additional lift is placed.")
p(doc, "Before the lift can be accepted, and before the capillary break and slab-on-grade are built over it, the "
       "following must be in hand:", after=3)
for txt in [
    "A new ASTM D1557 Method C determination — maximum dry density and optimum moisture content — on the "
    "stockpile-north-of-Block-C material actually placed, performed by Vantree as the Owner's laboratory, "
    "reported with its own report number and sealed (Contractor to request; Vantree to perform; Thelbridge to "
    "review).",
    "The gradation retest of the stockpile material required by RFI 079 and letter TPM-25-079, demonstrating "
    "conformance to Article 2.1.B (Rowan Bay to produce; Thelbridge to review).",
    "Field Density Report SF-26-0708 reissued against the new ASTM D1557 Method C determination on the material "
    "actually placed, stating for each location the D1557 maximum dry density and optimum moisture content used as "
    "denominators, the percent compaction and the moisture deviation from optimum, as Article 1.5.B.1 and Article "
    "3.7.B require (Vantree to issue).",
    "Rework and retest of any location that fails either criterion against the new basis, and a closing "
    "disposition of RFI 125 on the moisture interpretation (Contractor to rework and request retest; Vantree to "
    "retest; Thelbridge to accept).",
    "A statement of special inspections for the fill and the continuous special-inspection record the adopted "
    "building code requires for fill placement, or a written determination by the EOR that the requirement is "
    "otherwise satisfied (Contractor and EOR to produce; Thelbridge to review).",
    "Review of FDR-BA-01 through FDR-BA-05 for Lifts 1 through 5 against the same new basis, since the defect "
    "identified here is not confined to Lift 6 (Thelbridge Materials/QA to review on receipt).",
]:
    par = doc.add_paragraph(style="List Bullet")
    r = par.add_run(txt); r.font.size = Pt(10)
    par.paragraph_format.space_after = Pt(2)

p(doc, "Verification Register Item 054 is not closed by this record. It remains open, and it remains outstanding "
       "at its 07/20/2026 due date, because none of the items above is on the record and the new Proctor alone "
       "cannot be produced and reviewed in the time remaining. Construction over the Block A slab-on-grade fill — "
       "including the capillary break and the slab itself, and any hold-point release that depends on this item — "
       "may proceed only after a new ASTM D1557 Method C determination on the material actually placed is obtained "
       "and the fill is accepted under Specification Section 31 20 00 Article 3.4.B on that basis.",
  after=8)

p(doc, "", size=8, after=2)
p(doc, "Karen Tarbray", size=10.5, bold=True, after=0)
p(doc, "Materials / QA Reviewer", size=9.5, after=0)
p(doc, "Thelbridge Project Management Services — Owner's Representative", size=9.5, after=0)
p(doc, "Date: July 16, 2026", size=9.5, after=8)
p(doc, "Attachments on file: SF-26-0708; VMT-25-0918-P04; RB-FPR-BA-2026; Specification Section 31 20 00 Rev.3; "
       "RFI Log Package A.", size=8.5, italic=True, after=0)

doc.save(PATH)
print("wrote", PATH, os.path.getsize(PATH), "bytes")
print("basis:", GAMMA_D1557, WOPT, "floor", FLOOR, "window", WLO, WHI, "req_tests", REQ_TESTS)
for tid, rho, w in TESTS:
    print(f"  {tid}: {rho} pcf = {rho/GAMMA_D1557*100:.1f}%  moisture {w}%  "
          f"density {'OK' if rho >= FLOOR else 'FAIL'}  moisture {'OK' if WLO <= w <= WHI else 'FAIL'}")
