#!/usr/bin/env python3
"""Results ledger: bind every measured score to the exact submission file that is on disk NOW.

For each checks / checks-judge task it records:
  - the submission artifact path, size, sha256, mtime (read off the disk this run),
  - every result file that holds a measurement, with its numbers and mtime,
  - the binding evidence: the candidate path recorded in the result's own adapter_config
    (if the run kept one), and whether the submission mtime is BEFORE the result mtime
    (a result older than the file it claims to score is stale by construction).

Nothing is taken from memory; a task with no result file is reported as such.
"""
import hashlib
import json
import os
import sys
from pathlib import Path

SOLVE = Path("/work/ple-solve")

# task -> (submission artifact on disk now, result files that hold the measurement)
TASKS = {
    "cooling-water-flush-plan": ("/work/cw/ws/output/submission.zip", [
        "/work/cw/off/verifier/metrics.json", "/work/cw/verif/heldout/reward.json",
        "/work/cw/verif/dev/reward.json"]),
    "data-center-site-model": ("/work/ple-solve/data-center-site-model/ws/submission/model.ifc", [
        "/work/ple-solve/data-center-site-model/results_523/metrics.json"]),
    "data-hall-device-takeoff": ("/work/ple-solve/data-hall-device-takeoff/output/submission.zip", [
        "/work/ple-solve/data-hall-device-takeoff/verifier/metrics.json",
        "/work/ple-solve/data-hall-device-takeoff/verifier/grade.json"]),
    "data-hall-mep-routing": ("/work/ple-solve/data-hall-mep-routing/output/solution.py", [
        "/work/ple-solve/data-hall-mep-routing/bench84/metrics.json"]),
    "data-hall-mep-routing-offset": ("/work/ple-solve/data-hall-mep-routing-offset/output/solution.py", [
        "/work/ple-solve/data-hall-mep-routing-offset/bench/final85/metrics.json"]),
    "division-26-specifications": ("/work/ple-solve/division-26-specifications/build/stage2/submission.zip", [
        "/work/ple-solve/division-26-specifications/grade/g_s3/logs/paper_score.json",
        "/work/ple-solve/division-26-specifications/grade/g_s3/logs/metrics.json"]),
    "eor-review-corrections": ("/work/ple-solve/eor-review-corrections/build/submission.zip", [
        "/work/ple-solve/eor-review-corrections/results_522/paper_score.json",
        "/work/ple-solve/eor-review-corrections/results_522/metrics.json"]),
    "foundation-strategy": ("/work/ple-solve/foundation-strategy/out/submission.zip", [
        "/work/ple-solve/foundation-strategy/grade/official/grade.json",
        "/work/ple-solve/foundation-strategy/grade/official/paper_score.json"]),
    "frame-extension-method": ("/work/ple-solve/frame-extension-method/out/pkg/submission.zip", [
        "/work/ple-solve/frame-extension-method/out/final/paper_heldout.json",
        "/work/ple-solve/frame-extension-method/out/final/grade_heldout.json"]),
    "heat-rejection-life-cycle-cost": ("/work/ple-solve/heat-rejection-life-cycle-cost/out/submission.zip", [
        "/work/ple-solve/heat-rejection-life-cycle-cost/grade/g4/logs/paper_score.json",
        "/work/ple-solve/heat-rejection-life-cycle-cost/grade/g4/logs/metrics.json"]),
    "lv-cable-sizing": ("/work/lv-cable-sizing/build3/submission.zip", [
        "/work/lv-cable-sizing/off/dev/paper_result.json", "/work/lv-cable-sizing/off/dev/grade.json"]),
    "mv-conveyance-study": ("/work/ple-solve/mv-conveyance-study/build/submission.zip", [
        "/work/ple-solve/mv-conveyance-study/results_523/paper.json",
        "/work/ple-solve/mv-conveyance-study/results_523/logs/metrics.json"]),
    "roof-deck-design": ("/work/ple-solve/roof-deck-design/submission.zip", [
        "/work/ple-solve/roof/grade/metrics3.json"]),
    "seismic-diaphragm-shear": ("/work/ple-solve/seismic-diaphragm-shear/submission.zip", [
        "/work/ple-solve/seismic-diaphragm-shear/work/grade/paper.json",
        "/work/ple-solve/seismic-diaphragm-shear/work/grade/logs/metrics.json"]),
    "wind-diaphragm-shear": ("/work/ple-solve/wind-diaphragm-shear/out/submission.zip", [
        "/work/ple-solve/wind-diaphragm-shear/results_523/paper.json",
        "/work/ple-solve/wind-diaphragm-shear/results_523/logs/metrics.json"]),
}

KEYS = ("reward", "grader_reward", "combined_score", "mean_p", "hard_pass_rate", "judge_status", "split")


def sha(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def nums(p: Path):
    try:
        d = json.loads(p.read_text())
    except Exception:
        return ""
    if not isinstance(d, dict):
        return ""
    out = {}
    for k in KEYS:
        if k in d and not isinstance(d[k], (dict, list)):
            out[k] = d[k]
    if "metrics" in d and isinstance(d["metrics"], dict):
        for k in KEYS:
            if k in d["metrics"] and k not in out:
                out[k] = d["metrics"][k]
    return ", ".join(f"{k}={v}" for k, v in out.items())


def candidate_from_run(result: Path):
    """Look for an adapter_config.json next to the result (same dir, or one up)."""
    for up in (result.parent, result.parent.parent):
        cfg = up / "adapter_config.json"
        if cfg.is_file():
            try:
                c = json.loads(cfg.read_text())
            except Exception:
                continue
            cands = c.get("candidate_paths") or []
            if cands:
                return [str(x) for x in cands], str(cfg)
    return None, None


rows = {}
for task, (sub, results) in TASKS.items():
    s = Path(sub)
    entry = {"submission": None, "results": []}
    if s.is_file():
        entry["submission"] = {"path": str(s), "size": s.stat().st_size, "sha256": sha(s),
                               "mtime": s.stat().st_mtime}
    for rp in results:
        r = Path(rp)
        if not r.is_file():
            entry["results"].append({"path": rp, "missing": True})
            continue
        cands, cfg = candidate_from_run(r)
        row = {"path": rp, "mtime": r.stat().st_mtime, "numbers": nums(r)}
        if cands:
            row["adapter_config"] = cfg
            row["candidates"] = cands
            if entry["submission"]:
                same = any(os.path.realpath(c) == os.path.realpath(str(s)) for c in cands)
                row["candidate_is_this_submission"] = same
        if entry["submission"]:
            row["submission_older_than_result"] = entry["submission"]["mtime"] <= r.stat().st_mtime
        entry["results"].append(row)
    rows[task] = entry

print(json.dumps(rows, indent=1, sort_keys=True))
