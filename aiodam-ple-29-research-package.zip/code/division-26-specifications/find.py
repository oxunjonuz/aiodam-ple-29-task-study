"""find.py - grep the built section docx for phrases:  find.py 262000 "phrase" ["phrase2" ...]"""
import re, sys, zipfile

num = sys.argv[1]
z = zipfile.ZipFile(f"/work/ple-solve/division-26-specifications/build/stage2/specs/{num}.docx")
ps = [p for p in re.findall(r'<w:t[^>]*>(.*?)</w:t>', z.read("word/document.xml").decode())]
for pat in sys.argv[2:]:
    hits = [i for i, p in enumerate(ps) if re.search(pat, p, re.I)]
    print(f"== {pat!r}: {len(hits)} hits")
    for i in hits[:6]:
        print("   ", i, "|", ps[i][:260])
