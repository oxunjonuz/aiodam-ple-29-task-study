import json, os
G = "/work/ple-dataset/tasks/division-26-specifications/tests/corrino/electrical_task8_electrical_specs/grading"
t = json.load(open(os.path.join(G, "data", "truth.json")))
print("== items ==")
for k, v in t["items"].items():
    print(" ", k, json.dumps(v)[:400])
print("\n== project_sections (first 8) ==")
for k, v in list(t["project_sections"].items())[:8]:
    print(" ", k, json.dumps(v)[:300])
print("\n== families keys ==")
print(list(t["families"]))
print("\n== one family ==")
k0 = list(t["families"])[0]
print(k0, json.dumps(t["families"][k0])[:800])
print("\n== assertions (first 3) ==")
for a in t["assertions"][:3]:
    print(json.dumps(a)[:600])
print("\n== register (first 3) ==")
for a in t["register"][:3]:
    print(json.dumps(a)[:400])
print("\n== sim_families keys ==", list(t["sim_families"]))
print("== sim_objectives ==", json.dumps(t["sim_objectives"])[:800])
print("== bounds ==", json.dumps(t["bounds"])[:600])
print("== other_task_order ==", json.dumps(t["other_task_order"])[:600])
