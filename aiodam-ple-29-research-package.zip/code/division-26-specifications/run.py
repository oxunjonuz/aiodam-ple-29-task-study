"""run.py - run the task's own frozen grader on a submission.zip and print the per-item detail."""
import json, sys
sys.path.insert(0, "/work/ple-dataset/tasks/division-26-specifications/tests")
from corrino.electrical_task8_electrical_specs.grading.grade import grade

zp = sys.argv[1] if len(sys.argv) > 1 else "/work/ple-solve/division-26-specifications/build/stage2/submission.zip"
splits = sys.argv[2].split(",") if len(sys.argv) > 2 else ["heldout", "dev"]
for sp in splits:
    m = grade(zp, sp)
    print("=" * 100)
    print(f"SPLIT {sp}: combined {m['combined_score']}  mean_p {m['mean_p']}  G {m['hard_pass_rate']}  "
          f"A {m['full_compliance_rate']}  O {m['objective_raw']}  reg_hard {m['register_recall_hard']}")
    print("  sim_families:", {k: v for k, v in m["sim_families"].items() if not v})
    print("  sim_objectives:", m["sim_objectives"])
    for item, r in m["per_item"].items():
        print(f"-- {item}: present {r['present']} fid {r.get('fidelity_coverage')} ratio {r.get('length_ratio')} "
              f"P {r.get('P')} p {r.get('p')} G {r.get('G')} A {r.get('A')} O {r.get('O')} score {r.get('score')}")
        if r.get("not_scored_reason"):
            print("   NOT SCORED:", r["not_scored_reason"])
        for f, d in (r.get("families") or {}).items():
            if not d["ok"]:
                print(f"   FAIL {f} [{d['tag']} w={d['weight']}]: {d['detail'][:220]}")
        if r.get("register_missing_binding"):
            print("   register missing:", r["register_missing_binding"])
    print("  unparseable:", m["unparseable"], "errors:", m["package_errors"])
