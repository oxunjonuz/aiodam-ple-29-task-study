import json, os, sys
G = "/work/ple-dataset/tasks/division-26-specifications/tests/corrino/electrical_task8_electrical_specs/grading"
t = json.load(open(os.path.join(G, "data", "truth.json")))
print("truth top:", type(t).__name__, len(t))
if isinstance(t, dict):
    for k, v in t.items():
        print("  ", k, type(v).__name__, len(v) if hasattr(v, "__len__") else v)
m = json.load(open(os.path.join(G, "data", "master_index.json")))
print("master_index top:", type(m).__name__, len(m))
if isinstance(m, dict):
    for k, v in list(m.items())[:10]:
        print("  ", k, type(v).__name__, len(v) if hasattr(v, "__len__") else v)
f = json.load(open(os.path.join(G, "data", "fidelity.json")))
print("fidelity top:", type(f).__name__, len(f))
if isinstance(f, dict):
    for k, v in list(f.items())[:10]:
        print("  ", k, type(v).__name__, len(v) if hasattr(v, "__len__") else v)
g = json.load(open(os.path.join(G, "data", "geometry.json")))
print("geometry top:", type(g).__name__, len(g))
if isinstance(g, dict):
    for k, v in list(g.items())[:10]:
        print("  ", k, type(v).__name__, len(v) if hasattr(v, "__len__") else v)
