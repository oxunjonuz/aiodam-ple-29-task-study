"""d26build.py - build the six project specification sections as .docx from the UFGS .SEC guides.

Pipeline per section:  parse (.SEC) -> tailoring rules -> resolve brackets -> prune references ->
re-order/renumber -> write DOCX (paragraph text only, literal numbering).
"""
from __future__ import annotations

import html
import json
import os
import re
import sys
import zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import d26sec as sec

OUT = os.path.join(HERE, "build", "stage2")
SEC_FILES = {"26 05 73": "26 05 73.SEC", "26 20 00": "26 20 00.SEC", "26 24 13": "26 24 13.SEC",
             "26 32 15": "26 32 15.SEC", "26 36 23": "26 36 23.SEC", "26 51 00": "26 51 00.SEC"}

NON_ARMY = ['Submittals not having a "G" or "S" classification are for Contractor Quality Control approval.']

W = 'xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"'
CT = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/'
      'package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.'
      'relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/'
      'document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>'
      '</Types>')
RELS = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats'
        '.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/'
        'officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>')


_BAD = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\ufffe\uffff]")


def esc(s):
    return html.escape(_BAD.sub(" ", s), quote=False)


def write_docx(path, paras):
    body = "".join(f'<w:p><w:r><w:t xml:space="preserve">{esc(p)}</w:t></w:r></w:p>' for p in paras if p.strip())
    doc = (f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document {W}><w:body>{body}'
           '<w:sectPr><w:pgSz w:w="12240" w:h="15840"/></w:sectPr></w:body></w:document>')
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", CT)
        z.writestr("_rels/.rels", RELS)
        z.writestr("word/document.xml", doc)


# ------------------------------------------------------------------ tailoring engine
class Sec:
    def __init__(self, number, blocks, title, date):
        self.number = number
        self.blocks = blocks
        self.title = title
        self.date = date

    # ---- selectors
    def articles(self):
        return [b for b in self.blocks if b.kind == "article"]

    def find(self, kw, part=None):
        kw = kw.lower()
        out = []
        cur_part = None
        for b in self.blocks:
            if b.kind == "part":
                cur_part = b.num
            if b.kind in ("article", "sub") and kw in b.title.lower():
                if part is None or cur_part == part:
                    out.append(b)
        return out

    # ---- operations
    def drop_article(self, kw):
        """drop the article whose title contains kw, with all its paragraphs and sub-paragraphs"""
        target = None
        for i, b in enumerate(self.blocks):
            if b.kind == "article" and kw.lower() in b.title.lower():
                target = i
                break
        if target is None:
            return self
        j = target + 1
        while j < len(self.blocks) and self.blocks[j].kind not in ("article", "part"):
            j += 1
        del self.blocks[target:j]
        return self

    def drop_sub(self, kw):
        target = None
        for i, b in enumerate(self.blocks):
            if b.kind == "sub" and kw.lower() in b.title.lower():
                target = i
                break
        if target is None:
            return self
        j = target + 1
        while j < len(self.blocks) and self.blocks[j].kind not in ("article", "sub", "part"):
            j += 1
        del self.blocks[target:j]
        return self

    def drop_text(self, sub, count=99):
        """drop paragraphs (text or list) containing the substring"""
        n = 0
        keep = []
        for b in self.blocks:
            if b.kind in ("text", "list") and sub.lower() in b.text.lower() and n < count:
                n += 1
                continue
            keep.append(b)
        self.blocks = keep
        return self

    def rewrite(self, sub, new, count=1):
        """replace the whole text of paragraphs containing `sub` (first `count` hits)"""
        n = 0
        for b in self.blocks:
            if b.kind in ("text", "list") and sub.lower() in b.text.lower() and n < count:
                b.text = new
                n += 1
        if n == 0:
            raise SystemExit(f"{self.number}: rewrite found no paragraph with {sub!r}")
        return self

    def drop_phrases(self, phrases):
        """drop any paragraph or numbered paragraph heading that states one of these choices positively"""
        low = [p.lower() for p in phrases]
        out, skip = [], False
        for b in self.blocks:
            if b.kind in ("article", "part"):
                skip = False
            if b.kind in ("text", "list") and not skip and any(p in b.text.lower() for p in low):
                continue
            if b.kind == "sub":
                if any(p in b.title.lower() for p in low):
                    skip = True          # drop this numbered paragraph and the text under it
                    continue
                skip = False
            if skip:
                continue
            out.append(b)
        self.blocks = out
        return self

    def dropm(self, pattern):
        rx = re.compile(pattern, re.I)
        self.blocks = [b for b in self.blocks if not (b.kind in ("text", "list") and rx.search(b.text))]
        return self

    def replace(self, old, new, count=0):
        for b in self.blocks:
            if b.kind in ("text", "list"):
                if old in b.text:
                    b.text = b.text.replace(old, new) if count == 0 else b.text.replace(old, new, count)
            elif b.kind in ("article", "sub"):
                if old in b.title:
                    b.title = b.title.replace(old, new)
        return self

    def append(self, kw, text, part=None):
        """append a paragraph at the end of the article whose title is exactly kw (else contains kw)"""
        idx = None
        for i, b in enumerate(self.blocks):
            if b.kind == "article" and b.title.strip().lower() == kw.lower():
                idx = i
                break
        if idx is None:
            for i, b in enumerate(self.blocks):
                if b.kind in ("article", "sub") and kw.lower() in b.title.lower():
                    idx = i
                    break
        if idx is None:
            raise SystemExit(f"{self.number}: no article matching {kw!r}")
        j = idx + 1
        while j < len(self.blocks) and self.blocks[j].kind not in ("article", "part"):
            j += 1
        self.blocks.insert(j, sec.Block("text", text=text))
        return self

    def append_part(self, part, text):
        idx = None
        for i, b in enumerate(self.blocks):
            if b.kind == "part" and b.num == part:
                idx = i
        j = idx + 1
        while j < len(self.blocks) and self.blocks[j].kind != "part":
            j += 1
        self.blocks.insert(j, sec.Block("text", text=text))
        return self

    def insert_before(self, kw, text):
        for i, b in enumerate(self.blocks):
            if b.kind in ("article", "sub") and kw.lower() in b.title.lower():
                self.blocks.insert(i, sec.Block("text", text=text))
                return self
        raise SystemExit(f"{self.number}: no article {kw!r}")

    def add_article(self, part, title, texts):
        """insert a new article at the end of a part"""
        idx = None
        for i, b in enumerate(self.blocks):
            if b.kind == "part" and b.num == part:
                idx = i
        j = idx + 1
        while j < len(self.blocks) and self.blocks[j].kind != "part":
            j += 1
        new = [sec.Block("article", num="", title=title)] + [sec.Block("text", text=t) for t in texts]
        self.blocks[j:j] = new
        return self

    def set_submittals(self, codes: dict, default="RO"):
        """assign an Army reviewer code to every 'G' submittal item, from SOW 3.6 Table 2"""
        for b in self.blocks:
            if b.kind != "list" or "; G" not in b.text:
                continue
            name = b.text.split(";")[0].strip().lower()
            code = None
            for key, val in codes.items():
                if re.search(key, name):
                    code = val
                    break
            b.text = re.sub(r";\s*G\s*,\s*(\[[^\]]*\]|_____)?\s*", f"; G, {code or default}", b.text)
            b.text = re.sub(r";\s*G\s*$", f"; G, {code or default}", b.text)
            b.text = re.sub(r"(;\s*G\s*,\s*(?:RO|DO|AE|AO|PO))S\b", r"\1", b.text)


# ------------------------------------------------------------------ references pruning
def prune_references(blocks):
    """keep only the reference entries the section text actually cites (UFS 1-300-02 2-3.9)"""
    refs = [b for b in blocks if b.kind == "ref"]
    if not refs:
        return blocks
    body = sec.norm if hasattr(sec, "norm") else None
    text = " ".join(b.text for b in blocks if b.kind in ("text", "list")).lower()
    text += " " + " ".join(b.title for b in blocks if b.kind in ("article", "sub")).lower()
    text = re.sub(r"\s+", " ", text)
    for r in refs:
        kept = []
        for rid, rtl in r.entries:
            d = re.sub(r"\s+", " ", rid.lower())
            pat = r"(?<![a-z0-9])" + re.escape(d).replace(r"\ ", r"\s*") + r"(?![a-z0-9]|[.\-][a-z0-9])"
            if re.search(pat, text):
                kept.append((rid, rtl))
        r.entries = kept
    return [b for b in blocks if b.kind != "ref" or b.entries]


# ------------------------------------------------------------------ emit
def render(s: Sec, non_army=()):
    paras = [f"SECTION {s.number}", s.title, s.date]  # title and date on their own lines (instruction format)
    part = None
    art = 0
    sub = 0
    l1 = l2 = 0
    for b in s.blocks:
        if b.kind == "part":
            part = b.num
            art = 0
            sub = 0
            paras.append(f"PART {b.num}   {re.sub(r'^PART [123]s*', '', b.title).strip()}")
        elif b.kind == "article":
            art += 1
            sub = 0
            l1 = l2 = 0
            paras.append(f"{part}.{art} {b.title.upper()}")
        elif b.kind == "sub":
            sub += 1
            l1 = l2 = 0
            paras.append(f"{part}.{art}.{sub} {b.title}")
        elif b.kind == "text":
            paras.append(b.text)
        elif b.kind == "list":
            if b.level == 1:
                l1 += 1
                l2 = 0
                paras.append(f"{_letters(l1)}. {b.text}")
            else:
                l2 += 1
                paras.append(f"({l2}) {b.text}")
        elif b.kind == "ref":
            paras.append(b.org)
            for rid, rtl in b.entries:
                paras.append(f"{rid} {rtl}".strip())
    paras.append("-- End of Section --")
    out = []
    for p in paras:
        p = re.sub(r"\s+", " ", p).strip()
        if not p:
            continue
        if any(p.lower().strip(" .") == x.strip(" .") for x in non_army):
            continue
        out.append(p)
    return out


def _letters(n):
    s = ""
    while n > 0:
        n, r = divmod(n - 1, 26)
        s = chr(97 + r) + s
    return s


def build(number, rules=None, submittal_codes=None):
    num, title, date, blocks = sec.parse(os.path.join(sec.SEC_DIR, SEC_FILES[number]))
    s = Sec(number, blocks, title, date)
    if rules:
        rules(s)
    if submittal_codes is not None:
        s.set_submittals(submittal_codes)
    # brackets: resolve, then tidy every text paragraph
    for b in s.blocks:
        if b.kind in ("text", "list"):
            b.text = sec.tidy(sec.resolve_brackets(b.text))
    s.blocks = [b for b in s.blocks if b.kind != "text" or (len(b.text.strip()) > 2 and re.search(r"[A-Za-z]", b.text))]
    s.blocks = prune_references(s.blocks)
    paras = render(s)
    os.makedirs(os.path.join(OUT, "specs"), exist_ok=True)
    path = os.path.join(OUT, "specs", number.replace(" ", "") + ".docx")
    write_docx(path, paras)
    return path, paras


# ------------------------------------------------------------------ generic cross-reference pass
def fix_xrefs(paras, project_sections):
    num_re = re.compile(r"\bsection\s+(\d{2}\s+\d{2}\s+\d{2}(?:\.\d{2}(?:\s+\d{2})?)?)", re.I)
    out = []
    for k, p in enumerate(paras):
        if k == 0 and re.match(r"^\s*section\s+\d", p, re.I):   # the section identifier line itself
            out.append(p)
            continue
        def rep(m):
            num = re.sub(r"\s+", " ", m.group(1))
            title = project_sections.get(num)
            if not title:
                return m.group(0)
            tail = p[m.end():m.end() + len(title) + 4]
            if re.sub(r"\s+", " ", tail).strip(" ,.;:").lower().startswith(title.lower()):
                return m.group(0)
            return f"Section {num} {title}"
        out.append(num_re.sub(rep, p))
    return out


def build_all(project_sections, rules_map, out_dir=OUT):
    import d26rules
    paths = []
    for num in SEC_FILES:
        rules = rules_map.get(num)
        num_, title, date, blocks = sec.parse(os.path.join(sec.SEC_DIR, SEC_FILES[num]))
        s = Sec(num, blocks, title, date)
        for b in s.blocks:                       # resolve the guide's options first, then tailor the result
            if b.kind in ("text", "list"):
                b.text = sec.tidy(sec.resolve_brackets(b.text))
        s.blocks = [b for b in s.blocks if b.kind != "text" or (len(b.text.strip()) > 2 and re.search(r"[A-Za-z]", b.text))]
        if rules:
            rules(s)
        for b in s.blocks:                       # the two non-Army submittal sentences (Army design-bid-build)
            if b.kind in ("text", "list"):
                for sent in NON_ARMY:
                    b.text = b.text.replace(sent, "")
                b.text = sec.tidy(b.text)
        s.set_submittals(d26rules.SUB_CODE)
        s.blocks = prune_references(s.blocks)
        paras = render(s)
        paras = fix_xrefs(paras, project_sections)
        os.makedirs(os.path.join(out_dir, "specs"), exist_ok=True)
        path = os.path.join(out_dir, "specs", num.replace(" ", "") + ".docx")
        write_docx(path, paras)
        paths.append(path)
        print(num, "->", path, len(paras), "paragraphs")
    return paths
