"""mutate_494.py - break the package on purpose and confirm the frozen grader notices.
Each mutation is applied to a copy of the submission and graded; a mutation the grader does not
notice is a hole in the package-to-score chain.
"""
import io, os, shutil, sys, zipfile
from openpyxl import load_workbook

sys.path.insert(0, "/work/ple-dataset/tasks/division-26-specifications/tests")
from corrino.electrical_task8_electrical_specs.grading.grade import grade

ZP = "/work/ple-solve/division-26-specifications/build/stage2/submission.zip"
MUT = "/work/ple-solve/division-26-specifications/build/mut"


def repack(mod):
    os.makedirs(MUT, exist_ok=True)
    z = zipfile.ZipFile(ZP)
    wb = load_workbook(io.BytesIO(z.read("design_basis.xlsx")))
    mod(wb)
    out = os.path.join(MUT, "mut.zip")
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zz:
        for n in z.namelist():
            if n == "design_basis.xlsx":
                buf = io.BytesIO()
                wb.save(buf)
                zz.writestr(n, buf.getvalue())
            else:
                zz.writestr(n, z.read(n))
    return out


def set_feeder(wb):
    ws = wb["Feeders"]
    for r in ws.iter_rows(min_row=2):
        if r[0].value == "MSB":
            r[2].value = 2          # 6 sets -> 2 sets


def set_photo(wb):
    ws = wb["Photometric"]
    for r in ws.iter_rows(min_row=2):
        if str(r[0].value) == "102":
            r[2].value = 12         # 24 -> 12 luminaires


def set_step(wb):
    ws = wb["StepLoad"]
    for r in ws.iter_rows(min_row=2):
        if r[0].value == 1:
            r[1].value = "EGRESS-LTG, FIRE-ALARM"   # drop COMM-MNS and ELEV-CTRL from step 1


base = grade(ZP, "heldout")["combined_score"]
print(f"baseline heldout {base}")
for name, mod in [("MSB 6x4/0 -> 2x4/0 (feeder sizing)", set_feeder),
                  ("space 102 24 -> 12 luminaires", set_photo),
                  ("step 1 loses two Article 700 loads", set_step)]:
    zp = repack(mod)
    m = grade(zp, "heldout")
    red = sorted(f for f, ok in m["families_satisfied"].items() if not ok)
    print(f"  {name}: combined {m['combined_score']} (was {base}); families now failing: {red}")
