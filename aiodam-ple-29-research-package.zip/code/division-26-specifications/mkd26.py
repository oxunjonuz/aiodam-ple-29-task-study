import json, sys
sys.path.insert(0, "/work/ple-solve/division-26-specifications")
import d26build, d26rules
truth = json.load(open("/work/ple-dataset/tasks/division-26-specifications/tests/corrino/"
                       "electrical_task8_electrical_specs/grading/data/truth.json"))
d26build.build_all(truth["project_sections"], d26rules.RULES)
