"""d26calc.py - my own forward models for Building 4410, written from the basis memoranda:
  FDB-01 Rev 1  feeder sizing (ampacity + voltage drop + raceway fill)
  PCB-01 Rev 1  interior photometrics (zonal flux, grid, direct + interreflected)
  GSB-01 Rev 1  generator step loading (transient dip, recovery, step rules)
  SCB-01 Rev 1  short-circuit study (per-unit, complex impedances, motor contribution)
Data: CDS-7, RDS-1, GEN-1 data sheet, M-601, E-501, A-601, IES-26 Rev 4, and the coordination
model BLDG4410-E_RevC.ifc read by d26_ifc.py.  Standard library only.
"""
from __future__ import annotations

import json, math, os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import d26_ifc as ifc

WS = "/work/ple-dataset/tasks/division-26-specifications/environment/filesystem/final_batch4__electrical_task8_electrical_specs__blind"

# ------------------------------------------------------------------ CDS-7 (copper, 75 C, steel conduit, 600 V)
CONDUCTOR = {  # size: (R ohm/1000ft, X ohm/1000ft, area sq in, amp75 A, max OCPD A)
    "12": (2.000, 0.068, 0.0181, 20, 20), "10": (1.200, 0.063, 0.0243, 35, 30),
    "8": (0.780, 0.065, 0.0437, 50, 50), "6": (0.490, 0.064, 0.0590, 65, 60),
    "4": (0.310, 0.060, 0.0814, 85, 85), "3": (0.250, 0.059, 0.0962, 100, 100),
    "2": (0.190, 0.057, 0.1146, 115, 110), "1": (0.150, 0.057, 0.1534, 130, 125),
    "1/0": (0.120, 0.055, 0.1825, 150, 150), "2/0": (0.100, 0.054, 0.2190, 175, 175),
    "3/0": (0.077, 0.052, 0.2642, 200, 200), "4/0": (0.062, 0.051, 0.3197, 230, 225),
    "250": (0.052, 0.052, 0.3904, 255, 250), "300": (0.044, 0.051, 0.4536, 285, 300),
    "350": (0.038, 0.050, 0.5166, 310, 300), "400": (0.033, 0.049, 0.5782, 335, 350),
    "500": (0.027, 0.048, 0.6984, 380, 400), "600": (0.023, 0.048, 0.8709, 420, 450),
}
SIZES = list(CONDUCTOR)

RACEWAY = {  # RDS-1 interior area sq in
    "EMT": {0.5: 0.304, 0.75: 0.533, 1.0: 0.864, 1.25: 1.496, 1.5: 2.036, 2.0: 3.356, 2.5: 5.858,
            3.0: 8.846, 3.5: 11.545, 4.0: 14.753},
    "RMC": {0.75: 0.549, 1.0: 0.887, 1.25: 1.526, 1.5: 2.071, 2.0: 3.408, 2.5: 4.866, 3.0: 7.499, 4.0: 12.882},
    "PVC40": {0.75: 0.480, 1.0: 0.799, 1.25: 1.526, 1.5: 2.071, 2.0: 3.291, 2.5: 4.695, 3.0: 7.268, 4.0: 12.554},
}
FILL_LIMIT_PCT = 40.0
PF = 0.9                       # FDB-01 para 3: design power factor of every feeder

# ------------------------------------------------------------------ FDB-01 Table 1
FDB = {  # tag: (from, to, volts, load A, raceway material)
    "MSB": ("UTILITY", "MSB", 480, 1250.0, "PVC40"),
    "HM1": ("MSB", "HM1", 480, 310.0, "RMC"),
    "H1A": ("MSB", "H1A", 480, 165.0, "EMT"),
    "H2A": ("MSB", "H2A", 480, 150.0, "EMT"),
    "ATS-E": ("MSB", "ATS-E", 480, 208.0, "EMT"),
    "HE1": ("ATS-E", "HE1", 480, 185.0, "EMT"),
    "ATS-L": ("MSB", "ATS-L", 480, 60.0, "EMT"),
    "T-1A": ("H1A", "T-1A", 480, 135.0, "EMT"),
    "LP1A": ("T-1A", "LP1A", 208, 312.0, "EMT"),
    "T-2A": ("H2A", "T-2A", 480, 90.0, "EMT"),
    "LP2A": ("T-2A", "LP2A", 208, 208.0, "EMT"),
    "T-C1": ("H1A", "T-C1", 480, 54.0, "EMT"),
    "LC1": ("T-C1", "LC1", 208, 125.0, "EMT"),
    "T-E1": ("ATS-L", "T-E1", 480, 54.0, "EMT"),
    "LE1": ("T-E1", "LE1", 208, 125.0, "EMT"),
    "GEN-ATSL": ("GEN-1", "ATS-L", 480, 60.0, "PVC40"),
    "GEN-ATSE": ("GEN-1", "ATS-E", 480, 208.0, "PVC40"),
}
# IES-26 4.7: emergency-system feeders 2 %, all other feeders 3 %
EMERGENCY_FEEDERS = {"ATS-L", "GEN-ATSL", "T-E1", "LE1"}
TRADE = [0.75, 1.0, 1.25, 1.5, 2.0, 2.5, 3.0, 3.5, 4.0]


def geometry_feeder(tag):
    """route length, trade size and number of raceways of a feeder run, read from the IFC model.
    The superseded Rev B run of H2A (system E-SUPERSEDED, status DEMOLISH) is excluded (FDB-01 para 2)."""
    segs = []
    for (sysname, longname), lst in ifc.feeds.items():
        if sysname != tag:
            continue
        for s in lst:
            st = (s["status"] or "").strip("'")
            if st.upper() == "DEMOLISH":
                continue
            segs.append(s)
    if not segs:
        return None
    rw = {}
    for s in segs:
        key = "-".join(s["name"].split("-")[:-1])
        rw.setdefault(key, []).append(s)
    lengths = [sum(x["len_mm"] for x in ss) / 304.8 for ss in rw.values()]
    trades = {float(x["tag"].replace("in", "")) for ss in rw.values() for x in ss}
    assert len(trades) == 1, (tag, trades)
    return {"length_ft": round(sum(lengths) / len(lengths), 2), "trade_in": trades.pop(), "raceways": len(rw),
            "raceway_lengths": [round(l, 2) for l in lengths]}


def egc_size(size):
    """IES-26 4.6: same size below 250 kcmil, one catalogue size smaller at 250 kcmil and larger."""
    if SIZES.index(size) < SIZES.index("250"):
        return size
    return SIZES[SIZES.index(size) - 1]


def vd_pct(tag, sets, size, length_ft):
    r, x, area, amp, ocpd = CONDUCTOR[size]
    sin_t = math.sqrt(1 - PF * PF)
    drop = math.sqrt(3) * FDB[tag][3] * (r * PF + x * sin_t) * length_ft / 1000.0 / sets
    return 100.0 * drop / FDB[tag][2]


def fill_pct(tag, sets, size, trade):
    interior = RACEWAY[FDB[tag][4]].get(trade)
    if not interior:
        return 999.0
    occupied = 4 * CONDUCTOR[size][2] + CONDUCTOR[egc_size(size)][2]
    return 100.0 * occupied / interior


def feeder_ok(tag, sets, size, trade, raceways):
    if sets > raceways:
        return False, {}
    vd = vd_pct(tag, sets, size, geometry_feeder(tag)["length_ft"])
    fill = fill_pct(tag, sets, size, trade)
    amp = sets * CONDUCTOR[size][3]
    limit = 2.0 if tag in EMERGENCY_FEEDERS else 3.0
    ok = vd <= limit + 1e-9 and fill <= FILL_LIMIT_PCT + 1e-9 and amp >= FDB[tag][3] - 1e-9
    return ok, {"vd_pct": round(vd, 3), "fill_pct": round(fill, 2), "ampacity_a": amp,
                "vd_limit": limit, "load_a": FDB[tag][3], "raceway_in": trade}


def feasible_in_raceway(tag, trade):
    g = geometry_feeder(tag)
    for sets in range(1, g["raceways"] + 1):
        for size in SIZES:
            ok, info = feeder_ok(tag, sets, size, trade, g["raceways"])
            if ok:
                return True
    return False


def required_raceway(tag):
    """FDB-01 para 6: the modelled raceway governs unless no conductor fits in it."""
    g = geometry_feeder(tag)
    if feasible_in_raceway(tag, g["trade_in"]):
        return g["trade_in"]
    for t in TRADE:
        if t <= g["trade_in"]:
            continue
        if feasible_in_raceway(tag, t):
            return t
    raise SystemExit(f"{tag}: no raceway size works")


def min_feeder(tag):
    """smallest total conductor area that satisfies ampacity, voltage drop and fill (CDS-7 catalogue)."""
    g = geometry_feeder(tag)
    trade = required_raceway(tag)
    best = None
    for sets in range(1, g["raceways"] + 1):
        for size in SIZES:
            ok, info = feeder_ok(tag, sets, size, trade, g["raceways"])
            if not ok:
                continue
            cu = sets * CONDUCTOR[size][2] * g["length_ft"]
            if best is None or cu < best[0]:
                best = (cu, sets, size, info)
    return {"sets": best[1], "size": best[2], "copper": best[0], **best[3],
            "route_length_ft": g["length_ft"], "raceways": g["raceways"], "raceway_in": trade}


def feeder_design():
    return {tag: min_feeder(tag) for tag in FDB}


# ------------------------------------------------------------------ LM-63 photometric files
def read_ies(path):
    lines = [l.rstrip("\r\n") for l in open(path, encoding="latin-1")]
    i = 0
    while not lines[i].strip().upper().startswith("TILT="):
        i += 1
    i += 1
    a = lines[i].split()
    n_lamp, lumens_per_lamp, cd_mult, n_v, n_h, phot_type, units, w, l, h = (
        float(a[0]), float(a[1]), float(a[2]), int(a[3]), int(a[4]), int(a[5]), int(a[6]),
        float(a[7]), float(a[8]), float(a[9]))
    i += 1
    b = lines[i].split()
    ballast, watts = float(b[0]), float(b[2]) if len(b) > 2 else None
    i += 1
    vals = []
    while len(vals) < n_v:
        vals += [float(x) for x in lines[i].split()]
        i += 1
    vang = vals[:n_v]
    vals = []
    while len(vals) < n_h:
        vals += [float(x) for x in lines[i].split()]
        i += 1
    hang = vals[:n_h]
    cd = []
    while len(cd) < n_h:
        row = []
        while len(row) < n_v:
            row += [float(x) for x in lines[i].split()]
            i += 1
        cd.append(row[:n_v])
    return {"n_lamp": n_lamp, "lumens_per_lamp": lumens_per_lamp, "cd_mult": cd_mult, "bang": vang,
            "hang": hang, "cd": cd, "watts": watts, "ballast": ballast}


def zonal_flux(tbl):
    """PCB-01 para 2: mean intensity over horizontal angles per vertical angle, then zonal summation."""
    bang, hang, cd = tbl["bang"], tbl["hang"], tbl["cd"]
    mean = []
    for j in range(len(bang)):
        if len(hang) == 1:
            mean.append(cd[0][j])
        else:
            acc = 0.0
            for a, b in zip(hang, hang[1:]):
                ia, ib = cd[hang.index(a)][j], cd[hang.index(b)][j]
                acc += (ia + ib) / 2.0 * (b - a)
            mean.append(acc / (hang[-1] - hang[0]))
    tot = 0.0
    for j in range(len(bang) - 1):
        t1, t2 = math.radians(bang[j]), math.radians(bang[j + 1])
        tot += 2 * math.pi * (math.cos(t1) - math.cos(t2)) * (mean[j] + mean[j + 1]) / 2.0
    return tot


def intensity(tbl, theta, phi):
    """PCB-01 para 3: bilinear interpolation, horizontal angle folded into 0..90 by quadrant symmetry."""
    if theta >= 90.0:
        return 0.0
    phi = abs(phi) % 180.0
    if phi > 90.0:
        phi = 180.0 - phi
    hang, bang, cd = tbl["hang"], tbl["bang"], tbl["cd"]
    if len(hang) == 1:
        rows, wts = [cd[0]], [1.0]
    else:
        hi = next((p for p in hang if p >= phi), hang[-1])
        lo = max([p for p in hang if p <= phi], default=hang[0])
        if hi == lo:
            rows, wts = [cd[hang.index(lo)]], [1.0]
        else:
            f = (phi - lo) / (hi - lo)
            rows, wts = [cd[hang.index(lo)], cd[hang.index(hi)]], [1 - f, f]
    step = bang[1] - bang[0]
    j = min(int(theta // step), len(bang) - 2)
    ft = (theta - bang[j]) / step
    return sum(w * (r[j] * (1 - ft) + r[j + 1] * ft) for r, w in zip(rows, wts))


IES_CACHE = {}
def ies(t):
    if t not in IES_CACHE:
        IES_CACHE[t] = read_ies(os.path.join(WS, "40_product_data", "photometrics", f"{t}.ies"))
    return IES_CACHE[t]


# ------------------------------------------------------------------ E-501 luminaire schedule
WATTS = {"L1": 30.0, "L2": 21.0, "L3": 36.0, "L4": 14.0, "L5": 40.0}
LLF = 0.81
WORKPLANE_FT = 2.5
GRID_FT = 1.0
GRID_OFFSET_FT = 0.5
LPD_CAP = 0.285

# IES-26 11.6, by application ("assign each space to the application that describes its use")
APPLICATION = [  # (regex on the space name, application, min average fc, uniformity max)
    (r"staff duty|lobby", "lobby", 20, 4),
    (r"open office", "open_office", 30, 3),
    (r"private office", "office", 30, 3),
    (r"conference|meeting", "conference", 30, 3),
    (r"training|classroom", "training", 30, 3),
    (r"communications|telecom", "communications", 30, 3),
    (r"break|kitchenette", "break", 20, 4),
    (r"electrical", "electrical", 20, 4),
    (r"mechanical|equipment", "mechanical", 20, 4),
    (r"corridor|circulation", "corridor", 10, 4),
    (r"toilet|locker", "toilet", 10, 4),
    (r"janitor", "janitor", 10, 6),
    (r"storage", "storage", 10, 6),
]
MARGIN = 0.10


def application(name):
    for pat, app, fc, u in APPLICATION:
        if re.search(pat, name, re.I):
            return app, fc, u
    raise SystemExit("no application for " + name)


def spaces():
    out = []
    a601 = {}
    from openpyxl import load_workbook
    wb = load_workbook(os.path.join(WS, "30_drawings", "A-601_Room_Finish_Schedule.xlsx"), data_only=True)
    ws = wb["A-601"]
    for r in list(ws.iter_rows(values_only=True))[1:]:
        if r[0]:
            a601[str(r[0]).strip()] = (float(r[6]), float(r[7]), float(r[8]))
    for s in ifc.dump_spaces():
        app, fc, u = application(s["name"])
        rc, rw, rf = a601[s["number"]]
        out.append({**s, "app": app, "target_fc": fc, "uniformity_max": u,
                    "rho": (rc, rw, rf)})
    return out


def grid_points(sp):
    def axis(a0, extent):
        n = int(math.floor((extent - 2 * GRID_OFFSET_FT) / GRID_FT)) + 1
        return [a0 + GRID_OFFSET_FT + GRID_FT * i for i in range(max(1, n))]
    return [(x, y) for y in axis(sp["y"], sp["d"]) for x in axis(sp["x"], sp["w"])]


def layout(sp, qty):
    """PCB-01 para 8: modelled positions when the quantity is unchanged, else the uniform re-layout."""
    if qty == sp["n_lums"]:
        return [(l["x"], l["y"]) for l in sp["lums"]]
    cols = max(1, int(round(math.sqrt(qty * sp["w"] / max(sp["d"], 1e-6)))))
    cols = min(cols, qty)
    rows = max(1, int(math.ceil(qty / cols)))
    pts = [(sp["x"] + sp["w"] * (c + 0.5) / cols, sp["y"] + sp["d"] * (r + 0.5) / rows)
           for r in range(rows) for c in range(cols)]
    return pts[:qty]


def photometry(sp, lt, qty):
    tbl = ies(lt)
    pts = grid_points(sp)
    lums = layout(sp, qty)
    z_lum = max((l["z"] for l in sp["lums"]), default=sp["z0"] + sp["ceiling"])
    h = (z_lum - sp["z0"]) - WORKPLANE_FT
    if h <= 0:
        return {"avg_fc": 0.0, "min_fc": 0.0, "uniformity": 99.0}
    vals = []
    for (px, py) in pts:
        e = 0.0
        for (lx, ly) in lums:
            dx, dy = px - lx, py - ly
            d2 = dx * dx + dy * dy
            dist = math.sqrt(d2 + h * h)
            theta = math.degrees(math.atan2(math.sqrt(d2), h))
            phi = math.degrees(math.atan2(abs(dy), abs(dx))) if d2 > 1e-12 else 0.0
            e += intensity(tbl, theta, phi) * (h / dist) / (dist * dist)
        vals.append(e * LLF)
    a_f = sp["w"] * sp["d"]
    e_dir = sum(vals) / len(vals)
    phi_tot = zonal_flux(tbl) * qty * LLF
    rc, rw, rf = sp["rho"]
    a_room = 2 * a_f + 2 * sp["ceiling"] * (sp["w"] + sp["d"])
    rho = (rc * a_f + rf * a_f + rw * 2 * sp["ceiling"] * (sp["w"] + sp["d"])) / a_room
    lost = max(0.0, phi_tot - e_dir * a_f)
    e_ind = rho / (1 - rho) * lost / a_room
    avg = e_dir + e_ind
    mn = min(vals) + e_ind
    return {"avg_fc": avg, "min_fc": mn, "uniformity": avg / mn if mn > 1e-9 else 99.0,
            "e_direct": e_dir, "e_indirect": e_ind, "watts": qty * WATTS[lt], "qty": qty,
            "lpd": qty * WATTS[lt] / a_f}


def space_ok(sp, lt, qty, margin=MARGIN):
    r = photometry(sp, lt, qty)
    ok = (r["avg_fc"] >= sp["target_fc"] * (1 - margin) - 1e-9 and
          r["uniformity"] <= sp["uniformity_max"] * (1 + margin) + 1e-9)
    return ok, r


def min_luminaire(sp, margin=0.0):
    """smallest quantity of the scheduled type that meets the target and the uniformity limit."""
    lt = sp["lum_types"][0]
    for q in range(1, 400):
        ok, r = space_ok(sp, lt, q, margin)
        if ok:
            return lt, q, r
    raise SystemExit("no feasible quantity for space " + sp["number"])


# ------------------------------------------------------------------ GSB-01 step loading
GEN = {"kva": 187.5, "kw": 150.0, "pf": 0.8, "xd2": 0.12}
DIP_LIMIT = 15.0
RECOVERY_LIMIT = 3.0

GEN_LOADS = {  # M-601 sheet 'Generator transfer loads'
    "EGRESS-LTG": (9.0, 9.0, "ATS-L"), "FIRE-ALARM": (3.0, 3.0, "ATS-L"), "COMM-MNS": (22.0, 22.0, "ATS-L"),
    "ELEV-CTRL": (6.0, 6.0, "ATS-L"), "AHU-1": (26.0, 94.5, "ATS-E"), "AHU-2": (26.0, 94.5, "ATS-E"),
    "CHWP-1": (13.0, 47.3, "ATS-E"), "CHWP-2": (13.0, 47.3, "ATS-E"), "EF-1-4": (8.0, 25.2, "ATS-E"),
    "RECEPT-HE1": (18.0, 18.0, "ATS-E"),
}


def step_dip(ks, kr):
    return 100.0 * GEN["xd2"] * ks / (GEN["kva"] + GEN["xd2"] * (ks + kr))


def simulate_steps(seq):
    seen, running, steps, errs = set(), 0.0, [], []
    for i, grp in enumerate(seq, 1):
        if not grp:
            errs.append(f"step {i} empty")
        ks = 0.0
        for t in grp:
            if t not in GEN_LOADS:
                errs.append(f"unknown load {t}")
            elif t in seen:
                errs.append(f"{t} started twice")
            else:
                seen.add(t)
                ks += GEN_LOADS[t][1]
        dip = step_dip(ks, running)
        running += sum(GEN_LOADS[t][0] for t in grp)
        steps.append({"step": i, "loads": sorted(grp), "step_kva_start": round(ks, 2),
                      "voltage_dip_pct": round(dip, 3), "recovery_s": round(0.6 + 0.08 * dip, 3),
                      "running_kva_before": round(running - sum(GEN_LOADS[t][0] for t in grp), 2)})
    missing = sorted(set(GEN_LOADS) - seen)
    if missing:
        errs.append(f"not transferred: {missing}")
    if any(GEN_LOADS[t][2] == "ATS-L" for grp in seq[1:] for t in grp):
        errs.append("Article 700 load not in step 1")
    if any(GEN_LOADS[t][2] == "ATS-E" for t in seq[0]):
        errs.append("Article 702 load in step 1")
    if any(s["voltage_dip_pct"] > DIP_LIMIT for s in steps):
        errs.append("dip over limit")
    if any(s["recovery_s"] > RECOVERY_LIMIT for s in steps):
        errs.append("recovery over limit")
    total_kw = sum(GEN_LOADS[t][0] for t in seen) * GEN["pf"]
    if total_kw > GEN["kw"] + 1e-9:
        errs.append("total running load over rating")
    return {"steps": steps, "errors": errs, "feasible": not errs, "total_kw": round(total_kw, 2),
            "max_dip_pct": round(max((s["voltage_dip_pct"] for s in steps), default=0.0), 3)}


def search_sequences():
    """all ordered partitions of the ATS-E loads after the ATS-L group; return feasible ones by step count"""
    ls = [t for t, v in GEN_LOADS.items() if v[2] == "ATS-L"]
    rest = sorted([t for t, v in GEN_LOADS.items() if v[2] == "ATS-E"])

    def parts(items, k):
        if k == 1:
            yield [list(items)]
            return
        n = len(items)
        for mask in range(1, 1 << n):
            head = [items[i] for i in range(n) if mask >> i & 1]
            tail = [items[i] for i in range(n) if not mask >> i & 1]
            if len(tail) < k - 1:
                continue
            for p in parts(tail, k - 1):
                yield [head] + p

    best = {}
    for k in range(1, len(rest) + 1):
        for p in parts(rest, k):
            seq = [ls] + p
            r = simulate_steps(seq)
            if r["feasible"]:
                best.setdefault(k + 1, []).append((p, r))
    return best


def min_steps():
    b = search_sequences()
    n = min(b)
    # among the minimum-step sequences take the one with the smallest worst dip
    cand = sorted(b[n], key=lambda x: max(s["voltage_dip_pct"] for s in x[1]["steps"]))
    return n, cand[0][0], cand[0][1]


# ------------------------------------------------------------------ SCB-01 short circuit
UTILITY = {"fault_mva": 250.0, "xr": 12.0, "xfmr_kva": 1000.0, "xfmr_z_pct": 5.75, "xfmr_xr": 6.5}
XFMR = {  # SCB-01 Table 1 (dry-type)
    "T-1A": {"kva": 112.5, "z_pct": 4.2, "xr": 2.0},
    "T-2A": {"kva": 75.0, "z_pct": 4.0, "xr": 1.8},
    "T-C1": {"kva": 45.0, "z_pct": 3.6, "xr": 1.5},
    "T-E1": {"kva": 45.0, "z_pct": 3.6, "xr": 1.5},
}
STD_SCCR = {480: [14, 18, 22, 25, 35, 42, 50, 65, 85, 100], 208: [10, 22, 25, 42, 65]}
BUSES = [  # E-601 Rev C one-line: tag, volts, fed_from, transformer, motor FLA at the bus
    ("MSB", 480, None, None, 0.0),
    ("HM1", 480, "MSB", None, 182.0),
    ("H1A", 480, "MSB", None, 0.0),
    ("H2A", 480, "MSB", None, 0.0),
    ("ATS-E", 480, "MSB", None, 0.0),
    ("HE1", 480, "ATS-E", None, 77.6),
    ("ATS-L", 480, "MSB", None, 0.0),
    ("LP1A", 208, "H1A", "T-1A", 0.0),
    ("LP2A", 208, "H2A", "T-2A", 0.0),
    ("LC1", 208, "H1A", "T-C1", 0.0),
    ("LE1", 208, "ATS-L", "T-E1", 0.0),
]


def fault_currents(design):
    import cmath
    zb = 480.0 * 480.0 / 1e6
    zu = (1.0 / UTILITY["fault_mva"]) * cmath.exp(1j * math.atan(UTILITY["xr"])) * zb
    zt = (UTILITY["xfmr_z_pct"] / 100.0 / (UTILITY["xfmr_kva"] / 1000.0)) * \
        cmath.exp(1j * math.atan(UTILITY["xfmr_xr"])) * zb
    zmap = {"_XFMR": (zu + zt, 480.0)}
    bmap = {b[0]: b for b in BUSES}

    def cable_z(tag):
        if tag not in design:
            return 0j
        sets, size = design[tag]
        r, x = CONDUCTOR[size][0], CONDUCTOR[size][1]
        return complex(r, x) * geometry_feeder(tag)["length_ft"] / 1000.0 / sets

    order, known = [], {"_XFMR"}
    pending = [b[0] for b in BUSES]
    while pending:
        moved = False
        for tag in list(pending):
            b = bmap[tag]
            if (b[2] or "_XFMR") in known:
                order.append(b); pending.remove(tag); known.add(tag); moved = True
        if not moved:
            raise ValueError("not a tree")
    res = {}
    for b in order:
        tag, volts, fed, xf, fla = b
        z_up, v_up = zmap[fed or "_XFMR"]
        if xf:
            zbs = volts * volts / 1e6
            x = XFMR[xf]
            zx = (x["z_pct"] / 100.0 / (x["kva"] / 1000.0)) * cmath.exp(1j * math.atan(x["xr"])) * zbs
            z = (z_up + cable_z(xf)) * (volts / v_up) ** 2 + zx + cable_z(tag)
        else:
            z = z_up + cable_z(tag)
        zmap[tag] = (z, volts)
        res[tag] = {"volts": volts, "isc_ka": volts / math.sqrt(3) / abs(z) / 1000.0,
                    "motors_fla": fla}

    def downstream(t):
        out = [t]
        for b in BUSES:
            if b[2] == t and b[1] == 480:
                out += downstream(b[0])
        return out

    for b in BUSES:
        tag, volts = b[0], b[1]
        m = 4.0 * sum(bmap[x][4] for x in downstream(tag)) / 1000.0 if volts == 480 else 0.0
        res[tag]["motor_ka"] = m
        res[tag]["total_ka"] = res[tag]["isc_ka"] + m
        res[tag]["min_rating_ka"] = min_rating(res[tag]["total_ka"], volts)
    return res


def min_rating(total_ka, volts):
    series = STD_SCCR[480] if volts > 240 else STD_SCCR[208]
    need = max(total_ka, 14 if volts > 240 else 10)
    for r in series:
        if r >= need - 1e-9:
            return r
    return series[-1]


# ------------------------------------------------------------------ report
if __name__ == "__main__":
    out = {}
    print("== feeders ==")
    fd = feeder_design()
    tot_cu = 0.0
    for tag, d in fd.items():
        g = geometry_feeder(tag)
        flag = "" if g["trade_in"] == d["raceway_in"] else f"  <-- model raceway {g['trade_in']} in too small"
        tot_cu += d["copper"]
        print(f"  {tag:9s} L={d['route_length_ft']:6.1f} ft  {d['sets']}x{d['size']:>4s} in {d['raceway_in']} in "
              f"VD {d['vd_pct']:5.2f}% (lim {d['vd_limit']}) fill {d['fill_pct']:5.1f}% amp {d['ampacity_a']:.0f}/{d['load_a']:.0f}{flag}")
    print(f"  total copper area x length = {tot_cu:.2f}")
    out["feeders"] = fd

    print("== photometrics ==")
    sp = spaces()
    ph = {}
    tw = 0.0
    tarea = 0.0
    for s in sp:
        lt, q, r = min_luminaire(s, margin=MARGIN)
        ph[s["number"]] = {"type": lt, "qty": q, **{k: round(v, 3) for k, v in r.items()}}
        tw += q * WATTS[lt]; tarea += s["w"] * s["d"]
        print(f"  {s['number']:4s} {s['app']:14s} {lt} q={q:3d} avg {r['avg_fc']:6.1f}/{s['target_fc']} "
              f"U {r['uniformity']:5.2f}/{s['uniformity_max']} W {q*WATTS[lt]:5.0f}")
    print(f"  building LPD {tw/tarea:.4f} W/sf (cap {LPD_CAP}), watts {tw:.0f}, area {tarea:.0f}")
    out["photometric"] = ph
    out["lpd"] = {"watts": tw, "area": tarea, "lpd": tw / tarea}

    print("== step loading ==")
    n, parts, r = min_steps()
    print("  min steps", n)
    for s in r["steps"]:
        print("  ", s)
    out["steps"] = r

    print("== short circuit ==")
    design = {t: (fd[t]["sets"], fd[t]["size"]) for t in fd}
    fc = fault_currents(design)
    for t, v in fc.items():
        print(f"  {t:6s} {v['volts']:.0f} V  Isc {v['isc_ka']:6.2f} + motor {v['motor_ka']:5.2f} = {v['total_ka']:6.2f} kA"
              f"  -> {v['min_rating_ka']} kA")
    out["shortcircuit"] = fc
    json.dump(out, open(os.path.join(HERE, "calc.json"), "w"), indent=1, default=str)
