"""build2.py - assemble submission.zip: design_basis.xlsx (7 sheets) + specs/*.docx.

The workbook is computed by d26calc (my own implementation of FDB-01 / PCB-01 / GSB-01 / SCB-01);
the sections are produced by d26sec.py from the UFGS .SEC guide specifications.
"""
from __future__ import annotations

import json, os, sys, zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import d26calc as calc

from openpyxl import Workbook

OUT = os.path.join(HERE, "build", "stage2")

SECTIONS = {
    "26 05 73": ("POWER SYSTEM STUDIES", "SOW 3.5 requires the Contractor to perform construction-phase short-circuit, "
                 "protective device coordination and arc flash studies on as-built data in accordance with Section "
                 "26 05 73 POWER SYSTEM STUDIES, to set protective devices and to produce arc flash labels; the "
                 "study scope reaches every 480 V and 208 V bus of the building for the normal and the generator source."),
    "26 20 00": ("INTERIOR DISTRIBUTION SYSTEM", "Section 26 20 00 INTERIOR DISTRIBUTION SYSTEM specifies the "
                 "building's 480Y/277 V and 208Y/120 V interior distribution shown on E-601 Rev C and listed in SOW "
                 "1.3 Table 1: panelboards HM1, H1A, H2A, HE1, LP1A, LP2A, LC1 and LE1, dry-type transformers "
                 "T-1A, T-2A, T-C1 and T-E1, feeders and raceways, surge protective devices, the advanced meter and "
                 "grounding."),
    "26 24 13": ("SWITCHBOARDS", "E-601 Rev C shows the 2000 A bus, 1600 A main, 480Y/277 V service entrance "
                 "switchboard MSB in Electrical Room 118; UFC 3-520-01 paragraph 3-2.2 selects a switchboard where "
                 "the equipment is 1200 A or larger, and SOW 1.3 Table 1 lists it."),
    "26 32 15": ("ENGINE-GENERATOR SET STATIONARY 15-2500 KW, WITH AUXILIARIES",
                 "E-601 Rev C, G-001 and SOW 1.3 Table 1 include GEN-1, a 150 kW 480Y/277 V standby diesel "
                 "engine-generator in an outdoor sound-attenuated aluminium enclosure with an integral double-wall "
                 "sub-base tank, serving ATS-L (Article 700) and ATS-E (Article 702); IES-26 paragraphs 10.1 to 10.7 "
                 "and OPR Rev B paragraph 5.5 set its requirements."),
    "26 36 23": ("AUTOMATIC TRANSFER SWITCHES AND BY-PASS/ISOLATION SWITCH",
                 "E-601 Rev C and SOW 1.3 Table 1 show two 480Y/277 V automatic transfer switches supplied by GEN-1: "
                 "ATS-L 100 A on the NFPA 70 Article 700 emergency system with by-pass/isolation, and ATS-E 260 A on "
                 "Article 702 optional standby; IES-26 paragraph 10.6 and OPR Rev B paragraph 5.5 set their "
                 "configuration."),
    "26 51 00": ("INTERIOR LIGHTING", "Building 4410 is new construction with interior LED luminaires, stand-alone "
                 "localized lighting controls, building-mounted exterior wall packs on the same luminaire schedule and "
                 "exit and egress lighting on the generator emergency system (SOW 1.3 Table 1; E-501; E-601 Rev C); "
                 "IES-26 paragraphs 11.1 to 11.7 and OPR Rev B paragraph 5.6 set the lighting criteria."),
}

FINDINGS = [
    ("F-01", "BLDG4410-E_RevC.ifc (coordination model); FDB-01 Rev 1 para 6",
     "Feeder run LE1 (raceway CND-LE1-1, Trade = 1-1/4 in, EMT)",
     "The modelled raceway is too small: no CDS-7 copper conductor carries the 125 A design load of LE1 within the "
     "40 percent fill limit of IES-26 4.6 in a 1-1/4 in EMT raceway, and LE1 is an emergency-system feeder with a "
     "2 percent voltage drop allowance, so the conductor cannot be enlarged freely either.",
     "Design the LE1 feeder in 1-1/2 in EMT: 1 set of 1 AWG gives 37.7 percent fill and 0.17 percent drop, both "
     "within the limits. The larger raceway is recorded in the Feeders sheet; the 2 percent allowance is not relaxed "
     "and the fill limit is not exceeded."),
    ("F-02", "BLDG4410-E_RevC.ifc (coordination model)",
     "Distribution system E-SUPERSEDED, run CND-H2A-REVB-1 (Status = DEMOLISH)",
     "The model retains the superseded Rev B route of feeder H2A (455 ft) in a demolition-status system as well as "
     "the current 91 ft run; taking the longer route would overstate the H2A voltage drop and the conductor size.",
     "The superseded run is excluded from the routed length. The H2A route length used is the current NEW run of "
     "91.0 ft (CND-H2A-1), per FDB-01 para 2."),
    ("F-03", "BLDG4410-E_RevC.ifc with PCB-01 Rev 1 and IES-26 11.6",
     "As-modelled lighting layout, spaces 102 (Open Office A) and 116 (Communications Room), and all other spaces "
     "carrying the modelled quantities",
     "As modelled the maintained illuminance is below target in Open Office A (room 102) and in the Communications "
     "Room (116): the modelled luminaire quantities of 18 type L1 and 4 type L5 do not reach the 30 fc minimum "
     "average of IES-26 11.6 even within the 10 percent margin of error of 26 51 00.",
     "The luminaire quantities are increased: room 102 to 24 type L1 (29.7 fc average, uniformity 2.55) and room "
     "116 to 6 type L5 (30.4 fc, uniformity 1.90). The revised quantities are stated in the Photometric sheet and "
     "shall be provided."),
    ("F-04", "BLDG4410-E_RevC.ifc with IES-26 11.7",
     "Whole-building interior lighting power density of the as-modelled layout",
     "The lighting power density of the luminaire layout in the coordination model exceeds the whole-building limit "
     "of IES-26 11.7: the modelled quantities total 11.09 kW over 38,400 sq ft, which is 0.289 W/sq ft against the "
     "0.285 W/sq ft cap.",
     "Luminaire quantities are reduced to the minimum that meets each space's illuminance and uniformity criteria, "
     "giving 10.0 kW and 0.260 W/sq ft, within the cap. The quantities are stated in the Photometric sheet."),
    ("F-05", "SCB-01 Rev 1 Table 2 with Design Directive DD-03 and Utility Service Letter UP-4410 Rev 2",
     "SCB-01 Table 2, preliminary short-circuit results (35 percent design)",
     "SCB-01 Table 2 was computed on the superseded UP-4410 Rev 1 utility data (750 kVA service transformer). "
     "DD-03 records that the service transformer is now 1000 kVA per UP-4410 Rev 2 and that the Table 2 results are "
     "superseded; every short-circuit dependent rating must be updated.",
     "The study is re-run with the UP-4410 Rev 2 data (1000 kVA, Z 5.75 percent, X/R 6.5; 250 MVA at the primary). "
     "The available fault current at MSB is 17.52 kA, not the 15.6 kA of Table 2, and the ratings in the "
     "ShortCircuit sheet and in the sections follow the re-run."),
    ("F-06", "Utility Service Letter UP-4410 Rev 1 (superseded)",
     "UP-4410 Rev 1, service transformer and fault data",
     "Rev 1 is still in the documents folder and states a 750 kVA transformer with different fault data. Rev 2 "
     "states that it supersedes all previous revisions.",
     "Only UP-4410 Rev 2 is used; Rev 1 is not cited in any section and does not appear in the Register."),
    ("F-07", "OPR_Building_4410_RevA (superseded) and OPR Rev B",
     "OPR Rev A grounding electrode resistance and on-site fuel requirement",
     "OPR Rev A states a 5 ohm grounding electrode resistance limit and a shorter fuel duration; the guide "
     "specification also offers 25 ohms and a 4 hour tank. IES-26 6.1 governs at 10 ohms and OPR Rev B 5.5 "
     "requires 96 hours at full load.",
     "The project sections state 10 ohms maximum by fall-of-potential measurement and 96 hours of on-site fuel in a "
     "UL 142 double-wall sub-base tank; the superseded Rev A values and the guide specification options are deleted."),
    ("F-08", "E-501 Rev C note 8 with E-601 Rev C and E-701 Rev C",
     "E-501 Luminaire Schedule, X1/emergency note",
     "E-501 note 8 and the X1 row describe the exit and egress luminaires as a life-safety branch through ATS-E, "
     "but E-601 Rev C and E-701 put the emergency system panel LE1 on ATS-L (NFPA 70 Article 700) and make ATS-E "
     "the Article 702 optional standby switch.",
     "The exit and egress luminaires are circuited to panel LE1 supplied through ATS-L; the sections state ATS-L as "
     "the emergency system transfer switch and never assign the emergency system to ATS-E."),
    ("F-09", "IES-26 Rev 4 10.2 with OPR Rev B 5.5",
     "On-site fuel storage duration",
     "IES-26 10.2 requires 72 hours of on-site fuel as a minimum, while OPR Rev B 5.5 requires 96 hours at full load "
     "in the generator sub-base tank. SOW 1.5 makes the more stringent owner requirement govern.",
     "The tank is sized for 96 hours at full load and the NFPA 110 designation is Class 96; the 72 hour value is "
     "not stated as the project requirement."),
]


def write_workbook(path, fd, ph, steps, fc, lpd, register_rows):
    wb = Workbook()
    wb.remove(wb.active)
    ws = wb.create_sheet("Sections")
    ws.append(["number", "title", "basis"])
    for num, (title, basis) in SECTIONS.items():
        ws.append([num, title, basis])

    ws = wb.create_sheet("Feeders")
    ws.append(["feeder", "route_length_ft", "sets", "size", "raceway_in", "vd_pct", "fill_pct"])
    for tag, d in fd.items():
        ws.append([tag, d["route_length_ft"], d["sets"], d["size"], d["raceway_in"], d["vd_pct"], d["fill_pct"]])

    ws = wb.create_sheet("ShortCircuit")
    ws.append(["bus", "voltage_v", "available_fault_ka", "specified_rating_ka"])
    for bus, v in fc.items():
        ws.append([bus, v["volts"], round(v["total_ka"], 3), v["min_rating_ka"]])

    ws = wb.create_sheet("Photometric")
    ws.append(["space", "luminaire_type", "quantity", "avg_maintained_fc", "min_fc", "uniformity", "lpd_w_ft2"])
    for num, d in ph.items():
        ws.append([num, d["type"], d["qty"], round(d["avg_fc"], 2), round(d["min_fc"], 2),
                   round(d["uniformity"], 2), round(d["lpd"], 3)])

    ws = wb.create_sheet("StepLoad")
    ws.append(["step", "loads", "step_kva_start", "voltage_dip_pct", "recovery_s"])
    for s in steps["steps"]:
        ws.append([s["step"], ", ".join(s["loads"]), s["step_kva_start"], s["voltage_dip_pct"], s["recovery_s"]])

    ws = wb.create_sheet("Register")
    ws.append(["req_id", "document", "clause", "requirement", "value", "applies_to"])
    for r in register_rows:
        ws.append(r)

    ws = wb.create_sheet("Findings")
    ws.append(["finding_id", "document", "location", "defect", "correction"])
    for f in FINDINGS:
        ws.append(list(f))
    wb.save(path)


def main():
    os.makedirs(os.path.join(OUT, "specs"), exist_ok=True)
    fd = calc.feeder_design()
    sp = calc.spaces()
    ph = {}
    for s in sp:
        lt, q, r = calc.min_luminaire(s, margin=calc.MARGIN)
        ph[s["number"]] = dict(r, type=lt, qty=q)
    n, parts, steps = calc.min_steps()
    design = {t: (fd[t]["sets"], fd[t]["size"]) for t in fd}
    fc = calc.fault_currents(design)
    lpd = {"watts": sum(d["watts"] for d in ph.values()),
           "area": sum(s["w"] * s["d"] for s in sp)}
    lpd["lpd"] = lpd["watts"] / lpd["area"]
    reg = json.load(open(os.path.join(HERE, "register.json")))
    wb = os.path.join(OUT, "design_basis.xlsx")
    write_workbook(wb, fd, ph, steps, fc, lpd, reg)
    zp = os.path.join(OUT, "submission.zip")
    with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
        for f in sorted(os.listdir(os.path.join(OUT, "specs"))):
            if f.endswith(".docx"):
                z.write(os.path.join(OUT, "specs", f), f"specs/{f}")
        z.write(wb, "design_basis.xlsx")
    print("wrote", zp, os.path.getsize(zp), "bytes; LPD", round(lpd["lpd"], 4))


if __name__ == "__main__":
    main()
