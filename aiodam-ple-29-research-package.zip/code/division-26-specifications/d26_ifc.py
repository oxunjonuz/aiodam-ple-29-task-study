"""Parse BLDG4410-E_RevC.ifc: raceway runs (length, trade size, count), spaces, luminaires.
Own STEP reader, standard library only."""
import json, math, re, sys

IFC = "/work/ple-dataset/tasks/division-26-specifications/environment/filesystem/final_batch4__electrical_task8_electrical_specs__blind/50_bim/BLDG4410-E_RevC.ifc"

def load(path):
    txt = open(path, encoding="latin-1").read()
    data = txt.split("DATA;", 1)[1]
    ents = {}
    for m in re.finditer(r"#(\d+)\s*=\s*([A-Z0-9_]+)\((.*?)\);\s*(?=#\d+\s*=|ENDSEC)", data, re.S):
        ents[int(m.group(1))] = (m.group(2), m.group(3))
    return ents

def args(s):
    """split top-level comma args, respecting quotes and parens"""
    out, depth, cur, q = [], 0, [], False
    for ch in s:
        if q:
            cur.append(ch)
            if ch == "'":
                q = False
            continue
        if ch == "'":
            q = True; cur.append(ch)
        elif ch == "(":
            depth += 1; cur.append(ch)
        elif ch == ")":
            depth -= 1; cur.append(ch)
        elif ch == "," and depth == 0:
            out.append("".join(cur).strip()); cur = []
        else:
            cur.append(ch)
    out.append("".join(cur).strip())
    return out

def S(x):
    x = x.strip()
    return x[1:-1] if x.startswith("'") else None

def refs(x):
    return [int(v) for v in re.findall(r"#(\d+)", x)]

E = load(IFC)

def pt(i):
    typ, a = E[i]
    assert typ in ("IFCCARTESIANPOINT",), typ
    vals = [float(v) for v in args(a)[0].strip("()").split(",")]
    while len(vals) < 3:
        vals.append(0.0)
    return tuple(vals)

def placement_origin(i):
    """absolute origin of an IfcLocalPlacement chain (mm)"""
    typ, a = E[i]
    if typ != "IFCLOCALPLACEMENT":
        return (0.0, 0.0, 0.0)
    ar = args(a)
    rel = refs(ar[0])
    base = placement_origin(rel[0]) if rel else (0.0, 0.0, 0.0)
    ax = args(E[refs(ar[1])[0]][1])
    loc = pt(refs(ax[0])[0])
    return (base[0] + loc[0], base[1] + loc[1], base[2] + loc[2])

def polyline_points(i):
    typ, a = E[i]
    if typ == "IFCPOLYLINE":
        return [pt(r) for r in refs(args(a)[0])]
    if typ == "IFCCOMPOSITECURVE":
        out = []
        for seg in refs(args(a)[0]):
            out += polyline_points(seg)
        return out
    if typ in ("IFCTRIMMEDCURVE",):
        return polyline_points(refs(args(a)[0])[0])
    return []

def rep_items(i):
    typ, a = E[i]
    assert typ == "IFCPRODUCTDEFINITIONSHAPE", typ
    out = []
    for r in refs(args(a)[2]):
        t2, a2 = E[r]
        out.append((S(args(a2)[1]), S(args(a2)[2]), refs(args(a2)[3])))
    return out

def props_of(entity_id):
    """psets attached to an entity: {pset: {prop: value}}"""
    out = {}
    for i, (typ, a) in E.items():
        if typ != "IFCRELDEFINESBYPROPERTIES":
            continue
        ar = args(a)
        if entity_id not in refs(ar[4]):
            continue
        ps = refs(ar[5])[0]
        tp, ap = E[ps]
        name = S(args(ap)[2])
        d = {}
        for pr in refs(args(ap)[4]):
            t3, a3 = E[pr]
            if t3 != "IFCPROPERTYSINGLEVALUE":
                continue
            pn = S(args(a3)[0]); pv = args(a3)[2]
            mm = re.search(r"\(([^()]*)\)", pv)
            d[pn] = (S(pv) if pv.startswith("'") else (mm.group(1) if mm else pv))
        out[name] = d
    return out

# ---- distribution systems and their segments
sysname = {}
for i, (typ, a) in E.items():
    if typ == "IFCDISTRIBUTIONSYSTEM":
        ar = args(a)
        sysname[i] = (S(ar[2]), S(ar[5]) if len(ar) > 5 else None)
assign = {}
for i, (typ, a) in E.items():
    if typ == "IFCRELASSIGNSTOGROUP":
        ar = args(a)
        g = refs(ar[6])[0] if len(ar) > 6 else refs(ar[-1])[0]
        for m in refs(ar[4]):
            assign[m] = g

feeds = {}
for i, (typ, a) in E.items():
    if typ != "IFCCABLECARRIERSEGMENT":
        continue
    ar = args(a)
    name = S(ar[2]); tag = S(ar[7]) if len(ar) > 7 else None
    g = assign.get(i)
    sname = sysname.get(g, ("?", None))
    pl = placement_origin(refs(ar[5])[0])
    length = 0.0
    for (rep, ctx, items) in rep_items(refs(ar[6])[0]):
        if rep == "Axis":
            for it in items:
                p = polyline_points(it)
                for a1, a2 in zip(p, p[1:]):
                    length += math.dist(a1, a2)
    st = props_of(i)
    status = None
    for k, d in st.items():
        if "Status" in d:
            status = d["Status"]
    feeds.setdefault((sname[0], sname[1]), []).append(
        {"name": name, "tag": tag, "len_mm": round(length, 1), "status": status, "origin": pl})

if __name__ == "__main__":
    print("=== systems ===")
    for k in sorted(feeds, key=lambda x: str(x)):
        segs = feeds[k]
        rw = {}
        for s in segs:
            key = "-".join(s["name"].split("-")[:-1])
            rw.setdefault(key, []).append(s)
        print(f"{k}: {len(segs)} segments, raceways {len(rw)}")
        for r, ss in sorted(rw.items()):
            tot = sum(s["len_mm"] for s in ss) / 304.8
            sts = {s["status"] for s in ss}
            tags = {s["tag"] for s in ss}
            print(f"   {r:22s} trades={tags} segs={len(ss)} length={tot:8.2f} ft status={sts}")


# ============================== spaces and luminaires ==============================
def space_geom(i):
    """(w_ft, d_ft, ceiling_ft, x_ft, y_ft, origin_z_mm) for an IfcSpace"""
    typ, a = E[i]
    ar = args(a)
    origin = placement_origin(refs(ar[5])[0])
    rep = rep_items(refs(ar[6])[0])
    for (rname, ctx, items) in rep:
        if rname != "Body":
            continue
        for it in items:
            t2, a2 = E[it]
            if t2 != "IFCEXTRUDEDAREASOLID":
                continue
            prof = refs(args(a2)[0])[0]
            depth = float(args(a2)[3])
            tp, ap = E[prof]
            pa = args(ap)
            w = float(pa[3]) / 304.8
            d = float(pa[4]) / 304.8
            # profile placement inside the extrusion gives the space's own offset
            axp = args(E[refs(pa[2])[0]][1])
            off = pt(refs(axp[0])[0])
            return (w, d, depth / 304.8, (origin[0] + off[0]) / 304.8, (origin[1] + off[1]) / 304.8,
                    origin[2] / 304.8)
    return None


def dump_spaces():
    out = []
    for i, (typ, a) in E.items():
        if typ != "IFCSPACE":
            continue
        ar = args(a)
        num, name = S(ar[2]), S(ar[7])
        g = space_geom(i)
        if not g:
            continue
        w, d, ceil, x, y, z0 = g
        pset = props_of(i)
        lux = None
        for k, dd in pset.items():
            if "Illuminance" in dd:
                lux = dd["Illuminance"]
        out.append({"number": num, "name": name, "w": round(w, 2), "d": round(d, 2),
                    "ceiling": round(ceil, 2), "x": round(x, 2), "y": round(y, 2), "z0": round(z0, 2), "lux": lux})
    lums = {}
    for i, (typ, a) in E.items():
        if typ != "IFCLIGHTFIXTURE":
            continue
        ar = args(a)
        nm = S(ar[2]); otype = S(ar[4]); tag = S(ar[8]) if len(ar) > 8 else None
        org = placement_origin(refs(ar[5])[0])
        parts = nm.split("-")
        sp = parts[1] if len(parts) > 1 else "?"
        lums.setdefault(sp, []).append({"name": nm, "type": otype or tag,
                                        "x": round(org[0] / 304.8, 2), "y": round(org[1] / 304.8, 2),
                                        "z": round(org[2] / 304.8, 2)})
    for s in out:
        L = lums.get(s["number"], [])
        s["n_lums"] = len(L)
        s["lums"] = L
        s["lum_types"] = sorted({l["type"] for l in L})
        s["lum_z"] = sorted({l["z"] for l in L})
    return out
