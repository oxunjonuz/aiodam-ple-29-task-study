"""build_pkg.py - stage 1 packer: design_basis.xlsx (7 sheets, required headers) + specs/*.docx -> submission.zip"""
import json, os, zipfile
import openpyxl

OUT = "/work/ple-solve/division-26-specifications/build/stage1"
MAN = json.load(open(os.path.join(OUT, "specs_manifest.json")))

BASIS = {
    "26 05 73": "SOW 3.5 requires the Contractor to perform construction-phase short-circuit, protective device coordination and arc flash studies on as-built data per Section 26 05 73.",
    "26 20 00": "Section 26 20 00 specifies the building's 480Y/277 V and 208Y/120 V interior distribution shown on E-601 Rev C and listed in SOW 1.3 Table 1.",
    "26 24 13": "E-601 Rev C shows the 2000 A, 480Y/277 V service entrance switchboard MSB in Electrical Room 118; UFC 3-520-01 3-2.2 selects a switchboard for equipment 1200 A and larger.",
    "26 32 15": "E-601 Rev C, G-001 and SOW 1.3 Table 1 include GEN-1, a 150 kW 480Y/277 V standby diesel engine-generator with sub-base tank serving ATS-L and ATS-E.",
    "26 36 23": "E-601 Rev C and SOW 1.3 Table 1 show ATS-L 100 A (Article 700) and ATS-E 260 A (Article 702) supplied by GEN-1.",
    "26 51 00": "Building 4410 is new construction with interior LED luminaires, local lighting controls, exterior wall packs and exit/emergency lighting on the generator emergency system (SOW 1.3 Table 1; E-501; E-601 Rev C).",
}
HEADERS = {
    "Sections": ["number", "title", "basis"],
    "Feeders": ["feeder", "route_length_ft", "sets", "size", "raceway_in", "vd_pct", "fill_pct"],
    "ShortCircuit": ["bus", "voltage_v", "available_fault_ka", "specified_rating_ka"],
    "Photometric": ["space", "luminaire_type", "quantity", "avg_maintained_fc", "min_fc", "uniformity", "lpd_w_ft2"],
    "StepLoad": ["step", "loads", "step_kva_start", "voltage_dip_pct", "recovery_s"],
    "Register": ["req_id", "document", "clause", "requirement", "value", "applies_to"],
    "Findings": ["finding_id", "document", "location", "defect", "correction"],
}

wb = openpyxl.Workbook()
wb.remove(wb.active)
for name, cols in HEADERS.items():
    ws = wb.create_sheet(name)
    ws.append(cols)
    if name == "Sections":
        for num, m in MAN.items():
            ws.append([num, m["title"], BASIS.get(num, "")])
xb = os.path.join(OUT, "design_basis.xlsx")
wb.save(xb)

zp = os.path.join(OUT, "submission.zip")
with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
    for f in sorted(os.listdir(os.path.join(OUT, "specs"))):
        if f.endswith(".docx"):
            z.write(os.path.join(OUT, "specs", f), f"specs/{f}")
    z.write(xb, "design_basis.xlsx")
print(zp, os.path.getsize(zp), "bytes")
