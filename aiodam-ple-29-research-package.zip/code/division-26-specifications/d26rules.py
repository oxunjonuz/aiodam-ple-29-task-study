"""d26rules.py - per-section project tailoring rules (see d26build.Sec for the operations)."""
from __future__ import annotations

import re

# SOW 3.6 Table 2 reviewer codes, most specific first
SUB_CODE = {
    r"^power system studies": "AE",
    r"^load flow": "AE",
    r"^fault current": "AE",
    r"^system coordination": "AE",
    r"^arc flash": "AE",
    r"^coordination": "AE",
    r"^seismic": "AE",
    r"^photometric": "AE",
    r"^luminaire drawings": "AE",
    r"^lighting control": "AE",
    r"^short.?circuit": "AE",
    r"^factory test": "DO",
    r"^engine-generator set": "DO",
    r"^assembled engine-generator set": "DO",
    r"^automatic transfer switch": "DO",
    r"^switchboard": "DO",
}


# ============================================================ 26 05 73 POWER SYSTEM STUDIES
def rules_260573(s):
    s.rewrite("The power system covered by this specification consists of",
              "The power system covered by this specification consists of the pad-mounted service transformer of Utility Service Letter UP-4410 Rev 2, a 1000 kVA "
              "480Y/277 V unit with 250 MVA available at the transformer primary and an X/R of 12; the service "
              "conductors to the main switchboard MSB; the switchboard MSB; the 480Y/277 V panelboards HM1, H1A, H2A "
              "and HE1; the 480Y/277 V automatic transfer switches ATS-L and ATS-E; the dry-type transformers T-1A, "
              "T-2A, T-C1 and T-E1; the 208Y/120 V panelboards LP1A, LP2A, LC1 and LE1; and the standby "
              "engine-generator set GEN-1.")
    s.replace("with a minimum of 3 years of experience", "with a minimum of 5 years of experience")
    # --- scope of studies: the project scope, not the facility-level option
    s.rewrite("The scope of the studies must begin at the source bus",
              "The scope of the studies must begin at the secondary terminals of the utility service transformer and "
              "extend through every 480 V and 208 V bus of the building, down to the individual protective devices of "
              "every panelboard: the switchboard MSB, the 480Y/277 V panelboards HM1, H1A, H2A and HE1, the automatic "
              "transfer switches ATS-L and ATS-E, and the 208Y/120 V panelboards LP1A, LP2A, LC1 and LE1, for the "
              "normal source and for the generator source.")
    s.replace("Perform power system studies to demonstrate the system operation with regard to ratings, coordination, "
              "protection, and Arc Flash Hazard.", "")
    s.rewrite("incorporate all existing and new equipment",
              "In the systems model for the studies, incorporate all new equipment within the scope of the studies. "
              "Incorporate the engine-generator set GEN-1 as an additional source and the motor loads of the mechanical "
              "equipment schedule M-601 as load equipment.")
    s.rewrite("Determine and document the time-current characteristics",
              "Determine and document the time-current characteristics, features, ratings, ampacities, and nameplate "
              "data for each new protective device, electrical equipment, and feeder cable. Obtain the available fault "
              "current from the owner of the source bus; the available fault current at the service transformer primary "
              "is 250 MVA at an X/R of 12, per Utility Service Letter UP-4410 Rev 2. For multiple modes of operation, "
              "use the mode with the available fault current that produces the greatest incident energy in the arc "
              "flash hazard study.")
    s.rewrite("The naming of existing components",
              "The naming of new components within the system model and single line diagram must use unique "
              "identifiers and be coordinated with the Government.")
    s.rewrite("Include a narrative describing the studies performed",
              "Include a narrative describing the studies performed; the bases and methods used; and the desired "
              "method of coordinated protection of the power system. Include the generator resistance and reactance "
              "data of the engine-generator set GEN-1, and the motor locked-rotor data of the mechanical equipment "
              "schedule M-601, in the model and in the report.")
    s.rewrite("Include descriptive and technical data for existing devices",
              "Include descriptive and technical data for the new protective devices proposed, with manufacturers' "
              "published data, nameplate data, and the definition of the fixed or adjustable features of each device.")
    s.rewrite("Document utility company data including system voltages",
              "Document utility company data including system voltages, fault MVA, system X/R ratio, time-current "
              "characteristic curves, current transformer ratios, and relay device numbers and settings. Identify all "
              "assumptions about the protection devices, equipment, and system where data was not available.")
    s.rewrite("For each bus in the system, provide fully coordinated",
              "For each bus in the system, provide fully coordinated composite time-current characteristics (TCC) "
              "curves as required to ensure coordinated power system protection between protective devices and "
              "equipment. In a tabular format, provide the recommended ratings and settings of all protective devices.")
    # --- arc flash study: the 8 cal/cm2 design goal of UFC 3-501-01 3-2.6 h
    s.rewrite("Perform the arc flash hazard study in accordance with IEEE 1584.1",
              "Perform the arc flash hazard study in accordance with IEEE 1584.1. Utilize the data from the fault "
              "current study to determine the worst case incident energy per IEEE 1584. Use identified modes of "
              "operation to determine the worst case arc flash energy. Where the calculated incident energy exceeds "
              "8 cal/cm2, provide recommendations to reduce the arc flash energy to 8 cal/cm2 or less, and identify "
              "the locations where it cannot be achieved. The design goal is an incident energy of 8 cal/cm2 or less "
              "at every location where work may be performed on energized equipment.")
    s.rewrite("Model existing electrical equipment",
              "Develop a software model of the electrical system identified in the scope of the studies. Use the "
              "latest version of SKM PowerTools. Develop the model with accurate, verified information, and model the "
              "new electrical equipment, machines, devices, and conductors directly connected to, altered by, or "
              "otherwise affected by the work, including generators, transformers, switchboards, panelboards, motors, "
              "circuit breakers, switches, fuses, conductors and the grounding system.")
    s.rewrite("The System Verifier may inspect and record settings",
              "The System Verifier may inspect and record settings and markings and otherwise document the equipment. "
              "The System Verifier must not make any calibrations or adjustments or place equipment into service. When "
              "working with energized equipment, the System Verifier must be a Qualified Person per NFPA 70E or work "
              "under the direct supervision of a Qualified Person.")
    s.drop_phrases(["document the existing equipment", "existing and new equipment", "each existing protective device",
                    "naming of existing components", "existing devices and new protective devices",
                    "existing or new protective devices", "for existing devices", "existing power system data",
                    "existing and recommended ratings", "model existing electrical equipment"])
    return s


# ============================================================ 26 20 00 INTERIOR DISTRIBUTION SYSTEM
def rules_262000(s):
    # ---- delete what the project does not have (SOW 1.3 Table 1) and what IES-26 prohibits
    for kw in ["Residential Load Centers", "BUSWAY", "CABLE TRAYS", "MOTOR CONTROL CENTERS", "HAZARDOUS LOCATIONS"]:
        s.drop_article(kw)
    for kw in ["Liquid-Tight Flexible Nonmetallic Conduit", "Surface Nonmetallic Raceway",
               "Aluminum Conductors", "Nonmetallic Sheathed Cable", "Metal-Clad Cable", "Armored Cable",
               "Wire and Cable for 400 Hertz", "400 Hz Panelboard and Breakers",
               "Branch Circuit Monitoring Panelboards", "Lighting Control Panelboards",
               "CATV Outlets", "CATV Faceplates", "Community Antenna Television",
               "Hazardous Locations", "Busway Installation", "Cable Tray Installation",
               "Metal-Clad Cable", "Armored Cable", "Nonmetallic Sheathed Cable Installation",
               "Conduit Interior to Buildings for 400 Hz Circuits",
               "Splices of Aluminum Conductors", "Terminating Aluminum Conductors",
               "Termination to Aluminum Bus"]:
        s.drop_sub(kw)
    s.drop_article("METER BASE ONLY")
    s.drop_text("prisoner")
    s.drop_text("high leg")
    s.drop_text("four-wire delta")
    s.drop_text("FOR DELTA CONNECTIONS")
    s.drop_text("rated 10 kVA and less")
    s.drop_text("Unventilated type")
    s.drop_text("unventilated")
    # ---- 1.8 SEISMIC REQUIREMENTS: delegated design to Section 26 05 48
    s.rewrite("Seismic", "Seismic restraint of electrical equipment is a Contractor delegated design prepared by a "
              "registered professional engineer and reviewed by the Designer of Record, and must be provided in "
              "accordance with Section 26 05 48 SEISMIC PROTECTION FOR ELECTRICAL EQUIPMENT. Components of the "
              "emergency system that are designated seismic systems have a component importance factor Ip of 1.5.")
    s.drop_text("existing panels modified")
    s.drop_text("Terminate aluminum conductors to copper bus")
    s.rewrite("Maximum resistance-to-ground of grounding system",
              "Maximum resistance-to-ground of the grounding electrode system: do not exceed 10 ohms, measured by the "
              "fall-of-potential method. Where the measured resistance exceeds 10 ohms, provide additional electrodes "
              "until the value is met and notify the Contracting Officer.")
    s.rewrite("Do not exceed 25 ohms under normally dry conditions",
              "Provide ground rods of copper-clad steel, 3/4 inch by 10 feet, and measure the resistance to ground by "
              "the fall-of-potential method of IEEE 81. Do not exceed 10 ohms under normally dry conditions.")
    s.rewrite("Perform the standard and optional tests in accordance with the Inspection and Test Procedures",
              "Perform the standard and optional tests of transformers, dry type, air-cooled, 600 volt and below, as "
              "specified in NETA ATS, by a recognized independent NETA-accredited testing organization with a NETA "
              "Level III lead technician. Acceptance tests must not be performed by the installing contractor.")
    s.rewrite("Overhead service conductors into buildings",
              "Overhead service conductors into buildings: terminate at service entrance fittings or a weatherhead "
              "outside the building. The primary service to the building is underground and is furnished by the "
              "utility; the secondary service conductors from the pad-mounted transformer to the switchboard MSB are "
              "provided under this section, in six 4 inch PVC Schedule 40 ducts encased in concrete.")
    # ---- project product requirements
    s.append("PANELBOARDS", "Provide panelboards with copper bus, door-in-door hinged trim, and bolt-on circuit "
             "breakers. The minimum short-circuit current rating must be 18000 A symmetrical at 480 V for the "
             "480Y/277 V panelboards HM1, H1A, H2A and HE1, and 10000 A symmetrical at 208 V for the 208Y/120 V "
             "panelboards LP1A, LP2A, LC1 and LE1.")
    s.append("PANELBOARDS", "Provide lock-on (handle-locking) devices on the circuit breakers that protect fire "
             "protection and life safety circuits, and identify those circuit breakers in red. Provide nameplates "
             "inscribed FIRE PROTECTION/LIFE SAFETY EQUIPMENT, red with white center core, on panelboards LE1 and "
             "T-E1 and on the dry-type transformers and transfer switches that supply them.")
    s.append("Insulation", "Provide copper conductors only. Feeder conductors: Type XHHW-2 copper. Branch-circuit "
             "conductors: Type THHN/THWN-2 copper. Aluminum conductors are not permitted anywhere in the project.")
    s.append("Color Coding", "Identify the neutral conductor of 480Y/277 V systems in gray and the neutral conductor "
             "of 208Y/120 V systems in white.")
    s.append("Bonding Conductors", "Size the equipment grounding conductor of a feeder the same size as the phase "
             "conductor where the phase conductor is smaller than 250 kcmil, and one size smaller in the CDS-7 size "
             "list where the phase conductor is 250 kcmil or larger. Where a phase conductor is increased in size for "
             "voltage drop, increase the equipment grounding conductor by the same rule.")
    s.append("TRANSFORMERS", "Dry-type transformers: 80 degrees C rise with an overload capability of 130 percent for "
             "the 115 percent nominal rating. Transformer T-C1 must be K-13 rated for the nonlinear electronic loads "
             "of the Communications Room 116 and must have a sound level 3 dB below the NEMA ST 20 values, and it "
             "must have an overload capability of 115 percent at 130 percent of rating.")
    s.append("TRANSFORMERS", "112.5 kVA T-1A: 98.99 percent minimum efficiency. 75 kVA T-2A: 98.88 percent "
             "minimum efficiency. Both values apply at 35 percent of rating in accordance with 10 CFR 431.")
    s.append("SURGE PROTECTIVE DEVICES", "Provide a service entrance surge protective device at switchboard MSB and a "
             "cascaded downstream surge protective device at panelboard LC1. Provide each unit with a surge counter "
             "and Form C dry contacts, and a surge life greater than 5000 surges at Category C3 at the service "
             "entrance and at Category B3 at the branch panelboard. List the total unit as installed to UL 1283 and "
             "to UL 1449. The downstream unit at LC1 must have a surge current rating of 20000 A per mode. Coordinate "
             "the surge protective device with the lightning protection system of NFPA 780.")
    s.append("INSTALLATION", "Provide a ground ring (counterpoise) of bare copper conductor at 30 in depth, 3 ft "
             "outside the building foundation, bonded to the electrical grounding electrode system, and interconnect "
             "all grounding media so that the building has a common ground potential. The water service is HDPE and "
             "is not used as a grounding electrode.")
    s.drop_text("all existing wiring to be reused must also be tested")
    s.rewrite("Ground connection at main service equipment",
              "Provide the grounding electrode conductor from the grounding electrode system to the main service "
              "equipment. The water service of this building is HDPE and is not a grounding electrode; do not make "
              "any connection to a water pipe. The grounding electrode system consists of the concrete-encased "
              "electrode, the ground ring and the copper-clad steel ground rods.")
    s.drop_text("Two pole arc-fault circuit-interrupters")
    s.drop_text("Provide watthour meter designed for use on a single-phase, three-wire")
    s.rewrite("Maximum L-N, and N-G voltage protection rating",
              "Maximum L-N and N-G voltage protection rating of each surge protective device must be 700 V for the "
              "480Y/277 V system and 500 V for the 208Y/120 V system, at a nominal discharge current of 20 kA.")
    s.drop_text("Meter Base Only")
    s.drop_text("Form: 2S, accuracy")
    s.dropm(r"^[\d,]+V\b.*(single phase|three phase)")
    s.dropm(r"^[a-f]\.\s*Maximum L-[LN]")
    s.append("MAINTENANCE", "Submit operation and maintenance data in accordance with Section 01 78 23 OPERATION AND "
             "MAINTENANCE DATA, and Army facility data in accordance with Section 01 78 24.00 10 FACILITY DATA "
             "REQUIREMENTS.")
    return s


# ============================================================ 26 32 15 ENGINE-GENERATOR SET
def rules_263215(s):
    for kw in ["Parallel Operation", "Load Sharing", "SYNCHRONIZING PANEL", "PYROMETER",
               "Station Battery System", "Day Tank"]:
        s.drop_article(kw)
    for kw in ["Parallel Operation Test", "Automatic Paralleling and Loading", "Pneumatic Starting System",
               "Fuel Transfer Pump", "Capacity, Prime", "Capacity, Standby",
               "Pneumatic", "Air Driven Motors", "Cylinder Injection", "Shell and U-Tube Type Heat Exchanger",
               "Auxiliary Systems Drawing Requirements", "Prime Rated Sets"]:
        s.drop_sub(kw)
    s.drop_text("fuel transfer pumps may be mounted")
    s.drop_text("day tank with the capacity")
    # ---- site conditions
    s.rewrite("Site Location: Site Elevation",
              "Site Location: Fort Calder, Georgia. Site elevation: 300 feet above mean sea level. Ambient "
              "temperatures: maximum 97 degrees F dry bulb, 78 degrees F wet bulb; minimum 18 degrees F dry bulb. "
              "Design wind velocity: 115 mph. Seismic design category D, component importance factor Ip = 1.5 for "
              "the engine-generator set as a designated seismic system.")
    # ---- parameter schedule and ratings
    s.append("Engine-Generator Parameter Schedule",
             "Engine-generator set GEN-1: diesel, standby rating 150 kW at 0.8 power factor (187.5 kVA), 480Y/277 V, "
             "3 phase, 4 wire, 60 Hz, 1800 rpm, 226 A at the standby rating, sub-base fuel tank integral with the "
             "enclosure, sound-attenuated aluminium enclosure for outdoor installation.")
    s.rewrite("engine burning diesel fuel conforming to MIL-DTL-16884",
              "The engine rating must be based on ultra-low-sulfur No. 2 diesel fuel in accordance with ASTM D975 "
              "Grade 2-D at the site conditions of paragraph SITE CONDITIONS.", count=5)
    s.rewrite("uninterrupted 4-hour period",
              "Each tank must have capacity as shown to supply fuel to the engine for an uninterrupted 96 hour period "
              "at 100 percent rated load without being refilled.")
    s.rewrite("reactive droop compensation",
              "Provide voltage regulation such that the reactive load is shared proportionally between sets only where "
              "sets operate in parallel; this project has a single engine-generator set and no parallel operation.")
    s.append("COOLING SYSTEM", "Design the radiator and the cooling system for an ambient temperature of 97 degrees F "
             "maximum, and for the maximum recorded ambient of 38 degrees C.")
    s.rewrite("The voltage and frequency behavior of the generator set must be in accordance with ISO 8528",
              "The voltage and frequency behavior of the generator set must be in accordance with ISO 8528 operating "
              "limit values for performance class G2.")
    s.append("Performance Class", "The transient voltage dip must not exceed 15 percent of rated voltage, the set must "
             "recover to within 2 percent of rated voltage within 3 seconds of the step, and the transient frequency "
             "deviation must not exceed 5 percent of rated frequency, on any step of the step-load sequence.")
    s.rewrite("Upon receipt of a signal to start",
              "Upon receipt of a signal to start, the engine-generator set must start, reach rated frequency and "
              "voltage and be ready to assume load within 10 seconds. The set is NFPA 110 Type 10, Level 1, Class 96 "
             "for the NFPA 70 Article 700 loads served through ATS-L.")
    # ---- sound
    s.append("SOUND LIMITATIONS", "The sound pressure level of the complete packaged unit must not exceed 72 dBA, "
             "measured at a distance of 23 ft from the enclosure in a free field, at 100 percent load.")
    # ---- enclosure
    s.append("Engine-Generator Set Enclosure", "Provide an outdoor, sound-attenuated aluminium enclosure with an "
             "integral double-wall sub-base fuel tank and leak detection.")
    # ---- emissions
    s.append("EMISSIONS", "The engine must be an EPA-certified emergency stationary compression-ignition engine "
             "in accordance with 40 CFR 60 Subpart IIII, covered by the installation air permit; no project air "
             "permit is required and no on-site emissions test is required. Submit the EPA engine certificate to the "
             "installation environmental office.")
    # ---- remote annunciator
    s.append("PANELS", "Provide a remote alarm annunciator at the Staff Duty desk in Room 101, configured for the two "
             "transfer switches ATS-L and ATS-E.")
    # ---- fuel
    s.append("Integral Main Fuel Storage Tank", "Provide a UL 142 double-wall sub-base fuel tank integral with the "
             "generator skid, with leak detection, sized for 96 hours of engine-generator set operation at full load. "
             "The NFPA 110 class designation is Class 96.")
    s.append("FUEL SYSTEM", "Fuel: ultra-low-sulfur No. 2 diesel in accordance with ASTM D975 Grade 2-D. Biodiesel "
             "and biodiesel blends are not permitted. The integral sub-base tank is the only fuel storage on the "
             "project; no day tank is provided.")
    # ---- starting system
    s.append("STARTING SYSTEM", "Provide a 24 volt DC electric starting system with two lead-acid batteries and a "
             "float charger, capable of continuous cranking of the engine at an ambient temperature of 18 degrees F.")
    # ---- testing
    s.append("Installation", "Perform a 4 hour resistive load bank test at 100 percent of the nameplate kW rating, "
             "and record the transient voltage dip, the recovery time and the frequency deviation of every step of "
             "the step-load sequence.")
    # ---- warranty and training
    s.add_article(1, "WARRANTY", ["Provide a minimum replacement warranty of 5 years on the engine-generator set and "
                                  "its auxiliary equipment, approved by the Contracting Officer."])
    s.append("ONSITE TRAINING", "The training period must consist of a total 8 hours of onsite training of Government "
             "personnel in the operation and maintenance of the engine-generator set.")
    # ---- seismic, without the UFC citation
    s.rewrite("Seismic requirements must be in accordance with UFC 3-301-01",
              "Seismic requirements must be in accordance with Sections 13 48 73 SEISMIC CONTROL FOR NONSTRUCTURAL "
              "COMPONENTS, 23 05 48.19 SEISMIC BRACING FOR MECHANICAL SYSTEMS and 26 05 48 SEISMIC PROTECTION FOR "
              "ELECTRICAL EQUIPMENT as shown on the drawings. The engine-generator set is a designated seismic "
              "system with a component importance factor Ip of 1.5.")
    # ---- grounding acceptance value
    s.drop_text("Single rod electrode")
    s.rewrite("resistance to solid earth ground",
              "Ground the system in accordance with NFPA 70 and IEEE C2, except that the grounding electrode system "
              "must have a resistance to solid earth ground not exceeding 10 ohms, measured by the fall-of-potential "
              "method. Where the measured value exceeds 10 ohms, provide additional electrodes until the value is met.")
    s.drop_text("are specified in Section 33 56 10 FACTORY-FABRICATED FUEL STORAGE TANKS")
    s.drop_text("Provide the fuel supply from the main storage of fuel to the day tank")
    s.rewrite("Make joints in grounding conductors by exothermic weld",
              "Make joints in grounding conductors by exothermic weld or compression connector. Install them in "
              "accordance with NFPA 70.")
    s.rewrite("Provide driven ground rods as specified in",
              "Provide driven ground rods of copper-clad steel, 3/4 inch by 10 feet. Connect ground conductors to the "
              "upper end of the ground rods by exothermic weld or compression connector, and provide compression "
              "connectors at the equipment end of the ground conductors.")
    s.drop_text("Multiple rod electrodes")
    s.drop_text("Ground mat")
    # ---- NFPA 110 level
    s.rewrite("Provide starting system for standby engine generator sets",
              "Provide the starting system for the standby engine-generator set in accordance with NFPA 110, Type 10, "
              "Level 1, Class 96, and as follows.")
    s.rewrite("Provide a local alarm panel with the following shutdown and alarm functions",
              "Provide a local alarm panel with the following shutdown and alarm functions in accordance with NFPA 110 "
              "Level 1, mounted either on or adjacent to the engine-generator set.")
    s.drop_phrases(["limited running time", "for prime rated units", "provide prime engine-generator sets",
                    "overload capacity (prime applications only)", "zinc coated or phosphatized and shop primed",
                    "remote radiator construction", "raw-water", "medium-voltage cable", "aeic cs8",
                    "station battery system", "8-hour rate", "method 7", "tier 4 final",
                    "provide on-site testing by a certified testing organization",
                    "floor plan arrangement of", "california scaqmd",
                    "separate self-supporting", "remote fuel transfer pump", "parallel operation",
                    "load sharing", "load share", "infinite bus", "isolated bus", "synchroscope",
                    "synchronizing panel", "station battery system", "pyrometer", "transfer pump"])
    return s


# ============================================================ 26 51 00 INTERIOR LIGHTING
def rules_265100(s):
    for kw in ["Luminaire Samples", "Luminaires for Hazardous Locations", "Luminaire Conversion Kits",
               "Linear LED Lamps", "Remote LED Drivers", "Centralized Control Systems", "Lighting Relay Panel",
               "Lighting Control Panel", "Gateway", "Lighting Contactor", "Local Area Controller",
               "Exit Signs with Battery Backup", "Central Emergency Lighting System", "Mini Inverters",
               "Photometric Plan", "Computer-generated Photometric Plans",
               "Schematic Photometric Plan Calculations", "Final Photometric Plan Calculations",
               "ANSI/IES TM-30 Test Report", "Exit Signs with Battery Backup"]:
        s.drop_sub(kw)
    # ---- light sources: 3500 K, CRI 80, no TM-30 criteria
    s.rewrite("CEC Title 20",
              "Provide LED light sources that meet the following requirements:")
    s.rewrite("Emit white light and have a nominal CCT of 3000 Kelvin",
              "Emit white light with a nominal correlated color temperature of 3500 Kelvin and a minimum color "
              "rendering index of 80, in accordance with NEMA ANSLG C78.377.", count=5)
    s.dropm(r"^Fidelity index|^minimum color rendering index .*tm-30|gamut index")
    s.drop_text("Fidelity index")
    s.drop_text("Minimum Color Rendering Index (CRI) of 80. Fidelity index")
    # ---- luminaire efficacy, wet location, BUG
    s.append("LUMINAIRES", "Luminaire efficacy: troffers 120 lm/W minimum, linear ambient luminaires 120 lm/W "
             "minimum, downlights 90 lm/W minimum, in accordance with the FEMP-designated levels of IES-26 11.2.")
    s.append("LUMINAIRES", "Building-mounted exterior luminaires are type W1 LED wall packs, listed for wet "
             "locations and with a BUG rating of B1-U0-G1.")
    s.rewrite("The combined driver and LED light source system does not exceed the minimum luminaire efficacy",
              "The combined driver and light source system must meet the minimum luminaire efficacy values listed in "
              "the luminaire schedule and in this section.")
    s.drop_text("does not exceed the minimum luminaire efficacy")
    # ---- drivers: 0-10 V dimming to 10 percent, integral
    s.rewrite("Provide dimming capability as indicated in the luminaire schedule",
              "Provide dimming capability as indicated in the luminaire schedule. Dimmable drivers must dim down to "
              "10 percent of light output and must be controlled by a Class 2 low-voltage 0-10 VDC controller. All "
              "interior drivers are integral with the luminaire.")
    # ---- controls: localized, daylight harvesting, UL 924 relay override
    s.append("LIGHTING CONTROLS", "Provide stand-alone localized room controls: wall-box dimmers, occupancy/vacancy "
             "sensors and photosensors, with no networked, centralized or building-automation connection. Provide "
             "daylight-responsive dimming in the offices on the south and east facades.")
    s.append("LIGHTING CONTROLS", "Provide UL 924 listed relays that force full light output on loss of normal power "
             "for the corridor egress luminaires that are on room controllers.")
    s.append("INSTALLATION", "Circuit the exit signs and the egress luminaires to the emergency panelboard LE1, which "
             "is supplied through ATS-L on the NFPA 70 Article 700 emergency system. Provide the 90 minute emergency "
             "operation required by NFPA 101.")
    s.append("INSTALLATION", "Anchor and brace luminaires and their supports for Seismic Design Category D in "
             "accordance with Section 26 05 48 SEISMIC PROTECTION FOR ELECTRICAL EQUIPMENT.")
    # ---- warranty
    s.replace("Occupancy/Vacancy Sensor Coverage Layout; G, ROS", "Occupancy/Vacancy Sensor Coverage Layout; G, RO")
    s.append("Luminaire Warranty", "Provide a minimum replacement warranty of 10 years on the LED luminaires and "
             "drivers, covering 100 percent of the cost of replacement parts and labour.")
    # ---- O&M data
    s.append("OPERATION AND MAINTENANCE MANUALS", "Submit operation and maintenance data in accordance with Section "
             "01 78 23 OPERATION AND MAINTENANCE DATA, and Army facility data in accordance with Section "
             "01 78 24.00 10 FACILITY DATA REQUIREMENTS.")
    s.drop_phrases(["additional requirements for the navy", "01 78 24.00 20", "photometric plan", "tm-30",
                    "fidelity index", "gamut index", "color maintenance value", "cec title", "chicago plenum",
                    "luminaire samples", "conversion kit", "linear led lamp", "hazardous locations", "ul 844",
                    "hazardous (classified)", "remote led driver", "remote driver", "centralized lighting control",
                    "lighting relay panel", "lighting control panel", "lighting contactor", "gateway", "bacnet",
                    "23 09 23", "central emergency lighting system", "central power system", "central inverter",
                    "free-standing cabinet with floor stand", "exit signs with battery backup", "photoluminescent",
                    "fused disconnect switch", "ahead of the local switch", "ats-e", "energy star label"])
    return s


# ============================================================ 26 24 13 SWITCHBOARDS
def rules_262413(s):
    for kw in ["Fusible Switches", "Integral Combination Breaker and Current-Limiting Fuses", "Heaters",
               "Additional Design Tests", "Submetering", "Digital Meters"]:
        s.drop_sub(kw)
    s.rewrite("Voltage rating: 480Y/277 volts AC, three-phase, 3-wireas indicated",
              "Voltage rating 480Y/277 V AC, three-phase, 4-wire, solidly grounded neutral. Continuous current rating "
              "of the main bus: 2000 amperes. Main device: 1600 ampere insulated-case circuit breaker. Short-circuit "
              "current rating: 18000 amperes rms symmetrical at 480 V. Insulated-case circuit breaker interrupting "
              "rating: 18000 amperes rms symmetrical at 480 V. UL listed and labeled as service entrance equipment.")
    s.rewrite("Enclosure: NEMA ICS 6 Type 3R",
              "Enclosure: NEMA ICS 6 Type 1, for indoor installation in the conditioned Electrical Room 118. "
              "Switchboard sections: bolted together, with hinged front doors, devices front accessible and "
              "completely isolated between sections by vertical steel barriers.")
    s.rewrite("Provide the main section consisting",
              "Provide the main section with an individually mounted 1600 ampere insulated-case main circuit breaker "
              "with an electronic trip unit, and distribution sections with the molded-case circuit breakers "
              "indicated. No fusible devices are used.")
    s.append("Electronic Trip Units", "Provide arc energy reduction capability with an energy-reducing maintenance "
             "switch with local status indicator on the main breaker, and ground-fault protection settings with a "
             "trip setting coordinated with the 480 V feeders.")
    s.rewrite("Design: Provide meter designed for use on a 3-phase, 4-wire, 208Y/120 volt system",
              "Provide an advanced electric meter at the switchboard: 480Y/277 V, three-phase 4-wire "
              "transformer-rated socket meter, ANSI Form 9S, ANSI C12.20 accuracy class 0.2, with test switch, "
              "15-minute interval demand data, and Modbus TCP communication to the installation meter data "
              "management system. Current transformers: ratio 1500/5, burden B-0.9, accuracy class 0.3. No other "
              "remote communication from the switchboard is provided.", count=3)
    s.append("SERVICE ENTRANCE AVAILABLE FAULT CURRENT LABEL",
             "Provide a field-fabricated label at the service entrance stating the available fault current and the "
             "date of the short-circuit calculation on which the rating is based.")
    s.append("SWITCHBOARD", "Provide a service entrance surge protective device (SPD-1) at switchboard MSB, mounted "
             "adjacent to the switchboard with a maximum lead length of 3 ft.")
    s.append("WARRANTY", "Provide 4 hours of training of Government personnel in the operation and maintenance of the "
             "switchboard, by a qualified instructor.")
    s.replace("Request for Settings", "Required Settings")
    s.drop_text("Submit request for settings of breakers")
    s.replace("in accordance with Government provided settings", "in accordance with the approved settings of the "
              "Contractor's power system studies")
    s.rewrite("NFPA 70 and IEEE C2, except that grounds and grounding systems",
              "Ground the switchboard in accordance with NFPA 70 and IEEE C2. The grounding electrode system "
              "resistance must not exceed 10 ohms measured by the fall-of-potential method.")
    s.drop_text("Provide driven ground rods as specified in Section 33 71 02")
    s.drop_text("Provide bare copper cable not smaller than No. 4/0 AWG")
    s.drop_text("Install exothermic welds and compression connectors as specified in Section 33 71 02")
    s.replace("are specified in Section 33 71 02 UNDERGROUND ELECTRICAL DISTRIBUTION, and Section 26 20 00 "
              "INTERIOR DISTRIBUTION SYSTEM", "are specified in Section 26 20 00 INTERIOR DISTRIBUTION SYSTEM")
    s.replace("three-phase, 3-wireas indicated", "three-phase, 4-wire, solidly grounded neutral, as indicated")
    s.drop_phrases(["fusible switch", "current-limiting fuse", "fuses", "fuse information", "fuse and circuit breaker",
                    "enclosure: nema ics 6 type 3r", "sloping roof", "vault handles", "stainless steel",
                    "galvanized steel", "c57.12.28",
                    "plus or minus 1.0 percent", "dnp3", "rs485", "rs232", "rs-232", "rs-485", "modbus rtu",
                    "twisted pair", "iec 61850",
                    "temperature rise test", "for navy installations", "26 27 14.00 20", "26 27 13.10 30",
                    "16000 volts", "tape wrap", "insulating sleeve", "astm d149", "heater", "humidistat",
                    "request for settings", "government provided settings", "additional design tests"])
    return s


# ============================================================ 26 36 23 AUTOMATIC TRANSFER SWITCHES
def rules_263623(s):
    for kw in ["Factory Testing -Medical Facilities", "Remote Annunciator and Control System Panel"]:
        s.drop_article(kw)
    for kw in ["Controls for Fire Pump Service", "Closed-Transition Transfer Switch",
               "Delayed Transition With Time Delay Neutral",
               "Make Before Break Neutral", "Auxiliary Contact for Uninterruptible Power Supply"]:
        s.drop_sub(kw)
    s.rewrite("Voltage: volts ac. Amperage: amps ac",
              "Voltage: 480Y/277 V AC, three-phase, 4-wire, 60 Hz. Amperage: ATS-L 100 A; ATS-E 260 A. Poles: Four "
              "switched; one of the poles is the neutral. ATS withstand current rating, UL 1008 close and withstand: "
              "ATS-L 14000 A rms symmetrical at 480 V; ATS-E 18000 A rms symmetrical at 480 V.")
    s.append("AUTOMATIC TRANSFER SWITCHES", "Provide two transfer switches: ATS-L, 100 A, serving the NFPA 70 "
             "Article 700 emergency system loads, and ATS-E, 260 A, serving the NFPA 70 Article 702 optional standby "
             "loads. Provide a by-pass/isolation switch integral with ATS-L only. Both switches are open transition "
             "with an in-phase monitor. Factory set the transfer time delay of ATS-E, the optional standby switch, to "
             "30 seconds after ATS-L transfers.")
    s.rewrite("Provide remote annunciation with LED indicating lights",
              "Provide remote annunciation with LED indicating lights, an audible alarm with silence switch and all "
              "appropriate labelling, at the Staff Duty desk in Room 101. The annunciator must be configured to "
              "handle 2 transfer switches, ATS-L and ATS-E.")
    s.drop_sub("Remote Annunciator and Control System Panel")
    s.replace("The annunciator must be configured to handle 2 transfer switches, ATS-L and ATS-E.",
              "The annunciator must serve both transfer switches, ATS-L and ATS-E.")
    s.append("FIELD FABRICATED NAMEPLATES", "Provide nameplates for the emergency and standby transfer switches with "
             "white letters on a red background.")
    s.append("SEISMIC REQUIREMENTS", "Provide seismic details conforming to Section 13 48 73 SEISMIC CONTROL FOR "
             "NONSTRUCTURAL COMPONENTS. ATS-L is part of a designated seismic system with a component importance "
             "factor Ip of 1.5.")
    s.add_article(1, "WARRANTY", ["Provide a minimum replacement warranty of 5 years on the automatic transfer "
                                  "switches and the by-pass/isolation switch, approved by the Contracting Officer."])
    s.drop_phrases(["include this paragraph on navy projects",
                    "applies to this section, with the additions and modifications specified herein",
                    "service entrance rated", "ats is the service disconnect", "fire pump service", "viewing ports",
                    "medical facilities", "section 21 30 00 fire pumps",
                    "medical facilities", "ieee 602", "nfpa 20", "nfpa 99", "cataloged product in accordance with "
                    "section 26 20 00", "aluminum conductors", "copper or aluminum", "copper and aluminum",
                    "aluminum or copper", "closed-transition", "make-before-break", "momentary interconnection",
                    "three switched", "two switched", "3-pole", "three-pole", "2-pole", "208 vac", "208 volts ac",
                    "withstand ratings at 208"])
    return s


RULES = {
    "26 05 73": rules_260573,
    "26 20 00": rules_262000,
    "26 32 15": rules_263215,
    "26 51 00": rules_265100,
    "26 24 13": rules_262413,
    "26 36 23": rules_263623,
}
