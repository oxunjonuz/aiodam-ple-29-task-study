"""d26sec.py - convert a UFGS SpecsIntact .SEC guide specification into a project .docx section.

The guide text is kept; what the editor would do by hand is done here:
  * editor notes (NTE/NPR), asterisk rules and header tables are dropped;
  * every bracketed option is resolved or deleted, and every blank filled (or its sentence dropped);
  * articles are renumbered as literal text (PART n, article n.m, paragraph n.m.k), lists get literal markers;
  * references are reduced to the publications the section actually cites;
  * a project tailoring pass (in d26tail.py) then edits the text for this project.
"""
from __future__ import annotations

import os, re, sys
import xml.etree.ElementTree as ET

HERE = os.path.dirname(os.path.abspath(__file__))
WS = "/work/ple-dataset/tasks/division-26-specifications/environment/filesystem/final_batch4__electrical_task8_electrical_specs__blind"
SEC_DIR = os.path.join(WS, "20_guide_specifications", "UFGS_Division_26_SpecsIntact")

DROP = {"NTE", "NPR", "AST", "HDR", "MTA", "HL4", "BRL", "BRK", "WBK", "TAB", "TDA", "ROW", "CEL", "COL",
        "DTA", "STS", "TBL", "TNOTE", "GFI", "SPT_", "MTA"}


class Block:
    def __init__(self, kind, **kw):
        self.kind = kind
        self.__dict__.update(kw)

    def __repr__(self):
        return f"<{self.kind} {self.__dict__}>"


def first_char(e):
    if e.text and e.text.strip():
        return e.text.strip()[0]
    for ch in e:
        c = first_char(ch)
        if c:
            return c
    return ""


def text_of(el) -> str:
    out = []

    def walk(e):
        if e.tag == "BRK":
            out.append(" ")
        if e.text:
            out.append(e.text)
        for ch in e:
            if ch.tag not in DROP:
                if out and e.tag != "BRK" and re.search(r"[A-Za-z0-9]$", "".join(out[-1:]) or "") and re.match(r"[A-Za-z]", first_char(ch) or ""):
                    out.append(" ")
                walk(ch)
            if ch.tail:
                if out and ch.tail and out[-1] and re.search(r"[A-Za-z0-9]$", out[-1]) and re.match(r"[A-Za-z0-9]", ch.tail):
                    out.append(" ")
                out.append(ch.tail)
    walk(el)
    return re.sub(r"\s+", " ", "".join(out)).strip()


def refs_of(el):
    out, rid, rtl = [], None, ""
    for ch in el:
        if ch.tag == "RID":
            if rid:
                out.append((rid, rtl))
            rid, rtl = text_of(ch), ""
        elif ch.tag == "RTL":
            rtl = text_of(ch)
    if rid:
        out.append((rid, rtl))
    return out


def parse(sec_path):
    root = ET.parse(sec_path).getroot()
    num = title = date = ""
    blocks = []
    st = {"part": 0, "art": 0, "sub": 0}

    def emit_body(el):
        """walk the children of an article or numbered paragraph"""
        for ch in el:
            tag = ch.tag
            if tag in ("TTL", "NTE") or tag in DROP:
                continue
            if tag == "SPT":
                st["sub"] += 1
                blocks.append(Block("sub", num=f'{st["part"]}.{st["art"]}.{st["sub"]}',
                                    title=text_of(ch.find("TTL")) if ch.find("TTL") is not None else ""))
                emit_body(ch)
            elif tag == "TXT":
                blocks.append(Block("text", text=text_of(ch)))
            elif tag in ("LST", "OLG"):
                blocks.append(Block("list", level=1, text=text_of(ch)))
                emit_body_lists(ch, 2)
            elif tag in ("ITM", "OLI"):
                blocks.append(Block("list", level=2, text=text_of(ch)))
            elif tag == "REF":
                blocks.append(Block("ref", org=text_of(ch.find("ORG")) if ch.find("ORG") is not None else "",
                                    entries=refs_of(ch)))
            else:
                s = text_of(ch)
                if s:
                    blocks.append(Block("text", text=s))

    def emit_body_lists(el, level):
        for ch in el:
            if ch.tag in ("LST", "OLG"):
                blocks.append(Block("list", level=level, text=text_of(ch)))
                emit_body_lists(ch, level + 1)
            elif ch.tag in ("ITM", "OLI"):
                blocks.append(Block("list", level=level, text=text_of(ch)))
                emit_body_lists(ch, level)

    for ch in root:
        tag = ch.tag
        if tag == "SCN":
            num = text_of(ch)
        elif tag == "STL":
            title = text_of(ch)
        elif tag == "DTE":
            date = text_of(ch)
        elif tag == "PRT":
            m = re.search(r"[123]", text_of(ch.find("TTL")))
            st.update({"part": int(m.group(0)), "art": 0, "sub": 0})
            blocks.append(Block("part", num=st["part"], title=text_of(ch.find("TTL"))))
            for x in ch:
                if x.tag in ("TTL", "NTE") or x.tag in DROP:
                    continue
                if x.tag == "SPT":
                    st["art"] += 1
                    st["sub"] = 0
                    blocks.append(Block("article", num=f'{st["part"]}.{st["art"]}',
                                        title=text_of(x.find("TTL")) if x.find("TTL") is not None else ""))
                    emit_body(x)
                else:
                    s = text_of(x)
                    if s:
                        blocks.append(Block("text", text=s))
    return num, title, date, blocks


# ------------------------------------------------------------------ bracket resolution
def resolve_brackets(s: str, fill=None) -> str:
    """`fill` maps the exact bracket content to the project value; everything else keeps its first alternative."""
    if fill:
        for k, v in fill.items():
            s = s.replace("[" + k + "]", "\x01" + v + "\x01")
    prev = None
    while prev != s:                       # "[A][B][C]" -> "[A]"
        prev = s
        s = re.sub(r"\[([^\[\]]*)\]\[([^\[\]]*)\]", r"[\1]", s)
    s = s.replace("[_____]", "\x00").replace("_____", "\x00")
    prev = None
    while prev != s:                       # remaining single group -> keep its content
        prev = s
        s = re.sub(r"\[([^\[\]]*)\]", r"\1", s)
    s = s.replace("\x01", "")
    return s


def tidy(s: str) -> str:
    """clean up after resolved brackets and dropped blanks"""
    s = re.sub(r"\s*\x00\s*", " ", s)
    s = re.sub(r"\s+([,.;:])", r"\1", s)
    s = re.sub(r"([,;:])\s*([,.;:])", r"\1", s)
    s = re.sub(r"\(\s*[,;:]?\s*\)", "", s)
    s = re.sub(r"\[\s*\]", "", s)
    s = s.replace("[", "").replace("]", "")
    s = re.sub(r"\s{2,}", " ", s)
    return s.strip(" ,;")


if __name__ == "__main__":
    n, t, d, blocks = parse(os.path.join(SEC_DIR, "26 05 73.SEC"))
    print(n, "|", t, "|", d, "|", len(blocks))
    for b in blocks[:30]:
        print("   ", b)
