import json, os
G = "/work/ple-dataset/tasks/division-26-specifications/tests/corrino/electrical_task8_electrical_specs/grading"
m = json.load(open(os.path.join(G, "data", "master_index.json")))
for k in ("26 36 23", "26 51 00"):
    print("==", k)
    for s in m[k]["non_army_tailoring"]:
        print("   ", s)
