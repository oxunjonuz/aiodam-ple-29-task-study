"""verify_494.py - independent checks of the division-26 package, without the grader's code.

1. the zip members and the workbook read back with openpyxl (a second reader than the one that wrote it)
2. every docx parsed with ElementTree (not my writer) and the required markers re-found
3. every feeder's voltage drop and raceway fill recomputed here from CDS-7 / RDS-1 / IES-26 and compared with
   the workbook, and the photometric sheet recomputed with the .ies tables
4. a sample of Register values checked against the source documents' text
"""
import math, os, re, sys, zipfile
import xml.etree.ElementTree as ET
from openpyxl import load_workbook

HERE = "/work/ple-solve/division-26-specifications"
ZP = os.path.join(HERE, "build", "stage2", "submission.zip")
WS = "/work/ple-dataset/tasks/division-26-specifications/environment/filesystem/final_batch4__electrical_task8_electrical_specs__blind"
sys.path.insert(0, HERE)
import d26calc as calc

ok = True


def check(cond, msg):
    global ok
    print(("  PASS  " if cond else "  FAIL  ") + msg)
    if not cond:
        ok = False


print("== 1. package members ==")
z = zipfile.ZipFile(ZP)
names = z.namelist()
print("  ", names)
check("design_basis.xlsx" in names, "design_basis.xlsx at the package root")
specs = [n for n in names if n.startswith("specs/") and n.endswith(".docx")]
check(len(specs) == 6, f"six section docx under specs/ ({len(specs)})")
check(all(not n.startswith("specs/specs") for n in names), "no nested duplicate folder")

print("== 2. every docx re-parsed with ElementTree ==")
W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
import io
for n in sorted(specs):
    inner = zipfile.ZipFile(io.BytesIO(z.read(n)))
    root = ET.fromstring(inner.read("word/document.xml"))
    paras = ["".join(t.text or "" for t in p.iter(W + "t")) for p in root.iter(W + "p")]
    paras = [p for p in paras if p.strip()]
    num = next((p for p in paras if p.upper().startswith("SECTION ")), "")
    parts = [p for p in paras if re.match(r"^PART [123]\b", p)]
    arts = [p for p in paras if re.match(r"^[123]\.\d+ [A-Z]", p)]
    check(bool(re.match(r"^SECTION \d\d \d\d \d\d", num)), f"{n}: SECTION line {num!r}")
    check(len(parts) == 3, f"{n}: three PART headings {parts}")
    check(paras[-1].startswith("-- End of Section --"), f"{n}: end marker {paras[-1]!r}")
    check(len(arts) >= 5, f"{n}: {len(arts)} articles, first {arts[:2]}")
    bad = [p for p in paras if re.search(r"[\[\]]|_{3,}", p)]
    check(not bad, f"{n}: no bracket or blank left ({len(bad)} hits)")

print("== 3. workbook read back and recomputed ==")
wb = load_workbook(__import__("io").BytesIO(z.read("design_basis.xlsx")), data_only=True)
sheets = {ws.title: [list(r) for r in ws.iter_rows(values_only=True)] for ws in wb.worksheets}
check(set(sheets) == {"Sections", "Feeders", "ShortCircuit", "Photometric", "StepLoad", "Register", "Findings"},
      f"seven sheets {sorted(sheets)}")
rows = sheets["Feeders"][1:]
worst_vd = worst_fill = 0.0
for r in rows:
    tag = r[0]
    sets, size = int(r[2]), str(r[3])
    L = calc.geometry_feeder(tag)["length_ft"]
    vd = calc.vd_pct(tag, sets, size, L)
    fill = calc.fill_pct(tag, sets, size, float(r[4]))
    worst_vd = max(worst_vd, abs(vd - float(r[5])))
    worst_fill = max(worst_fill, abs(fill - float(r[6])))
    limit = 2.0 if tag in calc.EMERGENCY_FEEDERS else 3.0
    check(vd <= limit + 1e-9 and fill <= 40 + 1e-9 and sets * calc.CONDUCTOR[size][3] >= calc.FDB[tag][3],
          f"  {tag:9s} {sets}x{size:>4s} in {r[4]} in: VD {vd:5.2f}% <= {limit}  fill {fill:5.1f}% <= 40")
check(worst_vd < 0.01 and worst_fill < 0.01, f"reported VD/fill agree with the recomputation "
      f"(max diff {worst_vd:.2e} %, {worst_fill:.2e} %)")

ph = sheets["Photometric"][1:]
sp = {s["number"]: s for s in calc.spaces()}
worst = 0.0
for r in ph:
    s = sp[str(r[0])]
    res = calc.photometry(s, str(r[1]), int(r[2]))
    worst = max(worst, abs(res["avg_fc"] - float(r[3])))
    okc, _ = calc.space_ok(s, str(r[1]), int(r[2]))
    check(okc, f"  space {r[0]:4s} {r[1]} n={r[2]:3d}: {res['avg_fc']:6.2f} fc avg, U {res['uniformity']:.2f}")
check(worst < 0.01, f"reported illuminance agrees with the recomputation (max diff {worst:.3f} fc)")
watts = sum(int(r[2]) * calc.WATTS[str(r[1])] for r in ph)
area = sum(s["w"] * s["d"] for s in sp.values())
check(watts / area <= calc.LPD_CAP, f"building LPD {watts/area:.4f} W/sq ft <= {calc.LPD_CAP}")

steps = sheets["StepLoad"][1:]
seq = [[t.strip() for t in str(r[1]).split(",")] for r in steps]
sim = calc.simulate_steps(seq)
check(sim["feasible"], f"declared step sequence feasible ({len(seq)} steps, max dip {sim['max_dip_pct']} %)")
dipdiff = max(abs(s["voltage_dip_pct"] - float(r[3])) for s, r in zip(sim["steps"], steps))
check(dipdiff < 1e-6, f"reported dips agree with the recomputation ({dipdiff:.2e})")

print("== 4. Register values against the source documents ==")
import subprocess


def pdftext(name):
    out = subprocess.run(["pdftotext", "-layout", os.path.join(WS, name), "-"], capture_output=True)
    return out.stdout.decode("latin-1")


probes = [
    ("UP-4410_Utility_Service_Letter_Rev2.pdf", "40_studies", ["250 MVA", "1000 kVA", "5.75"]),
    ("GEN-1_Engine-Generator_Data_Sheet.pdf", "40_product_data", ["150 kW", "187.5 kVA", "0.12"]),
    ("IES-26_Fort_Calder_Installation_Electrical_Design_Standard_Rev4.pdf", "01_owner",
     ["0.285", "72 dBA", "23 ft", "10 ohms", "15 percent"]),
    ("SCB-01_Short-Circuit_Study_Basis_Rev1.pdf", "40_studies", ["14, 18, 22, 25, 35, 42, 50, 65, 85, 100"]),
    ("CDS-7_Copper_Conductor_Data_Sheet.pdf", "40_product_data", ["0.0181", "0.3904", "2.000"]),
    ("RDS-1_Raceway_Data_Sheet.pdf", "40_product_data", ["14.753", "1.496"]),
    ("FDB-01_Feeder_Design_Basis_Rev1.pdf", "40_studies", ["41.9", "0.4359"] if False else ["0.4359", "1250"]),
]
for fname, folder, needles in probes:
    t = pdftext(os.path.join(folder, fname))
    for nd in needles:
        check(nd.lower() in t.lower(), f"{fname}: {nd!r} found in the document")

# OPR and SOW are docx
import zipfile as _zip


def docx_text(path):
    zz = _zip.ZipFile(path)
    root = ET.fromstring(zz.read("word/document.xml"))
    return " ".join("".join(t.text or "" for t in p.iter(W + "t")) for p in root.iter(W + "p"))


for f, needles in [("01_owner/OPR_Building_4410_RevB.docx", ["96 hours", "Room 101", "10 years", "5 years",
                                                              "bypass-isolation", "3500 K"]),
                   ("00_contract/SOW_W912XX-27-C-0418_AE_Scope_of_Work_Electrical.docx",
                    ["5 years", "G,", "AE", "DO", "RO"])]:
    t = docx_text(os.path.join(WS, f))
    for nd in needles:
        check(nd.lower() in t.lower(), f"{os.path.basename(f)}: {nd!r} found")

print()
print("RESULT:", "all checks pass" if ok else "FAILURES ABOVE")
sys.exit(0 if ok else 1)
