#!/usr/bin/env python3
"""Number audit: every figure in the note must be derivable from the record or from the recomputation.

A different mechanism from checks.py: it does not look for phrases at all. It pulls every
number out of the rendered note and asks whether that number exists in the files on the file
server (all of them, text-extracted) or is one of the recomputed values in computed.json.
Anything else is reported with its context.

    python3 audit_numbers.py out/note_pdf.txt [--control]
"""
from __future__ import annotations

import csv
import json
import re
import sys
from pathlib import Path

BASE = Path("/work/ple-dataset/tasks/les-mesh-resolution/environment/files")
C = json.loads(Path("/work/les/computed.json").read_text())


def norm(t: str) -> str:
    t = t.replace("\u00b3", "3").replace("\u00b2", "2")
    t = t.replace("\u2013", "-").replace("\u2014", "-").replace("\u2212", "-")
    t = re.sub(r"-\s*\n\s*", "", t)
    return re.sub(r"\s+", " ", t)


def canon(v: str) -> str:
    """canonical form of a numeric token: no thousands separators, trailing zeros kept."""
    return v.replace(",", "").replace(" ", "")


def extract_numbers(text: str) -> list[tuple[str, str]]:
    out = []
    for m in re.finditer(r"\d{1,3}(?:,\d{3})+(?:\.\d+)?|\d+(?:\.\d+)?", text):
        tok = m.group(0)
        ctx = text[max(0, m.start() - 55):m.end() + 20]
        out.append((tok, ctx))
    return out


def record_corpus() -> set[str]:
    """every numeric token in every file on the file server, canonically."""
    nums: set[str] = set()
    docs = []

    def add(t: str) -> None:
        for m in re.finditer(r"\d{1,3}(?:,\d{3})+(?:\.\d+)?|\d+(?:\.\d+)?", t):
            nums.add(canon(m.group(0)))
            # a space-grouped thousands form ("11 214 862") also counts as its joined value
            nums.add(canon(m.group(0)).rstrip("."))

    for p in sorted(BASE.rglob("*")):
        if not p.is_file():
            continue
        suf = p.suffix.lower()
        try:
            if suf == ".pdf":
                import pymupdf
                d = pymupdf.open(p)
                docs.append("\n".join(pg.get_text() for pg in d))
            elif suf == ".docx":
                import docx
                d = docx.Document(p)
                parts = [q.text for q in d.paragraphs]
                for t in d.tables:
                    for row in t.rows:
                        parts.append(" ".join(c.text for c in row.cells))
                docs.append("\n".join(parts))
            elif suf == ".xlsx":
                import openpyxl
                wb = openpyxl.load_workbook(p, data_only=True)
                parts = []
                for ws in wb.worksheets:
                    for row in ws.iter_rows(values_only=True):
                        parts.append(" ".join(str(v) for v in row if v is not None))
                docs.append("\n".join(parts))
            elif suf in (".txt", ".csv", ".eml", ".json", ".md"):
                docs.append(p.read_text(errors="replace"))
            elif suf == ".fcstd":
                continue
        except Exception as exc:                     # a file the audit cannot read is stated, not ignored
            print(f"  [audit] could not read {p.name}: {exc}")
    joined = norm("\n".join(docs))
    # space-grouped thousands ("11 214 862") -> also their joined form
    for m in re.finditer(r"\d{1,3}(?: \d{3})+", joined):
        nums.add(m.group(0).replace(" ", ""))
    add(joined)
    return nums


def recomputed() -> dict[str, str]:
    """the values this analysis computed, in the form the note prints them."""
    vals = {
        "3.742": C["Dstar_3dp"], "3.7423": C["Dstar_m"], "3.74": C["Dstar_reported"],
        "29.94": round(C["index"], 2), "29.9": C["index_1dp"], "29.938": round(C["index"], 3),
        "0.125": C["dx_fire"], "0.1246": C["dx_fire_minvol_4dp"], "0.001936": C["min_vol_fine"],
        "2.81": C["probe_height_2dp"], "27.09": round(C["ratio"], 2), "27.08": C["ratio_record"],
        "2450": C["zone_vol_by_cells"][0], "2455": C["zone_vol_by_cells"][1], "2454": C["zone_vol_by_cells"][2],
        "2453": round(C["zone_vol_mean"]), "3.61": C["zone_r_min_in_domain_2dp"],
        "16.7": C["zone_r_if_h_is_probe_1dp"], "5.6": C["zone_r_over_segment_1dp"],
        "30.08": round(C["index_with_record_D"], 2), "30.1": C["index_with_record_D_1dp"],
        "7.52": C["index_on_background"], "3.0": C["index_over_band_1dp"],
    }
    return {k: str(v) for k, v in vals.items()}


def audit(path: Path) -> tuple[int, list]:
    text = norm(path.read_text(errors="replace"))
    corpus = record_corpus()
    mine = set(recomputed())
    # physical constants this note uses, each with an external source (not project data):
    # 101 325 Pa = 1 standard atmosphere, 10th CGPM 1954 -- src_cb451907e479
    constants = {"101325"}
    rows, unknown = [], []
    for tok, ctx in extract_numbers(text):
        c = canon(tok)
        if c in corpus or c in mine or c in constants or c.rstrip("0").rstrip(".") in corpus or c in ("1", "2", "3", "4", "5"):
            rows.append((tok, "record" if c in corpus else "recomputed", ctx))
            continue
        unknown.append((tok, ctx))
    return len(rows), unknown


def main() -> int:
    path = Path(sys.argv[1])
    ok, unknown = audit(path)
    print(f"numeric tokens resolved: {ok}")
    print(f"unresolved: {len(unknown)}")
    for tok, ctx in unknown[:25]:
        print(f"  {tok!r:>12}  ...{ctx}...")
    if "--control" in sys.argv:
        # the audit must not be vacuous: three invented numbers, injected into a copy
        import tempfile
        t = norm(path.read_text(errors="replace"))
        t2 = t.replace("2,450", "2,477").replace("3.61", "3.93").replace("101,325", "98,742")
        with tempfile.NamedTemporaryFile("w", suffix=".txt", delete=False) as fh:
            fh.write(t2)
            tmp = Path(fh.name)
        _, ctrl = audit(tmp)
        print(f"\ncontrol (three numbers replaced): {len(ctrl)} unresolved")
        for tok, ctx in ctrl[:6]:
            print(f"  {tok!r:>12}  ...{ctx}...")
        if len(ctrl) < 3:
            print("CONTROL FAILED: the audit did not notice invented numbers")
            return 1
    return 0 if not unknown else 1


if __name__ == "__main__":
    sys.exit(main())
