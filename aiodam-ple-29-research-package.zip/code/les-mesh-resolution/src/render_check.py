#!/usr/bin/env python3
"""Nothing lost in the render: every paragraph and table cell of the docx must survive into the
PDF text twin the judge reads, and the rendering must not put text outside the page margins.

    python3 render_check.py out/CFDME-2025-041_resolution_note_revA.docx out/note_pdf.txt
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

import docx


def norm(t: str) -> str:
    t = t.replace("\u00b3", "3").replace("\u00b2", "2")
    t = t.replace("\u2013", "-").replace("\u2014", "-").replace("\u2212", "-")
    t = re.sub(r"-\s*\n\s*", "-", t)          # a compound split at a line end stays whole
    return re.sub(r"\s+", " ", t).strip()


def main() -> int:
    d = docx.Document(sys.argv[1])
    pdf = norm(Path(sys.argv[2]).read_text(errors="replace"))
    units = [p.text for p in d.paragraphs]
    for t in d.tables:
        for row in t.rows:
            for c in row.cells:
                units.append(c.text)
    units = [norm(u) for u in units if norm(u)]
    missing = [u for u in units if u not in pdf]
    # a paragraph split across a page break still appears, but with a hyphen or a space inserted:
    def loose(u: str) -> bool:
        parts = [p for p in re.split(r"\s+", u) if p]
        return all(p in pdf for p in parts) if parts else True
    missing_soft = [u for u in missing if not loose(u)]
    print(f"docx text units: {len(units)}   missing from the PDF text: {len(missing)} (loosely: {len(missing_soft)})")
    for u in missing_soft[:5]:
        print("  MISSING:", u[:160])
    print(f"pdf chars {len(pdf)}")
    return 0 if not missing_soft else 1


if __name__ == "__main__":
    sys.exit(main())
