#!/usr/bin/env python3
"""Build the LES resolution note (CFDME-2025-041, rev A) from computed.json.

Every number in the document is interpolated from the recomputation in compute.py;
nothing numeric is typed here except the fixed document furniture (dates, section
numbers, standard section references).
"""
from __future__ import annotations

import json
import os
from pathlib import Path

import docx
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.shared import Pt, Inches, RGBColor

MUTATIONS = {
    # M01 the record's own slip: dividing by the background cell
    "M01": [("0.125 m", "0.500 m")],
    "M02": [("3.74 m", "3.76 m")],
    "M03": [("the band is not met", "the band is met"),
            ("criterion is therefore not met", "criterion is therefore met"),
            ("The plume resolution criterion is not met", "The plume resolution criterion is met"),
            ("and it is not the quantity", "and it is the quantity")],
    "M04": [("rests on the resolved turbulent kinetic energy criterion alone",
             "rests on the plume resolution criterion alone")],
    "M05": [("requires no escalation to you as Reviewing Engineer", "requires escalation to you as Reviewing Engineer")],
    "M06": [("neither its radius nor its height", "both its radius and its height")],
    "M07": [("are reference-atmosphere values", "are site design values"),
            ("standard reference-atmosphere conditions", "standard site design conditions")],
    "M08": [("cannot be evaluated from the files on the file server", "can be evaluated from the files on the file server")],
    "M09": [("remains open", "can now be closed")],
    "M10": [("Mixed-convection LES setup memo", "setup record")],
    "M11": [("without any new simulation run", "only after a new simulation run")],
    "M12": [("No ruling from you as Reviewing Engineer is needed", "A ruling from you as Reviewing Engineer is needed")],
    "M13": [("does not apply to Phase 1 rev B", "applies to Phase 1 rev B")],
    "M14": [("29.9", "7.5")],
    "M15": [("101,325 Pa", "101,325")],
    "M16": [("2.81 m", "3.76 m")],
    "M17": [("two additional snappy refinement levels", "one additional snappy refinement level"),
            ("0.125 m", "0.250 m")],
    "M18": [("84 %", "72 %")],
    "M19": [("5 to 10", "5 to 40")],
    "M20": [("10/10/2025", "10/11/2025")],
}
MUT = os.environ.get("MUT", "")


def mut(text):
    for a, b in MUTATIONS.get(MUT, []):
        text = text.replace(a, b)
    return text


C = json.loads(Path("/work/les/computed.json").read_text())
OUT = Path("/work/les/out/CFDME-2025-041_resolution_note_revA.docx")


def f(x, nd=0):
    """Number with thousands separators."""
    if nd:
        return f"{x:,.{nd}f}"
    return f"{x:,.0f}"


n = {
    "Q_MW": f"{C['Q_MW_study']:.1f}",
    "rho": f"{C['rho_inf']:.3f}",
    "T": f"{C['T_inf_K']:.2f}",
    "cp": f"{C['cp_inf']:.0f}",
    "g": f"{C['g']:.2f}",
    "ratio": f"{C['ratio']:.2f}",
    "ratio_rec": f"{C['ratio_record']:.2f}",
    "D3": f"{C['Dstar_3dp']:.3f}",
    "D2": f"{C['Dstar_reported']:.2f}",
    "D_rec": f"{C['claimed_Dstar_m']:.2f}",
    "D_rec_to_D": f"{C['ratio_to_D']:.3f}",
    "dx_bg": f"{C['dx_bg_fine']:.3f}",
    "dx_fire": f"{C['dx_fire']:.3f}",
    "dx_minvol": f"{C['dx_fire_minvol_4dp']:.4f}",
    "minvol": f"{C['min_vol_fine']:.6f}",
    "zone_cells": f(C["grids"][2]["zone_cells"]),
    "zone_cells_1": f(C["grids"][0]["zone_cells"]),
    "zone_cells_2": f(C["grids"][1]["zone_cells"]),
    "v1": f(C["zone_vol_by_cells"][0], 0),
    "v2": f(C["zone_vol_by_cells"][1], 0),
    "v3": f(C["zone_vol_by_cells"][2], 0),
    "vmean": f(C["zone_vol_mean"], 0),
    "index": f"{C['index_1dp']:.1f}",
    "index_2dp": f"{C['index']:.2f}",
    "index_recD": f"{C['index_with_record_D_1dp']:.1f}",
    "index_rec": f"{C['claimed_index_rounded']:.1f}",
    "index_rec2": f"{C['claimed_index']:.2f}",
    "index_bg": f"{C['index_on_background']:.2f}",
    "over": f"{C['index_over_band_1dp']:.1f}",
    "band_lo": f"{C['band_lo']:.0f}",
    "band_hi": f"{C['band_hi']:.0f}",
    "pope": f"{C['pope_fine']*100:.0f}",
    "pope_min": f"{C['pope_min']*100:.0f}",
    "probe_h": f"{C['probe_height_2dp']:.2f}",
    "probe_factor": f"{C['probe_factor']:.2f}",
    "r_min": f"{C['zone_r_min_in_domain_2dp']:.2f}",
    "r_disc": f"{C['zone_r_if_h_is_probe_1dp']:.1f}",
    "r_over_seg": f"{C['zone_r_over_segment_1dp']:.1f}",
    "seg": f"{C['segment_m']:.1f}",
    "site_lo": f"{C['site_T_lo_C']:.0f}",
    "site_hi": f"{C['site_T_hi_C']:.0f}",
    "met_hot": f(C["met_hot_hours"]),
    "met_max": f"{C['met_Tmax_C']:.1f}",
    "met_rows": f(C["met_rows"]),
    "elev": f"{C['nominal_elev_m']:.0f}",
    "rho_wind": f"{C['nominal_density_wind']:.1f}",
    "p_ref": f(C["press_ref_Pa"]),
    "prod_cells": f(C["prod_cells"]),
    "levels": f"{C['levels_above_bg']:.0f}",
    "domain_top": f"{C['domain_top_m']:.0f}",
    "I": f(C["I_kW_m"]),
}

doc = docx.Document()

# page and base style
sec = doc.sections[0]
sec.top_margin = Inches(0.8)
sec.bottom_margin = Inches(0.8)
sec.left_margin = Inches(0.9)
sec.right_margin = Inches(0.9)
st = doc.styles["Normal"]
st.font.name = "Calibri"
st.font.size = Pt(10.5)
st.paragraph_format.space_after = Pt(5)
st.paragraph_format.line_spacing = 1.05


def para(text, bold=False, size=None, space_after=5, align=None, italic=False, style=None):
    p = doc.add_paragraph(style=style)
    r = p.add_run(mut(text))
    r.bold = bold
    r.italic = italic
    if size:
        r.font.size = Pt(size)
    p.paragraph_format.space_after = Pt(space_after)
    if align is not None:
        p.alignment = align
    return p


def head(text):
    p = doc.add_paragraph()
    r = p.add_run(mut(text))
    r.bold = True
    r.font.size = Pt(11.5)
    p.paragraph_format.space_before = Pt(10)
    p.paragraph_format.space_after = Pt(3)
    return p


def bullet(text, lead=None):
    p = doc.add_paragraph(style="List Bullet")
    if lead:
        r = p.add_run(mut(lead))
        r.bold = True
    p.add_run(mut(text))
    p.paragraph_format.space_after = Pt(2)
    return p


def table(rows, widths=None, header=True, size=9.5):
    t = doc.add_table(rows=0, cols=len(rows[0]))
    t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, row in enumerate(rows):
        cells = t.add_row().cells
        for j, val in enumerate(row):
            cells[j].text = ""
            p = cells[j].paragraphs[0]
            r = p.add_run(mut(str(val)))
            r.font.size = Pt(size)
            if header and i == 0:
                r.bold = True
            p.paragraph_format.space_after = Pt(0)
            if widths:
                cells[j].width = Inches(widths[j])
    doc.add_paragraph().paragraph_format.space_after = Pt(2)
    return t


# ------------------------------------------------------------------ letterhead
para("THE CFD ME  |  Tucson, Arizona  |  CFDME-2025-041 rev A", bold=True, size=9.5,
     align=WD_ALIGN_PARAGRAPH.LEFT, space_after=2)
para("MEMORANDUM — LES RESOLUTION BASIS", bold=True, size=15, space_after=8)

table([
    ["To", "Marguerite Falk, PE — Technical Director & Reviewing Engineer (AZ PE #42798)"],
    ["From", "Gordon Selby, PE — Owner & Principal Engineer (AZ PE #48213)"],
    ["Project", "CFDME-2025-041 — Ocotillo WUI Wildfire, Phase 1"],
    ["Deliverable under review", "Phase 1 Report rev B; peer-review checklist Item 4 (resolution basis), currently open"],
    ["Date", "10/10/2025"],
    ["Subject", "The plume resolution index on the fine grid of the three-grid study, and what the resolution "
                "acceptance for Phase 1 rev B rests on"],
    ["Basis", "Documents on the file server as of 10/09/2025. No new simulation has been run for this note."],
], widths=[1.7, 4.9], header=False, size=9.5)

# ------------------------------------------------------------------ 1
head("1.  The answer, before the reasoning")
para(f"You have Item 4 open on the checklist and will not sign rev B until it closes, so the note leads with the "
     f"figures and then shows where each one comes from. On the grid the Phase 1 report rests on — the fine grid of "
     f"the three-grid mesh study, background cell size {n['dx_bg']} m — the plume resolution index is {n['index']}, "
     f"not the {n['index_rec']} the record carries. It is computed on a representative fire-region cell edge length of "
     f"{n['dx_fire']} m and a plume characteristic diameter of {n['D2']} m, and it is outside the band of "
     f"{n['band_lo']} to {n['band_hi']}: the band is not met. The resolution acceptance for rev B therefore rests on "
     f"the resolved turbulent kinetic energy criterion alone, whose {n['pope']} % on the plume axis clears the "
     f"{n['pope_min']} % minimum. Resting it there requires no escalation to you and no ruling from you on which cell "
     f"edge length the index takes. What keeps Item 4 open is something else: the sub-grid-scale closure of the "
     f"simulation that produced the reported monitors is not recorded anywhere on the file server, so the item "
     f"remains open, and it closes by recording the closure in the Mixed-convection LES setup memo — without any new "
     f"simulation run.")

table([
    ["Quantity", "Value", "Where it comes from"],
    ["Fire heat release rate, Q", f"{n['Q_MW']} MW", "Scoping memo §5.1"],
    ["Ambient density, rho_inf", f"{n['rho']} kg/m³", "Scoping memo §5.1 (reference atmosphere)"],
    ["Ambient temperature, T_inf", f"{n['T']} K", "Scoping memo §5.1 (reference atmosphere)"],
    ["Specific heat, cp", f"{n['cp']} J/(kg·K)", "Scoping memo §5.1"],
    ["Plume characteristic diameter, D*", f"{n['D2']} m", f"Recomputed here ({n['D3']} m); the record carries {n['D_rec']} m"],
    ["Background cell size, fine grid of the study", f"{n['dx_bg']} m", "Three-grid study, GRID 3 of 3"],
    ["Refinement of the fire-source zone above background", f"{n['levels']} levels", "Three-grid study, head note"],
    ["Representative fire-region cell edge length, dx", f"{n['dx_fire']} m",
     f"{n['dx_bg']} m divided by 2^{n['levels']}"],
    ["Plume resolution index, D*/dx", f"{n['index']}", f"{n['D3']} m / {n['dx_fire']} m"],
    ["Required band", f"{n['band_lo']} to {n['band_hi']}", "QA Verification Standard rev 3, §5.1"],
    ["Band met?", "No", f"{n['index']} is {n['over']} times the upper limit"],
    ["Pope resolved-TKE fraction, k_res/(k_res+k_sgs)", f"{n['pope']} %", "Fine-grid solver summary, on-axis probe"],
    ["Required minimum", f"{n['pope_min']} %", "QA Verification Standard rev 3, §5.2"],
    ["Pope criterion met?", "Yes", f"{n['pope']} % against {n['pope_min']} %"],
], widths=[2.5, 1.0, 3.1], size=9)

# ------------------------------------------------------------------ 2
head("2.  Which grid this is about")
para(f"Rev B retains the fine grid as the reporting grid for the six SOW §3.1 cases (§6.3), reports its centreline "
     f"monitors in §5.4, and carries the resolution table in Appendix C. That grid is the one the report rests on "
     f"and the one every number in this note describes. The production mesh is a different mesh — {n['prod_cells']} "
     f"cells, with the conjugate wall assembly and the ties resolved — and the index below is not defined on it; it "
     f"is defined on the fine grid of the study, as the standard and the record both put it.")

# ------------------------------------------------------------------ 3
head(f"3.  The cell edge length the index takes: {n['dx_fire']} m")
para(f"The study's head note records that the fire-source refinement zone, a cylinder over the {n['seg']} m front "
     f"segment, carries two additional snappy refinement levels above background in every case. On the fine grid of "
     f"that study the background cell size is {n['dx_bg']} m, so two levels of halving put the representative cell "
     f"edge length across the buoyancy-dominated region — the representative fire-region cell edge length — at "
     f"{n['dx_fire']} m. That is the cell size the index takes.")
para(f"Two independent checks in the same checkMesh block agree. The minimum cell volume on the fine grid is "
     f"{n['minvol']} m³, whose cube root is {n['dx_minvol']} m. And the refined zone holds {n['zone_cells']} cells; "
     f"taken with the zone volume that cell count implies, {n['v3']} m³ on the fine grid, that is the same "
     f"{n['dx_fire']} m per cell. The same zone gives {n['v1']} m³ on the coarse grid ({n['zone_cells_1']} cells) "
     f"and {n['v2']} m³ on the medium grid ({n['zone_cells_2']} cells), so it is one physical cylinder on all three "
     f"grids and about {n['vmean']} m³ in volume.")
para(f"The {n['dx_bg']} m is the far-field background cell, not the fire-region cell. Dividing by it is what makes "
     f"the record's index read inside the band; no cell in the buoyancy-dominated region is {n['dx_bg']} m.")

# ------------------------------------------------------------------ 4
head(f"4.  The plume length scale: {n['D2']} m, not {n['D_rec']} m")
para(f"D* is the axisymmetric source length scale of QA §2, D* = ( Q / ( rho_inf · cp · T_inf · sqrt(g) ) )^(2/5). "
     f"With the record's own inputs — Q = {n['Q_MW']} MW, rho_inf = {n['rho']} kg/m³, cp = {n['cp']} J/(kg·K), "
     f"T_inf = {n['T']} K, g = {n['g']} m/s² — the bracketed group is a volume of {n['ratio']} m³, and its two-fifths "
     f"power is {n['D3']} m, reported as {n['D2']} m.")
para(f"The {n['D_rec']} m the scoping memo and rev B Appendix C carry does not follow from those inputs. The memo "
     f"prints the bracketed value as {n['ratio_rec']} m³ correctly and then takes it to {n['D_rec']} m, but "
     f"{n['ratio_rec']} to the power 2/5 is {n['D_rec_to_D']} m. The slip is in the last step only. It moves no "
     f"verdict — at {n['D_rec']} m the index would be {n['index_recD']}, still far outside the band — but {n['D2']} m "
     f"is the number the record should carry, and the correction should be made where the memo is next revised.")

# ------------------------------------------------------------------ 5
head(f"5.  The index and the band: {n['index']} against {n['band_lo']} to {n['band_hi']} — the band is not met")
para(f"On the grid behind the result the Phase 1 report rests on, {n['D3']} m over {n['dx_fire']} m gives "
     f"{n['index_2dp']}, reported as {n['index']}. QA §5.1 requires that index to fall in the band "
     f"{n['band_lo']} to {n['band_hi']}; {n['index']} is {n['over']} times the upper limit. The plume resolution "
     f"criterion is therefore not met on that grid.")
para(f"The index of {n['index_rec2']} that the study's resolution-assessment block reports — and the "
     f"{n['index_rec']} (also dimensionless) that Appendix C of rev B reports — is {n['D_rec']} m divided by "
     f"{n['dx_bg']} m, that is, the "
     f"characteristic diameter over the background cell; both figures are dimensionless ratios. That is the "
     f"far-field ratio, and it is not the quantity §5.1 defines.")

# ------------------------------------------------------------------ 6
head("6.  What the resolution acceptance for rev B rests on, and what needs no decision from you")
para(f"QA §5 accepts either criterion alone as sufficient evidence of adequate resolution. The plume resolution "
     f"criterion is not met (§5 above). The Pope resolved-TKE fraction on the fine grid is {n['pope']} %, above the "
     f"{n['pope_min']} % minimum of §5.2. Large-eddy resolution acceptance for rev B therefore rests on the resolved "
     f"turbulent kinetic energy criterion alone — on the numerical evidence of §5.2, not on engineering judgement "
     f"asserted in place of it, which §5 forbids.")
para("Resting the acceptance on one criterion requires no escalation to you as Reviewing Engineer. QA §5 requires "
     "escalation only where a physical constraint prevents meeting either criterion; one criterion is met here, so "
     "there is no constraint to state and nothing to escalate.")
para(f"No ruling from you as Reviewing Engineer is needed to fix which cell edge length the plume resolution index "
     f"takes. QA §2 defines the index on the representative fire-region cell edge length, §5.1 fixes that length as "
     f"the representative cell edge length across the buoyancy-dominated region, and the mesh record supplies it — "
     f"two refinement levels above a {n['dx_bg']} m background, i.e. {n['dx_fire']} m. The denominator follows from "
     f"the standard and the mesh record rather than from a call that needs review.")
para(f"One expectation does not apply to this deliverable, and it is the one that would otherwise make the unmet band "
     f"a bar: the expectation that both resolution acceptance criteria be met is set by QA §5 as the default only "
     f"for deliverables prepared for authorities having jurisdiction or for life-safety end use. Phase 1 rev B is "
     f"neither. SOW §1 and §10 procure analysis only; the fire-resistance rating on the assembly is certified "
     f"separately by a third-party fire-protection engineer under a separate engagement and sits outside the stamp "
     f"boundary; and no authority-having-jurisdiction submittal is in scope under the SOW. The both-criteria "
     f"expectation therefore does not apply to Phase 1 rev B.")

# ------------------------------------------------------------------ 7
head("7.  Was the resolved-energy figure taken inside the region the index describes?")
para(f"Partly, and what limits the answer is the record rather than the number. The probe is on the plume axis, at "
     f"{n['probe_factor']} D* above the source top surface — that is {n['probe_h']} m above it — which is inside the "
     f"buoyancy-dominated flow that §5.2 asks for, and the study samples more than twenty puffing cycles on every "
     f"grid, which is the statistically converged window §5.2 asks for.")
para(f"What the files on the file server do not record is the geometry of the fire-source refinement zone itself: "
     f"neither its radius nor its height. The study records it only as a cylinder over the {n['seg']} m front "
     f"segment, together with its cell count; the recorded volume of about {n['vmean']} m³ fixes only the product of "
     f"radius squared and height. Whether the probe lies inside that zone is therefore reached by inference, not "
     f"read from a recorded geometry — and the unrecorded radius and height are the recorded fact that this answer "
     f"rests on.")
para(f"Two bounds make the inference a strong one. For a cylinder of {n['vmean']} m³ to fit within the "
     f"{n['domain_top']} m height of the study domain its radius must be at least {n['r_min']} m, so the zone is not "
     f"a narrow tube around the {n['seg']} m segment. And for the zone's height to fall below the probe elevation of "
     f"{n['probe_h']} m it would have to be a disc at least {n['r_disc']} m in radius, {n['r_over_seg']} times the "
     f"segment length. On any plausible reading the probe sits inside the zone. The note states that as an inference "
     f"from a volume, which is what it is; if the containment has to be asserted as fact rather than inferred, the "
     f"mesher's zone definition — the dictionary entry that carries the cylinder's radius and height — should be "
     f"placed on the file server, because only the meshing log, which reports levels and cell counts, is there now.")

# ------------------------------------------------------------------ 8
head("8.  Do the ambient values behind the length scale represent the site?")
para(f"No. The ambient density of {n['rho']} kg/m³ and the ambient temperature of {n['T']} K behind the plume "
     f"characteristic diameter are reference-atmosphere values — the scoping memo names them as standard "
     f"reference-atmosphere conditions — and they are not the site design ambient of {n['site_lo']} to "
     f"{n['site_hi']} °C that the SOW §3.1 matrix and the Phase 1 report carry. The site meteorological pull agrees "
     f"with the warmer envelope rather than the reference one: {n['met_hot']} hours of the {n['met_rows']} hourly "
     f"records sit at or above {n['site_lo']} °C, with a maximum of {n['met_max']} °C.")
para(f"What the site's conditions would do to the length scale is fixed in direction and not in magnitude. For an "
     f"ideal gas the product of ambient density and temperature is pressure over the gas constant, so temperature "
     f"alone leaves D* unchanged: at the same pressure a warmer ambient lowers the density exactly enough to cancel "
     f"the rise in temperature in the bracketed group. A site-condition D* therefore turns on the site barometric "
     f"pressure.")
para(f"A plume characteristic diameter at site conditions cannot be evaluated from the files on the file server. No "
     f"file records a site pressure, and the meteorological pull carries six columns — timestamp, ambient "
     f"temperature, relative humidity, 20-ft wind speed, wind direction and solar irradiance — with no pressure "
     f"column and no elevation. The only elevation anywhere on the file server is the nominal ~{n['elev']} m in the "
     f"structural wind-load basis memo, given there for the ASCE 7-22 ground elevation factor of the separate SOW "
     f"§3.2 load case; that memo takes the nominal site air density as {n['rho_wind']} kg/m³, which is the "
     f"reference value already behind D*, and the SOW states that the §3.1 and §3.2 cases are not to be mixed. So "
     f"there is no recorded site pressure and no recorded site density to work from.")
para(f"The direction is determinable: any site pressure below the {n['p_ref']} Pa standard would lower the ambient "
     f"density and raise D*, and with it the index — a warmer, higher site makes the resolution worse, not better. "
     f"The magnitude is not determinable from the record. If a site-condition value is wanted, the site barometric "
     f"pressure has to enter the record first, as a measured or design value with its source, and D* and the index "
     f"then follow from it by the same expression.")

# ------------------------------------------------------------------ 9
head("9.  Can the item close? Not yet")
para("QA §3(a) requires the Verification section of an LES deliverable to state the turbulence treatment used and, "
     "for LES, the sub-grid-scale closure. No file on the file server names the closure of the simulation that "
     "produced the reported monitors. What is on file is three things, and none of them carries that entry:")
bullet(f" the study's summary blocks, which say fireFoam, LES, EDC combustion and fvDOM radiation, and name no "
       f"sub-grid-scale closure;", lead="The study —")
bullet(f" the only solver log on the server, which is a steady k-epsilon bring-up run inside a SIMPLE loop and is "
       f"described in its own operator note as a device to reach an initial condition before switching to LES, so "
       f"it is not the closure of the reported result;", lead="The solver log —")
bullet(f" the only case-setup export on the server, built from the Dry Wash Aerospace case CFDME-2024-018, "
       f"which carries rhoSimpleFoam, the RAS kOmegaSST closure, no combustion and radiation off — an unrelated "
       f"RANS envelope, not this simulation's closure.", lead="The case-setup record —")
para(f"The modeling standard names the two permissible closures, dynamic Smagorinsky and WALE, but no case record "
     f"says which one this case used. Item 4 also asks that D*/dx and the Pope fraction be stated in the body of the "
     f"Verification section rather than in an appendix; rev B states them in Appendix C. The figures in Section 1 "
     f"above are what that body has to carry.")
para("So the peer-review resolution-basis item remains open, and it stays open until the closure is in the record "
     "and the resolution basis is stated in the body of the Verification section rather than in an appendix.")

# ------------------------------------------------------------------ 10
head("10.  What would settle it")
para("Recording the choice of sub-grid-scale closure in the case setup memo settles the point at issue, and that is "
     "what the firm fire and buoyant flows modeling standard requires in §5, which states that the choice between "
     "the two closures shall be recorded in the case setup memo. On this project that memo is the Mixed-convection "
     "LES setup memo, SOW §4 deliverable 2, which documents the solver stack and the LES resolution basis; the "
     "closure should be established from the case build that produced the reported monitors and recorded there.")
para("Rev B's Verification section should then state the closure together with D*, dx, D*/dx and the Pope fraction "
     "in the body rather than in an appendix, at which point Item 4 has the entry it is asking for.")
para("The item can be settled without any new simulation run. What is missing is a record entry, not a result: the "
     "turbulence treatment of the simulation that produced the monitors is a fact about a case that has already been "
     "run, and establishing it from the case build and the case directory is work on the record. Nothing in this "
     "note calls for a new LES, a new mesh, or a re-run of the three-grid study.")

# ------------------------------------------------------------------ 11
head("11.  What this note does not do")
para("It does not revise Phase 1 rev B, and it changes no reported monitor. It does not evaluate a site-condition "
     "D*, for the reason given in Section 8. It does not by itself close Item 4: it supplies the resolution figures "
     "the Verification section has to state, and it identifies the one entry still missing from the record. Stamp "
     "boundary: CFD thermal analysis only; fire-resistance rating certified separately by others.")

doc.add_paragraph()
para("Prepared by: Gordon Selby, PE — Owner & Principal Engineer, The CFD Mechanical Engineer, LLC (AZ PE #48213)",
     size=9.5, space_after=1)
para("Date: 10/10/2025", size=9.5, space_after=1)
para("File: CFDME-2025-041_resolution_note_revA.docx  |  rev A  |  10/10/2025", size=8.5, italic=True)

OUT.parent.mkdir(parents=True, exist_ok=True)
doc.save(str(OUT))
print("wrote", OUT, OUT.stat().st_size, "bytes")
