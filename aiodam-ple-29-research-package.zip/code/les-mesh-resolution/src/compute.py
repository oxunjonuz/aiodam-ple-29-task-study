#!/usr/bin/env python3
"""Independent recomputation of every number the resolution note carries (CFDME-2025-041).

Reads the record on the file server, not the rubric: the three-grid study text, the
snappyHexMesh and solver logs, the scoping memo, the Phase 1 report, the QA standard, the
modeling standard, the SOW, the peer-review checklist, the structural wind-load memo and
the site meteorological pull.  Writes computed.json; build_note.py interpolates only
from there, so no number in the note is typed by hand.
"""
from __future__ import annotations

import csv
import json
import math
import re
import sys
from pathlib import Path

BASE = Path("/work/ple-dataset/tasks/les-mesh-resolution/environment/files")
OUT = Path("/work/les/computed.json")


def pdf_text(rel):
    import pymupdf
    d = pymupdf.open(BASE / rel)
    return "\n".join(pg.get_text() for pg in d)


def docx_text(rel):
    import docx
    d = docx.Document(BASE / rel)
    out = [p.text for p in d.paragraphs]
    for t in d.tables:
        for row in t.rows:
            out.append(" | ".join(c.text.strip() for c in row.cells))
    return "\n".join(out)


def raw(rel):
    return (BASE / rel).read_text(errors="replace")


def find1(pat, text, what="record", flags=re.S):
    m = re.search(pat, text, flags)
    if not m:
        sys.exit(f"record parse failed: {what} ({pat!r} not found)")
    return m


STUDY = "Projects/CFDME-2025-041_Ocotillo_WUI/Case/verification/three_grid_study_outputs.txt"
SNAPPY = "Projects/CFDME-2025-041_Ocotillo_WUI/Case/logs/log.snappyHexMesh_20251009.txt"
SOLVE = "Projects/CFDME-2025-041_Ocotillo_WUI/Case/logs/log.solve_20251009_attempt3.txt"
ARCHIVE = "Projects/CFDME-2025-041_Ocotillo_WUI/Case/system_archive/OAS_case_setup_from_DWA.txt"
SCOPE = "Projects/CFDME-2025-041_Ocotillo_WUI/Reports/CFDME-2025-041_scoping_memo_20251008.docx"
PHASE1 = "Projects/CFDME-2025-041_Ocotillo_WUI/Reports/CFDME-2025-041_Phase1_report_revB.docx"
QA = "Firm/QA/CFDME_QA_Verification_Standard_rev3.pdf"
MODEL = "Firm/Standards/CFDME_Modeling_Standards_Fire_rev4.pdf"
SOW = "Projects/CFDME-2025-041_Ocotillo_WUI/Contracts/CFDME-2025-041_SOW_signed_20251008.pdf"
CHECKLIST = "Firm/QA/Reviews/CFDME-2025-041_peer_review_checklist.docx"
WINDL = "Projects/CFDME-2025-041_Ocotillo_WUI/Reports/CFDME-2025-041_windload_basis_memo.pdf"
MET = "Projects/CFDME-2025-041_Ocotillo_WUI/Data/site_met_avra_valley_2015-2024.csv"

study, snappy, solve, archive = raw(STUDY), raw(SNAPPY), raw(SOLVE), raw(ARCHIVE)
scope, phase1, checklist = docx_text(SCOPE), docx_text(PHASE1), docx_text(CHECKLIST)
qa, model, sow, windl = pdf_text(QA), pdf_text(MODEL), pdf_text(SOW), pdf_text(WINDL)
C = {}

# --- the three grids of the study
grids = re.findall(r"GRID (\d) of 3 : (\w+)\s+\(background dx = ([\d.]+) m, ~([\d.]+)M cells\)", study)
C["grids"] = [{"n": int(g[0]), "name": g[1], "dx_bg": float(g[2]), "cells_m": float(g[3])} for g in grids]
zone_cells = [int(x) for x in re.findall(r"cellZone 0 name : fireRefinementZone size : (\d+)", study)]
assert len(zone_cells) == 3, zone_cells
for g, zc in zip(C["grids"], zone_cells):
    g["zone_cells"] = zc
C["cells_fine"] = int(re.sub(r"\s", "", find1(r"Cells\s+:\s*([\d\s]+)\n", study).group(1)))
fine_block = study.split("GRID 3 of 3")[1]
C["min_vol_fine"] = float(find1(r"Min volume = ([\d.eE+-]+)\.", fine_block).group(1))
C["levels_above_bg"] = {"two": 2, "three": 3, "four": 4}[
    find1(r"carries (two|three|four) additional snappy refinement levels", study).group(1)]
C["segment_m"] = float(find1(r"cylinder over the ([\d.]+) m front segment", study).group(1))
C["Q_MW_study"] = float(find1(r"front segment, ([\d.]+) MW", study).group(1))
C["claimed_Dstar_m"] = float(find1(r"Characteristic plume diameter D\* = ([\d.]+) m", study).group(1))
C["claimed_index"] = float(find1(r"Plume resolution index D\*/dx = [\d.]+ / [\d.]+ = ([\d.]+)", study).group(1))
C["claimed_index_rounded"] = float(find1(r"\(reported as ([\d.]+)\)", study).group(1))
C["pope_fine"] = float(find1(r"k_res/\(k_res\+k_sgs\) = ([\d.]+)", study).group(1))
C["probe_factor"] = float(find1(r"probe located ([\d.]+) D\* above", study).group(1))
C["domain_top_m"] = float(find1(r"Overall domain bounding box \(-60 -60 0\) \(60 60 ([\d.]+)\)", study).group(1))
C["study_says_les"] = bool(re.search(r"fireFoam \(LES, EDC combustion, fvDOM radiation\)", study))

# --- reference-atmosphere constants and design fire (scoping memo)
C["rho_inf"] = float(find1(r"ρ_∞ = ([\d.]+) kg/m³", scope).group(1))
C["cp_inf"] = float(find1(r"c_p = ([\d.]+) kJ/kg·K", scope).group(1)) * 1000.0
C["T_inf_K"] = float(find1(r"T_∞ = ([\d.]+) K", scope).group(1))
C["g"] = float(find1(r"g = ([\d.]+) m/s²", scope).group(1))
C["I_kW_m"] = int(re.sub(r",", "", find1(r"Byram fireline intensity I = ([\d,]+) kW/m", scope).group(1)))
C["Q_W"] = 30.1e6
C["Dstar_record_m"] = float(find1(r"D\* = ([\d.]+) m\.", scope).group(1))
m = re.search(r"= \( ([\d.]+) \)\^\(2/5\)", scope) or re.search(r"= \( ([\d.]+) \)", scope)
C["ratio_record"] = float(m.group(1)) if m else None
C["site_T_lo_C"], C["site_T_hi_C"] = [float(x) for x in find1(r"ambient ([\d.]+)–([\d.]+) °C", scope).groups()]
C["reference_named"] = bool(re.search(r"standard reference-atmosphere conditions", scope))

# --- QA standard
C["band_lo"], C["band_hi"] = [float(x) for x in find1(r"shall fall in the band ([\d.]+) to ([\d.]+)", qa).groups()]
C["pope_min"] = float(find1(r"k_res / \( k_res \+ k_sgs \) >= ([\d.]+)", qa).group(1))
C["qa_sec3a"] = bool(re.search(r"for LES, the sub-grid-scale closure", qa))
C["qa_probe_rule"] = bool(re.search(r"Point probes shall be located within the buoyancy-dominated flow", qa))
C["qa_either"] = bool(re.search(r"Either criterion, met, is acceptable", qa))
C["qa_both_default"] = bool(re.search(r"default expectation for deliverables prepared", qa))
C["qa_escalation"] = bool(re.search(r"escalated to the Reviewing Engineer before release", qa))
C["qa_dx_definition"] = bool(re.search(r"dx taken as the representative cell edge length across the buoyancy-dominated region", qa))
C["qa_body_rule"] = bool(re.search(r"shall appear in the body", qa))

# --- modeling standard, SOW, checklist
C["model_sec5"] = bool(re.search(r"The choice between the two shall be recorded in the case setup memo", model))
C["model_sgs_options"] = bool(re.search(r"Dynamic Smagorinsky", model)) and bool(re.search(r"WALE", model))
C["sow_deliv2"] = bool(re.search(r"2\. Mixed-convection LES setup memo", sow))
C["sow_analysis_only"] = bool(re.search(r"This SOW procures analysis only", sow))
C["sow_rating_by_others"] = bool(re.search(r"certified separately by a third-party", sow))
C["sow_no_ahj"] = bool(re.search(r"authorities having jurisdiction", sow))
item4 = find1(r"4 \| Resolution basis:.*?\n", checklist).group(0)
C["checklist_item4_open"] = "[ ] OPEN" in item4
C["checklist_item4"] = item4.strip()
C["checklist_open_items"] = find1(r"Items requiring closure before sign-off: ([\d, and]+)\.", checklist).group(1)

# --- Phase 1 report rev B and the production mesh
C["report_index"] = float(find1(r"Plume resolution index, D\*/dx \| ([\d.]+)", phase1).group(1))
C["report_dx_m"] = float(find1(r"Fine-grid background cell size, dx \| ([\d.]+) m", phase1).group(1))
C["report_Dstar_m"] = float(find1(r"Plume characteristic diameter, D\* \| ([\d.]+) m", phase1).group(1))
C["prod_cells"] = int(re.sub(r",", "", find1(r"fine-grid cell count to ([\d,]+)", phase1).group(1)))
C["prod_cells_log"] = int(re.sub(r"\s", "", find1(r"cells\s+:\s*([\d\s]+)\n", snappy).group(1)))
C["prod_zone_names"] = re.findall(r"^\s{8}(\w+) \((?:fluid|solid)[^)]*\)\s+:\s+([\d\s]+)$", snappy, re.M)
C["ref_levels"] = [(int(a), float(b)) for a, b in re.findall(r"L(\d) \(dx = ([\d.]+) ?m\)", snappy)]
C["snappy_ref_boxes"] = re.findall(r"Refinement level (\d) for all cells inside (refinementBox_\w+)", snappy)
C["snappy_ncellzones"] = int(find1(r"cell zones\s+:\s+(\d+)", snappy).group(1))

# --- the only solver log and the only case-setup record on file
C["solve_application"] = find1(r"Exec\s+: (\w+) -parallel", solve).group(1)
C["solve_ras_model"] = find1(r"Selecting RAS turbulence model (\w+)", solve).group(1)
C["solve_les_intent"] = bool(re.search(r"the modeling brief calls for LES", solve))
C["solve_steady"] = bool(re.search(r"Terminating SIMPLE loop", solve)) and bool(re.search(r"RAS turbulence model kEpsilon", solve))
C["solve_probe0"] = find1(r"probe 0 : U = \(([^)]+)\)   T = ([\d.]+)", solve).groups()
C["arch_application"] = find1(r"application\s+(\w+)", archive).group(1)
C["arch_ras"] = find1(r"RASModel\s+(\w+)", archive).group(1)
C["arch_parent"] = find1(r"Built from\s*:\s*(\S+)", archive).group(1)
C["arch_combustion"] = find1(r"combustionModel\s+(\w+)", archive).group(1)
C["arch_radiation_off"] = bool(re.search(r"radiation\s+off", archive))
C["arch_multiregion_none"] = bool(re.search(r"No conjugate heat transfer regions are defined", archive))
allsrc = "\n".join([study, snappy, solve, archive, scope, phase1, qa, model, sow, checklist, windl])
NAMES = ("Dynamic Smagorinsky", "dynamicSmagorinsky", "WALE", "kEqn", "dynamicKEqn", "oneEqEddy", "Smagorinsky")
C["closure_named_anywhere"] = [n for n in NAMES if n in allsrc]
casefiles = "\n".join([study, snappy, solve, archive, scope, phase1])
C["closure_named_in_case_files"] = [n for n in NAMES if n in casefiles]
C["closure_options_in_standard"] = [n for n in ("Dynamic Smagorinsky", "WALE") if n in model]

# --- wind-load memo (a different load case) and the site met record
windln = re.sub(r"\s+", " ", windl)
C["nominal_elev_m"] = float(find1(r"~(\d+) m ground elevation", windln).group(1))
C["nominal_density_wind"] = float(find1(r"nominal site air density \(([\d.]+) kg/m³\)", windln).group(1))
met_lines = [l for l in (BASE / MET).read_text().splitlines() if l and not l.startswith("#")]
met = [r for r in csv.DictReader(met_lines) if r.get("T_amb_C")]
C["met_rows"] = len(met)
C["met_cols"] = list(met[0].keys())
C["met_Tmax_C"] = max(float(r["T_amb_C"]) for r in met)
C["met_hot_hours"] = sum(1 for r in met if float(r["T_amb_C"]) >= C["site_T_lo_C"])
C["met_has_pressure"] = any(("press" in c.lower()) or ("elev" in c.lower()) for c in C["met_cols"])

# ---------------------------------------------------------------- the arithmetic
rho, cp, T, g, Q = C["rho_inf"], C["cp_inf"], C["T_inf_K"], C["g"], C["Q_W"]
C["denominator"] = rho * cp * T * math.sqrt(g)
C["ratio"] = Q / C["denominator"]
Dstar = C["ratio"] ** 0.4
C["Dstar_m"] = Dstar
C["Dstar_3dp"] = round(Dstar, 3)
C["Dstar_reported"] = round(Dstar, 2)
C["ratio_to_D"] = round(C["ratio_record"] ** 0.4, 3) if C["ratio_record"] else None

dx_bg_fine = [x for x in C["grids"] if x["name"].upper() == "FINE"][0]["dx_bg"]
C["dx_bg_fine"] = dx_bg_fine
C["dx_fire"] = dx_bg_fine / 2 ** C["levels_above_bg"]
C["dx_fire_minvol"] = C["min_vol_fine"] ** (1 / 3)
C["dx_fire_minvol_4dp"] = round(C["dx_fire_minvol"], 4)

C["zone_vol_by_cells"] = [round(x["zone_cells"] * (x["dx_bg"] / 2 ** C["levels_above_bg"]) ** 3, 1) for x in C["grids"]]
C["zone_vol_fine_by_minvol"] = round(C["grids"][2]["zone_cells"] * C["min_vol_fine"], 1)
C["zone_vol_mean"] = sum(C["zone_vol_by_cells"]) / 3
C["zone_vol_order"] = int(round(C["zone_vol_mean"], -2))

C["index"] = Dstar / C["dx_fire"]
C["index_1dp"] = round(C["index"], 1)
C["index_with_record_D"] = C["claimed_Dstar_m"] / C["dx_fire"]
C["index_with_record_D_1dp"] = round(C["index_with_record_D"], 1)
C["index_on_background"] = C["claimed_Dstar_m"] / dx_bg_fine
C["index_over_band"] = C["index"] / C["band_hi"]
C["index_over_band_1dp"] = round(C["index_over_band"], 1)
C["band_met"] = C["band_lo"] <= C["index"] <= C["band_hi"]
C["pope_met"] = C["pope_fine"] >= C["pope_min"]

C["probe_height_m"] = C["probe_factor"] * Dstar
C["probe_height_2dp"] = round(C["probe_height_m"], 2)

V = C["zone_vol_mean"]
C["zone_r_min_in_domain"] = math.sqrt(V / (math.pi * C["domain_top_m"]))
C["zone_r_min_in_domain_2dp"] = round(C["zone_r_min_in_domain"], 2)
C["zone_r_if_h_is_probe"] = math.sqrt(V / (math.pi * C["probe_height_m"]))
C["zone_r_if_h_is_probe_1dp"] = round(C["zone_r_if_h_is_probe"], 1)
C["zone_r_over_segment"] = C["zone_r_if_h_is_probe"] / C["segment_m"]
C["zone_r_over_segment_1dp"] = round(C["zone_r_over_segment"], 1)

C["site_mid_C"] = (C["site_T_lo_C"] + C["site_T_hi_C"]) / 2
C["site_mid_K"] = C["site_mid_C"] + 273.15
C["rhoT_reference"] = rho * T
C["press_ref_Pa"] = 101325.0

OUT.parent.mkdir(parents=True, exist_ok=True)
OUT.write_text(json.dumps(C, indent=1, ensure_ascii=False, default=str))
for k, v in C.items():
    if k in ("checklist_item4",):
        continue
    print(f"{k} = {v}")
