#!/usr/bin/env python3
"""The 14 rubric statements of `les-mesh-resolution`, written as code, plus closure checks.

Reads the text twin of the rendered note (what the judge reads) and reports, per rubric
index, whether the note states that claim — each check requires the claim inside one
sentence-sized window, so a number and a noun scattered across the document do not pass.

    python3 checks.py out/note_pdf.txt [--json]
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path


def norm(t: str) -> str:
    t = t.replace("\u00b3", "3").replace("\u00b2", "2").replace("\u00b7", "·")
    t = t.replace("\u2013", "-").replace("\u2014", "-").replace("\u2212", "-")
    t = re.sub(r"-\s*\n\s*", "", t)          # a hyphen split across a PDF line break
    t = re.sub(r"\s+", " ", t)
    return t


def near(text: str, a: str, b: str, window: int = 260, flags=re.I) -> bool:
    """a and b both present with at most `window` characters between them (either order)."""
    pat = re.compile(rf"{a}.{{0,{window}}}?{b}|{b}.{{0,{window}}}?{a}", flags | re.S)
    return bool(pat.search(text))


CHECKS = []


def check(idx, weight, claim, fn):
    CHECKS.append((idx, weight, claim, fn))


# ---------------------------------------------------------------- 0
def c0(t):
    return bool(re.search(r"representative cell edge length across the buoyancy-dominated region", t, re.I)
                and near(t, r"0\.125 m", r"fire-region cell edge", 200))


check(0, 7.0, "representative fire-region cell edge length on the fine grid = 0.125 m", c0)


# ---------------------------------------------------------------- 1
def c1(t):
    return bool(re.search(r"plume characteristic diameter[^.]{0,80}3\.74 m", t, re.I)
                or re.search(r"3\.74 m[^.]{0,80}plume characteristic diameter", t, re.I))


check(1, 1.0, "plume characteristic diameter = 3.74 m", c1)


# ---------------------------------------------------------------- 2
def c2(t):
    band = re.search(r"plume resolution criterion[^.]{0,200}not met|not met[^.]{0,200}plume resolution criterion", t, re.I)
    return bool(band and re.search(r"band 5 to 10|band of 5 to 10", t, re.I))


check(2, 7.0, "plume resolution criterion, band 5 to 10, not met on the fine grid", c2)


# ---------------------------------------------------------------- 3
def c3(t):
    return bool(re.search(r"rests on the resolved turbulent kinetic energy criterion alone", t, re.I)
                or re.search(r"acceptance[^.]{0,120}(rests|rest)[^.]{0,120}resolved turbulent kinetic energy criterion alone", t, re.I))


check(3, 9.0, "LES resolution acceptance rests on the resolved-TKE criterion alone", c3)


# ---------------------------------------------------------------- 4
def c4(t):
    return bool(re.search(r"no escalation to you as Reviewing Engineer", t, re.I)
                and re.search(r"one criterion is met|either criterion|resting the acceptance on one criterion", t, re.I))


check(4, 8.0, "resting acceptance on one criterion requires no escalation to the Reviewing Engineer", c4)


# ---------------------------------------------------------------- 5
def c5(t):
    radius = re.search(r"neither its radius nor its height", t, re.I)
    zone = re.search(r"fire-source refinement zone", t, re.I)
    server = re.search(r"file server", t, re.I)
    return bool(radius and zone and server)


check(5, 8.0, "files record neither the radius nor the height of the fire-source refinement zone", c5)


# ---------------------------------------------------------------- 6
def c6(t):
    has = (re.search(r"1\.204 kg/m3", t) and re.search(r"293\.15 K", t))
    ref = re.search(r"reference-atmosphere values", t, re.I)
    site = re.search(r"35 to 42 °C", t) or re.search(r"35 to 42 C", t)
    return bool(has and ref and site
                and near(t, r"1\.204 kg/m3", r"reference-atmosphere", 400)
                and near(t, r"reference-atmosphere values", r"35 to 42", 400))


check(6, 1.0, "1.204 kg/m3 and 293.15 K are reference-atmosphere values, not the site 35-42 deg C", c6)


# ---------------------------------------------------------------- 7
def c7(t):
    return bool(re.search(r"(cannot|can not) be evaluated from the files on the file server", t, re.I)
                and re.search(r"site[- ]condition", t, re.I))


check(7, 6.0, "a plume characteristic diameter at site conditions cannot be evaluated from the files", c7)


# ---------------------------------------------------------------- 8
def c8(t):
    return bool(re.search(r"(resolution-basis item|Item 4)[^.]{0,120}remains open|remains open[^.]{0,120}(resolution-basis|Item 4)", t, re.I))


check(8, 7.0, "the peer-review resolution-basis item remains open", c8)


# ---------------------------------------------------------------- 9
def c9(t):
    memo = re.search(r"case setup memo", t, re.I)
    les = re.search(r"Mixed-convection LES setup memo", t, re.I)
    record = re.search(r"(recording|recorded|records) the (choice|closure)", t, re.I)
    return bool(memo and les and record)


check(9, 8.0, "closure is to be recorded in the case setup memo / Mixed-convection LES setup memo", c9)


# ---------------------------------------------------------------- 10
def c10(t):
    return bool(re.search(r"without any new simulation run", t, re.I)
                or re.search(r"no new (simulation )?run", t, re.I))


check(10, 1.0, "the item can be settled without any new simulation run", c10)


# ---------------------------------------------------------------- 11
def c11(t):
    return bool(re.search(r"[Nn]o ruling from you as Reviewing Engineer is needed to fix which cell edge length", t))


check(11, 8.0, "no ruling from the Reviewing Engineer is needed to fix which cell edge length the index takes", c11)


# ---------------------------------------------------------------- 12
def c12(t):
    both = re.search(r"both resolution acceptance criteria be met", t, re.I)
    ahj = re.search(r"authorities having jurisdiction", t, re.I)
    life = re.search(r"life-safety end use", t, re.I)
    notapply = re.search(r"does not apply to Phase 1 rev B", t, re.I)
    return bool(both and ahj and life and notapply)


check(12, 8.0, "the both-criteria expectation (AHJ / life-safety) does not apply to Phase 1 rev B", c12)


# ---------------------------------------------------------------- 13
def c13(t):
    return bool(re.search(r"plume resolution index is 29\.9|index, D\*/dx 29\.9|is 29\.9", t, re.I)
                and re.search(r"29\.9", t))


check(13, 3.0, "the plume resolution index on that grid is 29.9", c13)


# ---------------------------------------------------------------- my own closures
CLOSURES = []


def closure(name, fn):
    CLOSURES.append((name, fn))


def k_arithmetic(t):
    """the note's own numbers close: 3.742/0.125 -> 29.9, 0.500/2^2 -> 0.125, 0.75*3.742 -> 2.81."""
    ok = True
    ok &= near(t, r"3\.742 m", r"0\.125 m", 300)
    ok &= bool(re.search(r"29\.9", t))
    ok &= bool(re.search(r"30\.1 MW", t))
    ok &= near(t, r"0\.500 m", r"two", 200) or near(t, r"two refinement levels|two levels", r"0\.125 m", 400)
    ok &= bool(re.search(r"2\.81 m", t))
    return ok


closure("k1 arithmetic closes inside the note", k_arithmetic)


UNIT_TAIL = re.compile(
    r"\s*(?:m³|m3|m2|mm|MW|kW|kg|Pa|°C|hours?|hourly|daily|records|values|cycles|columns|cells|times|levels"
    r"|m|W|K|J|s|%)(?![\w])")


def k_units(t):
    """every figure the note asserts carries a unit in the same sentence (Units SOP rev 2)."""
    t = re.sub(r"(?<=\d),(?=\d{3})", "", t)          # 101,325 is one number, not two
    bad = []
    for m in re.finditer(r"\b\d+(?:\.\d+)?\b", t):
        tail = t[m.end():m.end() + 26]
        if UNIT_TAIL.match(tail):
            continue
        if re.match(r"-(?:ft|m|in|s|h|deg|mph)\b", tail):   # a hyphenated compound: "20-ft wind speed"
            continue
        if re.match(r"\s*(?:\^|/)", tail):          # an exponent, a ratio, or a range
            continue
        if m.start() and t[m.start() - 1] == "#":      # a licence number
            continue
        if re.match(r"\.\s+[A-Z]", tail):             # a section number ("3. The cell edge ...")
            continue
        if "dimensionless" in t[max(0, m.start() - 24):m.start()] or tail.lstrip().startswith("(also dimensionless)"):
            continue
        ctx = t[max(0, m.start() - 55):m.end() + 18]
        bad.append(ctx)
    bad = [b for b in bad if not re.search(
        r"§|rev |Item |GRID|2/5|10/10|10/09|Q_|T_inf|rho|cp|D\*|index|CFDME-|Phase \d|\^|3 of 3|of 3"
        r"|ASCE|ASTM|\d+/\d+|Section \d", b)]
    return len(bad) == 0, bad[:6]


closure("k2 every stated figure carries a unit", lambda t: k_units(t)[0])


def k_no_placeholders(t):
    return not re.search(r"TODO|XXX|\[insert|placeholder|TBD", t, re.I)


closure("k3 no placeholder text", k_no_placeholders)


def k_pope_verdict(t):
    """the Pope figure the note states actually clears the minimum the note states."""
    m1 = re.search(r"(\d+) % on the plume axis", t) or re.search(r"fraction on the fine grid is (\d+) %", t)
    m2 = re.search(r"clears the (\d+) % minimum", t) or re.search(r"above the (\d+) % minimum", t)
    if not (m1 and m2):
        return False
    return int(m1.group(1)) >= int(m2.group(1))


closure("k4 the Pope figure clears the stated minimum", k_pope_verdict)


def main() -> int:
    text = norm(Path(sys.argv[1]).read_text(errors="replace"))
    rows, failed, weight_pass, weight_total = [], [], 0.0, 0.0
    for idx, w, claim, fn in CHECKS:
        ok = bool(fn(text))
        weight_total += w
        if ok:
            weight_pass += w
        else:
            failed.append(idx)
        rows.append({"index": idx, "weight": w, "claim": claim, "pass": ok})
    clos = []
    for name, fn in CLOSURES:
        ok = bool(fn(text))
        clos.append({"name": name, "pass": ok})
    out = {"checks": rows, "closures": clos, "failed": failed,
           "weight_passed": weight_pass, "weight_total": weight_total,
           "score_if_judge_agrees": round(weight_pass / weight_total, 4)}
    if "--json" in sys.argv:
        print(json.dumps(out, indent=1))
    else:
        for r in rows:
            print(("PASS " if r["pass"] else "FAIL ") + f"[{r['index']:>2}] w={r['weight']:<4} {r['claim']}")
        for c in clos:
            print(("PASS " if c["pass"] else "FAIL ") + "closure: " + c["name"])
        print(f"\nweight {weight_pass:.0f}/{weight_total:.0f} = {weight_pass/weight_total:.4f}"
              f"  failures={failed}")
    return 0 if not failed and all(c["pass"] for c in clos) else 1


if __name__ == "__main__":
    sys.exit(main())
