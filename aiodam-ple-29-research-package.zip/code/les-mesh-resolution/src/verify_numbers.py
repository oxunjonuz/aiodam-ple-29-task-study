#!/usr/bin/env python3
"""Second, independent recomputation: different arithmetic (Decimal, not float), different
parsing of the record, and the numbers compared against computed.json.

Nothing here imports compute.py; if the two agree, the agreement is between two paths.
"""
from __future__ import annotations

import csv
import json
import re
from decimal import Decimal, getcontext
from pathlib import Path

getcontext().prec = 40

BASE = Path("/work/ple-dataset/tasks/les-mesh-resolution/environment/files")
C = json.loads(Path("/work/les/computed.json").read_text())
study = (BASE / "Projects/CFDME-2025-041_Ocotillo_WUI/Case/verification/three_grid_study_outputs.txt").read_text()

fails = []


def close(name, mine, theirs, tol=Decimal("0.0005")):
    ok = abs(Decimal(str(mine)) - Decimal(str(theirs))) <= tol
    print(f"{'OK  ' if ok else 'FAIL'} {name}: independent={mine} computed.json={theirs}")
    if not ok:
        fails.append(name)


# --- the record, parsed a second way
blocks = re.split(r"// =+\n// GRID ", study)
assert len(blocks) == 4, len(blocks)
dx_bg = []
zone = []
for b in blocks[1:]:
    dx_bg.append(Decimal(re.search(r"background dx = ([\d.]+) m", b).group(1)))
    zone.append(int(re.search(r"fireRefinementZone size : (\d+)", b).group(1)))
fine = blocks[3]
minvol = Decimal(re.search(r"Min volume = ([\d.eE+-]+)\.", fine).group(1))
levels = Decimal(2) if "carries two additional snappy refinement levels" in study else None
assert levels is not None

D = Decimal("30.1e6")                                   # joules per second, from the memo's 30.1 MW
rho = Decimal("1.204")
cp = Decimal("1005")
T = Decimal("293.15")
g = Decimal("9.81")
grp = D / (rho * cp * T * g.sqrt())
Dstar = (Decimal(2) / Decimal(5) * grp.ln()).exp()      # exp(0.4 ln x), not x**0.4
dx_fire = dx_bg[2] / Decimal(2) ** levels
index = Dstar / dx_fire
probe = Decimal("0.75") * Dstar

close("D* (m)", round(Dstar, 6), C["Dstar_m"], tol=Decimal("0.000002"))
close("fire-region dx (m)", dx_fire, C["dx_fire"], tol=Decimal("0"))
close("index", round(index, 4), round(C["index"], 4), tol=Decimal("0.0001"))
close("probe height (m)", round(probe, 4), round(C["probe_height_m"], 4), tol=Decimal("0.0001"))
close("cube root of min cell volume", round(minvol ** (Decimal(1) / Decimal(3)), 5),
      round(C["dx_fire_minvol"], 5), tol=Decimal("0.00002"))
for i, (zc, dxb) in enumerate(zip(zone, dx_bg)):
    vol = Decimal(zc) * (dxb / Decimal(2) ** levels) ** 3
    close(f"zone volume grid {i+1} (m3)", round(vol, 1), C["zone_vol_by_cells"][i], tol=Decimal("0.1"))

# what the record's own bracket value gives, by the same expression
grp_rec = Decimal("27.08")
D_rec = (Decimal(2) / Decimal(5) * grp_rec.ln()).exp()
close("D* from the memo's own bracket", round(D_rec, 3), C["ratio_to_D"], tol=Decimal("0.0005"))
bound_flag = "band met" if Decimal(5) <= index <= Decimal(10) else "band NOT met"
print(f"     verdict from the independent path: index {index:.3f} -> {bound_flag}")

# the site record, read a second way (csv module, not a regex)
rows = [r for r in csv.DictReader(
    [l for l in (BASE / "Projects/CFDME-2025-041_Ocotillo_WUI/Data/site_met_avra_valley_2015-2024.csv")
     .read_text().splitlines() if l and not l.startswith("#")]) if r.get("T_amb_C")]
close("met record rows", len(rows), C["met_rows"], tol=Decimal("0"))
close("met max temperature (degC)", max(Decimal(r["T_amb_C"]) for r in rows), C["met_Tmax_C"], tol=Decimal("0"))
close("hours at or above 35 degC", sum(1 for r in rows if Decimal(r["T_amb_C"]) >= Decimal(35)), C["met_hot_hours"],
      tol=Decimal("0"))
print("     met record columns:", list(rows[0].keys()))

print(f"\nFAILURES: {len(fails)}" + (f" {fails}" if fails else ""))
raise SystemExit(1 if fails else 0)
