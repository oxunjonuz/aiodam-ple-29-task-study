#!/usr/bin/env python3
"""A stub judge for the official verifier path: OpenAI-compatible, on loopback.

It answers /v1/chat/completions with one grade per criterion, computed by the reader in
checks.py on the candidate text that actually arrived in the request — not on any file of
ours — so a run through test.sh -> verify.py -> grade.py proves the wiring (staging,
rendering, schema, weighting) on real bytes. Its score is the reader's, so a 1.0 here is a
statement about the reader and the pipeline, never about the real judge's opinion.
"""
from __future__ import annotations

import json
import re
import sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

sys.path.insert(0, "/work/les/src")
import checks  # noqa: E402


def candidate_text(prompt: str) -> str:
    """The staged candidate: everything from the first '===== <file> =====' header on."""
    m = re.search(r"\n===== ", prompt)
    return prompt[m.start():] if m else ""


def grades_for(text: str) -> list:
    t = checks.norm(text)
    rows = []
    for idx, w, claim, fn in checks.CHECKS:
        ok = bool(fn(t))
        rows.append({"index": idx, "score": 1.0 if ok else 0.0, "passed": ok,
                     "evidence": "the staged rendering carries the statement" if ok else "no sentence in the staged rendering states it",
                     "reason": claim})
    return rows


class H(BaseHTTPRequestHandler):
    def do_POST(self):
        n = int(self.headers.get("Content-Length", 0))
        body = json.loads(self.rfile.read(n) or b"{}")
        msgs = body.get("messages") or []
        prompt = "\n".join(m.get("content", "") for m in msgs if m.get("role") == "user")
        text = candidate_text(prompt)
        rows = grades_for(text)
        with open("/work/les/out/stub_last_request.txt", "w") as fh:
            fh.write(text)
        payload = {"choices": [{"index": 0, "finish_reason": "stop",
                                "message": {"role": "assistant", "content": json.dumps({"grades": rows})}}],
                   "usage": {"completion_tokens": len(rows)}}
        data = json.dumps(payload).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def log_message(self, *a):
        pass


if __name__ == "__main__":
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8731
    ThreadingHTTPServer(("127.0.0.1", port), H).serve_forever()
