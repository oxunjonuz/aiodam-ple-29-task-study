#!/usr/bin/env python3
"""Mutation campaign for the LES resolution note.

For each mutation: rebuild the docx from build_note.py with MUT=<id>, render it to PDF with
the task's own transform.py, extract the text twin the judge would read, and run the reader
in checks.py. A mutation counts as caught only when the failure set is non-empty and the
reader did not crash — a red run with a traceback is not a catch.

M20 is the control: a harmless date change that must NOT be caught, so a reader that fails
on anything is exposed as a reader that proves nothing.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path("/work/les")
SRC = ROOT / "src"
TR = Path("/work/ple-dataset/tasks/les-mesh-resolution/tests/tools/verifiers/deps/transform.py")
ENV = dict(os.environ, PYTHONPATH="/work/venv-verifier/lib/python3.12/site-packages")

IDS = ["M01", "M02", "M03", "M04", "M05", "M06", "M07", "M08", "M09", "M10",
       "M11", "M12", "M13", "M14", "M15", "M16", "M17", "M18", "M19", "M20"]
EXPECT = {  # what the mutation is meant to break: a rubric index, or a closure letter
    "M01": "c0", "M02": "c1", "M03": "c2", "M04": "c3", "M05": "c4",
    "M06": "c5", "M07": "c6", "M08": "c7", "M09": "c8", "M10": "c9",
    "M11": "c10", "M12": "c11", "M13": "c12", "M14": "c13", "M15": "k2",
    "M16": "k1", "M17": "c0", "M18": "k4", "M19": "c2", "M20": None,
}


def run(cmd, env=None, cwd=None):
    return subprocess.run(cmd, shell=isinstance(cmd, str), capture_output=True, text=True,
                          env=env or ENV, cwd=cwd or str(ROOT))


def one(mid: str) -> dict:
    env = dict(ENV, MUT=mid)
    b = run([sys.executable, str(SRC / "build_note.py")], env=env)
    if b.returncode:
        return {"mut": mid, "built": False, "stderr": b.stderr[-600:]}
    docx = ROOT / "out" / "CFDME-2025-041_resolution_note_revA.docx"
    pdf = ROOT / "out" / "mut" / f"{mid}.pdf"
    pdf.parent.mkdir(parents=True, exist_ok=True)
    r = run([sys.executable, str(TR), "--input", str(docx), "--output", str(pdf), "--transformation", "docx_to_pdf"])
    if r.returncode or not pdf.is_file():
        return {"mut": mid, "built": True, "rendered": False, "stderr": (r.stderr or r.stdout)[-600:]}
    import pymupdf
    d = pymupdf.open(pdf)
    txt = "\n".join(p.get_text() for p in d)
    tp = ROOT / "out" / "mut" / f"{mid}.txt"
    tp.write_text(txt)
    c = run([sys.executable, str(SRC / "checks.py"), str(tp), "--json"])
    if c.returncode not in (0, 1) or "Traceback" in (c.stderr or ""):
        return {"mut": mid, "rendered": True, "crashed": True, "stderr": (c.stderr or "")[-600:]}
    try:
        res = json.loads(c.stdout)
    except Exception:
        return {"mut": mid, "rendered": True, "crashed": True, "stderr": c.stdout[-400:]}
    failed = res["failed"]
    clos_failed = [x["name"] for x in res["closures"] if not x["pass"]]
    return {"mut": mid, "rendered": True, "crashed": False,
            "failed_criteria": failed, "failed_closures": clos_failed,
            "caught": bool(failed or clos_failed), "score": res["score_if_judge_agrees"]}


def main() -> int:
    only = [a for a in sys.argv[1:] if a.startswith("M")]
    ids = only or IDS
    rows = []
    for mid in ids:
        row = one(mid)
        rows.append(row)
        exp = EXPECT.get(mid)
        if row.get("crashed"):
            verdict = "CRASH"
        elif mid == "M20":
            verdict = "ok (control not caught)" if not row.get("caught") else "CONTROL CAUGHT - reader too broad"
        elif row.get("caught"):
            hit = ",".join(f"c{i}" for i in row["failed_criteria"]) + \
                  ("," + ",".join(row["failed_closures"]) if row["failed_closures"] else "")
            ok_exp = exp is None or any(h.strip().startswith(exp) or h.strip() == exp for h in hit.split(","))
            verdict = f"caught by {hit}" + ("" if ok_exp else f"  (expected {exp})")
        else:
            verdict = "SURVIVED"
        print(f"{mid:>4}  {verdict}")
    caught = sum(1 for r in rows if r.get("caught") and r["mut"] != "M20")
    survived = [r["mut"] for r in rows if not r.get("caught") and r["mut"] != "M20"]
    bad_ctrl = [r["mut"] for r in rows if r["mut"] == "M20" and r.get("caught")]
    print(f"\ncaught {caught}/{len([r for r in rows if r['mut'] != 'M20'])}  survived={survived}  control_failed={bad_ctrl}")
    (ROOT / "out" / "mutations.json").write_text(json.dumps(rows, indent=1))
    return 0 if not survived and not bad_ctrl else 1


if __name__ == "__main__":
    sys.exit(main())
