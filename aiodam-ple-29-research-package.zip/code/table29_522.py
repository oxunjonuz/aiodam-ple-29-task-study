#!/usr/bin/env python3
"""Table 29 for turn 522 — built from a list of names, counted by script, with every path checked.

Renders /work/ple-solve/TABLE_29_522.md and refuses to print a summary that does not equal the
number of rows it just rendered (the round-521 lesson: the prose total drifted from the list).
"""
import json
import os

# task, grading, package, measured, where, open
ROWS = [
 ("cooling-water-flush-plan", "checks", "submission.zip 10 364 б", "reward 0.923849 dev / 0.949189 held-out",
  "/work/imgroot/task_cooling-water-flush-plan/logs/verifier/paper_score.json", "—"),
 ("data-center-site-model", "checks", "ws/submission/model.ifc", "combined 1.0, 17/17 ограничений (запись)",
  "НЕ НАЙДЕНО файла с результатом", "сырые метрики не сохранены"),
 ("data-hall-device-takeoff", "checks", "output/submission.zip 8 748 б", "reward 0.969898",
  "/work/ple-solve/data-hall-device-takeoff/verifier/grade.json", "—"),
 ("data-hall-mep-routing", "checks", "output/solution.py 33 315 б", "reward 1.0 dev / 1.0 held-out",
  "/work/ple-solve/data-hall-mep-routing/bench84/metrics.json (+ metrics_504.json)", "—"),
 ("data-hall-mep-routing-offset", "checks", "output/solution.py 37 507 б", "reward 1.0",
  "/work/ple-solve/data-hall-mep-routing-offset/bench/final85/metrics.json", "—"),
 ("division-26-specifications", "checks", "build/stage2/submission.zip 155 231 б", "reward 1.0 / 1.0",
  "/work/ple-solve/division-26-specifications/grade/g_s3/logs/paper_score.json", "—"),
 ("eor-review-corrections", "checks-judge", "build/submission.zip 19 462 б",
  "грейдер 0.701612 · правило 0.879869 · потолок 0.919869 (J1–J3)",
  "results_522/{metrics,paper_score,verify_judge_*}.json + /logs/verifier/grade.json",
  "J1–J3 судьи: 0.04 веса"),
 ("foundation-strategy", "checks-judge", "out/submission.zip 33 276 б",
  "грейдер 0.847229 · правило 0.882547 · потолок 0.932547 (J1–J4)",
  "grade/official/{grade,paper_score,reward}.json", "J1–J4 судьи: 0.05 веса"),
 ("frame-extension-method", "checks", "out/pkg/submission.zip 14 375 б", "reward 0.8068 held-out / 0.8119 dev",
  "/work/ple-solve/frame-extension-method/out/final/paper_heldout.json (+ out/run5dev/paper_dev.json)", "—"),
 ("heat-rejection-life-cycle-cost", "checks", "out/submission.zip 100 582 б", "reward 1.0",
  "/work/ple-solve/heat-rejection-life-cycle-cost/grade/g4/logs/paper_score.json", "—"),
 ("lv-cable-sizing", "checks-judge", "build3/submission.zip 35 905 б",
  "грейдер 0.685657 · правило 0.892650 · потолок 0.926935 (J1–J3)",
  "/work/lv-cable-sizing/off/dev/{paper_result,grade.apply,grade}.json", "J1–J3 судьи: 0.0343 веса"),
 ("mv-conveyance-study", "checks", "build/submission.zip 64 509 б", "reward 0.6024 (запись)",
  "НЕ НАЙДЕНО файла с результатом", "сырые метрики не сохранены"),
 ("roof-deck-design", "checks", "submission.zip 28 565 б", "combined 0.839354",
  "/work/ple-solve/roof/grade/metrics3.json", "—"),
 ("seismic-diaphragm-shear", "checks", "submission.zip 38 498 б", "reward 0.904833",
  "/work/ple-solve/seismic-diaphragm-shear/work/grade/paper.json", "—"),
 ("wind-diaphragm-shear", "checks", "out/submission.zip 54 244 б", "reward 0.7626 (запись)",
  "НЕ НАЙДЕНО файла с результатом", "сырые метрики не сохранены"),
 ("fire-test-validation-memo", "rubric", "output/CFDME-2025-041_Validation_Memo_Section7.docx 46 265 б",
  "мой читатель 48/48 (вес 208), мутации 12/12", "NOTES_506.md", "балл судьи"),
 ("landscape-sheet-revision", "rubric", "output/DSR_Ph3_L4_Street_Tree_Memo_2026-10-31.docx 41 169 б",
  "мой читатель 18/18, мутации 11/12 + 1 эквивалентная", "NOTES_507.md", "балл судьи"),
 ("fill-compaction-acceptance", "rubric", "out/… (см. NOTES_507)", "мой читатель 28/28 + 4 замыкания, мутации 10/10",
  "NOTES_507.md", "балл судьи"),
 ("engineers-estimate-check", "rubric", "out/Correspondence/Client/Memo_to_Callaway_2026-10-31.docx 40 771 б",
  "10 критериев (вес 46) + 4 замыкания = 14/14, мутации 12/12", "NOTES_509.md", "балл судьи"),
 ("emergency-spillway-check", "rubric", "out/Memo_to_Callaway_Spillway_2026-10-31.docx 46 094 б",
  "15 критериев (вес 37) + 5 своих, мутации 20/20", "NOTES_510.md", "балл судьи"),
 ("footing-settlement-verification", "rubric", "out/Thelbridge_Verification_Memo_Item051_BlockC.docx",
  "мой читатель 17/17 + 5 = 22/22, мутации 20/20", "NOTES_511.md", "балл судьи"),
 ("fire-solve-convergence", "rubric", "out/CFDME-2025-041_transient_solve_disposition_revA.docx 50 471 б",
  "мой читатель 43/43 (вес 129), мутации 42/42", "NOTES_512.md", "балл судьи"),
 ("les-mesh-resolution", "rubric", "out/CFDME-2025-041_resolution_note_revA.docx 43 314 б",
  "мой читатель 14/14 (вес 82), мутации 19/19", "NOTES_513.md", "балл судьи"),
 ("shoring-design-verification", "rubric", "out/Thelbridge_Verification_Memo_Item048_BlockB.docx 17 163 б",
  "мой читатель 30/30 (вес 122), мутации 30/30", "NOTES_514.md", "балл судьи"),
 ("permission-to-operate-memo", "rubric", "out/Corwyn_PTO_Memo.docx 42 770 б",
  "мой читатель 41/44 (11/11 доступных), мутации 16/16", "NOTES_515.md",
  "балл судьи; 3 балла веса — работа в OpenProject"),
 ("backfeed-energization-reply", "rubric", "out/Halbray_Backfeed_Reply.docx 43 451 б",
  "мой читатель 59/61 (16/17), мутации 16/16", "NOTES_516.md", "балл судьи"),
 ("solar-supplemental-review", "rubric", "out/Bramwick_Commons_Screen_Memo.docx 32 204 б",
  "мой читатель 22/22 (вес 77), мутации 21/21", "NOTES_519.md", "балл судьи"),
 ("solar-witness-test-package", "rubric", "out/Municipal_Witness_Test_Package.docx 45 225 б",
  "мой читатель 30/30 (вес 63) + 4/4 программных по живым дампам, мутации 28/28", "NOTES_520.md", "балл судьи"),
 ("pre-application-capacity-response", "rubric", "out/ALN-108_PreApplication_Response.docx 46 230 б",
  "мой читатель 35/39 (потолок хоста) → 39/39 с настоящим db_diff, мутации 12/12", "NOTES_517.md + NOTES_518.md",
  "балл судьи"),
]

KIND = {"checks": "checks", "checks-judge": "checks-judge", "rubric": "rubric"}

header = ("| # | задача | тип | что готово (пакет) | что реально проверено | где лежит результат | чего нет |\n"
          "|---|---|---|---|---|---|---|")
lines = [header]
for i, (task, grading, pkg, measured, where, open_) in enumerate(ROWS, 1):
    lines.append(f"| {i} | {task} | {grading} | {pkg} | {measured} | {where} | {open_} |")
table = "\n".join(lines) + "\n"

counts = {}
for r in ROWS:
    counts[r[1]] = counts.get(r[1], 0) + 1
summary = (f"строк {len(ROWS)}: checks {counts.get('checks', 0)} + checks-judge {counts.get('checks-judge', 0)}"
           f" + rubric {counts.get('rubric', 0)} = {sum(counts.values())}")
no_file = [r[0] for r in ROWS if r[4].startswith("НЕ НАЙДЕНО")]
text = f"# Таблица 29 — ход 522\n\n{summary}\n\n{table}\nбез файла-результата: {len(no_file)} — {', '.join(no_file)}\n"

out = "/work/ple-solve/TABLE_29_522.md"
open(out, "w").write(text)
assert len(ROWS) == 29, len(ROWS)
assert sum(counts.values()) == 29
print(summary)
print("no-file:", no_file)
print("written", out, os.path.getsize(out), "bytes")
