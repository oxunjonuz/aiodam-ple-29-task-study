#!/usr/bin/env python3
"""Сверка переписи корпуса PLE: 29 задач по именам.

Источник истины — диск: /work/ple-dataset/tasks/*/task.toml, поле [metadata] grading.
Ручная часть — только состояние работы по каждой задаче (замерялось раньше, ходы 486..520).
Скрипт падает, если список не совпадает с диском или если суммы не сходятся.
"""
import json, os, glob, re, sys

ROOT = '/work/ple-dataset/tasks'

# состояние: measured = балл снят настоящим грейдером задачи (checks / checks-judge)
#           no_judge = пакет собран, балл судьи не измерен (rubric)
# reward: запись из STATUS.md / NOTES; kind уточняет, что именно измерено
CENSUS = [
    # --- 15 задач с машинным грейдером: балл измерен ---
    ("cooling-water-flush-plan",            "measured", "0.9238 dev / 0.9492 held-out"),
    ("data-center-site-model",              "measured", "combined 1.0, 17/17 constraints"),
    ("data-hall-device-takeoff",            "measured", "0.9699"),
    ("data-hall-mep-routing",               "measured", "1.0 / 1.0"),
    ("data-hall-mep-routing-offset",        "measured", "1.0"),
    ("division-26-specifications",          "measured", "1.0 / 1.0"),
    ("eor-review-corrections",              "measured", "0.9199 / 0.8799"),
    ("foundation-strategy",                 "measured", "0.9325 / 0.8825"),
    ("frame-extension-method",              "measured", "0.8068 / 0.8119"),
    ("heat-rejection-life-cycle-cost",      "measured", "1.0"),
    ("lv-cable-sizing",                     "measured", "0.6857 / 0.8926"),
    ("mv-conveyance-study",                 "measured", "0.6024"),
    ("roof-deck-design",                    "measured", "0.8394"),
    ("seismic-diaphragm-shear",             "measured", "0.9048"),
    ("wind-diaphragm-shear",                "measured", "0.7626"),
    # --- 14 rubric-задач: пакет собран, балл судьи не измерен ---
    ("backfeed-energization-reply",         "no_judge", "16/17 = 59/61 своим читателем; официальный путь 1.0 (стаб)"),
    ("emergency-spillway-check",            "no_judge", "пакет + свой читатель"),
    ("engineers-estimate-check",            "no_judge", "пакет + свой читатель"),
    ("fill-compaction-acceptance",          "no_judge", "пакет + свой читатель"),
    ("fire-solve-convergence",              "no_judge", "пакет + свой читатель"),
    ("fire-test-validation-memo",           "no_judge", "48/48 своим читателем, 12/12 мутаций"),
    ("footing-settlement-verification",     "no_judge", "пакет + свой читатель"),
    ("landscape-sheet-revision",            "no_judge", "пакет + свой читатель"),
    ("les-mesh-resolution",                 "no_judge", "14/14 на PDF-двойнике, 19/19 мутаций"),
    ("permission-to-operate-memo",          "no_judge", "41/44 (нет задачи в живом OpenProject)"),
    ("shoring-design-verification",         "no_judge", "30/30, 122/122 веса, 30/30 мутаций"),
    ("solar-supplemental-review",           "no_judge", "22/22, 77/77, 21/21 мутаций"),
    ("solar-witness-test-package",          "no_judge", "30/30 (63/63) + 4/4 программных по живым дампам"),
    ("pre-application-capacity-response",   "no_judge", "39/39, включая 4 критерия по настоящему db_diff"),
]

def grading_of(task):
    txt = open(os.path.join(ROOT, task, 'task.toml')).read()
    m = re.search(r'^grading\s*=\s*"([^"]+)"', txt, re.M)
    return m.group(1) if m else 'MISSING'

disk = sorted(os.path.basename(p) for p in glob.glob(ROOT + '/*') if os.path.isdir(p))
names = [r[0] for r in CENSUS]
errors = []

if len(names) != len(set(names)):
    errors.append('дубликаты в переписи: %s' % sorted({n for n in names if names.count(n) > 1}))
if sorted(names) != disk:
    errors.append('перепись не совпадает с диском: нет в переписи %s; нет на диске %s'
                  % (sorted(set(disk) - set(names)), sorted(set(names) - set(disk))))

rows = []
for task, state, note in CENSUS:
    g = grading_of(task)
    ok = (state == 'measured' and g in ('checks', 'checks-judge')) or \
         (state == 'no_judge' and g == 'rubric')
    if not ok:
        errors.append('%s: состояние %s не соответствует grading=%s' % (task, state, g))
    rows.append({'task': task, 'grading': g, 'state': state, 'measured': note})

measured = [r for r in rows if r['state'] == 'measured']
no_judge = [r for r in rows if r['state'] == 'no_judge']
summary = {
    'tasks_on_disk': len(disk),
    'measured_by_task_grader': len(measured),
    'assembled_judge_score_not_measured': len(no_judge),
    'sum': len(measured) + len(no_judge),
    'grading_counts': {k: sum(1 for r in rows if r['grading'] == k) for k in sorted({r['grading'] for r in rows})},
}

print(json.dumps(summary, ensure_ascii=False, indent=2))
print('\nОШИБКИ:', errors if errors else 'нет')
json.dump({'summary': summary, 'rows': rows, 'errors': errors},
          open('/work/ple-solve/census.json', 'w'), ensure_ascii=False, indent=2)
sys.exit(1 if errors else 0)
