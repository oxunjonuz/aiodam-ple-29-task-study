#!/usr/bin/env python3
"""Build submission/model.ifc from design.py and grade it with the task's OWN
blind grader (frontier_eval/evaluate.py). Exit 0 only if the grader says
FEASIBLE, combined_score == 1.0 and both objective caps hold.

This is the end-to-end test command: it exercises the STEP text, the
ifcopenshell extraction, the semantic gate and the constraint bundle.
"""
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
TASK = Path("/work/ple-dataset/tasks/data-center-site-model")
PY = "/work/venv-verifier/bin/python"


def main() -> int:
    tmp = Path(tempfile.mkdtemp(prefix="dcgrade_"))
    try:
        bench = tmp / "bench"
        shutil.copytree(TASK / "tests" / "evaluator", bench)
        (bench / "submission").mkdir()
        r = subprocess.run([PY, str(HERE / "make_ifc.py"), str(bench / "submission" / "model.ifc")],
                           capture_output=True, text=True)
        if r.returncode != 0:
            print("MAKE_IFC_FAILED", r.stdout[-500:], r.stderr[-800:])
            return 2
        g = subprocess.run([PY, str(bench / "frontier_eval" / "evaluate.py"),
                            "submission/model.ifc"], cwd=str(bench),
                           capture_output=True, text=True)
        if g.returncode != 0:
            print("GRADER_EXIT", g.returncode, g.stderr[-800:])
            return 2
        metrics = json.loads((bench / "metrics.json").read_text())
        verdict = metrics.get("verdict")
        score = metrics.get("combined_score")
        obj = (metrics.get("report", {}) or {}).get("layers", {}).get("4_objective", {})
        gate = metrics.get("extraction_gate", {})
        print(f"verdict={verdict} score={score} buildings={gate.get('n_buildings')} "
              f"objective={obj.get('weighted_total')} mv={obj.get('mv_cable_length_m')} "
              f"road={obj.get('road_length_m')}")
        fails = metrics.get("failed_constraints") or []
        if fails:
            print("FAILED_CONSTRAINTS", fails)
        ok = (verdict == "FEASIBLE" and score == 1.0
              and (obj.get("weighted_total") or 1e9) <= 473.0)
        print("RESULT=" + ("PASS" if ok else "FAIL"))
        return 0 if ok else 1
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    sys.exit(main())
