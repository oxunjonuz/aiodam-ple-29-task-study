"""Layout definition for PLE p6_002 (data-center-site-model), revision 3.

Every number here is a design decision; the truth about whether it works is
check.py, which runs the task's OWN frozen verifier (geobench.verify) on this
dictionary. Nothing here is scored by hand.

Program facts that shaped it (all read off agent_view.json / instance.json):
  * data_hall min footprint 4500 m2, min GFA 7200 m2 -> 2 storeys (GFA 9000);
    the checker's program_coverage needs >= 2 data halls (DH_P1 count 1,
    DH_P2 count 2, cumulative), and the brief says a two-hall campus.
  * coverage cap 15.1 % of 89 600 m2 = 13 529.6 m2; the two halls + SUB + CTP
    + GEN = 11 600 m2 fits; three halls (13 500 + 2 600) would not.
  * GEN (106 dB(A)) must be >= 28 m from every occupied structure and hidden
    from R1/R2; the berm does the hiding because no occupied building may
    stand that close to it.
"""

# building: (id, type, x0, y0, x1, y1, height_m, storeys, phase)
BUILDINGS = [
    ("DH1", "data_hall", 100.0, 190.0, 175.0, 250.0, 8.0, 2, 1),   # 75x60 = 4500, GFA 9000
    ("DH2", "data_hall", 20.0, 190.0, 95.0, 250.0, 8.0, 2, 2),
    ("SUB", "substation", 195.0, 190.0, 235.0, 215.0, 5.0, 1, 1),  # 40x25 = 1000
    ("CTP", "cooling_plant", 245.0, 192.0, 285.0, 212.0, 8.0, 1, 1),  # 40x20 = 800
    ("GEN", "generator_yard", 250.0, 242.0, 290.0, 262.0, 3.0, 1, 1),  # 40x20 = 800
    ("BRM", "berm", 222.0, 218.0, 252.0, 238.0, 12.0, 1, 1),      # 30x20 = 600 screen
    ("RET", "stormwater_retention", 200.0, 20.0, 320.0, 45.0, 0.0, 1, 1),  # 3000, below grade
]

# network: (id, type, [(x, y), ...], width_m, phase)
NETWORKS = [
    ("RD_SPINE", "road", [(180.0, 0.0), (180.0, 182.0)], 6.0, 1),
    ("RD_NORTH", "road", [(98.0, 182.0), (305.0, 182.0)], 6.0, 1),
    ("RD_EAST", "road", [(305.0, 182.0), (305.0, 244.0)], 6.0, 1),
    ("MV_ENTRY", "mv_power", [(320.0, 195.0), (310.0, 186.0), (240.0, 186.0), (240.0, 200.0)], 0.0, 1),
    ("MV_DH1", "mv_power", [(195.0, 200.0), (180.0, 200.0)], 0.0, 1),
    ("MV_DH2", "mv_power", [(195.0, 188.0), (195.0, 184.0), (98.0, 184.0), (98.0, 187.0)], 0.0, 2),
]

GRAPH = {
    "nodes": ["DH1", "DH2", "SUB", "CTP", "GEN", "GATE"],
    "edges": [
        {"u": "SUB", "v": "DH1", "type": "power_feed", "via": "MV_DH1"},
        {"u": "SUB", "v": "DH2", "type": "power_feed", "via": "MV_DH2"},
        {"u": "GATE", "v": "SUB", "type": "utility_feed", "via": "MV_ENTRY"},
    ],
}


def rect(x0, y0, x1, y1):
    return [[x0, y0], [x1, y0], [x1, y1], [x0, y1]]


def layout():
    buildings = []
    for bid, btype, x0, y0, x1, y1, h, st, ph in BUILDINGS:
        buildings.append({"id": bid, "type": btype, "footprint": rect(x0, y0, x1, y1),
                          "height_m": h, "storeys": st, "phase": ph})
    networks = [{"id": nid, "type": t, "geom": [list(p) for p in pts],
                 "width_m": w, "phase": ph} for nid, t, pts, w, ph in NETWORKS]
    return {"buildings": buildings, "networks": networks, "graph": GRAPH}
