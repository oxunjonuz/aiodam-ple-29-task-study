#!/usr/bin/env python3
"""End-to-end test that IMPORTS make_ifc in-process (so a mutation campaign can
see the code it mutates), then grades the produced IFC with the task's own
blind grader.

Exit 0 only if the grader returns FEASIBLE, combined_score == 1.0 and the
weighted objective stays under the 473 cap.
"""
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
TASK = Path("/work/ple-dataset/tasks/data-center-site-model")
PY = "/work/venv-verifier/bin/python"

sys.path.insert(0, str(HERE))
import make_ifc  # noqa: E402


def main() -> int:
    tmp = Path(tempfile.mkdtemp(prefix="dctest_"))
    try:
        bench = tmp / "bench"
        shutil.copytree(TASK / "tests" / "evaluator", bench)
        (bench / "submission").mkdir()
        out = bench / "submission" / "model.ifc"
        argv = sys.argv[:]
        sys.argv = ["make_ifc.py", str(out)]
        try:
            rc = make_ifc.main()
        finally:
            sys.argv = argv
        if rc != 0 or not out.is_file() or out.stat().st_size == 0:
            print("MAKE_IFC_BROKEN")
            return 2
        g = subprocess.run([PY, str(bench / "frontier_eval" / "evaluate.py"),
                            "submission/model.ifc"], cwd=str(bench),
                           capture_output=True, text=True)
        if g.returncode != 0 or not (bench / "metrics.json").is_file():
            print("GRADER_EXIT", g.returncode, g.stderr[-600:])
            return 2
        m = json.loads((bench / "metrics.json").read_text())
        obj = (m.get("report", {}) or {}).get("layers", {}).get("4_objective", {}) or {}
        print(f"verdict={m.get('verdict')} score={m.get('combined_score')} "
              f"objective={obj.get('weighted_total')} "
              f"buildings={(m.get('extraction_gate') or {}).get('n_buildings')}")
        problems = conformance(out)
        for p in problems:
            print("CONFORMANCE:", p)
        ok = (m.get("verdict") == "FEASIBLE"
              and m.get("combined_score") == 1.0
              and (obj.get("weighted_total") or 1e9) <= 473.0
              and not problems)
        print("RESULT=" + ("PASS" if ok else "FAIL"))
        return 0 if ok else 1
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def conformance(path: Path) -> list:
    """Checks the blind grader does NOT make, which docs/ifc_contract.md demands.

    Without these, the emitter can drop the unit assignment, shorten a GUID or
    detach the site from the project and the grade stays 1.0 - the mutation
    campaign showed exactly that. It also caught the reverse gap: ifcopenshell
    0.8.5 silently SKIPS a DATA line whose entity keyword is corrupt, so a
    damaged file still grades FEASIBLE unless the text itself is checked.
    """
    import re

    import ifcopenshell
    import ifcopenshell.util.unit
    import ifcopenshell.validate

    import design

    out = []
    text = path.read_text(encoding="utf-8")
    if not text.startswith("ISO-10303-21;"):
        out.append("not a STEP file header")
    data = text.split("DATA;", 1)[1].rsplit("ENDSEC;", 1)[0]
    lines = [ln for ln in data.strip().splitlines() if ln.strip()]
    bad = [ln for ln in lines if not re.match(r"^#\d+=[A-Z][A-Z0-9_]*\(.*\);$", ln)]
    if bad:
        out.append(f"{len(bad)} DATA line(s) do not parse as '#id=TYPE(...);': "
                   f"{bad[0][:120]}")
    n_buildings = len(design.BUILDINGS)
    n_storeys = sum(max(1, b[7]) for b in design.BUILDINGS)
    expect = {"IfcBuilding": n_buildings,
              "IfcBuildingStorey": n_storeys,
              "IfcExtrudedAreaSolid": n_buildings,
              "IfcPropertySet": n_buildings + 1,
              "IfcSite": 1,
              "IfcProject": 1}
    f = ifcopenshell.open(str(path))
    for typ, want in expect.items():
        got = len(f.by_type(typ))
        if got != want:
            out.append(f"{typ}: {got} entities, expected {want}")
    projects = f.by_type("IfcProject")
    if len(projects) != 1:
        out.append(f"{len(projects)} IfcProject, need 1")
        return out
    proj = projects[0]
    if not proj.UnitsInContext:
        out.append("IfcProject.UnitsInContext is empty (must declare METRE)")
    else:
        try:
            scale = ifcopenshell.util.unit.calculate_unit_scale(f)
        except Exception as e:  # noqa: BLE001
            out.append(f"unit scale unresolved: {e}")
            scale = None
        if scale is not None and abs(scale - 1.0) > 1e-9:
            out.append(f"length unit scale {scale} != 1.0 m")
    sites = f.by_type("IfcSite")
    if len(sites) != 1:
        out.append(f"{len(sites)} IfcSite, need 1")
    else:
        if not any(rel.is_a("IfcRelAggregates") for rel in sites[0].Decomposes):
            out.append("IfcSite is not aggregated under the project")
        for b in f.by_type("IfcBuilding"):
            if sites[0] not in {rel.RelatingObject for rel in b.Decomposes}:
                out.append(f"{b.Name}: not aggregated under the site")
    for root in f.by_type("IfcRoot"):
        if len(root.GlobalId or "") != 22:
            out.append(f"{root.is_a()} GlobalId {root.GlobalId!r} is not 22 chars")
    # every storey elevation must lie inside its own building's solid z-range
    import ifcopenshell.geom
    settings = ifcopenshell.geom.settings()
    settings.set("use-world-coords", True)
    for b in f.by_type("IfcBuilding"):
        shape = ifcopenshell.geom.create_shape(settings, b)
        zs = [shape.geometry.verts[i + 2] for i in range(0, len(shape.geometry.verts), 3)]
        zmin, zmax = min(zs), max(zs)
        for rel in b.IsDecomposedBy or []:
            for e in rel.RelatedObjects:
                if not e.is_a("IfcBuildingStorey"):
                    continue
                elev = float(e.Elevation or 0.0)
                if not (zmin - 0.5 <= elev <= zmax + 0.5):
                    out.append(f"{b.Name}: storey elevation {elev:.2f} m outside "
                               f"solid z-range [{zmin:.2f}, {zmax:.2f}]")
        if (b.Name or "") == "RET" and abs(zmax) > 1e-6:
            out.append(f"RET max Z = {zmax:.3f} m; ground works must read height 0")
    logger = ifcopenshell.validate.json_logger()
    ifcopenshell.validate.validate(f, logger)
    errors = [s for s in logger.statements if s.get("level") == "error"]
    if errors:
        out.append(f"express_rules: {len(errors)} error(s), first: "
                   f"{str(errors[0].get('message'))[:200]}")
    return out


if __name__ == "__main__":
    sys.exit(main())
