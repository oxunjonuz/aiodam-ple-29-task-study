#!/usr/bin/env python3
"""Run the task's OWN frozen verifier (geobench, the same code the grader uses)
on design.py's layout. Exit 0 only if FEASIBLE and both objective caps hold;
prints every violation with its detail so a failure is diagnosable.

This is the test command: `python3 check.py`. It is the only thing allowed to
say whether the design passes.
"""
import json
import sys
from pathlib import Path

TASK = Path("/work/ple-dataset/tasks/data-center-site-model/tests/evaluator")
sys.path.insert(0, str(TASK))

from geobench.verify import verify  # noqa: E402

sys.path.insert(0, str(Path(__file__).resolve().parent))
import design  # noqa: E402


def main() -> int:
    inst = json.loads((TASK / "instance.json").read_text(encoding="utf-8"))
    rep = verify(design.layout(), inst)
    verdict = rep.get("verdict")
    layers = rep.get("layers", {})
    print(f"VERDICT={verdict}")
    for name in ("1_schema", "2_geometry"):
        lay = layers.get(name)
        if lay and not lay["pass"]:
            for e in lay["errors"]:
                print(f"  {name}: {e}")
    l3 = layers.get("3_constraints")
    if l3:
        print(f"constraints {l3['satisfied']}/{l3['total']} fraction={l3['fraction']}")
        for c in l3["per_constraint"]:
            if c["pass"]:
                continue
            for v in c["violations"]:
                print(f"  FAIL {c['id']} ({c['template']}): {v.get('item')} :: {v.get('detail')}")
    if rep.get("checker_errors"):
        print("CHECKER_ERRORS", rep["checker_errors"])
    l4 = layers.get("4_objective")
    if l4:
        print("OBJECTIVE " + json.dumps(l4))
    ok = verdict == "FEASIBLE"
    if ok and l4:
        # the caps are also hard constraints (c13/c14); restate them as a gate
        ok = l4["weighted_total"] <= 473.0
    print("RESULT=" + ("PASS" if ok else "FAIL"))
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
