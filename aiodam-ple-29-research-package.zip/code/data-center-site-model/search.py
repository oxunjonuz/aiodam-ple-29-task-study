#!/usr/bin/env python3
"""Staged search over the plant+berm placement of p6_002.

Fixed: the two data halls (4500 m2 footprint, 2 storeys), the retention basin,
the road topology (corridor spine + north road + east spur) and the MV topology.
Searched: SUB, CTP and GEN positions, then berm rectangles for the sightlines.

The score comes from the task's OWN verifier (geobench.verify) - nothing here
decides whether a layout is good, it only enumerates candidates.
"""
import json
import sys
from pathlib import Path

TASK = Path("/work/ple-dataset/tasks/data-center-site-model/tests/evaluator")
sys.path.insert(0, str(TASK))
from geobench.verify import verify  # noqa: E402

INST = json.loads((TASK / "instance.json").read_text(encoding="utf-8"))

DH1 = ("DH1", "data_hall", 100.0, 190.0, 175.0, 250.0, 8.0, 2, 1)   # 75x60=4500, ph1
DH2 = ("DH2", "data_hall", 20.0, 190.0, 95.0, 250.0, 8.0, 2, 2)     # ph2
RET = ("RET", "stormwater_retention", 200.0, 20.0, 320.0, 45.0, 0.0, 1, 1)
SUB_W, SUB_D = 40.0, 25.0
CTP_W, CTP_D = 40.0, 20.0
GEN_W, GEN_D = 45.0, 20.0
ROAD_Y = 182.0
SPINE_X = 180.0


def rect(x0, y0, x1, y1):
    return [[x0, y0], [x1, y0], [x1, y1], [x0, y1]]


def build(sub, ctp, gen, berms):
    b = []
    for bid, btype, x0, y0, x1, y1, h, st, ph in (DH1, DH2, RET):
        b.append({"id": bid, "type": btype, "footprint": rect(x0, y0, x1, y1),
                  "height_m": h, "storeys": st, "phase": ph})
    for bid, btype, (x0, y0, w, d), h, ph in (("SUB", "substation", sub, 5.0, 1),
                                              ("CTP", "cooling_plant", ctp, 8.0, 1),
                                              ("GEN", "generator_yard", gen, 3.0, 1)):
        b.append({"id": bid, "type": btype, "footprint": rect(x0, y0, x0 + w, y0 + d),
                  "height_m": h, "storeys": 1, "phase": ph})
    for i, (x0, y0, x1, y1) in enumerate(berms):
        b.append({"id": f"BRM{i+1}", "type": "berm", "footprint": rect(x0, y0, x1, y1),
                  "height_m": 12.0, "storeys": 1, "phase": 1})
    east = max(sub[0] + sub[2], ctp[0] + ctp[2], gen[0] + gen[2]) + 10.0
    n = [
        {"id": "RD_SPINE", "type": "road", "geom": [[SPINE_X, 0.0], [SPINE_X, ROAD_Y]],
         "width_m": 6.0, "phase": 1},
        {"id": "RD_NORTH", "type": "road", "geom": [[98.0, ROAD_Y], [east, ROAD_Y]],
         "width_m": 6.0, "phase": 1},
        {"id": "RD_EAST", "type": "road", "geom": [[east, ROAD_Y], [east, gen[1] + 2.0]],
         "width_m": 6.0, "phase": 1},
    ]
    sy = sub[1] + sub[3] / 2.0
    n += [
        {"id": "MV_ENTRY", "type": "mv_power", "width_m": 0.0, "phase": 1,
         "geom": [[320.0, 195.0], [east + 10.0, 190.0], [sub[0] + sub[2] + 5.0, sy]]},
        {"id": "MV_DH1", "type": "mv_power", "width_m": 0.0, "phase": 1,
         "geom": [[sub[0] - 5.0, sy], [177.0, sy]]},
        {"id": "MV_DH2", "type": "mv_power", "width_m": 0.0, "phase": 2,
         "geom": [[sub[0], sub[1] + 2.0], [sub[0] - 8.0, ROAD_Y + 2.0],
                  [98.0, ROAD_Y + 2.0], [98.0, 187.0]]},
    ]
    graph = {"nodes": ["DH1", "DH2", "SUB", "CTP", "GEN", "GATE"],
             "edges": [{"u": "SUB", "v": "DH1", "type": "power_feed", "via": "MV_DH1"},
                       {"u": "SUB", "v": "DH2", "type": "power_feed", "via": "MV_DH2"},
                       {"u": "GATE", "v": "SUB", "type": "utility_feed", "via": "MV_ENTRY"}]}
    return {"buildings": b, "networks": n, "graph": graph}


def score(layout):
    rep = verify(layout, INST)
    if rep["verdict"] in ("SCHEMA_INVALID", "GEOMETRY_INVALID"):
        return -1, rep, 1e9, ["L1" if rep["verdict"] == "SCHEMA_INVALID" else "L2"]
    l3 = rep["layers"]["3_constraints"]
    fails = [c["id"] for c in l3["per_constraint"] if not c["pass"]]
    l4 = rep["layers"].get("4_objective") or {}
    return l3["satisfied"], rep, l4.get("weighted_total", 1e9), fails


def scan(sub_grid, ctp_grid, gens, berms=(), keep=6):
    out = []
    for gen in gens:
        for sub in sub_grid:
            for ctp in ctp_grid:
                lay = build(sub, ctp, gen, berms)
                n, rep, obj, fails = score(lay)
                out.append(((n, -obj), sub, ctp, gen, fails, rep))
    out.sort(key=lambda t: t[0], reverse=True)
    return out[:keep]


def stage(n):
    print(f"\n=== stage {n} ===")


def main() -> int:
    gens = [(240.0 + 5 * i, 242.0, GEN_W, GEN_D) for i in range(0, 4)]
    gens += [(245.0, 238.0, GEN_W, GEN_D)]
    xs = [180.0 + 10 * i for i in range(0, 13)]      # 180..300
    ys = [162.0 + 10 * i for i in range(0, 10)]      # 162..252
    sub_grid = [(x, y, SUB_W, SUB_D) for x in xs for y in ys
                if x + SUB_W <= 302 and y + SUB_D <= 262]
    ctp_grid = [(x, y, CTP_W, CTP_D) for x in xs for y in ys
                if x + CTP_W <= 302 and y + CTP_D <= 262]
    stage(1)
    coarse = scan(sub_grid, ctp_grid, gens)
    for key, sub, ctp, gen, fails, rep in coarse:
        print(f"n={key[0]} obj={-key[1]:.1f} SUB={sub} CTP={ctp} GEN={gen} fails={fails}")

    # refine around the best plant placement with a fine grid
    stage(2)
    key, sub, ctp, gen, fails, rep = coarse[0]
    sub_fine = [(sub[0] + dx, sub[1] + dy, SUB_W, SUB_D)
                for dx in (-7.5, -5, -2.5, 0, 2.5, 5, 7.5)
                for dy in (-7.5, -5, -2.5, 0, 2.5, 5, 7.5)]
    ctp_fine = [(ctp[0] + dx, ctp[1] + dy, CTP_W, CTP_D)
                for dx in (-7.5, -5, -2.5, 0, 2.5, 5, 7.5)
                for dy in (-7.5, -5, -2.5, 0, 2.5, 5, 7.5)]
    gen_fine = [(gen[0] + dx, gen[1] + dy, GEN_W, GEN_D)
                for dx in (-5, -2.5, 0, 2.5, 5) for dy in (-4, -2, 0, 2)]
    fine = scan(sub_fine, ctp_fine, gen_fine)
    for key, sub, ctp, gen, fails, rep in fine:
        print(f"n={key[0]} obj={-key[1]:.1f} SUB={sub} CTP={ctp} GEN={gen} fails={fails}")
    best = fine[0]
    print("\nBEST PLANT:", json.dumps({"sub": best[1], "ctp": best[2], "gen": best[3]}))
    print("fails:", best[4])
    if best[5]["layers"].get("3_constraints"):
        for c in best[5]["layers"]["3_constraints"]["per_constraint"]:
            if not c["pass"]:
                print("  ", c["id"], c["template"], c["violations"])
    return 0


if __name__ == "__main__":
    sys.exit(main())
