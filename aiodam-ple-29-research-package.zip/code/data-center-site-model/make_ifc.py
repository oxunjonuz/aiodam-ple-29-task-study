#!/usr/bin/env python3
"""Emit submission/model.ifc (IFC4 STEP text) from design.layout().

The workspace has no BIM library (the task's own note says so), so the STEP
text is written by hand here, exactly as docs/ifc_contract.md requires:
one IfcProject, one IfcSite, one IfcBuilding per program item with a Body
SweptSolid IfcExtrudedAreaSolid (world-coordinate profile, +Z), a DCD_Layout
pset, real IfcBuildingStorey entities for the storeyed use, and the networks
as the DCD_Networks `json` property on the site.

Usage: python3 make_ifc.py [out.ifc]
"""
import hashlib
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import design  # noqa: E402

ALPHABET = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz_$"


def guid(seed: str) -> str:
    """A valid IfcGloballyUniqueId: 128 bits in 22 base-64 chars.

    22 x 6 = 132 bits, so the leading character holds only the top 4 spare bits
    and must land in 0..3 -- which is exactly what taking 6 bits at a time from
    the least significant end and then reversing produces. (Getting this
    backwards yields 22 chars that ifcopenshell accepts but express_rules
    rejects: 'Guid first character must be either a 0, 1, 2, or 3'.)
    """
    h = hashlib.sha256(seed.encode()).digest()
    n = int.from_bytes(h[:16], "big")
    out = []
    for _ in range(22):
        out.append(ALPHABET[n & 63])
        n >>= 6
    return "".join(reversed(out))


def step_str(s: str) -> str:
    return s.replace("'", "''")


class Step:
    def __init__(self):
        self.lines = []
        self.n = 0

    def add(self, body: str) -> str:
        self.n += 1
        self.lines.append(f"#{self.n}={body};")
        return f"#{self.n}"

    def text(self) -> str:
        head = (
            "ISO-10303-21;\n"
            "HEADER;\n"
            "FILE_DESCRIPTION(('ViewDefinition[DesignTransferView]'),'2;1');\n"
            "FILE_NAME('model.ifc','2026-11-10T00:00:00+00:00',(''),(''),"
            "'hand-written STEP emitter','aiodam','nobody');\n"
            "FILE_SCHEMA(('IFC4'));\n"
            "ENDSEC;\n"
            "DATA;\n"
        )
        return head + "\n".join(self.lines) + "\nENDSEC;\nEND-ISO-10303-21;\n"


def main() -> int:
    out = Path(sys.argv[1] if len(sys.argv) > 1 else "ws/submission/model.ifc")
    lay = design.layout()
    s = Step()

    # units + context
    u_len = s.add("IFCSIUNIT(*,.LENGTHUNIT.,$,.METRE.)")
    u_area = s.add("IFCSIUNIT(*,.AREAUNIT.,$,.SQUARE_METRE.)")
    u_vol = s.add("IFCSIUNIT(*,.VOLUMEUNIT.,$,.CUBIC_METRE.)")
    ua = s.add(f"IFCUNITASSIGNMENT(({u_area},{u_vol},{u_len}))")
    p0 = s.add("IFCCARTESIANPOINT((0.,0.,0.))")
    dz = s.add("IFCDIRECTION((0.,0.,1.))")
    dx = s.add("IFCDIRECTION((1.,0.,0.))")
    ax = s.add(f"IFCAXIS2PLACEMENT3D({p0},{dz},{dx})")
    ctx = s.add(f"IFCGEOMETRICREPRESENTATIONCONTEXT($,'Model',3,1.E-05,{ax},$)")
    sub = s.add(f"IFCGEOMETRICREPRESENTATIONSUBCONTEXT('Body','Model',*,*,*,*,{ctx},$,.MODEL_VIEW.,$)")

    project = s.add(
        f"IFCPROJECT('{guid('project')}',$,'p6_002',"
        f"'Data-center site design, p6_002',$,$,$,({ctx}),{ua})")
    site = s.add(
        f"IFCSITE('{guid('site')}',$,'SITE',$,$,$,$,$,$,$,$,$,$,$)")
    s.add(f"IFCRELAGGREGATES('{guid('site-rel')}',$,$,$,{project},({site}))")

    buildings = []
    for b in lay["buildings"]:
        bid = b["id"]
        pts = b["footprint"]
        z0 = -0.3 if b["type"] == "stormwater_retention" else 0.0
        height = b["height_m"] if b["type"] != "stormwater_retention" else 0.3
        cp = [s.add(f"IFCCARTESIANPOINT(({x:.6f},{y:.6f}))") for x, y in pts]
        cp.append(cp[0])
        poly = s.add(f"IFCPOLYLINE(({','.join(cp)}))")
        prof = s.add(f"IFCARBITRARYCLOSEDPROFILEDEF(.AREA.,$,{poly})")
        org = s.add(f"IFCCARTESIANPOINT((0.,0.,{z0:.6f}))")
        axs = s.add(f"IFCAXIS2PLACEMENT3D({org},{dz},{dx})")
        solid = s.add(f"IFCEXTRUDEDAREASOLID({prof},{axs},{dz},{height:.6f})")
        shape = s.add(f"IFCSHAPEREPRESENTATION({sub},'Body','SweptSolid',({solid}))")
        pds = s.add(f"IFCPRODUCTDEFINITIONSHAPE($,$,({shape}))")
        bld = s.add(f"IFCBUILDING('{guid(bid)}',$,'{step_str(bid)}',$,$,$,{pds},$,$,$,$,$)")
        buildings.append((b, bld))

    rels = ",".join(bld for _, bld in buildings)
    s.add(f"IFCRELAGGREGATES('{guid('bld-rel')}',$,$,$,{site},({rels}))")

    # storeys (one per storey; halls have 2 so their GFA is footprint x 2)
    for b, bld in buildings:
        n = int(b["storeys"])
        h = b["height_m"] if b["type"] != "stormwater_retention" else 0.0
        if b["type"] == "stormwater_retention":
            elevs = [0.0]
        else:
            elevs = [round(h * i / max(n, 1), 6) for i in range(max(n, 1))]
        ents = []
        for i, e in enumerate(elevs):
            ents.append(s.add(
                f"IFCBUILDINGSTOREY('{guid(b['id'] + 'S' + str(i))}',$,"
                f"'{step_str(b['id'])}_S{i+1}',$,$,$,$,$,$,{e:.6f})"))
        s.add(f"IFCRELAGGREGATES('{guid(b['id'] + '-storey')}',$,$,$,{bld},({','.join(ents)}))")

    # DCD_Layout psets
    for b, bld in buildings:
        bid = b["id"]
        props = [
            s.add(f"IFCPROPERTYSINGLEVALUE('LayoutId',$,IFCLABEL('{step_str(bid)}'),$)"),
            s.add(f"IFCPROPERTYSINGLEVALUE('LayoutType',$,IFCLABEL('{b['type']}'),$)"),
            s.add(f"IFCPROPERTYSINGLEVALUE('Phase',$,IFCINTEGER({int(b['phase'])}),$)"),
            s.add(f"IFCPROPERTYSINGLEVALUE('HeightM',$,IFCREAL({b['height_m']:.1f}),$)"),
        ]
        if b["type"] == "data_hall":
            footprint_area = _area(b["footprint"])
            gfa = footprint_area * int(b["storeys"])
            props.append(s.add(
                f"IFCPROPERTYSINGLEVALUE('GrossFloorAreaM2',$,IFCREAL({gfa:.4f}),$)"))
        pset = s.add(f"IFCPROPERTYSET('{guid(bid + '-pset')}',$,'DCD_Layout',$,({','.join(props)}))")
        s.add(f"IFCRELDEFINESBYPROPERTIES('{guid(bid + '-rel')}',$,$,$,({bld}),{pset})")

    # DCD_Networks on the site
    payload = json.dumps({"networks": lay["networks"], "graph": lay["graph"]},
                         separators=(",", ":"))
    prop = s.add(f"IFCPROPERTYSINGLEVALUE('json',$,IFCLABEL('{step_str(payload)}'),$)")
    netpset = s.add(f"IFCPROPERTYSET('{guid('networks')}',$,'DCD_Networks',$,({prop}))")
    s.add(f"IFCRELDEFINESBYPROPERTIES('{guid('networks-rel')}',$,$,$,({site}),{netpset})")

    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(s.text(), encoding="utf-8")
    print(f"wrote {out} ({len(s.text())} bytes, {s.n} entities)")
    return 0


def _area(poly):
    a = 0.0
    for i in range(len(poly)):
        x0, y0 = poly[i]
        x1, y1 = poly[(i + 1) % len(poly)]
        a += x0 * y1 - x1 * y0
    return abs(a) / 2.0


if __name__ == "__main__":
    sys.exit(main())
