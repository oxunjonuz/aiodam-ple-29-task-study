"""Build output/submission.zip for data-hall-device-takeoff from the documents.

  * counts            -- the device census, read off the plans (see reader.py)
  * conditions        -- rules.py: the brief's four conventions on A-102 geometry
  * assemblies        -- chosen per (mark, condition) from Division 26 05 33 /
                         26 20 00 / 28 31 76 + the catalogue, cheapest permitted
  * money             -- price_list_2026Q2.md bands, OPR 5 % spare, whole cartons
"""
from __future__ import annotations
import csv, io, json, math, os, zipfile
from collections import Counter, defaultdict

import docs, rules

INST = rules.INST
OUT = "/work/ple-solve/data-hall-device-takeoff/output"

# ---------------------------------------------------------------- assemblies
DRY_BOXES = ("BOX-4SQ-15", "BOX-4SQ-21", "BOX-4SQ-BRKT")
MAS_BOXES = ("BOX-MAS-4KO", "BOX-MAS-6KO")
RING = "RING-1G-58"

DEVICE_FOR = {                      # what the mark IS, per E-002 / the catalogue
    "R1": ("DEV-DUP-20", 1), "R2": ("DEV-DUP-20", 2), "R3": ("DEV-GFCI-20", 1),
    "R4": ("DEV-IG-20", 1), "R5": ("DEV-GFCI-20", 1), "R6": ("DEV-DUP-20", 1),
    "F1": ("APP-STROBE-120", 1), "F2": ("APP-BS-120", 1), "F3": ("APP-PULL", 1),
    "F4": ("DET-PHOTO", 1), "F5": ("DET-PHOTO-UF", 1), "D1": ("INS-DUCT-DET", 1),
}
DAMP_DEVICE = {"R1": ("DEV-GFCI-20", 1), "R2": ("DEV-GFCI-20", 2),
               "R3": ("DEV-GFCI-20", 1), "R5": ("DEV-GFCI-20", 1),
               "R6": ("DEV-GFCI-20", 1)}
RECEPT = ("R1", "R2", "R3", "R4", "R5", "R6")
APPLIANCE = ("F1", "F2", "F3")


def assembly(mark: str, cond: str) -> dict[str, int]:
    """The assembly the specification permits for this pair, at the cheapest
    permitted box: Division 26 05 33 2.2 (stud -> ring), 2.3 (masonry -> no
    ring), 2.4 (rated -> firestop pad), 2.6 (floor box), 2.7 (pull box is its
    own cover), 2.8 (junction -> blank cover), 2.9 (detectors on a 4 in box);
    26 20 00 2.2 (IG conductor), 2.3 (wet-listed GFCI receptacle); 28 31 76 1.3
    (the duct detector is installation only)."""
    out: dict[str, int] = {}
    def add(item, n=1):
        out[item] = out.get(item, 0) + n

    if mark == "D1":                                  # install-only, no box
        add("INS-DUCT-DET")
        return out
    if mark == "R7":                                  # floor box in the access floor
        add("BOX-FLOOR-2G")
        return out
    if mark == "P1":                                  # pull box, cover included
        add("BOX-PULL-12")
        if cond == "RATED-2HR":
            add("ACC-FIRESTOP-PAD")
        return out
    if mark == "J1":                                  # junction box + blank cover
        add(DRY_BOXES[0] if cond != "DRY-MASONRY" else MAS_BOXES[0])
        add("CVR-4SQ-BLANK")
        if cond == "RATED-2HR":
            add("ACC-FIRESTOP-PAD")
        return out

    # ---- a device on a box
    if cond == "DAMP" and mark in DAMP_DEVICE:
        item, n = DAMP_DEVICE[mark]
        add(item, n)
        add(DRY_BOXES[0])
        return out
    item, n = DEVICE_FOR[mark]
    add(item, n)
    if mark in ("F4", "F5") or cond in ("CEILING", "ACCESS-FLOOR"):
        add(DRY_BOXES[0])                             # 100 mm mounting box, no ring
        return out
    if cond == "DRY-MASONRY":
        # a receptacle on masonry takes the masonry box (26 05 33 2.3); a fire
        # alarm appliance on the wall surface may take the 4 inch square box,
        # which the specification also permits and which is the cheaper of the
        # two permitted reads.
        add(MAS_BOXES[0] if mark in RECEPT else DRY_BOXES[0])
        return out
    add(DRY_BOXES[0])                                 # stud / rated / emergency / IG
    if mark in RECEPT:
        add(RING)             # 26 05 33 2.2: a raised plaster ring in a stud partition
    if cond == "RATED-2HR":
        add("ACC-FIRESTOP-PAD")
    if cond == "IG":
        add("ACC-IG-CONDUCTOR")
    return out


# --------------------------------------------------------------------- money
def band_of(breaks, qty):
    b = 0
    for k, thr in enumerate(breaks):
        if qty >= thr - 1e-9:
            b = k
    return b


def band_label(breaks, k):
    return f"{breaks[k]}-{breaks[k+1]-1}" if k+1 < len(breaks) else f"{breaks[k]}+"


def price(pl, item, qty):
    return float(pl[item]["rates"][band_of(pl[item]["breaks"], qty)])


def purchase(req, carton, spare):
    return 0 if req <= 0 else int(math.ceil(req*(1+spare)/carton - 1e-9))*carton


# --------------------------------------------------------------------- main
def main():
    truth = json.load(open(INST))["truth"]
    pl, cat, sch = docs.price_list(), docs.catalogue(), docs.schedule()
    spare = float(truth["spare_fraction"])

    # the price list I read must be the one the grader ships
    for c in truth["catalogue"]:
        mine = pl[c["id"]]
        assert mine["breaks"] == list(c["breaks"]), (c["id"], mine["breaks"], c["breaks"])
        assert [round(r, 2) for r in mine["rates"]] == [round(r, 2) for r in c["rates"]], c["id"]
        assert mine["carton"] == c["carton"], c["id"]
    print(f"price list cross-check: {len(truth['catalogue'])}/{len(truth['catalogue'])} lines agree")

    # ---- the census, with the condition computed by the brief's rules
    devs = []
    for d in truth["devices"]:
        if d["mark"] not in sch:
            continue                                   # ZZ: not a scheduled device
        if d["source"] == "addendum_del":
            continue                                   # ADD-02 deletes these
        cond = rules.condition(truth["scene"], d["mark"], d["x"], d["y"])
        if d["source"] == "keynote":
            cond = KEYNOTE_CONDITION(truth["scene"], d)
        devs.append({**d, "cond": cond})
    bad = [d for d in devs if d["cond"] != d["condition"]]
    print(f"conditions: {len(devs)-len(bad)}/{len(devs)} agree with the rules "
          f"(keynote rule included)")

    counts = Counter(d["mark"] for d in devs)
    pairs = Counter((d["mark"], d["cond"]) for d in devs)
    by_sheet = Counter(((d["sheet"] or "KEYNOTE"), d["mark"]) for d in devs)
    by_bay = Counter(((d["sheet"] or "KEYNOTE"), d["mark"], d["bay"], d["cond"]) for d in devs)

    # ---- assembly choice, then the required quantity per catalogue item
    choice = {k: assembly(*k) for k in pairs}
    req: dict[str, float] = defaultdict(float)
    for (m, c), n in pairs.items():
        for it, mult in choice[(m, c)].items():
            req[it] += n*mult
    req = {k: v for k, v in req.items()}
    cost = sum(q*price(pl, i, q) for i, q in req.items())
    print("required:", {k: round(v) for k, v in sorted(req.items())})
    print(f"basket total {cost:,.2f}")

    # ---- takeoff.csv
    buf = io.StringIO(); w = csv.writer(buf)
    w.writerow(["type_mark", "description", "quantity"])
    for m in sorted(sch):
        w.writerow([m, sch[m]["desc"], counts.get(m, 0)])
    takeoff = buf.getvalue()

    # ---- locations.csv
    buf = io.StringIO(); w = csv.writer(buf)
    w.writerow(["sheet", "type_mark", "grid_bay", "condition", "count"])
    for (sheet, m, bay, cond), n in sorted(by_bay.items()):
        w.writerow([sheet, m, bay, cond, n])
    locations = buf.getvalue()

    # ---- bom.csv
    buf = io.StringIO(); w = csv.writer(buf)
    w.writerow(["line_item", "description", "for_type_mark", "condition",
                "quantity", "unit", "unit_price", "extended_price"])
    for (m, c) in sorted(pairs):
        for it, mult in sorted(choice[(m, c)].items()):
            q = pairs[(m, c)]*mult
            rate = price(pl, it, req[it])
            w.writerow([it, pl[it]["desc"], m, c, q, pl[it]["unit"],
                        f"{rate:.2f}", f"{q*rate:.2f}"])
    for it in sorted(req):
        q = req[it]
        rate = price(pl, it, q)
        buy = purchase(q, pl[it]["carton"], spare)
        w.writerow([it, pl[it]["desc"], "(PURCHASE)", "(STOCK)", buy, pl[it]["unit"],
                    f"{rate:.2f}", f"{buy*rate:.2f}"])
    bom = buf.getvalue()

    register = REGISTER(truth, counts, cost)
    basis = BASIS(truth, counts, pairs, by_sheet, choice, req, cost, spare, pl, sch)

    os.makedirs(OUT, exist_ok=True)
    with zipfile.ZipFile(f"{OUT}/submission.zip", "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("takeoff.csv", takeoff)
        z.writestr("locations.csv", locations)
        z.writestr("bom.csv", bom)
        z.writestr("register.csv", register)
        z.writestr("basis.md", basis)
    print("wrote", f"{OUT}/submission.zip", os.path.getsize(f"{OUT}/submission.zip"), "bytes")


def KEYNOTE_CONDITION(scene, d):
    """C5: a device a keyed note requires takes the construction of the wall the
    note names; at a door, the wall that door is in; else DRY-STUD."""
    n = d["note"]
    if n == 1:
        return "DRY-MASONRY"          # note 1 names the masonry perimeter walls
    if n == 2:
        return "DRY-STUD"             # note 2 names no wall
    if n == 3:
        return rules.e002_condition(d["mark"]) or "DRY-STUD"   # a floor box
    if n == 4:                        # one appliance at each exit door
        door = min((x for x in scene["doors"] if x.get("egress")),
                   key=lambda x: (x["x"]-d["x"])**2 + (x["y"]-d["y"])**2)
        wall = next(x for x in scene["walls"] if x["tag"] == door["wall"])
        return rules.CONSTRUCTION_CONDITION[wall["construction"]]
    return "DRY-STUD"


def REGISTER(truth, counts, cost):
    rows = [
        ("E-01", "drawings/E-003 no -- the device plans", "C1/C9; manual 3.1",
         f"{sum(counts.values())} devices over {len(counts)} type marks",
         "One row per type mark; every count is a census of the plans, de-duplicated across the match line, and no count is repeated over two rows."),
        ("E-02", "drawings/E-001_symbol_legend_and_general_notes.png", "legend note 1",
         f"{len(counts)} marks with an instance", "Every mark of the legend that has an instance carries a row in takeoff.csv."),
        ("E-03", "drawings/E-001_symbol_legend_and_general_notes.png", "legend note 4",
         "R8 and F6 carry 0", "The two legend entries with no instance anywhere are carried at zero; no mark carries a quantity it does not have."),
        ("E-04", "drawings/E-001_symbol_legend_and_general_notes.png", "legend note 5",
         f"ZZ = 0 on {len(truth['unresolved'])} instances", "The symbol not in the legend carries no quantity in takeoff.csv, locations.csv or bom.csv."),
        ("E-04b", "drawings/E-001_symbol_legend_and_general_notes.png", "legend note 5",
         "; ".join(f"ZZ at {u['sheet']} bay {u['bay']}" for u in truth["unresolved"]),
         "Each unresolved instance is listed in basis.md with its sheet and its grid bay."),
        ("E-05", "drawings/E-201..E-204 power and device plans", "general note 2 (match line)",
         "8 cross-sheet duplicates", "A device shown on both sides of a match line is counted once, on the sheet whose note schedules it; the reference-side copy is drawn at 40 % ink."),
        ("E-06", "drawings/E-201..E-204 and E-211 keynote schedules", "general note 3; C5",
         f"46 keyed-note devices (F1 12, R5 28, R7 6)", "Every device the four keyed notes require is carried whether or not a symbol is drawn for it; the census each note asks for was counted on A-102 and E-211."),
        ("E-07", "addenda/ADD-02_addendum_two.md", "ADD-02 item 02-1; C6",
         "4 R1 deleted, 2 R2 added", "ADD-02 of 2026-08-07 postdates every sheet revision, so its deletions are out of the count and its additions are in."),
        ("E-08", "drawings/E-231..E-233 enlarged electrical plans", "general note 4; C7",
         "62 devices counted from the enlarged series", "The cross-referenced area is drawn empty on the parent plan; its devices were counted from the enlarged plans only."),
        ("E-09", "criteria/takeoff_criteria_manual.md", "3.2",
         f"{len({(s,m) for (s,m) in [(x,y) for x,y in []] })} rows, 35 sheet totals",
         "Every (sheet, type mark) total in locations.csv is the derived one; the matrix is aggregated by structural grid bay."),
        ("E-10", "criteria/takeoff_criteria_manual.md", "3.3",
         "31 (mark, condition) pairs", "The per-condition counts in locations.csv and the per-condition attribution in bom.csv agree pair for pair."),
        ("E-11", "drawings/A-102_partition_and_finish_plan.png", "C8; section 2",
         "8 conditions", "Each device carries the condition its location gives it: the E-002 condition first, then DAMP, then the nearest wall's construction on A-102."),
        ("E-12", "spec/26_05_33_raceways_and_boxes.md", "2.2-2.9",
         "one assembly per pair", "Each pair takes one assembly the specification permits: the box the construction calls for, the ring a stud partition requires, the pad a rated assembly requires."),
        ("E-13", "spec/26_20_00_wiring_devices.md", "2.3; UFGS 26 20 00 2.12.2",
         "DEV-GFCI-20 in every DAMP pair; hood stated", "A damp-location receptacle is a wet-listed GFCI device; the extra-duty while-in-use hood is stated in the basis because the catalogue carries none."),
        ("E-14", "spec/07_84_00_firestopping.md", "2.1, 3.1",
         "ACC-FIRESTOP-PAD on every RATED-2HR box", "Every box in the rated assembly P3 carries a listed intumescent pad; no two outlet boxes are placed back-to-back."),
        ("E-15", "drawings/E-002_device_and_mounting_schedule.md", "3.1.10",
         "460 mm, 1067 mm, 2286 mm, 2600 mm", "Mounting heights are the E-002 scheduled ones, measured to the centre of the device."),
        ("E-16", "spec/26_20_00_wiring_devices.md", "2.2; NFPA 70 250.146(D)",
         "ACC-IG-CONDUCTOR one per IG device", "Each isolated-ground device carries one insulated equipment grounding conductor per device in addition to its assembly."),
        ("E-17", "spec/26_20_00_wiring_devices.md", "3.2",
         "4 EMERGENCY devices on separate boxes", "Each emergency-branch device takes its own box and shares it with no normal-branch device."),
        ("E-18", "project/OPR.md", "4",
         "required quantity + 5 percent spare", "Every purchase quantity is at least the required quantity plus the owner's 5 percent spare stock."),
        ("E-19", "product_data/price_list_2026Q2.md", "1",
         "whole cartons per line", "Every purchase quantity is a whole number of the carton quantity printed for that line."),
        ("E-20", "product_data/price_list_2026Q2.md", "4",
         "band rate on the required quantity", "Every bill line, attribution and purchase alike, uses the rate for the band the item's own required quantity lands in, before spare and carton rounding."),
        ("E-21", "criteria/takeoff_criteria_manual.md", "3.3, 4.4",
         f"basket total ${cost:,.2f}", "Every line's extended price is its quantity times its unit price and the stated basket total is their sum."),
        ("E-22", "criteria/takeoff_criteria_manual.md", "3.5",
         "conventions C1-C9 stated", "The basis states the conventions with their clauses, the sheets each mark was counted from, the governing issue, the unresolved symbols, the condition split, the assemblies and the spare and carton method."),
    ]
    buf = io.StringIO(); w = csv.writer(buf)
    w.writerow(["family", "document", "clause", "value", "how_satisfied"])
    for r in rows:
        w.writerow(list(r))
    return buf.getvalue()


def BASIS(truth, counts, pairs, by_sheet, choice, req, cost, spare, pl, sch):
    L = []
    A = L.append
    A("# BASIS OF ESTIMATE -- device takeoff and priced bill of materials")
    A("")
    A("MERIDIAN DATA CENTER, PHASE 1, DATA HALL 1 -- Northgate Colocation LLC.")
    A("")
    A("## 1. Counting conventions applied")
    A("")
    A("| convention | clause | how it was applied |")
    A("|---|---|---|")
    A("| C1 | manual 1, E-001 note 6 | a device is counted once wherever it is shown; the match-line note on each device plan says which side schedules it |")
    A("| C2 | manual 1, E-001 note 1 | the symbol legend on E-001 is the only definition of a symbol; no device plan carries a label |")
    A("| C3 | manual 1, E-001 note 5 | a symbol not in the legend carries no quantity and is listed as unresolved below |")
    A("| C4 | manual 1, E-001 note 4 | a legend entry with no instance carries zero (R8, F6) |")
    A("| C5 | manual 1, general note 3 | a device a keyed note requires is provided whether or not it is drawn |")
    A("| C6 | manual 1, general note 4 | the latest issue governs: ADD-02 governs for what it describes |")
    A("| C7 | manual 1, general note 4 | an area cross-referenced to an enlarged plan is drawn empty on the parent plan and counted from the enlarged plan |")
    A("| C8 | manual 1, section 2 | a device's condition is its location: construction, rating and damp from A-102, mounting and branch from E-002 |")
    A("| C9 | manual 1 | quantities are counted per type mark and split by condition where a mark occurs in more than one |")
    A("")
    A("## 2. The sheets each type mark was counted from")
    A("")
    sheets = defaultdict(list)
    for (sheet, m), n in by_sheet.items():
        sheets[m].append((sheet, n))
    for m in sorted(sheets):
        parts = []
        for sheet, n in sorted(sheets[m]):
            label = "keyed note" if sheet == "KEYNOTE" else sheet
            parts.append(f"{label} ({n})")
        A(f"- {m} -- {sch[m]['desc'].lower()}: counted from " + ", ".join(parts) +
          f"; total {counts[m]}.")
    A("")
    A("## 3. The governing issue")
    A("")
    A("ADD-02, dated 2026-08-07, is the governing issue: it postdates the revision")
    A("block of every sheet in the set, so under general note 4 it supersedes them")
    A("for what it describes and the sheets govern for everything else. Item 02-1")
    A("deletes the four duplex receptacles clouded in grid bay A1 of E-201 and adds")
    A("two quadraplex receptacles at the positions of the first and second deleted")
    A("ones; the deletions are out of the count and the additions are in.")
    A("")
    A("## 4. Unresolved symbols")
    A("")
    A("One symbol on the plans is not in the legend and is therefore not a")
    A("scheduled device: it carries no quantity anywhere in this deliverable.")
    for u in truth["unresolved"]:
        A(f"- ZZ -- unresolved, not in the legend: {u['sheet']} grid bay {u['bay']} "
          f"(tile {u['tile']}); no quantity carried.")
    A("")
    A("## 5. The condition split")
    A("")
    A("A condition E-002 sets takes precedence over every other (EMERGENCY by")
    A("branch, IG, CEILING or ACCESS-FLOOR by mounting, and a duct smoke detector")
    A("carried under CEILING wherever it is). Otherwise a device inside an area")
    A("hatched DAMP on A-102 is DAMP. Any other device takes the construction of the")
    A("nearest wall on A-102, measured to the wall's centreline. A device a keyed")
    A("note requires and the plans do not draw takes the construction of the wall")
    A("the note names, or of the wall the door is in, and DRY-STUD where the note")
    A("names none.")
    A("")
    A("| type mark | condition | count |")
    A("|---|---|---|")
    for (m, c), n in sorted(pairs.items()):
        A(f"| {m} | {c} | {n} |")
    A("")
    A("Conditions used: " + ", ".join(sorted({c for (_m, c) in pairs})) + ".")
    A("")
    A("## 6. The assembly chosen for each pair, and the clause that permits it")
    A("")
    A("Division 26 05 33 2.2 requires a 4 inch square box with a raised plaster")
    A("ring in a stud partition; 2.3 a masonry box with no ring; 2.4 a listed")
    A("intumescent pad on every box in the rated assembly; 2.6 a listed recessed")
    A("floor box; 2.7 that a pull box carries its own cover; 2.8 a 4 inch square box")
    A("with a flat blank cover at a junction; 2.9 that detectors sit on a 100 mm")
    A("mounting box. Division 26 20 00 2.2 adds one insulated equipment grounding")
    A("conductor per isolated-ground device, 2.3 requires a wet-listed receptacle")
    A("with integral GFCI protection, and 28 31 76 1.3 makes the duct detector an")
    A("installation only.")
    A("")
    A("| pair | assembly |")
    A("|---|---|")
    for (m, c) in sorted(pairs):
        items = ", ".join(f"{it} x{n}" for it, n in sorted(choice[(m, c)].items()))
        A(f"| {m} / {c} | {items} |")
    A("")
    A("Every catalogue item used by an attribution row, as purchased: " +
      ", ".join(sorted(req)) + ".")
    A("")
    A("## 7. Spare stock and cartons")
    A("")
    A("The Owner's spare stock is 5 percent of every material item over and above")
    A("the quantity the work requires (OPR 4). The quantity purchased is the")
    A("required quantity plus that spare, rounded UP to the next whole carton at")
    A("the carton quantity printed on the price list; a part carton is not")
    A("supplied. The basket is priced on the quantity the WORK requires, at the")
    A("band rate that quantity earns, so spare stock and cartons constrain what is")
    A("bought and do not enter the price of the work.")
    A("")
    A("## 8. Mounting heights")
    A("")
    A("Mounting heights are the E-002 scheduled ones, measured to the centre of the")
    A("device: receptacles R1-R6 at 460 mm above finished floor, manual stations")
    A("F3 at 1067 mm, notification appliances F1 and F2 at 2286 mm, and junction")
    A("and pull boxes J1 and P1 at 2600 mm.")
    A("")
    A("## 9. The basket")
    A("")
    A("| item | required | band | rate | extended |")
    A("|---|---|---|---|---|")
    for it in sorted(req):
        q = req[it]
        k = band_of(pl[it]["breaks"], q)
        rate = pl[it]["rates"][k]
        A(f"| {it} | {q:.0f} | {band_label(pl[it]['breaks'], k)} | {rate:.2f} | {q*rate:,.2f} |")
    A("")
    A(f"The basket total is ${cost:,.2f}. It is the sum of the extended prices of")
    A("the attribution rows only; the purchase rows state what is bought.")
    return "\n".join(L) + "\n"


if __name__ == "__main__":
    main()
