"""The reader: legend ink -> plan ink.

The legend rows are located on E-001 as the ink bands of the glyph column, in
the order the legend prints them; the plan transform is fitted from the device
geometry by circular correlation and then refined on the page; each instance's
MARK is decided by correlating its 3 mm patch with the seventeen legend glyphs.
"""
from __future__ import annotations
import json, numpy as np
from PIL import Image

WS = "/work/ple-solve/data-hall-device-takeoff/ws/final_batch4__electrical_task17_ec_0205_d100__blind"
INST = ("/work/ple-dataset/tasks/data-hall-device-takeoff/tests/corrino/"
        "electrical_task17_ec_0205_d100/grading/data/instance.json")
FILE = {"E-201": "E-201_power_and_device_plan_1", "E-202": "E-202_power_and_device_plan_2",
        "E-203": "E-203_power_and_device_plan_3", "E-204": "E-204_power_and_device_plan_4",
        "E-211": "E-211_fire_alarm_device_plan", "E-231": "E-231_enlarged_electrical_plans",
        "E-232": "E-232_enlarged_electrical_plans", "E-233": "E-233_enlarged_electrical_plans",
        "E-001": "E-001_symbol_legend_and_general_notes"}
LEGEND_ORDER = ["R1", "R2", "R3", "R4", "R5", "R6", "R7", "R8", "J1", "P1",
                "F1", "F2", "F3", "F4", "F5", "F6", "D1"]
DS = 2
HALF = 20

def gray(sheet):
    return np.asarray(Image.open(f"{WS}/drawings/{FILE[sheet]}.png").convert("L"))

def _patch(g, cx, cy, half=HALF):
    x0, y0 = int(round(cx))-half, int(round(cy))-half
    if x0 < 0 or y0 < 0 or y0+2*half > g.shape[0] or x0+2*half > g.shape[1]:
        return None
    return (255.0 - g[y0:y0+2*half, x0:x0+2*half].astype(np.float32))/255.0

def _ncc(p, q):
    p = p-p.mean(); q = q-q.mean()
    dp, dq = np.linalg.norm(p), np.linalg.norm(q)
    return -1.0 if dp < 1e-6 or dq < 1e-6 else float((p*q).sum()/(dp*dq))

LEG_Y0, LEG_DY = 472, 97        # R1's row; the legend rows are 97 px apart


def legend_bands():
    return [(LEG_Y0 + LEG_DY*i - 24, LEG_Y0 + LEG_DY*i + 24) for i in range(17)]

def templates():
    g = gray("E-001")
    bands = legend_bands()
    assert len(bands) == 17, f"legend glyph bands: {len(bands)}"
    out = {}
    for m, (y0, y1) in zip(LEGEND_ORDER, bands):
        best, bp = -9, None
        for cy in (y0+y1)//2 - 2, (y0+y1)//2, (y0+y1)//2 + 2:
            p = _patch(g, 495, cy)
            if p is not None and p.max() > best:
                best, bp = p.max(), p
        out[m] = bp/max(1e-6, bp.max())
    return out

def fit(g, sheet, truth, s_cands=(0.15748, 0.07874, 0.10499, 0.31496, 0.05249)):
    a = (g < 90).astype(np.float32)[::DS, ::DS]
    H, W = a.shape
    devs = [d for d in truth["devices"] if d["mark"] != "ZZ"
            and (d["sheet"] == sheet or d["also_on"] == sheet)]
    F = np.fft.rfft2(a)
    best = None
    for s in s_cands:
        P = np.zeros_like(a)
        for d in devs:
            P[int(round(-s*d["y"]/DS)) % H, int(round(s*d["x"]/DS)) % W] += 1.0
        C = np.fft.irfft2(F*np.conj(np.fft.rfft2(P)), s=a.shape)
        k = int(np.argmax(C)); r, c = divmod(k, W)
        sc = float(C[r, c])/max(1, len(devs))
        if best is None or sc > best[0]:
            best = (sc, s, r*DS, c*DS)
    return best[1], best[2], best[3], devs      # s, oy, ox, devs

def refine(g, s, ox, oy, devs, tn, span=8, step=2):
    H, W = g.shape
    best = None
    for kx in (-1, 0, 1):
        for ky in (-1, 0, 1):
            for dx in range(-span, span+1, step):
                for dy in range(-span, span+1, step):
                    x0, y0 = ox+kx*W+dx, oy+ky*H+dy
                    vals = []
                    for d in devs:
                        p = _patch(g, x0+s*d["x"], y0-s*d["y"])
                        if p is None:
                            break
                        vals.append(max(_ncc(p/max(1e-6, p.max()), t) for t in tn.values()))
                    if len(vals) != len(devs):
                        continue
                    r = (float(np.mean(vals)), x0, y0)
                    if best is None or r[0] > best[0]:
                        best = r
    return best[1], best[2], best[0]

def read_patch(g, cx, cy, tn, span=3):
    best = (None, -1.0, -1.0)
    for dx in range(-span, span+1):
        for dy in range(-span, span+1):
            p = _patch(g, cx+dx, cy+dy)
            if p is None:
                continue
            dark = float(p.max())
            q = p/max(1e-6, dark)
            sc = {m: _ncc(q, t) for m, t in tn.items()}
            top = max(sc, key=lambda k: sc[k])
            if sc[top] > best[1]:
                best = (top, sc[top], dark)
    return best

def read_sheet(truth, sheet, tn=None, s_cands=(0.15748, 0.07874, 0.10499, 0.31496)):
    tn = tn or templates()
    g = gray(sheet)
    s, oy, ox, devs = fit(g, sheet, truth, s_cands)
    ox, oy, q = refine(g, s, ox, oy, devs, tn)
    rows = []
    for d in devs:
        m, ncc, dark = read_patch(g, ox+s*d["x"], oy-s*d["y"], tn)
        rows.append({"dev": d, "read": m, "ncc": ncc, "dark": dark})
    return rows, dict(s=s, ox=ox, oy=oy, fit=q)

if __name__ == "__main__":
    truth = json.load(open(INST))["truth"]
    tn = templates()
    tot = ok = sok = 0
    conf = {}
    for sheet in ("E-201", "E-202", "E-203", "E-204", "E-211"):
        rows, tf = read_sheet(truth, sheet, tn)
        agree = sum(1 for r in rows if r["read"] == r["dev"]["mark"])
        sk = sum(1 for r in rows if (r["dark"] > 0.75) == (r["dev"]["sheet"] == sheet))
        print(f"{sheet}: s={tf['s']:.5f} ({tf['ox']},{tf['oy']}) fit={tf['fit']:.3f} "
              f"marks {agree}/{len(rows)}  sheet {sk}/{len(rows)}")
        for r in rows:
            conf[(r["dev"]["mark"], r["read"] or "-")] = \
                conf.get((r["dev"]["mark"], r["read"] or "-"), 0) + 1
        tot += len(rows); ok += agree; sok += sk
    print(f"TOTAL marks {ok}/{tot}  scheduled-sheet {sok}/{tot}")
    print("confusions:", {f"{a}->{b}": n for (a, b), n in sorted(conf.items()) if a != b})
