"""Read the shipped product data: catalogue and price list, as printed."""
from __future__ import annotations
import re

WS = "/work/ple-solve/data-hall-device-takeoff/ws/final_batch4__electrical_task17_ec_0205_d100__blind"

def price_list():
    text = open(f"{WS}/product_data/price_list_2026Q2.md").read()
    out = {}
    for ln in text.splitlines():
        if not ln.startswith("| `"):
            continue
        cells = [c.strip() for c in ln.strip().strip("|").split("|")]
        if len(cells) < 10:
            continue
        item = cells[0].strip("`")
        unit, carton = cells[2], int(cells[3])
        bands = []
        for k in range(4, 10, 2):
            lo = cells[k]
            rate = float(cells[k+1])
            m = re.match(r"(\d+)\s*[–-]\s*(\d+)", lo)
            bands.append((int(m.group(1)) if m else int(lo.rstrip("+")), rate))
        breaks = [b[0] for b in bands]
        out[item] = {"desc": cells[1], "unit": unit, "carton": carton,
                     "breaks": breaks, "rates": [b[1] for b in bands]}
    return out

def catalogue():
    text = open(f"{WS}/product_data/device_catalogue_2026.md").read()
    out = {}
    for ln in text.splitlines():
        if not ln.startswith("| `"):
            continue
        cells = [c.strip() for c in ln.strip().strip("|").split("|")]
        if len(cells) < 7:
            continue
        out[cells[0].strip("`")] = {"desc": cells[1], "mfr": cells[2],
                                    "part": cells[3], "kind": cells[6].lower(),
                                    "listed": tuple(x.strip().upper()
                                                    for x in cells[4].split(","))}
    return out

def schedule():
    """E-002: mark -> description, mounting, branch."""
    text = open(f"{WS}/drawings/E-002_device_and_mounting_schedule.md").read()
    out = {}
    for ln in text.splitlines():
        if not ln.startswith("| ") or ln.startswith("| TYPE") or ln.startswith("|---"):
            continue
        cells = [c.strip() for c in ln.strip().strip("|").split("|")]
        if len(cells) < 8 or not re.fullmatch(r"[RPJFD]\d", cells[0]):
            continue
        out[cells[0]] = {"desc": cells[1], "height": cells[2], "mount": cells[3],
                         "wiring": cells[4], "colour": cells[5], "branch": cells[6]}
    return out

if __name__ == "__main__":
    p = price_list(); c = catalogue(); s = schedule()
    print("price lines", len(p), "catalogue lines", len(c), "schedule rows", len(s))
    for k in ("BOX-4SQ-15", "DEV-DUP-20", "ACC-FIRESTOP-PAD"):
        print(" ", k, p[k])
