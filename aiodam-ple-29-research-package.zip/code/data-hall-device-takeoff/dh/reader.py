"""Independent read of the device plans: transform fitted from geometry, mark
decided by the legend ink on E-001, scheduled sheet decided by ink level."""
from __future__ import annotations
import json, numpy as np
from glyphread import templates, gray, fit, _patch, _ncc, INST, LEGEND_ORDER

TMPL = templates()
TN = {m: (t/max(1e-6, t.max())) for m, t in TMPL.items()}

def refine(g, s, ox, oy, devs, span=8, step=2):
    H, W = g.shape
    best = None
    for kx in (-1, 0, 1):
        for ky in (-1, 0, 1):
            for dx in range(-span, span+1, step):
                for dy in range(-span, span+1, step):
                    x0, y0 = ox+kx*W+dx, oy+ky*H+dy
                    tot = []
                    for d in devs:
                        p = _patch(g, x0+s*d["x"], y0-s*d["y"])
                        if p is None:
                            continue
                        q = p/max(1e-6, p.max())
                        tot.append(max(_ncc(q, t) for t in TN.values()))
                    if not tot:
                        continue
                    r = (float(np.mean(tot)), x0, y0)
                    if best is None or r[0] > best[0]:
                        best = r
    return best[1], best[2], best[0]

def read_sheet(truth, sheet, s_cands=(0.15748, 0.07874, 0.10499, 0.31496)):
    g = gray(sheet)
    (sc, s, oy, ox), devs = fit(g, sheet, truth, s_cands)
    ox, oy, q = refine(g, s, ox, oy, devs)
    out = []
    for d in devs:
        p = _patch(g, ox+s*d["x"], oy-s*d["y"])
        if p is None:
            out.append({"dev": d, "read": None, "ncc": -1.0, "dark": -1.0})
            continue
        dark = float(p.max())
        q2 = p/max(1e-6, dark)
        sc2 = {m: _ncc(q2, t) for m, t in TN.items()}
        best = max(sc2, key=sc2.get)
        out.append({"dev": d, "read": best, "ncc": sc2[best], "dark": dark})
    return out, dict(s=s, ox=ox, oy=oy, fit=q)

if __name__ == "__main__":
    truth = json.load(open(INST))["truth"]
    tot = ok = sched_ok = 0
    for sheet in ("E-201", "E-202", "E-203", "E-204", "E-211"):
        rows, tf = read_sheet(truth, sheet)
        agree = sum(1 for r in rows if r["read"] == r["dev"]["mark"])
        # scheduled on this sheet <=> full ink (alpha 1.0); reference copy <=> 0.4
        sok = sum(1 for r in rows
                  if (r["dark"] > 0.75) == (r["dev"]["sheet"] == sheet))
        seen = [r["read"] for r in rows]
        print(f"{sheet}: transform={tf['s']:.5f} ({tf['ox']},{tf['oy']}) fit={tf['fit']:.3f}")
        print(f"   marks read {agree}/{len(rows)}   sheet(dark/light) {sok}/{len(rows)}")
        for r in rows:
            if r["read"] != r["dev"]["mark"]:
                d = r["dev"]
                print(f"     MISS {d['mark']:3s} sched={d['sheet']:6s} also={d['also_on']:6s} "
                      f"read={str(r['read']):4s} ncc={r['ncc']:.2f} dark={r['dark']:.2f}")
        tot += len(rows); ok += agree; sched_ok += sok
    print(f"TOTAL marks {ok}/{tot}   scheduled-sheet {sched_ok}/{tot}")
