"""Break the package one way at a time and let the frozen grader say whether
the break is noticed."""
import io, json, os, shutil, subprocess, sys, tempfile, zipfile

ROOT = "/work/ple-solve/data-hall-device-takeoff"
SRC = f"{ROOT}/output/submission.zip"
GRADE = ("/work/ple-dataset/tasks/data-hall-device-takeoff/tests/corrino/"
         "electrical_task17_ec_0205_d100/grading/verification/run_grade.py")
PY = "/work/venv-verifier/bin/python"

def load():
    with zipfile.ZipFile(SRC) as z:
        return {n: z.read(n).decode() for n in z.namelist() if not n.endswith("/")}

def grade(files, tag):
    d = tempfile.mkdtemp()
    p = os.path.join(d, "submission.zip")
    with zipfile.ZipFile(p, "w") as z:
        for n, t in files.items():
            z.writestr(n, t)
    m, a = os.path.join(d, "m.json"), os.path.join(d, "a.json")
    subprocess.run([PY, GRADE, p, "--metrics-out", m, "--artifacts-out", a],
                   check=False, capture_output=True)
    met = json.load(open(m)); art = json.load(open(a))
    sat = art.get("satisfied") or {}
    failed = sorted(k for k, v in sat.items() if not v)
    print(f"  {tag:44s} combined={met['combined_score']:.6f}  failed={failed}")
    return met["combined_score"], failed

def main():
    base = load()
    print("mutations against the frozen grader:")
    c0, f0 = grade(base, "M0 unmutated package")

    f = dict(base); f["takeoff.csv"] = f["takeoff.csv"].replace("R1,", "R1,", 1)
    rows = f["takeoff.csv"].splitlines()
    rows = [("R1,RECEPTACLE, DUPLEX, 20 A, 125 V, WALL-MOUNTED,52" if r.startswith("R1,") else r)
            for r in rows]
    f["takeoff.csv"] = "\n".join(rows) + "\n"
    grade(f, "M1 R1 count 51 -> 52")

    f = dict(base)
    f["register.csv"] = "\n".join(r for r in f["register.csv"].splitlines()
                                  if not r.startswith("E-14")) + "\n"
    grade(f, "M2 register row E-14 dropped")

    f = dict(base)
    out = []
    for r in f["bom.csv"].splitlines():
        if r.startswith("ACC-FIRESTOP-PAD") and "(PURCHASE)" not in r:
            continue
        out.append(r)
    f["bom.csv"] = "\n".join(out) + "\n"
    grade(f, "M3 no firestop pad attributed")

    f = dict(base)
    out = []
    for r in f["bom.csv"].splitlines():
        if "(PURCHASE)" in r:
            head, tail = r.rsplit(",", 4)[0], r.rsplit(",", 4)[1:]
            q = int(tail[0]); req = round(q/1.05)
            r = f"{head},{req},{tail[1]},{tail[2]},{req*float(tail[2]):.2f}"
        out.append(r)
    f["bom.csv"] = "\n".join(out) + "\n"
    grade(f, "M4 bought exactly the required quantity")

    f = dict(base)
    out = []
    for r in f["bom.csv"].splitlines():
        if r.startswith("BOX-4SQ-15"):
            head, tail = r.rsplit(",", 4)[0], r.rsplit(",", 4)[1:]
            q, unit = tail[0], tail[1]
            out.append(f"{head},{q},{unit},2.27,{float(q)*2.27:.2f}")
        else:
            out.append(r)
    f["bom.csv"] = "\n".join(out) + "\n"
    grade(f, "M5 BOX-4SQ-15 priced at the 1-74 band")

    f = dict(base)
    f["basis.md"] = f["basis.md"].replace("The basket total is", "The estimate is")
    grade(f, "M6 basis states no basket total")

    f = dict(base)
    f["takeoff.csv"] = f["takeoff.csv"] + "ZZ,UNRESOLVED SYMBOL,2\n"
    grade(f, "M7 a quantity carried for ZZ")

    f = dict(base)
    f["locations.csv"] = "\n".join(
        r for r in f["locations.csv"].splitlines() if not r.startswith("E-231,")) + "\n"
    grade(f, "M8 enlarged-plan rows deleted")

main()
