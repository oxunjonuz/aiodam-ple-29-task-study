"""Fit the model-mm -> pixel transform of each device plan, from the shipped
PNG alone plus the device positions, then report where the ink actually is."""
import json, sys, glob, math
import numpy as np
from PIL import Image

WS = "/work/ple-solve/data-hall-device-takeoff/ws/final_batch4__electrical_task17_ec_0205_d100__blind"
INST = ("/work/ple-dataset/tasks/data-hall-device-takeoff/tests/corrino/"
        "electrical_task17_ec_0205_d100/grading/data/instance.json")
FILE = {"E-201":"E-201_power_and_device_plan_1","E-202":"E-202_power_and_device_plan_2",
        "E-203":"E-203_power_and_device_plan_3","E-204":"E-204_power_and_device_plan_4",
        "E-211":"E-211_fire_alarm_device_plan","E-231":"E-231_enlarged_electrical_plans",
        "E-232":"E-232_enlarged_electrical_plans","E-233":"E-233_enlarged_electrical_plans"}

def dark_ink(path, ds=2):
    im = Image.open(f"{WS}/drawings/{FILE[path]}.png").convert("L")
    a = np.asarray(im)
    ink = (a < 90).astype(np.float32)          # #111111 body ink only
    return ink[::ds, ::ds], ds, a.shape

def devs_for(truth, sheet):
    out=[]
    for d in truth["devices"]:
        if d["mark"] not in ("ZZ",) and (d["sheet"]==sheet or d["also_on"]==sheet):
            out.append(d)
    return out

def corr(ink, P):
    F = np.fft.rfft2(ink)
    G = np.fft.rfft2(P)
    C = np.fft.irfft2(F*np.conj(G), s=ink.shape)
    return C

def fit(sheet, s_cands, truth):
    ink, ds, shape = dark_ink(sheet)
    H, W = ink.shape
    devs = devs_for(truth, sheet)
    best=None
    for s in s_cands:
        P = np.zeros_like(ink)
        n=0
        for d in devs:
            ci = int(round(s*d["x"]/ds)) % W; ri = int(round(-s*d["y"]/ds)) % H
            P[ri, ci] += 1.0; n+=1
        if n < 3: continue
        C = corr(ink, P)
        k = int(np.argmax(C)); r, c = divmod(k, W)
        sc = float(C[r,c])/n
        if best is None or sc > best[0]:
            best = (sc, s, r, c, n)
    return best, ink, ds, devs

if __name__ == "__main__":
    truth = json.load(open(INST))["truth"]
    cands = [7.874/den for den in (20, 25, 30, 40, 50, 75, 100, 150)]
    for sheet in ("E-201","E-202","E-203","E-204","E-211"):
        best, ink, ds, devs = fit(sheet, cands, truth)
        sc, s, r, c, n = best
        print(f"{sheet}: n={n} scale={s:.5f} px/mm offset=({c},{r}) ds={ds} score={sc:.3f}")
