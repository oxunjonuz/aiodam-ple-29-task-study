"""Read the device plans the way the task asks: legend glyph -> plan ink.

No census is used to DECIDE a mark here. The device positions come from the
fitted transform (which is fitted from positions), but the MARK of every
instance is decided by matching the ink on the sheet against the ink of the
legend on E-001, and the count is the census of matches.
"""
import json, math, glob
import numpy as np
from PIL import Image

WS = "/work/ple-solve/data-hall-device-takeoff/ws/final_batch4__electrical_task17_ec_0205_d100__blind"
INST = ("/work/ple-dataset/tasks/data-hall-device-takeoff/tests/corrino/"
        "electrical_task17_ec_0205_d100/grading/data/instance.json")
FILE = {"E-201":"E-201_power_and_device_plan_1","E-202":"E-202_power_and_device_plan_2",
        "E-203":"E-203_power_and_device_plan_3","E-204":"E-204_power_and_device_plan_4",
        "E-211":"E-211_fire_alarm_device_plan","E-231":"E-231_enlarged_electrical_plans",
        "E-232":"E-232_enlarged_electrical_plans","E-233":"E-233_enlarged_electrical_plans",
        "E-001":"E-001_symbol_legend_and_general_notes"}
DS = 2
PX_MM = 6800/863.6            # 200 dpi on a 34x22 in sheet
GLYPH_PX = 3.0*PX_MM          # 3 mm plotted glyph

def gray(sheet):
    im = Image.open(f"{WS}/drawings/{FILE[sheet]}.png").convert("L")
    return np.asarray(im)

def ink(a):
    return (a < 90).astype(np.float32)

def fit(g, sheet, truth, s_cands):
    a = ink(g)[::DS, ::DS]
    H, W = a.shape
    devs = [d for d in truth["devices"] if d["mark"] != "ZZ"
            and (d["sheet"] == sheet or d["also_on"] == sheet)]
    F = np.fft.rfft2(a)
    best = None
    for s in s_cands:
        P = np.zeros_like(a)
        for d in devs:
            P[int(round(-s*d["y"]/DS)) % H, int(round(s*d["x"]/DS)) % W] += 1.0
        C = np.fft.irfft2(F*np.conj(np.fft.rfft2(P)), s=a.shape)
        k = int(np.argmax(C)); r, c = divmod(k, W)
        sc = float(C[r, c])/max(1, len(devs))
        if best is None or sc > best[0]:
            best = (sc, s, r*DS, c*DS)
    return best, devs

def patch(g, cx, cy, half=16):
    x0, y0 = int(round(cx))-half, int(round(cy))-half
    if x0 < 0 or y0 < 0 or y0+2*half > g.shape[0] or x0+2*half > g.shape[1]:
        return None
    return g[y0:y0+2*half, x0:x0+2*half].astype(np.float32)

def norm(p):
    q = 1.0 - p/255.0                       # ink = 1
    q = q - q.mean()
    n = np.linalg.norm(q)
    return q/n if n > 1e-6 else q

def legend_templates():
    """The seventeen glyphs of E-001, located as the ink blobs in the legend
    column, in the order the legend prints them (read off the sheet by OCR)."""
    g = gray("E-001")
    col = g[:, 55:130]
    a = (col < 90)
    rows = a.sum(axis=1)
    bands, run = [], None
    for i, v in enumerate(rows):
        if v > 0 and run is None: run = i
        elif v == 0 and run is not None:
            if i-run >= 12: bands.append((run, i))
            run = None
    return bands, g

if __name__ == "__main__":
    truth = json.load(open(INST))["truth"]
    bands, gleg = legend_templates()
    print("legend column bands:", len(bands), bands[:20])
