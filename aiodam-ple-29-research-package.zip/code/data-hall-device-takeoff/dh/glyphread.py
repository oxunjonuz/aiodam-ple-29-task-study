"""Legend -> plan: read each device's mark off the ink, not off a census."""
from __future__ import annotations
import json, numpy as np
from PIL import Image
from read_sheet import gray, ink, fit, FILE, WS

INST = ("/work/ple-dataset/tasks/data-hall-device-takeoff/tests/corrino/"
        "electrical_task17_ec_0205_d100/grading/data/instance.json")
LEGEND_ORDER = ["R1","R2","R3","R4","R5","R6","R7","R8","J1","P1",
                "F1","F2","F3","F4","F5","F6","D1"]
HALF = 20
LEG_X, LEG_Y0, LEG_DY = 495, 424, 97   # R1 is the first row (OCR: R2 sits at 521)

def _ncc(p, q):
    p = p - p.mean(); q = q - q.mean()
    dp, dq = np.linalg.norm(p), np.linalg.norm(q)
    if dp < 1e-6 or dq < 1e-6:
        return -1.0
    return float((p*q).sum()/(dp*dq))

def _patch(g, cx, cy, half=HALF):
    x0, y0 = int(round(cx))-half, int(round(cy))-half
    if x0 < 0 or y0 < 0 or y0+2*half > g.shape[0] or x0+2*half > g.shape[1]:
        return None
    return (255.0 - g[y0:y0+2*half, x0:x0+2*half].astype(np.float32))/255.0

def templates():
    g = gray("E-001")
    out = {}
    for k, m in enumerate(LEGEND_ORDER):
        p = _patch(g, LEG_X, LEG_Y0 + LEG_DY*k)
        out[m] = p
    return out

def best_fit(truth, sheet, s_cands=(0.15748, 0.07874, 0.10499, 0.31496, 0.05249)):
    """The circular correlation returns the offset modulo the image size, so the
    representative is the one that actually puts the glyphs on the page."""
    g = gray(sheet)
    (score, s, oy, ox), devs = fit(g, sheet, truth, s_cands)
    Himg, Wimg = g.shape
    best = None
    for kx in (-1, 0, 1):
        for ky in (-1, 0, 1):
            cx0, cy0 = ox + kx*Wimg, oy + ky*Himg
            hits = tot = 0.0
            for d in devs:
                cx, cy = cx0 + s*d["x"], cy0 - s*d["y"]
                p = _patch(g, cx, cy)
                if p is None:
                    continue
                tot += 1
                hits += float(p.max())
            if best is None or hits > best[0]:
                best = (hits, cx0, cy0, tot)
    _h, bx, by, placed = best
    return g, s, bx, by, devs, (score, placed, len(devs))

def read(truth, sheet, tmpl, s_cands=(0.15748, 0.07874, 0.10499, 0.31496, 0.05249)):
    g, s, ox, oy, devs, score = best_fit(truth, sheet, s_cands)
    rows = []
    for d in devs:
        cx, cy = ox + s*d["x"], oy - s*d["y"]
        p = _patch(g, cx, cy)
        if p is None:
            rows.append({"dev": d, "mark": None, "ncc": -1, "dark": None}); continue
        dark = float(p.max())
        if dark < 0.35:                       # no ink at all
            rows.append({"dev": d, "mark": None, "ncc": -1, "dark": dark}); continue
        q = p/ max(1e-6, dark)                # contrast-normalise (0.4-alpha copies)
        sc = {m: _ncc(q, t/max(1e-6, t.max())) for m, t in tmpl.items()}
        best = max(sc, key=sc.get)
        rows.append({"dev": d, "mark": best, "ncc": sc[best], "dark": dark,
                     "second": sorted(sc.values())[-2]})
    return rows, (s, ox, oy, score)

if __name__ == "__main__":
    truth = json.load(open(INST))["truth"]
    tmpl = templates()
    for sheet in ("E-202",):
        rows, tf = read(truth, sheet, tmpl)
        print(f"{sheet} transform={tf}")
        ok = 0
        for r in rows:
            d = r["dev"]
            hit = (r["mark"] == d["mark"])
            ok += hit
            print(f"  {d['mark']:3s} sched={d['sheet']:6s} also={d['also_on']:6s} "
                  f"read={str(r['mark']):4s} ncc={r['ncc']:+.3f} dark={(-1 if r['dark'] is None else r['dark']):.2f} {'OK' if hit else ''}")
        print(f"{sheet}: mark read {ok}/{len(rows)}")
