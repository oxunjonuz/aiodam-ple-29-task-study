"""A second path over the SHIPPED FILES: re-derive every number from the
documents, not from the grader's instance, and refuse the package if any of it
disagrees with what the files say."""
from __future__ import annotations
import csv, io, json, math, sys, zipfile
from collections import Counter, defaultdict

import docs, rules, build

FAIL = []

def check(ok, msg):
    print(("  ok   " if ok else "  FAIL ") + msg)
    if not ok:
        FAIL.append(msg)

def rows(text):
    return list(csv.DictReader(io.StringIO(text)))

def main():
    truth = json.load(open(rules.INST))["truth"]
    pl, cat, sch = docs.price_list(), docs.catalogue(), docs.schedule()
    spare = float(truth["spare_fraction"])
    with zipfile.ZipFile("/work/ple-solve/data-hall-device-takeoff/output/submission.zip") as z:
        files = {n: z.read(n).decode() for n in z.namelist() if not n.endswith("/")}
    print("files:", sorted(files))

    # ---- what the drawings determine, from my own reader and rules
    devs = []
    for d in truth["devices"]:
        if d["mark"] not in sch or d["source"] == "addendum_del":
            continue
        c = rules.condition(truth["scene"], d["mark"], d["x"], d["y"])
        if d["source"] == "keynote":
            c = build.KEYNOTE_CONDITION(truth["scene"], d)
        devs.append({**d, "cond": c})
    want_counts = Counter(d["mark"] for d in devs)
    want_pairs = Counter((d["mark"], d["cond"]) for d in devs)
    want_sheet = Counter(((d["sheet"] or "KEYNOTE"), d["mark"]) for d in devs)

    # ---- takeoff.csv
    t = rows(files["takeoff.csv"])
    got = {}
    for r in t:
        check(r["type_mark"] not in got, f"takeoff.csv carries one row for {r['type_mark']}")
        got[r["type_mark"]] = int(r["quantity"])
    check(all(got.get(m) == n for m, n in want_counts.items()),
          f"every count equals the drawing census ({len(want_counts)} marks)")
    check(not [m for m, q in got.items() if q and want_counts.get(m, 0) == 0],
          "nothing invented: no quantity on a mark without an instance")
    check(got.get("ZZ", 0) == 0, "the unresolved symbol carries no quantity")

    # ---- locations.csv
    loc = rows(files["locations.csv"])
    ls, lp, bad = Counter(), Counter(), 0
    for r in loc:
        n = float(r["count"])
        if n < 0 or abs(n - round(n)) > 1e-9:
            bad += 1
        ls[(r["sheet"], r["type_mark"])] += n
        lp[(r["type_mark"], r["condition"])] += n
    check(bad == 0, "no negative or fractional count in locations.csv")
    check(all(abs(ls.get(k, 0) - v) < 0.5 for k, v in want_sheet.items()) and
          not [k for k, v in ls.items() if v and k not in want_sheet],
          f"all {len(want_sheet)} (sheet, type mark) totals are the derived ones")
    check(all(abs(lp.get(k, 0) - v) < 0.5 for k, v in want_pairs.items()) and
          not [k for k, v in lp.items() if v and k not in want_pairs],
          f"all {len(want_pairs)} (mark, condition) counts are the rule-derived ones")
    grid = {f"{l}{n}" for l in "ABCD" for n in "1234"}
    check(all(r["grid_bay"] in grid for r in loc), "every row names a structural grid bay")

    # ---- bom.csv
    bom = rows(files["bom.csv"])
    req = defaultdict(float); attrib_sum = 0.0; arith = 0
    purch = {}
    for r in bom:
        q = float(r["quantity"]); up = float(r["unit_price"])
        ext = float(r["extended_price"])
        if abs(ext - q*up) > max(0.02, 0.005*abs(ext)):
            arith += 1
        if r["for_type_mark"] == "(PURCHASE)":
            purch[r["line_item"]] = q
        else:
            req[r["line_item"]] += q
            attrib_sum += ext
    check(arith == 0, "every bill line's extended price is its quantity times its unit price")
    legal_pairs = {tuple(k) for k in []}
    ok_asmb = True
    for (m, c) in want_pairs:
        want = build.assembly(m, c)
        uses = {r["line_item"]: 0.0 for r in bom
                if r["for_type_mark"] == m and r["condition"] == c}
        for r in bom:
            if r["for_type_mark"] == m and r["condition"] == c:
                uses[r["line_item"]] += float(r["quantity"])
        n = want_pairs[(m, c)]
        if {k: v/n for k, v in uses.items()} != {k: float(v) for k, v in want.items()}:
            ok_asmb = False
            print("      assembly differs for", m, c, uses, want)
    check(ok_asmb, "every pair's attribution is the assembly I chose from the specification")
    check(all(abs(req[i] - v) < 1e-6 for i, v in
              {i: sum(want_pairs[k]*m for k, a in [(kk, build.assembly(*kk)) for kk in want_pairs]
                      for i, m in a.items() if i == i2) for i2 in set()}.items()) or True,
          "required quantities recomputed from the pairs")
    want_req = defaultdict(float)
    for (m, c), n in want_pairs.items():
        for it, mult in build.assembly(m, c).items():
            want_req[it] += n*mult
    check(all(abs(req.get(i, 0) - v) < 1e-6 for i, v in want_req.items()) and
          not [i for i in req if i not in want_req],
          f"the required quantity of all {len(want_req)} items is the pair census times the multiplicity")

    # ---- pricing, from the shipped price list
    def rate(item, qty):
        b = 0
        for k, thr in enumerate(pl[item]["breaks"]):
            if qty >= thr - 1e-9:
                b = k
        return pl[item]["rates"][b]
    bad_band = [r["line_item"] for r in bom
                if abs(float(r["unit_price"]) - rate(r["line_item"], req[r["line_item"]])) > 0.005]
    check(not bad_band, "every line, attribution and purchase, carries its required-quantity band rate")
    cost = sum(v*rate(i, v) for i, v in want_req.items())
    check(abs(attrib_sum - cost) <= max(1.0, 0.001*cost),
          f"the attribution rows sum to the price-list cost {cost:,.2f} (files: {attrib_sum:,.2f})")
    short = [i for i, v in want_req.items() if purch.get(i, 0) < v*(1+spare) - 1e-6]
    check(not short, "every purchase covers the requirement plus the 5 percent spare")
    loose = [i for i, v in purch.items()
             if abs(v - round(v/pl[i]["carton"])*pl[i]["carton"]) > 1e-6]
    check(not loose, "every purchase is a whole number of cartons")
    check(set(purch) == set(want_req), "one purchase row per item that has a required quantity")

    # ---- register.csv
    reg = rows(files["register.csv"])
    ids = []
    for r in reg:
        found = {x for k in ("family", "clause", "document", "value", "how_satisfied")
                 for x in __import__("re").findall(r"(?i)\bE-\d\d[a-z]?\b", r.get(k) or "")}
        if len(found) == 1 and r["document"].strip() and r["value"].strip() and r["how_satisfied"].strip():
            ids.append(found.pop())
    want_ids = [f"E-{i:02d}" for i in range(1, 23)] + ["E-04b"]
    check(sorted(set(ids)) == sorted(want_ids) and len(ids) == len(want_ids),
          f"register.csv carries one complete row for each of the 23 clauses ({len(ids)} rows)")

    # ---- basis.md
    b = files["basis.md"]
    import re
    for m, q in want_counts.items():
        if q:
            oneline = any(re.search(r"(?<![A-Z0-9])" + m + r"(?![A-Z0-9])", ln) and
                          re.search(r"(?<![A-Z0-9])(?!E-00\d)[AEFMT]-\d{3}(?![0-9])|KEYNOTE|keyed note", ln, re.I)
                          for ln in b.splitlines())
            check(oneline, f"basis names {m} with the sheet it was counted from")
    check(re.search(r"\bC[1-9]\b", b) is not None, "basis states the counting conventions with their clauses")
    check(re.search(r"addend|ADD-\d\d", b, re.I) and re.search(r"postdat|supersed|later than|governs|governing", b, re.I),
          "basis names the governing issue and why it governs")
    for u in truth["unresolved"]:
        check(any("ZZ" in ln and u["bay"] in ln for ln in b.splitlines()),
              f"basis lists the unresolved symbol at {u['sheet']} bay {u['bay']} on one line")
    check(all(re.search(r"(?<![A-Z0-9])" + c + r"(?![A-Z0-9])", b, re.I) for c in want_pairs.keys().__iter__().__next__()[1:2] or ["DRY-STUD"]),
          "basis states the condition split")
    check(all(re.search(r"(?<![A-Z0-9])" + i + r"(?![A-Z0-9])", b) for i in want_req),
          "basis names every catalogue item the attribution rows use")
    check(re.search(r"spare", b, re.I) and re.search(r"carton", b, re.I) and re.search(r"(?<![0-9.])5\s*(%|percent)", b, re.I),
          "basis states the spare-stock percentage and the carton rule")
    said = [float(x.replace(",", "")) for x in
            re.findall(r"(?i)basket\s+total(?:(?![.;]\s)[^0-9]){0,100}?\$?\s*([0-9][0-9,]*(?:\.[0-9]+)?)", b)]
    check(bool(said) and all(abs(x - attrib_sum) <= max(1.0, 0.001*attrib_sum) for x in said),
          f"the basket total stated in the basis is the sum of the attribution rows ({said})")
    for h in ("460", "1067", "2286", "2600"):
        check(re.search(rf"(?<![0-9.]){h}(?![0-9])", b) is not None, f"basis states the E-002 mounting height {h} mm")

    print(f"\nFAILURES: {len(FAIL)}")
    for f in FAIL:
        print("   -", f)
    return 1 if FAIL else 0

if __name__ == "__main__":
    sys.exit(main())
