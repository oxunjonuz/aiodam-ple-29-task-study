"""Per-device mark read: the patch is aligned to the nearest pixel of the
fitted transform (+-3 px), then correlated with the 17 legend glyphs."""
from __future__ import annotations
import json, numpy as np
from glyphread import templates, gray, fit, _patch, _ncc, INST, LEGEND_ORDER

TMPL = templates()
TN = {m: (t/max(1e-6, t.max())) for m, t in TMPL.items()}

def read_patch(g, cx, cy, span=3):
    best = (None, -1.0, -1.0)
    for dx in range(-span, span+1):
        for dy in range(-span, span+1):
            p = _patch(g, cx+dx, cy+dy)
            if p is None:
                continue
            dark = float(p.max())
            q = p/max(1e-6, dark)
            sc = {m: _ncc(q, t) for m, t in TN.items()}
            top = max(sc, key=sc.get)
            if sc[top] > best[1]:
                best = (top, sc[top], dark)
    return best

def refine(g, s, ox, oy, devs, span=8, step=2):
    H, W = g.shape
    best = None
    for kx in (-1, 0, 1):
        for ky in (-1, 0, 1):
            for dx in range(-span, span+1, step):
                for dy in range(-span, span+1, step):
                    x0, y0 = ox+kx*W+dx, oy+ky*H+dy
                    vals = []
                    for d in devs:
                        p = _patch(g, x0+s*d["x"], y0-s*d["y"])
                        if p is None:
                            continue
                        q = p/max(1e-6, p.max())
                        vals.append(max(_ncc(q, t) for t in TN.values()))
                    if vals and (best is None or np.mean(vals) > best[0]):
                        best = (float(np.mean(vals)), x0, y0)
    return best[1], best[2], best[0]

def read_sheet(truth, sheet, s_cands=(0.15748, 0.07874, 0.10499, 0.31496)):
    g = gray(sheet)
    (sc, s, oy, ox), devs = fit(g, sheet, truth, s_cands)
    ox, oy, q = refine(g, s, ox, oy, devs)
    out = []
    for d in devs:
        m, ncc, dark = read_patch(g, ox+s*d["x"], oy-s*d["y"])
        out.append({"dev": d, "read": m, "ncc": ncc, "dark": dark})
    return out, dict(s=s, ox=ox, oy=oy, fit=q)

if __name__ == "__main__":
    truth = json.load(open(INST))["truth"]
    tot = ok = sok = 0
    conf = {}
    for sheet in ("E-201", "E-202", "E-203", "E-204", "E-211"):
        rows, tf = read_sheet(truth, sheet)
        agree = sum(1 for r in rows if r["read"] == r["dev"]["mark"])
        sk = sum(1 for r in rows if (r["dark"] > 0.75) == (r["dev"]["sheet"] == sheet))
        print(f"{sheet}: s={tf['s']:.5f} ({tf['ox']},{tf['oy']}) fit={tf['fit']:.3f} "
              f"marks {agree}/{len(rows)}  sheet {sk}/{len(rows)}")
        for r in rows:
            d = r["dev"]
            conf[(d["mark"], r["read"])] = conf.get((d["mark"], r["read"]), 0) + 1
        tot += len(rows); ok += agree; sok += sk
    print(f"TOTAL marks {ok}/{tot}  scheduled-sheet {sok}/{tot}")
    print("confusions:")
    for (a, b), n in sorted(conf.items()):
        if a != b:
            print(f"   {a} -> {b}: {n}")
