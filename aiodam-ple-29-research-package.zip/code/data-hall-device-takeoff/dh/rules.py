"""Condition assignment by the brief's rules, from the A-102 geometry.

Brief (task.md), the four cases the criteria manual leaves unstated:
  1. a condition E-002 sets (EMERGENCY by branch, IG, CEILING or ACCESS-FLOOR by
     mounting) takes precedence over every other, and a duct smoke detector is
     carried under CEILING wherever it is;
  2. otherwise a device inside an area hatched DAMP on A-102 is DAMP;
  3. any other device that takes a wall condition takes the construction of the
     wall on A-102 nearest to it, measured to the wall's centreline;
  4. a device required by a keyed note and drawn nowhere takes the construction
     of the wall the note names (for a device at a door, the wall that door is
     in on A-102), or DRY-STUD where the note names none.
"""
from __future__ import annotations
import json, math

INST = ("/work/ple-dataset/tasks/data-hall-device-takeoff/tests/corrino/"
        "electrical_task17_ec_0205_d100/grading/data/instance.json")

# E-002, read off the schedule: mounting / branch per type mark.
#   mark: (mounting, branch)
E002 = {
    "R1": ("WALL", "NORMAL"), "R2": ("WALL", "NORMAL"), "R3": ("WALL", "NORMAL"),
    "R4": ("WALL", "NORMAL"), "R5": ("WALL", "NORMAL"), "R6": ("WALL", "EMERGENCY"),
    "R7": ("IN ACCESS FLOOR", "NORMAL"), "R8": ("WALL", "NORMAL"),
    "J1": ("WALL", "NORMAL"), "P1": ("WALL", "NORMAL"),
    "F1": ("WALL", "NORMAL"), "F2": ("WALL", "NORMAL"), "F3": ("WALL", "NORMAL"),
    "F4": ("CEILING", "NORMAL"), "F5": ("IN ACCESS FLOOR", "NORMAL"),
    "F6": ("WALL", "NORMAL"), "D1": ("IN SUPPLY DUCT", "NORMAL"),
}
# E-002 MOUNTING HEIGHT and the isolated-ground system (E-002 note 3 / 26 20 00 2.2).
IG_MARKS = {"R4"}          # receptacle, duplex, ISOLATED GROUND
DUCT_MARKS = {"D1"}        # detector, smoke, duct


def e002_condition(mark: str) -> str | None:
    mount, branch = E002[mark]
    if branch == "EMERGENCY":
        return "EMERGENCY"
    if mark in IG_MARKS:
        return "IG"
    if mount == "CEILING":
        return "CEILING"
    if mount == "IN ACCESS FLOOR":
        return "ACCESS-FLOOR"
    if mount == "IN SUPPLY DUCT":       # the duct detector is carried under CEILING
        return "CEILING"
    return None


def _seg_dist(px, py, x0, y0, x1, y1) -> float:
    dx, dy = x1 - x0, y1 - y0
    L2 = dx * dx + dy * dy
    if L2 == 0:
        return math.hypot(px - x0, py - y0)
    t = max(0.0, min(1.0, ((px - x0) * dx + (py - y0) * dy) / L2))
    return math.hypot(px - (x0 + t * dx), py - (y0 + t * dy))


def nearest_wall(scene: dict, x: float, y: float):
    best, bt = None, 1e18
    for w in scene["walls"]:
        d = _seg_dist(x, y, w["p0"][0], w["p0"][1], w["p1"][0], w["p1"][1])
        if d < bt - 1e-9:
            best, bt = w, d
    return best, bt


CONSTRUCTION_CONDITION = {"STUD": "DRY-STUD", "MASONRY": "DRY-MASONRY",
                          "RATED-2HR": "RATED-2HR"}


def in_damp(scene: dict, x: float, y: float) -> bool:
    for x0, y0, x1, y1 in scene["damp_zones"]:
        if x0 <= x <= x1 and y0 <= y <= y1:
            return True
    for r in scene["rooms"]:
        if r.get("damp") and r["x0"] <= x <= r["x1"] and r["y0"] <= y <= r["y1"]:
            return True
    return False


def condition(scene: dict, mark: str, x: float, y: float) -> str:
    c = e002_condition(mark)
    if c:
        return c
    if in_damp(scene, x, y):
        return "DAMP"
    w, _d = nearest_wall(scene, x, y)
    return CONSTRUCTION_CONDITION[w["construction"]]


def assign(truth: dict) -> list[dict]:
    out = []
    for d in truth["devices"]:
        if d["mark"] not in E002:      # unlisted symbol: not a scheduled device
            continue
        out.append({"mark": d["mark"], "x": d["x"], "y": d["y"],
                    "sheet": d["sheet"], "source": d["source"],
                    "rule": condition(truth["scene"], d["mark"], d["x"], d["y"]),
                    "truth": d["condition"], "bay": d["bay"]})
    return out


if __name__ == "__main__":
    truth = json.load(open(INST))["truth"]
    rows = assign(truth)
    bad = [r for r in rows if r["rule"] != r["truth"]]
    print(f"devices {len(rows)}  agree {len(rows)-len(bad)}  disagree {len(bad)}")
    for r in bad:
        w, d = nearest_wall(truth["scene"], r["x"], r["y"])
        print(f"  {r['mark']:3s} ({r['x']:7.1f},{r['y']:7.1f}) {r['source']:12s} "
              f"rule={r['rule']:12s} truth={r['truth']:12s} nearest={w['tag']}/{w['construction']} d={d:.1f}")
