#!/usr/bin/env python3
"""Criteria 3-6 of this task, read from the artifact the judge reads: db_diff.txt.

The diff is written by the task's own helpers/db_diff.py, which loads the before/after
snapshots the world's services export (openproject_dump.sql, nextcloud's database_dump.sql
and nextcloud.db) into SQLite and prints changed rows.  These checks read that text the way
the criteria are worded, not the way it was produced:

  c3  work_packages: the case is there and its status is the one *named* Closed after the run
  c4  journals on that case: a note recording the withholding of the capacity figure
  c5  journals on that case: a note assigning Distribution Planning an open follow-up
  c6  oc_filecache: ALN-108_PreApplication_Response.docx under Correspondence, a Word type,
      matching the delivered file by checksum when one was recorded, else by byte size

Every check also reports the row it read, so a green here is a citation, not a verdict.
"""
from __future__ import annotations

import json
import re
import sqlite3
from pathlib import Path

CASE_SUBJECT = "Respond to the Feeder ALN-108 pre-application request"
DOCX_NAME = "ALN-108_PreApplication_Response.docx"


# ------------------------------------------------------------------ reading the diff text
def _blocks(text: str) -> dict:
    """{database: {table: [row dicts]}} from db_diff.txt, keeping Before/After pairs whole."""
    out: dict[str, dict[str, list[dict]]] = {}
    db = table = None
    for line in text.splitlines():
        m = re.match(r"^=== Database: (\S+) ===", line)
        if m:
            db, table = m.group(1), None
            out.setdefault(db, {})
            continue
        m = re.match(r"^--- Table: (\S+) ---", line)
        if m and db:
            table = m.group(1)
            out[db].setdefault(table, [])
            continue
        if db is None or table is None:
            continue
        s = line.strip()
        for tag in ("Before:", "After: ", "Added: ", "Deleted: "):
            if s.startswith(tag):
                payload = s[len(tag):].strip()
                try:
                    row = json.loads(payload)
                except json.JSONDecodeError:
                    continue
                row["_tag"] = tag.strip(": ")
                out[db][table].append(row)
                break
        else:
            if s.startswith("{") and s.endswith("}"):
                try:
                    row = json.loads(s)
                except json.JSONDecodeError:
                    continue
                row.setdefault("_tag", "+")
                out[db][table].append(row)
    return out


def _pairs(rows: list[dict]) -> list[tuple[dict, dict]]:
    """Consecutive Before/After rows -> (before, after) pairs; lone rows pair with {}."""
    pairs, pending = [], None
    for r in rows:
        if r.get("_tag") == "Before":
            pending = r
            continue
        if r.get("_tag") == "After":
            pairs.append((pending or {}, r))
            pending = None
            continue
        pairs.append(({}, r))
    if pending is not None:
        pairs.append((pending, {}))
    return pairs


def _status_names(dump_sql: Path) -> dict[int, str]:
    """status id -> name, from the after-run OpenProject dump (not from the diff)."""
    names: dict[int, str] = {}
    if not dump_sql.is_file():
        return names
    for line in dump_sql.read_text(encoding="utf-8", errors="replace").splitlines():
        if "INSERT INTO public.statuses " not in line and "INSERT INTO statuses " not in line:
            continue
        m = re.search(r"VALUES \((\d+), '((?:[^']|'')*)', (true|false)", line, re.I)
        if m:
            names[int(m.group(1))] = m.group(2).replace("''", "'")
    return names


# ------------------------------------------------------------------------------- criteria
OP_DUMP = Path("/.apps_data/openproject/openproject_dump.sql")
NC_DUMP = Path("/.apps_data/nextcloud_browser/database_dump.sql")


def c3(db: dict, dump_sql: Path | None = None) -> tuple[bool, str]:
    statuses = _status_names(OP_DUMP)
    rows = db.get(".apps_data/openproject/openproject_dump.sql", {}).get("work_packages", [])
    for before, after in _pairs(rows):
        row = after or before
        if str(row.get("subject", "")).strip() != CASE_SUBJECT:
            continue
        after_id = int(after.get("status_id", row.get("status_id", -1)) or -1)
        before_id = int(before.get("status_id", after_id) or after_id)
        after_name = statuses.get(after_id, f"id {after_id}")
        before_name = statuses.get(before_id, f"id {before_id}")
        ok = after_name.strip().lower() == "closed"
        return ok, (f"work_packages id={row.get('id')} subject={row.get('subject')!r}: "
                    f"status {before_name!r} -> {after_name!r} (ids {before_id}->{after_id})")
    return False, f"no work_packages row in the diff has subject {CASE_SUBJECT!r}"


def _notes_rows(db: dict) -> list[dict]:
    out = []
    for table in ("journals", "work_package_journals"):
        for r in db.get(".apps_data/openproject/openproject_dump.sql", {}).get(table, []):
            if str(r.get("journable_type", "")).lower() not in ("workpackage", "") and table == "journals":
                continue
            if int(r.get("journable_id", 0) or 0) != 44 and table == "journals":
                continue
            if str(r.get("notes", "") or "").strip():
                out.append({**r, "_table": table})
    return out


def c4(db: dict, dump_sql: Path | None = None) -> tuple[bool, str]:
    for r in _notes_rows(db):
        n = str(r["notes"])
        low = n.lower()
        withholds = re.search(r"\bwithh(el|eld|olding|old)\w*\b|\bdefer\w*\b|\bnot confirmed\b|\bis withheld\b", low)
        figure = re.search(r"\bcapacity\b", low) or re.search(r"\b\d+(\.\d+)?\s*mw\b", low)
        ident = re.search(r"aln-108|northline|pxa-2025-0231", low)
        # the criterion rejects a note that communicates a current figure as available
        bad = re.search(r"(available capacity (of|is) [\d.]+ ?mw|[\d.]+ ?mw (of |is )?(available|confirmed|available capacity))", low)
        if withholds and figure and ident and not bad:
            return True, (f"journals row id={r.get('id')} ({r['_table']}) on journable_id={r.get('journable_id')} "
                          f"records the withholding: {n[:180]!r}…")
    return False, "no journal note on the case records a withholding of the capacity figure"


def c5(db: dict, dump_sql: Path | None = None) -> tuple[bool, str]:
    for r in _notes_rows(db):
        n = str(r["notes"])
        low = n.lower()
        ident = re.search(r"aln-108", low)
        owner = re.search(r"distribution planning", low)
        action = re.search(r"\b(confirm|re-?issue|refresh|study|evaluate|determine|update|screen)\w*\b", low)
        open_words = re.sub(r"\b(not|yet|never|isn't|wasn't)\s+(been\s+)?complet\w*", "open", low)
        open_words = re.sub(r"\b(remains?|still)\s+open\b", "open", open_words)
        dead = re.search(r"\b(cancel\w*|no follow-up|no action required|already (done|completed)|"
                         r"complet(?:ed|ion)|closed out|signed off)\b", open_words)
        if ident and owner and action and not dead:
            return True, (f"journals row id={r.get('id')} ({r['_table']}) on journable_id={r.get('journable_id')} "
                          f"assigns Distribution Planning a follow-up: {n[:180]!r}…")
    return False, "no journal note on the case assigns Distribution Planning an open follow-up naming ALN-108"


def c6(db: dict, dump_sql: Path | None = None, docx: Path | None = None) -> tuple[bool, str]:
    """Every copy of oc_filecache in the diff is read; the store writes both, so they must agree."""
    want_size = docx.stat().st_size if docx and docx.is_file() else None
    want_sha = None
    if docx and docx.is_file():
        import hashlib
        want_sha = hashlib.sha256(docx.read_bytes()).hexdigest()
    mimetypes = {}
    if NC_DUMP.is_file():
        for line in NC_DUMP.read_text(encoding="utf-8", errors="replace").splitlines():
            if "INSERT INTO public.oc_mimetypes " in line:
                m = re.search(r"VALUES \((\d+), '([^']*)'", line)
                if m:
                    mimetypes[int(m.group(1))] = m.group(2)
    seen, failures, evidence = 0, [], []
    for dbase, tables in db.items():
        for row in tables.get("oc_filecache", []):
            if str(row.get("name", "")) != DOCX_NAME:
                continue
            seen += 1
            path = str(row.get("path", ""))
            in_folder = "/Correspondence/" in path
            mt_id = int(row.get("mimetype", -1) or -1)
            mt = mimetypes.get(mt_id, "")
            is_docx = "wordprocessingml" in mt or mt == "application/msword"
            size = int(row.get("size", -1) or -1)
            checksum = str(row.get("checksum", "") or "")
            size_ok = want_size is not None and size == want_size
            sum_ok = bool(checksum) and bool(want_sha) and checksum.lower() == want_sha.lower()
            ok = in_folder and is_docx and (sum_ok or (not checksum and size_ok))
            evidence.append(f"{dbase}: fileid={row.get('fileid')} path={path!r} mimetype={mt!r} "
                            f"size={size} (delivered {want_size}) checksum={checksum!r} -> {ok}")
            if not ok:
                failures.append(f"{dbase}: {evidence[-1]}")
    if not seen:
        return False, f"no oc_filecache row named {DOCX_NAME} in the diff"
    return not failures, " | ".join(evidence) if not failures else " | ".join(failures)


def run(db_diff: Path, dump_sql: Path, docx: Path | None) -> dict[int, tuple[bool, str]]:
    text = Path(db_diff).read_text(encoding="utf-8", errors="replace")
    db = _blocks(text)
    return {
        3: c3(db),
        4: c4(db),
        5: c5(db),
        6: c6(db, docx=docx),
    }


if __name__ == "__main__":
    import sys
    d = run(Path(sys.argv[1]), Path(sys.argv[2]) if len(sys.argv) > 2 else Path("/.apps_data/nextcloud_browser/database_dump.sql"),
            Path(sys.argv[3]) if len(sys.argv) > 3 else None)
    for k, (ok, ev) in d.items():
        print(f"c{k}: {'PASS' if ok else 'FAIL'}  {ev}")
