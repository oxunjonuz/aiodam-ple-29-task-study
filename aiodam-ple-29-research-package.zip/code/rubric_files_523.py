#!/usr/bin/env python3
"""Cross-check the rubric deliverables against what is on disk NOW.

For each rubric task: the docx named in NOTES/TABLE, its real path, size, sha256, mtime — and, where
the note recorded a size, whether the file still has it. Nothing is inferred: a path that does not
exist is printed as MISSING.
"""
import hashlib
import json
from pathlib import Path

S = Path("/work/ple-solve")
# task -> (deliverable path, size recorded in table 29 / NOTES, note file that recorded it)
DOCS = {
    "fire-test-validation-memo": ("fire-test-validation-memo/output/CFDME-2025-041_Validation_Memo_Section7.docx", 46265, "NOTES_506.md"),
    "landscape-sheet-revision": ("landscape-sheet-revision/output/DSR_Ph3_L4_Street_Tree_Memo_2026-10-31.docx", 41169, "NOTES_507.md"),
    "fill-compaction-acceptance": ("fill-compaction-acceptance/output/Thelbridge_Materials_Acceptance_Fill_Compaction_2026-0708.docx", None, "NOTES_507.md"),
    "engineers-estimate-check": ("engineers-estimate-check/out/Correspondence/Client/Memo_to_Callaway_2026-10-31.docx", 40771, "NOTES_509.md"),
    "emergency-spillway-check": ("emergency-spillway-check/out/Memo_to_Callaway_Spillway_2026-10-31.docx", 46094, "NOTES_510.md"),
    "footing-settlement-verification": ("/work/foot/out/Thelbridge_Verification_Memo_Item051_BlockC.docx", 17638, "NOTES_511.md"),
    "fire-solve-convergence": ("fire-solve-convergence/out/CFDME-2025-041_transient_solve_disposition_revA.docx", 50471, "NOTES_512.md"),
    "les-mesh-resolution": ("les-mesh-resolution/out/CFDME-2025-041_resolution_note_revA.docx", 43314, "NOTES_513.md"),
    "shoring-design-verification": ("shoring-design-verification/out/Thelbridge_Verification_Memo_Item048_BlockB.docx", 17163, "NOTES_514.md"),
    "permission-to-operate-memo": ("permission-to-operate-memo/out/Corwyn_PTO_Memo.docx", 42770, "NOTES_515.md"),
    "backfeed-energization-reply": ("backfeed-energization-reply/out/Halbray_Backfeed_Reply.docx", 43451, "NOTES_516.md"),
    "solar-supplemental-review": ("/work/ssr/build/Bramwick_Commons_Screen_Memo.docx", 32204, "NOTES_519.md"),
    "solar-witness-test-package": ("/work/wit/out/Municipal_Witness_Test_Package.docx", 45225, "NOTES_520.md"),
    "pre-application-capacity-response": (
        "pre-application-capacity-response/out/ALN-108_PreApplication_Response.docx", 46230, "NOTES_517.md"),
}


def sha(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()


def find_any(pattern):
    hits = sorted(S.glob(pattern))
    return hits


rows = {}
for task, (rel, size_rec, note) in DOCS.items():
    p = Path(rel) if rel.startswith("/") else S / rel
    row = {"recorded_size": size_rec, "note": note}
    if p.is_file():
        row.update(path=rel, size=p.stat().st_size, sha256=sha(p), mtime=p.stat().st_mtime,
                   size_matches_record=(size_rec is None or p.stat().st_size == size_rec))
    else:
        alt = find_any(f"{task}/**/*.docx")
        row.update(path=None, missing=rel, alternatives=[str(a.relative_to(S)) for a in alt][:6])
    rows[task] = row

print(json.dumps(rows, indent=1, sort_keys=True))
