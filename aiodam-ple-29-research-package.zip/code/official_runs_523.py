#!/usr/bin/env python3
"""Run each task's REAL tests/test.sh against the submission on disk now.

Staging: /tests <- <task>/tests, the submission copied to the exact artifact path read from
task.toml's artifacts[0], /logs/verifier emptied. The PATH carries the interpreter that has the
task's requirements (the verifier image installs tests/requirements.txt; here that is
/work/venv-verifier for py3.12 tasks and /work/venv311 for the py3.11 task image).

Every run leaves its whole /logs/verifier under <task>/results_523/official_testsh/ and prints the
reward the official entrypoint wrote.
"""
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

TASKS = Path("/work/ple-dataset/tasks")
SOLVE = Path("/work/ple-solve")

# task -> (submission on disk, interpreter dir for PATH, submission dir in the solve tree)
RUNS = {
    "cooling-water-flush-plan": ("/work/cw/ws/output/submission.zip", "/work/venv-verifier/bin"),
    "data-hall-device-takeoff": ("/work/ple-solve/data-hall-device-takeoff/output/submission.zip",
                                 "/work/venv-verifier/bin"),
    "division-26-specifications": ("/work/ple-solve/division-26-specifications/build/stage2/submission.zip",
                                   "/work/venv-verifier/bin"),
    "heat-rejection-life-cycle-cost": ("/work/ple-solve/heat-rejection-life-cycle-cost/out/submission.zip",
                                       "/work/venv-verifier/bin"),
    "roof-deck-design": ("/work/ple-solve/roof-deck-design/submission.zip", "/work/venv-verifier/bin"),
    "seismic-diaphragm-shear": ("/work/ple-solve/seismic-diaphragm-shear/submission.zip",
                                "/work/venv-verifier/bin"),
    "frame-extension-method": ("/work/ple-solve/frame-extension-method/out/pkg/submission.zip",
                               "/work/venv-verifier/bin"),
}

only = set(sys.argv[1:])
for task, (sub, pybin) in RUNS.items():
    if only and task not in only:
        continue
    tdir = TASKS / task
    toml = (tdir / "task.toml").read_text()
    art = toml.split('artifacts = [', 1)[1].split(']', 1)[0].split(",")[0].strip().strip('"')
    src = Path(sub)
    if not src.is_file():
        print(f"{task}: SUBMISSION MISSING {sub}")
        continue
    # stage tests
    shutil.rmtree("/tests", ignore_errors=True)
    subprocess.run(["cp", "-a", str(tdir / "tests"), "/tests"], check=True)
    dst = Path(art)
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(src, dst)
    shutil.rmtree("/logs/verifier", ignore_errors=True)
    Path("/logs/verifier").mkdir(parents=True)
    env = dict(os.environ, PATH=pybin + ":/usr/local/bin:/usr/bin:/bin")
    t0 = time.time()
    r = subprocess.run(["bash", "/tests/test.sh"], cwd="/", capture_output=True, text=True, env=env)
    dt = time.time() - t0
    out = SOLVE / task / "results_523" / "official_testsh"
    shutil.rmtree(out, ignore_errors=True)
    shutil.copytree("/logs/verifier", out)
    reward = None
    for name in ("reward.txt", "reward.json"):
        p = Path("/logs/verifier") / name
        if p.is_file():
            try:
                d = json.loads(p.read_text())
                reward = d.get("reward") if isinstance(d, dict) else float(p.read_text().strip())
            except Exception:
                reward = p.read_text().strip()
            break
    failed = (Path("/logs/verifier") / "GRADER_FAILED.txt").is_file()
    rec = {"task": task, "submission": sub, "artifact_path": art, "exit": r.returncode,
           "seconds": round(dt, 1), "reward": reward, "grader_failed": failed,
           "stdout_tail": r.stdout[-500:], "stderr_tail": r.stderr[-300:]}
    (out / "RUN.json").write_text(json.dumps(rec, indent=1, default=str))
    print(f"{task}: exit={r.returncode} reward={reward} failed={failed} {dt:.0f}s")
