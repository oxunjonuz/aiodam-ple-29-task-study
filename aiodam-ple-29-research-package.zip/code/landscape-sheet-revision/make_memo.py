#!/usr/bin/env python3
"""Build the memo for task `landscape-sheet-revision` (L-4 street tree revision / 11-30 resubmittal).

Every number in the memo is computed or quoted from a document in environment/filesystem:
  Condition 14        Correspondence/Agency/TM-22-500041_Conditions_of_Approval_03142022.pdf (p.4, group C 14-20)
  L-4 comment         Correspondence/Agency/CC-PW_1stReview_Comments_10092026.pdf (landscape table)
  tree counts         Design-Drafting/Landscape/DSR_Ph3_Landscape_L1-L4.pdf (plant schedule; L-2 frontage summary)
  common area         Tenders-Contracts/DSR_CCRs_CommonArea_Exhibit.pdf (2.5, 2.17)
  TAB calendar        Meeting Notes/EnterpriseTAB_Calendar_Agenda.pdf (2026 table; Section 3)
  pre-app notes       Meeting Notes/DSR_Ph3_PreApp_Meeting_Notes.docx (3.3)
  tracker             Correspondence/DSR_Ph3_Resubmittal_Tracker.xlsx (Milestones; Outstanding Items 9)
  water budget        Reports-Studies/DSR_Ph3_Water_Budget.xlsx (HZ-3, Totals)
  counsel letter      Correspondence/Client/Callaway_counsel_turf_exemption.eml (L-2 only)
"""
import os
from docx import Document
from docx.shared import Pt, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH

OUT = "/work/ple-solve/landscape-sheet-revision/output"
os.makedirs(OUT, exist_ok=True)
PATH = os.path.join(OUT, "DSR_Ph3_L4_Street_Tree_Memo_2026-10-31.docx")

FRONTAGE_LF = 4160
PER_TREE_LF = 20
REQUIRED = FRONTAGE_LF // PER_TREE_LF          # 208
SHOWN = 58
OTHER_TREES = 6 + 10                            # entry monument + park shade, L-1 schedule
GAL_PER_TREE = 2000
CUR_TREES = SHOWN + OTHER_TREES                 # 74, as the water budget states
CUR_HZ3_GAL = CUR_TREES * GAL_PER_TREE          # 148,000
NEW_TREES = REQUIRED + OTHER_TREES              # 224
NEW_HZ3_GAL = NEW_TREES * GAL_PER_TREE          # 448,000
GAL_PER_ACFT = 325851
ADD_ACFT = (NEW_HZ3_GAL - CUR_HZ3_GAL) / GAL_PER_ACFT
CUR_TOTAL = 3.28
NEW_TOTAL = round(2.32 + 0.51 + NEW_HZ3_GAL / GAL_PER_ACFT, 2)


def para(doc, text, size=10.5, bold=False, italic=False, space_after=6, align=None, style=None):
    p = doc.add_paragraph(style=style)
    r = p.add_run(text)
    r.font.size = Pt(size)
    r.bold = bold
    r.italic = italic
    if align is not None:
        p.alignment = align
    p.paragraph_format.space_after = Pt(space_after)
    return p


def rich(doc, chunks, size=10.5, space_after=6, style=None):
    p = doc.add_paragraph(style=style)
    for text, bold, italic in chunks:
        r = p.add_run(text)
        r.font.size = Pt(size)
        r.bold = bold
        r.italic = italic
    p.paragraph_format.space_after = Pt(space_after)
    return p


doc = Document()
sec = doc.sections[0]
sec.left_margin = sec.right_margin = Inches(1.0)
sec.top_margin = Inches(0.8)
sec.bottom_margin = Inches(0.8)
st = doc.styles["Normal"]
st.font.name = "Calibri"
st.font.size = Pt(10.5)

# ---------------------------------------------------------------- letterhead
para(doc, "SUNDIAL ENGINEERING & SURVEY", size=13, bold=True, space_after=0)
para(doc, "4720 South Rainbow Boulevard, Suite 210 · Las Vegas, Nevada 89103 · (702) 555-0142 · NV COA #C-3874",
     size=8.5, space_after=2)
para(doc, "Desert Sage Ranch — Phase 3 · Job No. 2201-03 · IP-26-100288 · FM-26-100290 · TM-22-500041",
     size=8.5, italic=True, space_after=10)

para(doc, "MEMORANDUM", size=12, bold=True, space_after=8)

meta = [
    ("TO:", "Mr. Garrett Nokes, Callaway Land Partners"),
    ("FROM:", "Jonathan R. Kessler, P.E., Principal-in-Charge, Sundial Engineering & Survey"),
    ("CC:", "Max Braddock, P.M. (Sundial); Bea Cortland, P.L.A. (Ocotillo Landscape Studio)"),
    ("DATE:", "October 31, 2026"),
    ("RE:", "Phase 3 landscape sheets, comment L-4 (street frontage trees): whether the 11/30/2026 resubmittal "
            "date can be committed on this revision, and what has to happen first"),
]
tbl = doc.add_table(rows=0, cols=2)
tbl.autofit = False
for k, v in meta:
    row = tbl.add_row().cells
    row[0].width = Inches(0.75)
    row[1].width = Inches(5.75)
    pk = row[0].paragraphs[0]; rk = pk.add_run(k); rk.bold = True; rk.font.size = Pt(10)
    pv = row[1].paragraphs[0]; rv = pv.add_run(v); rv.font.size = Pt(10)
    for c in row:
        for p in c.paragraphs:
            p.paragraph_format.space_after = Pt(2)
para(doc, "", size=6, space_after=2)

# ---------------------------------------------------------------- answer
rich(doc, [("Answer. ", True, False),
           ("We cannot commit to the 11/30/2026 resubmittal date on this revision as it now stands: no significant-change "
            "determination has been issued on the street tree revision required by comment L-4, and until Clark County "
            "Comprehensive Planning issues that determination in writing the review path — and therefore the date — is "
            "undetermined. Condition 14 of the tentative map approval letter for TM-22-500041 dated 03/14/2022 makes a "
            "significant change to landscape and streetscape treatments in common areas subject to design review as a public "
            "hearing before the Enterprise Town Advisory Board and the Planning Commission before any staff-level action, and "
            "the street tree revision is such a change. With the application window for the 11/18/2026 TAB meeting already "
            "closed on 10/28/2026, that path runs to 12/16/2026 at the earliest.", False, False)])

# ---------------------------------------------------------------- 1. the revision
para(doc, "1. What the revision is", size=11, bold=True, space_after=4)
rich(doc, [("Comment L-4 in the Clark County Public Works first-round letter dated 10/09/2026 requires street frontage "
            "planting to meet the Title 30 chapter 30.64 standard of one tree per twenty linear feet of street frontage. "
            f"On {FRONTAGE_LF:,} linear feet of frontage the standard requires {REQUIRED} trees. Sheet L-2 of the current "
            f"set (frontage summary) and the plant schedule on L-1 both show {SHOWN} street trees — {SHOWN} Chilopsis, "
            "Parkinsonia and Prosopis (" + "18 + 22 + 18" + ") across all Phase 3 dedicated street frontages. The revision "
            f"therefore adds {REQUIRED - SHOWN} street trees and changes the streetscape planting plan itself, not merely "
            "its labelling. The comment requires the revised planting plan and a revised annual irrigation demand with the "
            "resubmittal.", False, False)])

# ---------------------------------------------------------------- 2. why condition 14
para(doc, "2. Why Condition 14 governs this revision", size=11, bold=True, space_after=4)
rich(doc, [("Condition 14, the first of the Comprehensive Planning conditions (14 through 20) in the 03/14/2022 "
            "approval letter, reads:", False, False)], space_after=2)
q = doc.add_paragraph()
q.paragraph_format.left_indent = Inches(0.4)
q.paragraph_format.right_indent = Inches(0.4)
qr = q.add_run("\u201cAny significant change to approved plans, including but not limited to landscape and streetscape "
               "treatments in common areas, shall be subject to design review as a public hearing before the applicable "
               "Town Advisory Board and Planning Commission prior to staff-level action.\u201d")
qr.italic = True
qr.font.size = Pt(10)
q.paragraph_format.space_after = Pt(6)
rich(doc, [("Condition 14 expressly covers landscape and streetscape treatments in common areas, and the frontage "
            "planting is exactly that: the Declaration of CC&Rs for Desert Sage Ranch (Book 175, Page 61) defines the "
            "\u201cStreetscape Common Area\u201d as those parcels or strips of Common Area between the right-of-way and the "
            "lots, and provides that each such parcel is owned by the Desert Sage Ranch Community Association, the "
            "homeowners association, and is not part of any lot. The planting the revision changes sits on that "
            "association-owned common area. The revision is therefore squarely within the subject matter Condition 14 "
            "names, and the only open question is whether it is significant — a determination the County makes, not the "
            "design team.", False, False)])

# ---------------------------------------------------------------- 3. determination
para(doc, "3. Where the significant-change determination stands", size=11, bold=True, space_after=4)
rich(doc, [("The party that makes the determination is Clark County Comprehensive Planning. The question was raised with "
            "that Department at the pre-application meeting of 06/22/2026: Odette Marchetti, Principal Planner, observed "
            "that any landscape change from the approved 2022 palette may require review beyond staff level depending on "
            "extent, that the threshold has to be evaluated on the actual proposed change, and that the design team should "
            "provide a red-line comparison of the proposed Phase 3 palette against the 2022 approved palette so that "
            "Planning can make the call once the actual change is on paper. No commitment was made at that meeting, and "
            "no significant-change determination has been issued since. It also remains open on the resubmittal tracker "
            "as of its 10/31/2026 baseline, where Outstanding Item 9 — the Enterprise TAB decision on whether the "
            "landscape resubmittal must go through TAB — is carried as an open item, not a closed one. Comprehensive "
            "Planning is the only party that can close it.", False, False)])

# ---------------------------------------------------------------- 4. counsel
para(doc, "4. What counsel's letter does, and what it does not do", size=11, bold=True, space_after=4)
rich(doc, [("Counsel's letter of Adrienne Vogel (Vogel & Marsh LLP) addresses comment L-2 only. It reasons that the "
            "nonfunctional turf prohibition of AB 356 (2021) and its 12/31/2026 conversion deadline do not apply because "
            "Phase 3 is zoned and mapped single-family residential, and concludes that no landscape change is required on "
            "that ground. That reasoning is confined to turf, and the letter says nothing about Condition 14, about "
            "streetscape planting, or about the street tree count. It therefore does not dispose of the L-4 revision: even "
            "if counsel is right on L-2, the streetscape planting change still has to be measured against Condition 14 by "
            "Comprehensive Planning. We should not represent to the County, and should not assume internally, that the "
            "L-2 exemption resolves the Condition 14 question.", False, False)])

# ---------------------------------------------------------------- 5. calendar
para(doc, "5. The calendar arithmetic, which is what makes the date the issue", size=11, bold=True, space_after=4)
rich(doc, [("Under the Enterprise Town Advisory Board 2026 calendar, applications for a regular meeting are due 21 days "
            "before the meeting. For the 11/18/2026 meeting that window closed on 10/28/2026 — before this memorandum. "
            "The next available Enterprise TAB meeting is 12/16/2026, with the application deadline 11/25/2026 and agenda "
            "posting on 12/06/2026. The Board's action on a planning item is a recommendation, forwarded with the record of "
            "testimony to the Planning Commission, so a significant-change determination would put this revision on a path "
            "of TAB on 12/16/2026, Planning Commission review after that, and only then staff-level action on the "
            "resubmittal.", False, False)])

# ---------------------------------------------------------------- 6. what has to happen
para(doc, "6. What has to happen first, by whom, and by when", size=11, bold=True, space_after=4)
rows = [
    ("1", "Written significant-change determination for the L-4 revision under Condition 14",
     "Clark County Comprehensive Planning (O. Marchetti, Principal Planner)", "Immediately — request by 11/04/2026"),
    ("2", "Red-line comparison of the revised streetscape planting against the approved 2022 palette, "
          "to be the basis of the determination", "Ocotillo Landscape Studio (B. Cortland, P.L.A.)", "With the request"),
    ("3", "Sealed landscape sheets L-1 through L-4 and the revised planting plan and revised annual irrigation demand",
     "Ocotillo Landscape Studio (B. Cortland, P.L.A.)", "Before any resubmittal"),
    ("4", "TAB application for the 12/16/2026 meeting, only if the determination is that this is a significant change",
     "Callaway Land Partners / Sundial", "11/25/2026 (hard)"),
    ("5", "Design review hearing, Enterprise TAB, then Planning Commission",
     "Enterprise TAB (Chair L. Pike); Clark County Planning Commission", "12/16/2026 and following"),
]
t = doc.add_table(rows=1, cols=4)
t.style = "Table Grid"
hdr = ["#", "Action", "Responsible party", "Deadline"]
widths = [Inches(0.3), Inches(2.85), Inches(2.1), Inches(1.25)]
for i, h in enumerate(hdr):
    c = t.rows[0].cells[i]
    c.width = widths[i]
    p = c.paragraphs[0]
    r = p.add_run(h); r.bold = True; r.font.size = Pt(9)
for r_ in rows:
    cells = t.add_row().cells
    for i, val in enumerate(r_):
        cells[i].width = widths[i]
        p = cells[i].paragraphs[0]
        rr = p.add_run(val); rr.font.size = Pt(9)
        p.paragraph_format.space_after = Pt(1)
para(doc, "", size=6, space_after=2)

rich(doc, [("Separately, comment L-1 in the same letter requires the landscape sheets to be sealed by the landscape "
            "architect of record on the resubmittal, and the current sheets still bear an unsigned seal block. The "
            "revised planting plan required by comment L-4 therefore has to be sealed by the landscape architect of "
            "record — Bea Cortland, P.L.A. (NV LA #742), Ocotillo Landscape Studio — before it is resubmitted. That is a "
            "prerequisite in its own right and it is unaffected by the Condition 14 question; the two run in parallel.",
            False, False)])
rich(doc, [("On present facts the first item is the one that gates everything else, and it is the immediate next action: "
            "the request to Comprehensive Planning for a written determination should go out now, with the red-line "
            "comparison attached, so that the answer arrives while there is still time to file for 12/16/2026 if the "
            "answer is adverse. Nothing the design team can do — including completing L-1 through L-4 by 11/04/2026 — "
            "shortens that step.", False, False)])

# ---------------------------------------------------------------- 7. cost of the revision
para(doc, "7. What the revision does to the irrigation demand", size=11, bold=True, space_after=4)
rich(doc, [(f"Comment L-4 requires a revised annual irrigation demand with the resubmittal. On the 08/15/2026 water "
            f"budget the tree hydrozone is {CUR_TREES} trees — {SHOWN} street, 6 entry monument and 10 park shade — at "
            f"2,000 gallons per tree per year, or {CUR_HZ3_GAL:,} gallons ({CUR_HZ3_GAL/GAL_PER_ACFT:.2f} acre-feet), "
            f"inside a Phase 3 total of {CUR_TOTAL:.2f} acre-feet per year. At {REQUIRED} street trees the tree hydrozone "
            f"becomes {NEW_TREES} trees and {NEW_HZ3_GAL:,} gallons ({NEW_HZ3_GAL/GAL_PER_ACFT:.2f} acre-feet): "
            f"{NEW_HZ3_GAL-CUR_HZ3_GAL:,} gallons, or {ADD_ACFT:.2f} acre-feet, more per year, taking the Phase 3 total "
            f"to about {NEW_TOTAL:.2f} acre-feet per year. The worksheet has to be reissued and reconciled to the revised "
            "plant schedule before the landscape sheets are sealed; it is not a formatting exercise.", False, False)])

# ---------------------------------------------------------------- 8. recommendation
para(doc, "8. Recommendation", size=11, bold=True, space_after=4)
recs = [
    "Hold the 11/30/2026 date as a target, not a commitment. On this revision it cannot be committed until Comprehensive "
    "Planning issues the significant-change determination.",
    "Request that written determination from Comprehensive Planning now, attaching the red-line comparison of the "
    "revised streetscape planting against the 2022 approved palette.",
    "If the determination is that the revision is not a significant change, the L-4 revision can proceed through staff "
    "review with the resubmittal and the 11/30/2026 date can be re-affirmed in writing.",
    "If the determination is that it is a significant change, the design review before the Enterprise TAB and the "
    "Planning Commission must precede any staff-level action, the earliest TAB date is 12/16/2026 with the application "
    "due 11/25/2026, and the 12/18/2026 recordation target cannot be met on this revision.",
    "Do not rely on counsel's L-2 letter to close the Condition 14 question. It is confined to the turf prohibition.",
]
for i, txt in enumerate(recs, 1):
    p = doc.add_paragraph(style="List Number")
    r = p.add_run(txt); r.font.size = Pt(10)
    p.paragraph_format.space_after = Pt(3)

rich(doc, [("Please confirm how you wish to proceed, and in particular whether the determination request should go to "
            "Comprehensive Planning over Sundial's signature or over Callaway's.", False, False)])

para(doc, "", size=8, space_after=2)
para(doc, "Jonathan R. Kessler, P.E.", size=10.5, bold=True, space_after=0)
para(doc, "Principal-in-Charge · Sundial Engineering & Survey · Nevada P.E. — supplied under separate seal block",
     size=9, space_after=6)
para(doc, "Attachment (by reference, not enclosed): CC-PW first-round comment letter 10/09/2026, comment L-4; "
          "TM-22-500041 conditions of approval 03/14/2022, Condition 14; Sheets L-1 through L-4; "
          "Phase 3 Landscape Water Budget 08/15/2026.",
     size=8.5, italic=True, space_after=0)

doc.save(PATH)
print("wrote", PATH, os.path.getsize(PATH), "bytes")
print(f"checks: required={REQUIRED} shown={SHOWN} new_trees={NEW_TREES} added_gal={NEW_HZ3_GAL-CUR_HZ3_GAL} "
      f"added_acft={ADD_ACFT:.3f} new_total={NEW_TOTAL}")
