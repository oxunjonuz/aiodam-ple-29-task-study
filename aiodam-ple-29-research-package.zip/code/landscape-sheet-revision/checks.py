#!/usr/bin/env python3
"""Deterministic reader for task `landscape-sheet-revision`: does the deliverable state each of the 18 rubric
criteria?  Written from tests/task.json (the criteria text), not from the memo — the memo is then read blind.

  python3 checks.py [path/to/memo.docx]

Each criterion is a set of required facts (each a list of accept-able regular expressions, all of which must hit
within one window of text) plus a "must not" where the criterion has a polarity.  Exit 0 iff all 18 pass.
"""
import json
import re
import sys
import unicodedata
from pathlib import Path

TASK = Path("/work/ple-dataset/tasks/landscape-sheet-revision/tests/task.json")
DEFAULT = "/work/ple-solve/landscape-sheet-revision/output/DSR_Ph3_L4_Street_Tree_Memo_2026-10-31.docx"


def docx_text(path):
    import docx
    d = docx.Document(path)
    parts = [p.text for p in d.paragraphs]
    for t in d.tables:
        for r in t.rows:
            parts.append(" | ".join(c.text for c in r.cells))
    return "\n".join(parts)


def norm(s):
    s = unicodedata.normalize("NFKC", s)
    s = s.replace("\u2019", "'").replace("\u2018", "'").replace("\u201c", '"').replace("\u201d", '"')
    s = s.replace("\u2013", "-").replace("\u2014", "-").replace("\u00a0", " ")
    return s


def window(text, anchor, size=400):
    """text around every hit of anchor, concatenated."""
    out = []
    for m in re.finditer(anchor, text, re.I):
        out.append(text[max(0, m.start() - size): m.end() + size])
    return "\n...\n".join(out)


# criterion index -> (short name, [required patterns], [forbidden patterns], window anchor)
SPEC = {
    0: ("Condition 14 governs staff-level action",
        [r"condition\s*14", r"TM-22-500041", r"03/14/2022", r"staff.level action"], [], r"condition\s*14"),
    1: ("Condition 14 covers landscape/streetscape in common areas",
        [r"landscape", r"streetscape", r"common area"], [], r"condition\s*14"),
    2: ("street tree revision is within Condition 14",
        [r"street tree", r"(falls|within|squarely).{0,80}(scope|within)", r"condition\s*14"], [],
        r"condition\s*14"),
    3: ("streetscape is HOA-owned common area",
        [r"homeowners association|community association", r"owned by", r"common area"], [],
        r"homeowners association|community association"),
    4: ("no significant-change determination issued",
        [r"no significant.change determination has been issued"], [], r"significant.change determination"),
    5: ("Comprehensive Planning makes the determination",
        [r"comprehensive planning", r"(makes|issues|make) the .{0,30}determination|makes the decision|"
         r"the party that makes the determination"],
        [r"public works.{0,60}(makes|issues).{0,30}determination"], r"comprehensive planning"),
    6: ("TAB applications due 21 days before",
        [r"21 days", r"(before|prior)"], [], r"21 days"),
    7: ("11/18 window closed 10/28/2026",
        [r"11/18/2026", r"10/28/2026", r"closed"], [], r"10/28/2026"),
    8: ("next available TAB is 12/16/2026",
        [r"12/16/2026", r"next available"], [], r"12/16/2026"),
    9: ("TAB action is a recommendation to Planning Commission",
        [r"recommendation", r"planning commission"], [], r"recommendation"),
    10: ("design review before staff-level action",
         [r"design review", r"(prior to|before)", r"staff.level action"], [], r"design review"),
    11: ("11/30 cannot be committed until the determination issues",
         [r"11/30/2026", r"(cannot|can not|not).{0,60}commit", r"determination"],
         [], r"cannot commit"),
    12: ("the determination is the immediate next action",
         [r"immediate next action", r"(written )?determination"], [], r"immediate next action"),
    13: ("58 street trees on the current sheets",
         [r"\b58\b", r"street tree"], [], r"\b58\b"),
    14: ("208 required by one per 20 lf",
         [r"\b208\b", r"(twenty|20) linear feet|1 tree per 20|one tree per twenty"], [], r"\b208\b"),
    15: ("revised planting plan sealed by the LA of record",
         [r"seal", r"landscape architect of record", r"revised planting plan"],
         [r"without a seal", r"need not be sealed", r"may be issued without"], r"seal"),
    16: ("one readable memo document", [], [], None),
    17: ("addressed to Callaway, dated 10/31/2026",
         [r"callaway", r"(october 31, 2026|10/31/2026)"], [], "TO_LINE"),
}


def main(argv):
    path = argv[1] if len(argv) > 1 else DEFAULT
    text = norm(docx_text(path))
    crit = json.load(open(TASK))["verifiers"]
    fails = []
    print(f"reader on {path}")
    print(f"  {len(text)} chars, {len(crit)} criteria\n")
    for i, (name, req, forb, anchor) in SPEC.items():
        if i == 16:  # one readable memo: structural, not textual
            ok = len(text.strip()) > 300
            detail = f"{len(text)} chars in one document"
        else:
            if anchor == "TO_LINE":
                to = re.search(r"^TO:.*$", text, re.M)
                dt = re.search(r"^(DATE|Dated?):.*$", text, re.M)
                scope = ((to.group(0) if to else "") + "\n" + (dt.group(0) if dt else ""))
            else:
                scope = window(text, anchor) if anchor else text
            ok = all(re.search(p, scope, re.I) for p in req) and not any(re.search(p, scope, re.I) for p in forb)
            missing = [p for p in req if not re.search(p, scope, re.I)]
            detail = "missing: " + "; ".join(missing[:3]) if missing else "all facts present in one window"
        w = crit[i]["config_input"].get("numerical_weight")
        print(f"  [{'PASS' if ok else 'FAIL'}] {i:2d} w={w:<2} {name}  — {detail}")
        if not ok:
            fails.append(i)
    weight = sum(crit[i]["config_input"]["numerical_weight"] for i in fails)
    print(f"\nFAILURES: {len(fails)} criteria (weight {weight} of 77) {fails if fails else ''}")
    return 0 if not fails else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv))
