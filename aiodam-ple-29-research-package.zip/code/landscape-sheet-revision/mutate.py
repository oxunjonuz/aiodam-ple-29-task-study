#!/usr/bin/env python3
"""Mutation run for the landscape memo: break the delivered .docx one way at a time and see whether the
deterministic reader (checks.py) goes red.  A mutation that survives is a place to read, not automatically a bug —
but every one here is a fact the rubric names, so all twelve should be caught.

  python3 mutate.py
"""
import re
import shutil
import subprocess
import sys
from pathlib import Path

import docx

SRC = Path("/work/ple-solve/landscape-sheet-revision/output/DSR_Ph3_L4_Street_Tree_Memo_2026-10-31.docx")
WORK = Path("/work/ple-solve/landscape-sheet-revision/mut")
PY = "/work/venv-verifier/bin/python"
CHECKS = "/work/ple-solve/landscape-sheet-revision/checks.py"

MUTANTS = [
    ("M01", r"\b58\b", "74", "street tree count on the current sheets"),
    ("M02", r"\b208\b", "200", "trees required by the standard"),
    ("M03", r"10/28/2026", "11/04/2026", "the 11/18 application window closing date"),
    ("M04", r"12/16/2026", "11/18/2026", "the next available TAB meeting"),
    ("M05", r"no significant-change determination has been issued",
     "a significant-change determination has been issued", "polarity of the determination"),
    ("M06", r"Mr\. Garrett Nokes, Callaway Land Partners", "Ms. Lorna Pike, Enterprise Town Advisory Board",
     "the addressee"),
    ("M07", r"October 31, 2026", "November 14, 2026", "the memo date"),
    ("M08", r"Clark County Comprehensive Planning", "Clark County Public Works", "who makes the determination"),
    ("M09", r"The revised planting plan required by comment L-4 therefore has to be sealed by the landscape architect "
            r"of record", "The revised planting plan may be issued without a seal", "the LA-of-record seal"),
    ("M10", r"We cannot commit", "We can commit", "whether the date can be committed"),
    ("M11", r"applications for a regular meeting are due 21 days before the meeting",
     "applications for a regular meeting are due 30 days before the meeting", "the 21-day application rule"),
    ("M12", r"recommendation, forwarded", "final action, forwarded", "TAB action being a recommendation"),
]


def mutate(src, dst, pattern, repl):
    d = docx.Document(str(src))
    n = 0

    def do(par):
        nonlocal n
        for run in par.runs:
            new, k = re.subn(pattern, repl, run.text)
            if k:
                run.text = new
                n += k

    for p in d.paragraphs:
        do(p)
    for t in d.tables:
        for r in t.rows:
            for c in r.cells:
                for p in c.paragraphs:
                    do(p)
    d.save(str(dst))
    return n


def main():
    WORK.mkdir(exist_ok=True)
    base = subprocess.run([PY, CHECKS, str(SRC)], capture_output=True, text=True)
    if base.returncode != 0:
        print("baseline is not green — fix that first"); print(base.stdout[-800:]); return 2
    print("baseline: green (0 of 18 criteria fail)\n")
    survivors = []
    for mid, pat, rep, what in MUTANTS:
        dst = WORK / f"{mid}.docx"
        k = mutate(SRC, dst, pat, rep)
        if k == 0:
            print(f"  {mid} NOT APPLIED ({what}) — pattern did not match"); survivors.append(mid); continue
        r = subprocess.run([PY, CHECKS, str(dst)], capture_output=True, text=True)
        failed = re.findall(r"\[FAIL\]\s+(\d+) w=\s*(\d+)\s+(.*?)  —", r.stdout)
        caught = r.returncode != 0
        label = ", ".join(f"#{i} {nm.strip()}" for i, w, nm in failed) or "—"
        print(f"  {'CAUGHT ' if caught else 'SURVIVED'} {mid} ({what}, {k} substitution(s)) -> {label}")
        if not caught:
            survivors.append(mid)
    print(f"\n{len(MUTANTS)-len(survivors)}/{len(MUTANTS)} caught; survivors: {survivors or 'none'}")
    return 0 if not survivors else 1


if __name__ == "__main__":
    sys.exit(main())
