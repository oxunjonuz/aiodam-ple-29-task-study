#!/usr/bin/env python3
"""Second, different reader: is every number in the memo traceable to a document (or to arithmetic on one)?

Not a phrase matcher — the opposite. It pulls every numeric token out of the memo (with its unit or context word),
then for each one asks: does this value appear in the extracted corpus text, or is it produced by an arithmetic
identity over corpus values (4160/20, 58+16, 74*2000/325851, 2.32+0.51+...)?  Anything else is reported.

  python3 audit_numbers.py
"""
import re
import sys
from pathlib import Path

import checks  # reuse the docx reader + normaliser

CORPUS = Path("/work/lsr/txt")
MEMO = checks.DEFAULT

# values that are arithmetic on corpus values, with the identity written out
DERIVED = {
    "208": "4160 lf / 20 lf per tree (both on sheet L-2 / comment L-4)",
    "224": "208 street + 6 entry monument + 10 park shade (L-1 plant schedule)",
    "448000": "224 trees x 2,000 gal/tree/yr (water budget rate table row 3)",
    "300000": "448,000 - 148,000 gallons (water budget HZ-3 vs revised)",
    "1.37": "448,000 gal / 325,851 gal per acre-foot",
    "1.38": "448,000 gal / 325,851 gal per acre-foot (rounded up)",
    "0.92": "300,000 gal / 325,851 gal per acre-foot",
    "0.45": "148,000 gal / 325,851 (water budget HZ-3)",
    "4.20": "2.32 + 0.51 + 1.37 acre-feet (water budget totals)",
    "4.2": "2.32 + 0.51 + 1.37 acre-feet (water budget totals)",
    "150": "208 - 58 trees",
}


def corpus_numbers():
    vals = set()
    for p in CORPUS.glob("*.txt"):
        if p.name in ("cond.txt",) or p.name.startswith("filesystem__"):
            continue
        t = checks.norm(p.read_text(errors="replace"))
        for m in re.finditer(r"\d[\d,]*\.?\d*", t):
            vals.add(m.group(0).replace(",", ""))
    return vals


MONTHS = {m: i for i, m in enumerate(
    "january february march april may june july august september october november december".split(), 1)}


def corpus_dates():
    """slash dates and 'Month D, YYYY' dates, normalised to MM/DD/YYYY."""
    out = set()
    for p in CORPUS.glob("*.txt"):
        if p.name.startswith("filesystem__"):
            continue
        t = checks.norm(p.read_text(errors="replace"))
        for a, b, c in re.findall(r"\b(\d{1,2})/(\d{1,2})/(\d{4})\b", t):
            out.add(f"{int(a):02d}/{int(b):02d}/{c}")
        for mon, d, y in re.findall(r"\b(" + "|".join(MONTHS) + r")\s+(\d{1,2}),?\s+(\d{4})\b", t, re.I):
            out.add(f"{MONTHS[mon.lower()]:02d}/{int(d):02d}/{y}")
    return out


# deadlines the memo proposes itself (not document values) — declared, so a reader can see them
OWN_RECOMMENDATIONS = {
    "11/04/2026": "Sundial's proposed date for sending the determination request (section 6, row 1)",
}


def main():
    text = checks.norm(checks.docx_text(MEMO))
    vals = corpus_numbers()
    print(f"corpus numbers: {len(vals)}; memo: {len(text)} chars\n")
    bad = []
    seen = []
    for m in re.finditer(r"(\$?)(\d[\d,]*(?:\.\d+)?)\s*(linear feet|lf|trees?|gallons?|acre-feet|"
                         r"days?|percent|%)?", text):
        raw, unit = m.group(2), m.group(3)
        v = raw.replace(",", "").rstrip(".")
        ctx = text[max(0, m.start() - 40):m.end() + 40].replace("\n", " ")
        kind = "unit" if unit else "bare"
        ok = (v in vals) or (v in DERIVED) or (v.rstrip("0").rstrip(".") in vals)
        # dates are checked separately, as dates
        if re.match(r"(0?\d|1[0-2])/\d{1,2}/\d{4}$", v):
            ok = v in vals or v.lstrip("0") in vals
        seen.append((v, unit or "", ok, ctx))
        if not ok and kind == "unit":
            bad.append((v, unit, ctx))
    n_unit = sum(1 for s in seen if s[1])
    print(f"numeric tokens: {len(seen)}, of them with a unit: {n_unit}")
    print(f"untraceable units: {len(bad)}")
    for v, u, ctx in bad:
        print(f"  !! {v} {u}  …{ctx}…")
    # dates present in the memo must appear in the corpus (or be declared as our own recommendation)
    dates = sorted(set(re.findall(r"\b\d{2}/\d{2}/\d{4}\b", text)))
    print(f"\ndates in memo: {len(dates)}")
    cdates = corpus_dates()
    miss = [d for d in dates if d not in cdates and d not in OWN_RECOMMENDATIONS]
    print(f"dates not in corpus: {miss or 'none'}")
    for d in dates:
        if d in OWN_RECOMMENDATIONS:
            print(f"  (own recommendation) {d}: {OWN_RECOMMENDATIONS[d]}")
    for d in dates:
        if d in cdates:
            print(f"  {d}: in corpus")
    # key derived values, recomputed here from the sheets' own numbers
    assert 4160 // 20 == 208
    assert (58 + 6 + 10) * 2000 == 148000
    assert (208 + 6 + 10) * 2000 - 148000 == 300000
    assert abs(300000 / 325851 - 0.921) < 0.002
    assert abs(2.32 + 0.51 + 448000 / 325851 - 4.20) < 0.01
    print("arithmetic identities hold")
    return 1 if (bad or miss) else 0


if __name__ == "__main__":
    sys.exit(main())
