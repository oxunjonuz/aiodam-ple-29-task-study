import json, sys
sys.path.insert(0, "/work/seis")
import opt
from structural_task6_seismic_diaphragm_shear.grading import analysis as A
from structural_task6_seismic_diaphragm_shear.grading import checks as CK
from structural_task6_seismic_diaphragm_shear.grading import cost as C

T = opt.T
d = json.load(open("/work/seis/best_design.json"))
print(json.dumps(d, indent=1))
r = opt.evaluate(d)
print("cost", round(r["cost"]), "ok", r["ok"])
ana = r["ana"]
caps = CK.design_capacities(T, d)
print("deck caps LRFD:", {k: round(v) for k, v in caps["deck"].items()})
print("\nper-zone envelope demand and per-ideal contributions")
zones = sorted(T["deck_zones"])
for z in zones:
    env = {sid: ana["scen"][sid]["zone_q_plf"][z] for sid in opt.SIDS}
    sid_max = max(env, key=env.get)
    ideal = {i: round(ana["scen"][sid_max]["per_ideal"][i]["zone_q_plf"][z]) for i in ("flexible", "rigid", "semirigid")}
    print(f"  {z:4s} pat={d['deck_zones'][z]:2s} area={C.zone_area(T,z):7.0f} "
          f"max={env[sid_max]:7.1f} @{sid_max} cap={caps['deck'][d['deck_zones'][z]]:6.0f} by={ideal}")
print("\nwall lines")
segs = A.build_segments(T, d["as_built_piers"])
segA = ana["segA"]
for lm, wd in d["wall_lines"].items():
    print(" ", lm, wd, "joints", C.n_joints(T, d["as_built_piers"])[lm],
          "panels", C.n_panels(T, d["as_built_piers"])[lm])
print("\nper-scenario line forces")
for sid in opt.SIDS:
    e = ana["scen"][sid]
    print(" ", sid, {k: round(v, 1) for k, v in e["line_force_kip"].items()},
          "delta_e", round(e["delta_e_in"], 4), "dia_defl", round(e["dia_defl_in"], 4),
          "ax", round(e["ax"], 3), "V", round(e["V_total_kip"], 1))
print("\nsegments: k_seg, max joint shear, panel M/N")
for sid, sa in segA.items():
    print(f"  {sid} {sa['line']} len={sa['length']:5.1f} k={sa['k_seg']:9.1f} "
          f"js={[round(x,4) for x in sa['joint_shear']]} M={[round(x,0) for x in sa['panel_M']]} "
          f"N={[round(x,2) for x in sa['panel_N']]} panels={sa['panel_len']}")
