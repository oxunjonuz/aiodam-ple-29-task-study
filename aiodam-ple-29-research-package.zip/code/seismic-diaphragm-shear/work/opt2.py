"""Second-pass optimizer: fixed-point sub-solves (deck, collectors, wall lines) + randomized restarts."""
import sys, json, copy, random, time

sys.path.insert(0, "/work/seis")
import opt
from structural_task6_seismic_diaphragm_shear.grading import analysis as A
from structural_task6_seismic_diaphragm_shear.grading import checks as CK
from structural_task6_seismic_diaphragm_shear.grading import cost as C

T = opt.T
SIDS = opt.SIDS


def deck_fixpoint(d, verbose=False):
    """Choose the cheapest pattern per zone against the envelope demand of the current design."""
    for it in range(6):
        r = opt.evaluate(d)
        if r["ana"] is None:
            return d
        ana, caps = r["ana"], CK.design_capacities(T, d)
        lf = caps["load_factor"]
        changed = False
        for z in T["deck_zones"]:
            dem = max(ana["scen"][s]["zone_q_plf"][z] for s in SIDS) * lf
            pick = None
            for p in sorted(T["deck_patterns"], key=lambda p: T["deck_patterns"][p]["cost_psf"]):
                if caps["deck"][p] + 1e-6 >= dem:
                    pick = p
                    break
            if pick is None:
                pick = max(T["deck_patterns"], key=lambda p: T["deck_patterns"][p]["cost_psf"])
            if pick != d["deck_zones"][z]:
                d["deck_zones"][z] = pick
                changed = True
        if not changed:
            break
    if not opt.evaluate(d)["ok"]:
        # a pattern that flipped the stiffness around: bump the failing zones one step up
        for it in range(4):
            r = opt.evaluate(d)
            bad = r["fail"].get("F1_DECK_SHEAR", [])
            if not bad:
                break
            ups = set()
            for msg in bad:
                z = msg.split(":")[1].strip().split()[0]
                ups.add(z)
            order = sorted(T["deck_patterns"], key=lambda p: T["deck_patterns"][p]["cost_psf"])
            for z in ups:
                if z in d["deck_zones"]:
                    i = order.index(d["deck_zones"][z])
                    d["deck_zones"][z] = order[min(i + 1, len(order) - 1)]
    return d


def coll_fixpoint(d):
    """Cheapest catalogue member per collector line that carries the enveloped bar force."""
    for it in range(4):
        r = opt.evaluate(d)
        if r["ana"] is None:
            return d
        ana, caps = r["ana"], CK.design_capacities(T, d)
        lf = caps["load_factor"]
        cat = T["sfrs_catalogue"][d["sfrs"]]
        o0 = cat["omega0"] - (T["omega0_flex_reduction"] if cat["omega0"] >= 2.5 else 0.0)
        changed = False
        for lid in T["collector_lines"]:
            dem = max(ana["scen"][s]["bar_axial_kip"].get(lid, 0.0) for s in SIDS) * lf
            if not (lid.startswith("CH-") or lid.startswith("OP-")):
                dem *= o0
            pick = None
            for c in sorted(T["collectors"], key=lambda c: T["collectors"][c]["cost_plf"]):
                if T["collectors"][c]["A_in2"] <= 0:
                    continue
                if caps["steel"][c] + 1e-6 >= dem:
                    pick = c
                    break
            if pick is None:
                pick = max(T["collectors"], key=lambda c: T["collectors"][c]["Pn_kip"])
            if pick != d["collector_lines"][lid]:
                d["collector_lines"][lid] = pick
                changed = True
        if not changed:
            break
    return d


JC_OPTS = [(j, n) for j, n, _ in opt.jc_options()]


def walls_solve(d, lines=None, verbose=False):
    """For each wall line: cheapest (joint connector, count, base anchor) that keeps the design feasible."""
    lines = lines or list(d["wall_lines"])
    for line in lines:
        cur_jc = (d["wall_lines"][line]["joint_connector"], d["wall_lines"][line]["connectors_per_joint"])
        cur_ba = d["wall_lines"][line]["base_anchor"]
        best = None
        for (j, n) in JC_OPTS:
            for ba in opt.ba_options():
                # cost of this combination
                trial = copy.deepcopy(d)
                trial["wall_lines"][line].update(joint_connector=j, connectors_per_joint=n, base_anchor=ba)
                nj = C.n_joints(T, d["as_built_piers"]).get(line, 0)
                npn = C.n_panels(T, d["as_built_piers"]).get(line, 0)
                c = nj * n * T["joint_connectors"][j]["cost_ea"] + npn * T["base_anchors"][ba]["cost_ea"]
                if best is not None and c >= best[0]:
                    continue
                if opt.evaluate(trial)["ok"]:
                    best = (c, j, n, ba)
                    break                          # ba options are cheapest-first
        if best is None:
            continue
        d["wall_lines"][line].update(joint_connector=best[1], connectors_per_joint=best[2],
                                     base_anchor=best[3])
        if verbose:
            print(f"   wall {line}: {best[1]}x{best[2]} {best[3]}  (line cost {best[0]:.0f})")
    return d


def wa_solve(d):
    for line in d["wall_lines"]:
        for (wa, sp, c) in opt.wa_options(line):
            d["wall_lines"][line]["wall_anchor"] = wa
            d["wall_lines"][line]["wall_anchor_spacing_ft"] = sp
            if opt.evaluate(d)["ok"]:
                break
    return d


def solve(d, rounds=3, verbose=True):
    d = copy.deepcopy(d)
    for k in range(rounds):
        d = wa_solve(d)
        d = walls_solve(d, verbose=verbose)
        d = deck_fixpoint(d)
        d = coll_fixpoint(d)
        r = opt.evaluate(d)
        if verbose:
            print(f" round {k}: cost {r['cost']:.0f} ok {r['ok']}", flush=True)
        if not r["ok"]:
            for f, v in r["fail"].items():
                print("   FAIL", f, v[:3])
            break
    return d


if __name__ == "__main__":
    best = json.load(open("/work/seis/best_design.json"))
    seeds = [best]
    # a few random seeds around the greedy solution
    rnd = random.Random(7)
    for i in range(3):
        s = copy.deepcopy(best)
        for z in T["deck_zones"]:
            s["deck_zones"][z] = rnd.choice(["P2", "P3", "P4", "P5"])
        for l in T["collector_lines"]:
            s["collector_lines"][l] = rnd.choice(["C1", "C2", "C3"])
        for line in T["wall_lines"]:
            j, n = rnd.choice(JC_OPTS)
            s["wall_lines"][line].update(joint_connector=j, connectors_per_joint=n,
                                         base_anchor=rnd.choice(["BA1", "BA2", "BA3"]))
        seeds.append(s)
    out = []
    t0 = time.time()
    for i, s in enumerate(seeds):
        r0 = opt.evaluate(s)
        if not r0["ok"]:
            print(f"seed {i}: infeasible at {r0['cost']:.0f}, skipping")
            continue
        print(f"seed {i}: start {r0['cost']:.0f}")
        d = solve(s, verbose=True)
        r = opt.evaluate(d)
        out.append((r["cost"], d, r["ok"]))
        print(f"seed {i}: final {r['cost']:.0f} ok={r['ok']}")
    out.sort(key=lambda q: q[0])
    for c, d, ok in out:
        print(f"  {c:.0f} ok={ok}")
    if out:
        json.dump(out[0][1], open("/work/seis/best_design2.json", "w"), indent=1)
        print("wrote best_design2.json", out[0][0])
    print("seconds", round(time.time() - t0))
