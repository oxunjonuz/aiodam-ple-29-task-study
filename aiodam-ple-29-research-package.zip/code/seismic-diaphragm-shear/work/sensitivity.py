"""Design-sensitivity campaign: take the submitted package, break ONE thing at a time, and check
that the frozen grader notices.

A family that no single-variable break can turn red is a family that is not really being checked
for this design.  Each mutation rebuilds the zip with only design_record.json (or the register, or
the cost line) changed, runs the task's own grader, and records which families stop being
engineered.
"""
import json, os, subprocess, sys, zipfile, copy, shutil

SOL = "/work/ple-solve/seismic-diaphragm-shear"
OUT = f"{SOL}/out"
ZIP = f"{SOL}/submission.zip"
GRADER = ("/work/ple-dataset/tasks/seismic-diaphragm-shear/tests/corrino/"
          "structural_task6_seismic_diaphragm_shear/grading/verification/run_grade.py")
PY = "/work/venv-verifier/bin/python"
TMP = "/tmp/seis_mut"

BASE = json.load(open(f"{OUT}/design_record.json"))
FILES = ["design_record.json", "diaphragm_plan.dxf", "seismic_calculations.xlsx",
         "constraint_register.xlsx", "design_basis.md"]


def build_zip(rec, path, drop_register_row=None):
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        for f in FILES:
            if f == "design_record.json":
                z.writestr(f, json.dumps(rec, indent=1))
            elif f == "constraint_register.xlsx" and drop_register_row is not None:
                from openpyxl import load_workbook, Workbook
                wb = load_workbook(f"{OUT}/{f}")
                ws = wb.active
                ws.delete_rows(drop_register_row, 1)
                import io
                buf = io.BytesIO()
                wb.save(buf)
                z.writestr(f, buf.getvalue())
            else:
                z.write(f"{OUT}/{f}", arcname=f)


def grade(path):
    out = "/tmp/seis_mut_metrics.json"
    if os.path.exists(out):
        os.remove(out)
    subprocess.run([PY, "-B", GRADER, path, "--metrics-out", out],
                   cwd=os.path.dirname(os.path.dirname(GRADER)), capture_output=True, timeout=1200)
    m = json.load(open(out))
    bad = set()
    for sid, fams in (m.get("unengineered") or {}).items():
        bad |= set(fams)
    return m, bad


def mut(rec, fn):
    r = copy.deepcopy(rec)
    fn(r)
    return r


MUTS = []
def add(name, fn=None, register_row=None):
    MUTS.append((name, fn, register_row))

add("Z1 deck P5 -> P4", lambda r: r["deck_zones"].__setitem__("Z1", "P4"))
add("Z6 deck P2 -> P1", lambda r: r["deck_zones"].__setitem__("Z6", "P1"))
add("chord CH-S -> C0 (no chord)", lambda r: r["collector_lines"].__setitem__("CH-S", "C0"))
add("drag strut DR-S1 -> C0", lambda r: r["collector_lines"].__setitem__("DR-S1", "C0"))
add("opening frame OP-1S -> C0", lambda r: r["collector_lines"].__setitem__("OP-1S", "C0"))
add("S base tie-down BA2 -> BA1", lambda r: r["wall_lines"]["S"].__setitem__("base_anchor", "BA1"))
add("wall anchor spacing 8 -> 10 ft", lambda r: [w.__setitem__("wall_anchor_spacing_ft", 10.0)
                                                 for w in r["wall_lines"].values()])
add("subdiaphragm L/b 2.5 -> 4.0", lambda r: r["wall_lines"]["S"].__setitem__("subdiaphragm_depth_ft", 60.0))
add("Omega_0 collector 2.0 -> 2.5", lambda r: r["seismic_basis"].__setitem__("omega0_collector", 2.5))
add("R 4 -> 5 (special system coefficients)", lambda r: r["seismic_basis"].__setitem__("R", 5.0))
add("sfrs -> ordinary_precast", lambda r: r.__setitem__("sfrs", "ordinary_precast"))
add("Ie 1.25 -> 1.0", lambda r: r["seismic_basis"].__setitem__("ie", 1.0))
add("site class D -> C", lambda r: r["seismic_basis"].__setitem__("site_class", "C"))
add("wall trib height 17.16 -> 17.0 ft", lambda r: r["seismic_basis"].__setitem__("wall_trib_height_ft", 17.0))
add("erection brace 12 -> 8 kip", lambda r: r["erection_bracing"].__setitem__("brace_capacity_kip", 8.0))
add("W piers -> record set 106/74", lambda r: r["as_built_piers"].__setitem__("W", [
    {"id": "WP01", "start": 0.0, "length": 12.0, "kind": "pier"},
    {"id": "WP02", "start": 16.0, "length": 50.0, "kind": "pier"},
    {"id": "WP03", "start": 106.0, "length": 74.0, "kind": "pier"}]))
add("D-3 opening 15.5 -> 14.0", lambda r: r["conflicts_resolved"]["opening_D3_width_ft"].__setitem__("resolved_value", 14.0))
add("governing S -> F4_WALL_PIER", lambda r: r["reported"]["governing_family"].__setitem__("S", "F4_WALL_PIER"))
add("installed cost 301358 -> 250000", lambda r: r["reported"].__setitem__("installed_cost_usd", 250000))
add("design format LRFD -> blank", lambda r: r.__setitem__("design_format", ""))
add("drop register row 34 (capital cap)", None, 34)

if __name__ == "__main__":
    os.makedirs(TMP, exist_ok=True)
    m0, bad0 = grade(ZIP)
    print(f"baseline: score {m0['combined_score']:.4f}  unengineered {sorted(bad0)}")
    rows = []
    for name, fn, reg in MUTS:
        p = f"{TMP}/m.zip"
        if fn is not None:
            build_zip(mut(BASE, fn), p)
        else:
            build_zip(BASE, p, drop_register_row=reg)
        try:
            m, bad = grade(p)
            sc = m.get("combined_score", 0.0)
            print(f"{name:44s} score {sc:.4f}  red: {', '.join(sorted(bad)) or '(none!)'}")
            rows.append((name, sc, sorted(bad)))
        except Exception as exc:              # noqa: BLE001
            print(f"{name:44s} GRADER ERROR {exc}")
            rows.append((name, None, [str(exc)]))
    survivors = [r for r in rows if r[1] is not None and r[1] >= m0["combined_score"] - 1e-9]
    print("\nmutations the grader did NOT punish:", [s[0] for s in survivors] or "none")
    json.dump({"baseline": m0["combined_score"], "rows": rows}, open(f"{SOL}/work/sensitivity.json", "w"), indent=1)
