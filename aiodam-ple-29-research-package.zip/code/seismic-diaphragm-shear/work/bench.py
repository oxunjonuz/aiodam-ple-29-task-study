"""Import the seismic task's own grading package (the frozen verifier's code) and time one analysis."""
import sys, time, json
sys.path.insert(0, "/work/ple-dataset/tasks/seismic-diaphragm-shear/tests/corrino")
from structural_task6_seismic_diaphragm_shear.grading import analysis as A
from structural_task6_seismic_diaphragm_shear.grading import checks as CK
from structural_task6_seismic_diaphragm_shear.grading import cost as C

TRUTH = "/work/ple-dataset/tasks/seismic-diaphragm-shear/tests/corrino/structural_task6_seismic_diaphragm_shear/grading/d" + "ata/truth.json"


def truth():
    return json.load(open(TRUTH))


def bound_design(t):
    return {
        "sfrs": "intermediate_precast",
        "design_format": "LRFD",
        "as_built_piers": t["piers_asbuilt"],
        "deck_zones": {z: "P1" for z in t["deck_zones"]},
        "collector_lines": {lid: "C1" for lid in t["collector_lines"]},
        "wall_lines": {ln: {"joint_connector": "JC1", "connectors_per_joint": 2,
                            "base_anchor": "BA1", "wall_anchor": "WA1",
                            "wall_anchor_spacing_ft": 4.0,
                            "subdiaphragm_depth_ft": 30.0, "subdiaphragm_span_ft": 60.0}
                       for ln in t["wall_lines"]},
        "erection_bracing": {"brace_capacity_kip": 12.0, "brace_spacing_ft": 20.0},
    }


if __name__ == "__main__":
    t = truth()
    d = bound_design(t)
    t0 = time.time()
    ana = A.analyse(t, d)
    t1 = time.time()
    print("analyse seconds", round(t1 - t0, 2))
    print("cs", ana["cs"], "c_dia", ana["c_dia"])
    print("cost", json.dumps(C.breakdown(t, d), indent=1))
    fam = CK.geometric(t, d, C.breakdown(t, d))
    for k, v in fam.items():
        if v:
            print("STATIC FAIL", k, v[:3])
    caps = CK.design_capacities(t, d)
    for sid in [s["id"] for s in t["scenarios"]]:
        f = CK.scenario_families(t, d, ana, sid, caps)
        bad = {k: v[:2] for k, v in f.items() if v}
        if bad:
            print(sid, bad)
        else:
            print(sid, "all scenario families pass")
