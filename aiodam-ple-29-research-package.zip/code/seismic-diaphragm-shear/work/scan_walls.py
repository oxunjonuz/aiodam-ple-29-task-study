"""Precise as-built measurement of every wall opening from the registered scan.

For every wall line, walk the along-wall coordinate in 0.25 ft steps and record, for the points that
lie on the wall plane, the occupied height band.  A solid panel reaches z ~ 31 ft; an opening is a
stretch where the wall-plane points stop well below that (you see the yard/floor through it).
"""
import numpy as np, json

G = np.load("/work/seis/scan_grid.npy")

WALLS = {"W": (0, 0.0, 1, 0.0, 180.0), "E": (0, 240.0, 1, 0.0, 180.0),
         "S": (1, 0.0, 0, 0.0, 240.0), "N": (1, 180.0, 0, 0.0, 240.0)}
res = {}
for name, (idx, pc, jdx, lo, hi) in WALLS.items():
    near = (np.abs(G[:, idx] - pc) < 0.6) & (G[:, 2] > 0.5)
    v = G[near, jdx]
    z = G[near, 2]
    step = 0.25
    edges = np.arange(lo, hi + step, step)
    zmax = np.zeros(len(edges) - 1)
    ztop = np.zeros(len(edges) - 1)
    cnt = np.zeros(len(edges) - 1)
    for k in range(len(edges) - 1):
        sel = (v >= edges[k]) & (v < edges[k + 1])
        cnt[k] = sel.sum()
        if sel.any():
            zmax[k] = z[sel].max()
            ztop[k] = np.percentile(z[sel], 99.5)
    # solid where the 99.5th percentile height is near the parapet
    solid = ztop > 29.0
    segs, start = [], None
    for k in range(len(solid)):
        if solid[k] and start is None:
            start = edges[k]
        if not solid[k] and start is not None:
            segs.append((round(start, 2), round(edges[k], 2)))
            start = None
    if start is not None:
        segs.append((round(start, 2), round(edges[-1], 2)))
    segs = [s for s in segs if s[1] - s[0] > 1.5]
    # openings = the complementary stretches that carry points but do not reach the parapet
    opens, prev = [], lo
    for a, b in segs:
        if a - prev > 1.5:
            sel = (v >= prev) & (v < a)
            opens.append({"from": round(prev, 2), "to": round(a, 2), "width": round(a - prev, 2),
                          "top_ft": round(float(np.percentile(z[sel], 99.5)), 2) if sel.any() else None})
        prev = b
    if hi - prev > 1.5:
        sel = (v >= prev) & (v <= hi)
        opens.append({"from": round(prev, 2), "to": round(hi, 2), "width": round(hi - prev, 2),
                      "top_ft": round(float(np.percentile(z[sel], 99.5)), 2) if sel.any() else None})
    res[name] = {"solid_runs": segs, "openings": opens}
    print(f"\n{name}: solid runs")
    for a, b in segs:
        print(f"    {a:7.2f} .. {b:7.2f}   {b - a:6.2f} ft")
    print(f"{name}: openings")
    for o in opens:
        print(f"    {o['from']:7.2f} .. {o['to']:7.2f}   width {o['width']:6.2f}  top ~{o['top_ft']} ft")
json.dump(res, open("/work/seis/scan_walls.json", "w"), indent=1)
