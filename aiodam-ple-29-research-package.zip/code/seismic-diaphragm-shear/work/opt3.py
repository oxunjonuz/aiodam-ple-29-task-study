"""Third pass: pairwise wall-line search (S/N and E/W interact) + simulated annealing on the deck."""
import sys, json, copy, random, time

sys.path.insert(0, "/work/seis")
import opt, opt2
from structural_task6_seismic_diaphragm_shear.grading import cost as C
from structural_task6_seismic_diaphragm_shear.grading import checks as CK

T = opt.T
SIDS = opt.SIDS
PATS = sorted(T["deck_patterns"], key=lambda p: T["deck_patterns"][p]["cost_psf"])


def wl_cost(d, line):
    wd = d["wall_lines"][line]
    nj = C.n_joints(T, d["as_built_piers"]).get(line, 0)
    npn = C.n_panels(T, d["as_built_piers"]).get(line, 0)
    return (nj * wd["connectors_per_joint"] * T["joint_connectors"][wd["joint_connector"]]["cost_ea"]
            + npn * T["base_anchors"][wd["base_anchor"]]["cost_ea"])


def pair_search(d, a, b, verbose=True):
    """Exhaustive over (jc,n,ba) of two lines that share a load direction."""
    opts = []
    for (j, n) in opt2.JC_OPTS:
        for ba in opt.ba_options():
            opts.append((j, n, ba))
    best = None
    for oa in opts:
        for ob in opts:
            trial = copy.deepcopy(d)
            trial["wall_lines"][a].update(joint_connector=oa[0], connectors_per_joint=oa[1], base_anchor=oa[2])
            trial["wall_lines"][b].update(joint_connector=ob[0], connectors_per_joint=ob[1], base_anchor=ob[2])
            c = wl_cost(trial, a) + wl_cost(trial, b)
            if best is not None and c >= best[0] - 1e-9:
                continue
            if opt.evaluate(trial)["ok"]:
                best = (c, oa, ob)
                break
    if best is not None:
        d["wall_lines"][a].update(joint_connector=best[1][0], connectors_per_joint=best[1][1], base_anchor=best[1][2])
        d["wall_lines"][b].update(joint_connector=best[2][0], connectors_per_joint=best[2][1], base_anchor=best[2][2])
        if verbose:
            print(f"  pair {a}/{b}: {best[1]} + {best[2]} line cost {best[0]:.0f}", flush=True)
    return d


def deck_sa(d, iters=1200, seed=1, verbose=True):
    rnd = random.Random(seed)
    cur = copy.deepcopy(d)
    rc = opt.evaluate(cur, full=True)
    best = (rc["cost"], copy.deepcopy(cur), rc["ok"])
    T0, alpha = 6000.0, 0.995
    temp = T0
    zones = sorted(T["deck_zones"])
    for it in range(iters):
        z = rnd.choice(zones)
        i = PATS.index(cur["deck_zones"][z])
        ni = max(0, min(len(PATS) - 1, i + rnd.choice([-1, -1, 1, 1, -2, 2])))
        if ni == i:
            continue
        trial = copy.deepcopy(cur)
        trial["deck_zones"][z] = PATS[ni]
        r = opt.evaluate(trial, full=True)
        # feasibility first, then cost
        pen_c = 0.0 if rc["ok"] else 4e5
        pen_t = 0.0 if r["ok"] else 4e5
        delta = (r["cost"] + pen_t) - (rc["cost"] + pen_c)
        if delta <= 0 or rnd.random() < pow(2.718281828, -delta / max(temp, 1e-6)):
            cur, rc = trial, r
            if r["ok"] and r["cost"] < best[0]:
                best = (r["cost"], copy.deepcopy(trial), True)
        temp *= alpha
        if verbose and it % 300 == 0:
            print(f"   sa {it}: cur {rc['cost']:.0f} ok={rc['ok']} best {best[0]:.0f} T={temp:.0f}", flush=True)
    if verbose:
        print(f"  deck SA: {d['deck_zones']} -> {best[1]['deck_zones']}", flush=True)
    return best[1]


if __name__ == "__main__":
    d = json.load(open("/work/seis/best_design.json"))
    t0 = time.time()
    print("start", opt.evaluate(d)["cost"], flush=True)
    for rnd in range(2):
        d = pair_search(d, "S", "N")
        d = pair_search(d, "W", "E")
        print(f" after pairs: {opt.evaluate(d)['cost']:.0f}", flush=True)
        d = opt2.deck_fixpoint(d)
        d = deck_sa(d, seed=rnd + 1)
        d = opt2.coll_fixpoint(d)
        d = opt2.wa_solve(d)
        r = opt.evaluate(d)
        print(f"round {rnd}: {r['cost']:.0f} ok={r['ok']}", flush=True)
        if not r["ok"]:
            for f, v in r["fail"].items():
                print("   FAIL", f, v[:3])
            break
    r = opt.evaluate(d)
    print("final", r["cost"], r["ok"])
    print(json.dumps(r["costs"], indent=1))
    json.dump(d, open("/work/seis/best_design3.json", "w"), indent=1)
    print("seconds", round(time.time() - t0))
