"""As-built pier schedule MEASURED from the 7 August 2026 interior scan (scan_walls.py) plus the
erection log: the point cloud settles every opening within about 0.25 ft.

E and S and N agree with ERL-2026-08 to the quarter foot.  On the west wall the scan shows the
electrical-yard opening EY-1 running 66.0..110.0 ft (44.0 ft, as ERL and RFI-041 both record), so
the west pier is 110.0..180.0 = 70.0 ft.  The record set (PC-101) has 40 ft there -> 106..180.
"""
MEASURED = {
    "S": [{"id": "SP01", "start": 0.0, "length": 18.0, "kind": "pier"},
          {"id": "SP02", "start": 32.0, "length": 16.0, "kind": "pier"},
          {"id": "SP03", "start": 62.0, "length": 16.0, "kind": "pier"},
          {"id": "SP04", "start": 93.5, "length": 16.0, "kind": "pier"},
          {"id": "SP05", "start": 123.5, "length": 14.5, "kind": "pier"},
          {"id": "SP06", "start": 152.0, "length": 44.0, "kind": "pier"},
          {"id": "SP07", "start": 200.0, "length": 40.0, "kind": "pier"}],
    "N": [{"id": "NP01", "start": 0.0, "length": 24.0, "kind": "pier"},
          {"id": "NP02", "start": 28.0, "length": 32.0, "kind": "pier"},
          {"id": "NP03", "start": 60.0, "length": 12.0, "kind": "spandrel"},
          {"id": "NP04", "start": 72.0, "length": 82.0, "kind": "pier"},
          {"id": "NP05", "start": 154.0, "length": 16.0, "kind": "spandrel"},
          {"id": "NP06", "start": 170.0, "length": 70.0, "kind": "pier"}],
    "W": [{"id": "WP01", "start": 0.0, "length": 12.0, "kind": "pier"},
          {"id": "WP02", "start": 16.0, "length": 50.0, "kind": "pier"},
          {"id": "WP03", "start": 110.0, "length": 70.0, "kind": "pier"}],
    "E": [{"id": "EP01", "start": 0.0, "length": 72.0, "kind": "pier"},
          {"id": "EP02", "start": 86.0, "length": 22.0, "kind": "pier"},
          {"id": "EP03", "start": 108.0, "length": 12.0, "kind": "spandrel"},
          {"id": "EP04", "start": 120.0, "length": 30.0, "kind": "pier"},
          {"id": "EP05", "start": 154.0, "length": 26.0, "kind": "pier"}],
}

OPENINGS = {   # from the same measurement (and ERL-2026-08), the as-built openings
    "S": [("D-1", 18.0, 14.0, 0.0, 16.0), ("D-2", 48.0, 14.0, 0.0, 16.0),
          ("D-3", 78.0, 15.5, 0.0, 16.0), ("D-4", 109.5, 14.0, 0.0, 16.0),
          ("D-5", 138.0, 14.0, 0.0, 16.0), ("P-1", 196.0, 4.0, 0.0, 8.0)],
    "N": [("P-2", 24.0, 4.0, 0.0, 8.0), ("L-1", 60.0, 12.0, 14.0, 24.0),
          ("L-2", 154.0, 16.0, 14.0, 24.0)],
    "W": [("P-3", 12.0, 4.0, 0.0, 8.0), ("EY-1", 66.0, 44.0, 0.0, 20.0)],
    "E": [("D-6", 72.0, 14.0, 0.0, 16.0), ("L-3", 108.0, 12.0, 14.0, 24.0),
          ("P-4", 150.0, 4.0, 0.0, 8.0)],
}
