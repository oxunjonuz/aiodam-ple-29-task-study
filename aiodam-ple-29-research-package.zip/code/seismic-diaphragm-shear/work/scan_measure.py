"""Register the as-built interior scan into the building grid and MEASURE the wall piers.

The survey report gives four 6 in spherical control targets, coordinated in the building grid
(CP_control_points.csv).  They are the only objects with intensity > 240.  Fit the rigid
transformation scanner -> grid on those four centres, then histogram the points that lie on each
wall plane to find the openings (and so the as-built piers), instead of copying them from a table.
"""
import numpy as np, json, struct, sys

PLY = ("/work/ple-solve/seismic-diaphragm-shear/ws/"
       "final_batch4__structural_task6_seismic_diaphragm_shear__blind/project/40_scan/"
       "ScanB_2026-08-07_interior.ply")


def read_ply(path):
    with open(path, "rb") as f:
        data = f.read()
    end = data.index(b"end_header\n") + len(b"end_header\n")
    hdr = data[:end].decode("ascii", "ignore")
    n = int([l for l in hdr.splitlines() if l.startswith("element vertex")][0].split()[-1])
    arr = np.frombuffer(data[end:end + n * 16], dtype="<f4").reshape(n, 4)
    return arr[:, :3].astype(np.float64), arr[:, 3].astype(np.float64), hdr


def fit_rigid(src, dst):
    """Least-squares rigid transform (rotation + translation) src -> dst (Kabsch, 2D on xy + z offset)."""
    cs, cd = src.mean(0), dst.mean(0)
    s, d = src - cs, dst - cd
    H = s.T @ d
    U, S, Vt = np.linalg.svd(H)
    R = Vt.T @ U.T
    if np.linalg.det(R) < 0:
        Vt[-1] *= -1
        R = Vt.T @ U.T
    t = cd - R @ cs
    return R, t


def main():
    P, I, hdr = read_ply(PLY)
    print("points", len(P))
    print(hdr.strip())
    hi = I > 240
    print("bright points", int(hi.sum()))
    src = P[hi]
    # cluster the bright points into 4 groups (spheres ~6 in across, well separated)
    from scipy.cluster.vq import kmeans2
    cent, lab = kmeans2(src, 4, minit="++", seed=3)
    print("scanner-frame cluster centres:")
    for c in cent:
        print("   ", np.round(c, 3), "n=", int((lab == np.argmin(((cent - c) ** 2).sum(1))).sum()))

    grid = np.array([[6.50, 4.25, 5.40], [233.75, 5.10, 5.55],
                     [234.60, 174.20, 5.35], [7.20, 175.40, 5.60]])
    # correspond by relative geometry: sort the four centres by distance from the mean and pair
    # with the grid set sorted the same way (both sets form the same quadrilateral, in some order)
    import itertools
    best = None
    for perm in itertools.permutations(range(4)):
        R, t = fit_rigid(cent[list(perm)], grid)
        pred = (R @ cent[list(perm)].T).T + t
        err = np.abs(pred - grid).max()
        if best is None or err < best[0]:
            best = (err, perm, R, t)
    err, perm, R, t = best
    print(f"best permutation {perm} max control error {err:.4f} ft")
    print("R =\n", np.round(R, 6), "\nt =", np.round(t, 4))

    G = (R @ P.T).T + t
    np.save("/work/seis/scan_grid.npy", G)
    print("registered cloud: x", np.round([G[:, 0].min(), G[:, 0].max()], 2),
          "y", np.round([G[:, 1].min(), G[:, 1].max()], 2),
          "z", np.round([G[:, 2].min(), G[:, 2].max()], 2))

    # ---------------- wall lines: histogram occupancy along each wall ----------------
    def occupancy(mask, coord, lo, hi, step=0.25):
        vals = coord[mask]
        bins = np.arange(lo, hi + 1e-9, step)
        h, _ = np.histogram(vals, bins=bins)
        return bins, h

    walls = {"W": ("x", 0.0, "y", 0.0, 180.0), "E": ("x", 240.0, "y", 0.0, 180.0),
             "S": ("y", 0.0, "x", 0.0, 240.0), "N": ("y", 180.0, "x", 0.0, 240.0)}
    out = {}
    for name, (perp, pcoord, along, lo, hi) in walls.items():
        idx = 0 if perp == "x" else 1
        jdx = 1 - idx
        near = np.abs(G[:, idx] - pcoord) < 0.75
        # keep the wall band: points whose height is within the panel (0..31 ft)
        band = near & (G[:, 2] > 1.0) & (G[:, 2] < 31.5)
        bins, h = occupancy(band, G[:, jdx], lo, hi, 0.25)
        # a bin is "solid" if it holds a reasonable number of points
        solid = h > max(6, 0.15 * np.median(h[h > 0]) if np.any(h > 0) else 6)
        # find gaps (runs of non-solid bins) inside the wall extent
        segs, start = [], None
        for k in range(len(solid)):
            if solid[k] and start is None:
                start = bins[k]
            if not solid[k] and start is not None:
                segs.append((start, bins[k]))
                start = None
        if start is not None:
            segs.append((start, bins[-1] + 0.25))
        segs = [s for s in segs if s[1] - s[0] > 1.0]
        out[name] = segs
        print(f"\n{name} wall (at {perp}={pcoord}): solid runs (ft)")
        for s in segs:
            print(f"    {s[0]:7.2f} .. {s[1]:7.2f}   length {s[1]-s[0]:6.2f}")
    json.dump(out, open("/work/seis/scan_piers.json", "w"), indent=1)


if __name__ == "__main__":
    main()
