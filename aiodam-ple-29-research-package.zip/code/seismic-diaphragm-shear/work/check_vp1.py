"""DAP-2 Rev 1 Appendix A, verification example VP-1, run against the Stage A implementation.

Case: a single wall segment 40.0 ft long on a wall line with no openings in it, four 10.0 ft panels,
8 in solid normal-weight precast, cantilever height 28.0 ft to the diaphragm, f'c = 6,000 psi,
cracked I = 0.50 Ig, joints connected by three RPC-40 connectors each (joint spring 3 x 320 kip/in).

Published: k_seg 1,279.4 kip/in; joint 1 shear 0.2630 kip/kip; joint 2 0.2527 kip/kip;
panel 1 base moment 88.91 kip-in/kip; panel 1 axial 0.2630 kip/kip; with no joint connectors
k_seg = 769.2 kip/in.
"""
import json, sys
sys.path.insert(0, "/work/ple-dataset/tasks/seismic-diaphragm-shear/tests/corrino")
import opt  # noqa: F401  (sets up the import path identically to the other scripts)
from structural_task6_seismic_diaphragm_shear.grading import analysis as A
from structural_task6_seismic_diaphragm_shear.grading.femodel import PanelSeg, panel_edges

T = opt.T
seg = PanelSeg(seg_id="VP1", line="S", start=0.0, length=40.0, kind="pier",
               panel_edges=panel_edges(0.0, 40.0, 10.0))


def run(jc, n):
    wd = {"S": {"joint_connector": jc, "connectors_per_joint": n}}
    out = A.stage_a(T, {seg.seg_id: seg}, wd)
    return out["VP1"]


a = run("JC2", 3)
b = run("JC0", 0)
print("with 3 x RPC-40 per joint")
print("  k_seg      %10.2f  (published 1279.4)" % a["k_seg"])
print("  joint 1    %10.4f  (published 0.2630)" % a["joint_shear"][0])
print("  joint 2    %10.4f  (published 0.2527)" % a["joint_shear"][1])
print("  panel 1 M  %10.2f  (published 88.91)" % a["panel_M"][0])
print("  panel 1 N  %10.4f  (published 0.2630)" % a["panel_N"][0])
print("with no joint connectors (isolated panel piers)")
print("  k_seg      %10.2f  (published 769.2)" % b["k_seg"])

checks = [("k_seg", a["k_seg"], 1279.4, 0.001), ("joint1", a["joint_shear"][0], 0.2630, 0.005),
          ("joint2", a["joint_shear"][1], 0.2527, 0.005), ("panelM", a["panel_M"][0], 88.91, 0.005),
          ("panelN", a["panel_N"][0], 0.2630, 0.01), ("k0", b["k_seg"], 769.2, 0.001)]
bad = [(n, g, w) for (n, g, w, tol) in checks if abs(g - w) > tol * abs(w)]
print("RESULT:", "all six published values reproduced" if not bad else f"MISMATCH {bad}")
sys.exit(1 if bad else 0)
