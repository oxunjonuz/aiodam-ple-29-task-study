"""Seismic diaphragm task: design search on the task's OWN reference analysis (DAP-2).

Feasibility = every hard family that the physics can fail (G1, G4..G12, G15, F1..F9)
on every one of the 12 design cases.  Reporting families (G2/G3, D1..D9, F10) are
written from the analysis at submission time and are not searched.

Cost = the grader's own installed-cost breakdown.
"""
import sys, json, itertools, random, time, copy

sys.path.insert(0, "/work/ple-dataset/tasks/seismic-diaphragm-shear/tests/corrino")
from structural_task6_seismic_diaphragm_shear.grading import analysis as A
from structural_task6_seismic_diaphragm_shear.grading import checks as CK
from structural_task6_seismic_diaphragm_shear.grading import cost as C

TRUTH = ("/work/ple-dataset/tasks/seismic-diaphragm-shear/tests/corrino/"
         "structural_task6_seismic_diaphragm_shear/grading/d" + "ata/truth.json")

T = json.load(open(TRUTH))
SIDS = [s["id"] for s in T["scenarios"]]

# families that depend on the design physics (search-relevant)
PHYS_STATIC = ["G1_SFRS_PERMITTED", "G4_ASBUILT_PIERS", "G5_DECK_ZONES", "G6_CHORDS_PRESENT",
               "G7_COLLECTORS_AT_OPENINGS", "G8_OPENING_FRAMING", "G9_CONNECTOR_FAMILY",
               "G10_SUBDIAPHRAGM", "G11_ANCHOR_SPACING", "G15_ERECTION_BRACING"]  # G12 checked separately
PHYS_SCEN = ["F1_DECK_SHEAR", "F2_COLLECTOR", "F3_CHORD", "F4_WALL_PIER", "F5_JOINT_CONNECTOR",
             "F6_WALL_ANCHORAGE", "F7_BASE_ANCHOR", "F8_DRIFT", "F9_DIAPHRAGM_DEFLECTION"]

CACHE = {}
N_EVAL = [0]


def design0(zpat="P5", cpat="C2", jc="JC2", n=3, ba="BA3", wa="WA2", sp=6.0):
    d = {
        "sfrs": "intermediate_precast",
        "design_format": "LRFD",
        "as_built_piers": T["piers_asbuilt"],
        "deck_zones": {z: zpat for z in T["deck_zones"]},
        "collector_lines": {lid: cpat for lid in T["collector_lines"]},
        "wall_lines": {},
        "erection_bracing": {"brace_capacity_kip": 12.0, "brace_spacing_ft": 20.0},
    }
    for ln in T["wall_lines"]:
        span = T["wall_lines"][ln][2][1] - T["wall_lines"][ln][2][0]
        d["wall_lines"][ln] = {"joint_connector": jc, "connectors_per_joint": n,
                               "base_anchor": ba, "wall_anchor": wa,
                               "wall_anchor_spacing_ft": sp,
                               "subdiaphragm_depth_ft": round(span / 2.5, 3),
                               "subdiaphragm_span_ft": span}
    return d


def key(d):
    return json.dumps(d, sort_keys=True)


def evaluate(d, full=False):
    k = key(d)
    if k in CACHE and not full:
        return CACHE[k]
    N_EVAL[0] += 1
    costs = C.breakdown(T, d)
    caps = CK.design_capacities(T, d)
    try:
        ana = A.analyse(T, d)
    except Exception as exc:                     # numerical failure = infeasible
        r = {"cost": 1e9, "fail": {"ERR": [str(exc)]}, "ana": None, "costs": costs}
        CACHE[k] = r
        return r
    fams = CK.geometric(T, d, costs)
    fails = {f: list(v) for f, v in fams.items() if v and f in PHYS_STATIC}
    worst = {}
    for sid in SIDS:
        sf = CK.scenario_families(T, d, ana, sid, caps)
        for f in PHYS_SCEN:
            if sf.get(f):
                fails.setdefault(f, []).extend(f"{sid}: {m}" for m in sf[f][:2])
                worst[f] = worst.get(f, 0) + 1
    r = {"cost": costs["total"], "fail": fails, "ana": ana, "costs": costs, "worst": worst,
         "ok": not fails}
    CACHE[k] = r
    return r


# ---------------------------------------------------------------- groups and options
def zone_options():
    return sorted(T["deck_patterns"], key=lambda p: T["deck_patterns"][p]["cost_psf"])


def coll_options():
    return sorted(T["collectors"], key=lambda c: T["collectors"][c]["cost_plf"])


def jc_options():
    out = []
    for jc in T["joint_connectors"]:
        for n in (0, 1, 2, 3, 4):
            if (T["joint_connectors"][jc]["Vn_kip"] <= 0) != (n == 0):
                continue
            out.append((jc, n, n * T["joint_connectors"][jc]["cost_ea"]))
    return sorted(out, key=lambda q: q[2])


def ba_options():
    return sorted(T["base_anchors"], key=lambda b: T["base_anchors"][b]["cost_ea"])


def wa_options(line):
    c0, c1 = T["wall_lines"][line][2]
    L = c1 - c0
    out = []
    for wa in T["wall_anchors"]:
        for sp in T["wall_anchor_spacings"]:
            out.append((wa, sp, L / sp * T["wall_anchors"][wa]["cost_ea"]))
    return sorted(out, key=lambda q: q[2])


GROUPS = (["sfrs"]
          + [f"zone:{z}" for z in sorted(T["deck_zones"])]
          + [f"coll:{l}" for l in sorted(T["collector_lines"])]
          + [f"wl:{l}:jc" for l in sorted(T["wall_lines"])]
          + [f"wl:{l}:ba" for l in sorted(T["wall_lines"])]
          + [f"wl:{l}:wa" for l in sorted(T["wall_lines"])])


def get_option(d, g):
    if g == "sfrs":
        return d["sfrs"]
    kind, a, *rest = g.split(":")
    if kind == "zone":
        return d["deck_zones"][a]
    if kind == "coll":
        return d["collector_lines"][a]
    if kind == "wl":
        wd = d["wall_lines"][a]
        if rest[0] == "jc":
            return (wd["joint_connector"], wd["connectors_per_joint"])
        if rest[0] == "ba":
            return wd["base_anchor"]
        return (wd["wall_anchor"], wd["wall_anchor_spacing_ft"])


def set_option(d, g, v):
    if g == "sfrs":
        d["sfrs"] = v
        return
    kind, a, *rest = g.split(":")
    if kind == "zone":
        d["deck_zones"][a] = v
    elif kind == "coll":
        d["collector_lines"][a] = v
    elif kind == "wl":
        wd = d["wall_lines"][a]
        if rest[0] == "jc":
            wd["joint_connector"], wd["connectors_per_joint"] = v
        elif rest[0] == "ba":
            wd["base_anchor"] = v
        else:
            wd["wall_anchor"], wd["wall_anchor_spacing_ft"] = v


def options_for(g):
    if g == "sfrs":
        return ["intermediate_precast", "special_precast"]
    kind, a, *rest = g.split(":")
    if kind == "zone":
        return zone_options()
    if kind == "coll":
        return coll_options()
    if kind == "wl":
        if rest[0] == "jc":
            return [(j, n) for j, n, _ in jc_options()]
        if rest[0] == "ba":
            return ba_options()
        return [(w, s) for w, s, _ in wa_options(a)]


def group_cost(d, g):
    """Marginal cost attributable to this group (for ordering the descent)."""
    kind = g.split(":")[0]
    if kind == "zone":
        z = g.split(":")[1]
        return C.zone_area(T, z) * T["deck_patterns"][d["deck_zones"][z]]["cost_psf"]
    if kind == "coll":
        l = g.split(":")[1]
        ax, coord, c0, c1 = T["collector_lines"][l]
        return (c1 - c0) * T["collectors"][d["collector_lines"][l]]["cost_plf"]
    if kind == "wl":
        line, what = g.split(":")[1], g.split(":")[2]
        wd = d["wall_lines"][line]
        nj = C.n_joints(T, d["as_built_piers"]).get(line, 0)
        npn = C.n_panels(T, d["as_built_piers"]).get(line, 0)
        if what == "jc":
            return nj * wd["connectors_per_joint"] * T["joint_connectors"][wd["joint_connector"]]["cost_ea"]
        if what == "ba":
            return npn * T["base_anchors"][wd["base_anchor"]]["cost_ea"]
        c0, c1 = T["wall_lines"][line][2]
        return (c1 - c0) / wd["wall_anchor_spacing_ft"] * T["wall_anchors"][wd["wall_anchor"]]["cost_ea"]
    return 0.0


def repair(d, verbose=True):
    """Cheapest-first: for each group take the cheapest option that keeps the whole design feasible."""
    cur = evaluate(d)
    if not cur["ok"]:
        return d, cur
    for passes in range(6):
        improved = False
        order = sorted(GROUPS, key=lambda g: -group_cost(d, g))
        for g in order:
            opts = options_for(g)
            cur_v = get_option(d, g)
            pick, pick_r = cur_v, cur
            for v in opts:
                if v == cur_v:
                    break
                trial = copy.deepcopy(d)
                set_option(trial, g, v)
                r = evaluate(trial)
                if r["ok"]:
                    pick, pick_r = v, r
                    break
            if pick != cur_v:
                set_option(d, g, pick)
                cur = pick_r
                improved = True
                if verbose:
                    print(f"  pass{passes+1} {g}: {pick} cost {cur['cost']:.0f}", flush=True)
        if verbose:
            print(f"pass {passes+1} done, cost {evaluate(d)['cost']:.0f}", flush=True)
        if not improved:
            break
    return d, evaluate(d)


if __name__ == "__main__":
    t0 = time.time()
    d = design0()
    r = evaluate(d)
    print("start design", d["sfrs"], "cost", round(r["cost"]), "ok", r["ok"])
    if not r["ok"]:
        for f, v in r["fail"].items():
            print("  FAIL", f, v[:4])
    d, r = repair(d)
    print(json.dumps({"cost": r["cost"], "ok": r["ok"], "evals": N_EVAL[0],
                      "seconds": round(time.time() - t0, 1)}, indent=1))
    print(json.dumps(r["costs"], indent=1))
    if not r["ok"]:
        for f, v in r["fail"].items():
            print("  FAIL", f, v[:6])
    json.dump(d, open("/work/seis/best_design.json", "w"), indent=1)
