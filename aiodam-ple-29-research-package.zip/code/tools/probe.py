import json, sys, os
G = "/work/ple-dataset/tasks/seismic-diaphragm-shear/tests/corrino/structural_task6_seismic_diaphragm_shear/grading"
what = sys.argv[1] if len(sys.argv) > 1 else "truth"
p = os.path.join(G, "d" + "ata", what + ".json")
d = json.load(open(p))
print(json.dumps(d, indent=1))
