#!/usr/bin/env python3
"""RESULTS_LEDGER.md — final: every task's deliverable bound to the file on disk NOW.

A. 15 checks / checks-judge tasks:
   - the submission file that is on disk now (path, size, sha256),
   - the number my driver (remeasure_523.py) got from it,
   - the number the task's OWN tests/test.sh got from it (official_testsh/RUN.json), where it ran.
B. 14 rubric tasks: the docx deliverable, size, sha256, and whether it still has the recorded size.

Nothing is filled in from notes: every number is read from a file this turn wrote.
"""
import json
from pathlib import Path

SOLVE = Path("/work/ple-solve")
CHECKS = [
    ("cooling-water-flush-plan", False), ("data-center-site-model", False),
    ("data-hall-device-takeoff", False), ("data-hall-mep-routing", False),
    ("data-hall-mep-routing-offset", False), ("division-26-specifications", False),
    ("eor-review-corrections", True), ("foundation-strategy", True),
    ("frame-extension-method", False), ("heat-rejection-life-cycle-cost", False),
    ("lv-cable-sizing", True), ("mv-conveyance-study", False),
    ("roof-deck-design", False), ("seismic-diaphragm-shear", False),
    ("wind-diaphragm-shear", False),
]

out = []
out.append("## A. checks / checks-judge — балл перемерен с файла, который лежит на диске сейчас")
out.append("")
out.append("| # | задача | файл решения | размер | sha256 | мой драйвер | официальный `tests/test.sh` |")
out.append("|---|---|---|---|---|---|---|")
n = off = 0
for task, is_judge in CHECKS:
    res = SOLVE / task / "results_523" / "RESULT.json"
    if not res.is_file():
        out.append(f"| — | `{task}` | NOT RE-MEASURED | | | | |")
        continue
    n += 1
    r = json.loads(res.read_text())
    sub = r["submission"]
    m = r["result"].get("metrics") or {}
    reward = r["result"].get("reward")
    run = SOLVE / task / "results_523" / "official_testsh" / "RUN.json"
    if run.is_file():
        off += 1
        orw = json.loads(run.read_text()).get("reward")
        offc = f"**{orw:.6f}**" if isinstance(orw, (int, float)) else str(orw)
    else:
        offc = "— (без ключа судьи путь падает до грейдера)"
    star = " *" if is_judge else ""
    out.append("| {i} | `{t}{s} | `{p}` | {sz} b | `{h}` | {rw} | {o} |".format(
        i=n, t=task, s="`" + star, p=sub["path"].replace("/work/ple-solve/", ""), sz=sub["size"],
        h=sub["sha256_before"][:16],
        rw=f"{reward:.6f}" if isinstance(reward, (int, float)) else "—", o=offc))
out.append("")
out.append(f"строк: {n} из 15; официальным путём подтверждено {off}; `*` = checks-judge.")
out.append("")
out.append("**Две не подтверждены официальным путём по одной причине:** в `verify.py` этих задач "
           "`LLM_JUDGE = True`, и без `JUDGE_BASE_URL` он выходит **до** запуска грейдера "
           "(`GRADER FAILED: JUDGE_BASE_URL is not set`). Их грейдерная часть перемерена драйвером "
           "напрямую (`run_grade.py --no-judge` + `paper_score.py`) — те же файлы, тот же код, "
           "минус relay судьи.")
out.append("")

rf = json.loads((SOLVE / "rubric_files_523.json").read_text())
out.append("## B. rubric — пакет собран и лежит на диске; балла нет, судьи нет")
out.append("")
out.append("| # | задача | файл решения | размер | sha256 | совпал с записью |")
out.append("|---|---|---|---|---|---|")
for i, (task, r) in enumerate(sorted(rf.items()), 1):
    if r.get("missing"):
        out.append(f"| {i} | `{task}` | **MISSING** `{r['missing']}` | | | |")
    else:
        out.append("| {i} | `{t}` | `{p}` | {s} b | `{h}` | {m} |".format(
            i=i, t=task, p=r["path"], s=r["size"], h=r["sha256"][:16],
            m="да" if r["size_matches_record"] else "НЕТ"))
out.append("")
out.append(f"строк: {len(rf)} из 14.")
print("\n".join(out))
