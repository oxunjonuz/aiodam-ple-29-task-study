"""Independent recomputation for engineers-estimate-check (Sundial / Desert Sage Ranch Ph3).
Reads the estimate workbook, the plan structure schedule (text of C-8), and C-9 inverts.
Every number below is computed here; nothing is copied from the rubric."""
import json, math, re
import openpyxl, pymupdf

BASE = "/work/ple-dataset/tasks/engineers-estimate-check/environment/tools/files/confirm-the-phase-3-engineer-s-estimate-ahead-of-the-bond-conversation-f38f3a26"
OUT = {}

# ---------- 1. Section 2 as issued
wb = openpyxl.load_workbook(f"{BASE}/Cost Estimates/DSR_Ph3_Engineers_Estimate.xlsx", data_only=True)
ws = wb['Estimate']
items = {}
for r in ws.iter_rows(values_only=True):
    if r[0] and isinstance(r[0], str) and re.fullmatch(r'\d\.\d\d', r[0].strip()):
        no = r[0].strip()
        items[no] = {'no': no, 'desc': r[1], 'qty': r[2], 'unit': r[3],
                     'price': r[4], 'ext': r[5]}
sec2 = {k: v for k, v in items.items() if k.startswith('2.')}
sec2_sum = round(sum(v['ext'] for v in sec2.values()), 2)
OUT['sec2_lines'] = sec2
OUT['sec2_as_issued'] = sec2_sum
assert sec2_sum == 1276934.00, sec2_sum

# ---------- 2. structure schedule from sheet C-8 (pages 13-14)
d = pymupdf.open(f"{BASE}/Design-Drafting/Phase 3/DSR_Ph3_Improvement_Plans_C1-C9.pdf")
txt = d[12].get_text() + "\n" + d[13].get_text()
rows, parts = [], re.split(r'(?m)^(S-\d+)\s*$', txt)
for i in range(1, len(parts), 2):
    sid, body = parts[i], parts[i+1]
    m = re.search(r'(\d+\+\d{2}\.\d{2})', body)
    if not m: continue
    typ = ' '.join(body[:m.start()].split())
    toks = re.findall(r'(\d,\d{3}\.\d{2}|\u2014)', body[m.end():])[:3]
    if len(toks) < 3: continue
    conv = lambda t: None if t == '\u2014' else float(t.replace(',', ''))
    rows.append({'id': sid, 'type': typ, 'station': m.group(1), 'rim': conv(toks[0]),
                 'in_out': conv(toks[2])})
assert len(rows) == 14, len(rows)
mh = [r for r in rows if 'manhole' in r['type'].lower()]
for r in rows:
    r['depth'] = round(r['rim'] - r['in_out'], 2)
deep = [r for r in mh if r['depth'] > 10.0]
excess = round(sum(r['depth'] - 10.0 for r in deep), 2)
OUT['structures'] = rows
OUT['manholes'] = [r['id'] for r in mh]
OUT['manholes_over_10ft'] = [(r['id'], r['depth']) for r in deep]
OUT['excess_vf'] = excess

# ---------- 3. C-9: 30-inch outfall reach from inverts and slope
c9 = d[17].get_text()
inv_head = float(re.search(r'invert at headwall face ([\d,]+\.\d+)', c9).group(1).replace(',', ''))
inv_stub = float(re.search(r'invert at existing stub ([\d,]+\.\d+)', d[16].get_text()).group(1).replace(',', ''))
slope = float(re.search(r'sloped at ([\d.]+)%', c9).group(1)) / 100.0
outfall_lf = round((inv_head - inv_stub) / slope, 2)
OUT.update(inv_head=inv_head, inv_stub=inv_stub, slope=slope, outfall_lf=outfall_lf)

# ---------- 3b. published unit prices, parsed from the schedule itself
sch_txt = '\n'.join(pg.get_text() for pg in pymupdf.open(f"{BASE}/Cost Estimates/CC_Unit_Cost_Schedule.pdf"))
sched = {}
for m in re.finditer(r'(?m)^(\d{1,2}\.\d\d)\n([^\n]+)\n(EA|LF|SY|CY|VF|LS|AC|SF)\n\$([\d,]+\.\d\d)$', sch_txt):
    sched[m.group(1)] = {'desc': m.group(2).strip(), 'unit': m.group(3),
                         'price': float(m.group(4).replace(',', ''))}
assert len(sched) > 60, len(sched)
OUT['schedule_items'] = sched
for k in ('2.03','2.35','2.36','2.38','2.47','2.30'):
    assert k in sched, k
    print('sched', k, sched[k])
p = lambda n: sched[n]['price']
corr = [
  {'no': '2.35', 'desc': sec2['2.35']['desc'], 'old_qty': sec2['2.35']['qty'],
   'old_amt': sec2['2.35']['ext'], 'qty': 0, 'unit': 'EA', 'price': p('2.35'), 'amt': 0.0,
   'basis': "No 48-inch manhole appears anywhere in the Sheet C-8 Structure Schedule; note 1 on C-8 makes every "
            "manhole 5-foot inside diameter. Quantity carried against the wrong diameter and count, removed.",
   'source': 'Sheet C-8 Structure Schedule (S-1 through S-14); C-8 Storm Drain Design Note 1'},
  {'no': '2.36', 'desc': sched['2.36']['desc'], 'old_qty': 0,
   'old_amt': 0.0, 'qty': len(mh), 'unit': 'EA', 'price': p('2.36'), 'amt': round(len(mh) * p('2.36'), 2),
   'basis': "Ten of the fourteen structures in the Sheet C-8 schedule are typed manhole (S-1, S-2, S-4, S-6, S-7, "
            "S-8, S-10, S-11, S-12, S-14); S-3, S-5, S-9 and S-13 are curb inlets only. Line absent from the estimate "
            "as issued.",
   'source': 'Sheet C-8 Structure Schedule'},
  {'no': '2.38', 'desc': sched['2.38']['desc'], 'old_qty': 0,
   'old_amt': 0.0, 'qty': excess, 'unit': 'VF', 'price': p('2.38'), 'amt': round(excess * p('2.38'), 2),
   'basis': "Seven of the ten manholes are deeper than the 10 ft ceiling of item 2.36: " +
            ', '.join(f"{i} {dp:.2f} ft" for i, dp in OUT['manholes_over_10ft']) +
            f". Depth taken rim to invert out; excess over 10 ft sums to {excess:.2f} VF.",
   'source': 'Sheet C-8 Structure Schedule (rim and invert-out elevations)'},
  {'no': '2.03', 'desc': sched['2.03']['desc'], 'old_qty': 0,
   'old_amt': 0.0, 'qty': outfall_lf, 'unit': 'LF', 'price': p('2.03'), 'amt': round(outfall_lf * p('2.03'), 2),
   'basis': f"Basin outlet: invert at headwall face {inv_head:,.2f} to existing shared outfall stub {inv_stub:,.2f} "
            f"at {slope*100:.2f}%, i.e. {outfall_lf:.0f} LF at the published $138.00/LF. The 30-inch outfall reach is "
            "not carried anywhere in the estimate as issued.",
   'source': 'Sheet C-9 outlet detail and Sheet C-9 longitudinal section callouts'},
]
net = round(sum(c['amt'] - c['old_amt'] for c in corr), 2)
sec2_new = round(sec2_sum + net, 2)
OUT['corrections'] = corr
OUT['net_change'] = net
OUT['sec2_corrected'] = sec2_new

# ---------- 5. bond arithmetic
summ = wb['Summary']
vals = {r[1].strip(): r[2] for r in summ.iter_rows(values_only=True) if isinstance(r[1], str) and isinstance(r[2], (int, float))}
OUT['summary_as_issued'] = vals
constr_old = round(vals['Construction Subtotal'], 2)
allowances = round(vals['Mobilization, Bonds, Insurance (lump sum allowance)'] +
                   vals['Contingency (lump sum allowance)'], 2)
constr_new = round(constr_old + net, 2)
raw_new = round(constr_new + allowances, 2)
bond_new = math.ceil(raw_new / 1000.0) * 1000
raw_old = round(constr_old + allowances, 2)
OUT.update(construction_old=constr_old, allowances=allowances, construction_new=constr_new,
           grand_unrounded_old=raw_old, grand_unrounded_new=raw_new,
           bond_old=math.ceil(raw_old / 1000.0) * 1000, bond_new=bond_new)

print(json.dumps({k: OUT[k] for k in ('sec2_as_issued', 'manholes', 'excess_vf', 'outfall_lf',
      'net_change', 'sec2_corrected', 'construction_old', 'construction_new',
      'grand_unrounded_new', 'bond_new')}, indent=1))
print('bond as issued on the sheet:', vals.get("ENGINEER'S ESTIMATE — TOTAL"))
for c in corr:
    print(f"  {c['no']}  qty {c['qty']:>8} {c['unit']:2s} x {c['price']:>8,.2f} = {c['amt']:>12,.2f}   (was {c['old_amt']:,.2f})")
json.dump(OUT, open('/work/ple-solve/engineers-estimate-check/results.json', 'w'), indent=1)
