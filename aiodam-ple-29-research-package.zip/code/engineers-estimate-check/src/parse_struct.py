import re, json, pymupdf
BASE = "/work/ple-dataset/tasks/engineers-estimate-check/environment/tools/files/confirm-the-phase-3-engineer-s-estimate-ahead-of-the-bond-conversation-f38f3a26"
d = pymupdf.open(f"{BASE}/Design-Drafting/Phase 3/DSR_Ph3_Improvement_Plans_C1-C9.pdf")
txt = d[12].get_text() + "\n<<<PAGEBREAK>>>\n" + d[13].get_text()

rows = []
parts = re.split(r'(?m)^(S-\d+)\s*$', txt)
for i in range(1, len(parts), 2):
    sid, body = parts[i], parts[i+1]
    body = body[:body.find('S-')+2] if False else body
    m = re.search(r'(\d+\+\d{2}\.\d{2})', body)
    if not m: continue
    typ = ' '.join(body[:m.start()].split())
    tail = body[m.end():]
    toks = re.findall(r'(\d,\d{3}\.\d{2}|\u2014)', tail)[:3]
    if len(toks) < 3: continue
    conv = lambda t: None if t == '\u2014' else float(t.replace(',', ''))
    rows.append({'id': sid, 'type': typ, 'station': m.group(1),
                 'rim': conv(toks[0]), 'in_in': conv(toks[1]), 'in_out': conv(toks[2])})
print(f"parsed {len(rows)} structures")
for r in rows:
    depth = r['rim'] - r['in_out']
    is_mh = 'manhole' in r['type'].lower()
    print(f"{r['id']:5s} {r['type'][:44]:44s} {r['station']:>9s} rim={r['rim']:.2f} out={r['in_out']:.2f} depth={depth:5.2f} {'MANHOLE' if is_mh else 'curb-inlet'}")
mh = [r for r in rows if 'manhole' in r['type'].lower()]
deep = [r for r in mh if r['rim'] - r['in_out'] > 10.0]
excess = sum(round(r['rim'] - r['in_out'], 2) - 10.0 for r in deep)
print(f"\nmanholes = {len(mh)}: {[r['id'] for r in mh]}")
print(f"deeper than 10 ft = {len(deep)}: {[(r['id'], round(r['rim']-r['in_out'],2)) for r in deep]}")
print(f"SUM of excess = {excess:.2f} VF   x $685.00 = ${excess*685:,.2f}")
json.dump(rows, open('/work/ple-solve/engineers-estimate-check/struct.json','w'), indent=1)
