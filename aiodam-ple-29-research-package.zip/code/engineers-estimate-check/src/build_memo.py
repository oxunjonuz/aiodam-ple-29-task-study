import json, os, shutil
from docx import Document
from docx.shared import Pt, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT

R = json.load(open('/work/ple-solve/engineers-estimate-check/results.json'))
m = lambda v: f"${v:,.2f}"
m0 = lambda v: f"${v:,.0f}"
corr = R['corrections']

doc = Document()
st = doc.styles['Normal']
st.font.name = 'Calibri'; st.font.size = Pt(10.5)
for s in doc.sections:
    s.top_margin = s.bottom_margin = Inches(0.8)
    s.left_margin = s.right_margin = Inches(0.9)

def para(text, bold=False, size=None, space_after=6, align=None, italic=False):
    p = doc.add_paragraph()
    r = p.add_run(text); r.bold = bold; r.italic = italic
    if size: r.font.size = Pt(size)
    p.paragraph_format.space_after = Pt(space_after)
    if align: p.alignment = align
    return p

def table(headers, rows, widths=None, align_right=None):
    t = doc.add_table(rows=1, cols=len(headers))
    t.style = 'Table Grid'
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, h in enumerate(headers):
        c = t.rows[0].cells[i]
        c.text = ''
        run = c.paragraphs[0].add_run(h); run.bold = True; run.font.size = Pt(8.5)
    for row in rows:
        cells = t.add_row().cells
        for i, v in enumerate(row):
            cells[i].text = ''
            run = cells[i].paragraphs[0].add_run(str(v)); run.font.size = Pt(8.5)
            if align_right and i in align_right:
                cells[i].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.RIGHT
    if widths:
        for row in t.rows:
            for i, w in enumerate(widths):
                row.cells[i].width = Inches(w)
    return t

# ---------------- letterhead / memo block
para('SUNDIAL ENGINEERING & SURVEY', bold=True, size=13, space_after=0)
para('4720 South Rainbow Boulevard, Suite 210  ·  Las Vegas, Nevada 89103  ·  (702) 555-0142  ·  NV COA #C-3874',
     size=8, space_after=10)
para('MEMORANDUM', bold=True, size=15, space_after=10)

hdr = [
    ('TO:', 'Callaway Land Partners — Garrett Nokes, VP Land Development; copy to the Phase 3 surety broker'),
    ('FROM:', 'Max Braddock, Project Manager, Sundial Engineering & Survey'),
    ('REVIEWED AND SEALED BY:', 'Jonathan R. Kessler, PE — Nevada Professional Engineer License No. 14203'),
    ('DATE:', '10/31/2026'),
    ('JOB NO.:', '2201-03 — Desert Sage Ranch Phase 3, 60 lots, 40.0 acres'),
    ('SUBJECT:', 'Corrected Section 2 (Storm Drain and Detention) and revised bond figure ahead of the bond conversation'),
]
t = doc.add_table(rows=0, cols=2)
for k, v in hdr:
    cells = t.add_row().cells
    cells[0].text = ''; cells[1].text = ''
    r0 = cells[0].paragraphs[0].add_run(k); r0.bold = True; r0.font.size = Pt(9.5)
    r1 = cells[1].paragraphs[0].add_run(v); r1.font.size = Pt(9.5)
for row in t.rows:
    row.cells[0].width = Inches(1.75); row.cells[1].width = Inches(5.15)
para('', space_after=4)

# ---------------- 1. bottom line
para('1.  Bottom line', bold=True, size=11.5, space_after=4)
para(
    f"Section 2 of the Phase 3 Engineer's Estimate (DSR_Ph3_Engineers_Estimate, Cost Estimates) has been checked "
    f"line by line against the drainage sheets C-6, C-8 and C-9 in DSR_Ph3_Improvement_Plans_C1-C9 and against the "
    f"pipe reaches scheduled in DSR_Ph3_StormDrain_HGL (Reports-Studies). Four lines in Section 2 change; every other "
    f"line in the estimate stands. The corrected Section 2 subtotal is {m(R['sec2_corrected'])} against "
    f"{m(R['sec2_as_issued'])} carried in the estimate as issued, a net increase of {m(R['net_change'])}.",
    space_after=6)
para(
    f"Carried through Sections 1 and 3 through 8 unchanged and the Section 9 agreed lump sums of "
    f"{m(R['allowances'])} untouched, the construction subtotal moves from {m(R['construction_old'])} to "
    f"{m(R['construction_new'])} and the unrounded total is {m(R['grand_unrounded_new'])}. Rounded up to the next "
    f"$1,000 per Section 12.02 of the Uniform Unit Cost Schedule, the revised rounded bond figure is "
    f"{m0(R['bond_new'])}. Please post {m0(R['bond_new'])} with the surety broker. That figure supersedes the "
    f"{m0(R['bond_old'])} shown on the estimate dated 10/10/2026; the estimate as issued is not to be circulated "
    f"for bonding.", space_after=10)

# ---------------- 2. line-by-line table
para('2.  Line-by-line changes to Section 2', bold=True, size=11.5, space_after=4)
para('Each change is listed with the quantity used, the published unit price, the extended amount, and the sheet or '
     'report the quantity comes off. Rounding of pipe lengths is to the next whole foot.', space_after=6)
rows = []
for c in corr:
    if c['no'] == '2.35':
        rows.append(['2.35', c['desc'], 'Removed — quantity carried against the wrong diameter and count',
                     '0 EA  (was 14 EA)', m(c['price']), '$0.00  (was ' + m(c['old_amt']) + ')',
                     'Sheet C-8 Structure Schedule; C-8 note 1 (all manholes 5-ft dia.)'])
    else:
        rows.append([c['no'], c['desc'], 'Added — absent from the estimate as issued',
                     f"{c['qty']:,.2f} {c['unit']}" if c['unit'] == 'VF' else f"{c['qty']:,.0f} {c['unit']}",
                     m(c['price']), m(c['amt']), c['source']])
rows.append(['', 'Net change to Section 2', '', '', '', m(R['net_change']), ''])
table(['Item', 'Description', 'Change', 'Quantity', 'Unit price', 'Amount', 'Source'], rows,
      widths=[0.45, 1.55, 1.35, 0.85, 0.7, 0.95, 1.25], align_right={3, 4, 5})
para('', space_after=6)

for c in corr:
    para(f"Item {c['no']} — {c['desc']}.", bold=True, size=9.5, space_after=2)
    para(c['basis'], size=9.5, space_after=6)

# ---------------- 3. reconciliation
para('3.  Reconciliation — items examined and left as carried', bold=True, size=11.5, space_after=4)
para(
    "The basin maintenance access ramp shown on Sheets C-6 and C-9 has no matching item in the published schedule. "
    "The detail on Sheet C-9 calls a 15-foot-wide ramp at 6 percent grade surfaced with 6-inch aggregate base course "
    "(H-20 load per the C-6 notes); the nearest published item, 2.47, is an access ramp of 4-inch asphaltic concrete "
    "over 6-inch aggregate base at $32.00 per square yard, which is a different section. No amount is added for the "
    "ramp: it is flagged here and referred for alternate pricing under Section 12.04 of the schedule, and the "
    "reconciliation carries it as an unresolved item for the bond conversation.", space_after=6)
para(
    f"The Type G curb inlets are the second such item. Sheet C-8 note 4 specifies curb inlets Type G with an 8-foot "
    f"opening per Clark County Standard Drawing SD-305, while the published schedule offers Type A, Type B and "
    f"combination inlets only. There is nothing in the schedule that matches a Type G inlet, so item 2.30 is flagged "
    f"and the amount already carried, {m(R['sec2_lines']['2.30']['ext'])}, remains in the Section 2 subtotal for "
    f"12 Type A curb inlets at $4,850.00 each. The same treatment applies to item 2.34, which stands at "
    f"{m(R['sec2_lines']['2.34']['ext'])}.", space_after=6)
para(
    "Items for which the plans give no dimension or stationing — 2.39 junction structure, 2.40 headwalls, 2.42 riprap, "
    "2.44 basin excavation, 2.45 outlet structure, 2.46 basin fencing and 2.99 field connections — keep the quantities "
    "already carried. The three pipe reaches were re-derived from the stationing on Sheet C-8 and the reach schedule in "
    "DSR_Ph3_StormDrain_HGL and are unchanged: 36-inch RCP 870 LF (869.58 LF computed), 48-inch RCP 687 LF "
    "(686.51 LF), 60-inch RCP 1,334 LF (1,333.56 LF, including the 240 LF Line B outfall reach), each rounded to the "
    "next whole foot. Detention storage on Sheet C-9 stays at the 6.4 acre-foot Phase 3 allocation.", space_after=10)

# ---------------- 4. bond build-up
para('4.  How the revised bond figure is built', bold=True, size=11.5, space_after=4)
bt = [
    ['Section 1 — Earthwork', m(R['summary_as_issued']['Earthwork']), 'unchanged'],
    ['Section 2 — Storm Drain and Detention', m(R['sec2_corrected']), f"was {m(R['sec2_as_issued'])}; net {m(R['net_change'])}"],
    ['Section 3 — Streets and Paving', m(R['summary_as_issued']['Streets and Paving']), 'unchanged'],
    ['Section 4 — Wet Utilities', m(R['summary_as_issued']['Wet Utilities (Water and Sewer)']), 'unchanged'],
    ['Section 5 — Dry Utilities', m(R['summary_as_issued']['Dry Utilities (Joint Trench)']), 'unchanged'],
    ['Section 6 — Landscape and Irrigation', m(R['summary_as_issued']['Landscape and Irrigation (Common Areas)']), 'unchanged'],
    ['Section 7 — Monumentation and Survey', m(R['summary_as_issued']['Monumentation and Survey']), 'unchanged'],
    ['Section 8 — Traffic Control and Signage', m(R['summary_as_issued']['Traffic Control and Signage']), 'unchanged'],
    ['Construction subtotal, Sections 1 through 8', m(R['construction_new']), f"was {m(R['construction_old'])}"],
    ['Section 9 — agreed lump sums (mobilization, bonds, insurance $350,000.00; contingency $150,000.00)',
     m(R['allowances']), 'unchanged, Addendum No. 1 items 11.05 and 11.06'],
    ['Unrounded total', m(R['grand_unrounded_new']), f"was {m(R['grand_unrounded_old'])}"],
    ['Rounded bond figure per Section 12.02', m0(R['bond_new']), f"was {m0(R['bond_old'])}"],
]
table(['Component', 'Amount', 'Note'], bt, widths=[3.6, 1.35, 2.6], align_right={1})
para('', space_after=6)
para(
    "The Section 9 allowances are the lump sums agreed with the Department under Addendum No. 1 and are not "
    "recalculated as percentages; item 11.02, design, survey and construction inspection, is owner-carried outside "
    "the bonded estimate, which is why the estimate carries an express statement of that treatment as item 11.07 "
    "requires. Rounding follows Section 12.02: unit prices to the cent as published, extensions to the dollar, and "
    "the bonded amount up to the next $1,000.", space_after=10)

# ---------------- 5. action
para('5.  Action requested', bold=True, size=11.5, space_after=4)
para(
    f"Post {m0(R['bond_new'])} with the surety broker as the Phase 3 performance bond amount and hold the estimate "
    f"until the corrected Section 2 is issued with this memorandum. The two flagged items — the basin maintenance "
    f"access ramp and the Type G curb inlets — need a decision before the figure is final: either the Department "
    f"accepts them under an alternate unit price under Section 12.04, or the ramp stays outside the bonded amount as "
    f"shown here. Until that decision arrives, {m0(R['bond_new'])} is the number to carry, and no part of the "
    f"{m(R['net_change'])} reconciliation moves back into the subtotal.", space_after=12)

para('Prepared by Max Braddock, Project Manager  ·  Sundial Engineering & Survey  ·  10/31/2026', size=9, space_after=2)
para('Sealed: Jonathan R. Kessler, PE — Nevada P.E. License No. 14203  ·  NV COA #C-3874', size=9, space_after=2)

out = '/work/ple-solve/engineers-estimate-check/out/Correspondence/Client'
os.makedirs(out, exist_ok=True)
path = f'{out}/Memo_to_Callaway_2026-10-31.docx'
doc.save(path)
print('wrote', path, os.path.getsize(path), 'bytes')
