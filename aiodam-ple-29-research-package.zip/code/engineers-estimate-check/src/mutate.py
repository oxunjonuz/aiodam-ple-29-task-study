"""12 single-point breakages of the delivered memo; the reader must catch every one."""
import os, subprocess, sys, docx
SRC = '/work/ple-solve/engineers-estimate-check/out/Correspondence/Client/Memo_to_Callaway_2026-10-31.docx'
OUT = '/work/ple-solve/engineers-estimate-check/mut'
READER = '/work/ple-solve/engineers-estimate-check/src/verify_memo.py'
PY_BIN = '/work/venv-verifier/bin/python'
os.makedirs(OUT, exist_ok=True)

MUTS = [
 ('M01_bond_5383000',      [('$5,384,000', '$5,383,000')]),
 ('M02_subtotal_off_by_1', [('$1,303,717.70', '$1,303,718.70')]),
 ('M03_manholes_11',       [('10 EA', '11 EA')]),
 ('M04_depth_amount',      [('$15,083.70', '$15,083.07')]),
 ('M05_outfall_amount',    [('$13,800', '$13,600')]),
 ('M06_union_inlet_dropped',[('$58,200.00', '$0.00')]),
 ('M07_wrong_recipient',   [('Callaway', 'Kestrel Holdings')]),
 ('M08_no_source_column',  [('Sheet C-8 Structure Schedule; C-8 note 1 (all manholes 5-ft dia.)', '—'),
                            ('Sheet C-8 Structure Schedule', '—'),
                            ('Sheet C-9 outlet detail and Sheet C-9 longitudinal section callouts', '—'),
                            ('Sheet C-8 Structure Schedule (rim and invert-out elevations)', '—')]),
 ('M09_wrong_date',        [('10/31/2026', '11/01/2026')]),
 ('M10_ramp_not_flagged',  [('has no matching item in the published schedule', 'is priced under item 2.47')]),
 ('M11_net_change',        [('$26,783.70', '$26,783.07')]),
 ('M12_turnover_carry',    [('$4,883,349.45', '$4,883,394.45')]),
]
def mutate(path, subs):
    d = docx.Document(SRC)
    hits = 0
    def do(par):
        nonlocal hits
        for r in par.runs:
            for a, b in subs:
                if a in r.text:
                    r.text = r.text.replace(a, b); hits += 1
    for p in d.paragraphs: do(p)
    for t in d.tables:
        for row in t.rows:
            for c in row.cells:
                for p in c.paragraphs: do(p)
    d.save(path)
    return hits

fails = 0
for name, subs in MUTS:
    path = f'{OUT}/{name}.docx'
    hits = mutate(path, subs)
    r = subprocess.run([PY_BIN, READER, path, 'read'], capture_output=True, text=True)
    red = [l.strip() for l in r.stdout.splitlines() if '[FAIL]' in l]
    caught = r.returncode != 0 and len(red) > 0 and 'Traceback' not in r.stderr
    print(f"{'CAUGHT ' if caught else 'SURVIVED'}  {name:26s} edits={hits}  red={len(red)}")
    for l in red[:3]: print('        ', l)
    fails += (not caught)
print(f'\nsummary: {len(MUTS)-fails}/{len(MUTS)} caught')
sys.exit(1 if fails else 0)
