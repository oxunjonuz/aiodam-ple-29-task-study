"""Three independent checks on the delivered memo, none of them sharing code with build_memo.py:
   read   — 10 rubric criteria evaluated on the docx text (paragraphs + table cells)
   audit  — every number carrying a unit must be derivable from the corpus documents
   mutate — a family of single-point breakages; each must turn `read` red
Usage: verify_memo.py <memo.docx> [read|audit|all]
"""
import json, re, sys, collections
import docx

PATH = sys.argv[1]
MODE = sys.argv[2] if len(sys.argv) > 2 else 'all'
R = json.load(open('/work/ple-solve/engineers-estimate-check/results.json'))

def full_text(path):
    d = docx.Document(path)
    parts = [p.text for p in d.paragraphs]
    for t in d.tables:
        for row in t.rows:
            parts.append(' | '.join(c.text for c in row.cells))
    return '\n'.join(parts)

T = full_text(PATH)
NORM = re.sub(r'\s+', ' ', T)

def num(s):  # money/quantity token -> float
    return float(s.replace(',', '').replace('$', ''))

results = []
def crit(name, ok, detail):
    results.append((name, ok, detail))

# C1 revised rounded bond figure
ok = bool(re.search(r'\$5,384,000(?!\d)', NORM)) or bool(re.search(r'\$5384000(?!\d)', NORM))
crit('C1 bond figure $5,384,000', ok, '$5,384,000 present' if ok else 'missing')

# C2 corrected Section 2 subtotal
ok = bool(re.search(r'\$1,303,717\.70', NORM)) or bool(re.search(r'\$1,303,718(?!\d)', NORM))
crit('C2 Section 2 subtotal $1,303,717.70', ok, 'present' if ok else 'missing')

# C3 item 2.36 quantity 10 EA
row = [l for l in T.split('\n') if l.strip().startswith('2.36')]
qty_cell = [c.strip() for c in row[0].split('|')][3] if row else ''
ok = bool(re.fullmatch(r'10\s*EA', qty_cell)) or \
     bool(re.search(r'item 2\.36[^.]{0,120}?10 (?:EA|each)', NORM, re.I)) or \
     bool(re.search(r'2\.36[^|]{0,200}?10[^|]{0,20}EA', NORM))
crit('C3 item 2.36 = 10 EA', ok, (row[0][:90] if row else 'no 2.36 row'))

# C4 item 2.38 amount
ok = bool(re.search(r'\$15,083\.70', NORM))
crit('C4 item 2.38 = $15,083.70', ok, 'present' if ok else 'missing')

# C5 item 2.03 amount
ok = bool(re.search(r'\$13,800(?!\d)', NORM))
crit('C5 item 2.03 = $13,800', ok, 'present' if ok else 'missing')

# C6 item 2.30 retains $58,200
ok = bool(re.search(r'\$58,200(?!\d)', NORM)) and '2.30' in NORM
crit('C6 item 2.30 retains $58,200', ok, 'present' if ok else 'missing')

# C7 recipient
ok = bool(re.search(r'TO:\s*Callaway', NORM, re.I)) or bool(re.search(r'Callaway Land Partners', NORM))
crit('C7 recipient Callaway', ok, 'present' if ok else 'missing')

# C8 line-by-line table pairing each change with its sheet source
hdr_ok = bool(re.search(r'Item \| Description \| Change \| Quantity \| Unit price \| Amount \| Source', NORM))
paired = 0
for item in ('2.35', '2.36', '2.38', '2.03'):
    l = [x for x in T.split('\n') if x.strip().startswith(item + ' |')]
    if l and re.search(r'Sheet C-[689]', l[0]):
        paired += 1
crit('C8 table pairs every change with its sheet', hdr_ok and paired == 4,
     f'header={hdr_ok} items with sheet={paired}/4')

# C9 date
ok = '10/31/2026' in NORM or 'October 31, 2026' in NORM
crit('C9 date 10/31/2026', ok, 'present' if ok else 'missing')

# C10 basin access ramp flagged as having no matching schedule item
sent = [x for x in re.split(r'(?<=[.])\s+', NORM) if re.search(r'\bramp\b', x, re.I)]
seg = sent[0] if sent else None
ok = bool(seg) and bool(re.search(r'no matching item|nothing in the schedule|no match(es)? ', seg, re.I))
crit('C10 ramp flagged as unmatched', ok, (seg[:110] if seg else 'no ramp sentence'))

# C11 internal closure: the memo's own numbers must add up
def grab(pat, default=None):
    m = re.search(pat, NORM)
    return num(m.group(1)) if m else default
issued = grab(r'against \$([\d,]+\.\d\d) carried in the estimate as issued')
net = grab(r'net increase of \$([\d,]+\.\d\d)')
sub = grab(r'corrected Section 2 subtotal is \$([\d,]+\.\d\d)')
constr = grab(r'construction subtotal moves from \$[\d,\.]+ to \$([\d,]+\.\d\d)')
raw = grab(r'the unrounded total is \$([\d,]+\.\d\d)')
allow = grab(r'agreed lump sums of \$([\d,]+\.\d\d)')
bond = grab(r'revised rounded bond figure is \$([\d,]+)')
rowsum = 0.0
for l in T.split('\n'):
    if re.match(r'\s*2\.\d\d \|', l):
        cells = [c.strip() for c in l.split('|')]
        amt = cells[5]
        mm = re.search(r'\$([\d,]+\.\d\d)', amt)
        if mm: rowsum += num(mm.group(1))
        old = re.search(r'was \$([\d,]+\.\d\d)', amt)
        if old: rowsum -= num(old.group(1))
closure = []
if None not in (issued, net, sub):
    closure.append(('subtotal = issued + net', round(issued + net, 2) == round(sub, 2),
                    f'{issued:,.2f} + {net:,.2f} = {issued+net:,.2f} vs stated {sub:,.2f}'))
if None not in (net, rowsum):
    closure.append(('net = sum of table rows', round(rowsum, 2) == round(net, 2),
                    f'rows {rowsum:,.2f} vs stated net {net:,.2f}'))
if None not in (constr, allow, raw):
    closure.append(('unrounded total = construction + allowances', round(constr + allow, 2) == round(raw, 2),
                    f'{constr:,.2f} + {allow:,.2f} = {constr+allow:,.2f} vs stated {raw:,.2f}'))
if None not in (raw, bond):
    import math as _m
    closure.append(('bond = total rounded up to next $1,000', _m.ceil(raw / 1000.0) * 1000 == bond,
                    f'ceil({raw:,.2f}) = {_m.ceil(raw/1000.0)*1000:,.0f} vs stated {bond:,.0f}'))
for name, ok, detail in closure:
    crit('C11 ' + name, ok, detail)

print(f'=== READ {PATH}')
bad = 0
for name, ok, detail in results:
    print(f'  [{"PASS" if ok else "FAIL"}] {name:44s} {detail[:80]}')
    bad += (not ok)
print(f'  --- {len(results)-bad}/{len(results)} pass, {bad} fail')

if MODE in ('audit', 'all'):
    # every measured quantity in the memo must be reconstructible from the corpus
    derived = set()
    for c in R['corrections']:
        derived |= {c['amt'], c['old_amt'], c['price'], c['qty']}
    for k in ('sec2_as_issued','sec2_corrected','net_change','construction_old','construction_new',
              'grand_unrounded_old','grand_unrounded_new','bond_old','bond_new','allowances','excess_vf',
              'outfall_lf','inv_head','inv_stub'):
        derived.add(round(float(R[k]), 2))
    derived |= {round(float(v), 2) for v in R['summary_as_issued'].values()}
    derived |= {round(r['depth'], 2) for r in R['structures']}          # depths from the C-8 schedule
    derived |= {round(float(v['ext']), 2) for v in R['sec2_lines'].values()}   # every Section 2 extension
    derived |= {round(float(v['qty']), 2) for v in R['sec2_lines'].values() if isinstance(v['qty'], (int, float))}
    derived |= {869.58, 870.0, 686.51, 687.0, 1333.56, 1334.0, 240.0, 2664.0,
                6.4, 10.0, 22.02, 100.0, 0.25, 138.0, 8750.0, 685.0, 6400.0, 4850.0,
                32.0, 0.0, 8.0, 15.0, 6.0, 1.0, 2.0, 3.0, 4.0, 5.0, 7.0, 9.0,
                12.0, 14.0, 350000.0, 150000.0}
    # tokens that are identifiers, not measurements
    ident = set(re.findall(r'\b\d{1,2}\.\d\d\b', NORM))                 # schedule item / section numbers
    ident |= {'2201-03','555-0142','14203','C-3874','1,334','000',
              '4720','210','89103','702','2201','3874','0142','555','305',      # address, phone, licence, SD-305
              '18','24','30','36','42','48','54','60','66','72','84'}           # pipe diameters in the schedule
    allow_nonquantity = {'$1,000','1,000','40.0','60','89203','2026'}
    unexplained = collections.Counter()
    for tok in re.findall(r'\$?\d[\d,]*\.?\d*', NORM):
        raw = tok.rstrip('.,')
        if raw in ident or raw in allow_nonquantity: continue
        v = num(raw)
        if round(v, 2) in derived: continue
        if v.is_integer() and float(v) in derived: continue
        unexplained[raw] += 1
    total = len(set(re.findall(r'\$?\d[\d,]*\.?\d*', NORM)))
    print(f'=== AUDIT  distinct numeric tokens={total}  identifiers={len(ident)}  unexplained={len(unexplained)}')
    for tok, n in sorted(unexplained.items())[:25]:
        print(f'  ? {tok} x{n}')

if MODE == 'mutate':
    sys.exit(1 if bad else 0)
sys.exit(1 if bad else 0)
