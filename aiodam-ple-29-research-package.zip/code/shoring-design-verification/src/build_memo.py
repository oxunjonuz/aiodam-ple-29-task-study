"""Build the Item 048 verification memorandum from the template, with every number interpolated from computed.json."""
from __future__ import annotations

import json
from pathlib import Path

import docx
from docx.shared import Pt

ROOT = Path(__file__).resolve().parent.parent
TEMPLATE = ROOT / "ws" / "Birchwood" / "Thelbridge_Verification_Memo_TEMPLATE_v2.docx"
OUT = ROOT / "out" / "Thelbridge_Verification_Memo_Item048_BlockB.docx"
D = json.loads((ROOT / "computed.json").read_text())

G, RC, TOE, AN, HV, AQ, CN, RD, RED = (D["geom"], D["rev2_check"], D["toe"], D["anchor"], D["heave"],
                                       D["aquifer"], D["consolidation"], D["record"], D["reduced"])


def n2(x):
    return f"{x:.2f}"


def e(x):
    """an elevation: always one decimal"""
    return f"{x:.1f}"


def n1(x):
    """a length in feet: always one decimal"""
    return f"{x:.1f}"


def n(x, nd=2):
    """number with thousands separators and at most nd decimals, trailing zeros kept off"""
    s = f"{x:,.{nd}f}"
    if "." in s:
        s = s.rstrip("0").rstrip(".")
    return s


BODY = []


def h(text):
    BODY.append(("h", text))


def p(text):
    BODY.append(("p", text))


def blank():
    BODY.append(("b", ""))


# ------------------------------------------------------------------ 1. PURPOSE
p(f"This memorandum verifies register Item 048 of the Package A register — the Kesterline Engineering, PC "
  f"support of excavation for the Block B plant-room excavation — on its current revision: Submittal 31-SH-B "
  f"Rev.1, sealed 06/11/2026, as supplemented by Revision 2 dated 07/13/2026 under Kesterline letter "
  f"KE-L-2026-0713. Item 048 was raised on 07/10/2026 and falls due on 07/20/2026. It is verified here against "
  f"the logged groundwater and subsurface conditions of the Package A record.")
p("What is determined: (a) the design basis the current revision applies and whether that basis exists at the "
  "plant-room location; (b) which of the design's checks can be carried forward as they stand and which cannot; "
  "(c) what the excavation this item releases would do to the permanent work already built at Block B; (d) what "
  "has to be produced, and by whom, before the excavation can start; and (e) the disposition and the status the "
  "register item should carry, with the register response recorded under A. Vance dated 07/20/2026.")
blank()

# ------------------------------------------------------------------ 2. DOCUMENTS REVIEWED
h("2.  DOCUMENTS REVIEWED")
for line in [
    "Thelbridge Review Comment and Verification Register — Package A (last updated 07/15/2026), register tab and SCHEDULE tab.",
    "Geotechnical Investigation Report, KGI-2024-0417 Rev.2, Kelbrook Geotechnical, Inc., 02/14/2025 (the GIR).",
    "Boring Logs and Groundwater Monitoring Records B-01 through B-09, Kelbrook Geotechnical, Inc. "
    "(B-04 and B-06 inside the plant-room footprint).",
    "Field Observation Report — Excavation and Groundwater, KGI-FO-2026-0528, 05/28/2026.",
    "Design Basis Memorandum CB-DBM-001 Rev.2, Calloway Braddock Structural Engineers, LLC, 11/14/2025 (the DBM).",
    "Sheet S-101 Rev.4, Foundation Plan, 05/29/2026; Sheet S-201 Rev.4, Foundation Sections and Details, "
    "05/29/2026; Sheet S-102 Rev.2, Basement Levels, Drainage and Joint Layout.",
    "Calculation CB-STR-011, Basement Mat Design; Calculation CB-GEO-004, Block B Driven Pile Design, "
    "sealed 08/22/2025.",
    "Consolidation Test Data D2435, Vantree Materials Testing VMT-2025-0109-CON, 01/09/2025.",
    "Submittal 31-SH-B Rev.1, Block B Plant-Room Support of Excavation Design Calculations, sealed 06/11/2026.",
    "Kesterline Engineering, PC letter KE-L-2026-0713, Revision 2 Engineering Supplement to Submittal 31-SH-B, "
    "07/13/2026.",
    "Submittal 31-DW-A Rev.1, Dewatering and Groundwater Control Plan, 06/04/2025.",
    "Specification Section 31 20 00 Rev.3, Earth Moving, 03/06/2026.",
    "Daily Field Reports 141 through 145, 06/28/2026 to 07/02/2026; Field Leak Report RBC-FLR-2026-011, "
    "07/02/2026; Progress Meeting Minutes No. 26, issued 07/10/2026.",
]:
    p("• " + line)
blank()

# ------------------------------------------------------------------ 3. BASIS OF REVIEW
h("3.  BASIS OF REVIEW")
p("The GIR is the controlling document for soil parameters and groundwater (DBM §9), and the DBM §6.2 governs "
  "the stability checks: the resisting side is taken at 0.9D and the minimum factor of safety for sliding and "
  f"base heave is {n2(HV['fs_min'])}. The GIR requires that the Contractor's dewatering plan and the shoring design, "
  "both delegated designs, together demonstrate an adequate factor of safety against base heave at the planned "
  "subgrade using the confined piezometric head El. 738.0 (GIR §9.4), that downdrag from the still-consolidating "
  "clay be carried as an added axial load (GIR §8.3 and §9.3), and that anything penetrating the clay across the "
  "plant-room footprint be sealed at the aquitard elevation (GIR §9.6).")
p("Basis applied: a check is carried forward only where the demand it was built from is still the demand that "
  "acts. The design is therefore checked against the conditions that will exist when it is built — the Block B "
  "basement comes first, and the plant-room excavation follows beneath it (Sheet S-101 Rev.4) — and not against "
  "the free working grade the calculations were written from. Where a number is my own and not the record's, it "
  "is identified as such in the finding.")
p("Limits of this review, stated plainly: I have not made new borings, new laboratory tests or any independent "
  "site investigation, and I have not carried out a structural design of the plant-room or of the permanent "
  "works. Findings 13, 16, 18 and 20 contain my own arithmetic on the record's parameters; every other number in this "
  "memorandum is taken from, or computed from, a document listed above.")
blank()

# ------------------------------------------------------------------ 4. FINDINGS
h("4.  FINDINGS")

p("Finding 1 — The excavation sits inside the completed Blocks A/B basement, not beneath an open grade. "
  "Sheet S-101 Rev.4 places the plant-room pit between grids H-L / 3-5, inside the continuous basement mat whose "
  "extent is grids B-L / 1-5; in other words the plant-room excavation outline lies inside the extent of the "
  "Blocks A/B basement mat. The same sheet records the mat as continuous, cold joints permitted only at B-2, F-2 "
  f"and K-5, cast 01/12/2026, underside El. {e(G['mat_underside'])} and top El. "
  f"{e(G['mat_top'])}, and states that the excavation is to be performed under a separate work package "
  "following completion of the mat above. Sheet S-201 Rev.4 Detail 1 carries the exterior basement wall to the "
  f"underside of the podium slab at El. {e(G['soffit'])}. The design was written for a pit cut from open grade.")

p(f"Finding 2 — The retained height at the plant-room location is about {n1(G['retained_height'])} ft. "
  f"The working: the basement floor is the top of the mat at El. {e(G['mat_top'])}, and the plant-room subgrade "
  f"is El. {e(G['pit_subgrade'])}, so the ground retained above subgrade is El. {e(G['mat_top'])} less El. "
  f"{e(G['pit_subgrade'])} = {n1(G['retained_height'])} ft. Of that, {n1(G['retained_mat_edge'])} ft is the "
  f"cut edge of the 3.0 ft mat (El. {e(G['mat_top'])} to El. {e(G['mat_underside'])}) and "
  f"{n1(G['retained_clay'])} ft is clay below the mat underside (El. {e(G['mat_underside'])} to El. "
  f"{e(G['pit_subgrade'])}). Measured from the finished floor, which is a bonded topping up to "
  f"{n1(G['topping_max'])} ft thick over the mat (S-102 Rev.2), it is {n1(G['retained_from_finished_floor'])} ft. "
  f"The design adopts H = {n1(G['design_H'])} ft from a ground surface at El. {e(750.0)}, which is "
  f"{n(G['design_over_actual'],2)} times the height that is actually retained here.")

p(f"Finding 3 — The lateral load case of Supplement Section R2.3 cannot be carried forward as the design loading "
  "for this excavation. R2.3 builds the driving load on a free working grade at El. 750.0, a retained height of "
  f"{n1(G['design_H'])} ft, the 250 psf surface surcharge applied at that grade and full hydrostatic pressure "
  f"from El. 742.0 over {n1(RC['water_head'])} ft. That gives {n(RC['P_total_printed'],0)} lb/ft of driving load "
  f"in total, of which {n(RC['P_w_printed'],1)} lb/ft is hydrostatic — {n1(RC['hydrostatic_share_pct'])} per cent "
  f"— and {n(RC['P_soil_printed'],1)} lb/ft is the layered effective-stress soil component under the same free "
  "surface. None of the three premises holds at the plant-room location: the surface at El. 750.0 is the podium, "
  "not a construction grade; the retained height is "
  f"{n1(G['retained_height'])} ft, not {n1(G['design_H'])} ft; and there is no free water column behind the wall. "
  "R2.4, R2.5, R2.6 and R2.7 all take their demand from R2.3.")

p("Finding 4 — No free water surface at El. 742.0 can act behind the sheet-pile wall at the plant-room location. "
  "The wall stands inside a drained, roofed basement beneath a 3 ft mat. Sheet S-102 Rev.2 carries the basement "
  f"floor over the same grids with a bonded topping and low-point drains — drain C-4 at invert El. "
  f"{e(734.5)} in Zone 1 (grids B-G) and drain K-6 at invert El. 734.7 in Zone 2 (grids H-L, the "
  "zone over the pit). Daily Field Reports 141 to 145, 06/28/2026 to 07/02/2026, record the basement floor as "
  "finished, Zone 2 — the zone over the pit — with drain K-6 and its slab depression dry on each of the five "
  "days, and the perimeter walls in both zones recorded dry at the base of wall. The GIR §6.2 adds the physical point: the upper sand is essentially absent beneath the "
  "Block B footprint, where the top of the clay is at existing grade under a thin topsoil mantle, so there is no "
  "stratum at El. 742.0 to hold a phreatic surface behind this wall in the first place. Whatever pore pressure "
  "acts on the retained clay is what the relief wells leave in the aquifer below, not a phreatic surface 16 ft "
  "above subgrade. The C-4 seepage of 07/01/2026 is a separate matter: it is at Zone 1, grids B-G, outside the "
  "pit footprint, and is carried under register Item 056; it is not a free water surface at El. 742.0 at the "
  "plant room.")

p("Finding 5 — The 250 psf construction surcharge is not the loading that acts behind the wall at the plant-room "
  "location. Rev.1 §4.1 applies 250 psf of construction traffic, laydown and light equipment at a free ground "
  f"surface at El. 750.0 (Rev.1 §4.2: p_q = Ka · 250 = 83 psf). The surface at that elevation is the podium. What "
  "bears on the ground behind the wall is the basement mat and the structure it carries, with podium columns "
  "landing on pile caps at the grid intersections the pit outline encloses — S-101 Rev.4 lays the Block B pile "
  "group out on grids B-L / 1-5 and S-201 Rev.4 Detail 2/3 shows the typical pile cap with its top at El. 734.5, "
  "cast into the mat. Rev.2 keeps §4.1 and §4.2 in force without modification, so the surcharge is still applied "
  "at a surface that is not there.")

p(f"Finding 6 — The tieback anchor row at El. {e(AN['row'])} lies inside the completed basement. The basement "
  f"floor is the top of the mat at El. {e(G['mat_top'])} and the podium soffit is at El. {e(G['soffit'])} "
  f"(S-201 Rev.4 Detail 1), so the anchor horizon sits {n1(G['anchor_above_floor'])} ft above the floor and "
  f"{n1(G['anchor_below_soffit'])} ft below the soffit, within the occupied basement volume — not {n1(G['row_below_grade'])} ft below "
  "an open working grade. Rev.2 R2.5 keeps the row unchanged at El. "
  f"{e(AN['row'])} with 6 ft centres and 20 degrees below horizontal.")

p(f"Finding 7 — A 30.5 ft sheet pile cannot be driven at the plant-room location with the plant the design relies "
  f"on. R2.4 lengthens the sheets to {n1(G['sheet_len'])} ft from El. 750.0 to a tip at El. {e(TOE['tip'])} and "
  "states that the ICE 44B vibratory hammer with a Delmag D19 finish of Rev.1 §11.3 is adequate for the revised "
  f"tip. The headroom between the basement floor at El. {e(G['mat_top'])} and the podium soffit at El. "
  f"{e(G['soffit'])} is {n1(G['headroom'])} ft. The sheets exceed that headroom by {n1(G['headroom_deficit'])} "
  f"ft, and so does Rev.1's own {n1(G['rev1_mill_length'])} ft single mill length; Rev.1 §13.1 item 3 drives "
  "the sheets from working grade El. 750.0, which at this location is under the podium slab.")

p(f"Finding 8 — The excavation undermines the Block B pile caps at underside El. {e(G['cap_underside'])}. "
  f"Sheet S-201 Rev.4 Detail 2 gives the pile cap underside at El. {e(G['cap_underside'])} with the pile cut-off "
  f"at El. {e(732.5)} and the cap top at El. {e(G['cap_underside'] + G['cap_thickness_ft'])}, "
  f"the cap being {n1(G['cap_thickness_ft'])} ft thick and cast into the mat; Detail 5 thickens the mat "
  f"underside to El. {e(G['thickened_underside'])} at columns. The plant-room subgrade is El. "
  f"{e(G['pit_subgrade'])}, which is {n1(G['cut_below_cap'])} ft below the cap underside and "
  f"{n1(G['cut_below_thickened'])} ft below the thickened underside, inside the mat footprint. The cut "
  "therefore removes bearing from beneath caps that are cast into the mat.")

p("Finding 9 — No temporary support of the basement mat and the pile caps during the excavation is designed in "
  "Rev.1 or Rev.2. Rev.1 §1.5 states that the delegated design does not extend to any permanent below-grade "
  "structure, waterproofing or permanent groundwater control, so no party has taken the question of holding the "
  "mat and the caps while the ground beneath them is removed. Rev.2 supersedes only Rev.1 Sections "
  f"{RD['superseded']} and leaves {RD['remains']} in force; none of the superseded or retained sections adds "
  "such a support, and the §13.1 sequence — drive, excavate, tie back, excavate to subgrade, build the "
  "plant-room mat and walls — contains no step that supports the mat or the caps.")

p("Finding 10 — No opening in the continuous basement mat over the plant-room pit is shown in the project "
  "record. S-101 Rev.4 records the mat as continuous across grids B-L / 1-5 with construction joints permitted "
  "at B-2, F-2 and K-5 only, and refers the plant-room boundary section to S-201/4; S-201 Rev.4 Detail 4 is the "
  "wall-to-mat construction joint and waterstop detail, not an opening; CB-STR-011 models a continuous mat. "
  "Recording this separately, because it is a different observation: the cross-reference S-101 Rev.4 makes to "
  "S-201/4 for a plant-room boundary section and cutoff wall interface is not met by S-201 Rev.4, whose Detail 4 "
  "holds no such section. A cross-reference that does not resolve is not the same thing as an opening, and "
  "neither is shown.")

p("Finding 11 — Which checks can be carried forward, and which cannot. The toe-embedment, anchor-load, "
  "sheet-flexure and deflection checks of Supplement Sections R2.4 to R2.7 cannot be carried forward because "
  "each takes its demand from the R2.3 lateral load case, which is built on a working grade and a hydrostatic "
  "column that do not exist at the plant-room location: R2.4 compares the passive moment against the R2.3 "
  "driving moment, R2.5 takes the anchor load as the residual after the passive credit against the R2.3 total, "
  "R2.6 is the span moment under the R2.3 pressure diagram and R2.7 is re-estimated under the same loading. What "
  "can be carried forward as it stands is what does not depend on that load case: the section and material "
  "capacities of the PZ-35 Grade 50 sheet (Mallow = 121 kip-ft/ft, Rev.1 §11.2 and R2.6) and the wale check of "
  "Rev.1 §11.4; and the base-heave formula and arithmetic of R2.2, which I reproduce in Finding 15 — but not its "
  "premise. Two further points against the supersession matrix itself: Rev.2 Table 1 keeps Rev.1 Section 8, "
  "global overturning and sliding, in force, yet §8 is built on the Rev.1 §5 driving force of 17,844 lb/ft from "
  "the free grade (its own sliding number without the tieback is 0.28), so §8 does not stand either; and Rev.2 "
  "also leaves §4.1 and §4.2 in force, which are the free-surface surcharge findings 5 and 3 reject.")

p(f"Finding 12 — The undrained shear strength of 1,400 psf used in the toe check is not supported by the project "
  "record. Rev.1 §3.2 cites the geotechnical report Section 6 and a Table 6.2 for the value; the report contains "
  f"Tables {', '.join(RD['gir_tables'][:-1])} and {RD['gir_tables'][-1]} and no Table 6.2, and its Section 6.3 "
  f"reports Su = {n(RD['gir_su'][0],0)} to {n(RD['gir_su'][1],0)} psf for the CL aquitard. DBM §9 makes the "
  "report controlling for all soil parameters, and R2.4 carries the 1,400 psf forward from Rev.1 §3.2 unchanged.")

p(f"Finding 13 — The sheet-pile toe embedment does not reach the 1.50 factor of safety when checked on the "
  "undrained strength the geotechnical report reports. On the R2.4 formulation with D = "
  f"{n1(TOE['D'])} ft and the driving moment of {n(TOE['M_D'],0)} ft-lb/ft, pn = 4Su - "
  f"{n(TOE['sigma_v0'],0)} psf gives: at Su = {n(RD['gir_su'][1],0)} psf, pn = "
  f"{n(TOE['cases']['1100']['pn'],0)} psf, Pp = {n(TOE['cases']['1100']['Pp'],0)} lb/ft, MR = "
  f"{n(TOE['cases']['1100']['MR'],0)} ft-lb/ft and FStoe = {n2(TOE['cases']['1100']['FS'])}; at Su = "
  f"{n(RD['gir_su'][0],0)} psf, pn = {n(TOE['cases']['900']['pn'],0)} psf, Pp = "
  f"{n(TOE['cases']['900']['Pp'],0)} lb/ft, MR = {n(TOE['cases']['900']['MR'],0)} ft-lb/ft and FStoe = "
  f"{n2(TOE['cases']['900']['FS'])}. The check as written needs Su of {n(TOE['su_required'],0)} psf to hold "
  f"1.50 — above the {n(RD['gir_su'][1],0)} psf the report reports. My computation, on the submittal's own "
  "formulation.")

p("Finding 14 — The tieback bond zone lies within the CL clay aquitard rather than the SW-GW stratum whose bond "
  f"stress is adopted. At the row El. {e(AN['row'])}, at {n(AN['inclination'],0)} degrees below horizontal, a "
  f"{n1(AN['free_length'])} ft free length and a {n1(AN['bond_length'])} ft bond length put the bond zone "
  f"between El. {n2(AN['bond_top'])} and El. {n2(AN['bond_bot'])} — inside the clay aquitard, which runs El. "
  f"{e(AN['clay_top'])} to El. {e(AN['clay_bottom'])}, and {n1(AN['above_aquifer'])} ft above the top of "
  "the aquifer at El. "
  f"{e(AN['aquifer_top'])}. Rev.1 §10.1 places the bond zone below El. {e(AN['claimed_below'])}, which the "
  f"geometry cannot reach: {n1(AN['free_length'] + AN['bond_length'])} ft at {n(AN['inclination'],0)} degrees "
  f"falls {n1(AN['fall'])} ft from the anchor, and Rev.1 §10.4 takes 20 psi of bond stress for pressure-grouted dense sand and "
  "gravel. Rev.2 R2.5 keeps the same 20 psi on the same geometry.")

p(f"Finding 15 — The base-heave check stands only on a drawdown that no sealed design demonstrates. The "
  f"arithmetic of R2.2 is right: a {n1(HV['plug'])} ft clay plug at 120 pcf weighs W = {n(HV['W'],0)} psf, "
  f"0.9W = {n(HV['W09'],0)} psf; at the controlled head El. {e(726.5)} the uplift is u = "
  f"{n(HV['u_at_hold'],1)} psf and FSheave = {n2(HV['FS_at_hold'])}, above the {n2(HV['fs_min'])} minimum. "
  f"Without relief-well pumping the base-heave factor of safety is about {n2(HV['FS_unpumped'])}: the same plug "
  f"faces {n(HV['u_unpumped'],1)} psf of uplift, the unpumped confined head at El. {e(738.0)}, against the "
  f"{n(HV['W09'],0)} psf resisting. But no sealed "
  "dewatering design covering the Block B relief wells exists in the project record: Submittal 31-DW-A Rev.1 "
  "Article 1.2 addresses the Block A basement only, states that no interior drawdown system is proposed for "
  "Block B, and its Part 4 says in terms that nothing in it relieves the confined piezometric head and that it "
  "shall not be relied upon by any design that assumes a reduction of that head below El. 738.0. Register Items "
  "005 and 006, both closed with comment, record the same position; Item 006 records the Block B strategy on file "
  "as a cutoff wall toed at El. 722.0 with no active drawdown planned. R2.1's four relief wells are a proposal, "
  "not a sealed design.")

p(f"Finding 16 — The piezometer stop-work trigger at El. {e(727.0)} does not satisfy the base-heave "
  f"minimum the design basis memorandum requires. At El. {e(727.0)} the uplift is {n(HV['u_at_trigger'],1)} psf "
  f"against 0.9W of {n(HV['W09'],0)} psf, a factor of {n2(HV['FS_at_trigger'])}, below the {n2(HV['fs_min'])} of "
  f"DBM §6.2; on the same plug the 1.50 line is lost above El. {e(HV['head_at_FS_min'])}. A trigger that "
  "permits 1.48 is not a trigger that protects the minimum.")

p("Finding 17 — No driveability analysis supports the revised sheet-pile tip elevation of El. "
  f"{e(TOE['tip'])}. R2.4 asserts that the Rev.1 §11.3 equipment is adequate for the deeper tip; Rev.1 §11.3 "
  f"records a minimum tip of El. {e(750.0 - 28.0)}, a {n1(G['rev1_mill_length'])} ft single mill length and 30 "
  "blows per foot anticipated in the clay, against a stratum logged at refusal — the GIR §6.4 records SPT values "
  "at refusal, N of 50 blows per 6 inches or more, throughout the SW-GW below El. 720.0, and R2.4 puts the tip "
  f"{n1(720.0 - TOE['tip'])} ft into it.")

p(f"Finding 18 — What the excavation and the depressurization would do to the permanent work already built at "
  "Block B. Holding the confined head at El. 726.5 is a drawdown of "
  f"{n1(AQ['drawdown'])} ft: a pore-pressure reduction of {n(AQ['du_base'],1)} psf at the base of the clay and "
  "nil at its top, where the shallow phreatic surface is unchanged. Total stress in the aquitard does not change, "
  "so that reduction lands on the vertical effective stress: the effective stress rises by the increment at every "
  "level of the clay, most at its base, and the clay beneath the completed Block B work — beneath the pile caps, "
  "the mat and the pile group that passes through it — is loaded by it. On the record's own parameters the "
  f"increment is not marginal: the in-situ effective stress is {n(AQ['sigma0'],0)} psf and the preconsolidation "
  f"pressure {n(AQ['sigma_p'],0)} psf, a margin of {n(AQ['preconsolidation_margin'],0)} psf, and the increment "
  f"at the base of the clay is {n2(AQ['base_exceeds_margin_by'])} times that margin, exceeding it over all but "
  f"the top {n(AQ['depth_from_clay_top_where_increment_exceeds_margin'],2)} ft of the stratum. Its time scale is "
  f"not the pumping window: on the report's own coefficient of consolidation (cv = {CN['cv_cm2s']:.4f} cm2/s, the "
  f"lower end of the {CN['cv_band_lo']:.4f} to {CN['cv_band_hi']:.4f} cm2/s band the laboratory reports) and a drainage path of {n1(CN['Hdr'])} ft, t50 is {n(CN['t50_days'],0)} days and "
  f"t90 is {n(CN['t90_days'],0)} days, about {n(CN['t90_years'],1)} years — my computation — so the aquitard "
  "takes the increment as a loading over the months of pumping and gives back only what re-expansion returns when "
  "the wells stop. And the effect of the excavation and of the aquifer depressurization on the Block B piles, pile "
  "caps and basement mat has not been evaluated by any party: Rev.1 §1.5 disclaims the permanent work; the GIR "
  "§8.3 and §9.3 require the downdrag of the still-consolidating clay as an added axial load; and CB-GEO-004 "
  f"counts the fill and clay interval the other way, as resistance — Qs,upper = {n(RD['pile_Qs_upper'],0)} kips "
  f"of shaft resistance through the fill and clay, inside the {n(RD['pile_Qult'],0)} kips ultimate, against "
  f"{n(RD['pile_Qservice'],0)} kips of service load — which is the sign "
  "that matters when the clay settles past the pile. That question is open under register Item 049 and is not "
  "resolved here; what is resolved here is that the excavation this item releases is planned over the same clay "
  "with no party having assessed it.")

p("Finding 19 — Specification Section 31\u00a050\u00a000, cited as the authority for the delegated shoring design, is not "
  "in the project record. Rev.2 §1 cites Specification Section 31 20 00 Rev.3 as governing; 31 20 00 §1.1.B.2 "
  "refers excavation support and protection out to Section 31\u00a050\u00a000; the Package A record holds Sections 31\u00a020\u00a000, 03 20 00, 03 30 00 and 09 21 16, and not 31\u00a050\u00a000. The design cannot be verified against a specification "
  "the record does not contain.")

p(f"Finding 20 — What my own arithmetic says about the size of the load case, offered as context and not as a "
  f"design case. Take the {n1(G['retained_height'])} ft that is actually retained as drained clay at Ka = "
  f"{n(RED['Ka_clay'])} and 120 pcf, with no surcharge and no free water: the horizontal load is "
  f"{n(RED['P_bound'],0)} lb/ft, {n1(RED['share_of_design_pct'])} per cent of the {n(RC['P_total_printed'],0)} "
  "lb/ft the design carries. The point is not that a smaller wall would do; it is that the design demand is an "
  "artefact of the free-grade premise rather than an envelope over the conditions that exist.")

p("Finding 21 — What has to be produced before the excavation can start, and who has to produce it. Two "
  "deliverables, each sealed by its own designer:")
p("(a) The revised, re-sealed shoring submittal 31-SH-B, produced by Kesterline Engineering, PC as delegated "
  "designer and transmitted to Thelbridge through Rowan Bay Constructors, Inc. as Contractor. It must rebuild the "
  "lateral load case on the conditions that exist, design the support of the mat and the pile caps, make the "
  "sheet and the driving plant compatible with the 14.0 ft of headroom and with the record showing no opening in "
  "the mat, correct the bond zone and the bond stress it relies on, and check the toe on the strength the "
  "geotechnical report reports.")
p("(b) A separately sealed Block B dewatering and groundwater-control plan under Specification Section 31 23 19, "
  "produced by Rowan Bay Constructors, Inc. with its dewatering designer, demonstrating the base-heave factor at "
  "El. 726.0 with the relief wells R2.1 proposes. The plan on file, Submittal 31-DW-A Rev.1, is Block A only and "
  "says so in Article 1.2.")
p("In addition, on my reading of the record and not as a substitute for either item above: the Engineer of "
  "Record's design for whatever opening is made through the completed mat and for the support of the mat and caps "
  "while the ground beneath them is removed; and the issue of Specification Section 31\u00a050\u00a000, or its removal as a "
  "citation.")
blank()

# ------------------------------------------------------------------ 5. CONCLUSION AND RECOMMENDATION
h("5.  CONCLUSION AND RECOMMENDATION")
p("Determination. Register Item 048 is not verified on the revision submitted. The design's governing lateral load "
  "case describes an excavation that does not exist at the plant-room location — a free grade at El. 750.0 with "
  f"{n1(G['design_H'])} ft retained, a surface surcharge at that grade and a free water column from El. 742.0 — "
  f"where the record shows about {n1(G['retained_height'])} ft retained beneath a completed, drained basement, "
  "no opening through the mat, and pile caps the cut would undermine. The checks that follow from that load case "
  "cannot be carried forward; the one independent check, base heave, holds only on a drawdown that no sealed "
  "dewatering design in the record demonstrates, and its stop-work trigger sits below the minimum the design "
  "basis memorandum requires. On the strength the geotechnical report actually reports, the toe embedment falls "
  "to 0.81 and 0.31 against the 1.50 required.")
p("Disposition for the register item: NOT VERIFIED. Register Item 048 is not verified and is not closed. Register "
  "Item 048 carries the status Open.")
p("Register response, to be recorded under A. Vance, dated 07/20/2026 (Response / Disposition field):")
p("“Item 048 — NOT VERIFIED. Submittal 31-SH-B Rev.1 as supplemented by Rev.2 (KE-L-2026-0713) is not verified "
  "against the logged groundwater and subsurface conditions. The R2.3 lateral load case is built on a free grade "
  "at El. 750.0 with 24 ft retained, a surface surcharge at that grade and hydrostatic pressure from El. 742.0, "
  "none of which exists at the plant-room location, where the excavation follows completion of the continuous "
  "basement mat (S-101 Rev.4) and retains about 8.5 ft beneath the basement floor at El. 734.5. R2.4 to R2.7 "
  "cannot be carried forward. The 1,400 psf undrained strength is not supported (GIR §6.3 reports 900 to 1,100 "
  "psf). The base-heave check depends on a relief-well drawdown for which no sealed design is in the record, and "
  "the El. 727.0 trigger gives 1.48 against the DBM §6.2 minimum of 1.50. Required before re-submittal: revised, "
  "re-sealed 31-SH-B from Kesterline Engineering, PC through Rowan Bay Constructors, Inc.; separately sealed "
  "Block B dewatering and groundwater-control plan under Section 31 23 19 from Rowan Bay Constructors, Inc. with "
  "its dewatering designer. Status: Open. Response by A. Vance, Thelbridge Project Management Services, "
  "07/20/2026.”")
p("Effect on the 08/10/2026 excavation start: the 08/10/2026 Block B plant-room excavation is not released on the "
  "disposition reached. The register SCHEDULE conditions that date on closure of Items 048 and 049 and on the "
  "groundwater component of Item 056, and Item 048 is not closed. No Thelbridge written verification exists for "
  "this work, and Sheet S-101 Rev.4 itself records that it does not release excavation for construction.")
p("Recommended action: return Submittal 31-SH-B to Kesterline Engineering, PC through Rowan Bay Constructors, "
  "Inc. with this memorandum, and require the two sealed deliverables of Finding 21 before the excavation is "
  "rescheduled; carry the aquifer-drawdown question raised in Finding 18 into Item 049, where the pile capacity "
  "under the still-consolidating clay is already open.")

# ------------------------------------------------------------------ write it
doc = docx.Document(str(TEMPLATE))
paras = doc.paragraphs

# header values, keeping the bold labels
fill = {3: "Rachel Marlbeck, University Program Director — Thornbury State University",
        4: "A. Vance, Project Engineer (Structural/Geotechnical) — Owner's Representative, Thelbridge Project "
           "Management Services",
        5: "07/20/2026",
        6: "Verification of Register Item 048 — Block B plant-room support of excavation, Submittal 31-SH-B Rev.1 "
           "as supplemented by Rev.2 (Kesterline letter KE-L-2026-0713)"}
for i, value in fill.items():
    runs = paras[i].runs
    runs[1].text = "\t" + value

# everything from paragraph 8 on is replaced by BODY, keeping the five section headings of the form
headings = ["1.  PURPOSE", "2.  DOCUMENTS REVIEWED", "3.  BASIS OF REVIEW", "4.  FINDINGS",
            "5.  CONCLUSION AND RECOMMENDATION"]
body_anchor = paras[7]._p          # "1.  PURPOSE"
tail = paras[-1]._p
# remove the template's instruction/spacer/signature paragraphs
for par in paras[8:]:
    par._p.getparent().remove(par._p)

from docx.oxml.ns import qn
from docx.oxml import OxmlElement
from docx.text.paragraph import Paragraph


def add_after(anchor, text, kind):
    new_p = OxmlElement("w:p")
    anchor.addnext(new_p)
    par = Paragraph(new_p, doc.paragraphs[0]._parent)
    run = par.add_run(text)
    run.font.name = "Calibri"
    if kind == "h":
        run.bold = True
        run.font.size = Pt(10.5)
        par.paragraph_format.space_before = Pt(10)
        par.paragraph_format.space_after = Pt(4)
    elif kind == "p":
        run.font.size = Pt(9.5)
        par.paragraph_format.space_after = Pt(4)
        par.paragraph_format.alignment = 3  # justify
    else:
        run.font.size = Pt(9.5)
    return new_p


anchor = body_anchor
current = None
for kind, text in BODY:
    if kind == "h":
        current = text
    anchor = add_after(anchor, text, kind)

# signature block
for text, bold in [("A. Vance", True),
                   ("Project Engineer (Structural/Geotechnical) — Owner's Representative", False),
                   ("Thelbridge Project Management Services", False),
                   ("Date: 07/20/2026", False)]:
    anchor = add_after(anchor, text, "h" if bold else "b")

OUT.parent.mkdir(parents=True, exist_ok=True)
doc.save(str(OUT))
print("wrote", OUT, OUT.stat().st_size, "bytes")
