"""Reading the Package A record: every value the memo rests on is pulled from the files, not typed here.

The corpus is the task's own environment tree (Birchwood/PackageA + the Kesterline Rev.2 overlay).
Text comes from pdftotext (no -layout) for the prose documents and from python-docx / openpyxl for
the office files.  Each reader raises if it cannot find what the memo claims, so a silent change in
the corpus cannot quietly become a silent change in the memo.
"""
from __future__ import annotations

import re
import subprocess
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
WS = ROOT / "ws" / "Birchwood"
A = WS / "PackageA"

_cache: dict = {}


def pdf_text(path: Path, layout: bool = False) -> str:
    path = Path(path)
    key = (path, layout)
    if key in _cache:
        return _cache[key]
    with tempfile.NamedTemporaryFile(suffix=".txt", delete=False) as fh:
        out = Path(fh.name)
    subprocess.run(["pdftotext"] + (["-layout"] if layout else []) + [str(path), str(out)], check=True)
    text = re.sub(r"[\x00-\x08\x0b-\x1f\x7f]", "", out.read_text(errors="replace"))
    text = text.replace("\u2212", "-").replace("\u2013", "-").replace("\u2014", "-")
    out.unlink(missing_ok=True)
    _cache[key] = text
    return text


def docx_text(path: Path) -> str:
    import docx

    d = docx.Document(str(path))
    parts = [p.text for p in d.paragraphs]
    for t in d.tables:
        for r in t.rows:
            parts.append("\t".join(c.text for c in r.cells))
    return "\n".join(parts)


def xlsx_rows(path: Path) -> dict[str, list[tuple]]:
    import openpyxl

    wb = openpyxl.load_workbook(str(path), data_only=True)
    return {n: list(wb[n].iter_rows(values_only=True)) for n in wb.sheetnames}


def need(pattern: str, text: str, what: str, flags: int = 0) -> re.Match:
    m = re.search(pattern, text, flags)
    if not m:
        raise LookupError(f"record reader: cannot find {what!r} in the corpus (pattern {pattern!r})")
    return m


def num(s: str) -> float:
    return float(s.replace(",", "").replace("'", "").strip().rstrip("."))


# ------------------------------------------------------------------ drawings
def s101() -> dict:
    t = pdf_text(A / "02_Structural/Drawings/S-101_Foundation_Plan_Rev4.pdf")
    flat = re.sub(r"\s+", " ", t)
    d = {}
    d["mat_underside"] = num(need(r"Underside of mat: El\. ([\d.]+)\.", flat, "mat underside").group(1))
    d["mat_thickness"] = num(need(r"Thickness: ([\d.]+) ft\. Top of mat", flat, "mat thickness").group(1))
    d["mat_top"] = num(need(r"Top of mat: El\. ([\d.]+)\.", flat, "mat top").group(1))
    d["pit_subgrade"] = num(need(r"Subgrade elevation: El\. ([\d.]+)\.", flat, "pit subgrade").group(1))
    d["depth_below_grade"] = num(need(r"Excavation depth below existing grade: (\d+) ft", flat, "24 ft depth").group(1))
    d["pit_grids"] = need(r"between grids (H[--]L / \d+[--]\d+)", flat, "pit grids").group(1).replace("-", "-")
    d["mat_grids"] = need(r"Continuous mat beneath Block A and Block B footprints, grids (B[--]L / \d+[--]\d+)",
                          flat, "mat grids").group(1).replace("-", "-")
    d["mat_joints"] = need(r"Construction joints: permitted at grid lines ([^.]+?) only", flat, "mat joints").group(1)
    d["mat_pour"] = need(r"Mat pour dated ([\d/]+)", flat, "mat pour date").group(1)
    d["pile_count"] = int(need(r"Pile count: (\d+)\.", flat, "pile count").group(1))
    d["pile_grids"] = need(r"Pile layout: see dot pattern on Block B plan \(grids ([^)]+)\)", flat, "pile grids").group(1)
    d["follow_mat"] = "following completion of the mat above" in flat
    d["not_release"] = "does not release excavation for construction" in flat
    d["start"] = need(r"Excavation scheduled start: ([\d/]+)", flat, "scheduled start").group(1)
    return d


def s201() -> dict:
    t = pdf_text(A / "02_Structural/Drawings/S-201_Foundation_Sections_Details_Rev4.pdf")
    flat = re.sub(r"\s+", " ", t)
    d = {}
    d["soffit"] = num(need(r"Wall extends to underside of podium slab at El\. ([\d.]+)", flat, "podium soffit").group(1))
    d["cap_underside"] = num(need(r"Underside of pile cap \. \. \. El\. ([\d.]+)", flat, "cap underside").group(1))
    d["cap_top"] = num(need(r"Top of pile cap \. \. \. El\. ([\d.]+)", flat, "cap top").group(1))
    d["cutoff"] = num(need(r"Cutoff elevation of pile \. \. \. El\. ([\d.]+)", flat, "pile cutoff").group(1))
    d["cap_thickness"] = "-".join(need(r"Pile cap thickness \. \. \. (\d+)'-(\d+)\"", flat, "cap thickness").groups())
    _a, _b = d["cap_thickness"].split("-")
    d["cap_thickness_ft"] = num(_a) + num(_b) / 12.0
    d["thickened_underside"] = num(need(r"thickened underside El\. ([\d.]+)", flat, "Detail 5 underside").group(1))
    d["wall_thickness"] = "-".join(need(r"Exterior basement wall thickness \. \. \. (\d+)'-(\d+)\"", flat, "wall thickness").groups())
    return d


def s102() -> dict:
    t = pdf_text(A / "02_Structural/Drawings/S-102_Basement_Levels_Drainage_Joint_Layout.pdf")
    flat = re.sub(r"\s+", " ", t)
    d = {}
    d["c4_invert"] = num(need(r"C-4 \(invert El\. ([\d.]+)\)", flat, "C-4 invert").group(1))
    d["k6_invert"] = num(need(r"K-6 \(invert El\. ([\d.]+)\)", flat, "K-6 invert").group(1))
    d["topping_max"] = num(need(r"topping thickness varies from 0\.0 ft at each drain to ([\d.]+)", flat, "topping").group(1))
    d["zone2_drain"] = need(r"(Grids H[--]L) \| 1% fall to Drain K-6", flat, "Zone 2 drain").group(1).replace("-", "-")
    d["zone1_drain"] = need(r"(Grids B[--]G) \| 1% fall to Drain C-4", flat, "Zone 1 drain").group(1).replace("-", "-")
    d["finish_note"] = "bonded topping" in flat
    return d


# ------------------------------------------------------------------ geotech / basis
def gir() -> dict:
    t = pdf_text(A / "01_Geotech/Geotechnical_Investigation_Report_PkgA_Rev2.pdf")
    flat = re.sub(r"\s+", " ", t)
    d = {}
    d["su"] = [num(x) for x in need(r"Su = ([\d,]+) to ([\d,]+) psf", flat, "su range").groups()]
    d["clay_top"] = num(need(r"extending from El\. ([\d.]+) down to El\. ([\d.]+)", flat, "clay top").group(1))
    d["clay_bottom"] = num(need(r"extending from El\. ([\d.]+) down to El\. ([\d.]+)", flat, "clay bottom").group(2))
    d["clay_thickness"] = num(need(r"Stratum 2 is an ([\d.]+)-ft-thick", flat, "clay thickness").group(1))
    d["gwt"] = num(need(r"The design water table for the Package A project is set at El\. ([\d.]+)", flat, "design GWT").group(1))
    d["confined_head"] = num(need(r"is at El\. ([\d.]+) - essentially at the top of the clay", flat, "confined head").group(1))
    d["aquifer_top"] = 720.0 if "SW-GW) below El. 720.0" in flat else None
    d["sand_absent_blockb"] = "ranges from essentially 0 ft beneath the low-lying Block B footprint" in flat
    d["tables"] = sorted(set(re.findall(r"Table (\d-\d)", flat)))
    d["has_table_6_2"] = bool(re.search(r"Table 6\.2", flat))
    d["plug_residual"] = num(need(r"clay-plug residual thickness of only ([\d.]+) ft", flat, "plug thickness").group(1))
    d["downdrag_sections"] = ("8.3" in flat) and ("9.3" in flat)
    d["steel_toe"] = need(r"as contemplated in Geotechnical Report Section ([\d.]+)", flat, "9.4 ref") if False else None
    d["permeability"] = need(r"order of 10[--](\d+) cm/s", flat, "clay permeability").group(1)
    d["refusal"] = "N ≥ 50 blows per 6 inches" in flat
    d["dewat_and_shoring"] = "must together demonstrate an adequate factor of safety against base heave" in flat
    d["seal_aquitard"] = "must be sealed at the aquitard elevation" in flat
    return d


def dbm() -> dict:
    t = pdf_text(A / "02_Structural/Design_Basis_Memorandum_Rev2.pdf")
    flat = re.sub(r"\s+", " ", t)
    d = {}
    d["fs_min"] = num(need(r"minimum ([\d.]+) for sliding and base heave", flat, "FS minimum").group(1))
    d["ninetenths"] = "is taken at 0.9D, with an explicit factor of safety stated" in flat
    d["report_controls"] = "controlling document for all soil parameters" in flat
    d["sigma0_mid"] = num(need(r"σ′0 = ([\d,]+) psf", flat, "sigma'0").group(1))
    d["sigma_p"] = num(need(r"σ′p = ([\d,]+) psf", flat, "sigma'p").group(1))
    d["Cc"] = num(need(r"Cc = ([\d.]+)", flat, "Cc").group(1))
    d["e0"] = num(need(r"e0 = ([\d.]+)", flat, "e0").group(1))
    d["settle_tol"] = num(need(r"Article 3\.6 \(total ([\d.]+) in", flat, "settlement tolerance").group(1))
    return d


def consolidation() -> dict:
    rows = xlsx_rows(A / "01_Geotech/Consolidation_Test_Data_D2435.xlsx")["Summary — Design Params"]
    d = {}
    for r in rows:
        if not r or not r[0]:
            continue
        k = str(r[0]).strip()
        v = r[1]
        if k.startswith("Coefficient of consolidati"):
            m = re.search(r"(\d) to (\d) × 10", str(v))
            d["cv_cm2s"] = float(m.group(1)) * 1e-4  # conservative (low) end of the 4-5 x 10^-4 band
            d["cv_hi"] = float(m.group(2)) * 1e-4
        if k.startswith("Layer thickness"):
            d["H"] = float(v)
        if k.startswith("Maximum drainage path"):
            d["Hdr"] = float(v)
        if k.startswith("In-situ vertical effective"):
            d["sigma0"] = float(v)
        if k.startswith("Preconsolidation pressure"):
            d["sigma_p"] = float(v)
        if k.startswith("Initial in-situ void ratio"):
            d["e0"] = float(v)
        if k.startswith("Compression index"):
            d["Cc"] = float(v)
        if k.startswith("Recompression"):
            d["Cr"] = float(v)
    if "cv_cm2s" not in d:
        # the band is printed as "4 to 5 × 10⁻⁴"
        for r in rows:
            if r and r[0] and str(r[0]).startswith("Coefficient"):
                m = re.search(r"(\d) to (\d) × 10-(\d)", str(r[1]))
                d["cv_cm2s"] = float(m.group(1)) * 10 ** (-int(m.group(3)))
                d["cv_hi"] = float(m.group(2)) * 10 ** (-int(m.group(3)))
    return d


def pile_calc() -> dict:
    sh = xlsx_rows(A / "02_Structural/Calcs/CB-GEO-004_Pile_Design_BlockB.xlsx")
    d = {}
    for r in sh["CAPACITY CALCULATION"]:
        if r and r[0] and str(r[0]).startswith("Contribution, Qs,B"):
            d["Qs_clay"] = float(r[2])
        if r and r[0] and str(r[0]).startswith("Sub-interval B"):
            d["clay_interval"] = str(r[2])
        if r and r[0] and str(r[0]).startswith("Total upper shaft"):
            d["Qs_upper"] = float(r[2])
        if r and r[0] and str(r[0]).startswith("Average undrained shear"):
            d["su_avg"] = float(r[2])
    for r in sh["SUMMARY"]:
        if r and r[0] and str(r[0]).startswith("Ultimate axial capacity"):
            d["Qult"] = float(r[2])
        if r and r[0] and str(r[0]).startswith("Allowable axial capacity"):
            d["Qall"] = float(r[2])
        if r and r[0] and str(r[0]).startswith("Design service load"):
            d["Qservice"] = float(r[2])
    return d


def register() -> dict:
    sh = xlsx_rows(A / "00_Program/Thelbridge_Verification_Register_PkgA.xlsx")
    hdr = [str(c.value if hasattr(c, "value") else c) for c in sh["REGISTER"][1]]
    d = {"open": []}
    for row in sh["REGISTER"][2:]:
        if not row or not row[0]:
            continue
        rec = dict(zip(hdr, row))
        item = str(rec["Item #"]).strip()
        d[item] = rec
        if str(rec.get("Status", "")).strip() == "Open":
            d["open"].append(item)
        if str(rec.get("Status", "")).strip() == "Closed-w-Comment":
            d.setdefault("closed_w_comment", []).append(item)
    sched = {}
    for row in sh["SCHEDULE"]:
        if row and row[0] and str(row[0]).isdigit():
            sched[str(row[1])] = str(row[2]) + " — " + str(row[3])
    d["schedule"] = sched
    return d


def shoring_rev1() -> dict:
    t = pdf_text(A / "06_Submittals_RFI/Submittal_31-SH-B_Shoring_Calculations_Rev1.pdf", layout=True)
    flat = re.sub(r"\s+", " ", t)
    d = {}
    d["sealed"] = need(r"Rev\.1 Sealed: ([\d/]+)", flat, "Rev.1 seal date").group(1)
    d["wg"] = num(need(r"Working grade \(behind wall\) .*?El\. ([\d.]+) ft", flat, "working grade").group(1))
    d["H"] = num(need(r"Total excavated depth H (\d+) ft", flat, "H = 24").group(1))
    d["toe"] = num(need(r"Sheet-pile tip \(toe\) elevation .*?El\. ([\d.]+) ft", flat, "Rev.1 toe").group(1))
    d["mill_length"] = num(need(r"Sheet-pile total length \(cutoff El\. 750\.0 to toe\) L_sp (\d+) ft", flat,
                                "Rev.1 mill length").group(1))
    d["surcharge"] = num(need(r"q_c = ([\d,]+) psf", flat, "250 psf surcharge").group(1))
    d["su_used"] = num(need(r"short-term undrained .*? ([\d,]+) ", flat, "1,400 psf su").group(1))
    d["table62"] = "Table 6.2" in flat
    d["gis_section"] = need(r"adopted from the Geotechnical Report \(R-1\), Section (\d)", flat, "Rev.1 §3 citation").group(1)
    d["bond_len"] = num(need(r"Bond \(grouted\) length: (\d+) ft", flat, "20 ft bond").group(1))
    d["bond_len_final"] = 24.0 if "increased to 24 ft" in flat else None
    d["free_len"] = num(need(r"Free \(unbonded\) length: (\d+) ft", flat, "free length").group(1))
    d["bond_psi"] = num(need(r"τ_bond = (\d+) psi", flat, "20 psi bond").group(1))
    d["spacing"] = num(need(r"Horizontal spacing: (\d+) ft o\.c\.", flat, "6 ft spacing").group(1))
    d["incl"] = num(need(r"Anchor inclination: (\d+)° below horizontal", flat, "20 deg").group(1))
    d["row"] = num(need(r"Row elevation: El\. ([\d.]+)", flat, "anchor row").group(1))
    d["tip_req"] = num(need(r"Minimum tip El\. required: ([\d.]+)", flat, "min tip").group(1))
    d["bpf"] = num(need(r"Maximum blow count anticipated in CL clay: (\d+) blows/ft", flat, "30 bpf").group(1))
    d["disclaim"] = "does not extend to any permanent below-grade structure" in flat
    d["bond_below"] = num(need(r"seated in the deep sand and gravel stratum below El\. ([\d.]+)", flat, "bond below 720").group(1))
    d["drive_from_grade"] = num(need(r"Sheet piles driven from working grade El\. ([\d.]+)", flat, "drive from grade").group(1))
    d["P_A"] = num(need(r"Total driving force P_A ([\d,]+) lb/ft", flat, "P_A").group(1))
    d["T"] = num(need(r"T = P_A - P_p,design = ([\d,]+) - ([\d,]+) = ([\d,]+) lb/ft", flat, "T").group(3))
    return d


NUMP = "([0-9][0-9,]*(?:[.][0-9]+)?)"


def _val(text: str, label: str, unit: str | None = None, nth: int = 1, window: int = 300) -> float:
    """The nth number printed after `label`, optionally one that carries `unit` right after it."""
    i = text.find(label)
    if i < 0:
        raise LookupError(f"record reader: label {label!r} not found")
    seg = text[i + len(label): i + len(label) + window]
    if unit:
        hits = re.findall(NUMP + "[ ]?" + re.escape(unit), seg)
        if len(hits) < nth:
            raise LookupError(f"record reader: fewer than {nth} numbers with {unit!r} after {label!r}")
        return num(hits[nth - 1])
    hits = re.findall(NUMP, seg)
    if len(hits) < nth:
        raise LookupError(f"record reader: fewer than {nth} numbers after {label!r}")
    return num(hits[nth - 1])


def _chain(text: str, label: str, unit: str | None = None, window: int = 320) -> float:
    """The value at the end of the '=' chain that follows `label`: the last '= <number> [unit]' in the window."""
    i = text.find(label)
    if i < 0:
        raise LookupError(f"record reader: label {label!r} not found")
    seg = text[i + len(label): i + len(label) + window]
    tail = "[ ]?" + re.escape(unit) if unit else ""
    hits = re.findall("=" + "[ ]?" + NUMP + tail, seg)
    if not hits:
        raise LookupError(f"record reader: no '= number' after {label!r}")
    return num(hits[-1])


def shoring_rev2() -> dict:
    t = pdf_text(WS / "Kesterline_31-SH-B_Rev2_Supplement_KE-L-2026-0713.pdf")
    flat = re.sub(r"\s+", " ", t)
    d = {}
    d["date"] = need(r"Date: ([\d/]+)", flat, "Rev.2 date").group(1)
    d["ref"] = need(r"Letter Reference: (KE-L-[\d-]+)", flat, "letter ref").group(1)
    d["H"] = _val(flat, "exposed wall height H =", "ft")
    d["wg"] = _val(flat, "ground surface at El.", None)
    d["sg"] = _val(flat, "final excavation subgrade at El.", None)
    d["wt"] = _val(flat, "Design Phreatic Water Table Behind Wall: El.", None)
    d["head_hold"] = _val(flat, "hold the confined piezometric head at or below El.", None)
    d["pumping_until"] = "until the plant-room slab is cast" in flat
    d["drawdown"] = _chain(flat, "planned drawdown of the confined head is", "ft")
    d["relief_wells"] = 4 if "four 8-in diameter pressure-relief wells" in flat else None
    d["plug"] = _val(flat, "a", "ft clay plug remains") if False else num(
        re.search("a " + NUMP + " ft clay plug remains", flat).group(1))
    d["W"] = _chain(flat, "Unfactored Clay Plug Weight (W)", "psf", 140)
    d["W09"] = _val(flat, "0.9W =", "psf")
    d["u_hold"] = _chain(flat, "Controlled Upward Water Pressure (u)", "psf", 140)
    d["FS_heave"] = _chain(flat, "Base Heave Factor of Safety", None, 90)
    d["P_soil"] = _val(flat, "Layered Effective-Stress Soil + 250 psf Surcharge (Psoil)", "lb/ft")
    d["P_w"] = _val(flat, "Hydrostatic Water Pressure, El. 742.0 to El. 726.0", "lb/ft")
    d["P_total"] = _val(flat, "Total Horizontal Driving Load & Moment Above Subgrade", "lb/ft")
    d["M_total"] = _val(flat, "Total Horizontal Driving Load & Moment Above Subgrade", "ft-lb/ft")
    d["sigma_v0"] = _chain(flat, "Total vertical overburden stress behind the wall at subgrade", "psf")
    d["D"] = _val(flat, "embedded a depth of D =", "ft")
    d["tip"] = _val(flat, "to a sheet-pile tip elevation of El.", None)
    d["sheet_len"] = _val(flat, "total sheet-pile length =", "ft")
    d["pn"] = _chain(flat, "the uniform net passive resistance below subgrade is:", "psf")
    d["Pp"] = _chain(flat, "Unfactored Passive Toe Resistance (Pp)", "lb/ft")
    d["z_p"] = _chain(flat, "Moment Arm About Anchor (El. 745.5)", "ft", 80)
    d["MR"] = _chain(flat, "Resisting Passive Moment (MR)", "ft-lb/ft")
    d["FS_toe"] = _chain(flat, "Rotational Toe Factor of Safety", None)
    d["T_h"] = _chain(flat, "required horizontal anchor reaction is", "lb/ft")
    d["T_design"] = _chain(flat, "the design anchor working load is:", "lb")
    d["Qult"] = _chain(flat, "Ultimate bond capacity is:", "lb")
    d["FS_anchor"] = _chain(flat, "yields a factor of safety of", None, 40)
    d["Mallow"] = _chain(flat, "Mallow =", "kip-ft/ft")
    d["Mmax"] = _val(flat, "producing a maximum flexural demand of", "kip-ft/ft")
    d["FS_flex"] = _chain(flat, "Flexural Factor of Safety", None)
    d["defl"] = _val(flat, "predicted maximum lateral wall deflection of", "in")
    d["H200"] = _chain(flat, "criterion adopted in Rev.1 Section 12.3 is", "in")
    d["trigger"] = _val(flat, "mandatory stop-work trigger if the piezometers read above El.", None)
    d["superseded"] = re.search("supersedes Submittal 31-SH-B Rev[.]1 Sections (.+?)[.] S", flat).group(1)
    i_rf = flat.find("remain in force")
    d["remains"] = flat[flat.rfind("Rev.1 Sections", 0, i_rf) + len("Rev.1 Sections "):i_rf].strip()
    d["cites_312000"] = "Specification Section 31 20 00 Rev.3" in flat
    return d


def spec3120() -> dict:
    t = pdf_text(A / "03_Specifications/Spec_312000_Earth_Moving_Rev3.pdf")
    flat = re.sub(r"\s+", " ", t)
    return {
        "refers_315000": "Section 31 50 00 - Excavation Support and Protection" in flat,
        "holds_315000": (A / "03_Specifications/Spec_315000_Excavation_Support_Rev3.pdf").exists(),
        "sections": sorted(p.name for p in (A / "03_Specifications").glob("*.pdf")),
    }


def dewatering() -> dict:
    t = pdf_text(A / "06_Submittals_RFI/Submittal_31-DW-A_Dewatering_Plan_Rev1.pdf")
    flat = re.sub(r"\s+", " ", t)
    return {
        "date": need(r"Date of Submittal ([\d/]+)", flat, "31-DW-A date").group(1),
        "block_a_only": "addresses dewatering of the Block A basement excavation only" in flat,
        "not_block_b": "does NOT extend to the separate deep excavation planned beneath Block B" in flat,
        "no_drawdown_b": "no interior drawdown system is proposed for Block B" in flat,
        "not_relieved": "nothing in this submittal shall be construed to, relieve the confined piezometric head" in flat,
        "shall_not_be_relied": "shall not be relied upon by others as the basis for:" in flat,
        "spec_ref": need(r"Specification Section (31 23 19)", flat, "31 23 19").group(1),
    }


def field_reports() -> dict:
    t = pdf_text(A / "05_Field/Daily_Field_Reports_Basement_20260628-0702.pdf")
    flat = re.sub(r"\s+", " ", t)
    return {
        "numbers": sorted(set(re.findall(r"Report No\. (\d+)", flat))),
        "dry_at_base": flat.count("dry at base of wall"),
        "wall_dry_zone2": "Perimeter walls in Zone 2 dry at base of wall" in flat,
        "k6_dry": "Zone 2 drain K-6" in flat and "dry" in flat,
    }


def minutes() -> dict:
    t = docx_text(A / "00_Program/Progress_Meeting_Minutes_026_20260709.docx")
    return {"issued": "07/10/2026" if "Issued 07/10/2026" in t else None,
            "item_048": "Shoring Calculations Rev.1" in t}


def everything() -> dict:
    return {
        "s101": s101(), "s201": s201(), "s102": s102(), "gir": gir(), "dbm": dbm(),
        "consolidation": consolidation(), "pile": pile_calc(), "register": register(),
        "rev1": shoring_rev1(), "rev2": shoring_rev2(), "spec": spec3120(),
        "dewatering": dewatering(), "field": field_reports(), "minutes": minutes(),
    }


if __name__ == "__main__":
    import json

    print(json.dumps(everything(), indent=1, default=str))
