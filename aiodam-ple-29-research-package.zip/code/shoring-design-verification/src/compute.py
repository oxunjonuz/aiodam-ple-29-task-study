"""Every number the memo prints, computed here from record inputs — never typed into the memo by hand.

Inputs come from record.py (the corpus itself).  Outputs go to computed.json, which build_memo.py
interpolates.  Alongside each computed value the submittal's own printed value is carried where the
submittal prints one, so the memo can say both "this is what I get" and "this is what they got".
"""
from __future__ import annotations

import json
import math
from pathlib import Path

import record

R = record.everything()
GAMMA_W = 62.4          # pcf, the unit weight the submittal itself carries (R2.2, R2.3)
GAMMA_CLAY = 120.0      # pcf, GIR Table 6-1 / Rev.1 §3.2 / Rev.2 R2.1
SIN20 = math.sin(math.radians(20.0))
COS20 = math.cos(math.radians(20.0))

s101, s201, s102 = R["s101"], R["s201"], R["s102"]
gir, dbm, cons, pile = R["gir"], R["dbm"], R["consolidation"], R["pile"]
rev1, rev2, reg = R["rev1"], R["rev2"], R["register"]

out = {"consts": {"gamma_w": GAMMA_W, "gamma_clay": GAMMA_CLAY}, "source": {}, "geom": {}, "rev2_check": {}, "toe": {}, "anchor": {}, "heave": {},
       "aquifer": {}, "consolidation": {}, "reduced": {}, "record": {}}


def r(x, n=6):
    return round(float(x), n)


# ---------------------------------------------------------------- geometry of the pit
top, under, sg = s101["mat_top"], s101["mat_underside"], s101["pit_subgrade"]
out["geom"]["mat_top"] = top
out["geom"]["mat_underside"] = under
out["geom"]["mat_thickness"] = s101["mat_thickness"]
out["geom"]["pit_subgrade"] = sg
out["geom"]["retained_height"] = r(top - sg)                       # 8.5 ft
out["geom"]["retained_mat_edge"] = r(top - under)                  # 3.0 ft
out["geom"]["retained_clay"] = r(under - sg)                       # 5.5 ft
out["geom"]["design_H"] = rev2["H"]                                # 24.0 ft
out["geom"]["design_over_actual"] = r(rev2["H"] / (top - sg))      # 2.82
out["geom"]["soffit"] = s201["soffit"]
out["geom"]["headroom"] = r(s201["soffit"] - top)                  # 14.0 ft
out["geom"]["sheet_len"] = rev2["sheet_len"]                       # 30.5 ft
out["geom"]["headroom_deficit"] = r(rev2["sheet_len"] - (s201["soffit"] - top))
out["geom"]["rev1_mill_length"] = rev1["mill_length"]              # 28 ft
out["geom"]["anchor_row"] = rev1["row"]
out["geom"]["row_below_grade"] = r(rev2["wg"] - rev1["row"])
out["geom"]["anchor_above_floor"] = r(rev1["row"] - top)           # 11.0
out["geom"]["anchor_below_soffit"] = r(s201["soffit"] - rev1["row"])   # 3.0
out["geom"]["cap_underside"] = s201["cap_underside"]
out["geom"]["cap_thickness_ft"] = s201["cap_thickness_ft"]
out["geom"]["cut_below_cap"] = r(s201["cap_underside"] - sg)       # 6.0
out["geom"]["thickened_underside"] = s201["thickened_underside"]
out["geom"]["cut_below_thickened"] = r(s201["thickened_underside"] - sg)   # 4.0
out["geom"]["topping_max"] = s102["topping_max"]
out["geom"]["retained_from_finished_floor"] = r(top + s102["topping_max"] - sg)

# ---------------------------------------------------------------- R2.3 lateral load case
head = rev2["wt"] - sg                                            # 16 ft of water from El. 742.0
P_w = 0.5 * GAMMA_W * head ** 2
P_soil = rev2["P_total"] - P_w
out["rev2_check"] = {
    "water_head": r(head),
    "P_w": r(P_w, 2),
    "P_w_printed": rev2["P_w"],
    "P_soil": r(P_soil, 2),
    "P_soil_printed": rev2["P_soil"],
    "P_total_printed": rev2["P_total"],
    "hydrostatic_share_pct": r(100 * P_w / rev2["P_total"], 2),
    "sigma_v0": r(rev1["surcharge"] + 12 * 118 + 12 * 120, 2),
    "sigma_v0_printed": rev2["sigma_v0"],
    "M_total_printed": rev2["M_total"],
}
# the same driving load with the geometry that exists: 8.5 ft of clay, drained, no surcharge, no free water
Ka_clay = 0.390                                                    # Rev.1 §3.2, CL drained
P_actual_bound = 0.5 * Ka_clay * GAMMA_CLAY * out["geom"]["retained_height"] ** 2
out["reduced"] = {
    "Ka_clay": Ka_clay,
    "P_bound": r(P_actual_bound, 1),
    "share_of_design_pct": r(100 * P_actual_bound / rev2["P_total"], 2),
    "note": "my own bound: 8.5 ft retained, drained CL at Ka 0.390, no surcharge, no free water",
}

# ---------------------------------------------------------------- R2.4 toe embedment on the reported strength
D, z_p, M_D = rev2["D"], rev2["z_p"], rev2["M_total"]
out["toe"]["D"] = D
out["toe"]["tip"] = rev2["tip"]
out["toe"]["z_p"] = z_p
out["toe"]["M_D"] = M_D
out["toe"]["sigma_v0"] = out["rev2_check"]["sigma_v0"]
out["toe"]["cases"] = {}
for su in (rev1["su_used"], gir["su"][1], gir["su"][0]):
    pn = 4 * su - out["toe"]["sigma_v0"]
    Pp = pn * D
    MR = Pp * z_p
    out["toe"]["cases"][f"{su:.0f}"] = {
        "su": su, "pn": r(pn, 1), "Pp": r(Pp, 1), "MR": r(MR, 1), "FS": r(MR / M_D, 4),
    }
out["toe"]["pn_printed"] = rev2["pn"]
out["toe"]["Pp_printed"] = rev2["Pp"]
out["toe"]["MR_printed"] = rev2["MR"]
out["toe"]["FS_printed"] = rev2["FS_toe"]
# the undrained strength the toe check needs to hold 1.50
pn_req = (1.5 * M_D / z_p) / D
out["toe"]["su_required"] = r((pn_req + out["toe"]["sigma_v0"]) / 4, 2)

# ---------------------------------------------------------------- R2.5 bond zone geometry
row, free_len, bond_len, incl = rev1["row"], rev1["free_len"], rev1["bond_len_final"], rev1["incl"]
bond_top = row - free_len * SIN20
bond_bot = row - (free_len + bond_len) * SIN20
out["anchor"] = {
    "row": row, "free_length": free_len, "bond_length": bond_len, "inclination": incl,
    "spacing": rev1["spacing"], "bond_top": r(bond_top, 2), "bond_bot": r(bond_bot, 2),
    "bond_vertical_extent": r(bond_top - bond_bot, 2),
    "fall": r((free_len + bond_len) * SIN20, 2),
    "clay_top": gir["clay_top"], "clay_bottom": gir["clay_bottom"], "aquifer_top": gir["aquifer_top"],
    "in_clay": bool(gir["clay_bottom"] < bond_bot and bond_top < gir["clay_top"]),
    "above_aquifer": r(bond_bot - gir["aquifer_top"], 2),
    "claimed_below": rev1["bond_below"],
    "impossible_by": r(rev1["bond_below"] - bond_bot, 2),
    "T_design_printed": rev2["T_design"], "Qult_printed": rev2["Qult"], "FS_printed": rev2["FS_anchor"],
    "bond_psi": rev1["bond_psi"],
}

# ---------------------------------------------------------------- R2.2 base heave
plug, W09 = rev2["plug"], rev2["W09"]
out["heave"] = {
    "plug": plug, "W": r(plug * GAMMA_CLAY, 1), "W_printed": rev2["W"], "W09": W09,
    "u_at_hold": r((rev2["head_hold"] - gir["aquifer_top"]) * GAMMA_W, 1),
    "u_at_hold_printed": rev2["u_hold"],
    "FS_at_hold": r(W09 / ((rev2["head_hold"] - gir["aquifer_top"]) * GAMMA_W), 4),
    "FS_at_hold_printed": rev2["FS_heave"],
    "u_unpumped": r((gir["confined_head"] - gir["aquifer_top"]) * GAMMA_W, 1),
    "FS_unpumped": r(W09 / ((gir["confined_head"] - gir["aquifer_top"]) * GAMMA_W), 4),
    "u_at_trigger": r((rev2["trigger"] - gir["aquifer_top"]) * GAMMA_W, 1),
    "FS_at_trigger": r(W09 / ((rev2["trigger"] - gir["aquifer_top"]) * GAMMA_W), 4),
    "head_at_FS_min": r(gir["aquifer_top"] + W09 / (dbm["fs_min"] * GAMMA_W), 2),
    "fs_min": dbm["fs_min"],
}

# ---------------------------------------------------------------- drawdown on the aquitard
dd = gir["confined_head"] - rev2["head_hold"]
du_base = dd * GAMMA_W
out["aquifer"] = {
    "drawdown": r(dd, 2),
    "du_base": r(du_base, 1),
    "du_top": 0.0,
    "du_mean": r(du_base / 2, 1),
    "sigma0": cons["sigma0"], "sigma_p": cons["sigma_p"],
    "preconsolidation_margin": r(cons["sigma_p"] - cons["sigma0"], 1),
    "base_exceeds_margin_by": r(du_base / (cons["sigma_p"] - cons["sigma0"]), 2),
    "depth_from_clay_top_where_increment_exceeds_margin": r((cons["sigma_p"] - cons["sigma0"]) * gir["clay_thickness"] / du_base, 2),
    "pumping_until": rev2["pumping_until"],
}

out["consolidation"]["cv_band_lo"] = cons["cv_cm2s"]
out["consolidation"]["cv_band_hi"] = cons.get("cv_hi", 5e-4)

# ---------------------------------------------------------------- time scale of the aquitard
cv_ft2_day = cons["cv_cm2s"] * 1e-4 * 10.7639 * 86400.0        # cm2/s -> ft2/day
Hdr = cons["Hdr"]
out["consolidation"] = {
    "cv_cm2s": cons["cv_cm2s"], "cv_band_lo": cons["cv_cm2s"], "cv_band_hi": cons.get("cv_hi", 5e-4),
    "cv_ft2_day": r(cv_ft2_day, 6), "H": cons["H"], "Hdr": Hdr,
    "t50_days": r(0.197 * Hdr ** 2 / cv_ft2_day, 1),
    "t90_days": r(0.848 * Hdr ** 2 / cv_ft2_day, 1),
    "t90_years": r(0.848 * Hdr ** 2 / cv_ft2_day / 365.25, 2),
}

# ---------------------------------------------------------------- the record's own statements
out["record"] = {
    "item048_status": reg["048"]["Status"],
    "item048_raised": reg["048"]["Raised date"],
    "item048_thread": reg["048"]["Verification thread"],
    "open_items": reg["open"],
    "closed_w_comment": reg.get("closed_w_comment", []),
    "schedule_0810": reg["schedule"].get("08/10/2026", ""),
    "schedule_0720": reg["schedule"].get("07/20/2026", ""),
    "gir_tables": gir["tables"],
    "gir_su": gir["su"],
    "rev1_cites_section": rev1["gis_section"],
    "rev1_table62": rev1["table62"],
    "gir_table62": gir["has_table_6_2"],
    "su_calc_used": pile["su_avg"],
    "pile_Qs_upper": pile["Qs_upper"],
    "pile_Qult": pile["Qult"],
    "pile_Qservice": pile["Qservice"],
    "dewat_block_a_only": R["dewatering"]["block_a_only"],
    "spec_315000_in_record": R["spec"]["holds_315000"],
    "spec_312000_refers": R["spec"]["refers_315000"],
    "dfr_numbers": R["field"]["numbers"],
    "dfr_dry_at_base": R["field"]["dry_at_base"],
    "superseded": rev2["superseded"],
    "remains": rev2["remains"],
}

Path(record.ROOT / "computed.json").write_text(json.dumps(out, indent=1))
print(json.dumps(out, indent=1))
