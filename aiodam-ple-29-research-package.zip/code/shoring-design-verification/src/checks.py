"""The 30 rubric criteria as code, read off the PDF rendering the judge is shown.

Each check is a test of the memorandum's content, not a keyword search: where a criterion is about a
number, the number is required together with the subject it belongs to, in the same passage.
Written before the memorandum text was drafted (criteria read from tests/grader/criteria.json).
"""
from __future__ import annotations

import re
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
PDF = ROOT / "render" / "Thelbridge_Verification_Memo_Item048_BlockB.pdf"
DOCX_NAME = "Thelbridge_Verification_Memo_Item048_BlockB.docx"


def norm(text: str) -> str:
    t = text.replace("\u00a0", " ").replace("\u2019", "'").replace("\u2018", "'")
    t = t.replace("\u201c", '"').replace("\u201d", '"')
    for dash in "\u2010\u2011\u2012\u2013\u2014\u2212":
        t = t.replace(dash, "-")
    t = re.sub(r"-[ \t]*\n[ \t]*", "-", t)          # "anchor-\nload" -> "anchor-load"
    t = re.sub(r"\s+", " ", t)
    return t.lower()


def pdf_text(path: Path = PDF) -> str:
    with tempfile.NamedTemporaryFile(suffix=".txt", delete=False) as fh:
        out = Path(fh.name)
    subprocess.run(["pdftotext", "-layout", str(path), str(out)], check=True)
    text = out.read_text(errors="replace")
    out.unlink(missing_ok=True)
    return text


def near(t: str, a: str, b: str, window: int = 320) -> bool:
    """`a` and `b` occur within `window` characters of each other (either order)."""
    for m in re.finditer(re.escape(a), t):
        seg = t[max(0, m.start() - window): m.end() + window]
        if b in seg:
            return True
    return False


def both(t: str, *needles: str) -> bool:
    return all(n in t for n in needles)


# --------------------------------------------------------------------------- the criteria
def c00(t: str) -> bool:
    """the R2.3 lateral load case cannot be carried forward as the design loading"""
    return (near(t, "cannot be carried forward as the design loading", "r2.3", 260)
            and both(t, "19,610 lb/ft", "7,987.2 lb/ft", "el. 750.0", "el. 742.0", "24.0 ft"))


def c01(t: str) -> bool:
    """retained height about 8.5 ft"""
    return near(t, "retained height", "8.5 ft", 120) or near(t, "about 8.5 ft", "plant-room", 400)


def c02(t: str) -> bool:
    """no free water surface at El. 742.0 behind the sheet-pile wall"""
    i = t.find("no free water surface at el. 742.0")
    if i < 0:
        return False
    seg = t[i:i + 260]
    return ("sheet-pile wall" in seg or "sheet pile wall" in seg) and "plant-room location" in seg


def c03(t: str) -> bool:
    """the 250 psf surcharge is not the loading that acts"""
    return (near(t, "250 psf", "not the loading that acts behind the wall", 120)
            and "plant-room location" in t)


def c04(t: str) -> bool:
    """the anchor row at El. 745.5 lies inside the completed basement"""
    return (near(t, "tieback anchor row at el. 745.5", "inside the completed basement", 80)
            and both(t, "el. 734.5", "el. 748.5"))


def c05(t: str) -> bool:
    """30.5 ft sheet cannot be driven with the plant relied on"""
    i = t.find("30.5 ft sheet pile cannot be driven")
    if i < 0:
        return False
    seg = t[i:i + 500]
    return ("plant the design relies on" in seg or "the plant" in seg) and "headroom" in seg and "14.0 ft" in seg


def c06(t: str) -> bool:
    """excavation undermines the pile caps at underside El. 732.0"""
    i = t.find("undermines the block b pile caps")
    if i < 0:
        return False
    seg = t[i:i + 120]
    return "732.0" in seg


def c07(t: str) -> bool:
    """R2.4-R2.7 cannot be carried forward: each takes its demand from R2.3"""
    i = t.find("r2.4 to r2.7 cannot be carried forward")
    if i < 0:
        return False
    seg = t[i:i + 420]
    return "takes its demand from the r2.3" in seg and "working grade" in seg and "hydrostatic" in seg


def c08(t: str) -> bool:
    """no temporary support of mat and caps designed in Rev.1 or Rev.2"""
    return both(t, "no temporary support of the basement mat and the pile caps",
                "designed in rev.1 or rev.2")


def c09(t: str) -> bool:
    """no opening in the continuous basement mat is shown in the project record"""
    return both(t, "no opening in the continuous basement mat over the plant-room pit",
                "is shown in the project record")


def c10(t: str) -> bool:
    """the pit outline lies inside the extent of the basement mat"""
    return near(t, "outline lies inside the extent", "basement mat", 120)


def c11(t: str) -> bool:
    """drawdown raises effective stress in the aquitard"""
    return (near(t, "717.6 psf", "base of the clay", 80)
            and (near(t, "717.6 psf", "nil at its top", 260) or near(t, "717.6 psf", "zero at its top", 260))
            and near(t, "total stress", "effective stress", 260))


def c12(t: str) -> bool:
    """the effect on piles, caps and mat has not been evaluated by any party"""
    i = t.find("has not been evaluated by any party")
    if i < 0:
        return False
    seg = t[max(0, i - 320):i + 60]
    return "piles" in seg and "caps" in seg and "mat" in seg


def c13(t: str) -> bool:
    """1,400 psf not supported by the record"""
    i = t.find("1,400 psf used in the toe check")
    if i < 0:
        return False
    seg = t[i:i + 420]
    return "not supported by the project record" in seg and "900" in seg and "1,100 psf" in seg


def c14(t: str) -> bool:
    """toe embedment below 1.50 on the reported strength"""
    return (both(t, "does not reach the 1.50 factor of safety", "0.81", "0.31")
            and near(t, "0.81", "1,100 psf", 400))


def c15(t: str) -> bool:
    """bond zone in the clay, not the SW-GW"""
    return (both(t, "bond zone lies within the cl clay aquitard", "sw-gw")
            and both(t, "el. 736.9", "el. 728.7"))


def c16(t: str) -> bool:
    """no sealed dewatering design covering the Block B relief wells"""
    return both(t, "no sealed dewatering design covering the block b relief wells exists in the project record",
                "31-dw-a", "block a basement")


def c17(t: str) -> bool:
    """without relief-well pumping, base heave about 0.58"""
    return near(t, "without relief-well pumping", "0.58", 220)


def c18(t: str) -> bool:
    """the El. 727.0 trigger does not satisfy the DBM minimum"""
    i = t.find("trigger at el. 727.0")
    if i < 0:
        return False
    seg = t[i:i + 300]
    return "does not satisfy" in seg and "1.48" in seg and "1.50" in seg


def c19(t: str) -> bool:
    """no driveability analysis for tip El. 719.5"""
    i = t.find("no driveability analysis supports the revised sheet-pile tip elevation of el. 719.5")
    return i >= 0 and "722.0" in t[i:i + 400]


def c20(t: str) -> bool:
    """Spec 31 50 00 not in the record"""
    return (both(t, "specification section 31 50 00", "not in the project record")
            and near(t, "31 50 00", "31 20 00", 400))


def c21(t: str) -> bool:
    return "item 048 is not verified" in t


def c22(t: str) -> bool:
    return both(t, "item 048 carries the status open", "open")


def c23(t: str) -> bool:
    return near(t, "08/10/2026", "not released on the disposition reached", 200)


def c24(t: str) -> bool:
    return (both(t, "register response", "a. vance", "07/20/2026")
            and near(t, "register response", "a. vance", 260))


def c25(t: str) -> bool:
    return both(t, "kesterline engineering, pc", "31-sh-b", "31 23 19", "rowan bay constructors",
                "dewatering designer")


def c26(t: str) -> bool:
    """the deliverable exists as a Word document with the required name"""
    return (ROOT / "out" / DOCX_NAME).is_file()


def c27(t: str) -> bool:
    head = t[:700]
    return "to:" in head and "rachel marlbeck" in head


def c28(t: str) -> bool:
    heads = ["1. purpose", "2. documents reviewed", "3. basis of review", "4. findings",
             "5. conclusion and recommendation"]
    pos = [t.find(h) for h in heads]
    return all(p >= 0 for p in pos) and pos == sorted(pos)


def c29(t: str) -> bool:
    """the working behind the retained height: 734.5 less 726.0"""
    chain = re.search(r"el\. 734\.5\s*(?:less|minus|-)\s*(?:el\.\s*)?726\.0\s*=\s*8\.5", t)
    return bool(chain) and near(t, "el. 734.5", "top of the mat", 300)


CHECKS = [("c%02d" % i, f) for i, f in enumerate(
    [c00, c01, c02, c03, c04, c05, c06, c07, c08, c09, c10, c11, c12, c13, c14,
     c15, c16, c17, c18, c19, c20, c21, c22, c23, c24, c25, c26, c27, c28, c29])]

WEIGHTS = [10, 9, 9, 8, 8, 7, 7, 6, 5, 5, 3, 5, 4, 3, 3, 3, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 3]
assert len(WEIGHTS) == len(CHECKS)


def run_text(text: str) -> dict:
    t = norm(text)
    results = {}
    for name, fn in CHECKS:
        try:
            results[name] = bool(fn(t))
        except Exception as exc:
            results[name] = False
            print(f"{name}: ERROR {exc}")
    return results


def run(pdf: Path | None = None) -> dict:
    t = norm(pdf_text(pdf or PDF))
    results = {}
    for name, fn in CHECKS:
        try:
            results[name] = bool(fn(t))
        except Exception as exc:                      # a check that blows up is a failed check
            results[name] = False
            print(f"{name}: ERROR {exc}")
    return results


if __name__ == "__main__":
    res = run(Path(sys.argv[1]) if len(sys.argv) > 1 else None)
    passed = [k for k, v in res.items() if v]
    failed = [k for k, v in res.items() if not v]
    print("passed", len(passed), "/", len(res), "weight", sum(w for (k, _), w in zip(CHECKS, WEIGHTS) if res[k]),
          "/", sum(WEIGHTS))
    print("failed:", failed if failed else "none")
    sys.exit(0 if not failed else 1)
