# flake8: noqa
#!/usr/bin/env python3
"""Docker-world artifact transformation script.

Standalone script packaged into the export ZIP. Runs inside the
container at shutdown time to transform reference artifacts into
grading-ready files.

Used when output verifiers request generated artifact transformations.

Supported transformations:
  *_to_text           - Extract text content from PDF/DOCX/PPTX
  *_to_images         - Render pages as a single concatenated PNG image (PDF/DOCX/PPTX only)
  *_to_pdf            - Convert Office docs to PDF via LibreOffice
  *_to_text_formulas  - Extract spreadsheet content preserving raw formulas
  *_to_style_metadata - Extract Office document style metadata
  *_to_comments_and_changes - Extract DOCX comments and tracked changes
  spreadsheet_to_pdf  - Convert spreadsheet to PDF (with sheet names on each page)

Native (*_native) transformations are NOT handled here. They are treated
identically to source (just cp) by the export pipeline.

Usage:
    python3 transform.py --input /app/files/report.docx \
                          --output /app/output/report.pdf \
                          --transformation docx_to_pdf
"""

from __future__ import annotations

import argparse
import asyncio
import importlib.util
import io
import re
import shutil
import subprocess
import sys
import tempfile
import zipfile
from collections.abc import Callable
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from openpyxl import Workbook
    from PIL import Image as PILImage

SUPPORTED_TRANSFORMATIONS = {"docx_to_comments_and_changes", "docx_to_images", "docx_to_pdf", "docx_to_style_metadata", "docx_to_text", "pdf_to_images", "pdf_to_text", "pptx_to_images", "pptx_to_pdf", "pptx_to_style_metadata", "pptx_to_text", "spreadsheet_to_pdf", "spreadsheet_to_style_metadata", "spreadsheet_to_text_formulas", "step_to_text"}

LIBREOFFICE_TIMEOUT = 120
MAX_RENDER_PAGES = 50
RENDER_DPI = 150


def _find_libreoffice() -> str | None:
    return shutil.which("libreoffice") or shutil.which("soffice")


def _convert_to_pdf(
    input_path: Path,
    *,
    export_filter: str = "pdf",
    profile_xml: str | None = None,
) -> Path | None:
    soffice = _find_libreoffice()
    if not soffice:
        print("ERROR: LibreOffice not found", file=sys.stderr)
        return None

    out_dir = tempfile.mkdtemp(prefix="transform_pdf_")
    user_dir = tempfile.mkdtemp(prefix="libreoffice_profile_")

    if profile_xml:
        profile_user = Path(user_dir) / "user"
        profile_user.mkdir(parents=True, exist_ok=True)
        (profile_user / "registrymodifications.xcu").write_text(
            profile_xml, encoding="utf-8"
        )

    try:
        result = subprocess.run(
            [
                soffice,
                "--headless",
                "--nologo",
                "--nolockcheck",
                f"-env:UserInstallation=file://{user_dir}",
                "--convert-to",
                export_filter,
                "--outdir",
                out_dir,
                str(input_path),
            ],
            capture_output=True,
            timeout=LIBREOFFICE_TIMEOUT,
        )

        if result.returncode != 0:
            print(
                f"ERROR: LibreOffice conversion failed: {result.stderr.decode()}",
                file=sys.stderr,
            )
            shutil.rmtree(out_dir, ignore_errors=True)
            return None

        pdf_path = Path(out_dir) / f"{input_path.stem}.pdf"
        if pdf_path.exists():
            return pdf_path

        print(f"ERROR: PDF not found at {pdf_path}", file=sys.stderr)
        shutil.rmtree(out_dir, ignore_errors=True)
        return None

    except subprocess.TimeoutExpired:
        print("ERROR: LibreOffice conversion timed out", file=sys.stderr)
        shutil.rmtree(out_dir, ignore_errors=True)
        return None
    finally:
        shutil.rmtree(user_dir, ignore_errors=True)


# ---------------------------------------------------------------------------
# Text extraction
# ---------------------------------------------------------------------------


def _extract_text_pdf(input_path: Path) -> str:
    import fitz  # pyright: ignore[reportMissingImports]

    doc = fitz.open(str(input_path))
    pages = []
    try:
        for page in doc:
            pages.append(page.get_text())
    finally:
        doc.close()
    return "\n".join(pages)


def _extract_text_docx(input_path: Path) -> str:
    from docx import Document

    doc = Document(str(input_path))
    paragraphs = [p.text for p in doc.paragraphs]

    for table in doc.tables:
        rows = []
        for row in table.rows:
            rows.append("\t".join(cell.text for cell in row.cells))
        paragraphs.append("\n".join(rows))

    return "\n".join(paragraphs)


def _extract_text_pptx(input_path: Path) -> str:
    from pptx import Presentation

    prs = Presentation(str(input_path))
    parts = []
    for i, slide in enumerate(prs.slides, 1):
        slide_texts: list[str] = []
        for shape in slide.shapes:
            if hasattr(shape, "text_frame") and shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:  # pyright: ignore[reportAttributeAccessIssue]
                    text = paragraph.text.strip()
                    if text:
                        slide_texts.append(text)
            if hasattr(shape, "table") and shape.has_table:
                for row in shape.table.rows:  # pyright: ignore[reportAttributeAccessIssue]
                    row_text = "\t".join(cell.text for cell in row.cells)
                    if row_text.strip():
                        slide_texts.append(row_text)
        if slide_texts:
            parts.append(f"--- Slide {i} ---\n" + "\n".join(slide_texts))
    return "\n\n".join(parts)


def _col_letter(col_idx: int) -> str:
    """Convert 1-based column index to Excel letter (1=A, 27=AA, etc.)."""
    result = ""
    while col_idx > 0:
        col_idx, rem = divmod(col_idx - 1, 26)
        result = chr(65 + rem) + result
    return result


def _xml_escape(val: str) -> str:
    return val.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")


def _spreadsheet_to_xml(input_path: Path, *, data_only: bool) -> str:
    import openpyxl

    read_only = data_only
    wb = openpyxl.load_workbook(str(input_path), data_only=data_only, read_only=read_only)
    parts = []
    try:
        for sheet_name in wb.sheetnames:
            ws = wb[sheet_name]
            rows_xml: list[str] = []
            for row_idx, row in enumerate(ws.iter_rows(min_row=1), start=1):
                cells_xml: list[str] = []
                has_value = False
                for cell in row:
                    col = _col_letter(cell.column) if hasattr(cell, "column") else _col_letter(cells_xml.__len__() + 1)
                    ref = f"{col}{row_idx}"
                    val = cell.value
                    if val is None:
                        cells_xml.append(f'    <cell ref="{ref}" />')
                    else:
                        has_value = True
                        escaped = _xml_escape(str(val))
                        if isinstance(val, str) and not str(val).startswith("="):
                            cells_xml.append(f'    <cell ref="{ref}" type="string">{escaped}</cell>')
                        else:
                            cells_xml.append(f'    <cell ref="{ref}">{escaped}</cell>')
                if has_value:
                    rows_xml.append(
                        f'  <row number="{row_idx}">\n' + "\n".join(cells_xml) + "\n  </row>"
                    )
            if rows_xml:
                escaped_name = _xml_escape(sheet_name)
                parts.append(
                    f'<template sheet="{escaped_name}">\n' + "\n".join(rows_xml) + "\n</template>"
                )
    finally:
        wb.close()
    return "\n\n".join(parts)


def _extract_text_spreadsheet_formulas(input_path: Path) -> str:
    return _spreadsheet_to_xml(input_path, data_only=False)


def _extract_text_step(input_path: Path) -> str:
    # STEP (ISO 10303-21) is a plain-text entity-record format; a faithful copy
    # IS the extraction. errors="replace" guards against stray non-UTF8 bytes.
    return input_path.read_text(encoding="utf-8", errors="replace")


_TEXT_EXTRACTORS: dict[str, Callable[[Path], str]] = {
    "pdf_to_text": _extract_text_pdf,
    "docx_to_text": _extract_text_docx,
    "pptx_to_text": _extract_text_pptx,
    "spreadsheet_to_text_formulas": _extract_text_spreadsheet_formulas,
    "step_to_text": _extract_text_step,
}


# ---------------------------------------------------------------------------
# PDF conversion
# ---------------------------------------------------------------------------

# Calc print profile: keep cell backgrounds/colors, scale each sheet to one
# page wide with unlimited height (ScaleToPagesX=1, ScaleToPagesY=0), and set
# recalculation-on-load to Never (OOXML/ODF RecalcMode=1).
# Without scale-to-pages, headless LibreOffice slices wide sheets into
# page-sized column blocks so the judge only sees the first few columns.
# RecalcMode=Never trusts the values Excel already cached — LibreOffice still
# computes cells that have no cached value (e.g. agent-generated workbooks), but
# does NOT recompute cells that reference external workbooks or use functions it
# doesn't implement, which would otherwise turn correct cached results into
# #NAME?/#VALUE!. (The workbook is converted whole — see
# ``_prepare_spreadsheet_for_pdf`` — so cached values survive to be trusted.)
_CALC_BACKGROUND_PROFILE_XML = """\
<?xml version="1.0" encoding="UTF-8"?>
<oor:items xmlns:oor="http://openoffice.org/2001/registry" \
xmlns:xs="http://www.w3.org/2001/XMLSchema" \
xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
<item oor:path="/org.openoffice.Office.Calc/Print/Page">\
<prop oor:name="Background" oor:op="fuse"><value>true</value></prop></item>
<item oor:path="/org.openoffice.Office.Calc/Print/Page">\
<prop oor:name="BlackWhite" oor:op="fuse"><value>false</value></prop></item>
<item oor:path="/org.openoffice.Office.Calc/Print/Page">\
<prop oor:name="ScaleToPagesX" oor:op="fuse"><value>1</value></prop></item>
<item oor:path="/org.openoffice.Office.Calc/Print/Page">\
<prop oor:name="ScaleToPagesY" oor:op="fuse"><value>0</value></prop></item>
<item oor:path="/org.openoffice.Office.Calc/Formula/Load">\
<prop oor:name="OOXMLRecalcMode" oor:op="fuse"><value>1</value></prop></item>
<item oor:path="/org.openoffice.Office.Calc/Formula/Load">\
<prop oor:name="ODFRecalcMode" oor:op="fuse"><value>1</value></prop></item>
</oor:items>"""


def _convert_docx_to_pdf(input_path: Path, output_path: Path) -> None:
    pdf = _convert_to_pdf(input_path, export_filter="pdf:writer_pdf_Export")
    if not pdf:
        print(f"ERROR: Failed to convert {input_path} to PDF", file=sys.stderr)
        sys.exit(1)
    try:
        shutil.move(str(pdf), str(output_path))
    finally:
        if pdf.parent.exists():
            shutil.rmtree(pdf.parent, ignore_errors=True)


def _convert_pptx_to_pdf(input_path: Path, output_path: Path) -> None:
    pdf = _convert_to_pdf(input_path, export_filter="pdf:impress_pdf_Export")
    if not pdf:
        print(f"ERROR: Failed to convert {input_path} to PDF", file=sys.stderr)
        sys.exit(1)
    try:
        shutil.move(str(pdf), str(output_path))
    finally:
        if pdf.parent.exists():
            shutil.rmtree(pdf.parent, ignore_errors=True)


def _clear_print_settings(wb: Workbook) -> None:
    """Clear stored print settings and force fit-to-width on every sheet.

    A print area saved inside the workbook overrides the scale-to-pages
    settings in _CALC_BACKGROUND_PROFILE_XML, so LibreOffice would only
    export the stored area (often a fraction of the sheet). Clearing it lets
    the fit-to-width setup below apply to the full used range.
    """
    from openpyxl.worksheet.properties import PageSetupProperties

    for ws in wb.worksheets:
        try:
            ws.print_area = None
        except (AttributeError, TypeError, ValueError):
            # Older openpyxl setters reject None; clear the backing attr.
            ws._print_area = None
        # print_title_rows/cols setters ignore None; clear the backing attrs.
        ws._print_rows = None
        ws._print_cols = None
        # Force fit-to-width in the workbook itself: headless Calc does NOT
        # honor the ScaleToPages profile keys on their own (Docker repro: a
        # 30-column sheet still exported 8 columns per page with the profile
        # alone), but it does honor the sheet's stored page setup. One page
        # wide, unlimited pages tall.
        ws.page_setup.orientation = "landscape"
        ws.page_setup.fitToWidth = 1
        ws.page_setup.fitToHeight = 0
        if ws.sheet_properties.pageSetUpPr is None:
            ws.sheet_properties.pageSetUpPr = PageSetupProperties(fitToPage=True)
        else:
            ws.sheet_properties.pageSetUpPr.fitToPage = True


_SHEET_NAME_HEADER = (
    "<headerFooter><oddHeader>&amp;LSheet: &amp;A</oddHeader></headerFooter>"
)


def _prepare_spreadsheet_for_pdf(input_path: Path) -> Path:
    """Rewrite a workbook (zip/XML edits only — NOT openpyxl) for whole-workbook
    PDF conversion, returning the path to a prepared copy.

    Per sheet / workbook it: unhides hidden sheets, clears stored print
    areas/titles, forces fit-to-one-page-wide, and adds a "Sheet: <name>" page
    header (LibreOffice's ``&A`` tab-name code).

    Editing the XML directly rather than round-tripping through openpyxl is
    essential: openpyxl's re-save drops cached formula values, external-link
    data, and defined names, which made formula cells render blank / ``#NAME?``
    / ``#VALUE!`` in the PDF. Converting the workbook whole (no per-sheet
    deletion) also keeps cross-sheet references intact.
    """
    out_dir = tempfile.mkdtemp(prefix="transform_xlsx_prep_")
    dst = Path(out_dir) / "prepared.xlsx"
    with (
        zipfile.ZipFile(str(input_path)) as zin,
        zipfile.ZipFile(str(dst), "w", zipfile.ZIP_DEFLATED) as zout,
    ):
        for name in zin.namelist():
            data = zin.read(name)
            if name == "xl/workbook.xml":
                s = data.decode("utf-8")
                s = re.sub(
                    r'(<sheet\b[^>]*?)\s+state="(?:hidden|veryHidden)"', r"\1", s
                )
                s = re.sub(
                    r'<definedName\b[^>]*name="_xlnm\.Print_Area"[^>]*>.*?</definedName>',
                    "",
                    s,
                    flags=re.S,
                )
                s = re.sub(
                    r'<definedName\b[^>]*name="_xlnm\.Print_Titles"[^>]*>.*?</definedName>',
                    "",
                    s,
                    flags=re.S,
                )
                data = s.encode("utf-8")
            elif re.match(r"xl/worksheets/sheet\d+\.xml$", name):
                s = data.decode("utf-8")
                # Fit-to-page mode: sheetPr/pageSetUpPr fitToPage="1".
                if re.search(r"<pageSetUpPr\b", s):
                    s = re.sub(
                        r"<pageSetUpPr\b[^>]*?/?>",
                        '<pageSetUpPr fitToPage="1"/>',
                        s,
                        count=1,
                    )
                elif re.search(r"<sheetPr\b[^>]*?/>", s):
                    s = re.sub(
                        r"<sheetPr\b([^>]*?)/>",
                        r'<sheetPr\1><pageSetUpPr fitToPage="1"/></sheetPr>',
                        s,
                        count=1,
                    )
                elif re.search(r"<sheetPr\b", s):
                    s = re.sub(
                        r"(</sheetPr>)",
                        r'<pageSetUpPr fitToPage="1"/>\1',
                        s,
                        count=1,
                    )
                else:
                    s = re.sub(
                        r"(<worksheet\b[^>]*>)",
                        r'\1<sheetPr><pageSetUpPr fitToPage="1"/></sheetPr>',
                        s,
                        count=1,
                    )
                # Page setup: 1 page wide, unlimited tall (drop any fixed scale).
                if re.search(r"<pageSetup\b", s):
                    s = re.sub(
                        r"<pageSetup\b([^>]*?)/?>",
                        lambda mo: "<pageSetup"
                        + re.sub(
                            r'\s+(?:scale|fitToWidth|fitToHeight)="[^"]*"',
                            "",
                            mo.group(1),
                        )
                        + ' fitToWidth="1" fitToHeight="0"/>',
                        s,
                        count=1,
                    )
                # Sheet-name header (replace any existing one).
                s = re.sub(
                    r"<headerFooter[^>]*>.*?</headerFooter>", "", s, flags=re.S
                )
                s = re.sub(r"<headerFooter[^>]*/>", "", s)
                if "<pageSetup" in s:
                    s = re.sub(
                        r"(<pageSetup\b[^>]*/>)",
                        lambda mo: mo.group(1) + _SHEET_NAME_HEADER,
                        s,
                        count=1,
                    )
                elif re.search(r"<pageMargins\b[^>]*/>", s):
                    s = re.sub(
                        r"(<pageMargins\b[^>]*/>)",
                        lambda mo: mo.group(1) + _SHEET_NAME_HEADER,
                        s,
                        count=1,
                    )
                else:
                    s = s.replace(
                        "</worksheet>", _SHEET_NAME_HEADER + "</worksheet>"
                    )
                data = s.encode("utf-8")
            zout.writestr(name, data)
    return dst


def _convert_spreadsheet_to_pdf(input_path: Path, output_path: Path) -> None:
    """Convert a spreadsheet to PDF, each sheet's page(s) labeled "Sheet: <name>".

    Converts the whole workbook in a single LibreOffice pass (see
    ``_prepare_spreadsheet_for_pdf``), so cached values, external-link data and
    cross-sheet references survive.
    """
    prepared = _prepare_spreadsheet_for_pdf(input_path)
    try:
        pdf = _convert_to_pdf(
            prepared,
            export_filter="pdf:calc_pdf_Export",
            profile_xml=_CALC_BACKGROUND_PROFILE_XML,
        )
        if not pdf:
            print(f"ERROR: Failed to convert {input_path} to PDF", file=sys.stderr)
            sys.exit(1)
        try:
            shutil.move(str(pdf), str(output_path))
        finally:
            if pdf.parent.exists():
                shutil.rmtree(pdf.parent, ignore_errors=True)
    finally:
        if prepared.parent.exists():
            shutil.rmtree(prepared.parent, ignore_errors=True)


def _safe_filename(s: str) -> str:
    """Replace characters unsafe for temp filenames."""
    return "".join(c if c.isalnum() or c in "._-" else "_" for c in s)[:50]


_PDF_CONVERTERS: dict[str, Callable[[Path, Path], None]] = {
    "docx_to_pdf": _convert_docx_to_pdf,
    "pptx_to_pdf": _convert_pptx_to_pdf,
    "spreadsheet_to_pdf": _convert_spreadsheet_to_pdf,
}

_STYLE_METADATA_EXTRACTORS = {
    "docx_to_style_metadata": "docx_to_style_metadata_output",
    "pptx_to_style_metadata": "pptx_to_style_metadata_output",
    "spreadsheet_to_style_metadata": "spreadsheet_to_style_metadata",
}


def _extract_style_metadata(input_path: Path, transformation: str) -> str:
    module_path = Path(__file__).with_name("obi_style_metadata.py")
    spec = importlib.util.spec_from_file_location("obi_style_metadata", module_path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Could not load style metadata extractor from {module_path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    extractor = getattr(module, _STYLE_METADATA_EXTRACTORS[transformation])
    result = asyncio.run(extractor(input_path.read_bytes(), input_path.name))
    text = (result.text or "").strip()
    if not text:
        raise ValueError("Style metadata extraction returned empty text")
    return (
        f'<STYLE_METADATA file="{_xml_escape(str(input_path))}">\n'
        f"{text}\n"
        "</STYLE_METADATA>\n"
    )


def _extract_comments_and_changes(input_path: Path) -> str:
    if not zipfile.is_zipfile(input_path):
        raise ValueError("Input is not a DOCX archive")
    module_path = Path(__file__).with_name("obi_text_extraction.py")
    spec = importlib.util.spec_from_file_location("obi_text_extraction", module_path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Could not load text extraction module from {module_path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)

    docx_bytes = input_path.read_bytes()
    tracked_changes = module.extract_tracked_changes_as_text(docx_bytes)
    comments = module.extract_comments_as_text(docx_bytes)
    blocks = []
    if tracked_changes is not None:
        blocks.append(f"<tracked_changes>\n{tracked_changes}\n</tracked_changes>")
    if comments is not None:
        blocks.append(f"<document_comments>\n{comments}\n</document_comments>")
    body = (
        "\n".join(blocks)
        if blocks
        else "This document has no tracked changes or comments."
    )
    return (
        f'<REVIEW_MARKUP file="{_xml_escape(str(input_path))}">\n'
        f"{body}\n"
        "</REVIEW_MARKUP>\n"
    )


# ---------------------------------------------------------------------------
# Image rendering
# ---------------------------------------------------------------------------


def _render_pdf_pages(pdf_path: Path) -> list[PILImage.Image]:
    import fitz  # pyright: ignore[reportMissingImports]
    from PIL import Image

    doc = fitz.open(str(pdf_path))
    images: list[PILImage.Image] = []
    try:
        for page in doc[:MAX_RENDER_PAGES]:  # pyright: ignore[reportArgumentType]
            zoom = RENDER_DPI / 72.0
            mat = fitz.Matrix(zoom, zoom)
            pix = page.get_pixmap(matrix=mat)
            img = Image.open(io.BytesIO(pix.tobytes("png")))
            images.append(img)
    finally:
        doc.close()
    return images


def _concatenate_images(images: list[PILImage.Image]) -> bytes:
    from PIL import Image

    if not images:
        return b""
    if len(images) == 1:
        buf = io.BytesIO()
        images[0].save(buf, format="PNG")
        return buf.getvalue()

    total_width = max(img.width for img in images)
    total_height = sum(img.height for img in images)
    combined = Image.new("RGB", (total_width, total_height), (255, 255, 255))
    y_offset = 0
    for img in images:
        combined.paste(img, (0, y_offset))
        y_offset += img.height

    buf = io.BytesIO()
    combined.save(buf, format="PNG")
    return buf.getvalue()


def _render_to_images(input_path: Path, transformation: str) -> bytes:
    ext = input_path.suffix.lower()
    needs_libreoffice = ext != ".pdf"

    if needs_libreoffice:
        pdf_path = _convert_to_pdf(input_path)
        if not pdf_path:
            print(
                f"ERROR: Failed to convert {input_path} to PDF",
                file=sys.stderr,
            )
            sys.exit(1)
        try:
            pages = _render_pdf_pages(pdf_path)
        finally:
            if pdf_path.exists():
                pdf_path.unlink(missing_ok=True)
            if pdf_path.parent.exists():
                shutil.rmtree(pdf_path.parent, ignore_errors=True)
    else:
        pages = _render_pdf_pages(input_path)

    if not pages:
        print(f"ERROR: No pages rendered from {input_path}", file=sys.stderr)
        sys.exit(1)

    return _concatenate_images(pages)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Transform a reference artifact for grading."
    )
    parser.add_argument("--input", required=True, help="Path to the input file")
    parser.add_argument("--output", required=True, help="Path for the output file")
    parser.add_argument(
        "--transformation",
        required=True,
        choices=sorted(SUPPORTED_TRANSFORMATIONS),
        help="Transformation to apply",
    )
    args = parser.parse_args()

    input_path = Path(args.input)
    output_path = Path(args.output)
    transformation = args.transformation

    if not input_path.exists():
        print(f"ERROR: Input file not found: {input_path}", file=sys.stderr)
        return 1

    output_path.parent.mkdir(parents=True, exist_ok=True)

    if transformation == "docx_to_comments_and_changes":
        try:
            text = _extract_comments_and_changes(input_path)
        except Exception as exc:
            print(
                f"WARNING: Failed to extract tracked changes and comments from "
                f"{input_path}: {exc}",
                file=sys.stderr,
            )
            text = (
                f'<REVIEW_MARKUP file="{_xml_escape(str(input_path))}" '
                'data-degraded="true">Tracked changes and comments could not be '
                "extracted from this file.</REVIEW_MARKUP>\n"
            )
        output_path.write_text(text, encoding="utf-8")
    elif transformation in _STYLE_METADATA_EXTRACTORS:
        try:
            text = _extract_style_metadata(input_path, transformation)
        except Exception as exc:
            print(
                f"WARNING: Failed to extract style metadata from {input_path}: {exc}",
                file=sys.stderr,
            )
            text = (
                f'<STYLE_METADATA file="{_xml_escape(str(input_path))}" '
                'data-degraded="true">Style metadata could not be extracted from '
                "this file.</STYLE_METADATA>\n"
            )
        output_path.write_text(text, encoding="utf-8")
    elif transformation in _TEXT_EXTRACTORS:
        extractor = _TEXT_EXTRACTORS[transformation]
        text = extractor(input_path)
        output_path.write_text(text, encoding="utf-8")
        print(
            f"OK: {transformation} | {input_path} -> {output_path} "
            f"({len(text):,} chars)",
            file=sys.stderr,
        )
    elif transformation in _PDF_CONVERTERS:
        converter = _PDF_CONVERTERS[transformation]
        converter(input_path, output_path)
        size = output_path.stat().st_size
        print(
            f"OK: {transformation} | {input_path} -> {output_path} "
            f"({size:,} bytes)",
            file=sys.stderr,
        )
    else:
        image_bytes = _render_to_images(input_path, transformation)
        output_path.write_bytes(image_bytes)
        print(
            f"OK: {transformation} | {input_path} -> {output_path} "
            f"({len(image_bytes):,} bytes)",
            file=sys.stderr,
        )

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
