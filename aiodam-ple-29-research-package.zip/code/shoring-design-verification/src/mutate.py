"""Mutation campaign: break one statement at a time in the memorandum and see whether the reader notices.

Each mutant is a copy of the deliverable with one phrase changed, rendered to PDF by the same transform
the task uses, then read by checks.py.  A mutation is caught when the check written for that statement
turns red.  One harmless control (punctuation only) must NOT be caught.
"""
from __future__ import annotations

import json
import shutil
import subprocess
import sys
from pathlib import Path

import docx

import checks

ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / "out" / "Thelbridge_Verification_Memo_Item048_BlockB.docx"
WORK = ROOT / "work_mut"
TRANSFORM = Path(__file__).resolve().parent / "transform.py"

# (id, target check, old phrase, new phrase)
MUTATIONS = [
    ("M01", "c00", "7,987.2 lb/ft is hydrostatic", "7,897.2 lb/ft is hydrostatic"),
    ("M02", "c00", "cannot be carried forward as the design loading", "can be carried forward as the design loading"),
    ("M03", "c01", "8.5 ft", "9.5 ft"),
    ("M04", "c02", "No free water surface at El. 742.0 can act", "A free water surface at El. 742.0 can act"),
    ("M05", "c03", "is not the loading that acts behind the wall", "is the loading that acts behind the wall"),
    ("M06", "c04", "lies inside the completed basement", "lies outside the completed basement"),
    ("M07", "c05", "30.5 ft sheet pile cannot be driven", "30.5 ft sheet pile can be driven"),
    ("M08", "c06", "pile caps at underside El. 732.0", "pile caps at underside El. 734.5"),
    ("M09", "c07", "R2.4 to R2.7 cannot be carried forward", "R2.4 to R2.7 can be carried forward"),
    ("M10", "c08", "No temporary support of the basement mat and the pile caps",
     "Some temporary support of the basement mat and the pile caps"),
    ("M11", "c09", "No opening in the continuous basement mat over the plant-room pit",
     "An opening in the continuous basement mat over the plant-room pit"),
    ("M12", "c10", "outline lies inside the extent", "outline lies outside the extent"),
    ("M13", "c11", "717.6 psf at the base of the clay", "717.6 psf at the top of the clay"),
    ("M14", "c12", "has not been evaluated by any party", "has been evaluated by the parties"),
    ("M15", "c13", "is not supported by the project record", "is supported by the project record"),
    ("M16", "c14", "does not reach the 1.50 factor of safety", "reaches the 1.50 factor of safety"),
    ("M17", "c15", "bond zone lies within the CL clay aquitard rather than the SW-GW",
     "bond zone lies within the SW-GW rather than the CL clay aquitard"),
    ("M18", "c16", "no sealed dewatering design covering the Block B relief wells exists",
     "a sealed dewatering design covering the Block B relief wells exists"),
    ("M19", "c17", "Without relief-well pumping the base-heave factor of safety is about 0.58",
     "Without relief-well pumping the base-heave factor of safety is about 0.85"),
    ("M20", "c18", "does not satisfy the base-heave minimum", "satisfies the base-heave minimum"),
    ("M21", "c19", "No driveability analysis supports", "A driveability analysis supports"),
    ("M22", "c20", "is not in the project record", "is in the project record"),
    ("M23", "c21", "Item 048 is not verified", "Item 048 is verified"),
    ("M24", "c22", "Register Item 048 carries the status Open", "Register Item 048 carries the status Closed"),
    ("M25", "c23", "is not released on the disposition reached", "is released on the disposition reached"),
    ("M26", "c24", "A. Vance", "R. Nimkar"),
    ("M27", "c25", "dewatering designer", "shoring designer"),
    ("M28", "c27", "Rachel Marlbeck, University Program Director", "Gregory Nash, PE, Structural Engineer of Record"),
    ("M29", "c28", "5.  CONCLUSION AND RECOMMENDATION", "6.  CONCLUSION AND RECOMMENDATION"),
    ("M30", "c29", "El. 734.5 less El. 726.0 = 8.5 ft", "El. 750.0 less El. 726.0 = 24.0 ft"),
    ("CTRL", None, "offered as context and not as a design case", "offered as context, not as a design case"),
]


def mutate(docx_path: Path, old: str, new: str, out_path: Path, every: bool = False) -> bool:
    d = docx.Document(str(docx_path))
    hit = False
    for par in d.paragraphs:
        if old in par.text:
            if every:
                for run in par.runs:
                    if old in run.text:
                        run.text = run.text.replace(old, new)
                        hit = True
                continue
            for run in par.runs:
                if old in run.text:
                    run.text = run.text.replace(old, new, 1)
                    hit = True
                    break
            else:
                for run in par.runs:            # phrase spread over runs: rewrite the whole paragraph
                    run.text = ""
                par.runs[0].text = par.text.replace(old, new, 1)
                hit = True
            break
    if hit:
        d.save(str(out_path))
    return hit


def render(docx_path: Path) -> Path:
    pdf = docx_path.with_suffix(".pdf")
    subprocess.run([sys.executable, str(TRANSFORM), "--input", str(docx_path), "--output", str(pdf),
                    "--transformation", "docx_to_pdf"], check=True, capture_output=True)
    return pdf


def main() -> int:
    WORK.mkdir(exist_ok=True)
    base = checks.run()
    print(f"base: {sum(base.values())}/{len(base)} green")
    if not all(base.values()):
        print("the unmutated memorandum does not pass; the campaign would prove nothing")
        return 2

    rows = []
    for mid, target, old, new in MUTATIONS:
        dpath = WORK / f"{mid}.docx"
        if dpath.exists():
            dpath.unlink()
        every = mid in {"M03", "M23", "M26", "M27"}
        if not mutate(SRC, old, new, dpath, every):
            rows.append((mid, target, "NOT APPLIED", []))
            continue
        res = checks.run(render(dpath))
        failed = [k for k, v in res.items() if not v]
        rows.append((mid, target, "caught" if failed else "SURVIVED", failed))

    caught = [r for r in rows if r[2] == "caught" and r[0] != "CTRL"]
    survived = [r for r in rows if r[2] == "SURVIVED" and r[0] != "CTRL"]
    control = [r for r in rows if r[0] == "CTRL"]
    print(f"\n{len(caught)} caught, {len(survived)} survived, control: {control[0][2] if control else 'n/a'}")
    for mid, target, verdict, failed in rows:
        flag = ""
        if target and target not in failed and verdict == "caught":
            flag = f"   <- caught, but NOT by {target}"
        if target and target in failed:
            flag = f"   <- by {target}"
        print(f"  {mid:5s} {str(target):5s} {verdict:11s} {','.join(failed) or '-':40s}{flag}")
    Path(ROOT / "mutations.json").write_text(json.dumps(rows, indent=1))
    ok = (not survived) and control and control[0][2] == "SURVIVED"
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
