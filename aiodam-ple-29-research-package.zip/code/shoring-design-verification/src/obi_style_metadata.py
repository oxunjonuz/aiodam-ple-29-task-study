#!/usr/bin/env python3
# flake8: noqa
"""Style-metadata extraction for the VLM judge — VENDORED from archipelago.

Studio's visual eval sends the judge the document's exact formatting facts —
fonts, bold, colours, borders, number formats, gridlines, frozen panes, print
settings — as ``<STYLE_METADATA>`` XML, ALONGSIDE the page images. Criteria like
"the header is bold and dark blue" are answered from this, not from pixels; and
"row 1 is frozen" or "prints on one page" have no pixel evidence at all.

The three extractors below are copied VERBATIM from
``archipelago/grading/runner/utils/file_transformations/{docx,pptx,spreadsheet}_to_style_metadata/main.py``
so the bundle produces byte-identical style text to Studio. Only the module
plumbing is replaced:

* archipelago-relative imports (``..models``, ``..xml_utils``,
  ``..style_metadata_cache``, ``...file_extraction``) -> the shims below.
* ``loguru`` -> a stderr shim (nothing consumes structured logs in the verifier).
* ``cached_style_text`` -> a direct call. Its LRU exists to coalesce concurrent
  identical extractions across ~80 verifiers sharing one grading run; this runs
  once per file in a single-shot subprocess, so the cache would never hit.
* Colliding names are prefixed. The three modules share one namespace here,
  so a repeated name would silently shadow the earlier definition:

  - ``pptx``'s ``_extract_run_style`` -> ``_pptx_extract_run_style``
  - ``spreadsheet``'s ``_THEME_PART_RE`` -> ``_SPREADSHEET_THEME_PART_RE``
  - ``spreadsheet``'s ``_theme_part_name`` -> ``_spreadsheet_theme_part_name``

  The OOXML namespace constants are declared once, mirrored from ``xml_utils``
  into the shim below. ``test_the_vendored_module_defines_every_name_once``
  checks that every name is defined once.

Third-party imports resolve because RewardKit executes ``checks.py`` inside its
own uv environment, and ``harbor-rewardkit[all]`` pulls
``markitdown[docx,pptx,xls,xlsx,pdf]`` -> lxml, openpyxl, python-pptx. markitdown
uses mammoth rather than python-docx, so ``test.sh`` adds ``--with python-docx``
and ``--with pypdf`` to the uvx invocation (the same mechanism already used for
google-cloud-aiplatform).

Eligibility is NARROWER than the render set, matching archipelago exactly:
``.xlsx/.xls/.xlsm`` (spreadsheet family), ``.pptx`` only and ``.docx`` only —
python-docx/pptx raise on legacy OLE2 (``.doc``/``.ppt``) and OpenDocument
(``.odt``/``.odp``), and no PDF style extractor exists.

XML safety: archipelago hardens the parser once and every ``etree.fromstring``
call below passes it —

    _SAFE_PARSER = etree.XMLParser(resolve_entities=False, no_network=True)

which closes both XXE vectors (entity expansion and external fetches) for the
agent-authored documents this parses.
"""

import asyncio
import colorsys
from collections.abc import Iterable
import io
import os
import re
import shutil
import subprocess
import sys
import tempfile
import zipfile
from xml.etree import ElementTree
from collections import Counter
from io import BytesIO
from pathlib import Path
from typing import Any, NamedTuple

import lxml.etree as etree
import openpyxl
from docx import Document
from docx.oxml.ns import qn
from docx.text.paragraph import Paragraph
from openpyxl.cell import Cell
from openpyxl.cell.cell import MergedCell
from openpyxl.styles.colors import COLOR_INDEX, Color
from openpyxl.utils.exceptions import InvalidFileException
from openpyxl.worksheet.worksheet import Worksheet
from pptx import Presentation
from pptx.util import Emu
from pypdf import PdfReader


class _Logger:
    """loguru stand-in: the verifier has no structured log sink, and every call
    site here is diagnostic."""

    @staticmethod
    def _emit(level: str, msg: object) -> None:
        print(f"[style_metadata:{level}] {msg}", file=sys.stderr)

    def debug(self, msg: object) -> None:
        self._emit("debug", msg)

    def info(self, msg: object) -> None:
        self._emit("info", msg)

    def warning(self, msg: object) -> None:
        self._emit("warning", msg)

    def error(self, msg: object) -> None:
        self._emit("error", msg)


logger = _Logger()

SOFFICE_TIMEOUT = 120


class TransformationOutput:
    """Stand-in for archipelago's pydantic model — the extractors only ever set
    and read ``text``/``pdf_bytes``."""

    def __init__(self, text=None, images=None, pdf_bytes=None):
        self.text = text
        self.images = images or []
        self.pdf_bytes = pdf_bytes


def xml_escape(value: str) -> str:
    """Escape a value for XML text or a double-quoted attribute.

    Verbatim from ``file_transformations/xml_utils.py``. ``&`` must be replaced
    first or the entities inserted afterwards get double-escaped.
    """
    return (
        value.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
    )


# OOXML namespaces, in one convention: wrapped in braces, the form ElementTree
# and lxml take in `find`/`iter`. The three extractors share one module
# namespace, so each constant is defined once, with one spelling.
PKG_RELS_NS = "{http://schemas.openxmlformats.org/package/2006/relationships}"
OFFICE_RELS_NS = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"
WML_NS = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
DML_NS = "{http://schemas.openxmlformats.org/drawingml/2006/main}"
PML_NS = "{http://schemas.openxmlformats.org/presentationml/2006/main}"


def bare(namespace: str) -> str:
    """A namespace without its braces, for the APIs that want it that way.

    python-docx's `qn` and the `nsmap` arguments take the bare URI, while
    `find`/`iter` take it braced. Deriving one from the other keeps a single
    source for the URI rather than two spellings to drift apart.
    """
    return namespace.strip("{}")


def nearest_ancestor(element: "Element", tag: str) -> "Element | None":
    """The closest ancestor of `element` whose tag is `tag`, or None.

    Starts at the parent, so an element is never its own ancestor. Written out
    three times in forty lines of the docx extractor before this existed —
    once for `w:tc`, twice for `w:tbl` — and each copy had to be mirrored into
    the vendored bundle separately.

    `tag` is the prefixed name (`"w:tbl"`), resolved through `qn` here so
    callers do not each import it.
    """
    node = element.getparent()
    qualified = qn(tag)
    while node is not None and node.tag != qualified:
        node = node.getparent()
    return node


def is_ooxml_package(file_bytes: bytes) -> bool:
    """Whether these bytes are an OOXML package python-docx/pptx can open.

    Verbatim from ``file_transformations/style_metadata_cache.py``. Zip-ness
    alone is not enough: .odt and .odp are zip packages too and then raise
    KeyError deep inside the parser; legacy .doc/.ppt are OLE2 and fail the zip
    check. Testing for the content-types part covers both.
    """
    try:
        with zipfile.ZipFile(io.BytesIO(file_bytes)) as zf:
            return "[Content_Types].xml" in zf.namelist()
    except Exception:
        return False


def _col_letter(col_idx: int) -> str:
    """Verbatim from ``file_transformations/spreadsheet_xml.py``."""
    result = ""
    while col_idx > 0:
        col_idx, rem = divmod(col_idx - 1, 26)
        result = chr(65 + rem) + result
    return result


def find_libreoffice() -> str | None:
    """Verbatim from ``file_extraction/utils/chart_extraction.py``."""
    return shutil.which("libreoffice") or shutil.which("soffice")


async def docx_to_pdf(file_bytes: bytes, file_name: str) -> TransformationOutput:
    """LibreOffice docx->pdf, used ONLY for the page-index approximation in the
    docx extractor. Mirrors archipelago's ``docx_to_pdf`` and the bundle's own
    renderer: headless, throwaway profile, --convert-to pdf.
    """
    soffice = find_libreoffice()
    if not soffice:
        return TransformationOutput()
    workdir = tempfile.mkdtemp(prefix="obi_style_pdf_")
    try:
        src = os.path.join(workdir, os.path.basename(file_name) or "input.docx")
        with open(src, "wb") as fh:
            fh.write(file_bytes)
        profile = os.path.join(workdir, "profile")
        proc = subprocess.run(
            [
                soffice,
                "--headless",
                f"-env:UserInstallation=file://{profile}",
                "--convert-to",
                "pdf",
                "--outdir",
                workdir,
                src,
            ],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=SOFFICE_TIMEOUT,
            check=False,
        )
        if proc.returncode != 0:
            return TransformationOutput()
        stem = os.path.splitext(os.path.basename(src))[0]
        pdf = os.path.join(workdir, f"{stem}.pdf")
        if not os.path.isfile(pdf):
            return TransformationOutput()
        with open(pdf, "rb") as fh:
            return TransformationOutput(pdf_bytes=fh.read())
    except Exception:
        return TransformationOutput()
    finally:
        shutil.rmtree(workdir, ignore_errors=True)


async def cached_style_text(file_bytes, file_name, kind, extract):
    """Direct call — see the module docstring on why the LRU is dropped."""
    return await extract(file_bytes, file_name)


async def evaluate_excel_formulas_with_libreoffice(
    file_bytes: bytes, suffix: str = ".xlsx"
) -> "bytes | None":
    """Round-trip a workbook through LibreOffice to .xlsx.

    Mirrors ``file_extraction/utils/chart_extraction.py``. The spreadsheet
    extractor uses this for ONE case: a legacy ``.xls``, which openpyxl cannot
    open at all. Returns None on any failure; the caller re-raises rather than
    presenting a degraded conversion to the judge as ground truth.
    """
    soffice = find_libreoffice()
    if not soffice:
        logger.warning("LibreOffice not found — cannot convert legacy spreadsheet")
        return None
    workdir = tempfile.mkdtemp(prefix="obi_style_xls_")
    try:
        src = os.path.join(workdir, f"input{suffix}")
        with open(src, "wb") as fh:
            fh.write(file_bytes)
        outdir = os.path.join(workdir, "out")
        os.makedirs(outdir, exist_ok=True)
        profile = os.path.join(workdir, "profile")
        proc = subprocess.run(
            [
                soffice,
                "--headless",
                "--calc",
                f"-env:UserInstallation=file://{profile}",
                "--convert-to",
                "xlsx",
                "--outdir",
                outdir,
                src,
            ],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=SOFFICE_TIMEOUT,
            check=False,
        )
        if proc.returncode != 0:
            return None
        for name in os.listdir(outdir):
            if name.lower().endswith(".xlsx"):
                with open(os.path.join(outdir, name), "rb") as fh:
                    return fh.read()
        return None
    except Exception as exc:
        logger.warning(f"legacy spreadsheet conversion failed: {exc!r}")
        return None
    finally:
        shutil.rmtree(workdir, ignore_errors=True)


# Verbatim from evals/spreadsheet_verifier/formatting_checker.py — the two
# colour helpers the spreadsheet extractor imports.
def get_color_hex(color: Color | None) -> str | None:
    """Convert openpyxl Color object to hex string."""
    if color is None:
        return None

    if color.type == "rgb" and color.rgb:
        rgb = color.rgb
        if len(rgb) == 8:
            return f"#{rgb[2:]}"
        return f"#{rgb}"

    if color.type == "indexed" and color.indexed is not None:
        try:
            idx = int(color.indexed)
            if 0 <= idx < len(COLOR_INDEX):
                indexed_color = COLOR_INDEX[idx]
                if indexed_color and indexed_color != "00000000":
                    return (
                        f"#{indexed_color[2:]}"
                        if len(indexed_color) == 8
                        else f"#{indexed_color}"
                    )
        except (ValueError, IndexError):
            pass

    if color.type == "theme" and color.theme is not None:
        tint = color.tint if color.tint else 0
        return f"theme:{color.theme}:{tint:.2f}"

    return None


def get_fill_color(cell: Cell | MergedCell) -> str | None:
    """Get the fill/highlight color of a cell."""
    if cell.fill is None:
        return None

    if cell.fill.fill_type == "solid" and cell.fill.fgColor:
        return get_color_hex(cell.fill.fgColor)

    return None


# ==========================================================================
# VENDORED VERBATIM: grading/runner/utils/file_transformations/spreadsheet_to_style_metadata/main.py
# workbook style facts: bold/colour/border/number-format per cell, sheet properties (gridlines, frozen panes, autofilter, print setup)
# ==========================================================================
_BORDER_SIDES = ("top", "bottom", "left", "right")

# Per-cell detail covers only the top of each sheet, where title bands and
# headers live; rows past it are covered by the style digest. Emitting every
# styled cell turned a 17MB workbook into 45MB of metadata, most of it one
# 470k-row data dump.
_HEAD_ROWS_PER_SHEET = 50

# Guard against a pathological sheet with per-cell unique formats. Real
# workbooks are nowhere near this (14 was the worst single sheet observed).
_MAX_DIGEST_ENTRIES = 24

# Character budget for per-cell head detail, split evenly across worksheets.
# Only the head detail is rationed; sheet_properties and the digest are small,
# bounded and always emitted. Kept low because the prompt budget truncates a
# head/tail slice of the COMBINED text, which would silently drop the middle
# sheets of a multi-sheet workbook — and this XML runs ~2.7 chars/token rather
# than the usual ~4.
_HEAD_DETAIL_CHAR_BUDGET = 12_000

# Theme 1 (default black) with no tint is boilerplate Excel writes into
# unstyled cells, so only that exact case is suppressed as noise. Theme 0
# (white) is kept — white text is always deliberate — and any nonzero tint
# means the colour was adjusted, so it is kept on either index.
_DEFAULT_TEXT_THEME_INDEX = 1

# Agent-produced workbooks are frequently written with openpyxl rather than
# Excel/LibreOffice, which tends to set an explicit RGB black (rather than a
# theme reference) as the ambient default. Treat that the same as the
# theme-1/no-tint case above, for the same reason.
_DEFAULT_TEXT_RGB_HEX = "#000000"


# Theme colour indices in openpyxl order, which is NOT the order clrScheme
# lists them in: index 0 is lt1 and 1 is dk1, likewise 2/3. Used to turn a
# "theme:4" reference into the hex it denotes.
_THEME_SLOT_ORDER = (
    "lt1",
    "dk1",
    "lt2",
    "dk2",
    "accent1",
    "accent2",
    "accent3",
    "accent4",
    "accent5",
    "accent6",
    "hlink",
    "folHlink",
)
_THEME_REF_RE = re.compile(r"^theme:(?P<index>\d+):(?P<tint>-?[\d.]+)$")


# Matches the theme part itself. A "_rels" entry and a bare directory entry
# both sort before "theme1.xml", so the first name under xl/theme/ is not
# necessarily the theme.
_SPREADSHEET_THEME_PART_RE = re.compile(r"^xl/theme/theme(\d+)\.xml$")


def _spreadsheet_theme_part_name(zf: zipfile.ZipFile) -> str | None:
    """The theme part the WORKBOOK references, else the lowest-numbered one.

    Editing a workbook can leave an orphaned theme1.xml behind while the
    workbook actually points at theme2.xml, and picking by number then reads a
    palette and font scheme the file does not use. The relationship is the
    authority; the numeric pick stays only as a fallback for packages whose
    rels cannot be read.
    """
    parts = [
        (m, n) for n in zf.namelist() if (m := _SPREADSHEET_THEME_PART_RE.match(n))
    ]
    if not parts:
        return None
    try:
        rels = ElementTree.fromstring(zf.read("xl/_rels/workbook.xml.rels"))
        for rel in rels.iter(f"{PKG_RELS_NS}Relationship"):
            if not (rel.get("Type") or "").endswith("/theme"):
                continue
            target = rel.get("Target") or ""
            name = target.lstrip("/") if target.startswith("/") else f"xl/{target}"
            if name in zf.namelist():
                return name
    except (KeyError, ElementTree.ParseError):
        pass
    return min(parts, key=lambda p: int(p[0].group(1)))[1]


def _theme_face_map(zf: zipfile.ZipFile) -> dict[str, str]:
    """{"major": face, "minor": face} from the workbook theme's font scheme."""
    part = _spreadsheet_theme_part_name(zf)
    if part is None:
        return {}
    try:
        root = ElementTree.fromstring(zf.read(part))
    except (KeyError, ElementTree.ParseError):
        return {}
    scheme = root.find(f".//{DML_NS}fontScheme")
    out: dict[str, str] = {}
    for slot in ("major", "minor"):
        latin = (
            scheme.find(f"{DML_NS}{slot}Font/{DML_NS}latin")
            if scheme is not None
            else None
        )
        typeface = latin.get("typeface") if latin is not None else None
        if typeface:
            out[slot] = typeface.strip()
    return out


def _rich_text_runs(
    cell: Cell | MergedCell,
) -> list[tuple[str | None, float | None, str | None]]:
    """(raw face, size, scheme slot) per run, None where the run states none.

    A cell can carry several fonts across its runs and the cell-level font is
    only the default among them, so a flattened cell reported one face and
    "all body text is Verdana" read a mixed cell as compliant. Each run is
    returned raw — a run naming no face renders in the cell's, and a run naming
    no size renders at the cell's — so the caller can fill both from the cell
    and resolve the face the same way it resolves a cell-level one. The scheme
    slot rides along for that resolution: a run can name a theme slot and a
    stale literal at once, and the slot is the one that renders. Returns []
    for a cell that is not rich text.
    """
    value = getattr(cell, "value", None)
    if value is None or isinstance(value, str) or not isinstance(value, Iterable):
        return []
    runs: list[tuple[str | None, float | None, str | None]] = []
    for block in value:
        font = getattr(block, "font", None)
        name = getattr(font, "rFont", None) if font is not None else None
        size = getattr(font, "sz", None) if font is not None else None
        slot = getattr(font, "scheme", None) if font is not None else None
        runs.append(
            (
                str(name).strip() if name else None,
                float(size) if size else None,
                str(slot) if slot else None,
            )
        )
    return runs


def _has_face(cell: Cell | MergedCell, theme_map: dict[str, str] | None = None) -> bool:
    """Whether this cell's font names a face, directly or via the theme.

    A font can carry scheme="major"/"minor" with no name at all, so the slot
    is consulted too — but it has to resolve, or there is no face to report.
    """
    font = cell.font
    if not font:
        return False
    if font.name:
        return True
    slot = getattr(font, "scheme", None)
    return slot in ("major", "minor") and bool((theme_map or {}).get(slot))


def _face_from(
    name: str | None,
    slot: str | None,
    theme_map: dict[str, str],
    theme_faces: frozenset[str],
) -> tuple[str, bool]:
    """The face a (name, scheme) pair renders in, and whether it was indirect.

    A font carrying scheme="major"/"minor" renders the theme face whatever
    name is stored beside it; Excel leaves that name stale when the theme
    changes, so it is a reference rather than the answer.

    Cell fonts and rich-text run fonts both carry the pair, so both resolve
    here. A run resolving on its own name alone reported the stale spelling
    the theme slot exists to correct -- the very confusion ("Verdana" vs
    "Verdana (Body)") this module was changed to end.
    """
    stored = str(name or "").strip()
    if slot in ("major", "minor") and theme_map.get(slot):
        face = theme_map[slot]
        return face, face.lower() != stored.lower()
    return _normalized_face(stored, theme_faces)


def _resolved_face(
    cell: Cell | MergedCell, theme_map: dict[str, str], theme_faces: frozenset[str]
) -> tuple[str, bool]:
    """The face a cell renders in, and whether it was recorded indirectly."""
    return _face_from(
        cell.font.name, getattr(cell.font, "scheme", None), theme_map, theme_faces
    )


def _theme_faces(zf: zipfile.ZipFile) -> frozenset[str]:
    """The workbook theme's major/minor Latin typefaces, lower-cased.

    Used to prove a name like "Verdana (Body)" really denotes a theme face
    before folding it, rather than stripping the suffix off anything that
    happens to end that way.
    """
    part = _spreadsheet_theme_part_name(zf)
    if part is None:
        return frozenset()
    try:
        root = ElementTree.fromstring(zf.read(part))
    except (KeyError, ElementTree.ParseError):
        return frozenset()
    faces: set[str] = set()
    scheme = root.find(f".//{DML_NS}fontScheme")
    for slot in ("major", "minor"):
        latin = (
            scheme.find(f"{DML_NS}{slot}Font/{DML_NS}latin")
            if scheme is not None
            else None
        )
        typeface = latin.get("typeface") if latin is not None else None
        if typeface:
            faces.add(typeface.strip().lower())
    return frozenset(faces)


def _theme_palette(file_bytes: bytes) -> list[str]:
    """The workbook's colour scheme as hex, in Excel's theme-index order."""
    try:
        with zipfile.ZipFile(io.BytesIO(file_bytes), "r") as zf:
            part = _spreadsheet_theme_part_name(zf)
            if part is None:
                return []
            root = ElementTree.fromstring(zf.read(part))
    except (zipfile.BadZipFile, KeyError, ElementTree.ParseError):
        return []

    by_slot: dict[str, str] = {}
    scheme = root.find(f".//{DML_NS}clrScheme")
    for child in scheme if scheme is not None else []:
        slot = child.tag.rsplit("}", 1)[-1]
        srgb = child.find(f"{DML_NS}srgbClr")
        if srgb is not None and srgb.get("val"):
            by_slot[slot] = str(srgb.get("val"))
            continue
        # dk1/lt1 are usually system colours; lastClr carries the concrete value.
        sys_clr = child.find(f"{DML_NS}sysClr")
        if sys_clr is not None and sys_clr.get("lastClr"):
            by_slot[slot] = str(sys_clr.get("lastClr"))
    return [by_slot.get(slot, "") for slot in _THEME_SLOT_ORDER]


# Excel works in HLS on a 0..240 integer scale, not on floats (MS-OI29500
# §2.1.750). Applying the tint to a float luminance and rounding only at the
# end lands one step off on many colours, and these values are graded against
# criteria that name an exact hex — so an off-by-one here IS a false flag.
_HLS_MAX = 240


def _apply_tint(hex_rgb: str, tint: float) -> str:
    """Excel's tint, applied to luminance on Excel's own 240-step HLS scale."""
    if not tint:
        return hex_rgb
    r, g, b = (int(hex_rgb[i : i + 2], 16) / 255 for i in (0, 2, 4))
    hue, lum, sat = colorsys.rgb_to_hls(r, g, b)
    lum = round(lum * _HLS_MAX)
    if tint < 0:
        lum = lum * (1 + tint)
    else:
        lum = lum * (1 - tint) + (_HLS_MAX - _HLS_MAX * (1 - tint))
    lum = max(0, min(_HLS_MAX, round(lum)))
    r, g, b = colorsys.hls_to_rgb(hue, lum / _HLS_MAX, sat)
    return f"{round(r * 255):02X}{round(g * 255):02X}{round(b * 255):02X}"


def _resolved_color(
    value: str | None, palette: list[str], exact_tint: float | None = None
) -> str | None:
    """Turn a "theme:N:tint" reference into the hex it denotes.

    exact_tint comes from the cell's own Color when the caller has it. The
    reference string carries the tint rounded to two decimals, and Excel writes
    tints like 0.499984740745262 for "50%" — rounding that shifts the result by
    a step or two per channel, which an exact-hex criterion counts as a miss.
    """
    if not value:
        return value
    match = _THEME_REF_RE.match(value)
    if not match:
        return value
    index = int(match.group("index"))
    if not palette or index >= len(palette) or not palette[index]:
        # Unresolvable: keep the reference rather than inventing a colour, so
        # the judge sees an unmatched slot instead of a confident wrong hex.
        return value
    tint = float(match.group("tint")) if exact_tint is None else exact_tint
    return f"#{_apply_tint(palette[index], tint)}"


def _notable_font_color(
    cell: Cell | MergedCell, palette: list[str] | None = None
) -> str | None:
    if not cell.font or not cell.font.color:
        return None
    color = cell.font.color
    hex_color = _resolved_color(
        get_color_hex(color), palette or [], getattr(color, "tint", None)
    )
    if hex_color and hex_color.startswith("#"):
        # Resolved, so judge it on the colour itself. Keying on the slot index
        # instead suppressed a workbook that customised slot 1 to something
        # other than black, losing the colour it actually renders.
        return None if hex_color.upper() == _DEFAULT_TEXT_RGB_HEX else hex_color
    # Unresolved (no readable theme): fall back to treating an untinted
    # slot-1 reference as the boilerplate default Excel writes everywhere.
    if (
        color.type == "theme"
        and color.theme == _DEFAULT_TEXT_THEME_INDEX
        and not (color.tint or 0)
    ):
        return None
    return hex_color


def _border_info(
    cell: Cell | MergedCell, palette: list[str] | None = None
) -> tuple[bool, str | None]:
    """Return (has_border, color_of_first_styled_side)."""
    border = cell.border
    if border is None:
        return False, None
    for side_name in _BORDER_SIDES:
        side = getattr(border, side_name, None)
        if side is not None and side.style:
            return True, _resolved_color(
                get_color_hex(side.color),
                palette or [],
                getattr(side.color, "tint", None),
            )
    return False, None


def _cell_style_attrs(
    cell: Cell | MergedCell,
    palette: list[str] | None = None,
    theme_faces: frozenset[str] = frozenset(),
    theme_map: dict[str, str] | None = None,
) -> str:
    """Style attributes for one cell, or "" when the cell is not worth emitting.

    Two distinct questions, deliberately kept apart: whether a cell is notable
    enough to list at all, and what to say about one that is. Only the first
    controls inclusion — the caller skips a cell whose attrs are empty, so
    anything that is present on nearly every cell (a font name, a size) must
    not participate in that test or every cell in the sheet becomes "styled".
    An earlier draft of this got it wrong and would have reproduced the 45MB
    blowup the head/digest split exists to prevent.
    """
    notable: list[str] = []

    if cell.font and cell.font.bold:
        notable.append('bold="true"')
    if cell.font and cell.font.italic:
        notable.append('italic="true"')

    font_color = _notable_font_color(cell, palette)
    if font_color:
        notable.append(f'font_color="{font_color}"')

    fill = getattr(cell, "fill", None)
    fg = getattr(fill, "fgColor", None) if fill else None
    fill_color = _resolved_color(
        get_fill_color(cell), palette or [], getattr(fg, "tint", None)
    )
    if fill_color:
        notable.append(f'fill_color="{fill_color}"')

    has_border, border_color = _border_info(cell, palette)
    if has_border:
        notable.append('border="true"')
        if border_color:
            notable.append(f'border_color="{border_color}"')

    if cell.number_format and cell.number_format != "General":
        notable.append(f'number_format="{xml_escape(cell.number_format)}"')

    if not notable:
        return ""

    # The cell is already being emitted, so naming its face and size is close
    # to free and answers the criteria this module previously could not: a
    # "title in worksheet 2 is 18pt" check had no size to read anywhere.
    font: list[str] = []
    if cell.font:
        if _has_face(cell, theme_map):
            # Same resolution the sheet summary uses, or the two views
            # disagree about the font one cell renders in. The raw spelling is
            # still reported once per sheet in theme_label_spellings.
            face, _ = _resolved_face(cell, theme_map or {}, theme_faces)
            font.append(f'font_name="{xml_escape(face)}"')
        if cell.font.sz:
            font.append(f'font_size_pt="{cell.font.sz}"')

    return " " + " ".join(font + notable)


# Distinct font faces/sizes listed per sheet. Real workbooks use a handful;
# this only guards against a pathological sheet with per-cell fonts.
_MAX_FONT_ENTRIES = 12


# Excel labels the theme faces "Verdana (Body)" / "Verdana (Headings)" in its
# font dropdown, and those labels reach styles.xml as literal font names even
# though no such font exists. Matches the label so it can be folded into the
# face it denotes.
_THEME_FACE_LABEL_RE = re.compile(r"^(?P<face>.+?)\s*\((?:Body|Headings)\)$", re.I)


def _normalized_face(
    name: str, theme_faces: frozenset[str] = frozenset()
) -> tuple[str, bool]:
    """(face, was_theme_label) for a raw font name from styles.xml.

    Gated on the workbook's own theme, so a literal family that merely ends in
    "(Body)" is left verbatim rather than rewritten to a font it never names.
    """
    stripped = name.strip()
    match = _THEME_FACE_LABEL_RE.match(stripped)
    if not match:
        return stripped, False
    face = match.group("face").strip()
    if face.lower() not in theme_faces:
        return stripped, False
    return face, True


# Face names and theme-label spellings listed in the summary attributes.
_MAX_FACE_NAMES = 12


def _sheet_fonts_xml(
    combos: "Counter[tuple[str, float | None]]",
    theme_labels: set[str] | None = None,
) -> str:
    """Render every distinct font face and size seen in the sheet.

    Exists because per-cell attrs are only emitted for cells that are already
    notable, while "all body text is Verdana 11" concerns cells with no bold,
    fill or border. Counts come from the caller's existing row walk rather than
    a second pass, which would double iteration on a 470k-row sheet.
    """
    if not combos:
        return ""

    entries: list[str] = []
    for (name, size), count in combos.most_common(_MAX_FONT_ENTRIES):
        size_attr = f' size_pt="{size}"' if size is not None else ""
        entries.append(
            f'    <font name="{xml_escape(name)}"{size_attr} cells="{count}" />'
        )

    # Faces and face/size combinations are counted separately, so one face at
    # two sizes does not read as two fonts. The name lists are capped like the
    # entries below, with the counts carrying the true totals.
    faces = sorted({name for name, _ in combos})
    shown_faces = faces[:_MAX_FACE_NAMES]
    faces_listed = (
        f' face_names_listed="{len(shown_faces)} of {len(faces)}"'
        if len(faces) > len(shown_faces)
        else ""
    )
    labels = ""
    if theme_labels:
        ordered_labels = sorted(theme_labels)
        shown_labels = ordered_labels[:_MAX_FACE_NAMES]
        labels = f' theme_label_spellings="{xml_escape(", ".join(shown_labels))}"'
        if len(ordered_labels) > len(shown_labels):
            labels += (
                f' theme_label_spellings_listed="{len(shown_labels)} of'
                f' {len(ordered_labels)}"'
            )
    omitted = len(combos) - len(entries)
    note = (
        f' note="the {len(entries)} most common of {len(combos)} face/size'
        f' combinations; {omitted} rarer one(s) not listed"'
        if omitted > 0
        else ' note="every face and size used by a non-empty cell in this sheet"'
    )
    return (
        f'  <fonts faces="{len(faces)}" '
        f'face_names="{xml_escape(", ".join(shown_faces))}"{faces_listed} '
        f'face_size_combinations="{len(combos)}"{labels}{note}>\n'
        + "\n".join(entries)
        + "\n  </fonts>\n"
    )


def _sheet_properties_xml(ws: Worksheet) -> str:
    attrs: list[str] = []

    # Visible is the default; some tools (unlike openpyxl, which leaves the
    # field unset) explicitly serialize showGridLines="1" for that default
    # state. Only surface the hidden case — the only one that's ever
    # actually notable — so those files don't get marked "has formatting"
    # purely from boilerplate.
    if ws.sheet_view.showGridLines is False:
        attrs.append('gridlines_visible="false"')

    if ws.freeze_panes:
        attrs.append(f'frozen_panes="{ws.freeze_panes}"')

    if ws.auto_filter and ws.auto_filter.ref:
        attrs.append(f'auto_filter_range="{xml_escape(str(ws.auto_filter.ref))}"')

    orientation = ws.page_setup.orientation
    if orientation:
        attrs.append(f'print_orientation="{xml_escape(str(orientation))}"')

    if ws.print_title_rows:
        # Embeds the sheet name itself (e.g. 'Sales & Ops'!$1:$1), unlike
        # frozen_panes (a bare cell ref), so it needs escaping too.
        attrs.append(f'print_title_rows="{xml_escape(str(ws.print_title_rows))}"')

    if ws.sheet_state and ws.sheet_state != "visible":
        attrs.append(f'sheet_state="{xml_escape(str(ws.sheet_state))}"')

    zoom = ws.sheet_view.zoomScale
    if zoom is not None and zoom != 100:
        attrs.append(f'zoom_scale="{zoom}"')

    if not attrs:
        return ""
    return f"  <sheet_properties {' '.join(attrs)} />\n"


# Bound the emitted list; a sheet with more tables than this is already well
# past the point where an individual range matters to a criterion.
_MAX_TABLES_PER_SHEET = 24


def _sheet_tables_xml(ws: Worksheet) -> str:
    """Emit the sheet's native Excel Table objects.

    This is the one workbook fact a screenshot can never establish: a native
    Table and a manually formatted range with a sheet-level AutoFilter look
    identical when rendered. A criterion may ask whether 20
    ranges "use native Excel Table objects", and another may ask for each
    table's AutoFilter and row banding — both unanswerable from images, and
    both read straight off the table definition here.

    Emitted even when empty: "this sheet has no native tables" is the evidence
    that distinguishes a genuine miss from an unreported one.
    """
    tables = list((ws.tables or {}).values())
    if not tables:
        return '  <tables count="0" />\n'

    rows: list[str] = []
    for tbl in tables[:_MAX_TABLES_PER_SHEET]:
        attrs = (
            f'name="{xml_escape(str(tbl.displayName))}" '
            f'range="{xml_escape(str(tbl.ref))}"'
        )
        style = tbl.tableStyleInfo
        if style is not None:
            if style.name:
                attrs += f' style="{xml_escape(str(style.name))}"'
            attrs += f' row_stripes="{str(bool(style.showRowStripes)).lower()}"'
            attrs += f' column_stripes="{str(bool(style.showColumnStripes)).lower()}"'
        # A native Table carries its own AutoFilter, independent of the
        # sheet-level one reported in <sheet_properties>.
        attrs += f' has_auto_filter="{str(tbl.autoFilter is not None).lower()}"'
        rows.append(f"    <table {attrs} />")

    omitted = len(tables) - len(rows)
    tail = f"\n    <!-- {omitted} more tables omitted -->" if omitted > 0 else ""
    return (
        f'  <tables count="{len(tables)}">\n'
        + "\n".join(rows)
        + tail
        + "\n  </tables>\n"
    )


def _style_digest_xml(
    signatures: Counter[str], row_span: dict[str, tuple[int, int]], listed_rows: int
) -> str:
    """Summarise every styled cell in a sheet, including unlisted rows.

    Per-cell detail is only emitted for the first _HEAD_ROWS_PER_SHEET rows
    (that's where title bands and headers live). But criteria are often
    phrased "…applied throughout every worksheet", which a head slice can't
    answer. Real workbooks reuse a tiny number of distinct styles — a
    470k-row data dump was 5 signatures — so a digest describes 100% of the
    cells in a handful of lines, which answers "throughout" better than a
    truncated per-cell dump ever could.
    """
    if not signatures:
        return ""

    entries: list[str] = []
    for attrs, count in signatures.most_common(_MAX_DIGEST_ENTRIES):
        lo, hi = row_span[attrs]
        span = f"{lo}" if lo == hi else f"{lo}-{hi}"
        entries.append(f'    <style count="{count}" rows="{span}"{attrs} />')

    listed_combinations = len(entries)
    omitted = len(signatures) - listed_combinations
    if omitted > 0:
        entries.append(f"    <!-- {omitted} rarer style combinations omitted -->")

    # The note describes what was actually written; the judge keys on this
    # attribute rather than on an XML comment, so it must not claim full
    # coverage after dropping combinations.
    if omitted > 0:
        note = (
            f"the {listed_combinations} most common of {len(signatures)} style "
            f"combinations in this sheet; {omitted} rarer combination(s) are not "
            f"listed, so absence here is not evidence a style is missing"
        )
    else:
        note = "covers every styled cell in this sheet, including rows not listed above"

    total = sum(signatures.values())
    return (
        f'  <style_digest total_styled_cells="{total}" '
        f'rows_listed_individually="{listed_rows}" '
        f'note="{note}">\n' + "\n".join(entries) + "\n  </style_digest>"
    )


def _collapse_row_xml(row_idx: int, styled: list[tuple[int, str]]) -> str:
    """Render one row, collapsing runs of identically-styled adjacent cells.

    Header rows are typically wide and uniformly styled (a 55-column navy
    title band was 55 separate lines before this). A range carries exactly
    the same information as the individual cells, so this is lossless.
    """
    entries: list[str] = []
    run_start = run_end = None
    run_sig: str | None = None

    def flush() -> None:
        if run_sig is None or run_start is None or run_end is None:
            return
        start_ref = f"{_col_letter(run_start)}{row_idx}"
        ref = (
            start_ref
            if run_start == run_end
            else f"{start_ref}:{_col_letter(run_end)}{row_idx}"
        )
        entries.append(f'    <cell ref="{ref}"{run_sig} />')

    for col_idx, sig in styled:
        if sig == run_sig and run_end is not None and col_idx == run_end + 1:
            run_end = col_idx
            continue
        flush()
        run_sig, run_start, run_end = sig, col_idx, col_idx
    flush()

    if not entries:
        return ""
    return f'  <row number="{row_idx}">\n' + "\n".join(entries) + "\n  </row>"


def _spreadsheet_to_style_xml(file_bytes: bytes) -> str:
    palette = _theme_palette(file_bytes)
    with zipfile.ZipFile(io.BytesIO(file_bytes), "r") as _zf:
        theme_faces = _theme_faces(_zf)
        theme_map = _theme_face_map(_zf)
    # data_only=False so an uncalculated formula reports its formula rather
    # than None, which is indistinguishable from an empty cell. cell.value has
    # no other consumer here, so styles are unaffected.
    # rich_text=True so a cell whose runs carry different fonts reports all of
    # them. Flattened, such a cell reports only its cell-level font, so a
    # criterion like "all body text is Verdana" reads a mixed cell as compliant.
    wb = openpyxl.load_workbook(io.BytesIO(file_bytes), data_only=False, rich_text=True)
    parts: list[str] = []
    try:
        # Chart sheets (openpyxl Chartsheet) have no cells, sheet_view or
        # freeze_panes — reading style off one raises, which would otherwise
        # take down extraction for every OTHER sheet in the workbook too.
        worksheets = [ws for ws in wb.worksheets if isinstance(ws, Worksheet)]
        per_sheet_budget = _HEAD_DETAIL_CHAR_BUDGET // max(1, len(worksheets))

        for ws in worksheets:
            sheet_props_xml = _sheet_properties_xml(ws)

            rows_xml: list[str] = []
            signatures: Counter[str] = Counter()
            row_span: dict[str, tuple[int, int]] = {}
            listed_rows = 0
            head_chars = 0
            budget_spent = False
            font_combos: Counter[tuple[str, float | None]] = Counter()
            theme_labels: set[str] = set()

            for row_idx, row in enumerate(ws.iter_rows(min_row=1), start=1):
                styled: list[tuple[int, str]] = []
                for cell in row:
                    # Non-anchor cells of a merged range are MergedCell, not
                    # Cell — but Excel/openpyxl can still store real
                    # border/fill on them (e.g. the outer edges of a bordered
                    # merged header block), so they're included too.
                    if not isinstance(cell, Cell | MergedCell) or cell.column is None:
                        continue
                    # Collected before the notability test: a plain body
                    # cell is skipped below, and its font is exactly what the
                    # "all body text is X" criteria need.
                    runs = _rich_text_runs(cell) if cell.value is not None else []
                    cell_has_face = cell.value is not None and _has_face(
                        cell, theme_map
                    )
                    # Runs are walked even when the CELL names no face: a run
                    # carrying its own renders regardless, and gating the whole
                    # walk on the cell dropped every one of them.
                    if cell_has_face or runs:
                        face, was_label = (
                            _resolved_face(cell, theme_map, theme_faces)
                            if cell_has_face
                            else ("", False)
                        )
                        if was_label:
                            theme_labels.add(
                                str(cell.font.name or "(theme font)").strip()
                            )
                        # Counted per CELL, not per run: the attribute is
                        # cells=, and three same-styled runs are still one cell
                        # to a criterion asking how many carry a face.
                        if not runs:
                            if face:
                                font_combos[(face, cell.font.sz)] += 1
                        else:
                            # Only rich text needs the de-duplicating set, and
                            # it is the rare cell — allocating one per plain
                            # cell cost measurable time on a 320k-cell sheet.
                            cell_combos: set[tuple[str, float | None]] = set()
                            for raw_face, raw_size, raw_slot in runs:
                                # A run inherits whichever of the two it omits,
                                # and its own name resolves exactly as a
                                # cell-level one does — theme slot first, then
                                # label folding.
                                run_face = face
                                if raw_face or raw_slot:
                                    run_face, run_was_label = _face_from(
                                        raw_face, raw_slot, theme_map, theme_faces
                                    )
                                    if run_was_label and raw_face:
                                        theme_labels.add(raw_face)
                                if not run_face:
                                    # Neither the run nor the cell names a face.
                                    continue
                                cell_combos.add((run_face, raw_size or cell.font.sz))
                            # Sorted, not set order: a set of (face, size)
                            # tuples iterates in hash order, which Python
                            # randomises per process, so the <font> lines came
                            # out in a different order run to run. Harmless to
                            # a judge reading them, but it makes the output
                            # non-reproducible and any byte-comparison of it
                            # unsound. None sorts before a real size.
                            for combo in sorted(
                                cell_combos,
                                key=lambda c: (c[0], c[1] is None, c[1] or 0.0),
                            ):
                                font_combos[combo] += 1

                    style_attrs = _cell_style_attrs(
                        cell, palette, theme_faces, theme_map
                    )
                    if not style_attrs:
                        continue

                    # Every styled cell feeds the digest, at any depth, so
                    # "throughout"-style criteria stay answerable even for
                    # rows that never get listed individually.
                    signatures[style_attrs] += 1
                    lo, hi = row_span.get(style_attrs, (row_idx, row_idx))
                    row_span[style_attrs] = (min(lo, row_idx), max(hi, row_idx))
                    styled.append((cell.column, style_attrs))

                if budget_spent or row_idx > _HEAD_ROWS_PER_SHEET or not styled:
                    continue

                row_xml = _collapse_row_xml(row_idx, styled)
                if head_chars + len(row_xml) > per_sheet_budget:
                    # Stop listing rows for this sheet, but keep scanning so
                    # the digest still covers the whole sheet.
                    budget_spent = True
                    continue
                rows_xml.append(row_xml)
                head_chars += len(row_xml)
                listed_rows += 1

            # Tables alone are enough to describe a sheet, but a sheet with
            # nothing notable at all still stays out — <tables count="0"/> on
            # an empty sheet is noise, whereas on a populated one it is the
            # evidence that no range was made a native Table.
            has_tables = bool(ws.tables)
            if (
                not sheet_props_xml
                and not rows_xml
                and not signatures
                and not has_tables
                # A sheet of plain text has no notable cell and so produced
                # nothing at all, which is exactly the case "all body text is
                # Verdana 11" asks about. Its <fonts> element is small and
                # bounded, so keep the sheet for that alone.
                and not font_combos
            ):
                continue

            digest_xml = _style_digest_xml(signatures, row_span, listed_rows)

            escaped_name = xml_escape(ws.title)
            body = (
                sheet_props_xml
                + _sheet_fonts_xml(font_combos, theme_labels)
                + _sheet_tables_xml(ws)
                + "\n".join([*rows_xml, digest_xml]).strip("\n")
            )
            parts.append(f'<template sheet="{escaped_name}">\n{body}\n</template>')
    finally:
        wb.close()
    return "\n\n".join(parts)


async def _extract_style_text(file_bytes: bytes, file_name: str) -> str:
    # Parsing is CPU-bound and can take tens of seconds on a large workbook.
    # Run it off the event loop so it doesn't stall the concurrent LLM calls
    # of every other verifier in the same grading run.
    try:
        text = await asyncio.to_thread(_spreadsheet_to_style_xml, file_bytes)
    except (zipfile.BadZipFile, InvalidFileException):
        # A legacy .xls is OLE2, which openpyxl surfaces as BadZipFile from
        # the zip layer; InvalidFileException is its own unsupported-format
        # error, caught alongside so the fallback works either way.
        #
        # Still narrowly scoped on purpose: a real bug while parsing a valid
        # .xlsx should propagate as an error, not silently fall back to a
        # LibreOffice re-save (up to 120s, and can itself alter formatting)
        # whose output would then be presented to the judge as ground truth.
        logger.info(
            f"[TRANSFORM] {file_name} is not OOXML (likely legacy .xls) — "
            f"converting via LibreOffice before style extraction"
        )
        converted = await evaluate_excel_formulas_with_libreoffice(
            file_bytes, suffix=Path(file_name).suffix
        )
        if not converted:
            # Deterministic for this file, so it is reported rather than
            # raised: the cache never stores failures, and re-raising would
            # make every later verifier pay another 120s LibreOffice timeout.
            logger.warning(
                f"[TRANSFORM] LibreOffice could not convert {file_name}; no "
                f"spreadsheet style metadata available"
            )
            # Degraded only when the renderer exists and still failed — that
            # may be a timeout or a non-zero exit, so it should be retried
            # rather than remembered. A missing binary is stable for the life of
            # the process, so that answer is cacheable like any other.
            degraded = ' data-degraded="true"' if find_libreoffice() else ""
            return (
                f'<style_metadata unsupported="true"{degraded}>This workbook '
                "could not be converted from its legacy format, so no style "
                "facts were extracted; draw no conclusion from their absence."
                "</style_metadata>\n"
            )
        text = await asyncio.to_thread(_spreadsheet_to_style_xml, converted)

    return text


async def spreadsheet_to_style_metadata(
    file_bytes: bytes, file_name: str
) -> TransformationOutput:
    """Extract sheet- and cell-level style metadata as judge-readable XML.

    Covers: bold/italic, font color, fill color, borders, number formats
    (cell-level) and gridline visibility, frozen panes, autofilter range,
    print orientation, print title rows, sheet visibility, zoom (sheet-level).

    Extraction is coalesced per grading run via the shared style-metadata
    cache — see style_metadata_cache for why that matters.
    """
    text = await cached_style_text(
        file_bytes, file_name, "spreadsheet", _extract_style_text
    )
    return TransformationOutput(text=text)


# VENDORED VERBATIM: grading/runner/utils/file_transformations/pptx_to_style_metadata/main.py
# slide style facts: shape geometry, run fonts/colours, theme colours
# ==========================================================================
def _emu_to_pt(emu_val: int | Emu | None) -> float | None:
    """Convert EMU to points. Returns None if input is None."""
    if emu_val is None:
        return None
    return round(int(emu_val) / 12700, 1)


def _rgb_to_hex(rgb: Any) -> str | None:
    """Convert an RGBColor to a hex string like '#RRGGBB'. Returns None if not set."""
    if rgb is None:
        return None
    try:
        return f"#{rgb}"
    except Exception:
        return None


def _theme_color_name(color: Any) -> str | None:
    """A theme colour as "accent1" / "dark1", plus any brightness tweak.

    python-pptx raises "no .rgb property on color type '_SchemeColor'" for a run
    coloured from the theme, so catching AttributeError and moving on left no
    colour information at all — and colouring by theme is what PowerPoint
    templates do by default. The theme slot is the honest answer: the concrete
    RGB lives in the theme part and can be overridden per layout, so naming the
    slot is both correct and stable.

    Brightness carries PowerPoint's "Lighter 40% / Darker 25%" variants, without
    which two visibly different shades collapse to the same slot.
    """
    try:
        theme = color.theme_color
    except Exception:
        return None
    # Falsy, not None: python-pptx returns the NOT_THEME_COLOR sentinel (an
    # int enum of value 0) for every non-scheme colour, and every real member
    # is nonzero — so `not theme` screens the sentinel and None alike.
    if not theme:
        return None
    # MSO_THEME_COLOR_INDEX.ACCENT_1 -> "accent1"
    name = str(theme).split()[0].lower().replace("_", "")
    try:
        brightness = color.brightness
    except Exception:
        brightness = 0
    if brightness:
        return f"{name}{brightness:+.0%}".replace("%", "pct")
    return name


def _pptx_extract_run_style(run: Any) -> dict[str, Any]:
    """Extract style properties from a single text run."""
    font = run.font
    color = font.color
    color_rgb = None
    color_theme = None
    if color is not None:
        try:
            color_rgb = _rgb_to_hex(color.rgb)
        except AttributeError:
            # Not an explicit RGB colour. A theme reference is still real colour
            # information, so resolve the slot rather than dropping it.
            color_theme = _theme_color_name(color)
    return {
        "text": run.text,
        "font_name": font.name,  # None means inherited from slide master
        "font_size_pt": _emu_to_pt(font.size),
        "font_color_rgb": color_rgb,
        # Additive: font_color_rgb keeps its meaning (explicit hex, or None), so
        # existing consumers see a new key rather than a changed value.
        "font_color_theme": color_theme,
        "bold": font.bold,  # None means inherited
        "italic": font.italic,  # None means inherited
    }


def _shape_type_name(shape: Any) -> tuple[str | None, str | None]:
    """(type name, why it could not be read).

    The reason is returned rather than swallowed for two reasons. python-pptx
    also returns None legitimately — for a graphic frame holding SmartArt — so
    collapsing both into None leaves a consumer unable to tell "no type" from
    "could not read the type". And it travels under the same `unreadable` key
    the per-shape guard below uses, so there is one marker for this class of gap
    rather than two for a consumer to reconcile.

    BaseShape.shape_type raises NotImplementedError for any subclass that
    doesn't override it, and Shape.shape_type raises for an sp that is neither
    placeholder, freeform, autoshape nor textbox. Letting that propagate cost
    the *whole* deck's style metadata over one odd shape — the caller catches
    per-file, not per-shape — so a criterion about branded text elsewhere on the
    slide would be graded with no evidence at all.
    """
    try:
        shape_type = shape.shape_type
    except Exception as e:
        return None, f"shape_type: {type(e).__name__}: {e}"
    return (str(shape_type) if shape_type else None), None


# Which master text style a placeholder falls back to when neither the shape,
# its layout placeholder nor the master placeholder states a size. PowerPoint
# keeps three on the master: titles, body, and everything else.
_TITLE_PH_TYPES = {"TITLE", "CENTER_TITLE", "VERTICAL_TITLE"}
_BODY_PH_TYPES = {
    "BODY",
    "SUBTITLE",
    "OBJECT",
    "CONTENT",
    "VERTICAL_BODY",
    "VERTICAL_OBJECT",
}


def _ph_category(ph_name: str) -> str:
    """Which master text style a placeholder inherits from: PowerPoint keeps
    three — titles, body, and everything else."""
    if ph_name in _TITLE_PH_TYPES:
        return "title"
    if ph_name in _BODY_PH_TYPES:
        return "body"
    return "other"


def _lvl_size_pt(element: Any, level: int) -> float | None:
    """Size declared for `level` in an element's a:lstStyle, in points.

    PowerPoint stores it per indent level as a:lvlNpPr/a:defRPr/@sz in
    hundredths of a point, so level 0 reads lvl1pPr.
    """
    if element is None:
        return None
    lst = element.find(f"{DML_NS}lstStyle")
    if lst is None:
        return None
    lvl = lst.find(f"{DML_NS}lvl{level + 1}pPr")
    if lvl is None:
        return None
    def_rpr = lvl.find(f"{DML_NS}defRPr")
    sz = def_rpr.get("sz") if def_rpr is not None else None
    return round(int(sz) / 100, 1) if sz else None


def _master_style_size_pt(master: Any, ph_type: str | None, level: int) -> float | None:
    """Size from the master's p:txStyles for this placeholder's category."""
    tx = master.element.find(f"{PML_NS}txStyles") if master is not None else None
    if tx is None:
        return None
    name = {"title": "titleStyle", "body": "bodyStyle"}.get(
        _ph_category(ph_type or ""), "otherStyle"
    )
    style = tx.find(f"{PML_NS}{name}")
    if style is None:
        return None
    lvl = style.find(f"{DML_NS}lvl{level + 1}pPr")
    def_rpr = lvl.find(f"{DML_NS}defRPr") if lvl is not None else None
    sz = def_rpr.get("sz") if def_rpr is not None else None
    return round(int(sz) / 100, 1) if sz else None


def _placeholder_para_size_pt(txbody: Any, level: int) -> float | None:
    """Size from a placeholder's own a:p/a:pPr/a:defRPr for this indent level.

    Matched on the paragraph's a:pPr@lvl (absent means level 0), so a
    multi-level body placeholder keeps each level's own size.
    """
    if txbody is None:
        return None
    for para in txbody.findall(f"{DML_NS}p"):
        ppr = para.find(f"{DML_NS}pPr")
        para_level = int((ppr.get("lvl") or "0") if ppr is not None else "0")
        if para_level != level:
            continue
        def_rpr = ppr.find(f"{DML_NS}defRPr") if ppr is not None else None
        sz = def_rpr.get("sz") if def_rpr is not None else None
        if sz:
            return round(int(sz) / 100, 1)
    return None


def _local_size_pt(
    txbody: Any, para: Any, list_style_source: str = "shape_list_style"
) -> tuple[float, str] | None:
    """The size declared on the paragraph itself or on its container's list
    style — the two links that need no placeholder chain, so a table cell can
    use them as well as a shape.

    a:pPr/a:defRPr applies to THIS paragraph, so it outranks the list style
    and everything below: a deck that overrides one paragraph was reported at
    the container's size instead of the size that renders.
    """
    ppr = para._p.find(f"{DML_NS}pPr")
    para_def = ppr.find(f"{DML_NS}defRPr") if ppr is not None else None
    para_sz = para_def.get("sz") if para_def is not None else None
    if para_sz:
        return round(int(para_sz) / 100, 1), "paragraph_default"

    own = _lvl_size_pt(txbody, para.level)
    return (own, list_style_source) if own is not None else None


def _presentation_default_size_pt(master: Any, level: int) -> tuple[float, str] | None:
    """Size from p:presentation/p:defaultTextStyle — the last link in the chain.

    Deliberately last: it is the weakest declaration, and a shape's own list
    style outranks it. Reaching it earlier reported 18pt for text that renders
    at 28. Reaching it at all matters for a plain text box that states nothing
    locally, whose size was otherwise left "inherited".
    """
    try:
        prs = master.part.package.presentation_part._element
        default = prs.find(f"{PML_NS}defaultTextStyle")
    except Exception:
        return None
    size = _lvl_size_pt_from(default, level)
    return (size, "presentation_default") if size is not None else None


def _lvl_size_pt_from(style_el: Any, level: int) -> float | None:
    """Size for `level` from an element that holds a:lvlNpPr children."""
    if style_el is None:
        return None
    lvl = style_el.find(f"{DML_NS}lvl{level + 1}pPr")
    def_rpr = lvl.find(f"{DML_NS}defRPr") if lvl is not None else None
    sz = def_rpr.get("sz") if def_rpr is not None else None
    return round(int(sz) / 100, 1) if sz else None


def _inherited_size_pt(shape: Any, para: Any, layout: Any) -> tuple[float, str] | None:
    """The size a run with no explicit size actually renders at, and its source.

    Walks the chain PowerPoint does, and the ORDER matters: the paragraph's own
    a:pPr/a:defRPr, then the shape's own a:lstStyle, then the layout
    placeholder, the master placeholder, the master txStyles, and last the
    presentation default. A placeholder copied onto a slide keeps its list
    style while losing placeholder status, so reaching the presentation default
    earlier would report 18pt for text that renders at 28.

    Returns (size_pt, source), or None when no link declares one.
    """
    try:
        level = para.level

        local = _local_size_pt(shape._element.find(f"{PML_NS}txBody"), para)
        if local is not None:
            return local

        if not shape.is_placeholder or layout is None:
            # A plain text box has no placeholder chain, but the presentation
            # still declares a default text size that it renders at.
            master = getattr(layout, "slide_master", None) if layout else None
            return _presentation_default_size_pt(master, para.level)
        idx = shape.placeholder_format.idx
        ph_type = shape.placeholder_format.type
        ph_name = getattr(ph_type, "name", None) or str(ph_type or "")

        for lp in layout.placeholders:
            if lp.placeholder_format.idx != idx:
                continue
            lp_body = lp._element.find(f"{PML_NS}txBody")
            # The layout placeholder can declare the size on its own
            # paragraphs rather than its list style, and that is the more
            # specific of the two — reading only the list style fell through
            # to the master and reported a size the layout overrides.
            size = _placeholder_para_size_pt(lp_body, level)
            if size is None:
                size = _lvl_size_pt(lp_body, level)
            if size is not None:
                return size, "layout_placeholder"
            break

        master = getattr(layout, "slide_master", None)
        if master is None:
            return None
        # Exact type first, then category. Category alone is needed because a
        # slide's content placeholder is OBJECT while the master's is BODY, but
        # it is too coarse on its own: date, footer and slide-number are all
        # "other", so the first of them would answer for all three.
        candidates = [
            mp
            for mp in master.placeholders
            if (getattr(mp.placeholder_format.type, "name", None) or "") == ph_name
        ] or [
            mp
            for mp in master.placeholders
            if _ph_category(getattr(mp.placeholder_format.type, "name", None) or "")
            == _ph_category(ph_name)
        ]
        for mp in candidates:
            mp_body = mp._element.find(f"{PML_NS}txBody")
            # Paragraph default before list style, as for the layout above.
            size = _placeholder_para_size_pt(mp_body, level)
            if size is None:
                size = _lvl_size_pt(mp_body, level)
            if size is not None:
                return size, "master_placeholder"
            break

        size = _master_style_size_pt(master, ph_name, level)
        if size is not None:
            return size, "master_text_styles"
        return _presentation_default_size_pt(master, level)
    except Exception as e:
        # Inheritance is best-effort: a deck with an odd placeholder graph must
        # fall back to "inherited" rather than fail the whole extraction. The
        # fallback is indistinguishable from a genuine "nothing declares a
        # size", so it is logged — otherwise a resolver that breaks on a whole
        # family of decks looks exactly like decks that state no size.
        logger.warning(
            f"[TRANSFORM] pptx size inheritance failed: {type(e).__name__}: {e}"
        )
        return None


def _extract_shape_metadata(shape: Any, layout: Any = None) -> dict[str, Any]:
    """Extract metadata from a single shape."""
    shape_type, type_unreadable = _shape_type_name(shape)
    result: dict[str, Any] = {
        "shape_name": shape.name,
        "shape_type": shape_type,
        "left": _emu_to_pt(shape.left),
        "top": _emu_to_pt(shape.top),
        "width": _emu_to_pt(shape.width),
        "height": _emu_to_pt(shape.height),
    }
    if type_unreadable:
        # Same key the per-shape guard below uses, so a consumer has one marker
        # for this class of gap rather than two to reconcile.
        result["unreadable"] = type_unreadable

    if shape.has_text_frame:
        paragraphs = []
        for para in shape.text_frame.paragraphs:
            runs = [_pptx_extract_run_style(run) for run in para.runs]
            # Fill in the size the run actually renders at when it declares
            # none of its own, and say where the value came from so a reader
            # can tell an inherited size from one set on the run.
            inherited = None
            if any(r["font_size_pt"] is None for r in runs):
                inherited = _inherited_size_pt(shape, para, layout)
            if inherited is not None:
                size, source = inherited
                for r in runs:
                    if r["font_size_pt"] is None:
                        r["font_size_pt"] = size
                        r["font_size_source"] = source
            paragraphs.append(
                {
                    "alignment": str(para.alignment) if para.alignment else None,
                    "level": para.level,
                    "text_runs": runs,
                }
            )
        result["paragraphs"] = paragraphs

    # A table is a GraphicFrame, so has_text_frame is False and every cell's
    # text and styling was skipped entirely — a criterion like "the table
    # content is 28pt" had nothing to read even though the cells state it
    # explicitly. Cell paragraphs are appended as the shape's own so the
    # per-slide style summary counts them like any other run.
    if getattr(shape, "has_table", False):
        table_paragraphs: list[dict[str, Any]] = []
        try:
            for row in shape.table.rows:
                for cell in row.cells:
                    for para in cell.text_frame.paragraphs:
                        runs = [_pptx_extract_run_style(run) for run in para.runs]
                        if not runs:
                            continue
                        # A cell has no placeholder chain, but it can still
                        # carry a paragraph default or its own list style,
                        # and those are what render.
                        if any(r["font_size_pt"] is None for r in runs):
                            local = _local_size_pt(
                                cell._tc.find(f"{DML_NS}txBody"),
                                para,
                                "cell_list_style",
                            )
                            if local is None and layout is not None:
                                # A cell states nothing of its own, so it falls
                                # to the presentation default like any other
                                # text. Stopping here reported "inherited" for
                                # table text while identical text in a plain
                                # box resolved.
                                local = _presentation_default_size_pt(
                                    getattr(layout, "slide_master", None), para.level
                                )
                            if local is not None:
                                size, source = local
                                for r in runs:
                                    if r["font_size_pt"] is None:
                                        r["font_size_pt"] = size
                                        r["font_size_source"] = source
                        table_paragraphs.append(
                            {
                                "alignment": str(para.alignment)
                                if para.alignment
                                else None,
                                "level": para.level,
                                "in_table": True,
                                "text_runs": runs,
                            }
                        )
        except Exception as e:
            # Same rule as the shape-type guard: one odd table must not cost
            # the whole deck's metadata.
            result["unreadable"] = f"table: {type(e).__name__}: {e}"
        if table_paragraphs:
            result["paragraphs"] = result.get("paragraphs", []) + table_paragraphs

    return result


# Guard against a malformed deck with a cyclic or absurdly deep group nesting.
_MAX_GROUP_DEPTH = 8


def _flatten_shapes(shapes: Any, depth: int = 0) -> list[Any]:
    """Yield shapes, descending into group shapes.

    slide.shapes lists a GroupShape but not its children, so grouped text is
    invisible to a plain iteration. Opt-in only, so the older verifiers keep
    the shape list they were written against — see pptx_to_style_metadata.
    """
    flat: list[Any] = []
    for shape in shapes:
        flat.append(shape)
        if depth >= _MAX_GROUP_DEPTH:
            continue
        # shape_type can raise on exotic shapes, so key off the child
        # collection that GroupShape actually exposes.
        children = getattr(shape, "shapes", None)
        if children is not None:
            flat.extend(_flatten_shapes(children, depth + 1))
    return flat


def pptx_to_style_metadata(
    file_bytes: bytes, file_name: str, include_grouped_shapes: bool = False
) -> dict[str, Any]:
    """Extract style metadata from a PPTX file.

    Args:
        file_bytes: Raw .pptx bytes.
        file_name: Filename, included in the output for context.
        include_grouped_shapes: Descend into group shapes. Defaults off because
            two pre-existing evals (pptx_style_verifier and
            pptx_style_verifier_apex_v2) json.dumps this dict wholesale, and
            adding a slide's group children plus the group shapes themselves
            changes any criterion that counts shapes — a 3-shape slide becomes
            5. Only the generic multi-representation judge opts in, where the
            output is a collapsed style summary that no criterion counts.

    Returns:
        {
            "file_name": str,
            "slide_width_pt": float,
            "slide_height_pt": float,
            "slide_count": int,
            "slides": [
                {
                    "index": int,
                    "title": str | None,
                    "layout_name": str,
                    "shapes": [...]
                }
            ]
        }
    """
    prs = Presentation(BytesIO(file_bytes))

    slide_width_pt = _emu_to_pt(prs.slide_width)
    slide_height_pt = _emu_to_pt(prs.slide_height)

    slides_meta: list[dict[str, Any]] = []
    for idx, slide in enumerate(prs.slides):
        # Extract title from the title placeholder if present
        title = None
        if slide.shapes.title and slide.shapes.title.has_text_frame:
            title = slide.shapes.title.text_frame.text

        layout_name = slide.slide_layout.name if slide.slide_layout else None

        # Degrade per shape, not per file. python-pptx raises on several
        # properties of shapes it cannot model, and the caller only catches at
        # file granularity — so one odd shape would otherwise discard every
        # other shape's fonts and colours along with it. The unreadable shape is
        # recorded rather than dropped so a consumer can see the gap.
        raw_shapes = (
            _flatten_shapes(slide.shapes)
            if include_grouped_shapes
            else list(slide.shapes)
        )
        shapes: list[dict[str, Any]] = []
        for shape in raw_shapes:
            try:
                shapes.append(_extract_shape_metadata(shape, slide.slide_layout))
            except Exception as e:
                logger.warning(
                    f"[TRANSFORM] unreadable shape in {file_name}: "
                    f"{type(e).__name__}: {e}"
                )
                shapes.append(
                    {
                        "shape_name": None,
                        "shape_type": None,
                        "unreadable": f"{type(e).__name__}: {e}",
                    }
                )

        slides_meta.append(
            {
                "index": idx,
                "title": title,
                "layout_name": layout_name,
                "shapes": shapes,
            }
        )

    return {
        "file_name": file_name,
        "slide_width_pt": slide_width_pt,
        "slide_height_pt": slide_height_pt,
        "slide_count": len(slides_meta),
        "slides": slides_meta,
    }


# ==========================================================================
# TRANSFORMATION WRAPPER (for the generic multi-representation judge)
# ==========================================================================
# The dict above is consumed directly by pptx_style_verifier, which json.dumps
# it wholesale. That verifier grades one deck per call, so size doesn't matter
# there. The generic judge is different: its style metadata shares a capped
# token budget with everything else in the prompt, and on a spreadsheet an
# unbounded dump cost 45MB and lost 7 of 8 sheets to truncation. So this emits
# a compact per-slide style summary instead — runs collapsed by identical
# style, which is what font/size/colour criteria actually need.

# Distinct style combinations listed per slide before summarising the rest.
_MAX_STYLES_PER_SLIDE = 12

# Characters of sample text kept per style, purely to help the judge tie a
# style to what it applies to.
_SAMPLE_TEXT_CHARS = 60

# Shape names listed per style group. A sample, and said to be one when it is
# truncated — see the shapes_listed attribute.
_MAX_SHAPE_NAMES = 3


def _run_style_key(run: dict[str, Any]) -> tuple[Any, ...]:
    return (
        run.get("font_name"),
        run.get("font_size_pt"),
        run.get("font_color_rgb") or run.get("font_color_theme"),
        run.get("bold"),
        run.get("italic"),
        # Part of the key, not just the output: a size the run states and one
        # resolved from a layout are different facts, and collapsing them
        # would report a single group whose provenance is true of only some
        # of its runs.
        run.get("font_size_source"),
    )


def _style_attrs(key: tuple[Any, ...]) -> str:
    font_name, size, color, bold, italic, size_source = key
    attrs: list[str] = []
    # None means "inherited from the slide layout/master" rather than unset,
    # so say that explicitly instead of silently omitting it — otherwise the
    # judge can't tell "not bold" from "not specified here".
    attrs.append(
        f'font_name="{xml_escape(str(font_name))}"'
        if font_name
        else 'font_name="inherited"'
    )
    attrs.append(
        f'font_size_pt="{size}"' if size is not None else 'font_size_pt="inherited"'
    )
    # Where the size came from, so a reader can tell a size the run states
    # from one this extractor walked the inheritance chain for.
    if size_source:
        attrs.append(f'font_size_pt_source="{xml_escape(str(size_source))}"')
    if color:
        # A theme slot is prefixed so the judge cannot mistake it for a hex.
        value = str(color)
        if not value.startswith("#"):
            value = f"theme:{value}"
        attrs.append(f'font_color="{xml_escape(value)}"')
    # Same reasoning as the fonts above, which this previously failed to
    # follow: omitting bold/italic when None left the judge unable to tell
    # inherited-bold from not-bold, on criteria whose subject is exactly that.
    attrs.append(
        f'bold="{str(bool(bold)).lower()}"' if bold is not None else 'bold="inherited"'
    )
    attrs.append(
        f'italic="{str(bool(italic)).lower()}"'
        if italic is not None
        else 'italic="inherited"'
    )
    return " ".join(attrs)


def _pptx_style_summary_xml(data: dict[str, Any]) -> str:
    lines: list[str] = [
        f'<presentation slides="{data.get("slide_count", 0)}" '
        f'slide_width_pt="{data.get("slide_width_pt")}" '
        f'slide_height_pt="{data.get("slide_height_pt")}">'
    ]

    for slide in data.get("slides", []):
        title = slide.get("title")
        attrs = f'index="{slide.get("index", 0) + 1}"'
        if slide.get("layout_name"):
            attrs += f' layout="{xml_escape(str(slide["layout_name"]))}"'
        if title:
            attrs += f' title="{xml_escape(title[:_SAMPLE_TEXT_CHARS])}"'
        lines.append(f"  <slide {attrs}>")

        # Collapse every run on the slide by identical style signature. A
        # deck reuses a handful of styles, so this stays tiny regardless of
        # how much text the slide holds.
        counts: Counter[tuple[Any, ...]] = Counter()
        samples: dict[tuple[Any, ...], str] = {}
        shapes_for: dict[tuple[Any, ...], set[str]] = {}
        for shape in slide.get("shapes", []):
            for para in shape.get("paragraphs", []):
                for run in para.get("text_runs", []):
                    key = _run_style_key(run)
                    counts[key] += 1
                    text = (run.get("text") or "").strip()
                    if text and key not in samples:
                        samples[key] = text[:_SAMPLE_TEXT_CHARS]
                    if shape.get("shape_name"):
                        shapes_for.setdefault(key, set()).add(shape["shape_name"])

        # Two gaps, reported separately. A shape that failed entirely has no
        # runs below, so its absence needs disclosing; a shape whose TYPE alone
        # could not be read still has its runs listed, so calling those
        # unrepresented would tell the judge to discount real evidence.
        def _represented(shape: dict[str, Any]) -> bool:
            return any(para.get("text_runs") for para in shape.get("paragraphs", []))

        flagged = [s for s in slide.get("shapes", []) if s.get("unreadable")]
        unreadable = [str(s.get("unreadable")) for s in flagged if not _represented(s)]
        partial = [str(s.get("unreadable")) for s in flagged if _represented(s)]

        if unreadable:
            reason = xml_escape(unreadable[0][:_SAMPLE_TEXT_CHARS])
            lines.append(
                f'    <unreadable_shapes count="{len(unreadable)}" '
                f'first_error="{reason}">Text and styles of these shapes are '
                f"NOT represented below; draw no conclusion about them from "
                f"their absence.</unreadable_shapes>"
            )
        if partial:
            reason = xml_escape(partial[0][:_SAMPLE_TEXT_CHARS])
            lines.append(
                f'    <partial_shapes count="{len(partial)}" '
                f'first_error="{reason}">The SHAPE TYPE of these shapes could '
                f"not be read, so draw no conclusion about what kind of object "
                f"they are. Their text and text styles ARE listed below and can "
                f"be relied on.</partial_shapes>"
            )

        for key, count in counts.most_common(_MAX_STYLES_PER_SLIDE):
            attrs = _style_attrs(key) + f' runs="{count}"'
            all_shapes = sorted(shapes_for.get(key, ()))
            shapes = all_shapes[:_MAX_SHAPE_NAMES]
            if shapes:
                attrs += f' shapes="{xml_escape(", ".join(shapes))}"'
                # Say the list is a sample. Unqualified, a criterion about
                # "the title and the footer" could read a 3-name list as the
                # complete set of shapes carrying this style.
                if len(all_shapes) > len(shapes):
                    attrs += f' shapes_listed="{len(shapes)} of {len(all_shapes)}"'
            sample = samples.get(key)
            if sample:
                lines.append(
                    f"    <text_style {attrs}>{xml_escape(sample)}</text_style>"
                )
            else:
                lines.append(f"    <text_style {attrs} />")

        omitted = len(counts) - min(len(counts), _MAX_STYLES_PER_SLIDE)
        if omitted > 0:
            lines.append(f"    <!-- {omitted} rarer style combinations omitted -->")

        lines.append("  </slide>")

    lines.append("</presentation>")
    return "\n".join(lines)


async def _extract_pptx_style_text(file_bytes: bytes, file_name: str) -> str:
    # Parsing is CPU-bound; keep it off the shared grading event loop.
    data = await asyncio.to_thread(pptx_to_style_metadata, file_bytes, file_name, True)
    return _pptx_style_summary_xml(data)


async def pptx_to_style_metadata_output(
    file_bytes: bytes, file_name: str
) -> TransformationOutput:
    """Per-slide font/size/colour summary as judge-readable XML.

    Answers criteria like "titles are 30pt on slides 1 and 7" or "the deck
    uses Arial Black" without the judge having to read font sizes off a
    rendered slide image.
    """
    if not is_ooxml_package(file_bytes):
        logger.info(
            f"[TRANSFORM] {file_name} is not an OOXML package — no pptx style "
            f"metadata available"
        )
        return TransformationOutput(
            text=(
                '<presentation unsupported="true" data-degraded="true">Style metadata requires a '
                ".pptx (OOXML) file; legacy .ppt and OpenDocument .odp are not "
                "supported by this extractor.</presentation>\n"
            )
        )

    text = await cached_style_text(
        file_bytes, file_name, "pptx", _extract_pptx_style_text
    )
    return TransformationOutput(text=text)


# VENDORED VERBATIM: grading/runner/utils/file_transformations/docx_to_style_metadata/main.py
# document style facts: run/paragraph formatting, comments, page index
# ==========================================================================
type Element = etree._Element  # pyright: ignore[reportPrivateUsage]

_WNS = bare(WML_NS)
_SAFE_PARSER = etree.XMLParser(resolve_entities=False, no_network=True)

# Word stores comment-thread parentage across two parts keyed by `paraId`, and
# neither namespace is in python-docx's `qn` map, so both are spelled out here.
_W14_NS = "http://schemas.microsoft.com/office/word/2010/wordml"
_W15_NS = "http://schemas.microsoft.com/office/word/2012/wordml"


def _on_off(el: Element) -> bool:
    """Whether a WordprocessingML on/off element is on.

    ST_OnOff admits 1/0/true/false/on/off, so this allow-lists the three truthy
    tokens rather than deny-listing the falsy ones: a deny-list of ("0","false")
    read w:val="off" as ON. Writers other than Word are the ones that serialize
    the attribute explicitly, and "off" is a token they emit, so the inversion
    landed exactly where it was least likely to be noticed. python-docx's own
    ST_OnOff.convert_from_xml uses the same truthy set. Case is normalised so a
    mis-cased "Off" cannot flip meaning either.

    Callers handle absence themselves, since for some properties absent means
    "inherit" rather than "off".
    """
    return str(el.get(qn("w:val"), "1")).strip().lower() in ("1", "true", "on")


def _half_pt_to_pt(half_pt: str | None) -> float | None:
    """Word stores font size in half-points (string). 22 -> 11.0pt."""
    if half_pt is None:
        return None
    try:
        return round(int(half_pt) / 2, 1)
    except (TypeError, ValueError):
        return None


def _twips_to_pt(twips: str | int | None) -> float | None:
    """Word uses twips (1/20 of a point) for spacing/indents."""
    if twips is None:
        return None
    try:
        return round(int(twips) / 20, 1)
    except (TypeError, ValueError):
        return None


def _extract_run_style(r: Element) -> dict[str, Any]:
    """Extract style + text from a single w:r element.

    Returns a dict with the inline text (possibly empty) and any style hints
    available on the run.
    """
    text_parts: list[str] = []
    for t in r:
        tag_local = etree.QName(t).localname
        if tag_local in ("t", "delText"):
            if t.text:
                text_parts.append(t.text)
        elif tag_local == "tab":
            text_parts.append("\t")
        elif tag_local == "br":
            text_parts.append("\n")
    text = "".join(text_parts)

    rpr = r.find(qn("w:rPr"))
    font_name: str | None = None
    font_size_pt: float | None = None
    bold: bool | None = None
    italic: bool | None = None
    underline: str | None = None
    color_hex: str | None = None
    color_auto = False
    run_shading: str | None = None
    # Stating "no shading" is not the same as saying nothing. Like any direct
    # formatting it overrides the character style's fill, so the style must not
    # be consulted afterwards.
    run_shading_cleared = False
    run_style: str | None = None
    if rpr is not None:
        rstyle = rpr.find(qn("w:rStyle"))
        if rstyle is not None:
            run_style = rstyle.get(qn("w:val"))
        rfonts = rpr.find(qn("w:rFonts"))
        if rfonts is not None:
            font_name = rfonts.get(qn("w:ascii")) or rfonts.get(qn("w:hAnsi"))
        sz = rpr.find(qn("w:sz"))
        if sz is not None:
            font_size_pt = _half_pt_to_pt(sz.get(qn("w:val")))
        b = rpr.find(qn("w:b"))
        if b is not None:
            bold = _on_off(b)
        i = rpr.find(qn("w:i"))
        if i is not None:
            italic = _on_off(i)
        u = rpr.find(qn("w:u"))
        if u is not None:
            underline = u.get(qn("w:val"))
        shd = rpr.find(qn("w:shd"))
        if shd is not None:
            run_shading, run_shading_cleared = _shading_state(shd)
            # Named for what the caller does with it: skip the character style.
        color = rpr.find(qn("w:color"))
        if color is not None:
            val = color.get(qn("w:val"))
            # "auto" is not "unset": Word renders it black on a light page,
            # whereas an absent w:color inherits from the style. Collapsing
            # both to None left a criterion about black text unanswerable.
            if val == "auto":
                color_auto = True
            elif val:
                color_hex = f"#{val}" if not val.startswith("#") else val

    return {
        "text": text,
        "font_name": font_name,
        "font_size_pt": font_size_pt,
        "bold": bold,
        "italic": italic,
        "underline": underline,
        "color_hex": color_hex,
        "color_auto": color_auto,
        # Shading on the run itself sits closest to the text, so it beats the
        # paragraph's when automatic colour is resolved.
        "run_shading": run_shading,
        # The character style is a reference to a background, resolved against
        # the same shaded style ids a paragraph or table style is.
        "run_style": run_style,
        "run_shading_cleared": run_shading_cleared,
    }


# A background we can see exists but cannot resolve to a hex. Automatic text
# is left unresolved over it rather than guessed at.
_UNKNOWN_SHADING = "?"


def _shading_state(shd: "Element") -> tuple[str | None, bool]:
    """What a w:shd paints: (fill or _UNKNOWN_SHADING, overrides_its_style).

    ST_Shd is not a colour, it is a PATTERN plus two colours. Only ``clear``
    means "no pattern, just w:fill"; ``nil`` means nothing at all; every other
    value (pct25, horzStripe, diagCross, ...) paints w:color over w:fill, and
    the blend of the two is not something this resolves. So "no usable w:fill"
    does not mean "nothing is painted" -- reading it that way reported a 25%
    pattern of navy ink as an empty background.

    The second value says whether this w:shd overrides the fill its style would
    otherwise supply. Anything that paints does. ``nil`` does, because it is an
    explicit "no shading" -- an authoring act, not a default.

    ``clear`` with no usable fill deliberately does NOT. It is the default
    state written out longhand, which is exactly the shape a converter emits as
    boilerplate, and treating boilerplate as an override would suppress a real
    dark table style and report readable black text on a navy cell -- the
    false positive this module exists to prevent. No file to hand settles
    whether converters emit it, so the ambiguous spelling stays unresolved,
    which is what main already does. The unambiguous one is honoured.
    """
    val = (shd.get(qn("w:val")) or "clear").lower()
    if val == "nil":
        return None, True
    if val != "clear":
        # A pattern paints something; the effective colour is unresolvable.
        return _UNKNOWN_SHADING, True
    if shd.get(qn("w:themeFill")):
        return _UNKNOWN_SHADING, True
    fill = shd.get(qn("w:fill"))
    if fill and fill.lower() not in ("auto", "none"):
        return fill, True
    return None, False


def _enclosing_table_style(p: "Element") -> str | None:
    """The style id of the table this paragraph sits in, if any.

    A table style is a reference, so it is resolved against the same shaded
    style ids a paragraph style is: the fill lives in the style, not on the
    cell.
    """
    node = nearest_ancestor(p, "w:tbl")
    if node is None:
        return None
    tbl_pr = node.find(qn("w:tblPr"))
    style = tbl_pr.find(qn("w:tblStyle")) if tbl_pr is not None else None
    val = style.get(qn("w:val")) if style is not None else None
    return str(val) if val else None


def _effective_shading(
    p: "Element",
    ppr: "Element | None",
) -> tuple[list[tuple[str, str]], tuple[str, ...]]:
    """The fills painted behind a paragraph, and which holders declared one.

    All of them, not the nearest one. Automatic text is resolved only when
    every background in play is known light, so which one Word would pick
    never has to be decided: if they agree the answer is the same either way,
    and if they disagree the honest answer is "unresolved" either way. That
    removes the precedence question rather than answering it.

    The holder is reported because one comparison is NOT a precedence question:
    a style's fill and a direct fill on the SAME element are one property
    written twice, and direct formatting simply replaces the style's, which is
    never painted (ECMA-376 §17.7.2). Knowing a holder set its own fill is what
    lets the caller drop that holder's style rather than weigh the two.

    Which is why the second return value exists. A holder can declare a
    background and declare it EMPTY -- w:shd val="nil", or fill="auto" -- and
    that still overrides its style, because it is direct formatting like any
    other. Deriving "this holder declared something" from the fill list alone
    could not see those: they produce no fill, so a paragraph that explicitly
    clears a dark style's shading looked identical to one that said nothing,
    and automatic text came back unresolved over a page Word renders white.
    """
    holders: list[tuple[str, Any]] = [] if ppr is None else [("paragraph", ppr)]
    cell = nearest_ancestor(p, "w:tc")
    if cell is not None:
        tc_pr = cell.find(qn("w:tcPr"))
        if tc_pr is not None:
            holders.append(("cell", tc_pr))
        tbl = nearest_ancestor(cell, "w:tbl")
        tbl_pr = tbl.find(qn("w:tblPr")) if tbl is not None else None
        if tbl_pr is not None:
            holders.append(("table", tbl_pr))

    fills: list[tuple[str, str]] = []
    declared: set[str] = set()
    for kind, holder in holders:
        shd = holder.find(qn("w:shd"))
        if shd is None:
            continue
        fill, overrides = _shading_state(shd)
        if overrides:
            declared.add(kind)
        if fill:
            fills.append((kind, fill))
    # Sorted tuple, not a set: every other value in the paragraph dict is a
    # JSON-safe primitive, and a set both breaks json.dumps and stringifies in
    # hash order -- the same non-determinism the <font> ordering had.
    return fills, tuple(sorted(declared))


def _is_known_light(hex_rgb: str) -> bool:
    """Whether a background is READABLE and light enough that Word renders
    automatic text black. Rec. 601 luma, midpoint threshold.

    Not the negation of "dark": a fill this cannot parse is neither, and
    answering "light" for it resolved automatic text to black over a background
    that was never read — inventing the value this module exists to avoid.
    """
    value = hex_rgb.lstrip("#")
    if len(value) != 6:
        return False
    try:
        r, g, b = (int(value[i : i + 2], 16) for i in (0, 2, 4))
    except ValueError:
        return False
    return (0.299 * r + 0.587 * g + 0.114 * b) >= 128


def _page_background_is_dark(
    zf: zipfile.ZipFile,
    doc_root: "Element",
) -> bool:
    """Whether the document paints a dark page background Word would honour.

    A w:background is inert unless settings.xml opts in via
    displayBackgroundShape, so an undisplayed one leaves the page white.
    """
    bg = doc_root.find(qn("w:background"))
    if bg is None:
        return False
    color = bg.get(qn("w:color")) or bg.get("color")
    themed = bg.get(qn("w:themeColor"))
    # A themed page colour is not resolved here, so it cannot be assumed light.
    if not themed and (
        not color or color.lower() in ("auto", "none") or _is_known_light(color)
    ):
        return False
    if "word/settings.xml" not in zf.namelist():
        return False
    try:
        st = etree.fromstring(zf.read("word/settings.xml"), parser=_SAFE_PARSER)
    except etree.XMLSyntaxError:
        return False
    dbs = st.find(qn("w:displayBackgroundShape"))
    return dbs is not None and _on_off(dbs)


# Elements that wrap runs without being runs. Word nests visible text inside
# any of these, and each one that is not descended into silently removes its
# text from the style summary. Enumerated rather than "recurse into anything
# unknown" so the tracked-change wrappers keep their own handling below and a
# non-content element cannot smuggle runs in.
_TRANSPARENT_RUN_CONTAINERS = frozenset(
    {
        "hyperlink",
        "fldSimple",
        "sdt",
        "sdtContent",
        "smartTag",
        "customXml",
        "dir",
        "bdo",
    }
)


_REVISION_TAGS = ("w:ins", "w:del", "w:moveFrom", "w:moveTo")
_COMMENT_TAGS = ("w:commentRangeStart", "w:commentRangeEnd", "w:commentReference")


def _has_descendant(p: Element, tags: tuple[str, ...]) -> bool:
    """True when the paragraph contains any of `tags`, at any depth."""
    return any(next(p.iter(qn(tag)), None) is not None for tag in tags)


_MARK_REVISION_LABELS = {"ins": "INSERTED", "del": "DELETED"}


def _mark_revisions(ppr: Element | None) -> list[dict[str, Any]]:
    """Revisions on the paragraph MARK itself — `w:pPr/w:rPr/w:ins` or `w:del`.

    That is how Word tracks a whole-paragraph insertion or deletion, and it
    produces no run and therefore no segment: 2,002 paragraphs across a
    146-document corpus carry one with no run-level revision anywhere in the
    same paragraph. `has_revisions` alone says only that something happened,
    so the type and the author were unrecoverable downstream.
    """
    if ppr is None:
        return []
    rpr = ppr.find(qn("w:rPr"))
    if rpr is None:
        return []
    out: list[dict[str, Any]] = []
    for el in rpr:
        label = _MARK_REVISION_LABELS.get(etree.QName(el).localname)
        if label is not None:
            out.append({"type": label, "author": el.get(qn("w:author"))})
    return out


def _deleted_inside_insert(r: Element, ins: Element) -> bool:
    """True when run `r` sits inside a `w:del` nested in the `w:ins` `ins`.

    `<w:ins><w:del>...</w:del></w:ins>` is text one party inserted and another
    then struck: it carries `w:delText` rather than `w:t`, and it is not part
    of the document as it now reads. Sweeping every descendant run of the
    `w:ins` reports that text as an INSERTION, which shows a judge wording
    that is not in the file — on one turn-3 contract it mis-rendered 32
    paragraphs, two of which exist ONLY as struck text and should have been
    empty. Upstream's *inline* renderer reads only `w:t` inside a `w:ins` and
    so emits nothing for these; dropping the runs here is what matches it.

    The strike itself is not discarded, only kept out of the inline body:
    upstream still lists it (and the pending insertion) in its tracked-change
    appendix, and `_extract_paragraph` records the same in `hidden_revisions`
    so the renderer can attribute the rejection. Dropping the runs here without
    that record would lose the change entirely — which upstream never does.

    Only `w:ins` is filtered. `<w:del><w:ins>...</w:ins></w:del>` keeps every
    descendant run, because upstream's deletion reader takes `w:t` as well as
    `w:delText` and so renders that text as a deletion.
    """
    node = r.getparent()
    while node is not None and node is not ins:
        if etree.QName(node).localname == "del":
            return True
        node = node.getparent()
    return False


def _extract_paragraph(p: Element, comments_by_id: dict[str, str]) -> dict[str, Any]:
    """Extract paragraph-level style + runs + tracked-change segments."""
    ppr = p.find(qn("w:pPr"))
    style_name: str | None = None
    alignment: str | None = None
    indent_left_pt: float | None = None
    indent_first_line_pt: float | None = None
    numbering_id: str | None = None
    numbering_level: str | None = None
    if ppr is not None:
        ps = ppr.find(qn("w:pStyle"))
        if ps is not None:
            style_name = ps.get(qn("w:val"))
        jc = ppr.find(qn("w:jc"))
        if jc is not None:
            alignment = jc.get(qn("w:val"))
        ind = ppr.find(qn("w:ind"))
        if ind is not None:
            indent_left_pt = _twips_to_pt(
                ind.get(qn("w:left")) or ind.get(qn("w:start"))
            )
            indent_first_line_pt = _twips_to_pt(ind.get(qn("w:firstLine")))
        numpr = ppr.find(qn("w:numPr"))
        if numpr is not None:
            numid_el = numpr.find(qn("w:numId"))
            ilvl_el = numpr.find(qn("w:ilvl"))
            if numid_el is not None:
                numbering_id = numid_el.get(qn("w:val"))
            # Upstream keys list membership on `w:numPr` presence and reads
            # `w:ilvl` regardless of `w:numId` (which a paragraph often inherits
            # from its style rather than declaring inline), defaulting to level 0
            # when `w:ilvl` is absent. So `numbering_level` — not `numbering_id` —
            # is the list-membership signal: set it whenever `numPr` is present.
            numbering_level = ilvl_el.get(qn("w:val")) if ilvl_el is not None else "0"

    # Walk children in order; capture runs + tracked-change segments.
    segments: list[dict[str, Any]] = []
    comment_refs: list[str] = []
    # Tracked changes that produce no inline `~~`/`++` marker and are not
    # paragraph-mark revisions, so nothing else in the view attributes them:
    # an insertion one party made and another struck before it was accepted
    # (`<w:ins><w:del>`), which the inline body drops on both sides (upstream's
    # `_ins_text` reads only `w:t`; `_deleted_inside_insert` drops the same runs
    # here). Upstream still lists these in its tracked-change appendix; the
    # renderer surfaces them from here so the rejection — its author and text —
    # is not lost. See `_deleted_inside_insert`.
    hidden_revisions: list[dict[str, Any]] = []

    def _record_comment(bucket: list[str], el: Any) -> None:
        cid = el.get(qn("w:id"))
        if cid and cid in comments_by_id and cid not in bucket:
            bucket.append(cid)

    def walk(children: Any) -> None:
        for child in children:
            tag_local = etree.QName(child).localname
            if tag_local in _TRANSPARENT_RUN_CONTAINERS:
                # Transparent wrappers: their runs are ordinary runs.
                # Recursed rather than swept with iter(w:r) so a tracked
                # change inside one keeps its own classification instead of
                # becoming live text.
                walk(child)
                continue
            _segment(child, tag_local)

    def _segment(child: Any, tag_local: str) -> None:
        if tag_local == "r":
            run = _extract_run_style(child)
            if run["text"] or any(
                run[k] is not None for k in ("font_name", "font_size_pt", "bold")
            ):
                segments.append({"kind": "run", **run})
        elif tag_local in ("ins", "del", "moveFrom", "moveTo"):
            label = {
                "ins": "INSERTED",
                "del": "DELETED",
                "moveFrom": "MOVED_FROM",
                "moveTo": "MOVED_TO",
            }[tag_local]
            inner_runs: list[dict[str, Any]] = []
            for r in child.iter(qn("w:r")):
                if tag_local == "ins" and _deleted_inside_insert(r, child):
                    continue
                run = _extract_run_style(r)
                inner_runs.append(run)
            text = "".join(rr["text"] for rr in inner_runs)
            segments.append(
                {
                    "kind": "tracked_change",
                    "type": label,
                    "author": child.get(qn("w:author")),
                    "date": child.get(qn("w:date")),
                    "text": text,
                    "runs": inner_runs,
                }
            )
            if tag_local == "ins":
                # A `w:del` nested in this `w:ins` is an insertion this party
                # made that another party then struck. Its runs were skipped
                # above (they render no inline marker), so the strike — the
                # rejection a criterion is graded on — would otherwise be lost.
                # Record it, matching upstream's deletion reader (delText, then
                # any plain w:t some tools leave inside a w:del).
                del_records: list[dict[str, Any]] = []
                for d in child.iter(qn("w:del")):
                    d_text = "".join(
                        t.text or ""
                        for t in list(d.iter(qn("w:delText"))) + list(d.iter(qn("w:t")))
                    )
                    del_records.append(
                        {
                            "type": "DELETED",
                            "author": d.get(qn("w:author")),
                            "date": d.get(qn("w:date")),
                            "text": d_text,
                        }
                    )
                # When the whole insertion was struck it also renders no inline
                # marker, so the pending insertion itself is attributed nowhere;
                # surface it too, before its strike, as upstream's appendix
                # does. (A partly-struck insertion keeps its surviving runs
                # inline, so it is already attributed and is not repeated here.)
                if del_records and not text:
                    hidden_revisions.append(
                        {
                            "type": "INSERTED",
                            "author": child.get(qn("w:author")),
                            "date": child.get(qn("w:date")),
                            "text": "".join(r["text"] for r in del_records),
                        }
                    )
                hidden_revisions.extend(del_records)
            # `walk` does not descend into a tracked change — its runs must
            # keep the tracked-change classification — so the branches below
            # never see a comment range nested in one. Swept here instead.
            for marker in child.iter(qn("w:commentRangeStart")):
                _record_comment(comment_refs, marker)
        elif tag_local == "commentRangeStart":
            _record_comment(comment_refs, child)

    walk(p)

    # Every `w:commentReference` id in the paragraph, in document order. A POINT
    # comment carries only a reference (no range), so it never reaches
    # `comment_refs` and would otherwise be anchored nowhere; a ranged comment's
    # end-reference lands here too, but the renderer treats as a point only an id
    # with no range start anywhere in the document (D23).
    comment_ref_ids: list[str] = []
    for marker in p.iter(qn("w:commentReference")):
        cid = marker.get(qn("w:id"))
        if cid and cid in comments_by_id and cid not in comment_ref_ids:
            comment_ref_ids.append(cid)

    plain_text = "".join(seg.get("text", "") for seg in segments if seg.get("text"))

    shading_fills, shading_declared_by = _effective_shading(p, ppr)

    return {
        "style_name": style_name,
        # Upstream's own predicates, deliberately NOT derived from `segments`
        # or `comment_ids`: a paragraph whose MARK was inserted or deleted
        # carries `w:ins` under `w:pPr/w:rPr` and produces no segment at all
        # (48 of 328 paragraphs on a real turn-2 contract), and a point comment
        # leaves a `w:commentReference` with no range to record.
        "has_revisions": _has_descendant(p, _REVISION_TAGS),
        "has_comments": _has_descendant(p, _COMMENT_TAGS),
        # The type and author behind a mark-only `has_revisions`, which no
        # segment carries — see `_mark_revisions`.
        "mark_revisions": _mark_revisions(ppr),
        # Tracked changes that carry no inline marker and are not paragraph
        # marks — a struck-before-accept insertion (`<w:ins><w:del>`) — so the
        # renderer can attribute them; see `hidden_revisions` above.
        "hidden_revisions": hidden_revisions,
        "alignment": alignment,
        # Everything painted behind this paragraph, so an automatic font
        # colour is resolved only when all of it is known light.
        "shading_fills": shading_fills,
        "shading_declared_by": shading_declared_by,
        "table_style": _enclosing_table_style(p),
        "indent_left_pt": indent_left_pt,
        "indent_first_line_pt": indent_first_line_pt,
        "numbering_id": numbering_id,
        "numbering_level": numbering_level,
        "plain_text": plain_text,
        "segments": segments,
        "comment_ids": comment_refs,
        # Every `w:commentReference` in the paragraph; the renderer places a
        # point comment (a ref with no range start anywhere) here (D23).
        "comment_ref_ids": comment_ref_ids,
    }


_PKG_REL_NS = "http://schemas.openxmlformats.org/package/2006/relationships"
_COMMENTS_REL = (
    "http://schemas.openxmlformats.org/officeDocument/2006/relationships/comments"
)
_COMMENTS_EXTENDED_REL = (
    "http://schemas.microsoft.com/office/2011/relationships/commentsExtended"
)


def _resolve_part(docx_zip: zipfile.ZipFile, rel_type: str, default: str) -> str | None:
    """Part path for a relationship type, resolved via document.xml.rels.

    Word usually writes `comments.xml` / `commentsExtended.xml`, but the part
    name is a RELATIONSHIP target, not a fixed filename — a custom-named target
    is legal, and probing only the default path would flatten every comment
    thread in such a document. Custom targets are followed (relative to `word/`,
    or package-absolute for a leading-slash target); external targets are
    skipped; falls back to `default` when no relationship is declared but the
    conventional part is present.
    """
    try:
        rels = etree.fromstring(
            docx_zip.read("word/_rels/document.xml.rels"), parser=_SAFE_PARSER
        )
    except (KeyError, etree.XMLSyntaxError):
        rels = None
    if rels is not None:
        for rel in rels.iter(f"{{{_PKG_REL_NS}}}Relationship"):
            if rel.get("Type") != rel_type:
                continue
            if (rel.get("TargetMode") or "Internal") == "External":
                continue
            target = rel.get("Target") or ""
            name = target[1:] if target.startswith("/") else f"word/{target}"
            if name in docx_zip.namelist():
                return name
    return default if default in docx_zip.namelist() else None


def _comment_parents(
    docx_zip: zipfile.ZipFile,
    comment_id_by_para_id: dict[str, str],
) -> dict[str, str]:
    """Map ``{reply_comment_id: parent_comment_id}`` from the commentsExtended part.

    Word records threading by ``paraId`` -- the id of the first paragraph
    *inside* a comment body -- rather than by comment id, so the two parts have
    to be joined: ``comment_id_by_para_id`` comes from comments.xml, and
    ``w15:commentEx`` here supplies ``paraId -> paraIdParent``.

    The part is optional; absent, or naming a paraId neither part resolves, the
    thread is reported flat rather than guessed at.
    """
    part = _resolve_part(docx_zip, _COMMENTS_EXTENDED_REL, "word/commentsExtended.xml")
    if part is None:
        return {}
    try:
        tree = etree.fromstring(docx_zip.read(part), parser=_SAFE_PARSER)
    except etree.XMLSyntaxError:
        return {}
    parents: dict[str, str] = {}
    for ex in tree.iter(f"{{{_W15_NS}}}commentEx"):
        para_id = ex.get(f"{{{_W15_NS}}}paraId")
        parent_para_id = ex.get(f"{{{_W15_NS}}}paraIdParent")
        if para_id is None or parent_para_id is None:
            continue
        cid = comment_id_by_para_id.get(para_id)
        parent_cid = comment_id_by_para_id.get(parent_para_id)
        if cid is not None and parent_cid is not None and cid != parent_cid:
            parents[cid] = parent_cid
    return parents


def _load_comments(
    docx_zip: zipfile.ZipFile,
) -> tuple[dict[str, str], dict[str, str], dict[str, str]]:
    """Load comments.xml if present.

    Returns ``({comment_id: text}, {comment_id: author}, {reply_id: parent_id})``.
    The author and parent maps are kept separate so the ``comments`` shape
    callers already consume is unchanged; ``w:author`` is on the ``w:comment``
    element and was previously discarded, which left a comment inherited from
    the counterparty indistinguishable from one the graded model wrote.

    Parentage matters for the same reason authorship does, one step on: most
    RedlineBench tasks are turns 2-4, whose rubrics are about *responding to* an
    existing thread, and a flat list of bodies cannot say which comment answers
    which.
    """
    part = _resolve_part(docx_zip, _COMMENTS_REL, "word/comments.xml")
    if part is None:
        return {}, {}, {}
    try:
        tree = etree.fromstring(docx_zip.read(part), parser=_SAFE_PARSER)
    except etree.XMLSyntaxError:
        return {}, {}, {}
    out: dict[str, str] = {}
    authors: dict[str, str] = {}
    comment_id_by_para_id: dict[str, str] = {}
    for c in tree.iter(qn("w:comment")):
        cid = c.get(qn("w:id"))
        if cid is None:
            continue
        out[cid] = "".join(t.text or "" for t in c.iter(qn("w:t")))
        author = c.get(qn("w:author"))
        if author:
            authors[cid] = author
        # EVERY paragraph of the body, not just the first: Word keys
        # `w15:commentEx` off the comment's LAST paragraph, so indexing only
        # the first silently drops the parentage of every multi-paragraph
        # comment (2 of 30 on a real turn-3 contract, taking 2 of its 3
        # replies with them). paraIds are document-unique, so the wider index
        # cannot collide.
        for body_para in c.iter(qn("w:p")):
            para_id = body_para.get(f"{{{_W14_NS}}}paraId")
            if para_id is not None:
                comment_id_by_para_id[para_id] = cid
    return out, authors, _comment_parents(docx_zip, comment_id_by_para_id)


def _approximate_page_index(
    paragraph_idx: int, total_paragraphs: int, page_count: int
) -> int:
    """Map a paragraph index to a 1-based page bucket.

    DOCX is a flowing format; "pages" only emerge after rendering. We bucket
    paragraphs evenly so page-scoped style criteria have a defined slice to
    grade. This is a coarse approximation — for criteria that need true
    per-page rendering, the image-mode judge sees actual PDF pages.
    """
    if page_count <= 1 or total_paragraphs == 0:
        return 1
    per_page = max(1, (total_paragraphs + page_count - 1) // page_count)
    return min(page_count, (paragraph_idx // per_page) + 1)


def docx_to_style_metadata(
    file_bytes: bytes,
    file_name: str,
    page_count: int | None = None,
    *,
    reuse_doc: Any = None,
    reuse_zip: zipfile.ZipFile | None = None,
) -> dict[str, Any]:
    """Extract style metadata from a DOCX file.

    Args:
        file_bytes: Raw .docx bytes.
        file_name: Filename, included in the output for context.
        page_count: Optional number of pages (from the image renderer). When
            provided, paragraphs are bucketed evenly across pages so a
            page-scoped judge can be given the relevant slice. If None, the
            whole document is treated as a single page.

    Returns:
        {
            "file_name": str,
            "page_count": int,
            "paragraph_count": int,
            "comments": {comment_id: text},
            "comment_authors": {comment_id: author},
            "comment_parents": {reply_comment_id: parent_comment_id},
            "tracked_change_summary": {
                "insertions": int,
                "deletions": int,
                "move_from": int,
                "move_to": int,
            },
            "paragraphs": [
                {
                    "index": int,
                    # Position among the body's DIRECT w:p children, which is
                    # upstream's p-NNN coordinate system; None for a paragraph
                    # nested in a table or other container.
                    "top_level_index": int | None,
                    "style_display_name": str | None,
                    "page": int,
                    "style_name": str | None,
                    "has_revisions": bool,
                    "has_comments": bool,
                    "mark_revisions": [{"type": str, "author": str | None}],
                    "hidden_revisions": [
                        {"type": str, "author": str | None, "text": str}
                    ],
                    "alignment": str | None,
                    "indent_left_pt": float | None,
                    "indent_first_line_pt": float | None,
                    "numbering_id": str | None,
                    "numbering_level": str | None,
                    "plain_text": str,
                    "segments": [...],
                    "comment_ids": [...],
                    "comment_ref_ids": [...],
                },
                ...
            ],
            "pages": [
                {"page": int, "paragraph_indices": [int, ...]},
                ...
            ],
        }
    """
    # reuse_doc/reuse_zip let a caller that has already parsed this document
    # hand them over instead of paying for a second parse. Both default to None
    # so every existing call site is unaffected; _docx_style_summary_xml is the
    # one caller that passes them, because it needs the same document and ZIP
    # for the chart, background and style-inheritance lookups it does itself.
    if reuse_zip is not None:
        comments, comment_authors, comment_parents = _load_comments(reuse_zip)
    else:
        with zipfile.ZipFile(io.BytesIO(file_bytes), "r") as zf:
            comments, comment_authors, comment_parents = _load_comments(zf)

    # python-docx for top-level access (sections, body) is convenient
    doc = reuse_doc if reuse_doc is not None else Document(io.BytesIO(file_bytes))
    body = doc.element.body  # pyright: ignore[reportAttributeAccessIssue]
    p_tag = qn("w:p")

    paragraphs_raw = [p for p in body.iter(p_tag)]
    total_paragraphs = len(paragraphs_raw)
    effective_page_count = page_count if (page_count and page_count > 0) else 1

    paragraphs_out: list[dict[str, Any]] = []
    counts = {"insertions": 0, "deletions": 0, "move_from": 0, "move_to": 0}
    # `body.iter(w:p)` reaches every paragraph including a table cell's, which
    # is what we want to render; upstream's `redline_engine.DocumentView`
    # numbers only the body's DIRECT `w:p` children. Recording the direct-child
    # position separately lets a consumer cite upstream's coordinate system --
    # the one the redliner agent itself reads through -- without losing the
    # nested text from the payload.
    top_level_position = 0
    for idx, p in enumerate(paragraphs_raw):
        meta = _extract_paragraph(p, comments)
        top_level_index: int | None = None
        if p.getparent() is body:
            top_level_index = top_level_position
            top_level_position += 1
        # `p.style.name` resolves the style ID through styles.xml and Word's
        # built-in aliases; `style_name` above is the raw `w:pStyle` ID, which
        # is a different string ("ListParagraph" vs "List Paragraph") and is
        # absent entirely on a default-styled paragraph.
        style = Paragraph(p, doc).style  # pyright: ignore[reportArgumentType]
        page = _approximate_page_index(idx, total_paragraphs, effective_page_count)
        for seg in meta["segments"]:
            if seg.get("kind") != "tracked_change":
                continue
            t = seg.get("type")
            if t == "INSERTED":
                counts["insertions"] += 1
            elif t == "DELETED":
                counts["deletions"] += 1
            elif t == "MOVED_FROM":
                counts["move_from"] += 1
            elif t == "MOVED_TO":
                counts["move_to"] += 1
        paragraphs_out.append(
            {
                "index": idx,
                "top_level_index": top_level_index,
                "style_display_name": style.name if style is not None else None,
                "page": page,
                **meta,
            }
        )

    pages_map: dict[int, list[int]] = {}
    for para in paragraphs_out:
        pages_map.setdefault(para["page"], []).append(para["index"])
    pages_out = [
        {"page": page, "paragraph_indices": pages_map[page]}
        for page in sorted(pages_map.keys())
    ]

    return {
        "file_name": file_name,
        "page_count": effective_page_count,
        "paragraph_count": total_paragraphs,
        "comments": comments,
        "comment_authors": comment_authors,
        "comment_parents": comment_parents,
        "tracked_change_summary": counts,
        "paragraphs": paragraphs_out,
        "pages": pages_out,
    }


# --- Registered transformation for the generic multi-representation judge ---
#
# The dict above is shaped for the docx_style_verifier_apex_v2 eval. What
# follows condenses the same document into a bounded XML block for the generic
# judge, plus two things the dict does not carry: embedded chart fills and the
# page background.
#
# Motivating case: a criterion asked that "all embedded tables and
# charts" have a transparent or #F4EBE8 background. The document had zero
# tables and two charts, both explicitly <a:noFill/> — i.e. compliant. But a
# transparent chart sitting on a tinted page renders as a tinted box, so the
# screenshot-reading judge failed it. The fill is only knowable from the XML.

_CHART_NS = "http://schemas.openxmlformats.org/drawingml/2006/chart"
# word/charts/ holds chartN.xml and chartExN.xml alongside companion
# colors1.xml / style1.xml parts; only the chart bodies are wanted.
_CHART_PART_RE = re.compile(r"word/charts/chart(?:Ex)?\d+\.xml")
# Theme part holding the major/minor font definitions styles.xml points at.
_THEME_PART_RE = re.compile(r"word/theme/theme\d+\.xml")

# Bound the emitted style groups; documents repeat a handful of combinations.
_MAX_RUN_STYLE_GROUPS = 20
_MAX_TABLE_ENTRIES = 12
# Cell fills listed per table; a sample, disclosed as one when truncated.
_MAX_CELL_FILLS = 8
_MAX_CHART_ENTRIES = 12


def _fill_of(sp_pr: "Element | None") -> str | None:
    """Describe a DrawingML <spPr> fill as 'none', '#RRGGBB', or a scheme name.

    Returns None when the element is absent, which in OOXML means "inherit"
    rather than "transparent" — the distinction matters for a criterion that
    accepts transparency, so the two are never collapsed.
    """
    if sp_pr is None:
        return None
    if sp_pr.find(f"{DML_NS}noFill") is not None:
        return "none"
    solid = sp_pr.find(f"{DML_NS}solidFill")
    if solid is None:
        return None
    srgb = solid.find(f"{DML_NS}srgbClr")
    if srgb is not None and srgb.get("val"):
        return f"#{str(srgb.get('val')).upper()}"
    scheme = solid.find(f"{DML_NS}schemeClr")
    if scheme is not None and scheme.get("val"):
        return f"scheme:{scheme.get('val')}"
    return "solid"


def _natural_key(name: str) -> str:
    """Sort key that orders chart10 after chart2.

    OOXML numbers parts sequentially, so the digits carry the ordering. Plain
    lexicographic sorting interleaves them (chart1, chart10, chart11, ...,
    chart2), which would both mislabel the emitted index and, once the entry
    cap truncates the list, keep the wrong charts. Zero-padding the digit runs
    in place keeps the key a plain string, so there is no int/str comparison to
    get wrong.
    """
    return re.sub(r"\d+", lambda m: m.group().zfill(12), name)


def _styles_root(zf: zipfile.ZipFile) -> "Element | None":
    """Parse word/styles.xml once, for the resolvers that both need it.

    _bold_style_ids and _style_run_fonts are called back to back and each used
    to read and parse the same part, so every docx paid two parses of it.
    Returns None when the part is absent or malformed, which both callers
    already treat as "nothing to resolve".
    """
    if "word/styles.xml" not in zf.namelist():
        return None
    try:
        return etree.fromstring(zf.read("word/styles.xml"), parser=_SAFE_PARSER)
    except etree.XMLSyntaxError:
        return None


def _bold_style_ids(
    zf: zipfile.ZipFile,
    root: "Element | None" = None,
) -> frozenset[str]:
    """Style ids whose definition turns bold on, following w:basedOn.

    A run with no w:b inherits from its paragraph style, so reporting such a
    run as not-bold is wrong: Heading1 in the motivating document sets bold at
    the style level and nowhere on the run. The criteria in play are precisely
    about which text is bold, so the distinction has to be resolved rather
    than flattened.
    """
    root = root if root is not None else _styles_root(zf)
    if root is None:
        return frozenset()

    # Tri-state per style: True = w:b turns bold on, False = w:b val="0"
    # turns it *off*, absent = says nothing and defers to w:basedOn. Collapsing
    # the last two into False made an explicit "off" keep walking up the chain,
    # so a style disabling bold while based on a bold parent was reported bold.
    own_bold: dict[str, bool | None] = {}
    based_on: dict[str, str] = {}
    for style in root.iter(qn("w:style")):
        sid = style.get(qn("w:styleId"))
        if not sid:
            continue
        rpr = style.find(qn("w:rPr"))
        b = rpr.find(qn("w:b")) if rpr is not None else None
        own_bold[sid] = None if b is None else _on_off(b)
        parent = style.find(qn("w:basedOn"))
        if parent is not None and parent.get(qn("w:val")):
            based_on[sid] = str(parent.get(qn("w:val")))

    def resolve(sid: str) -> bool:
        # Bounded walk: a malformed basedOn chain can be cyclic. The nearest
        # style that states a value wins, so an explicit off stops the walk
        # instead of letting an ancestor's bold leak through.
        seen: set[str] = set()
        cur = sid
        while cur and cur not in seen:
            seen.add(cur)
            stated = own_bold.get(cur)
            if stated is not None:
                return stated
            cur = based_on.get(cur, "")
        return False

    return frozenset(sid for sid in own_bold if resolve(sid))


def _theme_part_name(zf: zipfile.ZipFile) -> str | None:
    """The theme part the document references, else the lowest-numbered one.

    Editing a document can leave an orphaned theme1.xml behind while the
    document points at theme2.xml; the relationship is the authority.
    """
    parts = sorted(
        (n for n in zf.namelist() if _THEME_PART_RE.fullmatch(n)), key=_natural_key
    )
    if not parts:
        return None
    try:
        rels = etree.fromstring(
            zf.read("word/_rels/document.xml.rels"), parser=_SAFE_PARSER
        )
    except (KeyError, etree.XMLSyntaxError):
        return parts[0]
    for rel in rels.iter(f"{PKG_RELS_NS}Relationship"):
        if not (rel.get("Type") or "").endswith("/theme"):
            continue
        name = _rel_part_name(rel.get("Target") or "")
        if name in parts:
            return name
    return parts[0]


def _theme_fonts(zf: zipfile.ZipFile) -> dict[str, str]:
    """The major/minor latin typefaces the theme defines.

    Word does not write literal font names into styles.xml by default. It
    writes theme references — `w:asciiTheme="minorHAnsi"` — and the actual name
    lives in word/theme/theme1.xml as `<a:minorFont><a:latin typeface="Aptos"/>`.
    Reading only w:ascii therefore resolves nothing on a stock document, which
    is how "only fonts from the Aptos family" failed against a document whose
    theme is Aptos / Aptos Display.
    """
    part = _theme_part_name(zf)
    if part is None:
        return {}
    try:
        root = etree.fromstring(zf.read(part), parser=_SAFE_PARSER)
    except etree.XMLSyntaxError:
        return {}
    out: dict[str, str] = {}
    for slot in ("major", "minor"):
        el = root.find(f".//{DML_NS}{slot}Font/{DML_NS}latin")
        face = el.get("typeface") if el is not None else None
        if face:
            out[slot] = face
    return out


def _style_run_fonts(
    zf: zipfile.ZipFile,
    root: "Element | None" = None,
) -> dict[str, tuple[str | None, float | None]]:
    """Per style id, the font name and size it resolves to, following w:basedOn.

    A run with no w:rFonts or w:sz inherits both from its paragraph style, and
    that is how Word writes documents by default — the motivating document sets
    neither on a single run. The emitter used to omit the attribute entirely in
    that case, and a judge told to treat this block as ground truth read the
    missing attribute as a non-compliant one: "Formats all text using only
    fonts from the Aptos family" failed against a document whose styles do set
    Aptos, purely because no font_name was emitted. That is the same
    absence-as-evidence failure this module exists to remove, so the value has
    to be resolved rather than dropped.

    w:docDefaults is the base of the chain: a style stating nothing inherits
    the document default, which is where Word puts the theme font.
    """
    root = root if root is not None else _styles_root(zf)
    if root is None:
        return {}

    theme = _theme_fonts(zf)

    def _own(rpr: "Element | None") -> tuple[str | None, float | None]:
        if rpr is None:
            return None, None
        fonts = rpr.find(qn("w:rFonts"))
        name = None
        if fonts is not None:
            # Theme first, then the literal. ECMA-376 17.3.2.26 has the theme
            # attribute win when both are present, and Word ships styles
            # carrying both — w:ascii="Calibri" beside
            # w:asciiTheme="minorHAnsi" on a document whose theme is Aptos.
            # Preferring the literal there reports a stale face and fails the
            # very "only Aptos family" criterion this resolution exists to fix.
            # The token names the slot: "major" is the heading face,
            # "minor" the body face.
            token = fonts.get(qn("w:asciiTheme")) or fonts.get(qn("w:hAnsiTheme"))
            if token:
                slot = "major" if str(token).startswith("major") else "minor"
                name = theme.get(slot)
            if not name:
                name = fonts.get(qn("w:ascii")) or fonts.get(qn("w:hAnsi"))
        sz = rpr.find(qn("w:sz"))
        return name, _half_pt_to_pt(sz.get(qn("w:val")) if sz is not None else None)

    # Document defaults sit under w:docDefaults/w:rPrDefault/w:rPr.
    default_font: str | None = None
    default_size: float | None = None
    doc_defaults = root.find(qn("w:docDefaults"))
    if doc_defaults is not None:
        rpr_default = doc_defaults.find(qn("w:rPrDefault"))
        if rpr_default is not None:
            default_font, default_size = _own(rpr_default.find(qn("w:rPr")))

    own: dict[str, tuple[str | None, float | None]] = {}
    based_on: dict[str, str] = {}
    for style in root.iter(qn("w:style")):
        sid = style.get(qn("w:styleId"))
        if not sid:
            continue
        own[sid] = _own(style.find(qn("w:rPr")))
        parent = style.find(qn("w:basedOn"))
        if parent is not None and parent.get(qn("w:val")):
            based_on[sid] = str(parent.get(qn("w:val")))

    def resolve(sid: str) -> tuple[str | None, float | None]:
        # Font and size resolve independently: a style may state a size while
        # inheriting its font, so the walk cannot stop at the first style that
        # states either one. Bounded like the bold walk, since a malformed
        # basedOn chain can be cyclic.
        font: str | None = None
        size: float | None = None
        seen: set[str] = set()
        cur = sid
        while cur and cur not in seen:
            seen.add(cur)
            f, z = own.get(cur, (None, None))
            if font is None:
                font = f
            if size is None:
                size = z
            if font is not None and size is not None:
                break
            cur = based_on.get(cur, "")
        return (
            font if font is not None else default_font,
            size if size is not None else default_size,
        )

    return {sid: resolve(sid) for sid in own}


def _charts_xml(zf: zipfile.ZipFile) -> str:
    """Emit the chart-space and plot-area fill of every embedded chart.

    Matches chart parts exactly rather than by prefix: word/charts/ also holds
    companion colors1.xml / style1.xml parts, and a bare "chart" prefix would
    additionally sweep in chartEx parts. Those are matched deliberately —
    modern chart types (waterfall, treemap, funnel) are stored as chartEx and
    live in their own namespace, so dropping them would understate the count a
    criterion about "all embedded charts" is graded against.
    """
    names = sorted(
        (n for n in zf.namelist() if _CHART_PART_RE.fullmatch(n)),
        key=_natural_key,
    )
    if not names:
        return '  <charts count="0" />\n'

    rows: list[str] = []
    for i, name in enumerate(names[:_MAX_CHART_ENTRIES], start=1):
        try:
            root = etree.fromstring(zf.read(name), parser=_SAFE_PARSER)
        except Exception:
            # Emit a placeholder rather than skipping, so `index` stays dense:
            # a silent gap reads as a numbering error, and a criterion counting
            # charts would be graded against the wrong total.
            #
            # `index` is position in the natural-sorted part-name order, NOT
            # document order. OPC part names reflect creation order, so an
            # edited document can name charts in an order that does not match
            # where they appear on the page, and orphan parts an editing tool
            # left behind still count. For agent-authored documents the two
            # normally coincide, which is why this is left as is — but a
            # criterion about "the third chart" is only reliable to the extent
            # they do. Resolving through document.xml.rels would give true
            # document order if that ever stops holding.
            rows.append(f'    <chart index="{i}" unreadable="true" />')
            continue
        # chartEx uses its own namespace for the same element names, so take
        # the namespace from the root rather than assuming the classic one.
        ns = etree.QName(root).namespace or _CHART_NS
        space_fill = _fill_of(root.find(f"{{{ns}}}spPr"))
        plot = root.find(f".//{{{ns}}}plotArea")
        plot_fill = _fill_of(plot.find(f"{{{ns}}}spPr") if plot is not None else None)
        attrs = f'index="{i}"'
        if ns != _CHART_NS:
            attrs += ' kind="extended"'
        if space_fill is not None:
            attrs += f' chart_background="{xml_escape(space_fill)}"'
        if plot_fill is not None:
            attrs += f' plot_area_background="{xml_escape(plot_fill)}"'
        rows.append(f"    <chart {attrs} />")

    # Only the cap needs a note now — unreadable parts are marked in place
    # above, so the two can no longer be conflated into one "omitted" count.
    over_cap = max(0, len(names) - _MAX_CHART_ENTRIES)
    notes: list[str] = []
    if over_cap:
        notes.append(f"    <!-- {over_cap} more charts omitted -->")
    body = "\n".join([*rows, *notes])
    return f'  <charts count="{len(names)}">\n{body}\n  </charts>\n'


def _shd_fill(el: "Element | None") -> str | None:
    """The fill of a w:shd child of `el`, normalised, or None."""
    if el is None:
        return None
    shd = el.find(qn("w:shd"))
    if shd is None:
        return None
    fill = shd.get(qn("w:fill"))
    if not fill:
        return None
    return "none" if fill.lower() in ("auto", "none") else f"#{fill.upper()}"


def _owned_by(el: "Element", tbl: "Element") -> bool:
    """Whether `el`'s nearest enclosing table is `tbl`.

    Descendant search with an ownership test, rather than direct children:
    findall() misses rows wrapped in w:sdt (a content control, common in Word
    templates) and would silently under-report their shading, while a plain
    iter() hands a nested table's fills to its parent as well. Walking up to the
    closest w:tbl gets both right.
    """
    parent = el.getparent()
    while parent is not None:
        if parent.tag == qn("w:tbl"):
            return parent is tbl
        parent = parent.getparent()
    return False


def _tables_xml(body: "Element") -> str:
    """Emit table count, each table's cell shading, and its table-wide shading.

    Shading is read from specific parents rather than by walking descendants.
    w:shd is valid on w:rPr and w:pPr as well as w:tcPr and w:tblPr, so an
    iter() over the table reported highlighted *text* inside a cell as
    cell_backgrounds — asserting a cell fill that does not exist, which is worse
    than omitting one. Table-wide shading is reported separately rather than
    folded in, since "the table has a background" and "its cells do" are
    different claims and a criterion may ask either.

    Rows and cells are matched by ownership rather than by depth — see
    _owned_by — so a nested table keeps its own fills while a row wrapped in a
    content control is still found.
    """
    tables = list(body.iter(qn("w:tbl")))
    if not tables:
        return '  <tables count="0" />\n'

    rows_out: list[str] = []
    for i, tbl in enumerate(tables[:_MAX_TABLE_ENTRIES], start=1):
        table_rows = [r for r in tbl.iter(qn("w:tr")) if _owned_by(r, tbl)]
        fills: list[str] = []
        for cell in tbl.iter(qn("w:tc")):
            if not _owned_by(cell, tbl):
                continue
            fill = _shd_fill(cell.find(qn("w:tcPr")))
            if fill and fill not in fills:
                fills.append(fill)

        attrs = f'index="{i}" rows="{len(table_rows)}"'
        table_fill = _shd_fill(tbl.find(qn("w:tblPr")))
        if table_fill:
            attrs += f' table_background="{xml_escape(table_fill)}"'
        if fills:
            shown = fills[:_MAX_CELL_FILLS]
            attrs += f' cell_backgrounds="{xml_escape(",".join(shown))}"'
            # Disclose the cap. A criterion like "all tables have the right
            # colour" reads an 8-value list as the table's complete set of
            # fills, so a 9th differing cell would be invisible — absence
            # taken as evidence, which is the failure this block exists to
            # remove.
            if len(fills) > len(shown):
                attrs += f' cell_backgrounds_listed="{len(shown)} of {len(fills)}"'
        else:
            attrs += ' cell_backgrounds="unset"'
        rows_out.append(f"    <table {attrs} />")

    omitted = len(tables) - len(rows_out)
    tail = f"\n    <!-- {omitted} more tables omitted -->" if omitted > 0 else ""
    return (
        f'  <tables count="{len(tables)}">\n'
        + "\n".join(rows_out)
        + tail
        + "\n  </tables>\n"
    )


# Link entries listed before summarising the rest, and the characters of link
# text kept per entry. Same disclose-the-cap rule as the tables above.
# Per KIND, not per section: hyperlinks, HYPERLINK fields and cross-references
# are capped independently so a document with many of one does not hide the
# others entirely. A shared cap would let 50 hyperlinks crowd out every
# cross-reference, and "do the cross-references resolve" is its own criterion.
# The omitted count below sums the per-kind overflow, so the total stays
# disclosed either way.
_MAX_LINK_ENTRIES_PER_KIND = 12
_MAX_BOOKMARK_NAMES = 24
_LINK_TEXT_CHARS = 60

# Field types that constitute a cross-reference. HYPERLINK is deliberately
# absent: it is a link, not a reference to another part of the document, and
# the two are separate claims a criterion may ask about.
_XREF_INSTRUCTIONS = ("REF", "PAGEREF", "NOTEREF")


class _Field(NamedTuple):
    """One Word field instance: its instruction and its displayed result."""

    instr: str
    text: str
    in_hyperlink: bool


def _has_ancestor(el: "Element", tag: str) -> bool:
    parent = el.getparent()
    while parent is not None:
        if parent.tag == tag:
            return True
        parent = parent.getparent()
    return False


def _field_instances(body: "Element") -> list[_Field]:
    """Every Word field in document order, with its displayed result text.

    A field is not one element: Word splits it into a w:fldChar "begin", one or
    more w:instrText carrying the instruction, a "separate", the runs holding
    the result the reader actually sees, and an "end". Reading only instrText
    gives the instruction with no way to tell WHICH issue a cross-reference
    points at, which is what a criterion asks. Fields nest (a REF inside a
    hyperlink inside a TOC), so the open fields are kept on a stack and text is
    attributed to the innermost.

    The older w:fldSimple spelling carries its instruction as an attribute and
    its result as children, so it is collected separately.
    """
    fields: list[_Field] = []
    stack: list[dict[str, Any]] = []

    for el in body.iter():
        tag = el.tag
        if tag == qn("w:fldChar"):
            char_type = el.get(qn("w:fldCharType"))
            if char_type == "begin":
                stack.append({"instr": [], "text": [], "in_result": False, "el": el})
            elif char_type == "separate" and stack:
                stack[-1]["in_result"] = True
            elif char_type == "end" and stack:
                done = stack.pop()
                text = "".join(done["text"]).strip()
                fields.append(
                    _Field(
                        "".join(done["instr"]).strip(),
                        text,
                        _has_ancestor(done["el"], qn("w:hyperlink")),
                    )
                )
                # A field can nest inside another, and the inner field's
                # result IS part of what the outer one displays. Attributing
                # the text only to the innermost left a wrapping HYPERLINK
                # with no label, so a criterion naming the link text could
                # not identify it.
                if stack and text:
                    stack[-1]["text"].append(text)
        elif tag == qn("w:instrText") and stack:
            stack[-1]["instr"].append(el.text or "")
        elif tag == qn("w:t") and stack and stack[-1]["in_result"]:
            stack[-1]["text"].append(el.text or "")
        elif tag == qn("w:fldSimple"):
            # Collected in the same traversal as the complex form, so the
            # entry cap drops the last fields rather than one spelling.
            fields.append(
                _Field(
                    (el.get(qn("w:instr")) or "").strip(),
                    "".join(t.text or "" for t in el.iter(qn("w:t"))).strip(),
                    _has_ancestor(el, qn("w:hyperlink")),
                )
            )

    return fields


def _instruction_name(instr: str) -> str:
    """The field type — the first word of the instruction, upper-cased."""
    parts = instr.split()
    return parts[0].upper() if parts else ""


def _xref_target(instr: str) -> str | None:
    """The bookmark a REF/PAGEREF/NOTEREF instruction points at."""
    parts = instr.split()
    return parts[1] if len(parts) > 1 else None


def _hyperlink_targets(
    zf: zipfile.ZipFile, part: str = "word/document.xml"
) -> dict[str, str]:
    """rId -> external target, from one part's own relationships."""
    directory, _, name = part.rpartition("/")
    try:
        rels = etree.fromstring(
            zf.read(f"{directory}/_rels/{name}.rels"), parser=_SAFE_PARSER
        )
    except (KeyError, etree.XMLSyntaxError):
        return {}
    out: dict[str, str] = {}
    for rel in rels.iter(f"{PKG_RELS_NS}Relationship"):
        rid, target = rel.get("Id"), rel.get("Target")
        if rid and target and rel.get("TargetMode") == "External":
            out[rid] = target
    return out


def _hyperlink_field_target(instr: str) -> tuple[str, str]:
    r"""(url, anchor) for a HYPERLINK field instruction.

    Word writes the destination quoted or bare and marks an in-document target
    with the \l switch. Tokenised rather than split on the substring "\l",
    because a bare Windows or UNC path contains one — C:\links\report.docx
    would otherwise be cut into a mangled url and a bookmark that does not
    exist, and both are handed to the judge as ground truth.
    """
    tokens = re.findall(r'"[^"]*"|\S+', instr)
    url = anchor = ""
    # What the next operand belongs to. \l names a bookmark; \o (ScreenTip)
    # and \t (target frame) also take one, and treating those as switches
    # without operands let a tooltip become the link's destination — reporting
    # an internal link as external, which is a fabricated fact rather than a
    # missing one. \m and \n take no operand.
    pending: str | None = None
    for token in tokens:
        if token.upper() == "HYPERLINK":
            continue
        if re.fullmatch(r"\\[a-zA-Z]", token):
            switch = token.lower()
            pending = (
                "anchor"
                if switch == "\\l"
                else "discard"
                if switch in ("\\o", "\\t")
                else None
            )
            continue
        value = token[1:-1] if token.startswith('"') and token.endswith('"') else token
        if pending == "anchor":
            anchor = anchor or value
        elif pending != "discard":
            url = url or value
        pending = None
    return url, anchor


def _destination_attr(key: str, value: str) -> str:
    """A link destination, saying so when it had to be cut.

    An exact-URL criterion cannot tell a truncated destination from a short
    one, so a silent cut reads as a complete value that simply does not match.
    """
    if len(value) <= _LINK_TEXT_CHARS:
        return f' {key}="{xml_escape(value)}"'
    return (
        f' {key}="{xml_escape(value[:_LINK_TEXT_CHARS])}"'
        f' {key}_truncated="{len(value)} chars"'
    )


def _links_xml(sources: list[tuple[str, Any, dict[str, str]]]) -> str:
    """Emit hyperlinks, cross-reference fields, and the bookmarks they target.

    The navigation target and the field's source bookmark are reported
    SEPARATELY and never reconciled: a cross-reference inserted as a hyperlink
    can navigate to one bookmark while displaying text pulled from another, so
    collapsing them would state the link goes somewhere it does not.
    """
    # Collected across every part that can hold a link, not just the body:
    # a footer holding a company URL reported as zero hyperlinks while the
    # attribute name claimed document-wide coverage.
    hyperlinks: list[tuple[str, Any]] = []
    field_links: list[tuple[str, _Field]] = []
    xrefs: list[tuple[str, _Field]] = []
    bookmarks: list[str] = []
    targets_by_part: dict[str, dict[str, str]] = {}

    for part, root, rel_targets in sources:
        targets_by_part[part] = rel_targets
        hyperlinks.extend((part, h) for h in root.iter(qn("w:hyperlink")))
        for field in _field_instances(root):
            name = _instruction_name(field.instr)
            # A HYPERLINK field wrapped in a w:hyperlink is the same single
            # link, so only the unwrapped ones are counted here.
            if name == "HYPERLINK" and not field.in_hyperlink:
                field_links.append((part, field))
            # First WORD, not a prefix: "REFX" is not a cross-reference.
            elif name in _XREF_INSTRUCTIONS:
                xrefs.append((part, field))
        bookmarks.extend(
            n
            for b in root.iter(qn("w:bookmarkStart"))
            if (n := b.get(qn("w:name"))) and n != "_GoBack"
        )

    header = (
        f'  <links hyperlinks="{len(hyperlinks) + len(field_links)}" '
        f'cross_reference_fields="{len(xrefs)}" '
        f'bookmarks="{len(bookmarks)}">\n'
    )

    def part_attr(part: str) -> str:
        """Name the part unless it is the body, so a header link is not read
        as body content."""
        return (
            ""
            if part == "word/document.xml"
            else f' part="{xml_escape(part.rpartition("/")[2])}"'
        )

    rows: list[str] = []
    for part, link in hyperlinks[:_MAX_LINK_ENTRIES_PER_KIND]:
        anchor = link.get(qn("w:anchor"))
        rid = link.get(f"{OFFICE_RELS_NS}id")
        text = "".join(t.text or "" for t in link.iter(qn("w:t"))).strip()
        if anchor:
            attrs = f'kind="internal" navigates_to="{xml_escape(anchor)}"'
            attrs += f' target_exists="{str(anchor in bookmarks).lower()}"'
        elif rid:
            url = targets_by_part.get(part, {}).get(rid)
            attrs = 'kind="external"'
            if url:
                attrs += _destination_attr("url", url)
        else:
            attrs = 'kind="unknown"'
        inner = "".join(i.text or "" for i in link.iter(qn("w:instrText"))).strip()
        if inner:
            # The displayed text of such a link comes from THIS field's
            # bookmark, which need not be the one w:anchor navigates to.
            attrs += f' displays_field="{xml_escape(inner[:_LINK_TEXT_CHARS])}"'
        if text:
            attrs += f' text="{xml_escape(text[:_LINK_TEXT_CHARS])}"'
        rows.append(f"    <hyperlink {attrs}{part_attr(part)} />")

    for part, field in field_links[:_MAX_LINK_ENTRIES_PER_KIND]:
        url, anchor = _hyperlink_field_target(field.instr)
        attrs = f'kind="{"internal" if anchor and not url else "external"}"'
        attrs += ' stored_as="field"'
        if url:
            attrs += _destination_attr("url", url)
        if anchor:
            attrs += _destination_attr("navigates_to", anchor)
            attrs += f' target_exists="{str(anchor in bookmarks).lower()}"'
        if field.text:
            attrs += f' text="{xml_escape(field.text[:_LINK_TEXT_CHARS])}"'
        rows.append(f"    <hyperlink {attrs}{part_attr(part)} />")

    for part, field in xrefs[:_MAX_LINK_ENTRIES_PER_KIND]:
        target = _xref_target(field.instr)
        attrs = f'field="{xml_escape(_instruction_name(field.instr))}"'
        if target:
            attrs += f' target="{xml_escape(target)}"'
            attrs += f' target_exists="{str(target in bookmarks).lower()}"'
        attrs += f' inside_hyperlink="{str(field.in_hyperlink).lower()}"'
        if field.text:
            attrs += f' text="{xml_escape(field.text[:_LINK_TEXT_CHARS])}"'
        rows.append(f"    <cross_reference {attrs}{part_attr(part)} />")

    if bookmarks:
        shown = bookmarks[:_MAX_BOOKMARK_NAMES]
        attrs = f'names="{xml_escape(",".join(shown))}"'
        if len(bookmarks) > len(shown):
            attrs += f' names_listed="{len(shown)} of {len(bookmarks)}"'
        rows.append(f"    <bookmarks {attrs} />")

    omitted = (
        max(0, len(hyperlinks) - _MAX_LINK_ENTRIES_PER_KIND)
        + max(0, len(field_links) - _MAX_LINK_ENTRIES_PER_KIND)
        + max(0, len(xrefs) - _MAX_LINK_ENTRIES_PER_KIND)
    )
    tail = f"\n    <!-- {omitted} more link entries omitted -->" if omitted else ""
    return header + "\n".join(rows) + tail + "\n  </links>\n"


def _page_background_xml(zf: zipfile.ZipFile, doc_root: "Element") -> str:
    """Emit the page background colour and whether Word actually displays it.

    w:background is inert unless settings.xml opts in via
    displayBackgroundShape, so reporting the colour without that flag would
    overstate what a reader sees.
    """
    bg = doc_root.find(qn("w:background"))
    color = bg.get(qn("w:color")) if bg is not None else None
    if color is None and bg is not None:
        color = bg.get("color")
    displayed = False
    if "word/settings.xml" in zf.namelist():
        try:
            st = etree.fromstring(zf.read("word/settings.xml"), parser=_SAFE_PARSER)
            dbs = st.find(qn("w:displayBackgroundShape"))
            displayed = dbs is not None and _on_off(dbs)
        except etree.XMLSyntaxError:
            displayed = False
    # w:color legitimately carries the literal "auto" (no explicit colour), not
    # just a hex triplet — emitting it verbatim produced color="#AUTO", which is
    # not a colour and reads to the judge like a deliberate fill. The run-colour
    # extractor above already screens "auto"; this now matches it.
    if color is None or color.lower() in ("auto", "none"):
        return f'  <page_background color="unset" displayed="{str(displayed).lower()}" />\n'
    return (
        f'  <page_background color="#{xml_escape(color.upper())}" '
        f'displayed="{str(displayed).lower()}" />\n'
    )


# Header and footer parts, in the order Word numbers them.
_HDR_FTR_RE = re.compile(r"word/(header|footer)\d+\.xml$")

# Characters of header/footer text kept, enough to identify a slogan.
_HDR_FTR_TEXT_CHARS = 80

# Header/footer parts listed. Word allows three of each per section, so a
# many-section document has many parts and this was the one section that
# emitted all of them — nothing downstream caps the text, and the metadata
# cache bounds entry count rather than size.
_MAX_HDR_FTR_PARTS = 8


def _rel_part_name(target: str) -> str:
    """A relationship Target as a package part name.

    A Target may be relative to the document part ("header1.xml") or
    package-absolute ("/word/header1.xml"). Prefixing "word/" unconditionally
    turned the absolute form into "word/word/header1.xml", which matched no
    part — so a document using that spelling reported no headers at all and
    its running header vanished from the metadata.
    """
    if target.startswith("/"):
        return target.lstrip("/")
    return f"word/{target}"


def _referenced_header_parts(
    zf: zipfile.ZipFile,
    doc_root: "Element",
) -> list[str]:
    """Header/footer parts the document actually renders, in part order.

    Orphaned parts that no sectPr points at are excluded — Word never renders
    them. Falls back to every part only when the relationships are unreadable.

    A referenced part is not necessarily a rendered one. A "first" header is
    painted only where its section sets w:titlePg, and an "even" header only
    where settings.xml opts the document into w:evenAndOddHeaders. Word leaves
    both references behind when the options are turned off, so reading the
    reference alone put text no reader sees in front of the judge — and a
    criterion about the header then answers off the wrong one.
    """
    all_parts = sorted(
        (n for n in zf.namelist() if _HDR_FTR_RE.match(n)), key=_natural_key
    )
    try:
        rels = etree.fromstring(
            zf.read("word/_rels/document.xml.rels"), parser=_SAFE_PARSER
        )
    except (KeyError, etree.XMLSyntaxError):
        return all_parts

    target_of = {
        rel.get("Id"): _rel_part_name(rel.get("Target") or "")
        for rel in rels.iter(f"{PKG_RELS_NS}Relationship")
    }
    rid = f"{OFFICE_RELS_NS}id"

    # Document-wide, unlike titlePg — one setting governs every section.
    even_rendered = False
    if "word/settings.xml" in zf.namelist():
        try:
            settings = etree.fromstring(
                zf.read("word/settings.xml"), parser=_SAFE_PARSER
            )
        except etree.XMLSyntaxError:
            settings = None
        if settings is not None:
            flag = settings.find(qn("w:evenAndOddHeaders"))
            even_rendered = flag is not None and _on_off(flag)

    referenced: list[str] = []
    # Per section, because titlePg is a property of the section: the same
    # "first" part can render in one section and not in another.
    #
    # A section that declares no reference of a kind inherits the previous
    # section's — this is what "Link to Previous" writes, or rather what it
    # omits. So the reference in force is carried forward rather than read off
    # the section alone: a first-page header declared in one section and
    # switched on by titlePg in the NEXT renders there, and looking only at
    # the section's own children lost it.
    # A w:sectPrChange holds the section as it was BEFORE a tracked edit, and
    # it nests a whole w:sectPr inside the live one. Walking every w:sectPr
    # descendant treated that snapshot as a section of its own, so a header the
    # edit replaced was reported as one the document still paints.
    historical = {
        old
        for change in doc_root.iter(qn("w:sectPrChange"))
        for old in change.iter(qn("w:sectPr"))
    }

    in_force: dict[tuple[str, str], list[str]] = {}
    for sect_pr in doc_root.iter(qn("w:sectPr")):
        if sect_pr in historical:
            continue
        title_pg = sect_pr.find(qn("w:titlePg"))
        first_rendered = title_pg is not None and _on_off(title_pg)
        for tag in ("headerReference", "footerReference"):
            # Declaring a kind REPLACES what was inherited for it; declaring
            # none inherits. Kept as a list because what a section declares is
            # taken as declared — a well-formed section names one part per
            # kind, and silently keeping the last of several would drop parts
            # this is supposed to be enumerating.
            declared: dict[str, list[str]] = {}
            # findall, not iter: a reference is a direct child of the section,
            # and descending would collect the ones inside its sectPrChange as
            # though this section had declared them.
            for ref in sect_pr.findall(qn(f"w:{tag}")):
                kind = ref.get(qn("w:type")) or "default"
                declared.setdefault(kind, []).append(ref.get(rid) or "")
            for kind, rids in declared.items():
                in_force[(tag, kind)] = rids
            for kind in ("default", "first", "even"):
                if kind == "first" and not first_rendered:
                    continue
                if kind == "even" and not even_rendered:
                    continue
                for ref_id in in_force.get((tag, kind), []):
                    part = target_of.get(ref_id)
                    if part in all_parts and part not in referenced:
                        referenced.append(part)
    return sorted(referenced, key=_natural_key)


def _headers_footers_xml(
    zf: zipfile.ZipFile,
    doc_root: "Element",
    bold_style_ids: frozenset[str],
    style_fonts: dict[str, tuple[str | None, float | None]],
    page_background_is_dark: bool = False,
    shaded_style_ids: dict[str, frozenset[str]] | None = None,
) -> str:
    """Emit the text and run styles of every header and footer part.

    Its own section rather than folded into <run_styles>: a criterion about
    body text must not start matching header runs, and the existing run-style
    groups must not shift under criteria already written against them.
    """
    parts = _referenced_header_parts(zf, doc_root)
    if not parts:
        # Same load-bearing count as the tables and links above: without it,
        # a document with no header is indistinguishable from one whose
        # header went unread.
        return '  <headers_footers count="0" />\n'

    # Split the window between headers and footers instead of slicing the
    # sorted list: "footer" sorts before "header", so a plain slice dropped
    # every header once a document had enough footers to fill the cap.
    headers = [n for n in parts if "/header" in n]
    footers = [n for n in parts if "/header" not in n]
    half = _MAX_HDR_FTR_PARTS // 2
    shown = headers[: max(half, _MAX_HDR_FTR_PARTS - len(footers))]
    shown += footers[: _MAX_HDR_FTR_PARTS - len(shown)]
    shown = sorted(shown, key=_natural_key)

    blocks: list[str] = []
    for name in shown:
        try:
            root = etree.fromstring(zf.read(name), parser=_SAFE_PARSER)
        except (KeyError, etree.XMLSyntaxError) as e:
            blocks.append(
                f'    <header_footer part="{xml_escape(name.split("/")[-1])}" '
                f'unreadable="{xml_escape(type(e).__name__)}" />'
            )
            continue

        paragraphs = [_extract_paragraph(p, {}) for p in root.iter(qn("w:p"))]
        text = " ".join(
            t.strip()
            for para in paragraphs
            for seg in para.get("segments", [])
            for t in [str(seg.get("text") or "")]
            if t.strip()
        )
        kind = "header" if "/header" in name else "footer"
        attrs = f' kind="{kind}" part="{xml_escape(name.split("/")[-1])}"'
        if text:
            attrs += f' text="{xml_escape(text[:_HDR_FTR_TEXT_CHARS])}"'
        blocks.append(
            _run_styles_xml(
                paragraphs,
                bold_style_ids,
                style_fonts,
                tag="header_footer",
                extra_attrs=attrs,
                indent="    ",
                sample_text=True,
                page_background_is_dark=page_background_is_dark,
                shaded_style_ids=shaded_style_ids,
            ).rstrip("\n")
        )

    omitted = len(parts) - len(shown)
    tail = (
        f"\n    <!-- {omitted} more header/footer parts omitted -->" if omitted else ""
    )
    return (
        f'  <headers_footers count="{len(parts)}">\n'
        + "\n".join(blocks)
        + tail
        + "\n  </headers_footers>\n"
    )


_SHADING_LAYERS = ("paragraph", "cell", "table", "run")


def _style_paints_dark(
    style_id: str | None,
    shaded: dict[str, frozenset[str]],
    overridden: set[str],
) -> bool:
    """Whether `style_id` paints a not-known-light layer nothing overrode.

    A style can set w:pPr, w:rPr, w:tcPr and w:tblPr at once, so asking only
    about the layer its NAME suggests missed the rest: a paragraph style that
    shades through w:rPr, or a table style that shades through w:pPr, was
    recorded and then never consulted. Direct formatting silences the one layer
    it sits on, not the style.
    """
    if not style_id:
        return False
    return any(
        style_id in shaded[layer] and layer not in overridden
        for layer in _SHADING_LAYERS
    )


def _shaded_style_ids(
    zf: zipfile.ZipFile,
    root: "Element | None" = None,
) -> dict[str, frozenset[str]]:
    """Style ids that paint a dark or unresolvable background behind text.

    Shading can come from the paragraph STYLE rather than the paragraph, and
    reading only the direct w:shd meant a styled dark block looked like a
    plain white page — automatic text over it resolved to black although Word
    renders it light.

    Character styles count too — their fill lives in w:rPr, and a run
    wearing one sits on that background whatever the paragraph does.

    Table styles count too, and through every holder they can paint from:
    w:tcPr, w:tblPr and the conditional w:tblStylePr bands. A table style is
    how Word paints most shaded tables, and reading only direct formatting
    resolved automatic text to black inside a cell the style paints navy.

    Follows w:basedOn like _bold_style_ids and _style_run_fonts: a style that
    inherits its fill states nothing itself, so stopping at the style's own
    w:shd treated it as unshaded. Tri-state per style for the same reason bold
    is: an explicit light fill must STOP the walk rather than let an
    ancestor's dark fill leak through.
    """
    root = root if root is not None else _styles_root(zf)
    if root is None:
        return {layer: frozenset() for layer in _SHADING_LAYERS}

    own_dark: dict[str, dict[str, bool | None]] = {}
    based_on: dict[str, str] = {}
    for style in root.iter(qn("w:style")):
        sid = style.get(qn("w:styleId"))
        if not sid:
            continue
        # Every holder a style can paint from. A paragraph style uses w:pPr;
        # a table style paints cells through w:tcPr/w:tblPr and the
        # conditional w:tblStylePr bands, and any of them can be the one
        # behind the text.
        # Tagged with the LAYER each paints, because a holder's own w:shd
        # overrides only the layer it sits on. A cell that clears itself beats
        # the style's per-cell fill; the style's table-level fill is a
        # different layer and still renders behind it.
        holders = [
            ("paragraph", style.find(qn("w:pPr"))),
            ("cell", style.find(qn("w:tcPr"))),
        ]
        # A character style carries its shading in w:rPr, and it sits closest
        # of all to the text.
        holders.append(("run", style.find(qn("w:rPr"))))
        holders.append(("table", style.find(qn("w:tblPr"))))
        for cond in style.iter(qn("w:tblStylePr")):
            holders.append(("cell", cond.find(qn("w:tcPr"))))
            holders.append(("table", cond.find(qn("w:tblPr"))))
        # Through _shading_state like the run and holder paths. This is the
        # THIRD reader of w:shd, and it is the one that reads styles.xml. When
        # it kept its own copy of the parsing, a pct25 pattern read as a fill
        # here while the identical w:shd on a run read as unresolvable, and a
        # style that cleared its parent's dark fill inherited it anyway.
        stated: dict[str, bool | None] = {}
        for layer, holder in holders:
            shd = holder.find(qn("w:shd")) if holder is not None else None
            if shd is None:
                continue
            fill, overrides = _shading_state(shd)
            if fill == _UNKNOWN_SHADING:
                # A pattern or an unresolvable themeFill: not known light.
                stated[layer] = True
            elif fill:
                if not _is_known_light(fill):
                    stated[layer] = True
                elif stated.get(layer) is not True:
                    # An explicit light fill answers this layer unless a later
                    # holder on the same layer paints something darker.
                    stated[layer] = False
            elif overrides:
                # w:val="nil" -- this style states this LAYER paints nothing,
                # stopping the basedOn walk for that layer rather than letting
                # a parent's dark fill leak through.
                stated.setdefault(layer, False)
        own_dark[sid] = stated
        parent = style.find(qn("w:basedOn"))
        if parent is not None and parent.get(qn("w:val")):
            based_on[sid] = str(parent.get(qn("w:val")))

    def resolve(sid: str, layer: str) -> bool:
        """Whether `sid` paints a not-known-light background on `layer`.

        Per layer, because a style can paint dark at table level while saying
        nothing per cell. Collapsing the two let a cell that cleared its own
        shading suppress the table-level fill still rendering behind it.
        """
        seen: set[str] = set()
        cur = sid
        while cur and cur not in seen:
            seen.add(cur)
            said = own_dark.get(cur, {}).get(layer)
            if said is not None:
                return said
            cur = based_on.get(cur, "")
        return False

    return {
        layer: frozenset(sid for sid in own_dark if resolve(sid, layer))
        for layer in _SHADING_LAYERS
    }


def _run_styles_xml(
    paragraphs: list[dict[str, Any]],
    bold_style_ids: frozenset[str] = frozenset(),
    style_fonts: dict[str, tuple[str | None, float | None]] | None = None,
    tag: str = "run_styles",
    extra_attrs: str = "",
    indent: str = "  ",
    sample_text: bool = False,
    page_background_is_dark: bool = False,
    shaded_style_ids: dict[str, frozenset[str]] | None = None,
) -> str:
    """Collapse runs into (paragraph style, bold, colour, size, font) groups.

    Paragraph style is part of the key because the criteria that need this
    distinguish header text from body text — "all bolded non-header body text
    is #CD8D81" is unanswerable from run properties alone.
    """
    groups: dict[tuple[Any, ...], int] = {}
    # Only populated when a caller asks. A style group says nothing about
    # WHICH text carries it, and in a two-run header ("slogan at 8pt, tagline
    # at 10pt") that leaves the judge guessing which group a criterion about
    # the slogan refers to. Body run styles deliberately stay without it: they
    # are collapsed across hundreds of runs where one sample would mislead.
    samples: dict[tuple[Any, ...], str] = {}
    for para in paragraphs:
        pstyle = para.get("style_name") or "Normal"
        for seg in para.get("segments", []):
            runs = (
                [seg]
                if seg.get("kind") == "run"
                else list(seg.get("runs", []))
                if seg.get("kind") == "tracked_change"
                else []
            )
            for run in runs:
                if not str(run.get("text") or "").strip():
                    continue
                # Tri-state, not bool(): the extractor returns None when the
                # run carries no w:b at all, which means "inherit from the
                # paragraph style". Collapsing that to False reported Heading1
                # text as not bold even though its style sets bold.
                raw_bold = run.get("bold")
                if raw_bold is None:
                    bold = "true" if pstyle in bold_style_ids else "unset"
                    source = "paragraph_style" if bold == "true" else None
                else:
                    bold = "true" if raw_bold else "false"
                    source = None
                # Tri-state as bold is: a run with no w:rFonts/w:sz takes
                # them from its paragraph style, which is how Word writes
                # documents by default.
                inherited_font, inherited_size = (style_fonts or {}).get(
                    pstyle, (None, None)
                )
                size = run.get("font_size_pt")
                size_source = None
                if size is None and inherited_size is not None:
                    size, size_source = inherited_size, "paragraph_style"
                font = run.get("font_name")
                font_source = None
                if not font and inherited_font:
                    font, font_source = inherited_font, "paragraph_style"
                # w:color val="auto" renders black only over a light
                # background, so it is resolved only when the background is
                # known light and left as "auto" otherwise.
                color = run.get("color_hex")
                color_source = None
                if color is None and run.get("color_auto"):
                    # Every background that applies, with no precedence
                    # between them: run, paragraph, cell, table, character
                    # style, paragraph style, table style, page. Black is
                    # reported only if all of them are
                    # known light; anything dark or unreadable leaves the
                    # value "auto". Ordering these was the source of repeated
                    # bugs and is not needed — where they agree the answer is
                    # the same, and where they disagree it is "unresolved".
                    layers = para.get("shading_fills", [])
                    # Declared, not merely resolved: a holder that cleared its
                    # shading has still overridden its style.
                    declared = para.get("shading_declared_by") or ()
                    shaded = shaded_style_ids or {
                        layer: frozenset() for layer in _SHADING_LAYERS
                    }
                    backgrounds = [
                        b
                        for b in [
                            run.get("run_shading"),
                            *(fill for _, fill in layers),
                        ]
                        if b
                    ]
                    # A holder that spoke has overridden whatever its style
                    # said for THAT LAYER, so the style is not consulted there.
                    # It is still consulted on every other layer it paints:
                    # a style can set w:pPr, w:rPr, w:tcPr and w:tblPr at once,
                    # and a cell clearing itself silences only the per-cell one.
                    overridden = set(declared) | {kind for kind, _ in layers}
                    if run.get("run_shading") or run.get("run_shading_cleared"):
                        overridden.add("run")

                    on_dark = (
                        any(not _is_known_light(b) for b in backgrounds)
                        or _style_paints_dark(pstyle, shaded, overridden)
                        or _style_paints_dark(
                            para.get("table_style"), shaded, overridden
                        )
                        or _style_paints_dark(run.get("run_style"), shaded, overridden)
                        or page_background_is_dark
                    )
                    color, color_source = (
                        ("auto", "unresolved_over_this_background")
                        if on_dark
                        else ("#000000", "auto")
                    )
                key = (
                    pstyle,
                    bold,
                    source,
                    color,
                    size,
                    font,
                    size_source,
                    font_source,
                    color_source,
                )
                groups[key] = groups.get(key, 0) + 1
                if sample_text and key not in samples:
                    samples[key] = str(run.get("text") or "").strip()

    if not groups:
        return f"{indent}<{tag}{extra_attrs} />\n"

    ordered = sorted(groups.items(), key=lambda kv: (-kv[1], str(kv[0])))
    rows: list[str] = []
    for (
        pstyle,
        bold,
        bold_source,
        color,
        size,
        font,
        size_source,
        font_source,
        color_source,
    ), count in ordered[:_MAX_RUN_STYLE_GROUPS]:
        attrs = f'count="{count}" paragraph_style="{xml_escape(str(pstyle))}"'
        attrs += f' bold="{bold}"'
        if bold_source:
            attrs += f' bold_source="{bold_source}"'
        # An unset colour inherits from the style, so say so rather than
        # implying black — a criterion about an explicit hex needs the
        # difference between "set to X" and "never set".
        if color == "auto":
            attrs += ' color="auto"'
        elif color:
            attrs += f' color="{xml_escape(color.upper())}"'
        else:
            attrs += ' color="inherited"'
        if color_source:
            attrs += f' color_source="{color_source}"'
        # Always emitted, "inherited" included — see the README on absence.
        if size is not None:
            attrs += f' size_pt="{size}"'
            if size_source:
                attrs += f' size_pt_source="{size_source}"'
        else:
            attrs += ' size_pt="inherited"'
        if font:
            attrs += f' font_name="{xml_escape(str(font))}"'
            if font_source:
                attrs += f' font_name_source="{font_source}"'
        else:
            attrs += ' font_name="inherited"'
        sample = samples.get(
            (
                pstyle,
                bold,
                bold_source,
                color,
                size,
                font,
                size_source,
                font_source,
                color_source,
            )
        )
        if sample:
            attrs += f' text="{xml_escape(sample[:_HDR_FTR_TEXT_CHARS])}"'
        rows.append(f"{indent}  <style {attrs} />")

    omitted = len(ordered) - len(rows)
    tail = (
        f"\n{indent}  <!-- {omitted} rarer style combinations omitted -->"
        if omitted
        else ""
    )
    return (
        f"{indent}<{tag}{extra_attrs}>\n"
        + "\n".join(rows)
        + tail
        + f"\n{indent}</{tag}>\n"
    )


async def _page_count(file_bytes: bytes, file_name: str) -> tuple[int | None, bool]:
    """Real page count, plus whether the failure to get one may be transient.

    Returns (count, retryable). A missing LibreOffice binary is stable for the
    life of the process, so "unknown" is then the file's real answer and the
    whole summary — run styles, tables, chart fills, all extracted fine — can be
    cached like any other. A conversion that fails *with* the binary present may
    be a timeout or a non-zero exit, so that one is marked retryable and the
    cache does not persist it.

    A DOCX is a flowing format — pages only exist once something lays it out —
    so criteria like "includes exactly one page" are unanswerable from the
    document XML. Reuses the docx_to_pdf transformation (LibreOffice) and counts
    the result, which is the same renderer the image path already relies on, so
    the number agrees with what a reviewer would see.

    Costs a subprocess, so it is only paid for docx and only once per file per
    grading run (cached_style_text coalesces the whole extraction).
    """
    if not find_libreoffice():
        logger.info(
            f"[TRANSFORM] LibreOffice unavailable; page count for {file_name} is "
            f"permanently unknown in this process"
        )
        return None, False
    try:
        converted = await docx_to_pdf(file_bytes, file_name)
    except Exception as e:
        logger.warning(
            f"[TRANSFORM] page count unavailable for {file_name}: "
            f"{type(e).__name__}: {e}"
        )
        return None, True
    if not converted.pdf_bytes:
        logger.info(
            f"[TRANSFORM] no PDF produced for {file_name}; page count unavailable"
        )
        return None, True
    try:
        return len(PdfReader(io.BytesIO(converted.pdf_bytes)).pages), False
    except Exception as e:
        logger.warning(
            f"[TRANSFORM] could not read converted PDF for {file_name}: "
            f"{type(e).__name__}: {e}"
        )
        return None, True


def _docx_style_summary_xml(
    file_bytes: bytes,
    file_name: str,
    page_count: int | None = None,
    retryable: bool = False,
) -> str:
    # One Document build and one ZIP open for the whole summary. This used to
    # parse the document twice — once inside docx_to_style_metadata and again
    # here — and open the package twice on top of that, for every docx in every
    # criterion that touches one. Both are handed to docx_to_style_metadata so
    # it reuses them rather than repeating the work.
    doc = Document(io.BytesIO(file_bytes))
    doc_root = doc.element
    body = doc_root.body  # pyright: ignore[reportAttributeAccessIssue]

    with zipfile.ZipFile(io.BytesIO(file_bytes), "r") as zf:
        data = docx_to_style_metadata(
            file_bytes, file_name, reuse_doc=doc, reuse_zip=zf
        )
        charts = _charts_xml(zf)
        background = _page_background_xml(zf, doc_root)
        styles_root = _styles_root(zf)
        bold_styles = _bold_style_ids(zf, styles_root)
        shaded_styles = _shaded_style_ids(zf, styles_root)
        style_fonts = _style_run_fonts(zf, styles_root)
        link_sources: list[tuple[str, Any, dict[str, str]]] = [
            ("word/document.xml", body, _hyperlink_targets(zf))
        ]
        # Headers/footers plus footnotes/endnotes: all hold visible text that
        # can carry a link, and the count claims document-wide coverage.
        extra_parts = _referenced_header_parts(zf, doc_root) + [
            n for n in ("word/footnotes.xml", "word/endnotes.xml") if n in zf.namelist()
        ]
        for part in extra_parts:
            try:
                part_root = etree.fromstring(zf.read(part), parser=_SAFE_PARSER)
            except (KeyError, etree.XMLSyntaxError):
                continue
            link_sources.append((part, part_root, _hyperlink_targets(zf, part)))
        bg_dark = _page_background_is_dark(zf, doc_root)
        headers_footers = _headers_footers_xml(
            zf,
            doc_root,
            bold_styles,
            style_fonts,
            bg_dark,
            shaded_styles,
        )

    # Deliberately carries no filename. cached_style_text keys on content hash
    # alone, so two byte-identical documents at different paths share an entry
    # — embedding the name here would label the second one with the first's.
    # The eval already wraps this in <STYLE_METADATA file="..."> using the real
    # artifact path, so the name is never actually lost.
    if page_count:
        pages_attr = f'pages="{page_count}"'
    else:
        # Only a possibly-transient failure is flagged degraded. A renderer that
        # is simply absent gives the same answer every time, so the run styles,
        # tables and chart fills extracted alongside it must stay cacheable —
        # marking them degraded made every verifier re-parse the document.
        pages_attr = 'pages="unknown"' + (' data-degraded="true"' if retryable else "")
    return (
        f'<style_metadata {pages_attr} paragraphs="{data["paragraph_count"]}">\n'
        + background
        + _run_styles_xml(
            data["paragraphs"],
            bold_styles,
            style_fonts,
            page_background_is_dark=bg_dark,
            shaded_style_ids=shaded_styles,
        )
        + _tables_xml(body)  # pyright: ignore[reportUnknownArgumentType]
        + _links_xml(link_sources)
        + headers_footers
        + charts
        + "</style_metadata>\n"
    )


async def _extract_docx_style_text(file_bytes: bytes, file_name: str) -> str:
    # Conversion is a subprocess and awaits; the XML parse is CPU-bound and goes
    # to a thread so it doesn't stall other verifiers' LLM calls.
    pages, retryable = await _page_count(file_bytes, file_name)
    return await asyncio.to_thread(
        _docx_style_summary_xml, file_bytes, file_name, pages, retryable
    )


async def docx_to_style_metadata_output(
    file_bytes: bytes, file_name: str
) -> TransformationOutput:
    """Run/table/chart style facts for a DOCX as judge-readable XML.

    Answers criteria like "bolded non-header body text is #CD8D81" or "all
    embedded tables and charts have a transparent background" from the
    document XML, instead of having the judge guess colours off a render.

    The registry maps this to the whole DOCX family, so .doc (OLE2) and .odt
    (OpenDocument, a zip but not an OOXML package) reach it too — python-docx
    reads neither. They answer with an
    explanatory note rather than a bare BadZipFile, because the agentic judge
    surfaces the transformation's error text to the model and "File is not a zip
    file" invites a retry, while a stated limitation does not.
    """
    if not is_ooxml_package(file_bytes):
        logger.info(
            f"[TRANSFORM] {file_name} is not an OOXML package — no docx style "
            f"metadata available"
        )
        return TransformationOutput(
            text=(
                '<style_metadata unsupported="true" data-degraded="true">Style metadata requires a '
                ".docx (OOXML) file; legacy .doc and OpenDocument .odt are not "
                "supported by this extractor.</style_metadata>\n"
            )
        )

    text = await cached_style_text(
        file_bytes, file_name, "docx", _extract_docx_style_text
    )
    return TransformationOutput(text=text)
