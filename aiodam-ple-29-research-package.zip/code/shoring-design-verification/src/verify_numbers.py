"""A second, independent recomputation of the memorandum's numbers.

Different mechanism from compute.py: Decimal arithmetic, and the inputs are re-read from the *rendered
memorandum text* (the way the judge sees them) rather than from the corpus — every relation the memo
asserts about its own numbers is re-derived here.  If the memo prints a number that does not follow
from the numbers around it, this fails.
"""
from __future__ import annotations

import re
import subprocess
import sys
import tempfile
from decimal import Decimal as Dc
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
PDF = ROOT / "render" / "Thelbridge_Verification_Memo_Item048_BlockB.pdf"


def text() -> str:
    with tempfile.NamedTemporaryFile(suffix=".txt", delete=False) as fh:
        out = Path(fh.name)
    subprocess.run(["pdftotext", "-layout", str(PDF), str(out)], check=True)
    t = out.read_text(errors="replace")
    out.unlink(missing_ok=True)
    t = t.replace("\u00a0", " ")
    return re.sub(r"\s+", " ", t)


T = text()
def num(s: str) -> Dc:
    return Dc(s.replace(",", "").rstrip("."))


CHECKS = []


def check(name, ok, detail=""):
    CHECKS.append((name, bool(ok), detail))


def grab(pattern: str) -> Dc:
    m = re.search(pattern, T)
    if not m:
        raise LookupError(f"cannot find {pattern!r} in the memorandum")
    return num(m.group(1))


# --- geometry: 734.5 - 726.0 = 8.5, and the split 3.0 + 5.5
top = grab(r"top of the mat at El\. ([\d.]+)")
sub = grab(r"plant-room subgrade is El\. ([\d.]+)")
h = grab(r"about ([\d.]+) ft\.")
check("retained height = top of mat - subgrade", top - sub == h, f"{top} - {sub} = {top - sub} vs {h}")
edge = grab(r"Of that, ([\d.]+) ft is the cut edge")
clay = grab(r"and ([\d.]+) ft is clay below the mat underside")
check("3.0 + 5.5 = 8.5", edge + clay == h, f"{edge} + {clay} = {edge + clay}")
under = grab(r"\(El\. [\d.]+ to El\. ([\d.]+)\) and")
check("top of mat - underside = cut edge", top - under == edge, f"{top} - {under} = {top - under}")

# --- hydrostatic component: 0.5 x 62.4 x 16^2 = 7,987.2 and the total 19,610
pw = grab(r"of which ([\d,.]+) lb/ft is hydrostatic")
head = grab(r"from El\. [\d.]+ over ([\d.]+) ft")
check("0.5 x 62.4 x h^2 = hydrostatic load", (Dc("62.4") * head * head / 2).quantize(Dc("0.1")) == pw,
      f"{pw} vs {(Dc('62.4') * head * head / 2).quantize(Dc('0.1'))}")
total = grab(r"That gives ([\d,]+) lb/ft of driving load")
soil = grab(r"and ([\d,.]+) lb/ft is the layered")
check("hydrostatic + soil = total", pw + soil == total, f"{pw} + {soil} = {pw + soil} vs {total}")
share = grab(r"— ([\d.]+) per cent —")
check("share = 100 x hydrostatic / total",
      (Dc(100) * pw / total).quantize(Dc("0.1")) == share,
      f"{(Dc(100) * pw / total).quantize(Dc('0.1'))} vs {share}")

# --- toe embedment on the reported strengths
sigma = grab(r"pn = 4Su - ([\d,]+) psf")
assert sigma == Dc(3106), sigma
m_d = grab(r"and the driving moment of ([\d,]+) ft-lb/ft")
for su, pn, pp, mr, fs in [("1100", None, None, None, "0.81"), ("900", None, None, None, "0.31")]:
    pn_p = grab(rf"at Su = {int(su):,} psf, pn = ([\d,]+) psf")
    pp_p = grab(rf"Pp = ([\d,]+) lb/ft, MR = [\d,]+ ft-lb/ft and FStoe = {fs}")
    mr_p = grab(rf"Pp = [\d,]+ lb/ft, MR = ([\d,]+) ft-lb/ft and FStoe = {fs}")
    check(f"pn at Su={su}: 4Su - 3,106", Dc(4 * int(su)) - sigma == pn_p, f"{Dc(4*int(su)) - sigma} vs {pn_p}")
    check(f"Pp at Su={su}: pn x D", pn_p * grab(r"with D = ([\d.]+) ft") == pp_p, f"{pn_p * grab(r'with D = ([\d.]+) ft')} vs {pp_p}")
    check(f"FStoe at Su={su}: MR / MD", (mr_p / m_d).quantize(Dc("0.01")) == Dc(fs),
          f"{(mr_p / m_d).quantize(Dc('0.01'))} vs {fs}")
su_req = grab(r"needs Su of ([\d,]+) psf to hold")
z_p = grab(r"At the row El\. ([\d.]+), at") - (sub - grab(r"with D = ([\d.]+) ft") / 2)
check("z_p = anchor row - mid-embedment", z_p == Dc("22.75"), f"{z_p} vs 22.75")
check("Su required closes to the printed value",
      abs(((Dc("1.5") * m_d / z_p / grab(r"with D = ([\d.]+) ft")) + sigma) / 4 - su_req) <= Dc("1"),
      f"{((Dc('1.5') * m_d / z_p / Dc('6.5')) + sigma) / 4} vs {su_req}")

# --- base heave: 6 x 120 = 720; 0.9 x 720 = 648; 6.5 x 62.4 = 405.6; 648/405.6 = 1.60
plug = grab(r"a ([\d.]+) ft clay plug at [\d,.]+ pcf weighs W = ([\d,]+) psf".replace("W = ", "W = "))
w = grab(r"weighs W = ([\d,]+) psf")
check("W = plug x 120", plug * Dc(120) == w, f"{plug} x 120 = {plug * 120} vs {w}")
w09 = grab(r"0\.9W = ([\d,]+) psf")
check("0.9W = 0.9 x W", (w * Dc("0.9")).quantize(Dc("1")) == w09, f"{(w * Dc('0.9')).quantize(Dc('1'))} vs {w09}")
u = grab(r"the uplift is u = ([\d,.]+) psf")
check("u = (726.5 - 720.0) x 62.4", (Dc("6.5") * Dc("62.4")).quantize(Dc("0.1")) == u, f"{Dc('6.5') * Dc('62.4')} vs {u}")
fs = grab(r"FSheave = ([\d.]+), above")
check("FSheave = 0.9W / u", (w09 / u).quantize(Dc("0.01")) == fs, f"{(w09 / u).quantize(Dc('0.01'))} vs {fs}")
u_un = grab(r"faces ([\d,.]+) psf of uplift, the unpumped")
check("unpumped u = 18 x 62.4", (Dc("18") * Dc("62.4")).quantize(Dc("0.1")) == u_un, f"{Dc('18')*Dc('62.4')} vs {u_un}")
fs_un = grab(r"factor of safety is about ([\d.]+): the same plug")
check("unpumped FS = 0.9W / u", (w09 / u_un).quantize(Dc("0.01")) == fs_un, f"{(w09 / u_un).quantize(Dc('0.01'))} vs {fs_un}")

# --- the trigger
u_tr = grab(r"the uplift is ([\d,.]+) psf against 0\.9W")
check("u at 727.0 = 7 x 62.4", (Dc("7") * Dc("62.4")).quantize(Dc("0.1")) == u_tr, f"{Dc('7')*Dc('62.4')} vs {u_tr}")
fs_tr = grab(r"psf against 0\.9W of [\d,]+ psf, a factor of ([\d.]+)")
check("trigger FS = 0.9W / u", (w09 / u_tr).quantize(Dc("0.01")) == fs_tr, f"{(w09 / u_tr).quantize(Dc('0.01'))} vs {fs_tr}")
head_min = grab(r"the 1\.50 line is lost above El\. ([\d.]+)")
check("head at FS 1.50 = 720 + 0.9W/(1.5 x 62.4)",
      (Dc(720) + w09 / (Dc("1.5") * Dc("62.4"))).quantize(Dc("0.1")) == head_min,
      f"{(Dc(720) + w09 / (Dc('1.5') * Dc('62.4'))).quantize(Dc('0.1'))} vs {head_min}")

# --- the drawdown on the aquitard
dd = grab(r"is a drawdown of ([\d.]+) ft: a pore-pressure")
du = grab(r"a pore-pressure reduction of ([\d,.]+) psf at the base")
check("du = drawdown x 62.4", (dd * Dc("62.4")).quantize(Dc("0.1")) == du, f"{dd * Dc('62.4')} vs {du}")
ratio = grab(r"is ([\d.]+) times that margin")
margin = grab(r"a margin of ([\d,]+) psf")
check("du / margin", (du / margin).quantize(Dc("0.01")) == ratio, f"{(du / margin).quantize(Dc('0.01'))} vs {ratio}")
depth = grab(r"all but the top ([\d.]+) ft of the stratum")
check("depth where du = margin", (margin * Dc(18) / du).quantize(Dc("0.01")) == depth,
      f"{(margin * Dc(18) / du).quantize(Dc('0.01'))} vs {depth}")

# --- the reduced-load bound: 0.5 x 0.39 x 120 x 8.5^2
bound = grab(r"the horizontal load is ([\d,]+) lb/ft")
check("0.5 x Ka x 120 x H^2", (Dc("0.5") * Dc("0.39") * Dc(120) * h * h).quantize(Dc("1")) == bound,
      f"{(Dc('0.5')*Dc('0.39')*Dc(120)*h*h).quantize(Dc('1'))} vs {bound}")
share2 = grab(r"([\d.]+) per cent of the [\d,]+ lb/ft the design carries")
check("bound / total", (Dc(100) * bound / total).quantize(Dc("0.1")) == share2,
      f"{(Dc(100) * bound / total).quantize(Dc('0.1'))} vs {share2}")

# --- bond zone geometry: 25 + 24 = 49 ft at 20 degrees
fall = grab(r"falls ([\d.]+) ft from the anchor")
check("fall = (25 + 24) x sin 20", abs(fall - (Dc(49) * Dc("0.3420201433")).quantize(Dc("0.1"))) <= Dc("0.05"),
      f"{Dc(49) * Dc('0.3420201433')} vs {fall}")
b_top = grab(r"between El\. ([\d.]+) and El\. [\d.]+ — inside the clay")
b_bot = grab(r"between El\. [\d.]+ and El\. ([\d.]+) — inside the clay")
row = grab(r"At the row El\. ([\d.]+), at")
check("bond top = row - 25 sin20", abs(b_top - (row - Dc(25) * Dc("0.3420201433"))) <= Dc("0.01"),
      f"{row - Dc(25) * Dc('0.3420201433')} vs {b_top}")
check("bond bottom = row - 49 sin20", abs(b_bot - (row - Dc(49) * Dc("0.3420201433"))) <= Dc("0.01"),
      f"{row - Dc(49) * Dc('0.3420201433')} vs {b_bot}")

# --- headroom
hr = grab(r"is ([\d.]+) ft\. The sheets exceed")
soffit = grab(r"podium soffit is at El\. ([\d.]+)")
check("headroom = soffit - floor", soffit - top == hr, f"{soffit} - {top} = {soffit - top} vs {hr}")
sheet = grab(r"lengthens the sheets to ([\d.]+) ft")
excess = grab(r"exceed that headroom by ([\d.]+) ft")
check("excess = sheet - headroom", sheet - hr == excess, f"{sheet - hr} vs {excess}")

# --- pile caps
cap = grab(r"pile caps at underside El\. ([\d.]+)")
cut = grab(r"plant-room subgrade is El\. [\d.]+, which is ([\d.]+) ft below the cap underside")
check("cut below cap = cap underside - subgrade", cap - sub == cut, f"{cap - sub} vs {cut}")

failed = [c for c in CHECKS if not c[1]]
print(f"{len(CHECKS)} relations recomputed, {len(failed)} do not close")
for name, ok, detail in CHECKS:
    if not ok:
        print("   FAIL", name, "|", detail)
sys.exit(1 if failed else 0)
