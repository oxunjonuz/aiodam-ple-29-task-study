"""Every number with a unit that appears in the memorandum must be derivable from the record.

Different mechanism from checks.py: this does not read for phrases at all.  It pulls every
"<number> <unit>" token out of the rendered memorandum and asks, for each one, whether that number
exists in what compute.py derived from the corpus, or in a record value the readers parsed, or in an
explicit quote that this file re-verifies against the source document before accepting it.
"""
from __future__ import annotations

import json
import re
import subprocess
import tempfile
from pathlib import Path

import record

ROOT = Path(__file__).resolve().parent.parent
PDF = Path(__import__("os").environ.get("MEMO_PDF", str(ROOT / "render" / "Thelbridge_Verification_Memo_Item048_BlockB.pdf")))

UNITS = ["ft-lb/ft", "kip-ft/ft", "lb/ft", "psf", "pcf", "psi", "ft", "in", "kips", "lb",
         "days", "years", "cm2/s", "degrees", "per cent"]
UNIT_RE = re.compile(r"(-?\d[\d,]*(?:\.\d+)?)\s*(" + "|".join(re.escape(u) for u in sorted(UNITS, key=len, reverse=True)) + r")\b")
# numbers that carry no unit but are still claims: an elevation, and a factor of safety
ELEV_RE = re.compile(r"(?:El\.|\(El\.)\s*(\d[\d,]*(?:\.\d+)?)")
RATIO_RE = re.compile(r"(?:factor of safety(?: is| of)?|a factor of|FStoe =|FSheave =|FSflex =|FSanchor =|is about)"
                      r"\D{0,12}(\d+\.\d+)")


def pdf_text() -> str:
    with tempfile.NamedTemporaryFile(suffix=".txt", delete=False) as fh:
        out = Path(fh.name)
    subprocess.run(["pdftotext", "-layout", str(PDF), str(out)], check=True)
    text = out.read_text(errors="replace")
    out.unlink(missing_ok=True)
    return text


def forms(value: float) -> set[str]:
    """the ways a number may legitimately be printed"""
    out = set()
    for nd in (0, 1, 2, 3, 4, 5, 6):
        s = f"{value:,.{nd}f}"
        out.add(s)
        out.add(s.replace(",", ""))
    return out


def walk(obj, sink: set[str]) -> None:
    if isinstance(obj, dict):
        for v in obj.values():
            walk(v, sink)
    elif isinstance(obj, (list, tuple)):
        for v in obj:
            walk(v, sink)
    elif isinstance(obj, bool):
        return
    elif isinstance(obj, (int, float)):
        sink |= forms(float(obj))
    elif isinstance(obj, str):
        for m in re.findall(r"\d[\d,]*(?:\.\d+)?", obj):
            try:
                sink |= forms(float(m.replace(",", "")))
            except ValueError:
                pass


# numbers quoted straight out of the record that no reader of mine returns as a number, each with the
# exact text that has to be in the source document for the quote to be accepted
QUOTES = [
    ("83", "06_Submittals_RFI/Submittal_31-SH-B_Shoring_Calculations_Rev1.pdf", r"0\.333 . 250 = 83 psf"),
    ("0.28", "06_Submittals_RFI/Submittal_31-SH-B_Shoring_Calculations_Rev1.pdf", r"= 3,740 / 13,392 = 0\.28"),
    ("0.9", "02_Structural/Design_Basis_Memorandum_Rev2.pdf", r"is taken at 0\.9D"),
    ("1.50", "02_Structural/Design_Basis_Memorandum_Rev2.pdf", r"minimum 1\.5 for sliding and base heave"),
    ("2.5", "02_Structural/Drawings/S-201_Foundation_Sections_Details_Rev4.pdf", r"Pile cap thickness \. \. \. 2'-6"),
    ("3.0", "02_Structural/Drawings/S-101_Foundation_Plan_Rev4.pdf", r"Thickness: 3\.0 ft"),
    ("6", "@KESTERLINE", r"a 6\.0 ft clay plug remains"),
    ("48", "02_Structural/Drawings/S-101_Foundation_Plan_Rev4.pdf", r"Pile count: 48"),
    ("20", "06_Submittals_RFI/Submittal_31-SH-B_Shoring_Calculations_Rev1.pdf", r"= 20 psi"),
    ("25", "06_Submittals_RFI/Submittal_31-SH-B_Shoring_Calculations_Rev1.pdf", r"Free \(unbonded\) length: 25 ft"),
    ("24", "06_Submittals_RFI/Submittal_31-SH-B_Shoring_Calculations_Rev1.pdf", r"increased to 24 ft"),
    ("50", "01_Geotech/Geotechnical_Investigation_Report_PkgA_Rev2.pdf", r"50 blows per 6 inches"),
    ("30", "06_Submittals_RFI/Submittal_31-SH-B_Shoring_Calculations_Rev1.pdf", r"30 blows/ft"),
    ("141", "05_Field/Daily_Field_Reports_Basement_20260628-0702.pdf", r"Report No\. 141"),
    ("145", "05_Field/Daily_Field_Reports_Basement_20260628-0702.pdf", r"Report No\. 145"),
    ("734.7", "02_Structural/Drawings/S-102_Basement_Levels_Drainage_Joint_Layout.pdf", r"K-6 \(invert El\. 734\.7\)"),
    ("900", "01_Geotech/Geotechnical_Investigation_Report_PkgA_Rev2.pdf", r"Su = 900 to 1,100 psf"),
    ("1,100", "01_Geotech/Geotechnical_Investigation_Report_PkgA_Rev2.pdf", r"Su = 900 to 1,100 psf"),
    ("1,400", "06_Submittals_RFI/Submittal_31-SH-B_Shoring_Calculations_Rev1.pdf", r"undrained 120 - - 1,400"),
    ("17,844", "06_Submittals_RFI/Submittal_31-SH-B_Shoring_Calculations_Rev1.pdf", r"Total driving force P_A"),
    ("121", "@KESTERLINE", r"= 121 kip-ft/ft"),
    ("405.6", "@KESTERLINE", r"u = 405\.6 psf"),
    ("648", "@KESTERLINE", r"0\.9W = 648 psf"),
    ("720", "@KESTERLINE", r"W = 720 psf"),
    ("4.0", "01_Geotech/Consolidation_Test_Data_D2435.xlsx", "@XLSX-4-5"),
    ("5", "01_Geotech/Consolidation_Test_Data_D2435.xlsx", "@XLSX-4-5"),
]


def quote_ok(number: str, source: str, pattern: str) -> bool:
    if source == "@KESTERLINE":
        path = record.WS / "Kesterline_31-SH-B_Rev2_Supplement_KE-L-2026-0713.pdf"
    else:
        path = record.A / source
    if not path.exists():
        return False
    if pattern == "@XLSX-4-5":
        rows = record.xlsx_rows(path)
        flat = json.dumps(rows, default=str)
        return "to 5" in flat and "10" in flat
    if path.suffix == ".pdf":
        text = record.pdf_text(path)
    elif path.suffix == ".xlsx":
        text = json.dumps(record.xlsx_rows(path), default=str)
    else:
        text = path.read_text(errors="replace")
    flat = re.sub(r"\s+", " ", text.replace("\u2212", "-"))
    return re.search(pattern, flat) is not None


def main() -> int:
    text = pdf_text()
    computed = json.loads((ROOT / "computed.json").read_text())
    allowed: set[str] = set()
    walk(computed, allowed)
    walk(record.everything(), allowed)

    quoted = set()
    for number, source, pattern in QUOTES:
        if pattern == "SELF":
            continue
        if quote_ok(number, source, pattern):
            quoted |= forms(float(number.replace(",", "")))
        else:
            print(f"QUOTE NOT VERIFIED: {number} against {source}")

    tokens = UNIT_RE.findall(text)
    for number in ELEV_RE.findall(text):
        tokens.append((number, "El."))
    for number in RATIO_RE.findall(text):
        tokens.append((number, "FS"))
    unexplained = []
    for number, unit in tokens:
        key = number.replace(",", "")
        if number in allowed or key in allowed or number in quoted or key in quoted:
            continue
        unexplained.append(f"{number} {unit}")

    print(f"{len(tokens)} number+unit tokens, {len(set(t for t in tokens))} distinct")
    print(f"unexplained: {len(unexplained)}")
    for u in sorted(set(unexplained)):
        print("   ", u)
    return 0 if not unexplained else 1


if __name__ == "__main__":
    raise SystemExit(main())
