"""A stand-in judge on loopback, so the task's own tests/test.sh → verify.py → grade.py can be run end to end.

It speaks the OpenAI chat-completions shape the task's grader posts to.  It does NOT decide the grade by
returning a constant: it reads the candidate text out of the request and runs checks.py on it, so a
document with a broken statement comes back with that criterion failed and a reward below 1.
This is a wiring test, not an evaluation — the stub is my reader, not an independent judge.
"""
from __future__ import annotations

import json
import re
import sys
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import checks

PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 8771
LOG = []


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):
        pass

    def do_POST(self):
        n = int(self.headers.get("Content-Length") or 0)
        body = self.rfile.read(n).decode("utf-8", "replace")
        try:
            req = json.loads(body)
        except json.JSONDecodeError:
            req = {}
        text = "\n".join(m.get("content", "") if isinstance(m.get("content"), str)
                         else " ".join(p.get("text", "") for p in m.get("content", []) if isinstance(p, dict))
                         for m in req.get("messages", []))
        wanted = sorted({int(x) for x in re.findall(r'"index":\s*(\d+)', text)})
        # the request is "<criteria payload>\n\nReturn JSON matching this schema:\n<schema>\n<body>"
        # the judge reads the body; so does the stub — the criteria wording must not answer its own question
        marker = "Return JSON matching this schema:"
        i = text.find(marker)
        if i >= 0:
            j = text.find('"additionalProperties": false}', i)
            if j > 0:
                text = text[j + len('"additionalProperties": false}'):]
        res = checks.run_text(text)
        # the grader asks one rendering group at a time: answer only the indices it asked about
        if not wanted:
            wanted = list(range(len(checks.CHECKS)))
        grades = []
        for i in wanted:
            name, _fn = checks.CHECKS[i]
            ok = bool(res.get(name))
            grades.append({"index": i, "score": 1.0 if ok else 0.0, "passed": ok,
                           "evidence": f"stub reader: {name} {'found' if ok else 'did not find'} its statement",
                           "reason": f"checks.{name} over the received candidate text"})
        LOG.append({"n_chars": len(text), "asked": wanted, "passed": sum(g["passed"] for g in grades),
                    "weight": sum(checks.WEIGHTS[i] for i in wanted if res.get(checks.CHECKS[i][0]))})
        payload = {"id": "stub", "object": "chat.completion", "model": "stub-judge",
                   "choices": [{"index": 0, "finish_reason": "stop",
                                "message": {"role": "assistant", "content": json.dumps({"grades": grades})}}],
                   "usage": {"prompt_tokens": len(text) // 4, "completion_tokens": 400, "total_tokens": len(text) // 4 + 400}}
        out = json.dumps(payload).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(out)))
        self.end_headers()
        self.wfile.write(out)

    def do_GET(self):
        out = json.dumps(LOG).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(out)))
        self.end_headers()
        self.wfile.write(out)


if __name__ == "__main__":
    srv = ThreadingHTTPServer(("127.0.0.1", PORT), Handler)
    print(f"stub judge on {PORT}", flush=True)
    srv.serve_forever()
