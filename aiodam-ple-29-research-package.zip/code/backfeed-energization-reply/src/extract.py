# -*- coding: utf-8 -*-
"""Read the Halbray record and write computed.json: every number and quoted string the letter uses,
taken from the files (xlsx cells, PDF text), plus what is calculated from them.  Nothing here reads
the rubric."""
import json, os, re
import openpyxl, pymupdf

BASE = '/work/ple-dataset/tasks/backfeed-energization-reply/environment/files'
OUT = '/work/bf/computed.json'

def pdf(rel):
    d = pymupdf.open(os.path.join(BASE, rel))
    return "\n".join(p.get_text() for p in d)

def sheet_rows(rel, sheet):
    wb = openpyxl.load_workbook(os.path.join(BASE, rel), data_only=True)
    ws = wb[sheet]
    rows = [[('' if c is None else str(c).strip()) for c in r] for r in ws.iter_rows(values_only=True)]
    return [r for r in rows if any(r)]

def kv(rows):
    """first column -> rest joined, for two-column sheets"""
    return {r[0]: ' | '.join(x for x in r[1:] if x) for r in rows}

D = {}
# ---------------------------------------------------------------- tracker rows (E-203 Rev B)
TR = 'Equipment/PXA-2024-0002_Halbray_Tracker_Row_Wiring_Schedule.xlsx'
tr_head = sheet_rows(TR, 'Header')
tr_blocks = sheet_rows(TR, 'Blocks')
tr_wiring = kv(sheet_rows(TR, 'Wiring'))
D['tracker_drawing'] = re.search(r'Drawing (\S+ Rev \w+), (\d\d/\d\d/\d{4})', ' '.join(tr_head[2])).group(0)
D['tracker_drawing_no'] = re.search(r'Drawing (\S+ Rev \w+)', ' '.join(tr_head[2])).group(1)
D['tracker_drawing_date'] = re.search(r'(\d\d/\d\d/\d{4})', ' '.join(tr_head[2])).group(1)
blocks = [r for r in tr_blocks[1:] if r[0].startswith('Block')]
D['blocks'] = len(blocks)
D['rows_per_block'] = int(re.match(r'(\d+) rows', blocks[0][1]).group(1))
D['drives_per_block'] = int(re.match(r'(\d+) x slew drive', blocks[0][2]).group(1))
D['drive_kw'] = float(re.search(r'([\d.]+) kW', blocks[0][2]).group(1))
D['drive_vdc'] = int(re.search(r'(\d+) V dc', blocks[0][2]).group(1))
D['drive_cable'] = tr_wiring['Drive circuits']
D['drive_cable_size'] = re.search(r'3 x (\d+ AWG Cu Type TC)', D['drive_cable']).group(1)
D['rows_total'] = D['blocks'] * D['rows_per_block']
D['drives_total'] = D['blocks'] * D['drives_per_block']
D['drive_kw_total'] = round(D['drives_total'] * D['drive_kw'], 3)
D['drive_a'] = round(D['drive_kw'] * 1000 / D['drive_vdc'], 1)   # per drive, at 48 V dc

# ---------------------------------------------------------------- inverter skids (E-301 Rev B)
SK = 'Equipment/PXA-2024-0002_Halbray_Inverter_Skid_Schedule.xlsx'
sk_head = sheet_rows(SK, 'Header')
D['skid_drawing_no'] = re.search(r'Drawing (\S+ Rev \w+)', ' '.join(sk_head[2])).group(1)
D['skid_drawing_date'] = re.search(r'(\d\d/\d\d/\d{4})', ' '.join(sk_head[2])).group(1)
sk = [r for r in sheet_rows(SK, 'Skids')][1:]
D['skids'] = len([r for r in sk if r[0].startswith('SK-')])
D['skid_kw'] = int(sk[0][2])
D['skid_a'] = int(sk[0][4])
D['skid_inverters'] = sk[0][1]                     # "2 x NG-XT-225, 1 x NG-XT-125"
m = re.search(r'(\d+) x (NG-XT-\d+), (\d+) x (NG-XT-\d+)', D['skid_inverters'])
D['n_xt225_per_skid'], D['n_xt125_per_skid'] = int(m.group(1)), int(m.group(3))
D['xt225'] , D['xt125'] = m.group(2), m.group(4)
D['n_xt225'] = D['n_xt225_per_skid'] * D['skids']
D['n_xt125'] = D['n_xt125_per_skid'] * D['skids']
D['n_inverters'] = D['n_xt225'] + D['n_xt125']
D['kw_total'] = D['skids'] * D['skid_kw']
D['mw_total'] = D['kw_total'] / 1000
D['acp'] = sk[0][3]
ic = {r[0]: r for r in sheet_rows(SK, 'Inverter Circuits')[1:]}
r225 = [r for r in ic.values() if '225' in r[1]][0]
r125 = [r for r in ic.values() if '125' in r[1]][0]
D['i225'] = float(r225[2]); D['brk225'] = int(r225[3]); D['cond225'] = r225[4]; D['egc225'] = r225[5]; D['raceway225'] = r225[6]
D['i125'] = float(r125[2]); D['brk125'] = int(r125[3]); D['cond125'] = r125[4]; D['egc125'] = r125[5]; D['raceway125'] = r125[6]
D['use2_size225'] = re.search(r'3 x 1/C (\S+ AWG Cu, \S+ kV Type USE-2)', D['cond225']).group(1)
D['use2_size125'] = re.search(r'3 x 1/C (\S+ AWG Cu, \S+ kV Type USE-2)', D['cond125']).group(1)
pads = kv(sheet_rows(SK, 'Pads'))
D['stubups'] = pads['Stub-ups']
D['feeder_exits'] = pads['Collection feeder exits']

# ---------------------------------------------------------------- plant equipment (E-201 Rev B)
EQ = 'Equipment/PXA-2024-0002_Halbray_Equipment_Schedule.xlsx'
eq_head = sheet_rows(EQ, 'Header')
D['eq_drawing_no'] = re.search(r'Drawing (\S+ Rev \w+)', ' '.join(eq_head[2])).group(1)
D['eq_drawing_date'] = re.search(r'(\d\d/\d\d/\d{4})', ' '.join(eq_head[2])).group(1)
eq = {r[0]: r for r in sheet_rows(EQ, 'Equipment')[1:]}
D['T1'] = eq['T-1'][1]; D['T1_data'] = eq['T-1'][3]
D['PSW1'] = eq['PSW-1'][1]; D['PSW1_data'] = eq['PSW-1'][3]
D['CSB1'] = eq['CSB-1'][1]; D['CSB1_data'] = eq['CSB-1'][3]
D['AUX1'] = eq['AUX-1'][1]; D['AUX1_data'] = eq['AUX-1'][3]
D['GND'] = eq['GND'][1] + ' | ' + eq['GND'][3]
D['kva'] = int(re.search(r'([\d,]+) kVA', D['T1']).group(1).replace(',', ''))
D['kv_primary'] = float(re.search(r'([\d.]+) kV grounded wye', D['T1']).group(1))
D['v_secondary'] = re.search(r'to (\S+) V', D['T1']).group(1)
D['fla_primary'] = int(re.search(r'full-load primary current (\d+) A', D['PSW1_data']).group(1))
D['fla_secondary'] = int(re.search(r'full-load secondary current (\d+) A', D['CSB1_data']).group(1))
D['fault_csb1'] = re.search(r'available fault current at CSB-1 ([\d.]+ kA)', D['CSB1_data']).group(1)
D['aux_breaker'] = int(re.search(r'one (\d+) A auxiliary breaker', D['CSB1']).group(1))
D['aux_feeder'] = eq['AUX-1'][3].split('Feeder ')[-1]
D['aux_duct'] = re.search(r'in (\d+ in\. HDPE duct)', D['aux_feeder']).group(1)
D['ground_ohm'] = re.search(r'measured ([\d.]+) ohm', D['GND']).group(1)
cf = {r[0]: r for r in sheet_rows(EQ, 'Collection Feeders')[1:]}
D['feeder_C1'] = cf['C-1'][3]; D['feeder_C1_a'] = int(cf['C-1'][5].split()[0])
D['feeder_C1_duct'] = cf['C-1'][6]; D['feeder_C1_len'] = int(cf['C-1'][7])
D['fla_primary_calc'] = round(D['kva'] * 1000 / (3 ** 0.5 * D['kv_primary'] * 1000), 1)

# ---------------------------------------------------------------- auxiliary power and controls (E-202 Rev B)
AX = 'Equipment/PXA-2024-0002_Halbray_Auxiliary_Power_and_Controls_Schedule.xlsx'
ax_head = sheet_rows(AX, 'Header')
D['aux_drawing_no'] = re.search(r'Drawing (\S+ Rev \w+)', ' '.join(ax_head[2])).group(1)
D['aux_drawing_date'] = re.search(r'(\d\d/\d\d/\d{4})', ' '.join(ax_head[2])).group(1)
D['aux_panel'] = {r[0]: r for r in sheet_rows(AX, 'Panelboard')[1:]}['AUX-1'][1]
D['aux_panel_data'] = {r[0]: r for r in sheet_rows(AX, 'Panelboard')[1:]}['AUX-1'][3]
D['aux_branch'] = re.search(r'Branch breakers: (.+)$', D['aux_panel_data']).group(1)
D['controllers'] = {r[0]: r for r in sheet_rows(AX, 'Controllers')[1:]}['TC-1 to TC-8'][1]
D['mounting'] = kv(sheet_rows(AX, 'Mounting'))['Mounting']
_m = re.search(r'on (1-5/8 in\. steel strut), (green enamel finish)', D['mounting'])
D['strut_size'], D['strut_finish'] = _m.group(1), _m.group(2)
D['n_controllers'] = 8

# ---------------------------------------------------------------- the request, the permit, the agreement, the checklist
D['request'] = pdf('Correspondence/2025-07-09_Halbray_Backfeed_Request.pdf')
D['permit'] = pdf('Correspondence/2025-05-12_Kelloway_Township_Electrical_Permit_EP-25-0418.pdf')
D['isa'] = pdf('Contracts/ISA-Halbray-Field-Site-3_Executed_Summary.pdf')
D['checklist'] = pdf('Commissioning/PXA-2024-0002_Halbray_Commissioning_Checklist.pdf')

def grab(text, pat):
    m = re.search(pat, re.sub(r'\s+', ' ', text))
    return re.sub(r'\s+', ' ', m.group(1)) if m else None

D['request_date'] = grab(D['request'], r'(\d\d/\d\d/\d{4}) To:')
D['backfeed_date'] = grab(D['request'], r'feeder ALN-159 on (\d\d/\d\d/\d{4})')
D['request_quote'] = grab(D['request'], r'(Under the pre-PTO backfeed term.*?utility power\.)')
D['request_close'] = grab(D['request'], r'(Please confirm the date, or tell us what stands in the way\.)')
D['request_inverters'] = grab(D['request'], r'(The inverters stay disabled.*?permission to operate\.)')
D['construction_complete'] = grab(D['request'], r'Construction was completed on (\d\d/\d\d/\d{4})')
D['inspection_booked'] = grab(D['request'], r'final electrical inspection under permit EP-25-0418 is booked for (\d\d/\d\d/\d{4})')
D['strathe'] = grab(D['request'], r'(Imogen Strathe, Project Manager, Halbray Community Solar LP)')
D['permit_no'] = grab(D['permit'], r'Electrical Permit (EP-\d\d-\d{4})')
D['permit_issued'] = grab(D['permit'], r'Issued (\d\d/\d\d/\d{4})')
D['permit_holder'] = grab(D['permit'], r'Permit holder ((?:Tamsworth)[^|]*?Lic\. #EC-\d+)')
D['adopted_code'] = grab(D['permit'], r'Adopted code (NFPA 70, National Electrical Code, 2023 edition, as adopted by Township Ordinance \d{4}-\d\d)')
D['energize_rule'] = grab(D['permit'], r'(No permitted work shall be energized before final approval\.)')
D['permit_scope'] = grab(D['permit'], r'Scope of work (2\.3 MW ac ground-mounted photovoltaic system: four inverter skids, the ac collection system, a 2,500 kVA pad-mounted step-up transformer and its 13\.2 kV interconnection)')
D['final_inspection_permit'] = grab(D['permit'], r'Final inspection (Booked by the permit holder with the Building Department)')
D['inspector'] = grab(D['permit'], r'Issued by: (Graham Telford, Electrical Inspector, Kelloway Township Building Department\.)')
D['isa_backfeed'] = grab(D['isa'], r'(On the interconnection customer\'s written request.*?before permission to operate\.)')
D['isa_disabled'] = grab(D['isa'], r'(During a backfeed the generating facility stays disabled and does not operate in parallel; parallel operation begins only with the Company\'s written permission to operate\.)')
D['isa_switching'] = grab(D['isa'], r'(Distribution Operations performs the switching for a backfeed under its own switching order\.)')
D['isa_customer_facilities'] = grab(D['isa'], r'Customer facilities (Four inverter skids.*?primary switch)')
D['isa_executed'] = grab(D['isa'], r'Executed (11/18/2024)')
D['cx_docno'] = grab(D['checklist'], r'Doc no\. (CX-HB-03 · Rev \d · Date \d\d/\d\d/\d{4})')
D['cx_inspection'] = grab(D['checklist'], r'(AHJ final inspection Permit EP-25-0418 Booked for \d\d/\d\d/\d{4})')
D['cx_backfeed'] = grab(D['checklist'], r'(Pre-PTO backfeed ISA pre-PTO backfeed term Requested by[^A]*?switching by Distribution Operations)')
D['cx_rtu'] = grab(D['checklist'], r'(Utility RTU installed and end-to-end point-to-point test TCS-02 §3\.6 Accepted by SCADA/EMS Engineering \(Marcus Deele\), \d\d/\d\d/\d{4})')
D['cx_settings'] = grab(D['checklist'], r'(POI recloser settings and protection coordination study DPS-07 §5\.1 Issued by Distribution Protection Engineering \(N\. Achterberg, P\.E\.\), \d\d/\d\d/\d{4})')
D['cx_siteacc'] = grab(D['checklist'], r'(POI recloser site acceptance, items 1 to 7 DPS-07 §6\.2 Complete[^R]*?\d\d/\d\d/\d{4})')
D['cx_meter'] = grab(D['checklist'], r'(Revenue meter RM-0002 ISA Set by Alleniom Metering, \d\d/\d\d/\d{4})')
D['cx_cel'] = grab(D['checklist'], r'(Inverter CEL check ENG-PRC-014 §4\.1 [^W]*?CEL-2025-Q2)')
D['cx_coordinator'] = grab(D['checklist'], r'(Coordinator: .*?07/14/2025\.)')
D['cx_nameplate'] = grab(D['checklist'], r'Nameplate (2\.3 MW ac \(\d,\d\d\d kW\), four inverter skids)')

# ---------------------------------------------------------------- date arithmetic (07/14/2025 as the record date)
from datetime import date
rec = date(2025, 7, 14)
def d(s):
    m, dd, y = s.split('/')
    return date(int(y), int(m), int(dd))
D['record_date'] = '07/14/2025'
D['days_to_inspection'] = (d(D['inspection_booked']) - rec).days
D['days_inspection_to_backfeed'] = (d(D['backfeed_date']) - d(D['inspection_booked'])).days
D['days_to_backfeed'] = (d(D['backfeed_date']) - rec).days
D['days_request_to_backfeed'] = (d(D['backfeed_date']) - d(D['request_date'])).days

json.dump(D, open(OUT, 'w'), indent=1, ensure_ascii=False)
missing = [k for k in ('isa_disabled','permit_scope','request_quote','request_close','permit_holder','adopted_code','energize_rule','isa_backfeed','isa_switching','cx_inspection','cx_backfeed','cx_rtu','cx_settings','cx_siteacc','cx_meter','cx_cel','cx_coordinator','strathe','inspector','permit_no','isa_customer_facilities','final_inspection_permit','isa_executed','cx_docno','cx_nameplate','construction_complete','inspection_booked','backfeed_date','request_date') if not D.get(k)]
print("computed.json written; missing:", missing)
for k in ('blocks','rows_per_block','drives_total','drive_a','n_inverters','kw_total','mw_total','fla_primary','fla_secondary','fla_primary_calc','days_to_inspection','days_inspection_to_backfeed','days_to_backfeed','days_request_to_backfeed'):
    print(f"  {k} = {D[k]}")
