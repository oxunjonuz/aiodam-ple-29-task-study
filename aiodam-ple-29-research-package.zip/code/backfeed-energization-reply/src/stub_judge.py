# -*- coding: utf-8 -*-
"""A stand-in judge on loopback so the task's own tests/test.sh -> verify.py -> grade.py runs end to end.
It reads the candidate text out of the request and runs checks.py on it: a document that no longer makes a
statement comes back with that criterion failed.  This is a wiring test, not an evaluation."""
import json, os, re, sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
sys.path.insert(0, '/work/bf/src')
import checks

PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 8777
BY_INDEX = {idx: name for name, fn, idx, clo in checks.CHECKS if idx is not None}
LOG = []

class Handler(BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'
    def log_message(self, fmt, *args):
        pass
    def do_POST(self):
        n = int(self.headers.get('Content-Length') or 0)
        body = self.rfile.read(n).decode('utf-8', 'replace')
        try:
            req = json.loads(body)
        except json.JSONDecodeError:
            req = {}
        text = '\n'.join(m.get('content', '') if isinstance(m.get('content'), str)
                         else ' '.join(p.get('text', '') for p in m.get('content', []) if isinstance(p, dict))
                         for m in req.get('messages', []))
        # the prompt is <criteria payload> ... <candidate text>; the criteria text itself states the very things
        # the checks look for, so the checks run on the candidate part only, and the indices come from the payload
        marker = 'Return JSON matching this schema:'
        i = text.find(marker)
        crit_part, cand_part = (text[:i], text[i:]) if i >= 0 else (text, text)
        j = cand_part.find('"additionalProperties": false}')
        if j > 0:
            cand_part = cand_part[j + len('"additionalProperties": false}'):]
        wanted = sorted({int(x) for x in re.findall(r'"index":\s*(\d+)', crit_part)})
        if not wanted:
            wanted = sorted(BY_INDEX)
        text = cand_part
        os.makedirs('/work/bf/render/bodies', exist_ok=True)
        open(f'/work/bf/render/bodies/body{len(LOG)}.txt', 'w', encoding='utf-8').write(text[-4000:])
        res = checks.run_text(text, filename_present=('Halbray_Backfeed_Reply' in text), db_diff=text)
        grades = []
        for i in wanted:
            name = BY_INDEX.get(i)
            ok = bool(res.get(name)) if name else False
            grades.append({'index': i, 'score': 1.0 if ok else 0.0, 'passed': ok,
                           'evidence': f'stub reader: {name} {"found" if ok else "did not find"} its statement',
                           'reason': f'checks.{name} over the received text'})
        LOG.append({'n_chars': len(text), 'asked': wanted, 'passed': sum(g['passed'] for g in grades)})
        payload = {'id': 'stub', 'object': 'chat.completion', 'model': 'stub-judge',
                   'choices': [{'index': 0, 'finish_reason': 'stop',
                                'message': {'role': 'assistant', 'content': json.dumps({'grades': grades})}}],
                   'usage': {'prompt_tokens': len(text) // 4, 'completion_tokens': 10, 'total_tokens': len(text) // 4 + 10}}
        raw = json.dumps(payload).encode()
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)
        with open('/work/bf/render/stub_log.json', 'w') as f:
            json.dump(LOG, f, indent=1)

if __name__ == '__main__':
    ThreadingHTTPServer(('127.0.0.1', PORT), Handler).serve_forever()
