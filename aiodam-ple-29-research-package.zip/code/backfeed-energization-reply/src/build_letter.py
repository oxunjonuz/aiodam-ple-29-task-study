# -*- coding: utf-8 -*-
"""Build Halbray_Backfeed_Reply.docx from computed.json.  Every number and every quoted string in the
letter comes out of the record; nothing is typed twice."""
import json
from docx import Document
from docx.shared import Pt, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

D = json.load(open('/work/bf/computed.json'))
OUT = '/work/bf/out/Halbray_Backfeed_Reply.docx'

doc = Document()
sec = doc.sections[0]
sec.left_margin = sec.right_margin = Inches(1.0)
sec.top_margin = Inches(0.9); sec.bottom_margin = Inches(0.9)

st = doc.styles['Normal']
st.font.name = 'Calibri'; st.font.size = Pt(10.5)
st.paragraph_format.space_after = Pt(6)
st.paragraph_format.line_spacing = 1.06

def para(text='', bold=False, size=None, align=None, space_after=None, italic=False):
    p = doc.add_paragraph()
    r = p.add_run(text)
    r.bold = bold; r.italic = italic
    if size:
        r.font.size = Pt(size)
    if align == 'c':
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    if space_after is not None:
        p.paragraph_format.space_after = Pt(space_after)
    return p

def rich(parts, space_after=None):
    """parts: list of (text, bold, italic)"""
    p = doc.add_paragraph()
    for t, b, i in parts:
        r = p.add_run(t); r.bold = b; r.italic = i
    if space_after is not None:
        p.paragraph_format.space_after = Pt(space_after)
    return p

def heading(text, level=1):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(10)
    p.paragraph_format.space_after = Pt(4)
    r = p.add_run(text)
    r.bold = True
    r.font.size = Pt(12.5 if level == 1 else 11)
    r.font.color.rgb = RGBColor(0x1F, 0x3A, 0x5F)
    return p

def bullet(text):
    p = doc.add_paragraph(style='List Bullet')
    p.paragraph_format.space_after = Pt(3)
    p.add_run(text)
    return p

def table(rows, widths, header=True, size=8.6):
    t = doc.add_table(rows=0, cols=len(rows[0]))
    t.style = 'Table Grid'
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, row in enumerate(rows):
        cells = t.add_row().cells
        for j, val in enumerate(row):
            cells[j].width = Inches(widths[j])
            cells[j].text = ''
            p = cells[j].paragraphs[0]
            p.paragraph_format.space_after = Pt(1)
            r = p.add_run(str(val))
            r.font.size = Pt(size)
            if header and i == 0:
                r.bold = True
    for row in t.rows:
        for j, c in enumerate(row.cells):
            c.width = Inches(widths[j])
    return t

# ------------------------------------------------------------------ letterhead
para('ALLENIOM UTILITIES — DER PROGRAM OFFICE', bold=True, size=13, align='c', space_after=1)
para('4200 Veldmere Boulevard, Halston, Alleron 01HA · (612) 555-0100 · alleniom.com', size=8.5, align='c', space_after=1)
para('der.program@alleniom.com', size=8.5, align='c', space_after=10)

table([
    ['Date', D['record_date']],
    ['To', 'Imogen Strathe, Project Manager, Halbray Community Solar LP, 6120 Halbray Road, Kelloway Township, Alleron 07KT'],
    ['From', 'S. Rennick, Commissioning, DER Program Office, Alleniom Utilities'],
    ['Copy', 'Tamsworth Electrical Constructors Inc. (permit holder, EP-25-0418); program file PXA-2024-0002'],
    ['Subject', 'Re: your letter of 07/09/2025 — pre-PTO backfeed of Halbray Field Solar Site 3 (PXA-2024-0002) from feeder ALN-159 on 07/29/2025: we cannot energize on that date, and here is what stands in the way'],
], widths=[0.85, 5.65], header=False, size=9)

para('')
para('Dear Ms Strathe,')
para('You closed your letter of 07/09/2025 with "Please confirm the date, or tell us what stands in the way." '
     'We cannot confirm 07/29/2025, and this letter tells you what stands in the way, what each item rests on, '
     'what has to be done about it, and who has to do it.', space_after=8)

# ------------------------------------------------------------------ 1. the answer
heading('1. The answer, stated plainly')
rich([('We cannot energize Halbray Field Solar Site 3 on 07/29/2025: the record shows, in the installation itself, '
       'three breaches of the electrical code that Kelloway Township has adopted for this work, and the permit under '
       'which the work is being built forbids energizing any of it before the Township' + "'" + 's final approval, '
       'which has not been issued.', True, False)])
para('The code is "' + D['adopted_code'] + '" — printed on the face of ' + D['permit_no'] + ' as the adopted code '
     'for this job. The three items are in the work that the '
     'backfeed puts in service and that the Township will inspect on ' + D['inspection_booked'] + ': the tracker row '
     'drive cable, the inverter output conductors on the skids, and the steel strut that carries the auxiliary '
     'panelboard and the tracker controllers. Each is dealt with in section 3, against the drawing that states it and '
     'the section of the code it does not meet.')
para('Two things are worth saying at the start, because both are easy to misread out of a letter of this kind.')
bullet('The pre-PTO backfeed itself is available to you under the executed agreement. ISA-Halbray-Field-Site-3, executed '
       + D['isa_executed'] + ', provides: "' + D['isa_backfeed'] + '" Your written request of ' + D['request_date'] +
       ' is on file. The term gives the Company the ability to energize for construction and commissioning power on a '
       'written request; it does not give either of us the ability to energize an installation that the adopted code '
       'does not permit, and it does not override the Township' + "'" + 's permit condition in section 4 below.')
bullet('Nothing here is a refusal of the project or a lost date. It is a list of three corrections and one permit '
       'condition, with an owner for each. Where they cannot be closed by 07/29/2025 we will re-date the request rather '
       'than refuse it, and we will say so in writing.')

# ------------------------------------------------------------------ 2. what the backfeed energizes
heading('2. What the backfeed would put in service')
para('The backfeed you asked for is not a bare transformer. Under the request it energizes the step-up transformer T-1 '
     'and the 800 V ac collection system from feeder ALN-159 so that your contractor can run the inverters' + "'" +
     ' pre-start checks on utility power. On the record that means:')
bullet('the transformer T-1, ' + format(D['kva'], ',') + ' kVA, ' + str(D['kv_primary']) + ' kV grounded wye to '
       + D['v_secondary'] + ' V, with its ' + str(D['fla_primary']) + ' A primary switch PSW-1;')
bullet('switchboard CSB-1 at 800 V — ' + str(D['fla_secondary']) + ' A full-load secondary current, ' + D['fault_csb1'] +
       ' available fault current — and the four 600 A feeders C-1 to C-4 from it to the four skids;')
bullet('the four ac combiner panels ACP-1 to ACP-4 on the skids, and behind each of them the inverter ac output '
       'circuits, up to the terminals of the twelve inverters (' + str(D['n_xt225']) + ' × ' + D['xt225'] + ', ' +
       str(D['n_xt125']) + ' × ' + D['xt125'] + ');')
bullet('panelboard AUX-1, fed from the ' + str(D['aux_breaker']) + ' A breaker in CSB-1, and through it the eight '
       'tracker controllers TC-1 to TC-8 and the row drive circuits to the ' + str(D['drives_total']) + ' slew drives.')
para('Those four bullets are also the reason the three findings matter: each of them sits on a circuit that is '
     'energized during the backfeed. The agreement describes the customer facilities in the same terms: "' +
     D['isa_customer_facilities'] + '".')

# ------------------------------------------------------------------ 3. the findings
heading('3. The three findings')
heading('3.1 Tracker row drive cable: Type TC run along the row piles, in no raceway and in no cable tray', 2)
para('What the record shows. Drawing ' + D['tracker_drawing_no'] + ' dated ' + D['tracker_drawing_date'] + ', sheet '
     '"Wiring", states the drive circuits as: "' + D['drive_cable'] + '". Sheet "Blocks" shows '
     + str(D['blocks']) + ' blocks of ' + str(D['rows_per_block']) + ' rows, one slew drive per row at ' +
     str(D['drive_vdc']) + ' V dc and ' + ('%g' % D['drive_kw']) + ' kW — ' + str(D['drives_total']) + ' drives and '
     + str(D['drives_total']) + ' cable runs. The row piles are the tracker structure in the field; there is no '
     'raceway and no cable tray on the record along the rows.')
para('What the code requires. Under NFPA 70-2023, Article 336 governs Type TC cable, and it is a tray cable: '
     '§336.10 lists where it may be used — in cable trays, in raceways, supported by a messenger, and as open runs '
     'only in industrial establishments where the conditions of maintenance and supervision ensure that only '
     'qualified persons service the installation. §336.12 states the negative side: Type TC is not permitted '
     '"installed outside of a cable tray system or raceway", except as §336.10 allows. A 2.3 MW community solar '
     'array with 96 drives spread over eight blocks is not an industrial establishment of that kind, and no '
     'maintenance-and-supervision condition that would qualify it as one appears anywhere in the record. So Type TC '
     'cable has to run in a raceway or in a cable tray here, and the drive cable along the row piles does neither.')
para('Why it bears on 07/29/2025. AUX-1, the eight controllers and the drive circuits are energized during the '
     'backfeed, and the trackers are worked for the pre-start checks. The condition is also visible: it is a wiring '
     'method spread along every row of the array, not a hidden detail.')
para('What has to be done, and by whom. The drive cable has to be put in a raceway or a cable tray along the rows, or '
     'replaced with a wiring method Article 336 permits there, or shown so on the record by a revised ' +
     D['tracker_drawing_no'] + '; the rework is Halbray Community Solar LP' + "'" + 's, through its electrical '
     'contractor Tamsworth Electrical Constructors Inc., the permit holder on ' + D['permit_no'] + '. It has to be done '
     'before 07/29/2025, and in practice before the ' + D['inspection_booked'] + ' inspection, which will see it.')

heading('3.2 Inverter output conductors: Type USE-2 used above ground on the skid frame', 2)
para('What the record shows. Drawing ' + D['skid_drawing_no'] + ' dated ' + D['skid_drawing_date'] + ', sheet '
     '"Inverter Circuits", states each ' + D['xt225'] + ' to its ACP breaker as "' + D['cond225'] + '" (' +
     ('%g' % D['i225']) + ' A on a ' + str(D['brk225']) + ' A breaker) and each ' + D['xt125'] + ' as "' +
     D['cond125'] + '" (' + ('%g' % D['i125']) + ' A on a ' + str(D['brk125']) + ' A breaker), with the raceway '
     'column reading "' + D['raceway225'] + '". There are twelve of these circuits, and the skid output is ' +
     str(D['skid_a']) + ' A per skid.')
para('What the code requires. Type USE is underground service-entrance cable. NFPA 70-2023 §338.12(B)(2) does not '
     'permit its use "for aboveground installations except where the cable emerges from the ground and is terminated '
     'in an enclosure at an outdoor location", protected in accordance with §300.5(D). The inverter output circuits '
     'never do that: they run above ground on the skid frame, from the inverter ac terminals to the breaker in the '
     'skid' + "'" + 's combiner panel, as the fixed wiring of the skid. Rigid steel conduit around an aboveground run '
     'does not change the answer, because what the section restricts is the cable type above ground, not only its '
     'exposure — the permitted abovegrade use of a USE conductor is the short emergence into an outdoor enclosure, '
     'and that is not what these circuits are.')
para('Why it bears on 07/29/2025. These twelve circuits are the ones the backfeed energizes directly: power flows '
     'from ALN-159 through T-1 and CSB-1 into each ACP and out to the inverter ac terminals. The pre-start checks '
     'your contractor wants to run are run with these conductors live.')
para('What has to be done, and by whom. The inverter output conductors on the skids have to be replaced with a '
     'conductor type the code permits above ground — for an 800 V ac circuit, a 2 kV Type RHW-2 or XHHW-2 conductor '
     'in the existing rigid steel conduit, or a conductor carrying both markings and shown as such — or shown so on '
     'the record by a revised ' + D['skid_drawing_no'] + '. That is Halbray' + "'" + 's work through Tamsworth '
     'Electrical Constructors Inc., and it has to be done before 07/29/2025 and before the ' +
     D['inspection_booked'] + ' inspection.')

heading('3.3 The strut carrying AUX-1 and the controllers: green enamel finish, outdoors', 2)
para('What the record shows. Drawing ' + D['aux_drawing_no'] + ' dated ' + D['aux_drawing_date'] + ', sheet '
     '"Mounting", states: "' + D['mounting'] + '". The panelboard and the eight controllers sit at the array north edge, '
     'outdoors, in the weather and at grade.')
para('What the code requires. NFPA 70-2023 §300.6(A) requires ferrous metal raceways, cable trays, cablebus, '
     'auxiliary gutters, cable armor, boxes, cabinets, supports, and support hardware to be "suitably protected against '
     'corrosion" both inside and outside by a coating of approved corrosion-resistant material. For steel outdoors in a '
     'wet location the protection the code recognises is galvanizing — hot-dip galvanized strut — or an equivalent '
     'listed, factory-applied corrosion-resistant coating; a shop enamel finish is a paint finish and is not corrosion '
     'protection for that service. Steel supports outdoors therefore have to carry more corrosion protection than '
     'enamel alone, and the green-enamel strut does not.')
para('Why it bears on 07/29/2025. The strut is the support of the panelboard and of the controllers that are energized '
     'in the backfeed; it is also the part of the installation that a corrosion inspection looks at first.')
para('What has to be done, and by whom. The enamel strut has to be replaced with strut carrying corrosion protection '
     'suited to outdoors — hot-dip galvanized, or an equivalent listed finish — or given that protection and shown so '
     'on the record by a revised ' + D['aux_drawing_no'] + '. That is Halbray' + "'" + 's work through Tamsworth '
     'Electrical Constructors Inc., before 07/29/2025 and before the ' + D['inspection_booked'] + ' inspection.')

# ------------------------------------------------------------------ 4. the permit condition
heading('4. The second thing that stands in the way: the Township' + "'" + 's permit condition')
para('Permit ' + D['permit_no'] + ', issued ' + D['permit_issued'] + ' to ' + D['permit_holder'] + ', carries a '
     'condition in one line: "' + D['energize_rule'] + '" Its scope of work is "' + D['permit_scope'] + '" — that is, '
     'the work the backfeed energizes. The condition is not ours to waive: we are '
     'not the authority having jurisdiction, and the Township' + "'" + 's permit is not ours to reinterpret.')
para('The final inspection is booked for ' + D['inspection_booked'] + ' (your letter of ' + D['request_date'] + '; '
     'checklist ' + D['cx_docno'] + '), ' + str(D['days_inspection_to_backfeed']) + ' days before the date you asked '
     'for. As of today it has not taken place, so no written final approval is on the record. So the second condition '
     'on 07/29/2025 is this: the final inspection booked for ' + D['inspection_booked'] +
     ' has to pass, and Kelloway Township' + "'" + 's written final approval has to be in hand before 07/29/2025. On '
     'the record as it stands it cannot pass while the three items in section 3 are open: all three are in the work the '
     'inspector will look at, and the first two are wiring methods that no inspection note can cure.')
para('Halbray Community Solar LP, or its permit holder Tamsworth Electrical Constructors Inc., is the party that gets '
     'the final inspection passed and obtains the written final approval; the permit is the permit holder' + "'" + 's. '
     'We will attend the inspection and answer for the utility-owned equipment, and we will do it as soon as you tell '
     'us the date, but we cannot obtain the Township' + "'" + 's approval for you.')

# ------------------------------------------------------------------ 5. what is not in the way
heading('5. What is not in the way')
para('So that you can plan the rest of the work, the utility-side conditions on our own list are met on the record as '
     'it stands:')
bullet('utility RTU installed and end-to-end point-to-point test accepted by SCADA/EMS Engineering, 07/02/2025 '
       '(TCS-02 §3.6);')
bullet('POI recloser settings and protection coordination study issued by Distribution Protection Engineering, '
       '06/16/2025 (DPS-07 §5.1), and POI recloser site acceptance items 1 to 7 accepted in writing, 07/07/2025 '
       '(DPS-07 §6.2);')
bullet('revenue meter RM-0002 set by Alleniom Metering, 07/08/2025;')
bullet('inverters ' + D['xt225'] + ' (' + str(D['n_xt225']) + ') and ' + D['xt125'] + ' (' + str(D['n_xt125']) + ') '
       'in the body of the certified equipment list CEL-2025-Q2 (ENG-PRC-014 §4.1).')
para('Halbray Field Solar Site 3 is not on the register of completed sites awaiting utility equipment; the equipment '
     'is already in and accepted. What remains on the utility side is the switching, which Distribution Operations '
     'performs under its own switching order — "' + D['isa_switching'] + '" — so the date is theirs to set as well as '
     'ours, and it is set only when the two conditions above are closed.')

# ------------------------------------------------------------------ 6. what we ask
heading('6. What we ask you to do, and by when')
table([
    ['#', 'Action', 'Who', 'By'],
    ['1', 'Rework the tracker row drive cable (Type TC) into a raceway or a cable tray along the rows, or replace it '
          'with a wiring method Article 336 permits there, and issue revised ' + D['tracker_drawing_no'] + '.',
     'Halbray Community Solar LP through Tamsworth Electrical Constructors Inc.', 'before the ' + D['inspection_booked'] + ' inspection'],
    ['2', 'Replace the inverter output conductors (Type USE-2) with a conductor type the code permits above ground, or '
          'show the permitted marking, and issue revised ' + D['skid_drawing_no'] + '.',
     'Halbray Community Solar LP through Tamsworth Electrical Constructors Inc.', 'before the ' + D['inspection_booked'] + ' inspection'],
    ['3', 'Replace the green-enamel strut with strut carrying corrosion protection suited to outdoors, or give it that '
          'protection, and issue revised ' + D['aux_drawing_no'] + '.',
     'Halbray Community Solar LP through Tamsworth Electrical Constructors Inc.', 'before the ' + D['inspection_booked'] + ' inspection'],
    ['4', 'Pass the final inspection booked for ' + D['inspection_booked'] + ' and put Kelloway Township' + "'" + 's '
          'written final approval in our hands.',
     'Halbray Community Solar LP or its permit holder Tamsworth Electrical Constructors Inc.',
     D['inspection_booked'] + ', and in our hands before ' + D['backfeed_date']],
    ['5', 'Written notice to us as each of items 1 to 3 is closed, with the revised drawing.',
     'Halbray Community Solar LP', 'as each is done'],
], widths=[0.3, 2.9, 1.9, 1.4], size=8.4)
para('')
para('If items 1 to 4 are closed and the Township' + "'" + 's written final approval is in our hands before '
     + D['backfeed_date'] + ', we will take your backfeed request to Distribution Operations the same day and confirm '
     'the earliest date they can switch it; the agreement provides that "' + D['isa_disabled'].rstrip('.') + '", and we '
     'will hold you to that. Your letter of ' + D['request_date'] + ' already says: "' + D['request_inverters'] + '" That is the '
     'condition of the backfeed, and we will satisfy ourselves on site that the generating facility is disabled '
     'before any switching. If the approval comes later than that, we will re-date the request — not refuse it — and tell you the new date in '
     'writing. What we will not do is confirm 07/29/2025 in advance of those items, or energize without them.')

# ------------------------------------------------------------------ 7. basis and limits
heading('7. What this reply rests on, and its limits')
para('This reply is made from the record as it stands at ' + D['record_date'] + ': ISA-Halbray-Field-Site-3 executed ' +
     D['isa_executed'] + '; permit ' + D['permit_no'] + ' issued ' + D['permit_issued'] + '; drawings ' +
     D['eq_drawing_no'] + ', ' + D['aux_drawing_no'] + ', ' + D['tracker_drawing_no'] + ' and ' + D['skid_drawing_no'] +
     ', all dated ' + D['tracker_drawing_date'] + '; commissioning checklist ' + D['cx_docno'] + '; and your letter of '
     + D['request_date'] + '. It is an engineering review of the record, not a site inspection: if the as-built '
     'condition differs from the drawings, send us the as-built and we will review that instead, and if any of the '
     'three items has already been corrected, send the revised drawing and we will take it off the list. Nothing in '
     'this letter waives any provision of the agreement or of the tariff.')
para('We would rather have written to confirm the date. Tell us when the three items are corrected and the Township' +
     "'" + 's approval is in hand, and we will move at once.')

para('')
para('Yours sincerely,')
para('')
para('S. Rennick', bold=True)
para('Commissioning, DER Program Office', size=10)
para('Alleniom Utilities · (612) 555-0100 · der.program@alleniom.com', size=10)
para('')
para('Enclosure: Table 1 — the three findings, the record they rest on, and the code basis.', size=9)

# ------------------------------------------------------------------ enclosure table on its own page
doc.add_page_break()
heading('Table 1. The three findings against the record and the code')
table([
    ['#', 'What is installed (record)', 'What the code requires (NFPA 70-2023, adopted by Ordinance 2024-03)',
     'What has to be done'],
    ['1', D['drive_cable'] + ' — ' + D['tracker_drawing_no'] + ', ' + D['tracker_drawing_date'],
     'Article 336: Type TC is a tray cable. §336.10 permits cable trays, raceways, messenger support, and open runs '
     'only in industrial establishments with qualified maintenance and supervision; §336.12 does not permit it '
     '"installed outside of a cable tray system or raceway" beyond that. A tracker row is not an industrial '
     'establishment.',
     'Raceway or cable tray along the rows, or a permitted wiring method, or a revised ' + D['tracker_drawing_no'] + '.'],
    ['2', D['cond225'] + ' and ' + D['cond125'] + ', "' + D['raceway225'] + '" — ' + D['skid_drawing_no'] + ', '
     + D['skid_drawing_date'],
     '§338.12(B)(2): Type USE is not permitted "for aboveground installations except where the cable emerges from the '
     'ground and is terminated in an enclosure at an outdoor location", protected per §300.5(D).',
     'A conductor type permitted above ground, or the dual marking shown, or a revised ' + D['skid_drawing_no'] + '.'],
    ['3', D['mounting'] + ' — ' + D['aux_drawing_no'] + ', ' + D['aux_drawing_date'],
     '§300.6(A): ferrous metal supports and support hardware shall be "suitably protected against corrosion" inside and '
     'outside by a coating of approved corrosion-resistant material — galvanizing or an equivalent listed finish, not '
     'enamel alone.',
     'Galvanized or equivalently protected strut, or a revised ' + D['aux_drawing_no'] + '.'],
], widths=[0.3, 1.7, 2.8, 1.7], size=8.0)

doc.save(OUT)
print('wrote', OUT)
