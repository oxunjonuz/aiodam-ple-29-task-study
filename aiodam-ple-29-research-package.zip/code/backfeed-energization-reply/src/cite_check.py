# -*- coding: utf-8 -*-
"""Two questions, per quote the letter makes: (1) does the letter actually contain it, word for word?
(2) does the file it is attributed to contain it, word for word?  A quote that is in neither list of
declared sources is reported, so a quote I invented cannot hide."""
import json, re, sys, openpyxl, pymupdf, os

BASE = '/work/ple-dataset/tasks/backfeed-energization-reply/environment/files'
LETTER = sys.argv[1] if len(sys.argv) > 1 else '/work/bf/render/Halbray_Backfeed_Reply.pdf.txt'
D = json.load(open('/work/bf/computed.json'))

def norm(s):
    s = s.replace('\u00ad', '')
    s = re.sub(r'-\s*\n\s*', '-', s)
    s = re.sub(r'\s+', ' ', s)
    return s.replace('“', '"').replace('”', '"').replace('’', "'").strip().lower()

def pdf_text(rel):
    d = pymupdf.open(os.path.join(BASE, rel))
    return norm('\n'.join(p.get_text() for p in d))

def xlsx_text(rel):
    wb = openpyxl.load_workbook(os.path.join(BASE, rel), data_only=True)
    parts = list(wb.sheetnames)
    for ws in wb.worksheets:
        for row in ws.iter_rows(values_only=True):
            parts.extend(str(c) for c in row if c is not None)
    return norm(' '.join(parts))

SOURCES = {
    'request': lambda: pdf_text('Correspondence/2025-07-09_Halbray_Backfeed_Request.pdf'),
    'permit': lambda: pdf_text('Correspondence/2025-05-12_Kelloway_Township_Electrical_Permit_EP-25-0418.pdf'),
    'isa': lambda: pdf_text('Contracts/ISA-Halbray-Field-Site-3_Executed_Summary.pdf'),
    'checklist': lambda: pdf_text('Commissioning/PXA-2024-0002_Halbray_Commissioning_Checklist.pdf'),
    'tracker': lambda: xlsx_text('Equipment/PXA-2024-0002_Halbray_Tracker_Row_Wiring_Schedule.xlsx'),
    'skid': lambda: xlsx_text('Equipment/PXA-2024-0002_Halbray_Inverter_Skid_Schedule.xlsx'),
    'equipment': lambda: xlsx_text('Equipment/PXA-2024-0002_Halbray_Equipment_Schedule.xlsx'),
    'aux': lambda: xlsx_text('Equipment/PXA-2024-0002_Halbray_Auxiliary_Power_and_Controls_Schedule.xlsx'),
}
HAY = {k: f() for k, f in SOURCES.items()}

DECLARED = [
    ('request_close', 'request'), ('request_inverters', 'request'), ('strathe', 'request'),
    ('isa_backfeed', 'isa'), ('isa_switching', 'isa'), ('isa_customer_facilities', 'isa'), ('isa_disabled', 'isa'),
    ('adopted_code', 'permit'), ('energize_rule', 'permit'), ('permit_holder', 'permit'),
    ('permit_scope', 'permit'),
    ('drive_cable', 'tracker'),
    ('cond225', 'skid'), ('cond125', 'skid'), ('raceway225', 'skid'),
    ('mounting', 'aux'),
    ('cx_docno', 'checklist'),
]
CODE = {
    'installed outside of a cable tray system or raceway': 'NEC 2023 §336.12',
    'for aboveground installations except where the cable emerges from the ground and is terminated in an enclosure at an outdoor location': 'NEC 2023 §338.12(B)(2)',
    'suitably protected against corrosion': 'NEC 2023 §300.6(A)',
}

letter = norm(open(LETTER, encoding='utf-8').read())
ok = miss_letter = miss_source = 0
for key, src in DECLARED:
    q = norm(D[key])
    in_letter = q in letter or q.rstrip('.') in letter
    in_source = q in HAY[src]
    if in_letter and in_source:
        ok += 1
    else:
        if not in_letter:
            miss_letter += 1
            print(f'  NOT IN LETTER  {key} ({src}): {q[:110]!r}')
        if not in_source:
            miss_source += 1
            print(f'  NOT IN SOURCE  {key} ({src}): {q[:110]!r}')

print(f'{ok}/{len(DECLARED)} declared quotes verbatim in the letter AND in their source file '
      f'({miss_letter} missing from the letter, {miss_source} missing from the source)')

# the code fragments: must be in the letter, and are declared code text (the code is not in the record)
for q, why in CODE.items():
    print(('  ok   ' if q in letter else '  LOST ') + f'{why}: {q[:70]!r}')

# anything else the letter quotes: report it, so an invented quote cannot pass unnoticed
quoted = []
for m in re.finditer(r'"([^"]*)"', letter):
    q = m.group(1).strip()
    if len(q) < 12 or q in quoted:
        continue
    if any(q in norm(D[k]) or norm(D[k]) in q for k, _ in DECLARED) or q in CODE:
        quoted.append(q)
        continue
    quoted.append(q)
    hit = [k for k, h in HAY.items() if q in h]
    print(('  extra ok  ' if hit else '  EXTRA QUOTE not in any source: ') + repr(q[:100]) + (f' -> {hit}' if hit else ''))
