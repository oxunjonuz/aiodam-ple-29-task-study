# -*- coding: utf-8 -*-
"""Mutation campaign: break one statement at a time in the .docx (in every place the document makes it),
render with the task's own transform.py, and see whether checks.py notices.  A mutation that survives is
either an incomplete mutation or a hole in the reader; each survivor is read by hand."""
import json, os, re, shutil, subprocess, sys
from docx import Document

SRC = '/work/bf/out/Halbray_Backfeed_Reply.docx'
WORK = '/work/bf/work_mut'
TR = '/work/ple-dataset/tasks/backfeed-energization-reply/tests/tools/verifiers/../tools/verifiers/deps/transform.py'
TR = '/work/ple-dataset/tasks/backfeed-energization-reply/tests/tools/verifiers/deps/transform.py'
sys.path.insert(0, '/work/bf/src')
import checks as C

MUT = [
 # id, criterion expected to go red, [(old, new)] applied to EVERY paragraph that contains old
 ('m00_code_breach_is_only_good_practice', 'c0_answer_breach_in_installation', [
    ('three breaches of the electrical code that Kelloway Township has adopted for this work',
     'three departures from good engineering practice on this job'),
 ]),
 ('m01_type_tc_becomes_type_se', 'c1_type_tc_raceway_or_tray', [
    ('Type TC', 'Type SE'),
 ]),
 ('m02_use_quote_becomes_permission', 'c2_type_use_out_of_ground_into_enclosure', [
    ('for aboveground installations except where the cable emerges from the ground and is terminated in an enclosure at an outdoor location',
     'for aboveground installations where the cable is run in rigid steel conduit on the skid frame'),
 ]),
 ('m03_enamel_is_enough', 'c3_strut_needs_more_than_enamel', [
    ('the protection the code recognises is galvanizing — hot-dip galvanized strut — or an equivalent listed, factory-applied corrosion-resistant coating; a shop enamel finish is a paint finish and is not corrosion protection for that service',
     'the protection the code recognises is any shop-applied finish of the installer\'s choosing; an enamel finish is one of them'),
    ('galvanizing or an equivalent listed finish, not enamel alone',
     'any shop-applied finish, enamel included'),
    ('hot-dip galvanized, or an equivalent listed finish',
     'any shop-applied finish'),
    ('Galvanized or equivalently protected strut, or a revised E-202 Rev B.',
     'Any strut finish, or a revised E-202 Rev B.'),
    ('by a coating of approved corrosion-resistant material', 'by a coating chosen by the installer'),
 ]),
 ('m04_drive_cable_left_as_is', 'c4_drive_cable_fix_before_date', [
    ('The drive cable has to be put in a raceway or a cable tray along the rows, or replaced with a wiring method Article 336 permits there, or shown so on the record by a revised E-203 Rev B; the rework is Halbray Community Solar LP',
     'The drive cable can stay as the record shows it, with the condition carried into the next revision cycle; the rework is Halbray Community Solar LP'),
    ('It has to be done before 07/29/2025, and in practice before the 07/24/2025 inspection, which will see it.',
     'Nothing has to be done before 07/29/2025 for this item.'),
 ]),
 ('m05_inverter_conductors_need_no_change', 'c5_inverter_conductors_fix_before_date', [
    ('The inverter output conductors on the skids have to be replaced with a conductor type the code permits above ground',
     'The inverter output conductors on the skids can stay as drawn'),
    ('or shown so on the record by a revised E-301 Rev B. That is Halbray\'s work through Tamsworth Electrical Constructors Inc., and it has to be done before 07/29/2025 and before the 07/24/2025 inspection.',
     'No revision is needed. That is Halbray\'s work through Tamsworth Electrical Constructors Inc.'),
    ('A conductor type permitted above ground, or the dual marking shown, or a revised E-301 Rev B.',
     'The conductors as drawn, and no revision of E-301 Rev B.'),
    ('Replace the inverter output conductors (Type USE-2) with a conductor type the code permits above ground, or show the permitted marking, and issue revised E-301 Rev B.',
     'Leave the inverter output conductors (Type USE-2) as drawn.'),
 ]),
 ('m06_strut_need_not_be_touched', 'c6_strut_fix_before_date', [
    ('The enamel strut has to be replaced with strut carrying corrosion protection suited to outdoors — hot-dip galvanized, or an equivalent listed finish — or given that protection and shown so on the record by a revised E-202 Rev B.',
     'The enamel strut can stay as drawn, and no revision to E-202 Rev B is needed.'),
    ('That is Halbray\'s work through Tamsworth Electrical Constructors Inc., before 07/29/2025 and before the 07/24/2025 inspection.',
     'That is Halbray\'s work through Tamsworth Electrical Constructors Inc., at its convenience.'),
    ('Replace the green-enamel strut with strut carrying corrosion protection suited to outdoors, or give it that protection, and issue revised E-202 Rev B.',
     'Leave the green-enamel strut as drawn.'),
 ]),
 ('m07_drive_cable_is_utility_work', 'c7_who_reworks_drive_cable', [
    ('the rework is Halbray Community Solar LP\'s, through its electrical contractor Tamsworth Electrical Constructors Inc., the permit holder on EP-25-0418. It has to be done',
     'the rework is Alleniom Utilities\' own, done by its line crews. It has to be done'),
    ('Halbray Community Solar LP through Tamsworth Electrical Constructors Inc.', 'Alleniom Utilities line crews'),
 ]),
 ('m08_inverter_conductors_are_utility_work', 'c8_who_replaces_inverter_conductors', [
    ('That is Halbray\'s work through Tamsworth Electrical Constructors Inc., and it has to be done before 07/29/2025 and before the 07/24/2025 inspection.',
     'That is Alleniom Utilities\' work, and it has to be done before 07/29/2025 and before the 07/24/2025 inspection.'),
    ('Halbray Community Solar LP through Tamsworth Electrical Constructors Inc.', 'Alleniom Utilities line crews'),
 ]),
 ('m09_strut_is_utility_work', 'c9_who_replaces_strut', [
    ('That is Halbray\'s work through Tamsworth Electrical Constructors Inc., before 07/29/2025 and before the 07/24/2025 inspection.',
     'That is Alleniom Utilities\' work, before 07/29/2025 and before the 07/24/2025 inspection.'),
    ('Halbray Community Solar LP through Tamsworth Electrical Constructors Inc.', 'Alleniom Utilities line crews'),
 ]),
 ('m12_permit_condition_reversed', 'c12_no_energizing_before_final_approval', [
    ('carries a condition in one line: "No permitted work shall be energized before final approval."',
     'carries a condition in one line: "Permitted work may be energized once the construction is complete."'),
 ]),
 ('m13_letter_to_someone_else', 'c13_addressed_to_strathe', [
    ('Imogen Strathe', 'Bronwyn Kessel'),
    ('Dear Ms Strathe', 'Dear Ms Kessel'),
 ]),
 ('m14_inspection_need_not_pass', 'c14_inspection_pass_and_approval_before_date', [
    ('the final inspection booked for 07/24/2025 has to pass, and Kelloway Township\'s written final approval has to be in hand before 07/29/2025',
     'the final inspection booked for 07/24/2025 will be attended, and whatever it finds can be dealt with after 07/29/2025'),
    ('Pass the final inspection booked for 07/24/2025 and put Kelloway Township\'s written final approval in our hands.',
     'Attend the final inspection booked for 07/24/2025.'),
    ('07/24/2025, and in our hands before 07/29/2025', '07/24/2025, and the rest later'),
 ]),
 ('m15_utility_gets_inspection_passed', 'c15_who_gets_inspection_passed', [
    ('Halbray Community Solar LP, or its permit holder Tamsworth Electrical Constructors Inc., is the party that gets the final inspection passed and obtains the written final approval; the permit is the permit holder\'s.',
     'Alleniom Utilities is the party that gets the final inspection passed and obtains the written final approval.'),
    ('Halbray Community Solar LP or its permit holder Tamsworth Electrical Constructors Inc.', 'Alleniom Utilities'),
 ]),
 ('m16_date_confirmed', 'c16_cannot_energize_or_confirm', [
    ('We cannot energize', 'We will energize'),
    ('We cannot confirm 07/29/2025', 'We confirm 07/29/2025'),
    ('we cannot energize on that date', 'we will energize on that date'),
    ('What we will not do is confirm 07/29/2025', 'What we will do is confirm 07/29/2025'),
 ]),
 # a control mutation that changes nothing a criterion speaks about
 ('m99_control_harmless', None, [
    ('program file PXA-2024-0002', 'program file PXA-2024-0002 (copy to the site office)'),
 ]),
]

def all_paragraphs(doc):
    out = list(doc.paragraphs)
    for tb in doc.tables:
        for row in tb.rows:
            for cell in row.cells:
                out.extend(cell.paragraphs)
                for t2 in cell.tables:
                    for r2 in t2.rows:
                        for c2 in r2.cells:
                            out.extend(c2.paragraphs)
    return out

def apply(doc, pairs):
    applied = []
    for old, new in pairs:
        n = 0
        for p in all_paragraphs(doc):
            if old in p.text:
                txt = p.text.replace(old, new)
                for r in list(p.runs)[1:]:
                    r._element.getparent().remove(r._element)
                if p.runs:
                    p.runs[0].text = txt
                else:
                    p.add_run(txt)
                n += 1
        applied.append((old[:40], n))
    return applied

def render(docx, outdir):
    os.makedirs(outdir, exist_ok=True)
    pdf = os.path.join(outdir, 'Halbray_Backfeed_Reply.pdf')
    env = dict(os.environ, PYTHONPATH='/work/venv-verifier/lib/python3.12/site-packages')
    r = subprocess.run(['python3', TR, '--input', docx, '--output', pdf, '--transformation', 'docx_to_pdf'],
                       capture_output=True, text=True, env=env)
    if r.returncode != 0:
        return None, r.stderr[-300:]
    txt = os.path.join(outdir, 'text.txt')
    r2 = subprocess.run(['python3', TR, '--input', pdf, '--output', txt, '--transformation', 'pdf_to_text'],
                        capture_output=True, text=True, env=env)
    if r2.returncode != 0:
        return None, r2.stderr[-300:]
    return open(txt, encoding='utf-8').read(), None

def main():
    base_text, err = render(SRC, os.path.join(WORK, 'base'))
    assert base_text, err
    base = C.run_text(base_text)
    red0 = [k for k, v in base.items() if not v]
    print('baseline red:', red0)

    shutil.rmtree(WORK, ignore_errors=True)
    rows = []
    for mid, target, pairs in MUT:
        d = Document(SRC)
        applied = apply(d, pairs)
        missing = [a for a in applied if a[1] == 0]
        outdir = os.path.join(WORK, mid)
        os.makedirs(outdir, exist_ok=True)
        path = os.path.join(outdir, 'Halbray_Backfeed_Reply.docx')
        d.save(path)
        text, err = render(path, outdir)
        if text is None:
            rows.append((mid, target, 'RENDER FAILED', err, missing))
            print(mid, 'RENDER FAILED', err)
            continue
        res = C.run_text(text)
        newly_red = sorted(k for k, v in res.items() if not v and base[k])
        caught = (target is None and not newly_red) or (target is not None and target in newly_red)
        rows.append((mid, target, 'CAUGHT' if caught else 'SURVIVED', newly_red, missing))
        print(f'{mid:45s} target={str(target):45s} {"CAUGHT" if caught else "SURVIVED":8s} red={newly_red} missing={missing}')
    json.dump([[a, b, c, d, e] for a, b, c, d, e in rows], open('/work/bf/mutations.json', 'w'), indent=1)
    ok = sum(1 for r in rows if r[2] == 'CAUGHT')
    print(f'\n{ok}/{len(rows)} as intended')

if __name__ == '__main__':
    main()
