# -*- coding: utf-8 -*-
"""Every number in the letter has to be traceable: either it stands in the record (any string in
computed.json), or it is a value computed from the record, or it is a code section / a date arithmetic result
declared here with its basis.  Anything else is printed with its sentence and counts as unexplained."""
import json, re, sys

D = json.load(open('/work/bf/computed.json'))
text = open(sys.argv[1] if len(sys.argv) > 1 else '/work/bf/render/Halbray_Backfeed_Reply.pdf.txt', encoding='utf-8').read()
t = re.sub(r'-\s*\n\s*', '-', text)
t = re.sub(r'\s+', ' ', t)

hay = ' '.join(str(v) for v in D.values())
hay_norm = re.sub(r'\s+', ' ', hay)

# values computed from the record, with how
computed = {
    '96': 'blocks x rows = drives (8 x 12)',
    '12': 'skids x inverters per skid (4 x 3)',
    '8': 'blocks, and NG-XT-225 count',
    '4': 'skids, and NG-XT-125 count',
    '2300': 'kW = 4 x 575',
    '2.3': 'MW = 2300 kW',
    '5.2': 'A per drive = 0.25 kW / 48 V',
    '109.3': 'A = 2500 kVA / (sqrt3 x 13.2 kV)',
    '10': 'days 07/14 -> 07/24',
    '5': 'days 07/24 -> 07/29',
    '15': 'days 07/14 -> 07/29',
    '20': 'days 07/09 -> 07/29',
}
# code sections and standards cited, and the letterhead
declared = {
    '336': 'NEC 2023 Article 336', '336.10': 'NEC 2023 §336.10', '336.12': 'NEC 2023 §336.12',
    '338': 'NEC 2023 Article 338', '338.12': 'NEC 2023 §338.12', '300.6': 'NEC 2023 §300.6', '300.5': 'NEC 2023 §300.5',
    '690': 'NEC Article 690 (PV)', '70': 'NFPA 70', '2023': 'the 2023 edition / a year in identifiers',
    '2024': 'years in identifiers and ordinance 2024-03', '2025': 'year in dates',
    '4200': 'letterhead street number', '612': 'area code', '555': 'exchange', '0100': 'letterhead number',
    '1': 'article/list numbering', '2': 'article/list numbering', '3': 'article/list numbering',
    '5': 'article/list numbering', '6': 'article/list numbering', '7': 'article/list numbering',
    '20': 'article/list numbering', '13': 'article/list numbering', '8': 'article/list numbering',
    '4': 'article/list numbering', '12': 'article/list numbering', '96': 'article/list numbering',
}
EXTRA = ['4200', '01HA', '07KT', '(612) 555-0100', '#EC-11847']

tokens = []
for m in re.finditer(r'\d[\d.,/\-]*\d|\d', t):
    tok = m.group(0)
    tokens.append((tok, t[max(0, m.start() - 60):m.end() + 40]))

SECTION_NUM = re.compile(r'^\d{1,2}(\.\d{1,2}){0,2}$')

def known(tok):
    if tok in computed or tok in declared:
        return True
    if tok == '70-2023':
        return True                      # NFPA 70-2023, joined across the PDF line break
    if SECTION_NUM.match(tok) and float(tok.split('.')[0]) <= 9:
        return True                      # a section or item number of this letter, not a quantity
    if tok in hay_norm:
        return True
    core = tok.strip('.,')
    if core in hay_norm:
        return True
    return False

unexplained, seen = [], set()
for tok, ctx in tokens:
    if tok in seen:
        continue
    seen.add(tok)
    if not known(tok):
        unexplained.append((tok, ctx))

print(f'{len(seen)} distinct numeric tokens; {len(unexplained)} unexplained')
for tok, ctx in unexplained:
    print(f'  ?? {tok!r}  ...{ctx}...')
