# -*- coding: utf-8 -*-
"""The rubric as code: 17 checks, one per criterion of tests/grader/criteria.json, plus 5 closure checks
of my own.  Written before the letter's text, from the criteria read in the task folder.

Each check reads the text the judge reads (the PDF twin), plus the file-name fact and, for index 11,
db_diff.txt.  Elements of one criterion must stand in one window of consecutive sentences (three), so
that a statement spread across the whole document does not pass as one statement.
"""
import re

NUM = r'[\d.,]+'

def normalize(t):
    t = t.replace('\u00ad', '')
    t = re.sub(r'-\s*\n\s*', '-', t)          # NFPA 70-\n2023 -> NFPA 70-2023
    t = re.sub(r'\s+', ' ', t)
    t = t.replace('“', '"').replace('”', '"').replace('’', "'").replace('‘', "'")
    t = t.replace('\u2014', '—')
    t = re.sub(r'\s+([,.;:)])', r'\1', t)
    return t.strip()

def sentences(t):
    parts = re.split(r'(?<=[.!?;])\s+(?=[A-Z0-9"“(§])', t)
    return [p.strip() for p in parts if p.strip()]

def windows(sents, k=3):
    return [' '.join(sents[i:i + k]) for i in range(len(sents))]

BLOCK_STARTS = [
    r'1\. The answer, stated plainly', r'2\. What the backfeed would put in service',
    r'3\. The three findings', r'3\.1 Tracker row drive cable', r'3\.2 Inverter output conductors',
    r'3\.3 The strut carrying AUX-1', r'4\. The second thing that stands in the way',
    r'5\. What is not in the way', r'6\. What we ask you to do', r'7\. What this reply rests on',
    r'Table 1\. The three findings', r'What the record shows\.', r'What the code requires\.',
    r'Why it bears on 07/29/2025\.', r'What has to be done, and by whom\.', r'Dear Ms Strathe',
    r'Two things are worth saying', r'Halbray Field Solar Site 3 is not on the register',
    r'If items 1 to 4 are closed', r'We would rather have written', r'So that you can plan',
    r'Those four bullets are also the reason',
]
BLOCK_RE = re.compile('|'.join('(%s)' % b for b in BLOCK_STARTS))

def segments(t):
    """Paragraph blocks: split at every section heading and every paragraph lead-in, so a statement has
    to be made inside one block and not assembled out of two."""
    parts, last = [], 0
    bounds = [m.start() for m in BLOCK_RE.finditer(t)]
    for b in bounds:
        if b > last:
            parts.append(t[last:b])
        last = b
    parts.append(t[last:])
    return [p.strip() for p in parts if p.strip()]

def win_has(t, *needles):
    return any(all(n.lower() in w.lower() for n in needles) for seg in segments(t) for w in windows(sentences(seg)))

def any_of(*needles):
    return list(needles)

def has_all(window, groups):
    w = window.lower()
    return all(any(alt.lower() in w for alt in group) for group in groups)

def win_has_groups(t, groups, k=3):
    return any(has_all(w, groups) for seg in segments(t) for w in windows(sentences(seg), k))

CHECKS = []   # (name, function(text, ctx)->bool, criterion index or None for closure)

def check(name, index=None, closure=False):
    def deco(fn):
        CHECKS.append((name, fn, index, closure))
        return fn
    return deco

# ------------------------------------------------------------------ criterion 0 (weight 10)
@check('c0_answer_breach_in_installation', 0)
def c0(t, ctx):
    # a plain "we cannot energize on 07/29/2025" tied to a code breach the record shows in the installation
    return win_has_groups(t, [
        ['07/29/2025'],
        ['cannot energize', "can not energize", 'cannot confirm'],
        ['breach', 'violat', 'does not comply', 'not comply', 'noncompliance', 'non-compliance'],
        ['electrical code', 'NFPA 70', 'NEC'],
        ['record', 'installation'],
    ], k=2)

# ------------------------------------------------------------------ criterion 1 (weight 9)
@check('c1_type_tc_raceway_or_tray', 1)
def c1(t, ctx):
    return win_has_groups(t, [
        ['type tc'],
        ['raceway'],
        ['cable tray'],
        ['row pile', 'along the rows', 'tracker row', 'the rows'],
        ['336', 'article 336'],
    ], k=3)

# ------------------------------------------------------------------ criterion 2 (weight 9)
@check('c2_type_use_out_of_ground_into_enclosure', 2)
def c2(t, ctx):
    return win_has_groups(t, [
        ['type use'],
        ['above ground', 'aboveground', 'above grade', 'abovegrade'],
        ['emerges from the ground', 'out of the ground', 'comes out of the ground'],
        ['enclosure'],
        ['inverter output'],
        ['338'],
    ], k=3)

# ------------------------------------------------------------------ criterion 3 (weight 9)
@check('c3_strut_needs_more_than_enamel', 3)
def c3(t, ctx):
    return win_has_groups(t, [
        ['strut'],
        ['enamel'],
        ['corrosion'],
        ['galvaniz', 'corrosion-resistant coating', 'approved corrosion-resistant', 'factory-applied'],
        ['outdoor', 'outdoors', 'wet location'],
        ['300.6'],
    ], k=3)

# ------------------------------------------------------------------ criteria 4-6 (weight 2 each): what has to be done, before 07/29/2025
@check('c4_drive_cable_fix_before_date', 4)
def c4(t, ctx):
    return win_has_groups(t, [
        ['drive cable', 'type tc'],
        ['raceway', 'cable tray', 'replaced', 'replace'],
        ['07/29/2025'],
        ['shown so on the record', 'shown on the record', 'revised', 'rework'],
    ], k=2)

@check('c5_inverter_conductors_fix_before_date', 5)
def c5(t, ctx):
    return win_has_groups(t, [
        ['inverter output conductor', 'type use-2', 'type use'],
        ['replace', 'replaced'],
        ['above ground', 'aboveground'],
        ['07/29/2025'],
        ['shown so on the record', 'shown on the record', 'revised'],
    ], k=2)

@check('c6_strut_fix_before_date', 6)
def c6(t, ctx):
    return win_has_groups(t, [
        ['strut'],
        ['replace', 'replaced', 'given that protection', 'galvaniz'],
        ['07/29/2025'],
        ['shown so on the record', 'shown on the record', 'revised'],
    ], k=2)

# ------------------------------------------------------------------ criteria 7-9 (weight 2 each): who
@check('c7_who_reworks_drive_cable', 7)
def c7(t, ctx):
    return win_has_groups(t, [
        ['drive cable'],
        ['halbray'],
        ['tamsworth'],
        ['work', 'rework', 'through'],
    ], k=2)

@check('c8_who_replaces_inverter_conductors', 8)
def c8(t, ctx):
    return win_has_groups(t, [
        ['inverter output conductor'],
        ['halbray'],
        ['tamsworth'],
        ['replace', 'replaced'],
    ], k=2)

@check('c9_who_replaces_strut', 9)
def c9(t, ctx):
    return win_has_groups(t, [
        ['strut'],
        ['halbray'],
        ['tamsworth'],
        ['replace', 'replaced', 'galvaniz'],
    ], k=2)

# ------------------------------------------------------------------ criterion 10 (weight 1): the file
@check('c10_file_named', 10)
def c10(t, ctx):
    return bool(ctx.get('filename_present'))

# ------------------------------------------------------------------ criterion 11 (weight 2): the work package
@check('c11_work_package_in_db_diff', 11)
def c11(t, ctx):
    d = ctx.get('db_diff')
    if not d:
        return False                      # nothing in the apps: no work package was created
    low = d.lower()
    return ('halbray' in low and 'der program backlog review' in low and 'type tc' in low
            and 'use-2' in low and 'strut' in low
            and ('work package' in low or 'work_package' in low or 'workpackages' in low))

# ------------------------------------------------------------------ criterion 12 (weight 2): the permit condition
@check('c12_no_energizing_before_final_approval', 12)
def c12(t, ctx):
    return win_has_groups(t, [
        ['permitted work'],
        ['energized', 'energize'],
        ['final approval'],
        ['kelloway', 'township'],
        ['ep-25-0418'],
    ], k=3)

# ------------------------------------------------------------------ criterion 13 (weight 1): the addressee
@check('c13_addressed_to_strathe', 13)
def c13(t, ctx):
    low = t.lower()
    return ('imogen strathe' in low and 'halbray community solar' in low
            and ('dear ms strathe' in low or 'imogen' in low.split('imogen strathe')[1][:200] if 'imogen strathe' in low else False))

# ------------------------------------------------------------------ criterion 14 (weight 2): inspection 07/24 must pass, written approval before 07/29
@check('c14_inspection_pass_and_approval_before_date', 14)
def c14(t, ctx):
    return win_has_groups(t, [
        ['07/24/2025'],
        ['final inspection'],
        ['pass'],
        ['written final approval'],
        ['07/29/2025'],
        ['before'],
    ], k=3)

# ------------------------------------------------------------------ criterion 15 (weight 2): who gets it passed
@check('c15_who_gets_inspection_passed', 15)
def c15(t, ctx):
    return win_has_groups(t, [
        ['final inspection'],
        ['halbray'],
        ['tamsworth'],
        ['permit holder', 'gets the final inspection passed', 'get the final inspection passed'],
    ], k=2)

# ------------------------------------------------------------------ criterion 16 (weight 2): the answer on the date
@check('c16_cannot_energize_or_confirm', 16)
def c16(t, ctx):
    return win_has_groups(t, [
        ['07/29/2025'],
        ['cannot energize', 'cannot confirm', 'cannot confirm energizing'],
    ], k=2)

# ================================================================== closure checks of my own
@check('x1_counts_consistent', None, closure=True)
def x1(t, ctx):
    """the counts the letter states agree with the record: 8 blocks x 12 rows = 96 drives,
    4 skids x 3 inverters = 12, 4 x 575 kW = 2,300 kW = 2.3 MW"""
    D = ctx['D']
    ok = D['blocks'] * D['rows_per_block'] == D['drives_total'] == 96
    ok &= D['n_inverters'] == 12 and D['n_xt225'] == 8 and D['n_xt125'] == 4
    ok &= D['skids'] * D['skid_kw'] == D['kw_total'] == 2300 and D['mw_total'] == 2.3
    return ok

@check('x2_ratings_consistent', None, closure=True)
def x2(t, ctx):
    """T-1 2,500 kVA at 13.2 kV gives 109.3 A, which is the 109 A the record states"""
    D = ctx['D']
    return abs(D['fla_primary_calc'] - D['fla_primary']) <= 0.5

@check('x3_dates_consistent', None, closure=True)
def x3(t, ctx):
    D = ctx['D']
    return (D['days_to_inspection'] == 10 and D['days_inspection_to_backfeed'] == 5
            and D['days_to_backfeed'] == 15 and D['days_request_to_backfeed'] == 20)

@check('x4_no_date_promised', None, closure=True)
def x4(t, ctx):
    """the letter never confirms 07/29/2025 as the energization date"""
    low = t.lower()
    bad = re.findall(r'(will energize[^.]{0,60}07/29/2025|confirm[^.]{0,25}07/29/2025[^.]{0,25}(?:as the date|for the))', low)
    return not bad

@check('x5_quotes_verbatim', None, closure=True)
def x5(t, ctx):
    """the two instruments are quoted, not paraphrased"""
    D = ctx['D']
    def norm(s):
        return re.sub(r'\s+', ' ', s).strip().lower()
    tt = norm(t)
    return (norm('No permitted work shall be energized before final approval.') in tt
            and norm('for aboveground installations except where the cable emerges from the ground') in tt
            and norm('installed outside of a cable tray system or raceway') in tt
            and norm('suitably protected against corrosion') in tt
            and norm('may energize the customer') in tt)

NAMES = [c[0] for c in CHECKS]

def run_text(text, filename_present=True, db_diff=None, D=None):
    import json
    if D is None:
        D = json.load(open('/work/bf/computed.json'))
    t = normalize(text)
    ctx = {'filename_present': filename_present, 'db_diff': db_diff, 'D': D}
    out = {}
    for name, fn, idx, closure in CHECKS:
        try:
            out[name] = bool(fn(t, ctx))
        except Exception as e:
            out[name] = False
            out[name + '_error'] = repr(e)
    return out

if __name__ == '__main__':
    import sys, json
    text = open(sys.argv[1], encoding='utf-8').read()
    res = run_text(text)
    rub = {n: v for n, f, i, c in CHECKS for n2, v in [(n, res[n])] if not c}
    clo = {n: v for n, f, i, c in CHECKS for n2, v in [(n, res[n])] if c}
    print('RUBRIC:', sum(rub.values()), '/', len(rub))
    for k, v in rub.items():
        if not v:
            print('   RED', k)
    print('CLOSURE:', sum(clo.values()), '/', len(clo))
    for k, v in clo.items():
        if not v:
            print('   RED', k, res.get(k + '_error', ''))
