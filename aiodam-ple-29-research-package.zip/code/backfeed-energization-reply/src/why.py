import sys, re
sys.path.insert(0,'/work/bf/src')
import checks as C
mut, needle = sys.argv[1], sys.argv[2]
text = open(f'/work/bf/work_mut/{mut}/text.txt', encoding='utf-8').read()
t = C.normalize(text)
sents = C.sentences(t)
print(f'--- {mut}: windows containing {needle!r} ---')
seen=0
for w in C.windows(sents, 3):
    if needle.lower() in w.lower():
        seen+=1
        print(f'[{seen}]', w[:600].replace('\n',' '))
print('total windows', len(C.windows(sents,3)), 'matching', seen)
