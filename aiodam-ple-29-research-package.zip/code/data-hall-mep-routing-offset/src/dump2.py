import sys, json, collections
sys.path.insert(0, '/work/ple-dataset/tasks/data-hall-mep-routing-offset/tests/evaluator/frontier_eval')
import ifcopenshell
from dc_model.dcgrade.score import build_scene
gt = ifcopenshell.open('/work/ple-dataset/tasks/data-hall-mep-routing-offset/tests/evaluator/frontier_eval/reference/ground_truth.ifc')
sc = build_scene(gt)

def seg(e):
    return [round(v,1) for v in e.min_mm], [round(v,1) for v in e.max_mm]

for k in ['cable_tray','busway','chw_pipe']:
    print("==",k)
    for e in sc.of_kind(k):
        print(" ", e.name, seg(e), dict(e.psets) if e.psets else '')

print("== containers/floor")
for e in sc.of_kind('containment'): print(" ", e.name, seg(e))
for e in sc.of_kind('raised_floor'): print(" ", e.name, seg(e))
print("== columns")
for e in sc.of_kind('column'): print(" ", e.name, seg(e))
print("== crah")
for e in sc.of_kind('crah'): print(" ", e.name, seg(e), e.psets.get('Pset_DCM_Cooling',{}))
print("== pdu")
for e in sc.of_kind('pdu'): print(" ", e.name, seg(e), e.psets)
