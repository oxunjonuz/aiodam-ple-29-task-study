import sys, json, collections
sys.path.insert(0, '/work/ple-dataset/tasks/data-hall-mep-routing-offset/tests/evaluator/frontier_eval')
import ifcopenshell
from dc_model.dcgrade.score import build_scene
gt = ifcopenshell.open('/work/ple-dataset/tasks/data-hall-mep-routing-offset/tests/evaluator/frontier_eval/reference/ground_truth.ifc')
sc = build_scene(gt)
print("hall:", sc.hall.name if sc.hall else None, [round(v) for v in sc.hall.min_mm], [round(v) for v in sc.hall.max_mm])
spr = sorted(sc.of_kind('sprinkler'), key=lambda e:e.name)
for e in spr:
    print(e.name, [round(v,1) for v in e.min_mm], [round(v,1) for v in e.max_mm], e.psets)
