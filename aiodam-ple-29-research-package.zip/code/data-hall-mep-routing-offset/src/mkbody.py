src = open('/work/ple-solve/data-hall-mep-routing/src/builder.py').read()
i = src.index('SCHEMA = "IFC4"')
j = src.index('    # -- the routes ---')
prefix = src[i:j]
old = '''        for name, cx, cy, deflector in SPRINKLERS:
            top = SOFFIT if deflector > CLEAR_HEIGHT else deflector + 100.0
            self.box("sprinkler", name,
                     (cx - 13.0, cy - 13.0, deflector, cx + 13.0, cy + 13.0, top))
'''
new = '''        for name, cx, cy, plane, half, top in SPRINKLERS:
            self.box("sprinkler", name,
                     (cx - half, cy - half, plane, cx + half, cy + half, top))
'''
assert old in prefix
prefix = prefix.replace(old, new)
open('body_prefix.py','w').write(prefix)
print("prefix bytes", len(prefix))
