SCHEMA = "IFC4"
_GUID_COUNTER = [0]


def _new_guid():
    """Deterministic IFC GlobalId: uuid5 over a fixed namespace and a counter.

    ifcopenshell.guid.new() would make every run produce different bytes; the
    contract asks for a deterministic script, so the identity of each entity is
    derived from its position in the (deterministic) creation order.
    """
    import uuid
    _GUID_COUNTER[0] += 1
    name = "dc_model/hall_seed000_d000/mep_routing/%d" % _GUID_COUNTER[0]
    return _guid.compress(str(uuid.uuid5(uuid.NAMESPACE_URL, name)))
FACING_ROT = {"NORTH": 0.0, "WEST": 90.0, "SOUTH": 180.0, "EAST": 270.0}

CLS = {
    "rack": ("IfcFurniture", "USERDEFINED", "Rack"),
    "crah": ("IfcUnitaryEquipment", "AIRCONDITIONINGUNIT", None),
    "pdu": ("IfcElectricDistributionBoard", "DISTRIBUTIONBOARD", None),
    "column": ("IfcColumn", None, None),
    "raised_floor": ("IfcCovering", "FLOORING", None),
    "containment": ("IfcCovering", "CLADDING", None),
    "sprinkler": ("IfcFireSuppressionTerminal", "SPRINKLER", None),
    "cable_tray": ("IfcCableCarrierSegment", "CABLETRAYSEGMENT", None),
    "busway": ("IfcCableSegment", "BUSBARSEGMENT", None),
    "chw_pipe": ("IfcPipeSegment", "RIGIDSEGMENT", None),
}


def _pt(f, xy, z=None):
    return f.create_entity("IfcCartesianPoint",
                           Coordinates=tuple(float(v) for v in
                                             ((xy[0], xy[1]) if z is None else (xy[0], xy[1], z))))


def _dir(f, ratios):
    return f.create_entity("IfcDirection", DirectionRatios=tuple(float(v) for v in ratios))


def _rect_profile(f, w, d):
    """2D closed profile, five points, as the drawing set's own elements use."""
    corners = [(0.0, 0.0), (w, 0.0), (w, d), (0.0, d), (0.0, 0.0)]
    poly = f.create_entity("IfcPolyline", Points=[_pt(f, c) for c in corners])
    return f.create_entity("IfcArbitraryClosedProfileDef",
                           ProfileType="AREA", OuterCurve=poly)


def _solid(f, w, d, h):
    origin = f.create_entity("IfcCartesianPoint", Coordinates=(0.0, 0.0, 0.0))
    axis = f.create_entity("IfcAxis2Placement3D", Location=origin,
                           Axis=_dir(f, (0, 0, 1)), RefDirection=_dir(f, (1, 0, 0)))
    return f.create_entity("IfcExtrudedAreaSolid",
                           SweptArea=_rect_profile(f, w, d), Position=axis,
                           ExtrudedDirection=_dir(f, (0, 0, 1)), Depth=float(h))


class Model:
    def __init__(self):
        f = ifcopenshell.file(schema=SCHEMA)
        self.f = f
        length = f.create_entity("IfcSIUnit", UnitType="LENGTHUNIT",
                                 Prefix="MILLI", Name="METRE")
        area = f.create_entity("IfcSIUnit", UnitType="AREAUNIT", Name="SQUARE_METRE")
        volume = f.create_entity("IfcSIUnit", UnitType="VOLUMEUNIT", Name="CUBIC_METRE")
        units = f.create_entity("IfcUnitAssignment", Units=[area, volume, length])
        origin = f.create_entity("IfcCartesianPoint", Coordinates=(0.0, 0.0, 0.0))
        world = f.create_entity("IfcAxis2Placement3D", Location=origin,
                                Axis=_dir(f, (0, 0, 1)), RefDirection=_dir(f, (1, 0, 0)))
        ctx = f.create_entity("IfcGeometricRepresentationContext",
                              ContextIdentifier="Model", ContextType="Model",
                              CoordinateSpaceDimension=3, Precision=1.0e-5,
                              WorldCoordinateSystem=world)
        self.body = f.create_entity("IfcGeometricRepresentationSubContext",
                                    ContextIdentifier="Body", ContextType="Model",
                                    ParentContext=ctx, TargetView="MODEL_VIEW")
        self.project = f.create_entity("IfcProject", GlobalId=_new_guid(),
                                       Name="DC Model", UnitsInContext=units,
                                       RepresentationContexts=[ctx])
        self.site = f.create_entity("IfcSite", GlobalId=_new_guid(), Name="SITE")
        self.building = f.create_entity("IfcBuilding", GlobalId=_new_guid(), Name="DC-01")
        self.storey = f.create_entity("IfcBuildingStorey", GlobalId=_new_guid(),
                                      Name="LEVEL 1", Elevation=0.0)
        f.create_entity("IfcRelAggregates", GlobalId=_new_guid(),
                        RelatingObject=self.project, RelatedObjects=[self.site])
        f.create_entity("IfcRelAggregates", GlobalId=_new_guid(),
                        RelatingObject=self.site, RelatedObjects=[self.building])
        f.create_entity("IfcRelAggregates", GlobalId=_new_guid(),
                        RelatingObject=self.building, RelatedObjects=[self.storey])
        self.storey_placement = f.create_entity(
            "IfcLocalPlacement", RelativePlacement=f.create_entity(
                "IfcAxis2Placement3D", Location=f.create_entity(
                    "IfcCartesianPoint", Coordinates=(0.0, 0.0, 0.0))))
        self.elements = []
        self.space = None

    # -- geometry ---------------------------------------------------------
    def box(self, kind, name, box, facing="NORTH", psets=None):
        return self._element(kind, name, box, facing, psets)

    def _element(self, kind, name, box, facing, psets, space=None):
        f = self.f
        x0, y0, z0, x1, y1, z1 = (float(v) for v in box)
        w, d, h = x1 - x0, y1 - y0, z1 - z0
        rot = FACING_ROT[facing]
        # The placement rotation is the facing; the two profile dimensions swap
        # for the quarter turns so the solid still lands on the drawn footprint.
        if rot == 0.0:
            loc, ref, pw, pd = (x0, y0, z0), (1.0, 0.0, 0.0), w, d
        elif rot == 90.0:
            loc, ref, pw, pd = (x1, y0, z0), (0.0, 1.0, 0.0), d, w
        elif rot == 180.0:
            loc, ref, pw, pd = (x1, y1, z0), (-1.0, 0.0, 0.0), w, d
        else:
            loc, ref, pw, pd = (x0, y1, z0), (0.0, -1.0, 0.0), d, w
        placement = f.create_entity(
            "IfcLocalPlacement", PlacementRelTo=self.storey_placement,
            RelativePlacement=f.create_entity(
                "IfcAxis2Placement3D",
                Location=f.create_entity("IfcCartesianPoint",
                                         Coordinates=tuple(loc)),
                Axis=_dir(f, (0, 0, 1)), RefDirection=_dir(f, ref)))
        shape = f.create_entity("IfcShapeRepresentation", ContextOfItems=self.body,
                                RepresentationIdentifier="Body",
                                RepresentationType="SweptSolid",
                                Items=[_solid(f, pw, pd, h)])
        product = f.create_entity("IfcProductDefinitionShape",
                                  Representations=[shape])
        cls, predefined, object_type = CLS[kind]
        kwargs = dict(GlobalId=_new_guid(), Name=name, ObjectPlacement=placement,
                      Representation=product)
        if object_type is not None:
            kwargs["ObjectType"] = object_type
        if predefined is not None:
            kwargs["PredefinedType"] = predefined
        element = f.create_entity(cls, **kwargs)
        self.elements.append(element)
        if psets:
            self._psets(element, psets)
        return element

    def _psets(self, element, psets):
        f = self.f
        for pset_name, props in psets.items():
            values = []
            for key, value in props.items():
                if isinstance(value, bool):
                    nominal = f.create_entity("IfcBoolean", bool(value))
                elif isinstance(value, int):
                    nominal = f.create_entity("IfcInteger", int(value))
                elif isinstance(value, float):
                    nominal = f.create_entity("IfcReal", float(value))
                else:
                    nominal = f.create_entity("IfcLabel", str(value))
                values.append(f.create_entity("IfcPropertySingleValue",
                                              Name=key, NominalValue=nominal))
            pset = f.create_entity("IfcPropertySet", GlobalId=_new_guid(),
                                   Name=pset_name, HasProperties=values)
            f.create_entity("IfcRelDefinesByProperties", GlobalId=_new_guid(),
                            RelatedObjects=[element], RelatingPropertyDefinition=pset)

    # -- the hall ----------------------------------------------------------
    def add_hall(self):
        f = self.f
        space = f.create_entity(
            "IfcSpace", GlobalId=_new_guid(), Name="DATA HALL 1",
            ObjectPlacement=self.storey_placement,
            Representation=f.create_entity(
                "IfcProductDefinitionShape",
                Representations=[f.create_entity(
                    "IfcShapeRepresentation", ContextOfItems=self.body,
                    RepresentationIdentifier="Body", RepresentationType="SweptSolid",
                    Items=[_solid(f, HALL_W, HALL_D, HALL_H)])]),
            CompositionType="ELEMENT", PredefinedType="INTERNAL",
            ElevationWithFlooring=0.0)
        self.space = space
        f.create_entity("IfcRelAggregates", GlobalId=_new_guid(),
                        RelatingObject=self.storey, RelatedObjects=[space])

    # -- fit-out -----------------------------------------------------------
    def add_fitout(self):
        self.box("raised_floor", "ACCESS FLOOR PANELS",
                 (0.0, 0.0, -PANEL_T, HALL_W, HALL_D, 0.0))
        for name, x0, y0 in COLUMNS:
            self.box("column", name, (x0, y0, 0.0, x0 + 600.0, y0 + 600.0, SOFFIT))
        for name, x0, y0, x1, y1, z0, z1 in CONTAINMENT:
            self.box("containment", name, (x0, y0, z0, x1, y1, z1))
        for name, cx, cy, plane, half, top in SPRINKLERS:
            self.box("sprinkler", name,
                     (cx - half, cy - half, plane, cx + half, cy + half, top))
        for row_id, y0, y1, facing, bays in ROWS:
            depth = y1 - y0
            for index, (x0, width, cabinet_type) in enumerate(bays, start=1):
                name = "RACK-%s%02d" % (row_id, index)
                self.box("rack", name, (x0, y0, 0.0, x0 + width, y1, 2000.0),
                         facing=facing,
                         psets={"Pset_DCM_Rack": {
                             "RackUnits": 42,
                             "WidthMM": float(width),
                             "DepthMM": float(depth),
                             "TileCoordinate": tile_address(x0, y0),
                             "RowId": row_id,
                             "FacingDirection": facing,
                             "CabinetType": cabinet_type,
                         }})
        for (name, x0, y0, x1, y1, facing, height, capacity, airflow,
             placement) in CRAHS:
            self.box("crah", name, (x0, y0, 0.0, x1, y1, height), facing=facing,
                     psets={"Pset_DCM_Cooling": {
                         "CapacityKW": float(capacity),
                         "AirflowM3H": float(airflow),
                         "FacingDirection": facing,
                         "Placement": placement,
                     }})
        for name, x0, y0, x1, y1, facing, height, kva, serves_row in PDUS:
            self.box("pdu", name, (x0, y0, 0.0, x1, y1, height), facing=facing,
                     psets={"Pset_DCM_Power": {
                         "RatingKVA": float(kva),
                         "ServesRow": serves_row,
                         "FacingDirection": facing,
                     }})

