    # -- the routes --------------------------------------------------------
    def add_routes(self):
        height = {"cable_tray": TRAY_H, "busway": BUS_H, "chw_pipe": CHW_OD}
        lanes = {"cable_tray": LANE_TRAY, "busway": LANE_BUS, "chw_pipe": LANE_CHW}
        bands = {"cable_tray": BANDS_TRAY, "busway": BANDS_BUS, "chw_pipe": BANDS_CHW}
        prefixes = {"cable_tray": "CT", "busway": "BW", "chw_pipe": "CHW"}
        # the CHW trunk starts at the perimeter header, the other two at the
        # north edge of the south corridor
        trunk_y0 = {"cable_tray": None, "busway": None, "chw_pipe": CHW_SPUR_Y[0]}
        self.route_segments = []
        for service in COVERAGE_SERVICES:
            lx0, lx1 = lanes[service]
            h = height[service]
            (sy0, sy1), (ny0, ny1) = bands[service]
            prefix = prefixes[service]
            # the two transverse corridors: west wall to the last bay of the
            # easternmost row each corridor serves
            self._route(service, prefix + "-B01",
                        (lx0, sy0, Z_OVERHEAD, ROUTE_EAST_S, sy1, Z_OVERHEAD + h))
            self._route(service, prefix + "-B02",
                        (lx0, ny0, Z_OVERHEAD, ROUTE_EAST_N, ny1, Z_OVERHEAD + h))
            # one riser in each corridor's own band (A-101 keynote 2)
            self._route(service, prefix + "-R01",
                        (lx0, sy0, Z_UNDER_TOP, lx1, sy1, Z_OVERHEAD))
            self._route(service, prefix + "-R02",
                        (lx0, ny0, Z_UNDER_TOP, lx1, ny1, Z_OVERHEAD))
            # north-south trunk in the access-floor plenum (TIA-942-B 8.6.2):
            # the one place a run can cross the ceiling-head lines
            ty0 = sy1 if trunk_y0[service] is None else trunk_y0[service]
            self._route(service, prefix + "-T01",
                        (lx0, ty0, Z_UNDER_TOP - h, lx1, ny0, Z_UNDER_TOP))
        # CHW header to the perimeter CRAH gallery on the south wall: all four
        # units are within the 2500 mm reach of y 1800-1968.3, and x 22 800 is
        # 2500 mm short of CRAH-04's west face at 25 200
        self._route("chw_pipe", "CHW-S01",
                    (LANE_CHW[1], CHW_SPUR_Y[0], Z_UNDER_TOP - CHW_OD,
                     CHW_SPUR_EAST, CHW_SPUR_Y[1], Z_UNDER_TOP))

    def _route(self, service, name, box):
        x0, y0, z0, x1, y1, z1 = box
        axis = "X" if (x1 - x0) >= max(y1 - y0, z1 - z0) else (
            "Y" if (y1 - y0) >= (z1 - z0) else "Z")
        length = max(x1 - x0, y1 - y0, z1 - z0)
        element = self.box(service, name, box, facing="NORTH",
                           psets={"Pset_DCM_Route": {
                               "Service": {"cable_tray": "telecom",
                                           "busway": "power",
                                           "chw_pipe": "chilled_water"}[service],
                               "Axis": axis,
                               "LengthMM": float(round(length, 1)),
                           }})
        self.route_segments.append(element)
        return element

    # -- output ------------------------------------------------------------
    def write(self, out_path):
        f = self.f
        if self.space is not None:
            f.create_entity("IfcRelContainedInSpatialStructure",
                            GlobalId=_new_guid(), RelatedElements=self.elements,
                            RelatingStructure=self.space)
        f.write(out_path)
        _pin_timestamp(out_path)


#: ifcopenshell stamps FILE_NAME with the wall clock, so two runs of a
#: perfectly deterministic script differ in four bytes of header.  The routing
#: contract asks for a deterministic script, so the stamp is pinned: two runs
#: of this file are then byte-identical, which is also what makes a package
#: hash meaningful.
FILE_NAME_STAMP = "2026-11-11T00:00:00"


def _pin_timestamp(path):
    import re as _re
    with open(path, "r", encoding="utf-8", errors="surrogateescape") as handle:
        text = handle.read()
    pinned = _re.sub(r"(FILE_NAME\('[^']*',')([^']*)(')",
                     r"\g<1>" + FILE_NAME_STAMP + r"\g<3>", text, count=1)
    if pinned != text:
        with open(path, "w", encoding="utf-8", errors="surrogateescape") as handle:
            handle.write(pinned)


def tile_address(x_mm, y_mm):
    """The access-floor tile an element's south-west corner stands in.

    A-101 note 3: 600 mm grid from the south-west internal corner, columns
    lettered eastward, rows numbered northward.
    """
    column = int(round(x_mm / 600.0))
    row = int(round(y_mm / 600.0)) + 1
    letters = ""
    value = column
    while True:
        letters = chr(ord("A") + value % 26) + letters
        value = value // 26 - 1
        if value < 0:
            break
    return "%s%02d" % (letters, row)


RECONCILIATION = {
    "A-301 soffit 3050 / deflector 3024.6": "enforced as the plenum datum; no run "
        "enters the 460 mm standoff under any head",
    "A-301 clear height 2600": "enforced as the underside of every overhead run",
    "A-602 note: standoff falls below the clear height":
        "read as the design constraint it is: at this soffit the standoff plane "
        "(2564.6) is 35.4 mm below the clear-height plane (2600), so an overhead "
        "run is legal only where no head is over it. The two corridors are "
        "threaded between the ceiling-head lines at y 3750/6250 and 8750/11250.",
    "A-602 tray 683x127, busway 128x147, CHW DN100 114.3+25.4 = 168.3":
        "used as the modelled outside sections",
    "E-101 note 6: 300 mm tray/busway": "320 mm in both corridors and in both trunks",
    "E-101 note 7: 1800 mm above each PDU dedicated":
        "no CHW run within 1800 mm above any PDU footprint: the CHW corridors "
        "stop at x 21 600/22 200, west of the PDU line at x >= 22 400",
    "M-101: CHW to every CRAH, perimeter gallery included":
        "two in-row corridors plus a plenum header at y 1800 to the south wall "
        "gallery; the header is within 2500 mm in plan of CRAH-01..04",
    "F-101: 94 ceiling heads + 10 in-aisle heads": "all 104 modelled; the 10 "
        "in-aisle heads hang from the containment soffit at +1890 per 3/A-301",
    "M-101 2 x DN100 supply and return": "one DN100 insulated main is modelled, "
        "as the coordination contract asks for one network per service; the "
        "return is a duplicate of the supply and is not drawn as a second net",
    "E-101 note 4: busway support at 1500 mm max": "supports are optional in the "
        "contract and are not modelled; the maximum unsupported span is the "
        "22 200 mm corridor, reported rather than claimed",
    "A-101 note: area reserved for future rows, not in contract":
        "the north half of the hall (y > 11 870) is left empty, as drawn",
}
