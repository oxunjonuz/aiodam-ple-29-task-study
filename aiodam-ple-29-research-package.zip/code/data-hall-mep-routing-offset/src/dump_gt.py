import sys, json, collections
sys.path.insert(0, '/work/ple-dataset/tasks/data-hall-mep-routing-offset/tests/evaluator/frontier_eval')
import ifcopenshell
from dc_model.dcgrade.score import build_scene, routed_length_mm
gt = ifcopenshell.open('/work/ple-dataset/tasks/data-hall-mep-routing-offset/tests/evaluator/frontier_eval/reference/ground_truth.ifc')
sc = build_scene(gt)
by = collections.Counter(e.kind for e in sc.elements)
print("KINDS:", dict(by), "total", len(sc.elements))
print("routed:", routed_length_mm(sc))
# floor z, ceiling z
print("floor_z", sc.floor_z_mm, "ceiling_z", sc.ceiling_z_mm)
# overall extents per kind
for k in sorted(by):
    els = sc.of_kind(k)
    x0=min(e.min_mm[0] for e in els); x1=max(e.max_mm[0] for e in els)
    y0=min(e.min_mm[1] for e in els); y1=max(e.max_mm[1] for e in els)
    z0=min(e.min_mm[2] for e in els); z1=max(e.max_mm[2] for e in els)
    print(f"{k:12s} n={len(els):4d} x[{x0:.0f},{x1:.0f}] y[{y0:.0f},{y1:.0f}] z[{z0:.0f},{z1:.0f}]")
out = []
for e in sc.elements:
    out.append(dict(kind=e.kind, name=e.name, min=e.min_mm, max=e.max_mm, psets=e.psets, fill=e.shape.fill_ratio if getattr(e,'shape',None) else None))
json.dump(out, open('gt_scene.json','w'), indent=0)
print("wrote gt_scene.json", len(out))
