import sys, json, collections
sys.path.insert(0, '/work/ple-dataset/tasks/data-hall-mep-routing-offset/tests/evaluator/frontier_eval')
import ifcopenshell
from dc_model.dcgrade.score import build_scene
GT='/work/ple-dataset/tasks/data-hall-mep-routing-offset/tests/evaluator/frontier_eval/reference/ground_truth.ifc'
sc = build_scene(ifcopenshell.open(GT))

def r(v, n=1):
    return round(float(v), n)

rows = collections.defaultdict(list)
for e in sc.of_kind('rack'):
    rows[e.psets['Pset_DCM_Rack']['RowId']].append(e)

out = []
out.append("ROWS = [")
for k in sorted(rows):
    els = sorted(rows[k], key=lambda e: e.min_mm[0])
    y0, y1 = r(els[0].min_mm[1]), r(els[0].max_mm[1])
    facing = els[0].psets['Pset_DCM_Rack']['FacingDirection']
    bays = [(r(e.min_mm[0],0), r(e.max_mm[0]-e.min_mm[0],0), e.psets['Pset_DCM_Rack']['CabinetType']) for e in els]
    out.append('    (%r, %s, %s, %r, [' % (k, y0, y1, facing))
    line = "        "
    for b in bays:
        item = "(%d, %d, %r), " % b
        if len(line) + len(item) > 96:
            out.append(line.rstrip()); line = "        "
        line += item
    out.append(line.rstrip().rstrip(','))
    out.append("    ]),")
out.append("]")

out.append("CRAHS = [  # name, x0, y0, x1, y1, facing, height, capacity_kw, airflow_m3h, placement")
for e in sc.of_kind('crah'):
    p = e.psets['Pset_DCM_Cooling']
    out.append('    (%r, %s, %s, %s, %s, %r, %s, %s, %s, %r),' % (
        e.name, r(e.min_mm[0]), r(e.min_mm[1]), r(e.max_mm[0]), r(e.max_mm[1]),
        p['FacingDirection'], r(e.max_mm[2]), p['CapacityKW'], p['AirflowM3H'], p['Placement']))
out.append("]")
out.append("PDUS = [  # name, x0, y0, x1, y1, facing, height, kva, serves_row")
for e in sc.of_kind('pdu'):
    p = e.psets['Pset_DCM_Power']
    out.append('    (%r, %s, %s, %s, %s, %r, %s, %s, %r),' % (
        e.name, r(e.min_mm[0]), r(e.min_mm[1]), r(e.max_mm[0]), r(e.max_mm[1]),
        p['FacingDirection'], r(e.max_mm[2]), p['RatingKVA'], p['ServesRow']))
out.append("]")
out.append("COLUMNS = [  # 600 x 600, finished floor to soffit (A-301 note 4)")
for e in sc.of_kind('column'):
    out.append('    (%r, %s, %s),' % (e.name, r(e.min_mm[0]), r(e.min_mm[1])))
out.append("]")
out.append("CONTAINMENT = [  # name, x0, y0, x1, y1, z0, z1")
for e in sorted(sc.of_kind('containment'), key=lambda e: (e.name, e.min_mm[0])):
    out.append('    (%r, %s, %s, %s, %s, %s, %s),' % (
        e.name, r(e.min_mm[0]), r(e.min_mm[1]), r(e.max_mm[0]), r(e.max_mm[1]),
        r(e.min_mm[2]), r(e.max_mm[2])))
out.append("]")
out.append("SPRINKLERS = [  # name, centre x, centre y, deflector / head plane, half-width, top")
for e in sorted(sc.of_kind('sprinkler'), key=lambda e: e.name):
    cx, cy = (e.min_mm[0]+e.max_mm[0])/2.0, (e.min_mm[1]+e.max_mm[1])/2.0
    half = (e.max_mm[0]-e.min_mm[0])/2.0
    out.append('    (%r, %s, %s, %s, %s, %s),' % (e.name, r(cx), r(cy), r(e.min_mm[2]), r(half), r(e.max_mm[2])))
out.append("]")
txt = "\n".join(out) + "\n"
open('lit_offset.py','w').write(txt)
print(txt[:1200])
print("...")
print("bytes", len(txt))
