parts = []
parts.append(open('head_off.py').read())
parts.append("\n# --------------------------------------------------------------------------\n"
             "# The hall as drawn: A-101 plan, A-601 schedules, A-301 section\n"
             "# --------------------------------------------------------------------------\n")
parts.append(open('lit_offset.py').read())
parts.append("\n\n")
parts.append(open('body_prefix.py').read())
parts.append(open('body_suffix.py').read())
parts.append('''

def build(out_path):
    model = Model()
    model.add_hall()
    model.add_fitout()
    model.add_routes()
    model.write(out_path)
    return model


def main(argv):
    out_path = argv[1] if len(argv) > 1 else "output/model.ifc"
    build(out_path)
    # the contract asks for a file that validates with the EXPRESS rules on
    model = ifcopenshell.open(out_path)
    logger = ifcopenshell.validate.json_logger()
    ifcopenshell.validate.validate(model, logger, express_rules=True)
    if logger.statements:
        raise SystemExit("EXPRESS validation failed: %s"
                         % str(logger.statements[0])[:400])
    try:
        import json
        import os
        os.makedirs("output", exist_ok=True)
        with open(os.path.join("output", "reconciliation.json"), "w") as handle:
            json.dump(RECONCILIATION, handle, indent=2)
    except OSError:
        pass
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
''')
open('solution_offset.py','w').write("".join(parts))
print("solution bytes", len("".join(parts)))
