import sys, collections
sys.path.insert(0, '/work/ple-dataset/tasks/data-hall-mep-routing-offset/tests/evaluator/frontier_eval')
import ifcopenshell
from dc_model.dcgrade.score import build_scene
gt = ifcopenshell.open('/work/ple-dataset/tasks/data-hall-mep-routing-offset/tests/evaluator/frontier_eval/reference/ground_truth.ifc')
sc = build_scene(gt)
spr = sc.of_kind('sprinkler')
print("n sprinkler", len(spr))
zs = collections.Counter()
for e in spr:
    zs[(round(e.min_mm[2],1), round(e.max_mm[2],1))]+=1
print("z pairs:", dict(zs))
xs=collections.Counter(); ys=collections.Counter()
for e in spr:
    xs[round(e.centroid_mm[0])]+=1; ys[round(e.centroid_mm[1])]+=1
print("xs:", sorted(xs.items()))
print("ys:", sorted(ys.items()))
print("pset sample:", spr[0].psets, spr[0].name)
# racks by row
rows=collections.defaultdict(list)
for e in sc.of_kind('rack'):
    rows[e.psets.get('Pset_DCM_Rack',{}).get('RowId')].append(e)
for k in sorted(rows):
    els=rows[k]
    print("row",k,"n",len(els),
          "x[%.0f,%.0f]"%(min(e.min_mm[0] for e in els),max(e.max_mm[0] for e in els)),
          "y[%.0f,%.0f]"%(min(e.min_mm[1] for e in els),max(e.max_mm[1] for e in els)),
          "faces",collections.Counter(e.psets.get('Pset_DCM_Rack',{}).get('FacingDirection') for e in els))
    # print the x sequence
    print("   xs:", [ (round(e.min_mm[0]),round(e.max_mm[0])) for e in sorted(els,key=lambda e:e.min_mm[0])])
