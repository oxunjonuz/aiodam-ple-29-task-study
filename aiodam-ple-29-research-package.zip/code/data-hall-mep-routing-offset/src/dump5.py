import sys, json, collections
sys.path.insert(0, '/work/ple-dataset/tasks/data-hall-mep-routing-offset/tests/evaluator/frontier_eval')
import ifcopenshell
from dc_model.dcgrade.score import build_scene
gt = ifcopenshell.open('/work/ple-dataset/tasks/data-hall-mep-routing-offset/tests/evaluator/frontier_eval/reference/ground_truth.ifc')
sc = build_scene(gt)
rows=collections.defaultdict(list)
for e in sc.of_kind('rack'): rows[e.psets.get('Pset_DCM_Rack',{}).get('RowId')].append(e)
for k in sorted(rows):
    els=sorted(rows[k], key=lambda e:e.min_mm[0])
    print("row",k, "y", els[0].min_mm[1], els[0].max_mm[1], "depth", els[0].max_mm[1]-els[0].min_mm[1], "n", len(els))
    print("   pset0:", els[0].psets)
    print("   bays:", [(round(e.min_mm[0]), round(e.max_mm[0]-e.min_mm[0])) for e in els])
    print("   names:", [e.name for e in els][:3], "...", els[-1].name)
