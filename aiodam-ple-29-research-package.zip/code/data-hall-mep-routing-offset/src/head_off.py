#!/usr/bin/env python3
"""Coordinated overhead MEP model for data hall 1 (dc_model hall_seed005_d100).

The hardest hall in the corpus: a 27 000 x 24 000 room on a 7200 mm structural
grid that is offset 150 mm from the 600 mm access-floor tile grid, one
circulation cross-aisle re-registering every cabinet row, and 104 sprinkler
heads over a 3050 mm soffit - the lowest ceiling in the set.

Built from the seven-sheet drawing set, in millimetres, as IFC4:

  A-101  equipment plan ........ four rows A-D on their own bay sequences
                                 (26/21/20/27 cabinets), the cross aisle at
                                 x 10 400-12 600, the columns at 7050/14250/
                                 21450 on both axes, CRAH and PDU addresses,
                                 and the west service strip that carries the
                                 service trunks and their risers (keynote 2)
  A-301  building section ...... finished floor +0 (35 mm panel), soffit +3050,
                                 deflector plane +3024.6, minimum clear height
                                 2600, sprinkler standoff 460, in-aisle head
                                 +1890, containment roof 1530 wide x 55.5,
                                 top of structural slab -600
  A-601  cabinet schedule ...... bay sequence per row by accumulation from the
                                 west end (not a constant pitch), C1/C2/N1/N2
                                 cabinet types, CRAH and PDU schedules
  A-602  containment/pathway ... tray 683 x 127, busway 128 x 147, CHW DN100
                                 bare 114.3 insulated 25.4 -> 168.3; the
                                 vertical budget of the plenum, and the note
                                 that carries the whole problem: at this
                                 soffit the 460 mm standoff falls BELOW the
                                 2600 mm clear height, so there is no
                                 continuous overhead pathway zone in this hall
  M-101  chilled water .......... 2 x DN100 enter at the west wall and are
                                 piped to every CRAH: the perimeter gallery
                                 (four units on the south wall) and the twelve
                                 in-row units alike
  E-101  busway and PDU ......... busway serves every row; 300 mm clear of the
                                 telecom tray on at least one axis; the
                                 1800 mm above each PDU belongs to the
                                 electrics; 900 mm working space at its front
  F-101  sprinkler grid ......... 94 ceiling heads on a 2500 mm grid plus 10
                                 in-aisle heads under the containment roofs

Routing is the contractor's to coordinate (A-602 note 1), so the three routes
below are mine.  The coordination logic, in one paragraph: the 460 mm standoff
under a ceiling deflector reaches to 2564.6 mm, which is BELOW the 2600 mm
clear height, so the plenum holds no continuous overhead zone at all - an
overhead run is legal only where no head sits over it.  The ceiling heads are
on a 2500 mm grid, so the two transverse corridors are threaded BETWEEN two
head lines (y 4300-5699 serving rows A+B, y 9300-10699 serving rows C+D),
each lane keeping 3x its own width - capped at 610 mm - clear of every head in
plan, which is why the three services sit at three different y in the same
corridor instead of at three tiers.  The north-south trunks stay in the access
floor plenum, where TIA-942-B 8.6.2 expressly permits them and where the head
grid cannot reach them, and rise into each corridor through the riser that
A-101 keynote 2 puts in that corridor's own band.  A trunk that stayed
overhead in the west strip would have to cross the head line at y 6250 with
only 380 mm of plan clearance to the head at x 1250.

Run:  python3 solution.py <out.ifc>
"""
import sys

import ifcopenshell
import ifcopenshell.validate
from ifcopenshell import guid as _guid

# --------------------------------------------------------------------------
# Design constants (all millimetres above finished floor unless stated)
# --------------------------------------------------------------------------
HALL_W, HALL_D, HALL_H = 27000.0, 24000.0, 3050.0   # A-101 plan, A-301 section
PANEL_T = 35.0                                      # A-301: finished floor +0
SOFFIT = 3050.0                                     # A-301
DEFLECTOR = 3024.6                                  # A-301: 25.4 below soffit
CLEAR_HEIGHT = 2600.0                               # A-301 / TIA-942 5.3.4.3
SPRINKLER_STANDOFF = 460.0                          # A-301 / F-101 note 5
PATTERN_ZONE = 450.0                                # NFPA 13 10.2.7.2.1
COVERAGE_SERVICES = ("cable_tray", "busway", "chw_pipe")

# A-602 pathway section schedule (outside dimensions)
TRAY_W, TRAY_H = 683.0, 127.0       # telecom cable tray, ladder, 610 ladder
BUS_W, BUS_H = 128.0, 147.0         # power busway
CHW_OD = 168.3                      # DN100 (114.3 bare) + 25.4 insulation
POWER_TELECOM_SEPARATION = 300.0    # E-101 note 6 / TIA-942 7.3.1 Table 2
STACK_HEADROOM = 300.0              # TIA-569-B via TIA-942 7.3.2

# Lowest overhead tier: the clear-height plane + 20 mm, as drawn on A-301
Z_OVERHEAD = 2620.0
# Under-floor trunks: top of run 20 mm below the -35 tile underside
# (TIA-942-B 8.6.2), the three lanes stacked on a common top.
Z_UNDER_TOP = -55.0

# West service strip (A-101 keynote 2): three lanes abreast, tray / busway / CHW
LANE_TRAY = (200.0, 200.0 + TRAY_W)          # 200 - 883
LANE_BUS = (1183.0, 1183.0 + BUS_W)          # 1183 - 1311
LANE_CHW = (1411.0, 1411.0 + CHW_OD)         # 1411 - 1579.3

# Two transverse corridors, one per pair of cabinet rows.  Each lane sits
# inside the 2500 mm service reach of both rows it serves, between two
# ceiling-head lines (y 3750 / 6250 and y 8750 / 11250) with at least the
# 3x-width offset NFPA 13 10.2.7.2.1.3 asks for, and clear of the containment
# (y 6370-7900), the columns (y 6750-7350) and the PDU line.
BANDS_TRAY = ((4568.3, 4568.3 + TRAY_W),      # corridor S: rows A + B
              (9568.3, 9568.3 + TRAY_W))      # corridor N: rows C + D
BANDS_BUS = ((5571.3, 5571.3 + BUS_W),        # 320 mm clear of the tray
             (10571.3, 10571.3 + BUS_W))
BANDS_CHW = ((4300.0, 4300.0 + CHW_OD),       # south of both other lanes
             (9300.0, 9300.0 + CHW_OD))

ROUTE_EAST_S = 21600.0      # east face of row A's last bay (26 bays)
ROUTE_EAST_N = 22200.0      # east face of row D's last bay (27 bays)
# Perimeter CRAH gallery on the south wall: a header at y 1800-1968.3 is
# within the 2500 mm reach of all four units (y 0-900) and within 504.9 mm of
# neither head line; it runs to x 22 800, which is 2500 mm short of CRAH-04
# at x 25 200.  In the plenum, so the ceiling grid is not a constraint at all.
CHW_SPUR_Y = (1800.0, 1800.0 + CHW_OD)
CHW_SPUR_EAST = 22800.0
