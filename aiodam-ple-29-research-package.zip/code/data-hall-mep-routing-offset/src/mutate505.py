#!/usr/bin/env python3
"""Mutation campaign against the real grader (not my verifier).

Each mutation is one textual change to the shipped solution.py; the model it
builds is graded by the task's own evaluate_submission.py through run_eval.sh.
A mutation is "noticed" when the score drops and a named rule (or a gate) says
why; a mutation that leaves 1.0 is either an equivalent change or a blind spot,
and is reported as such rather than explained away.
"""
import json
import os
import shutil
import subprocess
import sys

BASE = os.path.dirname(os.path.abspath(__file__))
TASK = "/work/ple-solve/data-hall-mep-routing-offset"
SOL = os.path.join(BASE, "solution_offset.py")
BENCH = os.path.join(TASK, "bench")
PY = "/work/venv-verifier/bin/python"

MUTATIONS = [
    ("chw_corridor_in_head_line", [
        ("BANDS_CHW = ((4300.0, 4300.0 + CHW_OD),",
         "BANDS_CHW = ((3700.0, 3700.0 + CHW_OD),")]),
    ("chw_corridor_between_rows_equiv", [
        ("BANDS_CHW = ((4300.0, 4300.0 + CHW_OD),",
         "BANDS_CHW = ((3000.0, 3000.0 + CHW_OD),")]),
    ("tray_corridor_inside_offset", [
        ("BANDS_TRAY = ((4568.3, 4568.3 + TRAY_W),",
         "BANDS_TRAY = ((5000.0, 5000.0 + TRAY_W),")]),
    ("overhead_too_low", [("Z_OVERHEAD = 2620.0", "Z_OVERHEAD = 2560.0")]),
    ("busway_touches_tray", [
        ("BANDS_BUS = ((5571.3, 5571.3 + BUS_W),",
         "BANDS_BUS = ((5251.3, 5251.3 + BUS_W),")]),
    ("chw_over_pdu_dedicated_space", [
        ("(9300.0, 9300.0 + CHW_OD))", "(11300.0, 11300.0 + CHW_OD))"),
        ("(lx0, ny0, Z_OVERHEAD, ROUTE_EAST_N, ny1, Z_OVERHEAD + h))",
         "(lx0, ny0, Z_OVERHEAD, 24600.0 if service == \"chw_pipe\" else ROUTE_EAST_N, ny1, Z_OVERHEAD + h))")]),
    ("tray_trunk_inside_slab", [("Z_UNDER_TOP = -55.0", "Z_UNDER_TOP = -30.0")]),
    ("one_riser_missing", [
        ('self._route(service, prefix + "-R02",\n                        (lx0, ny0, Z_UNDER_TOP, lx1, ny1, Z_OVERHEAD))',
         'pass')]),
    ("corridor_short_of_row_d", [
        ('self._route(service, prefix + "-B02",\n                        (lx0, ny0, Z_OVERHEAD, ROUTE_EAST_N, ny1, Z_OVERHEAD + h))',
         'self._route(service, prefix + "-B02",\n                        (lx0, ny0, Z_OVERHEAD, 18000.0, ny1, Z_OVERHEAD + h))')]),
    ("no_perimeter_header", [
        ('        self._route("chw_pipe", "CHW-S01",\n'
         '                    (LANE_CHW[1], CHW_SPUR_Y[0], Z_UNDER_TOP - CHW_OD,\n'
         '                     CHW_SPUR_EAST, CHW_SPUR_Y[1], Z_UNDER_TOP))',
         '        pass  # perimeter header deliberately not built')]),
    ("racks_not_modelled", [
        ("                self.box(\"rack\", name,", "                _skip = None and self.box(\"rack\", name,")]),
    ("tray_wider_than_1200", [("TRAY_W, TRAY_H = 683.0, 127.0", "TRAY_W, TRAY_H = 1300.0, 127.0")]),
    ("no_in_aisle_heads", [
        ("        for name, cx, cy, plane, half, top in SPRINKLERS:",
         "        for name, cx, cy, plane, half, top in SPRINKLERS:\n            if plane < 3000.0:\n                continue")]),
    ("second_tray_tier", [
        ('self._route(service, prefix + "-B01",\n'
         '                        (lx0, sy0, Z_OVERHEAD, ROUTE_EAST_S, sy1, Z_OVERHEAD + h))',
         'self._route(service, prefix + "-B01",\n'
         '                        (lx0, sy0, Z_OVERHEAD, ROUTE_EAST_S, sy1, Z_OVERHEAD + h))\n'
         '            if service == "cable_tray":\n'
         '                self._route(service, "CT-B09",\n'
         '                            (lx0, sy0, Z_OVERHEAD + h + 100.0, ROUTE_EAST_S,\n'
         '                             sy1, Z_OVERHEAD + 2 * h + 100.0))')]),
]


def run(cmd, **kw):
    return subprocess.run(cmd, shell=True, cwd=kw.pop("cwd", BASE),
                          capture_output=True, text=True, **kw)


def grade(model_path):
    shutil.rmtree(os.path.join(BENCH, "output"), ignore_errors=True)
    os.makedirs(os.path.join(BENCH, "output"), exist_ok=True)
    shutil.copy(model_path, os.path.join(BENCH, "output", "model.ifc"))
    src = os.path.join(BENCH, "output", "solution.py")
    if os.path.exists(src):
        os.remove(src)
    run("bash frontier_eval/run_eval.sh %s %s" % (PY, BENCH), cwd=BENCH)
    with open(os.path.join(BENCH, "metrics.json")) as fh:
        return json.load(fh)


def summary(m):
    rules = m.get("secondary", {}).get("violation_detail", {}).get("rule_counts", {})
    return dict(score=m["combined_score"], exec=m["exec_status"],
                vr=m["violation_rate"], clash=m["clash_count"],
                length=m["routed_length"]["total_mm"],
                rules=rules,
                gates=(m["gates"]["gate_1_no_hard_clash"],
                       m["gates"]["gate_2_connectivity"]["passed"]))


def main(only=None):
    base_text = open(SOL).read()
    out = []
    # baseline
    run("%s %s/%s model.ifc" % (PY, BASE, "solution_offset.py"))
    res = summary(grade(os.path.join(BASE, "model.ifc")))
    print("baseline", res)
    out.append({"mutation": "baseline", **res})
    for name, patches in MUTATIONS:
        if only and name not in only:
            continue
        text = base_text
        ok = True
        for old, new in patches:
            if old not in text:
                print("!! patch anchor missing for", name)
                ok = False
                break
            text = text.replace(old, new, 1)
        if not ok:
            continue
        path = os.path.join(BASE, "mut_%s.py" % name)
        open(path, "w").write(text)
        build = run("%s %s mut_%s/model.ifc" % (PY, path, name))
        if build.returncode != 0:
            print("!! build failed for", name, build.stderr[-300:])
            out.append({"mutation": name, "score": None, "error": build.stderr[-300:]})
            continue
        res = summary(grade(os.path.join(BASE, "mut_%s" % name, "model.ifc")))
        print("%-34s %s" % (name, res))
        out.append({"mutation": name, **res})
    with open(os.path.join(BASE, "mutations_505.json"), "w") as fh:
        json.dump(out, fh, indent=1)


if __name__ == "__main__":
    main(set(sys.argv[1:]))
