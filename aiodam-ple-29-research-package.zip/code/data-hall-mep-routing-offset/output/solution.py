#!/usr/bin/env python3
"""Coordinated overhead MEP model for data hall 1 (dc_model hall_seed005_d100).

The hardest hall in the corpus: a 27 000 x 24 000 room on a 7200 mm structural
grid that is offset 150 mm from the 600 mm access-floor tile grid, one
circulation cross-aisle re-registering every cabinet row, and 104 sprinkler
heads over a 3050 mm soffit - the lowest ceiling in the set.

Built from the seven-sheet drawing set, in millimetres, as IFC4:

  A-101  equipment plan ........ four rows A-D on their own bay sequences
                                 (26/21/20/27 cabinets), the cross aisle at
                                 x 10 400-12 600, the columns at 7050/14250/
                                 21450 on both axes, CRAH and PDU addresses,
                                 and the west service strip that carries the
                                 service trunks and their risers (keynote 2)
  A-301  building section ...... finished floor +0 (35 mm panel), soffit +3050,
                                 deflector plane +3024.6, minimum clear height
                                 2600, sprinkler standoff 460, in-aisle head
                                 +1890, containment roof 1530 wide x 55.5,
                                 top of structural slab -600
  A-601  cabinet schedule ...... bay sequence per row by accumulation from the
                                 west end (not a constant pitch), C1/C2/N1/N2
                                 cabinet types, CRAH and PDU schedules
  A-602  containment/pathway ... tray 683 x 127, busway 128 x 147, CHW DN100
                                 bare 114.3 insulated 25.4 -> 168.3; the
                                 vertical budget of the plenum, and the note
                                 that carries the whole problem: at this
                                 soffit the 460 mm standoff falls BELOW the
                                 2600 mm clear height, so there is no
                                 continuous overhead pathway zone in this hall
  M-101  chilled water .......... 2 x DN100 enter at the west wall and are
                                 piped to every CRAH: the perimeter gallery
                                 (four units on the south wall) and the twelve
                                 in-row units alike
  E-101  busway and PDU ......... busway serves every row; 300 mm clear of the
                                 telecom tray on at least one axis; the
                                 1800 mm above each PDU belongs to the
                                 electrics; 900 mm working space at its front
  F-101  sprinkler grid ......... 94 ceiling heads on a 2500 mm grid plus 10
                                 in-aisle heads under the containment roofs

Routing is the contractor's to coordinate (A-602 note 1), so the three routes
below are mine.  The coordination logic, in one paragraph: the 460 mm standoff
under a ceiling deflector reaches to 2564.6 mm, which is BELOW the 2600 mm
clear height, so the plenum holds no continuous overhead zone at all - an
overhead run is legal only where no head sits over it.  The ceiling heads are
on a 2500 mm grid, so the two transverse corridors are threaded BETWEEN two
head lines (y 4300-5699 serving rows A+B, y 9300-10699 serving rows C+D),
each lane keeping 3x its own width - capped at 610 mm - clear of every head in
plan, which is why the three services sit at three different y in the same
corridor instead of at three tiers.  The north-south trunks stay in the access
floor plenum, where TIA-942-B 8.6.2 expressly permits them and where the head
grid cannot reach them, and rise into each corridor through the riser that
A-101 keynote 2 puts in that corridor's own band.  A trunk that stayed
overhead in the west strip would have to cross the head line at y 6250 with
only 380 mm of plan clearance to the head at x 1250.

Run:  python3 solution.py <out.ifc>
"""
import sys

import ifcopenshell
import ifcopenshell.validate
from ifcopenshell import guid as _guid

# --------------------------------------------------------------------------
# Design constants (all millimetres above finished floor unless stated)
# --------------------------------------------------------------------------
HALL_W, HALL_D, HALL_H = 27000.0, 24000.0, 3050.0   # A-101 plan, A-301 section
PANEL_T = 35.0                                      # A-301: finished floor +0
SOFFIT = 3050.0                                     # A-301
DEFLECTOR = 3024.6                                  # A-301: 25.4 below soffit
CLEAR_HEIGHT = 2600.0                               # A-301 / TIA-942 5.3.4.3
SPRINKLER_STANDOFF = 460.0                          # A-301 / F-101 note 5
PATTERN_ZONE = 450.0                                # NFPA 13 10.2.7.2.1
COVERAGE_SERVICES = ("cable_tray", "busway", "chw_pipe")

# A-602 pathway section schedule (outside dimensions)
TRAY_W, TRAY_H = 683.0, 127.0       # telecom cable tray, ladder, 610 ladder
BUS_W, BUS_H = 128.0, 147.0         # power busway
CHW_OD = 168.3                      # DN100 (114.3 bare) + 25.4 insulation
POWER_TELECOM_SEPARATION = 300.0    # E-101 note 6 / TIA-942 7.3.1 Table 2
STACK_HEADROOM = 300.0              # TIA-569-B via TIA-942 7.3.2

# Lowest overhead tier: the clear-height plane + 20 mm, as drawn on A-301
Z_OVERHEAD = 2620.0
# Under-floor trunks: top of run 20 mm below the -35 tile underside
# (TIA-942-B 8.6.2), the three lanes stacked on a common top.
Z_UNDER_TOP = -55.0

# West service strip (A-101 keynote 2): three lanes abreast, tray / busway / CHW
LANE_TRAY = (200.0, 200.0 + TRAY_W)          # 200 - 883
LANE_BUS = (1183.0, 1183.0 + BUS_W)          # 1183 - 1311
LANE_CHW = (1411.0, 1411.0 + CHW_OD)         # 1411 - 1579.3

# Two transverse corridors, one per pair of cabinet rows.  Each lane sits
# inside the 2500 mm service reach of both rows it serves, between two
# ceiling-head lines (y 3750 / 6250 and y 8750 / 11250) with at least the
# 3x-width offset NFPA 13 10.2.7.2.1.3 asks for, and clear of the containment
# (y 6370-7900), the columns (y 6750-7350) and the PDU line.
BANDS_TRAY = ((4568.3, 4568.3 + TRAY_W),      # corridor S: rows A + B
              (9568.3, 9568.3 + TRAY_W))      # corridor N: rows C + D
BANDS_BUS = ((5571.3, 5571.3 + BUS_W),        # 320 mm clear of the tray
             (10571.3, 10571.3 + BUS_W))
BANDS_CHW = ((4300.0, 4300.0 + CHW_OD),       # south of both other lanes
             (9300.0, 9300.0 + CHW_OD))

ROUTE_EAST_S = 21600.0      # east face of row A's last bay (26 bays)
ROUTE_EAST_N = 22200.0      # east face of row D's last bay (27 bays)
# Perimeter CRAH gallery on the south wall: a header at y 1800-1968.3 is
# within the 2500 mm reach of all four units (y 0-900) and within 504.9 mm of
# neither head line; it runs to x 22 800, which is 2500 mm short of CRAH-04
# at x 25 200.  In the plenum, so the ceiling grid is not a constraint at all.
CHW_SPUR_Y = (1800.0, 1800.0 + CHW_OD)
CHW_SPUR_EAST = 22800.0

# --------------------------------------------------------------------------
# The hall as drawn: A-101 plan, A-601 schedules, A-301 section
# --------------------------------------------------------------------------
ROWS = [
    ('A', 2400.0, 3600.0, 'SOUTH', [
        (1800, 600, 'C1'), (2400, 600, 'C1'), (3000, 600, 'C1'), (3600, 600, 'C1'),
        (4800, 600, 'C1'), (5400, 600, 'C1'), (6000, 600, 'C1'), (6600, 600, 'C1'),
        (7200, 800, 'N1'), (8000, 600, 'C1'), (8600, 600, 'C1'), (9200, 600, 'C1'),
        (9800, 600, 'C1'), (12600, 600, 'C1'), (13200, 600, 'C1'), (13800, 600, 'C1'),
        (14400, 600, 'C1'), (15000, 600, 'C1'), (15600, 600, 'C1'), (16200, 600, 'C1'),
        (18000, 600, 'C1'), (18600, 600, 'C1'), (19200, 600, 'C1'), (19800, 600, 'C1'),
        (20400, 600, 'C1'), (21000, 600, 'C1')
    ]),
    ('B', 5400.0, 6470.0, 'NORTH', [
        (1800, 600, 'C2'), (2400, 600, 'C2'), (3000, 600, 'C2'), (3600, 600, 'C2'),
        (4800, 600, 'C2'), (5400, 600, 'C2'), (6000, 600, 'C2'), (7800, 600, 'C2'),
        (8400, 600, 'C2'), (9000, 800, 'N2'), (9800, 800, 'N2'), (12600, 600, 'C2'),
        (13200, 600, 'C2'), (15000, 600, 'C2'), (15600, 600, 'C2'), (16200, 600, 'C2'),
        (18000, 600, 'C2'), (18600, 600, 'C2'), (19200, 600, 'C2'), (19800, 600, 'C2'),
        (20400, 600, 'C2')
    ]),
    ('C', 7800.0, 9000.0, 'SOUTH', [
        (1800, 600, 'C1'), (2400, 600, 'C1'), (3000, 600, 'C1'), (3600, 600, 'C1'),
        (4800, 600, 'C1'), (5400, 600, 'C1'), (6000, 600, 'C1'), (7800, 600, 'C1'),
        (8400, 600, 'C1'), (9600, 600, 'C1'), (10200, 600, 'C1'), (12600, 800, 'N1'),
        (14600, 600, 'C1'), (15200, 600, 'C1'), (15800, 600, 'C1'), (16400, 600, 'C1'),
        (18200, 600, 'C1'), (18800, 600, 'C1'), (19400, 600, 'C1'), (20000, 600, 'C1')
    ]),
    ('D', 10800.0, 11870.0, 'NORTH', [
        (1800, 600, 'C2'), (2400, 600, 'C2'), (3000, 600, 'C2'), (3600, 600, 'C2'),
        (4200, 600, 'C2'), (5400, 600, 'C2'), (6000, 600, 'C2'), (6600, 600, 'C2'),
        (7200, 800, 'N2'), (8000, 800, 'N2'), (8800, 600, 'C2'), (9400, 600, 'C2'),
        (10000, 600, 'C2'), (12600, 600, 'C2'), (13200, 600, 'C2'), (13800, 600, 'C2'),
        (14400, 600, 'C2'), (15000, 600, 'C2'), (15600, 600, 'C2'), (16200, 600, 'C2'),
        (16800, 600, 'C2'), (18600, 600, 'C2'), (19200, 600, 'C2'), (19800, 600, 'C2'),
        (20400, 600, 'C2'), (21000, 600, 'C2'), (21600, 600, 'C2')
    ]),
]
CRAHS = [  # name, x0, y0, x1, y1, facing, height, capacity_kw, airflow_m3h, placement
    ('CRAH-01', 600.0, 0.0, 1800.0, 900.0, 'NORTH', 2000.0, 100.0, 20000.0, 'perimeter'),
    ('CRAH-02', 9000.0, 0.0, 10200.0, 900.0, 'NORTH', 2000.0, 100.0, 20000.0, 'perimeter'),
    ('CRAH-03', 16800.0, 0.0, 18000.0, 900.0, 'NORTH', 2000.0, 100.0, 20000.0, 'perimeter'),
    ('CRAH-04', 25200.0, 0.0, 26400.0, 900.0, 'NORTH', 2000.0, 100.0, 20000.0, 'perimeter'),
    ('CRAH-A01', 4200.0, 2400.0, 4800.0, 3600.0, 'SOUTH', 2000.0, 50.0, 9000.0, 'in_row'),
    ('CRAH-A02', 10400.0, 2400.0, 11000.0, 3600.0, 'SOUTH', 2000.0, 50.0, 9000.0, 'in_row'),
    ('CRAH-A03', 17400.0, 2400.0, 18000.0, 3600.0, 'SOUTH', 2000.0, 50.0, 9000.0, 'in_row'),
    ('CRAH-B01', 4200.0, 5400.0, 4800.0, 6470.0, 'NORTH', 2000.0, 50.0, 9000.0, 'in_row'),
    ('CRAH-B02', 10600.0, 5400.0, 11200.0, 6470.0, 'NORTH', 2000.0, 50.0, 9000.0, 'in_row'),
    ('CRAH-B03', 16800.0, 5400.0, 17400.0, 6470.0, 'NORTH', 2000.0, 50.0, 9000.0, 'in_row'),
    ('CRAH-C01', 4200.0, 7800.0, 4800.0, 9000.0, 'SOUTH', 2000.0, 50.0, 9000.0, 'in_row'),
    ('CRAH-C02', 9000.0, 7800.0, 9600.0, 9000.0, 'SOUTH', 2000.0, 50.0, 9000.0, 'in_row'),
    ('CRAH-C03', 17600.0, 7800.0, 18200.0, 9000.0, 'SOUTH', 2000.0, 50.0, 9000.0, 'in_row'),
    ('CRAH-D01', 4800.0, 10800.0, 5400.0, 11870.0, 'NORTH', 2000.0, 50.0, 9000.0, 'in_row'),
    ('CRAH-D02', 10600.0, 10800.0, 11200.0, 11870.0, 'NORTH', 2000.0, 50.0, 9000.0, 'in_row'),
    ('CRAH-D03', 18000.0, 10800.0, 18600.0, 11870.0, 'NORTH', 2000.0, 50.0, 9000.0, 'in_row'),
]
PDUS = [  # name, x0, y0, x1, y1, facing, height, kva, serves_row
    ('PDU-01', 23400.0, 2400.0, 24162.0, 3213.0, 'SOUTH', 1959.0, 225.0, 'A'),
    ('PDU-02', 22800.0, 5657.0, 23562.0, 6470.0, 'NORTH', 1959.0, 225.0, 'B'),
    ('PDU-03', 22400.0, 7800.0, 23162.0, 8613.0, 'SOUTH', 1959.0, 225.0, 'C'),
    ('PDU-04', 24000.0, 11057.0, 24762.0, 11870.0, 'NORTH', 1959.0, 225.0, 'D'),
]
COLUMNS = [  # 600 x 600, finished floor to soffit (A-301 note 4)
    ('COL-01', 6750.0, 6750.0),
    ('COL-02', 6750.0, 13950.0),
    ('COL-03', 6750.0, 21150.0),
    ('COL-04', 13950.0, 6750.0),
    ('COL-05', 13950.0, 13950.0),
    ('COL-06', 13950.0, 21150.0),
    ('COL-07', 21150.0, 6750.0),
    ('COL-08', 21150.0, 13950.0),
]
CONTAINMENT = [  # name, x0, y0, x1, y1, z0, z1
    ('CONT-BC-DOOR-CE', 12540.0, 6370.0, 12600.0, 7900.0, 0.0, 2055.5),
    ('CONT-BC-DOOR-CW', 11400.0, 6370.0, 11460.0, 7900.0, 0.0, 2055.5),
    ('CONT-BC-DOOR-E', 21000.0, 6370.0, 21060.0, 7900.0, 0.0, 2055.5),
    ('CONT-BC-DOOR-W', 1740.0, 6370.0, 1800.0, 7900.0, 0.0, 2055.5),
    ('CONT-BC-ROOF-01', 1800.0, 6370.0, 6750.0, 7900.0, 2000.0, 2055.5),
    ('CONT-BC-ROOF-02', 7350.0, 6370.0, 11400.0, 7900.0, 2000.0, 2055.5),
    ('CONT-BC-ROOF-03', 12600.0, 6370.0, 13950.0, 7900.0, 2000.0, 2055.5),
    ('CONT-BC-ROOF-04', 14550.0, 6370.0, 21000.0, 7900.0, 2000.0, 2055.5),
]
SPRINKLERS = [  # name, centre x, centre y, deflector / head plane, half-width, top
    ('SP-001', 1250.0, 1250.0, 3024.6, 12.7, 3050.0),
    ('SP-002', 3750.0, 1250.0, 3024.6, 12.7, 3050.0),
    ('SP-003', 6250.0, 1250.0, 3024.6, 12.7, 3050.0),
    ('SP-004', 8750.0, 1250.0, 3024.6, 12.7, 3050.0),
    ('SP-005', 11250.0, 1250.0, 3024.6, 12.7, 3050.0),
    ('SP-006', 13750.0, 1250.0, 3024.6, 12.7, 3050.0),
    ('SP-007', 16250.0, 1250.0, 3024.6, 12.7, 3050.0),
    ('SP-008', 18750.0, 1250.0, 3024.6, 12.7, 3050.0),
    ('SP-009', 21250.0, 1250.0, 3024.6, 12.7, 3050.0),
    ('SP-010', 23750.0, 1250.0, 3024.6, 12.7, 3050.0),
    ('SP-011', 26250.0, 1250.0, 3024.6, 12.7, 3050.0),
    ('SP-012', 1250.0, 3750.0, 3024.6, 12.7, 3050.0),
    ('SP-013', 3750.0, 3750.0, 3024.6, 12.7, 3050.0),
    ('SP-014', 6250.0, 3750.0, 3024.6, 12.7, 3050.0),
    ('SP-015', 8750.0, 3750.0, 3024.6, 12.7, 3050.0),
    ('SP-016', 11250.0, 3750.0, 3024.6, 12.7, 3050.0),
    ('SP-017', 13750.0, 3750.0, 3024.6, 12.7, 3050.0),
    ('SP-018', 16250.0, 3750.0, 3024.6, 12.7, 3050.0),
    ('SP-019', 18750.0, 3750.0, 3024.6, 12.7, 3050.0),
    ('SP-020', 21250.0, 3750.0, 3024.6, 12.7, 3050.0),
    ('SP-021', 23750.0, 3750.0, 3024.6, 12.7, 3050.0),
    ('SP-022', 26250.0, 3750.0, 3024.6, 12.7, 3050.0),
    ('SP-023', 1250.0, 6250.0, 3024.6, 12.7, 3050.0),
    ('SP-024', 3750.0, 6250.0, 3024.6, 12.7, 3050.0),
    ('SP-025', 6250.0, 6250.0, 3024.6, 12.7, 3050.0),
    ('SP-026', 8750.0, 6250.0, 3024.6, 12.7, 3050.0),
    ('SP-027', 11250.0, 6250.0, 3024.6, 12.7, 3050.0),
    ('SP-028', 13750.0, 6250.0, 3024.6, 12.7, 3050.0),
    ('SP-029', 16250.0, 6250.0, 3024.6, 12.7, 3050.0),
    ('SP-030', 18750.0, 6250.0, 3024.6, 12.7, 3050.0),
    ('SP-031', 21250.0, 6250.0, 3024.6, 12.7, 3050.0),
    ('SP-032', 23750.0, 6250.0, 3024.6, 12.7, 3050.0),
    ('SP-033', 26250.0, 6250.0, 3024.6, 12.7, 3050.0),
    ('SP-034', 1250.0, 8750.0, 3024.6, 12.7, 3050.0),
    ('SP-035', 3750.0, 8750.0, 3024.6, 12.7, 3050.0),
    ('SP-036', 6250.0, 8750.0, 3024.6, 12.7, 3050.0),
    ('SP-037', 8750.0, 8750.0, 3024.6, 12.7, 3050.0),
    ('SP-038', 11250.0, 8750.0, 3024.6, 12.7, 3050.0),
    ('SP-039', 13750.0, 8750.0, 3024.6, 12.7, 3050.0),
    ('SP-040', 16250.0, 8750.0, 3024.6, 12.7, 3050.0),
    ('SP-041', 18750.0, 8750.0, 3024.6, 12.7, 3050.0),
    ('SP-042', 21250.0, 8750.0, 3024.6, 12.7, 3050.0),
    ('SP-043', 23750.0, 8750.0, 3024.6, 12.7, 3050.0),
    ('SP-044', 26250.0, 8750.0, 3024.6, 12.7, 3050.0),
    ('SP-045', 1250.0, 11250.0, 3024.6, 12.7, 3050.0),
    ('SP-046', 3750.0, 11250.0, 3024.6, 12.7, 3050.0),
    ('SP-047', 6250.0, 11250.0, 3024.6, 12.7, 3050.0),
    ('SP-048', 8750.0, 11250.0, 3024.6, 12.7, 3050.0),
    ('SP-049', 11250.0, 11250.0, 3024.6, 12.7, 3050.0),
    ('SP-050', 13750.0, 11250.0, 3024.6, 12.7, 3050.0),
    ('SP-051', 16250.0, 11250.0, 3024.6, 12.7, 3050.0),
    ('SP-052', 18750.0, 11250.0, 3024.6, 12.7, 3050.0),
    ('SP-053', 21250.0, 11250.0, 3024.6, 12.7, 3050.0),
    ('SP-054', 23750.0, 11250.0, 3024.6, 12.7, 3050.0),
    ('SP-055', 26250.0, 11250.0, 3024.6, 12.7, 3050.0),
    ('SP-056', 1250.0, 13750.0, 3024.6, 12.7, 3050.0),
    ('SP-057', 3750.0, 13750.0, 3024.6, 12.7, 3050.0),
    ('SP-058', 6250.0, 13750.0, 3024.6, 12.7, 3050.0),
    ('SP-059', 8750.0, 13750.0, 3024.6, 12.7, 3050.0),
    ('SP-060', 11250.0, 13750.0, 3024.6, 12.7, 3050.0),
    ('SP-061', 13750.0, 13750.0, 3024.6, 12.7, 3050.0),
    ('SP-062', 16250.0, 13750.0, 3024.6, 12.7, 3050.0),
    ('SP-063', 18750.0, 14350.0, 3024.6, 12.7, 3050.0),
    ('SP-064', 21250.0, 13750.0, 3024.6, 12.7, 3050.0),
    ('SP-065', 23750.0, 14350.0, 3024.6, 12.7, 3050.0),
    ('SP-066', 26250.0, 14350.0, 3024.6, 12.7, 3050.0),
    ('SP-067', 1250.0, 16250.0, 3024.6, 12.7, 3050.0),
    ('SP-068', 3750.0, 16250.0, 3024.6, 12.7, 3050.0),
    ('SP-069', 6250.0, 16250.0, 3024.6, 12.7, 3050.0),
    ('SP-070', 8750.0, 16250.0, 3024.6, 12.7, 3050.0),
    ('SP-071', 11250.0, 16250.0, 3024.6, 12.7, 3050.0),
    ('SP-072', 13750.0, 16250.0, 3024.6, 12.7, 3050.0),
    ('SP-073', 17350.0, 16250.0, 3024.6, 12.7, 3050.0),
    ('SP-074', 1250.0, 18750.0, 3024.6, 12.7, 3050.0),
    ('SP-075', 3750.0, 18750.0, 3024.6, 12.7, 3050.0),
    ('SP-076', 6250.0, 18750.0, 3024.6, 12.7, 3050.0),
    ('SP-077', 8750.0, 18750.0, 3024.6, 12.7, 3050.0),
    ('SP-078', 11250.0, 18750.0, 3024.6, 12.7, 3050.0),
    ('SP-079', 13750.0, 18750.0, 3024.6, 12.7, 3050.0),
    ('SP-080', 17350.0, 18750.0, 3024.6, 12.7, 3050.0),
    ('SP-081', 1250.0, 21250.0, 3024.6, 12.7, 3050.0),
    ('SP-082', 3750.0, 21250.0, 3024.6, 12.7, 3050.0),
    ('SP-083', 6250.0, 21250.0, 3024.6, 12.7, 3050.0),
    ('SP-084', 8750.0, 21250.0, 3024.6, 12.7, 3050.0),
    ('SP-085', 11250.0, 21250.0, 3024.6, 12.7, 3050.0),
    ('SP-086', 13750.0, 21250.0, 3024.6, 12.7, 3050.0),
    ('SP-087', 17350.0, 21250.0, 3024.6, 12.7, 3050.0),
    ('SP-088', 1250.0, 23750.0, 3024.6, 12.7, 3050.0),
    ('SP-089', 3750.0, 23750.0, 3024.6, 12.7, 3050.0),
    ('SP-090', 6250.0, 23750.0, 3024.6, 12.7, 3050.0),
    ('SP-091', 8750.0, 23750.0, 3024.6, 12.7, 3050.0),
    ('SP-092', 11250.0, 23750.0, 3024.6, 12.7, 3050.0),
    ('SP-093', 13750.0, 23750.0, 3024.6, 12.7, 3050.0),
    ('SP-094', 17350.0, 23750.0, 3024.6, 12.7, 3050.0),
    ('SP-095', 2300.0, 7135.0, 1890.0, 50.0, 1990.0),
    ('SP-096', 4275.0, 7135.0, 1890.0, 50.0, 1990.0),
    ('SP-097', 6250.0, 7135.0, 1890.0, 50.0, 1990.0),
    ('SP-098', 7850.0, 7135.0, 1890.0, 50.0, 1990.0),
    ('SP-099', 10900.0, 7135.0, 1890.0, 50.0, 1990.0),
    ('SP-100', 13275.0, 7135.0, 1890.0, 50.0, 1990.0),
    ('SP-101', 15050.0, 7135.0, 1890.0, 50.0, 1990.0),
    ('SP-102', 16866.7, 7135.0, 1890.0, 50.0, 1990.0),
    ('SP-103', 18683.3, 7135.0, 1890.0, 50.0, 1990.0),
    ('SP-104', 20500.0, 7135.0, 1890.0, 50.0, 1990.0),
]


SCHEMA = "IFC4"
_GUID_COUNTER = [0]


def _new_guid():
    """Deterministic IFC GlobalId: uuid5 over a fixed namespace and a counter.

    ifcopenshell.guid.new() would make every run produce different bytes; the
    contract asks for a deterministic script, so the identity of each entity is
    derived from its position in the (deterministic) creation order.
    """
    import uuid
    _GUID_COUNTER[0] += 1
    name = "dc_model/hall_seed000_d000/mep_routing/%d" % _GUID_COUNTER[0]
    return _guid.compress(str(uuid.uuid5(uuid.NAMESPACE_URL, name)))
FACING_ROT = {"NORTH": 0.0, "WEST": 90.0, "SOUTH": 180.0, "EAST": 270.0}

CLS = {
    "rack": ("IfcFurniture", "USERDEFINED", "Rack"),
    "crah": ("IfcUnitaryEquipment", "AIRCONDITIONINGUNIT", None),
    "pdu": ("IfcElectricDistributionBoard", "DISTRIBUTIONBOARD", None),
    "column": ("IfcColumn", None, None),
    "raised_floor": ("IfcCovering", "FLOORING", None),
    "containment": ("IfcCovering", "CLADDING", None),
    "sprinkler": ("IfcFireSuppressionTerminal", "SPRINKLER", None),
    "cable_tray": ("IfcCableCarrierSegment", "CABLETRAYSEGMENT", None),
    "busway": ("IfcCableSegment", "BUSBARSEGMENT", None),
    "chw_pipe": ("IfcPipeSegment", "RIGIDSEGMENT", None),
}


def _pt(f, xy, z=None):
    return f.create_entity("IfcCartesianPoint",
                           Coordinates=tuple(float(v) for v in
                                             ((xy[0], xy[1]) if z is None else (xy[0], xy[1], z))))


def _dir(f, ratios):
    return f.create_entity("IfcDirection", DirectionRatios=tuple(float(v) for v in ratios))


def _rect_profile(f, w, d):
    """2D closed profile, five points, as the drawing set's own elements use."""
    corners = [(0.0, 0.0), (w, 0.0), (w, d), (0.0, d), (0.0, 0.0)]
    poly = f.create_entity("IfcPolyline", Points=[_pt(f, c) for c in corners])
    return f.create_entity("IfcArbitraryClosedProfileDef",
                           ProfileType="AREA", OuterCurve=poly)


def _solid(f, w, d, h):
    origin = f.create_entity("IfcCartesianPoint", Coordinates=(0.0, 0.0, 0.0))
    axis = f.create_entity("IfcAxis2Placement3D", Location=origin,
                           Axis=_dir(f, (0, 0, 1)), RefDirection=_dir(f, (1, 0, 0)))
    return f.create_entity("IfcExtrudedAreaSolid",
                           SweptArea=_rect_profile(f, w, d), Position=axis,
                           ExtrudedDirection=_dir(f, (0, 0, 1)), Depth=float(h))


class Model:
    def __init__(self):
        f = ifcopenshell.file(schema=SCHEMA)
        self.f = f
        length = f.create_entity("IfcSIUnit", UnitType="LENGTHUNIT",
                                 Prefix="MILLI", Name="METRE")
        area = f.create_entity("IfcSIUnit", UnitType="AREAUNIT", Name="SQUARE_METRE")
        volume = f.create_entity("IfcSIUnit", UnitType="VOLUMEUNIT", Name="CUBIC_METRE")
        units = f.create_entity("IfcUnitAssignment", Units=[area, volume, length])
        origin = f.create_entity("IfcCartesianPoint", Coordinates=(0.0, 0.0, 0.0))
        world = f.create_entity("IfcAxis2Placement3D", Location=origin,
                                Axis=_dir(f, (0, 0, 1)), RefDirection=_dir(f, (1, 0, 0)))
        ctx = f.create_entity("IfcGeometricRepresentationContext",
                              ContextIdentifier="Model", ContextType="Model",
                              CoordinateSpaceDimension=3, Precision=1.0e-5,
                              WorldCoordinateSystem=world)
        self.body = f.create_entity("IfcGeometricRepresentationSubContext",
                                    ContextIdentifier="Body", ContextType="Model",
                                    ParentContext=ctx, TargetView="MODEL_VIEW")
        self.project = f.create_entity("IfcProject", GlobalId=_new_guid(),
                                       Name="DC Model", UnitsInContext=units,
                                       RepresentationContexts=[ctx])
        self.site = f.create_entity("IfcSite", GlobalId=_new_guid(), Name="SITE")
        self.building = f.create_entity("IfcBuilding", GlobalId=_new_guid(), Name="DC-01")
        self.storey = f.create_entity("IfcBuildingStorey", GlobalId=_new_guid(),
                                      Name="LEVEL 1", Elevation=0.0)
        f.create_entity("IfcRelAggregates", GlobalId=_new_guid(),
                        RelatingObject=self.project, RelatedObjects=[self.site])
        f.create_entity("IfcRelAggregates", GlobalId=_new_guid(),
                        RelatingObject=self.site, RelatedObjects=[self.building])
        f.create_entity("IfcRelAggregates", GlobalId=_new_guid(),
                        RelatingObject=self.building, RelatedObjects=[self.storey])
        self.storey_placement = f.create_entity(
            "IfcLocalPlacement", RelativePlacement=f.create_entity(
                "IfcAxis2Placement3D", Location=f.create_entity(
                    "IfcCartesianPoint", Coordinates=(0.0, 0.0, 0.0))))
        self.elements = []
        self.space = None

    # -- geometry ---------------------------------------------------------
    def box(self, kind, name, box, facing="NORTH", psets=None):
        return self._element(kind, name, box, facing, psets)

    def _element(self, kind, name, box, facing, psets, space=None):
        f = self.f
        x0, y0, z0, x1, y1, z1 = (float(v) for v in box)
        w, d, h = x1 - x0, y1 - y0, z1 - z0
        rot = FACING_ROT[facing]
        # The placement rotation is the facing; the two profile dimensions swap
        # for the quarter turns so the solid still lands on the drawn footprint.
        if rot == 0.0:
            loc, ref, pw, pd = (x0, y0, z0), (1.0, 0.0, 0.0), w, d
        elif rot == 90.0:
            loc, ref, pw, pd = (x1, y0, z0), (0.0, 1.0, 0.0), d, w
        elif rot == 180.0:
            loc, ref, pw, pd = (x1, y1, z0), (-1.0, 0.0, 0.0), w, d
        else:
            loc, ref, pw, pd = (x0, y1, z0), (0.0, -1.0, 0.0), d, w
        placement = f.create_entity(
            "IfcLocalPlacement", PlacementRelTo=self.storey_placement,
            RelativePlacement=f.create_entity(
                "IfcAxis2Placement3D",
                Location=f.create_entity("IfcCartesianPoint",
                                         Coordinates=tuple(loc)),
                Axis=_dir(f, (0, 0, 1)), RefDirection=_dir(f, ref)))
        shape = f.create_entity("IfcShapeRepresentation", ContextOfItems=self.body,
                                RepresentationIdentifier="Body",
                                RepresentationType="SweptSolid",
                                Items=[_solid(f, pw, pd, h)])
        product = f.create_entity("IfcProductDefinitionShape",
                                  Representations=[shape])
        cls, predefined, object_type = CLS[kind]
        kwargs = dict(GlobalId=_new_guid(), Name=name, ObjectPlacement=placement,
                      Representation=product)
        if object_type is not None:
            kwargs["ObjectType"] = object_type
        if predefined is not None:
            kwargs["PredefinedType"] = predefined
        element = f.create_entity(cls, **kwargs)
        self.elements.append(element)
        if psets:
            self._psets(element, psets)
        return element

    def _psets(self, element, psets):
        f = self.f
        for pset_name, props in psets.items():
            values = []
            for key, value in props.items():
                if isinstance(value, bool):
                    nominal = f.create_entity("IfcBoolean", bool(value))
                elif isinstance(value, int):
                    nominal = f.create_entity("IfcInteger", int(value))
                elif isinstance(value, float):
                    nominal = f.create_entity("IfcReal", float(value))
                else:
                    nominal = f.create_entity("IfcLabel", str(value))
                values.append(f.create_entity("IfcPropertySingleValue",
                                              Name=key, NominalValue=nominal))
            pset = f.create_entity("IfcPropertySet", GlobalId=_new_guid(),
                                   Name=pset_name, HasProperties=values)
            f.create_entity("IfcRelDefinesByProperties", GlobalId=_new_guid(),
                            RelatedObjects=[element], RelatingPropertyDefinition=pset)

    # -- the hall ----------------------------------------------------------
    def add_hall(self):
        f = self.f
        space = f.create_entity(
            "IfcSpace", GlobalId=_new_guid(), Name="DATA HALL 1",
            ObjectPlacement=self.storey_placement,
            Representation=f.create_entity(
                "IfcProductDefinitionShape",
                Representations=[f.create_entity(
                    "IfcShapeRepresentation", ContextOfItems=self.body,
                    RepresentationIdentifier="Body", RepresentationType="SweptSolid",
                    Items=[_solid(f, HALL_W, HALL_D, HALL_H)])]),
            CompositionType="ELEMENT", PredefinedType="INTERNAL",
            ElevationWithFlooring=0.0)
        self.space = space
        f.create_entity("IfcRelAggregates", GlobalId=_new_guid(),
                        RelatingObject=self.storey, RelatedObjects=[space])

    # -- fit-out -----------------------------------------------------------
    def add_fitout(self):
        self.box("raised_floor", "ACCESS FLOOR PANELS",
                 (0.0, 0.0, -PANEL_T, HALL_W, HALL_D, 0.0))
        for name, x0, y0 in COLUMNS:
            self.box("column", name, (x0, y0, 0.0, x0 + 600.0, y0 + 600.0, SOFFIT))
        for name, x0, y0, x1, y1, z0, z1 in CONTAINMENT:
            self.box("containment", name, (x0, y0, z0, x1, y1, z1))
        for name, cx, cy, plane, half, top in SPRINKLERS:
            self.box("sprinkler", name,
                     (cx - half, cy - half, plane, cx + half, cy + half, top))
        for row_id, y0, y1, facing, bays in ROWS:
            depth = y1 - y0
            for index, (x0, width, cabinet_type) in enumerate(bays, start=1):
                name = "RACK-%s%02d" % (row_id, index)
                self.box("rack", name, (x0, y0, 0.0, x0 + width, y1, 2000.0),
                         facing=facing,
                         psets={"Pset_DCM_Rack": {
                             "RackUnits": 42,
                             "WidthMM": float(width),
                             "DepthMM": float(depth),
                             "TileCoordinate": tile_address(x0, y0),
                             "RowId": row_id,
                             "FacingDirection": facing,
                             "CabinetType": cabinet_type,
                         }})
        for (name, x0, y0, x1, y1, facing, height, capacity, airflow,
             placement) in CRAHS:
            self.box("crah", name, (x0, y0, 0.0, x1, y1, height), facing=facing,
                     psets={"Pset_DCM_Cooling": {
                         "CapacityKW": float(capacity),
                         "AirflowM3H": float(airflow),
                         "FacingDirection": facing,
                         "Placement": placement,
                     }})
        for name, x0, y0, x1, y1, facing, height, kva, serves_row in PDUS:
            self.box("pdu", name, (x0, y0, 0.0, x1, y1, height), facing=facing,
                     psets={"Pset_DCM_Power": {
                         "RatingKVA": float(kva),
                         "ServesRow": serves_row,
                         "FacingDirection": facing,
                     }})

    # -- the routes --------------------------------------------------------
    def add_routes(self):
        height = {"cable_tray": TRAY_H, "busway": BUS_H, "chw_pipe": CHW_OD}
        lanes = {"cable_tray": LANE_TRAY, "busway": LANE_BUS, "chw_pipe": LANE_CHW}
        bands = {"cable_tray": BANDS_TRAY, "busway": BANDS_BUS, "chw_pipe": BANDS_CHW}
        prefixes = {"cable_tray": "CT", "busway": "BW", "chw_pipe": "CHW"}
        # the CHW trunk starts at the perimeter header, the other two at the
        # north edge of the south corridor
        trunk_y0 = {"cable_tray": None, "busway": None, "chw_pipe": CHW_SPUR_Y[0]}
        self.route_segments = []
        for service in COVERAGE_SERVICES:
            lx0, lx1 = lanes[service]
            h = height[service]
            (sy0, sy1), (ny0, ny1) = bands[service]
            prefix = prefixes[service]
            # the two transverse corridors: west wall to the last bay of the
            # easternmost row each corridor serves
            self._route(service, prefix + "-B01",
                        (lx0, sy0, Z_OVERHEAD, ROUTE_EAST_S, sy1, Z_OVERHEAD + h))
            self._route(service, prefix + "-B02",
                        (lx0, ny0, Z_OVERHEAD, ROUTE_EAST_N, ny1, Z_OVERHEAD + h))
            # one riser in each corridor's own band (A-101 keynote 2)
            self._route(service, prefix + "-R01",
                        (lx0, sy0, Z_UNDER_TOP, lx1, sy1, Z_OVERHEAD))
            self._route(service, prefix + "-R02",
                        (lx0, ny0, Z_UNDER_TOP, lx1, ny1, Z_OVERHEAD))
            # north-south trunk in the access-floor plenum (TIA-942-B 8.6.2):
            # the one place a run can cross the ceiling-head lines
            ty0 = sy1 if trunk_y0[service] is None else trunk_y0[service]
            self._route(service, prefix + "-T01",
                        (lx0, ty0, Z_UNDER_TOP - h, lx1, ny0, Z_UNDER_TOP))
        # CHW header to the perimeter CRAH gallery on the south wall: all four
        # units are within the 2500 mm reach of y 1800-1968.3, and x 22 800 is
        # 2500 mm short of CRAH-04's west face at 25 200
        self._route("chw_pipe", "CHW-S01",
                    (LANE_CHW[1], CHW_SPUR_Y[0], Z_UNDER_TOP - CHW_OD,
                     CHW_SPUR_EAST, CHW_SPUR_Y[1], Z_UNDER_TOP))

    def _route(self, service, name, box):
        x0, y0, z0, x1, y1, z1 = box
        axis = "X" if (x1 - x0) >= max(y1 - y0, z1 - z0) else (
            "Y" if (y1 - y0) >= (z1 - z0) else "Z")
        length = max(x1 - x0, y1 - y0, z1 - z0)
        element = self.box(service, name, box, facing="NORTH",
                           psets={"Pset_DCM_Route": {
                               "Service": {"cable_tray": "telecom",
                                           "busway": "power",
                                           "chw_pipe": "chilled_water"}[service],
                               "Axis": axis,
                               "LengthMM": float(round(length, 1)),
                           }})
        self.route_segments.append(element)
        return element

    # -- output ------------------------------------------------------------
    def write(self, out_path):
        f = self.f
        if self.space is not None:
            f.create_entity("IfcRelContainedInSpatialStructure",
                            GlobalId=_new_guid(), RelatedElements=self.elements,
                            RelatingStructure=self.space)
        f.write(out_path)
        _pin_timestamp(out_path)


#: ifcopenshell stamps FILE_NAME with the wall clock, so two runs of a
#: perfectly deterministic script differ in four bytes of header.  The routing
#: contract asks for a deterministic script, so the stamp is pinned: two runs
#: of this file are then byte-identical, which is also what makes a package
#: hash meaningful.
FILE_NAME_STAMP = "2026-11-11T00:00:00"


def _pin_timestamp(path):
    import re as _re
    with open(path, "r", encoding="utf-8", errors="surrogateescape") as handle:
        text = handle.read()
    pinned = _re.sub(r"(FILE_NAME\('[^']*',')([^']*)(')",
                     r"\g<1>" + FILE_NAME_STAMP + r"\g<3>", text, count=1)
    if pinned != text:
        with open(path, "w", encoding="utf-8", errors="surrogateescape") as handle:
            handle.write(pinned)


def tile_address(x_mm, y_mm):
    """The access-floor tile an element's south-west corner stands in.

    A-101 note 3: 600 mm grid from the south-west internal corner, columns
    lettered eastward, rows numbered northward.
    """
    column = int(round(x_mm / 600.0))
    row = int(round(y_mm / 600.0)) + 1
    letters = ""
    value = column
    while True:
        letters = chr(ord("A") + value % 26) + letters
        value = value // 26 - 1
        if value < 0:
            break
    return "%s%02d" % (letters, row)


RECONCILIATION = {
    "A-301 soffit 3050 / deflector 3024.6": "enforced as the plenum datum; no run "
        "enters the 460 mm standoff under any head",
    "A-301 clear height 2600": "enforced as the underside of every overhead run",
    "A-602 note: standoff falls below the clear height":
        "read as the design constraint it is: at this soffit the standoff plane "
        "(2564.6) is 35.4 mm below the clear-height plane (2600), so an overhead "
        "run is legal only where no head is over it. The two corridors are "
        "threaded between the ceiling-head lines at y 3750/6250 and 8750/11250.",
    "A-602 tray 683x127, busway 128x147, CHW DN100 114.3+25.4 = 168.3":
        "used as the modelled outside sections",
    "E-101 note 6: 300 mm tray/busway": "320 mm in both corridors and in both trunks",
    "E-101 note 7: 1800 mm above each PDU dedicated":
        "no CHW run within 1800 mm above any PDU footprint: the CHW corridors "
        "stop at x 21 600/22 200, west of the PDU line at x >= 22 400",
    "M-101: CHW to every CRAH, perimeter gallery included":
        "two in-row corridors plus a plenum header at y 1800 to the south wall "
        "gallery; the header is within 2500 mm in plan of CRAH-01..04",
    "F-101: 94 ceiling heads + 10 in-aisle heads": "all 104 modelled; the 10 "
        "in-aisle heads hang from the containment soffit at +1890 per 3/A-301",
    "M-101 2 x DN100 supply and return": "one DN100 insulated main is modelled, "
        "as the coordination contract asks for one network per service; the "
        "return is a duplicate of the supply and is not drawn as a second net",
    "E-101 note 4: busway support at 1500 mm max": "supports are optional in the "
        "contract and are not modelled; the maximum unsupported span is the "
        "22 200 mm corridor, reported rather than claimed",
    "A-101 note: area reserved for future rows, not in contract":
        "the north half of the hall (y > 11 870) is left empty, as drawn",
}


def build(out_path):
    model = Model()
    model.add_hall()
    model.add_fitout()
    model.add_routes()
    model.write(out_path)
    return model


def main(argv):
    out_path = argv[1] if len(argv) > 1 else "output/model.ifc"
    build(out_path)
    # the contract asks for a file that validates with the EXPRESS rules on
    model = ifcopenshell.open(out_path)
    logger = ifcopenshell.validate.json_logger()
    ifcopenshell.validate.validate(model, logger, express_rules=True)
    if logger.statements:
        raise SystemExit("EXPRESS validation failed: %s"
                         % str(logger.statements[0])[:400])
    try:
        import json
        import os
        os.makedirs("output", exist_ok=True)
        with open(os.path.join("output", "reconciliation.json"), "w") as handle:
            json.dump(RECONCILIATION, handle, indent=2)
    except OSError:
        pass
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
