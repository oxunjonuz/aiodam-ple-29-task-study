#!/usr/bin/env python3
"""Build the verified data layer for the 29-task PLE report.

Reads the deliverables and result files that exist on disk *now*, recomputes
sha256/size, re-reads every machine score from its result JSON, re-reads every
rubric's criteria count and weight from the task definition, and checks that a
few anchor facts quoted in the report actually occur in each rubric document.

Output: report_data.json (single source of truth for the HTML generator).
"""
import hashlib
import json
import os
import re
import sys
import zipfile

ROOT = "/work/ple-solve"
TASKS_DIR = "/work/ple-dataset/tasks"
OUT = os.path.join(ROOT, "report", "report_data.json")

CHECKS = [
    dict(num=1, id="cooling-water-flush-plan", type="checks", discipline="Mechanical",
         deliverable="/work/cw/ws/output/submission.zip", size=10349, sha_prefix="ae3b5b76",
         result=f"{ROOT}/cooling-water-flush-plan/results_523/RESULT.json",
         official=f"{ROOT}/cooling-water-flush-plan/results_523/official_testsh/RUN.json",
         official_kind="host", container="task verifier image in Docker on isolated VM (turn 509): 0.949233",
         notes="NOTES_501.md, NOTES_502.md, NOTES_523.md"),
    dict(num=2, id="data-center-site-model", type="checks", discipline="Architectural / site",
         deliverable=f"{ROOT}/data-center-site-model/ws/submission/model.ifc", size=10328, sha_prefix="8b406bee",
         result=f"{ROOT}/data-center-site-model/results_523/metrics.json",
         official=f"{ROOT}/data-center-site-model/results_523/official_testsh/RUN.json",
         official_kind="host", container=None, notes="STATUS.md (turn 486), NOTES_523.md"),
    dict(num=3, id="data-hall-device-takeoff", type="checks", discipline="Electrical",
         deliverable=f"{ROOT}/data-hall-device-takeoff/output/submission.zip", size=8748, sha_prefix="626f9303",
         result=f"{ROOT}/data-hall-device-takeoff/results_523/RESULT.json",
         official=f"{ROOT}/data-hall-device-takeoff/results_523/official_testsh/RUN.json",
         official_kind="host", container=None, notes="NOTES_503.md"),
    dict(num=4, id="data-hall-mep-routing", type="checks", discipline="Mechanical / plumbing",
         deliverable=f"{ROOT}/data-hall-mep-routing/output/solution.py", size=33315, sha_prefix="1e1ab19a",
         result=f"{ROOT}/data-hall-mep-routing/results_523/RESULT.json",
         official=f"{ROOT}/data-hall-mep-routing/results_523/official_testsh/RUN.json",
         official_kind="host", container=None, notes="NOTES_504.md"),
    dict(num=5, id="data-hall-mep-routing-offset", type="checks", discipline="Mechanical / plumbing",
         deliverable=f"{ROOT}/data-hall-mep-routing-offset/output/solution.py", size=37507, sha_prefix="1bdb6077",
         result=f"{ROOT}/data-hall-mep-routing-offset/results_523/RESULT.json",
         official=f"{ROOT}/data-hall-mep-routing-offset/results_523/official_testsh/RUN.json",
         official_kind="host", container=None, notes="NOTES_505.md"),
    dict(num=6, id="division-26-specifications", type="checks", discipline="Electrical",
         deliverable=f"{ROOT}/division-26-specifications/build/stage2/submission.zip", size=155231, sha_prefix="52e1b7f8",
         result=f"{ROOT}/division-26-specifications/results_523/RESULT.json",
         official=f"{ROOT}/division-26-specifications/results_523/official_testsh/RUN.json",
         official_kind="host", container=None, notes="NOTES_494.md"),
    dict(num=7, id="frame-extension-method", type="checks", discipline="Construction planning",
         deliverable=f"{ROOT}/frame-extension-method/out/pkg/submission.zip", size=14375, sha_prefix="9852b459",
         result=f"{ROOT}/frame-extension-method/results_523/RESULT.json",
         official=f"{ROOT}/frame-extension-method/results_523/official_testsh/RUN.json",
         official_kind="host", container=None, notes="NOTES_495.md"),
    dict(num=8, id="heat-rejection-life-cycle-cost", type="checks", discipline="Mechanical",
         deliverable=f"{ROOT}/heat-rejection-life-cycle-cost/out/submission.zip", size=100582, sha_prefix="2f5581ec",
         result=f"{ROOT}/heat-rejection-life-cycle-cost/results_523/RESULT.json",
         official=f"{ROOT}/heat-rejection-life-cycle-cost/results_523/official_testsh/RUN.json",
         official_kind="host", container=None, notes="NOTES_492.md"),
    dict(num=9, id="mv-conveyance-study", type="checks", discipline="Electrical (MV)",
         deliverable=f"{ROOT}/mv-conveyance-study/build/submission.zip", size=64509, sha_prefix="1041555a",
         result=f"{ROOT}/mv-conveyance-study/results_523/RESULT.json",
         official=f"{ROOT}/mv-conveyance-study/results_523/official_testsh/RUN.json",
         official_kind="host", container=None, notes="NOTES_490.md"),
    dict(num=10, id="roof-deck-design", type="checks", discipline="Structural",
         deliverable=f"{ROOT}/roof-deck-design/submission.zip", size=28565, sha_prefix="cda37f86",
         result=f"{ROOT}/roof-deck-design/results_523/RESULT.json",
         official=f"{ROOT}/roof-deck-design/results_523/official_testsh/RUN.json",
         official_kind="host", container=None, notes="STATUS.md (turn 489)"),
    dict(num=11, id="seismic-diaphragm-shear", type="checks", discipline="Structural",
         deliverable=f"{ROOT}/seismic-diaphragm-shear/submission.zip", size=38498, sha_prefix="b686556a",
         result=f"{ROOT}/seismic-diaphragm-shear/results_523/RESULT.json",
         official=f"{ROOT}/seismic-diaphragm-shear/results_523/official_testsh/RUN.json",
         official_kind="host", container="task verifier image in Docker on isolated VM (turn 489): 0.9048330221442563",
         notes="STATUS.md (turn 487), NOTES_523.md"),
    dict(num=12, id="wind-diaphragm-shear", type="checks", discipline="Structural",
         deliverable=f"{ROOT}/wind-diaphragm-shear/out/submission.zip", size=54244, sha_prefix="34061c2f",
         result=f"{ROOT}/wind-diaphragm-shear/results_523/RESULT.json",
         official=f"{ROOT}/wind-diaphragm-shear/results_523/official_testsh/RUN.json",
         official_kind="host", container="task verifier image in Docker on isolated VM (turn 489): 0.7625785645251897",
         notes="STATUS.md (turn 488), NOTES_523.md"),
    dict(num=13, id="eor-review-corrections", type="checks-judge", discipline="Structural (EOR review)",
         deliverable=f"{ROOT}/eor-review-corrections/build/submission.zip", size=19462, sha_prefix="e616192c",
         result=f"{ROOT}/eor-review-corrections/results_523/paper_score.json",
         official=f"{ROOT}/eor-review-corrections/results_523/official_testsh/RUN.json",
         official_kind="host-stub", container=None,
         notes="NOTES_497.md, NOTES_522.md",
         ceiling=0.9198686415517736, ceiling_note="3 of 30 families are judge families; ceiling = reward + 0.4*3/30"),
    dict(num=14, id="foundation-strategy", type="checks-judge", discipline="Geotechnical / structural",
         deliverable=f"{ROOT}/foundation-strategy/out/submission.zip", size=33276, sha_prefix="6debcd3f",
         result=f"{ROOT}/foundation-strategy/results_523/paper_score.json",
         official=None, official_kind="blocked-key", container=None,
         notes="NOTES_496.md, NOTES_522.md",
         ceiling=0.9325465836319168, ceiling_note="4 judge families of 32; ceiling = reward + 0.4*4/32"),
    dict(num=15, id="lv-cable-sizing", type="checks-judge", discipline="Electrical",
         deliverable="/work/lv-cable-sizing/build3/submission.zip", size=35905, sha_prefix="02e84d78",
         result=f"{ROOT}/lv-cable-sizing/results_523/paper_score.json",
         official=None, official_kind="blocked-key", container="Docker on isolated VM with a stub judge relay (turn 499): 0.926935 (simulation, not a judge score)",
         notes="NOTES_498.md, NOTES_499.md",
         ceiling=0.926935336209825, ceiling_note="3 judge families of 35; ceiling = 0.4 + 0.6*O'"),
]

RUBRIC = [
    dict(num=16, id="backfeed-energization-reply", discipline="Electrical / interconnection",
         deliverable=f"{ROOT}/backfeed-energization-reply/out/Halbray_Backfeed_Reply.docx", size=43451,
         sha_prefix="f5a90d94", passed=59, weight_passed=59, mutations="16/16", notes="NOTES_516.md",
         anchors=["07/29/2025", "336.12", "USE-2", "No permitted work shall be energized"]),
    dict(num=17, id="emergency-spillway-check", discipline="Civil / hydraulics",
         deliverable=f"{ROOT}/emergency-spillway-check/out/Memo_to_Callaway_Spillway_2026-10-31.docx", size=46094,
         sha_prefix="4280fed4", passed=20, weight_passed=37, mutations="20/20", notes="NOTES_510.md",
         anchors=["2,857.91", "2,859.20", "Windmill", "1.29"]),
    dict(num=18, id="engineers-estimate-check", discipline="Cost engineering",
         deliverable=f"{ROOT}/engineers-estimate-check/out/Correspondence/Client/Memo_to_Callaway_2026-10-31.docx", size=40771,
         sha_prefix="fdf51ee0", passed=14, weight_passed=46, mutations="12/12", notes="NOTES_509.md",
         anchors=["1,303,717.70", "4,883,349.45", "22.02", "89,600"]),
    dict(num=19, id="fill-compaction-acceptance", discipline="Geotechnical",
         deliverable=f"{ROOT}/fill-compaction-acceptance/output/Thelbridge_Materials_Acceptance_Fill_Compaction_2026-0708.docx", size=42525,
         sha_prefix="5e6234c1", passed=32, weight_passed=108, mutations="10/10", notes="NOTES_507.md",
         anchors=["REJECTED", "128.4", "118.6", "D1557"]),
    dict(num=20, id="fire-solve-convergence", discipline="CFD / fire",
         deliverable=f"{ROOT}/fire-solve-convergence/out/CFDME-2025-041_transient_solve_disposition_revA.docx", size=50471,
         sha_prefix="c1d6cdf2", passed=43, weight_passed=129, mutations="42/42", notes="NOTES_512.md",
         anchors=["0.87", "31.10", "11,214,862", "0.0461"]),
    dict(num=21, id="fire-test-validation-memo", discipline="Fire testing",
         deliverable=f"{ROOT}/fire-test-validation-memo/output/CFDME-2025-041_Validation_Memo_Section7.docx", size=46265,
         sha_prefix="69daa395", passed=48, weight_passed=208, mutations="12/12", notes="NOTES_506.md",
         anchors=["129.8", "118", "13", "9"]),
    dict(num=22, id="footing-settlement-verification", discipline="Geotechnical",
         deliverable="/work/foot/out/Thelbridge_Verification_Memo_Item051_BlockC.docx", size=17638,
         sha_prefix="54fd2aa4", passed=22, weight_passed=62, mutations="20/20", notes="NOTES_511.md",
         anchors=["746.0", "5.42", "6.32", "NOT VERIFIED"]),
    dict(num=23, id="landscape-sheet-revision", discipline="Landscape / planning",
         deliverable=f"{ROOT}/landscape-sheet-revision/output/DSR_Ph3_L4_Street_Tree_Memo_2026-10-31.docx", size=41169,
         sha_prefix="1c7bed31", passed=18, weight_passed=77, mutations="11/12 (+1 equivalent)", notes="NOTES_507.md",
         anchors=["11/30", "208", "11/18", "12/16"]),
    dict(num=24, id="les-mesh-resolution", discipline="CFD / fire",
         deliverable=f"{ROOT}/les-mesh-resolution/out/CFDME-2025-041_resolution_note_revA.docx", size=43314,
         sha_prefix="a0155983", passed=14, weight_passed=82, mutations="19/19", notes="NOTES_513.md",
         anchors=["29.9", "3.74", "84 %", "0.125"]),
    dict(num=25, id="permission-to-operate-memo", discipline="Electrical / interconnection",
         deliverable=f"{ROOT}/permission-to-operate-memo/out/Corwyn_PTO_Memo.docx", size=42770,
         sha_prefix="42b209e0", passed=11, weight_passed=41, mutations="16/16", notes="NOTES_515.md",
         anchors=["08/04/2025", "TCS-02", "21:05", "12.1"]),
    dict(num=26, id="pre-application-capacity-response", discipline="Electrical / planning",
         deliverable=f"{ROOT}/pre-application-capacity-response/out/ALN-108_PreApplication_Response.docx", size=46230,
         sha_prefix="ed8039a0", passed=14, weight_passed=39, mutations="12/12", notes="NOTES_517.md, NOTES_518.md",
         anchors=["3.0 MW", "1.8 MW", "425 days", "ALN-108"]),
    dict(num=27, id="shoring-design-verification", discipline="Geotechnical / temporary works",
         deliverable=f"{ROOT}/shoring-design-verification/out/Thelbridge_Verification_Memo_Item048_BlockB.docx", size=17163,
         sha_prefix="a9c75696", passed=30, weight_passed=122, mutations="30/30", notes="NOTES_514.md",
         anchors=["8.5", "0.81", "NOT VERIFIED", "1.50"]),
    dict(num=28, id="solar-supplemental-review", discipline="Electrical / interconnection",
         deliverable="/work/ssr/build/Bramwick_Commons_Screen_Memo.docx", size=32204,
         sha_prefix="198adf55", passed=22, weight_passed=77, mutations="21/21", notes="NOTES_519.md",
         anchors=["2,400 kW", "1,800 kW", "Screen D", "06/25/2025"]),
    dict(num=29, id="solar-witness-test-package", discipline="Electrical / interconnection",
         deliverable="/work/wit/out/Municipal_Witness_Test_Package.docx", size=45225,
         sha_prefix="7720499c", passed=34, weight_passed=67, mutations="28/28", notes="NOTES_520.md",
         anchors=["SM-215K-3P", "SV-720", "07/09/2025", "CEL-2025-Q2"]),
]

# extra measured facts for rubric tasks that have programmatic criteria or a
# reader ceiling, keyed by task id
EXTRA = {
    "emergency-spillway-check": dict(reader_text="15 of 15 criteria + 5 closure checks · 37 of 37 weight",
                                      reader_compact="15/15 +5"),
    "engineers-estimate-check": dict(reader_text="10 of 10 criteria + 4 closure checks · 46 of 46 weight",
                                     reader_compact="10/10 +4"),
    "fill-compaction-acceptance": dict(reader_text="28 of 28 criteria + 4 closure checks · 108 of 108 weight",
                                       reader_compact="28/28 +4"),
    "footing-settlement-verification": dict(reader_text="17 of 17 criteria + 5 closure checks · 62 of 62 weight",
                                            reader_compact="17/17 +5"),
    "solar-witness-test-package": dict(reader_text="30 of 30 rendered + 4 of 4 programmatic · 67 of 67 weight",
                                       reader_compact="30/30 +4/4"),
    "permission-to-operate-memo": dict(reader_note="11 of 11 criterion groups reachable without the live apps; 3 weight points require work in OpenProject, which was not performed",
                                       judge_score=None),
    "pre-application-capacity-response": dict(reader_note="35/39 (89.7%) against the document alone; 39/39 once the programmatic db_diff criteria are fed the real application dump",
                                              reader_text="14 of 14 criteria with the live db_diff · 39 of 39 weight (35 of 39 on the document alone)",
                                              reader_compact="14/14 (39/39 W)",
                                              judge_score=None),

    "backfeed-energization-reply": dict(reader_note="16 of 17 criteria (59 of 61 weight); criterion 11 stays open because it asks for work in the live apps",
                                        judge_score=None),
}


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def docx_text(path):
    try:
        with zipfile.ZipFile(path) as z:
            xml = z.read("word/document.xml").decode("utf-8", "replace")
    except Exception as exc:  # noqa: BLE001
        return "", f"cannot read docx: {exc}"
    xml = re.sub(r"</w:p>", "\n", xml)
    txt = re.sub(r"<[^>]+>", "", xml)
    txt = (txt.replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
              .replace("&quot;", '"').replace("&apos;", "'"))
    return txt, None


def load_json(path):
    with open(path) as f:
        return json.load(f)


def main():
    errors = []
    rows = []

    for t in CHECKS:
        path = t["deliverable"]
        if not os.path.exists(path):
            errors.append(f"{t['id']}: deliverable missing {path}")
            continue
        size = os.path.getsize(path)
        digest = sha256(path)
        if size != t["size"]:
            errors.append(f"{t['id']}: size {size} != recorded {t['size']}")
        if not digest.startswith(t["sha_prefix"]):
            errors.append(f"{t['id']}: sha {digest[:16]} != recorded prefix {t['sha_prefix']}")
        res = load_json(t["result"])
        if "result" in res:
            inner = res["result"]
            if "paper" in inner:
                reward, grader = inner["paper"]["reward"], inner["paper"]["grader_reward"]
            else:
                reward = inner.get("reward")
                grader = inner.get("metrics", {}).get("combined_score", reward)
        elif "reward" in res:
            reward, grader = res.get("reward"), res.get("grader_reward", res.get("reward"))
        else:  # metrics.json
            reward = grader = res.get("combined_score")
        t.update(size_measured=size, sha256=digest, reward=float(reward), grader=float(grader),
                 file_ok=size == t["size"] and digest.startswith(t["sha_prefix"]))
        if t.get("official"):
            run = load_json(t["official"])
            t["official_reward"] = float(run.get("reward")) if run.get("reward") is not None else None
            t["official_failed"] = bool(run.get("grader_failed"))
            if t["official_reward"] is not None and abs(t["official_reward"] - t["reward"]) > 2e-6:
                # eor official run used the stub judge: that is expected to differ
                if t["official_kind"] != "host-stub":
                    errors.append(f"{t['id']}: official {t['official_reward']} != driver {t['reward']}")
        else:
            t["official_reward"] = None
            t["official_failed"] = None
        rows.append(t)

    for t in RUBRIC:
        path = t["deliverable"]
        if not os.path.exists(path):
            errors.append(f"{t['id']}: deliverable missing {path}")
            continue
        size = os.path.getsize(path)
        digest = sha256(path)
        if size != t["size"]:
            errors.append(f"{t['id']}: size {size} != recorded {t['size']}")
        if not digest.startswith(t["sha_prefix"]):
            errors.append(f"{t['id']}: sha {digest[:16]} != recorded prefix {t['sha_prefix']}")
        crit_path = os.path.join(TASKS_DIR, t["id"], "tests", "grader", "criteria.json")
        crit = load_json(crit_path)
        crit = crit["criteria"] if isinstance(crit, dict) and "criteria" in crit else crit
        n = len(crit)
        w = sum(float(c.get("numerical_weight", 0)) for c in crit)
        prog = sum(1 for c in crit if c.get("programmatic"))
        text, err = docx_text(path)
        if err:
            errors.append(f"{t['id']}: {err}")
        missing = [a for a in t["anchors"] if a not in text]
        if missing:
            errors.append(f"{t['id']}: anchors missing in document: {missing}")
        t.update(type="rubric", size_measured=size, sha256=digest, criteria=n, criteria_weight=w,
                 programmatic=prog, file_ok=size == t["size"] and digest.startswith(t["sha_prefix"]),
                 anchors_ok=not missing, judge_score=None, reward=None, grader=None,
                 official=None, official_kind="not applicable (rubric)", container=None)
        t.update(EXTRA.get(t["id"], {}))
        extra = EXTRA.get(t["id"], {})
        t.setdefault("reader_text", f"{t['passed']} of {t['criteria']} criteria · {t['weight_passed']:.0f} of {t['criteria_weight']:.0f} weight")
        t.setdefault("reader_compact", f"{t['passed']}/{t['criteria']}")
        rows.append(t)

    # sanity: 29 unique tasks, three groups
    assert len(rows) == 29, len(rows)
    assert len({r["id"] for r in rows}) == 29
    assert sum(1 for r in rows if r["type"] == "checks") == 12
    assert sum(1 for r in rows if r["type"] == "checks-judge") == 3
    assert sum(1 for r in rows if r["type"] == "rubric") == 14

    checked = [r for r in rows if r["type"] in ("checks", "checks-judge")]
    rewards = [r["reward"] for r in checked]
    graders = [r["grader"] for r in checked]
    agg = dict(n_tasks=29, n_checks=12, n_checks_judge=3, n_rubric=14,
               n_machine_measured=len(checked),
               n_at_one=sum(1 for r in rewards if abs(r - 1.0) < 1e-9),
               mean_reward=sum(rewards) / len(rewards),
               mean_grader=sum(graders) / len(graders),
               min_reward=min(rewards), max_reward=max(rewards),
               n_official_host=sum(1 for r in checked if r.get("official_kind") == "host"),
               n_official_host_stub=sum(1 for r in checked if r.get("official_kind") == "host-stub"),
               n_blocked_key=sum(1 for r in checked if r.get("official_kind") == "blocked-key"),
               n_container=sum(1 for r in checked if r.get("container")),
               n_rubric_without_judge=14,
               rubric_weight_total=sum(r["criteria_weight"] for r in rows if r["type"] == "rubric"),
               rubric_criteria_total=sum(r["criteria"] for r in rows if r["type"] == "rubric"),
               rubric_breakages=sum(int(re.search(r"/(\d+)", r["mutations"]).group(1)) for r in rows if r["type"] == "rubric"))

    # independent arithmetic on the reported aggregates (the lesson of turn 521)
    assert agg["n_tasks"] == agg["n_checks"] + agg["n_checks_judge"] + agg["n_rubric"] == 29
    assert agg["n_machine_measured"] == 15
    assert round(agg["mean_reward"], 6) == round(sum(rewards) / 15, 6)

    data = dict(generated_from="files on disk at build time", tasks=rows, aggregates=agg,
                errors=errors, build_host=os.uname().nodename)
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w") as f:
        json.dump(data, f, ensure_ascii=False, indent=1)

    print(f"tasks: {len(rows)}  errors: {len(errors)}")
    for e in errors:
        print("  ERR", e)
    print("aggregates:", {k: (round(v, 6) if isinstance(v, float) else v) for k, v in agg.items()})
    for r in rows:
        if r["type"] in ("checks", "checks-judge"):
            print(f"  T-{r['num']:02d} {r['id']:36s} reward={r['reward']:.6f} grader={r['grader']:.6f} "
                  f"official={r.get('official_reward')} kind={r['official_kind']} sha={r['sha256'][:12]}")
        else:
            print(f"  T-{r['num']:02d} {r['id']:36s} rubric n={r['criteria']:2d} w={r['criteria_weight']:5.1f} "
                  f"anchors={'ok' if r['anchors_ok'] else 'MISS'} sha={r['sha256'][:12]}")
    return 1 if errors else 0


if __name__ == "__main__":
    sys.exit(main())
