#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Independent verification of the generated report PDF.

Checks structure (all 29 tasks, TOC numbers), content against report_data.json
(every score, every hash, every size), layout (nothing outside the page, no
same-line overlap, no tiny pages), fonts, and absence of secrets.
Writes VERIFY_REPORT.md and exits non-zero on any failure.
"""
import json
import os
import re
import subprocess
import sys

import fitz  # PyMuPDF

HERE = os.path.dirname(os.path.abspath(__file__))
PDF = "/work/ple-solve/out/PLE_29_Task_Report_AIODAM.pdf"
DATA = json.load(open(os.path.join(HERE, "report_data.json")))
TOC_PAGES = json.load(open(os.path.join(HERE, "toc_pages.json")))

RESULTS = []


def check(name, ok, detail=""):
    RESULTS.append((name, bool(ok), detail))
    print(("PASS " if ok else "FAIL ") + name + (("  — " + detail) if detail else ""))


def main():
    doc = fitz.open(PDF)
    n = len(doc)
    texts = [doc[i].get_text() for i in range(n)]
    full = "\n".join(texts)
    check("PDF opens and has a plausible page count", 40 <= n <= 90, f"{n} pages")

    # page geometry
    w, h = doc[0].rect.width, doc[0].rect.height
    check("page size is A4", abs(w - 595.3) < 2 and abs(h - 841.9) < 2, f"{w:.1f} x {h:.1f} pt")

    # 1. cover
    check("cover carries title, byline and the four headline numbers",
          all(s in texts[0] for s in ["What was measured", "AIODAM", "DeepSeek V4.1 Flash", "29", "15", "14", "0"]),
          "cover page 1")

    # 2. TOC
    toc_txt = texts[1]
    check("contents page present", "Contents" in toc_txt, "page 2")
    lines = [l.strip() for l in toc_txt.splitlines() if l.strip()]
    pairs = []
    for i, l in enumerate(lines[:-1]):
        if re.fullmatch(r"\d{1,2}", l) and not re.fullmatch(r"\d{1,2}", lines[i - 1] if i else ""):
            pairs.append((lines[i - 1], int(l)))
    check("contents lists 40+ entries", len(pairs) >= 40, f"{len(pairs)} entries")

    # every TOC number must equal the page on which the label actually starts
    bad = []
    for label, p in pairs:
        # find first page after the TOC that contains the label
        found = None
        for i in range(2, n):
            if label in texts[i]:
                found = i + 1
                break
        if found != p:
            bad.append((label, p, found))
    check("every contents page number matches the page where the section starts", not bad, str(bad[:4]))

    # 3. all 29 tasks present, with their headings and six mandatory labels
    labels = ["TASK AND INPUTS", "WHAT WAS AMBIGUOUS OR BROKEN", "WHAT I DID AND WHAT CAME OUT",
              "HOW IT WAS VERIFIED", "MY MISTAKES IN THIS TASK", "WHAT REMAINS UNVERIFIED",
              "USE OF REFERENCE OR GRADER MATERIAL"]
    missing, short = [], []
    for t in DATA["tasks"]:
        head = f"T-{t['num']:02d} — {t['id']}"
        if head not in full:
            missing.append(head)
            continue
        p = next(i for i in range(2, n) if head in texts[i])
        body = "\n".join(texts[p:min(p + 3, n)])
        if len(body) < 1800:
            short.append((head, len(body)))
    check("all 29 task headings present", not missing, str(missing[:3]))
    counts = {l: full.count(l) for l in labels}
    bad_counts = {k: v for k, v in counts.items() if v != 29}
    check("each of the seven subsection labels appears exactly 29 times", not bad_counts, str(bad_counts))
    check("no task section is suspiciously short", not short, str(short[:3]))

    # 4. every number in the report matches report_data.json
    bad_scores = []
    for t in DATA["tasks"]:
        if t["type"] in ("checks", "checks-judge"):
            for v in (t["reward"], t["grader"]):
                s = f"{v:.6f}"
                if s not in full:
                    bad_scores.append((t["id"], s))
    check("all 30 measured score figures appear verbatim (6 dp)", not bad_scores, str(bad_scores[:5]))

    bad_rubric = []
    for t in DATA["tasks"]:
        if t["type"] == "rubric":
            s = f"{t['criteria']} criteria · {t['criteria_weight']:.0f} weight points"
            if s not in full:
                bad_rubric.append((t["id"], s))
    check("all 14 rubric criteria/weight pairs appear", not bad_rubric, str(bad_rubric[:3]))

    # 5. every file hash and size appears (hash split in two 32-char halves)
    bad_hash, bad_size = [], []
    for t in DATA["tasks"]:
        sha = t["sha256"]
        if sha[:32] not in full or sha[32:] not in full:
            bad_hash.append(t["id"])
        if f"{t['size_measured']:,}" not in full:
            bad_size.append((t["id"], f"{t['size_measured']:,}"))
    check("all 29 sha256 values appear in full (two halves)", not bad_hash, str(bad_hash[:4]))
    check("all 29 file sizes appear", not bad_size, str(bad_size[:4]))

    # 6. aggregates
    agg = DATA["aggregates"]
    check("aggregate mean reward appears", f"{agg['mean_reward']:.6f}" in full, f"{agg['mean_reward']:.6f}")
    check("aggregate mean grader appears", f"{agg['mean_grader']:.6f}" in full, f"{agg['mean_grader']:.6f}")

    # 7. layout: nothing outside the page, no same-line overlap
    outside, overlaps = [], []
    for i in range(n):
        for wd in doc[i].get_text("words"):
            x0, y0, x1, y1 = wd[:4]
            if x0 < 1 or y0 < 1 or x1 > w - 1 or y1 > h - 1:
                outside.append((i + 1, wd[4], round(x0, 1), round(x1, 1)))
        # same-line overlaps
        words = doc[i].get_text("words")
        by_line = {}
        for x0, y0, x1, y1, word, *_ in words:
            key = round(y0, 0)
            by_line.setdefault(key, []).append((x0, x1, word))
        for key, items in by_line.items():
            items.sort()
            for a, b in zip(items, items[1:]):
                if b[0] < a[1] - 2.0:
                    overlaps.append((i + 1, a[2], b[2], round(a[1] - b[0], 1)))
    check("no glyph outside the page box", not outside, str(outside[:4]))
    # content must stay inside the 17 mm side margins, and the only thing below the
    # 18 mm bottom margin must be the stamped page number
    margin_l, margin_r, margin_b = 17 * 72 / 25.4, w - 17 * 72 / 25.4, h - 45
    in_margin, low = [], []
    for i in range(n):
        for x0, y0, x1, y1, word, *_ in doc[i].get_text("words"):
            if i == 0:
                continue
            if x0 < margin_l - 3 or x1 > margin_r + 3:
                in_margin.append((i + 1, word))
            if y1 > margin_b:
                low.append((i + 1, word))
    check("body text stays inside the side margins", not in_margin, str(in_margin[:4]))
    low_text = " ".join(x[1] for x in low)
    check("below the bottom margin there is only the stamped page number",
          bool(re.fullmatch(r"(page \d+ of \d+\s*)+", low_text)), low_text[:80])
    check("no overlapping words on the same line", not overlaps, str(overlaps[:5]))

    # 8. no blank pages except none expected
    blanks = [i + 1 for i, t in enumerate(texts) if len(t.strip()) < 60]
    check("no blank or near-blank pages", not blanks, str(blanks))

    # 9. figures: captions and images
    caps = [c for c in ["Figure 1.", "Figure 2.", "Figure 3.", "Figure 4."] if c in full]
    check("all four figure captions present", len(caps) == 4, str(caps))
    img_pages = sum(1 for i in range(n) if doc[i].get_images(full=True))
    check("raster figures embedded", img_pages >= 3, f"{img_pages} pages carry images")

    # 10. fonts embedded
    try:
        ff = subprocess.run(["pdffonts", PDF], capture_output=True, text=True).stdout
        rows = [l for l in ff.splitlines()[2:] if l.strip()]
        def emb_col(line):
            m = re.search(r"\b(yes|no)\s+(yes|no)\s+(yes|no)\s+\d+\s+\d+\s*$", line)
            return m.group(1) if m else "?"
        not_emb = [l for l in rows if emb_col(l) != "yes"]
        t3 = [l for l in rows if "Type 3" in l]
        check("all fonts embedded", not not_emb, str(not_emb[:2]))
        check("no Type 3 fonts", not t3, str(t3[:2]))
    except FileNotFoundError:
        check("pdffonts available", False, "pdffonts not found")

    # 11. independent extraction with pdftotext must contain the same key strings
    pdftotext = subprocess.run(["pdftotext", "-layout", PDF, "-"], capture_output=True, text=True).stdout
    keys = ["cooling-water-flush-plan", "0.949233", "data-hall-mep-routing-offset",
            "NOT MEASURED", "Appendix D — glossary", "0.905973"]
    check("second extractor (pdftotext) sees the same key strings",
          all(k in pdftotext for k in keys), str([k for k in keys if k not in pdftotext]))
    from pypdf import PdfReader
    r = PdfReader(PDF)
    t3 = "".join((pg.extract_text() or "") for pg in r.pages)
    keys3 = ["T-29 — solar-witness-test-package", "0.949233", "NOT MEASURED", "0.905973"]
    check("third extractor (pypdf) agrees on page count and key strings",
          len(r.pages) == n and all(k in t3 for k in keys3),
          f"{len(r.pages)} pages, missing {[k for k in keys3 if k not in t3]}")
    ctrl = [c for c in full if ord(c) < 32 and c not in "\n\t\r\f"]
    check("no control characters in extracted text", not ctrl, str(sorted(set(map(hex, ctrl)))[:5]))

    # 12. secrets
    patterns = [r"sk-[A-Za-z0-9_\-]{12,}", r"AKIA[0-9A-Z]{16}", r"(?i)(api[_-]?key|password|secret|token)\s*[:=]\s*[^\s,;]{6,}",
                r"Bearer\s+[A-Za-z0-9\-._~+/]{10,}", r"(?i)judge_api_key\s*=\s*\S+"]
    hits = []
    for pat in patterns:
        for m in re.finditer(pat, full):
            hits.append((pat, m.group(0)[:40]))
    check("no credentials or key values in the report", not hits, str(hits[:3]))

    # 13. the summary table carries all 29 rows
    sum_start = next(i for i in range(n) if "All 29 tasks at a glance" in texts[i])
    sum_end = next(i for i in range(sum_start + 1, n) if "How the work was done" in texts[i])
    sum_txt = "\n".join(texts[sum_start:sum_end])
    miss_rows = [t["id"] for t in DATA["tasks"] if t["id"] not in sum_txt]
    check("summary table contains all 29 task names", not miss_rows, str(miss_rows[:4]))
    miss_r = [f"{t['id']}={t['reward']:.4f}" for t in DATA["tasks"]
              if t["type"] in ("checks", "checks-judge") and f"{t['reward']:.4f}" not in sum_txt]
    check("summary table shows the final reward for all 15 machine-scored tasks", not miss_r, str(miss_r[:4]))

    # 14. every rubric section states that the judge score is not measured
    bad_judge = []
    for t in DATA["tasks"]:
        if t["type"] != "rubric":
            continue
        head = f"T-{t['num']:02d} — {t['id']}"
        p = next(i for i in range(2, n) if head in texts[i])
        if "NOT MEASURED" not in texts[p]:
            bad_judge.append(t["id"])
    check("every rubric task states NOT MEASURED in its score box", not bad_judge, str(bad_judge))
    check("the report states that no judge score exists anywhere",
          "no LLM-judge score exists anywhere in this report" in full.replace("\n", " "), "")

    # write the verification record
    ok = sum(1 for _, k, _ in RESULTS if k)
    with open(os.path.join(HERE, "VERIFY_REPORT.md"), "w") as f:
        f.write("# Report verification\n\n")
        f.write(f"PDF: `{PDF}` · {n} pages · {os.path.getsize(PDF):,} bytes\n\n")
        f.write(f"Checks: {ok}/{len(RESULTS)} passed.\n\n| # | check | result | detail |\n|---|---|---|---|\n")
        for i, (name, k, detail) in enumerate(RESULTS, 1):
            f.write(f"| {i} | {name} | {'PASS' if k else 'FAIL'} | {detail.replace('|', '/')} |\n")
    print(f"\n{ok}/{len(RESULTS)} checks passed; wrote VERIFY_REPORT.md")
    return 0 if ok == len(RESULTS) else 1


if __name__ == "__main__":
    sys.exit(main())
