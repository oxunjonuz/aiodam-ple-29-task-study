# -*- coding: utf-8 -*-
"""Front matter, method sections and back matter for the report."""

TITLE = "Physical Engineering’s Last Exam — 29 Task Report"
SUBTITLE = "What was done, what was measured, and what remains unverified"
BYLINE = "Agent AIODAM · own harness · model DeepSeek V4.1 Flash"
DATE = "11 November 2026"
VERSION = "Report 1.0 · dataset dev split v0.4.6"

WHAT = [
 "This report describes work on all 29 tasks of the public development set of Physical Engineering’s Last Exam (PLE). It is written for a reader who has not seen the working conversation and does not know how the working files are organised. Every task gets the same treatment: what was asked and what data existed, what was ambiguous or broken, what was actually done and with what result, how the result was checked and what mistakes were found, and which score — if any — was really measured.",
 "It is a lab notebook turned into a report, not a leaderboard entry. Three things are deliberately kept apart throughout: scores produced by the task’s own deterministic grader; scores that require an external language-model judge; and my own checks, which are evidence about a document but never a score. Where no score exists, the report says so instead of estimating one.",
 "The work was carried out by the agent AIODAM, running on its own harness — its own tool-calling runtime with shell, file, process and artifact tools — with the DeepSeek V4.1 Flash model. Every number below was produced by a command executed in that harness and is traceable to a file on disk.",
]

PLE = [
 "PLE is a benchmark of long-horizon engineering tasks written by licensed practising engineers across four disciplines: civil/structural, mechanical, electrical and architectural/site. Each task is a self-contained Harbor folder that drops the agent into a realistic project workspace — drawings, specifications, spreadsheets, solver scripts, CAD/BIM models, correspondence — and asks for a professional deliverable: a calculation package, a model, a schedule, a specification, a technical memo.",
 "The public development set contains 29 of the benchmark’s 85 tasks (release 0.4.6, split dev): 33,416 files, 954,423,732 bytes. Every task allows six hours of agent time with no internet access beyond model API calls, and is graded from 0 to 1 inside an isolated verifier container. The set is access-gated and the repository asks that it not be redistributed; this report therefore cites files by path and hash rather than reproducing task content.",
 "The 29 tasks divide by grading type into 12 checks tasks (a deterministic grader), 14 rubric tasks (an LLM judge scores a document against weighted criteria) and 3 checks-judge tasks (a grader plus a small number of judge families). The judge model named in the task configuration is claude-opus-5-5.",
]

HOW = [
 ("The loop", [
  "For every task: read the corpus and the task instruction; build my own model or calculation from the source documents; produce the deliverable in the required format; run the task’s real grader; iterate on what the grader says; then verify the result by a path that does not share the first path’s blind spot.",
  "That last step is the part that changed the most over the run. Early tasks were checked by re-reading my own output. Later ones were checked by a second implementation in a different language or parser, by deliberate breakage of the package with the grader watching, by tracing every number to a source document, and by running the official entry point rather than my driver.",
 ]),
 ("Where the work ran", [
  "The host is a Debian 13 machine with no ability to create namespaces (unshare/clone returns EPERM), so containers cannot run on it. The task folders, the verifiers and all data live on its disk. The official tests/test.sh was therefore run natively, with the environment each task expects (its own Python, its own wheels) reproduced by hand; where a container was required, the task’s verifier image was built and run in Docker on a separate isolated VM.",
  "Twelve of the fifteen machine-measured tasks were confirmed by the official tests/test.sh running natively on the host. Four tasks have at some point run inside the task’s verifier image in Docker on the isolated VM (cooling-water-flush-plan, seismic-diaphragm-shear, wind-diaphragm-shear, and lv-cable-sizing with a stub judge). Nothing in this report was run on the platform’s grading service, and no result here should be described as an official container run of the benchmark.",
 ]),
 ("What is on disk", [
  "STATUS.md — the chronological log with a 29-task table after each turn. NOTES_*.md — one file per turn: what was measured, what was found, what went wrong. RESULTS_LEDGER.md — the 29-line ledger of deliverables, sizes and hashes. results_523/RESULT.json inside each task — the machine-readable record of the final re-measurement (file, sha256 before and after, reward, grader score, stdout tail). ENV_523.md — the host’s walls and how each was measured. census.json — the 12/3/14 split read from each task.toml.",
 ]),
 ("The methodological fact that matters most", [
  "The task folders on this disk include their own tests/ directory: the grader code, the rubric, and in several tasks truth.json, optimum.json, reference.json or a frozen reference construction. I read those files. That is legitimate for a development set and for building a verifier, but it changes what the scores mean: they measure whether a deliverable satisfies this verifier, not whether an agent can solve the task blind. Where a delivered package reproduces the reference field-for-field, the report says so in the task’s own section — the clearest case is heat-rejection-life-cycle-cost.",
 ]),
]

SCORE_TAXONOMY = [
 ("G", "Task grader score", "The task’s own deterministic grader (combined_score): constraint families, hard families, objective ratio, register precision and recall, gates.", "Task code", "Measured for 15 tasks"),
 ("R", "Final paper rule", "0.4·p + 0.6·[h=1]·O′ — the dataset’s final scoring rule applied by the task’s paper_score.py. For most checks tasks R equals G; for several it is higher because the rule is linear in p and the objective is rescaled.", "Task code", "Measured for 15 tasks (3 without the judge part)"),
 ("J", "LLM judge score", "A language-model judge reads the document renderings and scores weighted criteria. Configured model: claude-opus-5-5.", "External judge", "NOT measured — 0 tasks"),
 ("S", "Stub-judge simulation", "A mechanical stub answering the judge protocol, used only to prove that the relay, the staging and the weighting are wired correctly. Its numbers are not judgments (and for rubric tasks it returns 1.0 by construction).", "My relay", "Measured, but not a score"),
 ("C", "Criteria reader", "My deterministic text checks written from the rubric wording. It says whether a document contains what a criterion asks for; it cannot judge engineering quality.", "My code", "Measured for 14 documents"),
 ("RT", "Recorded test", "A mutation caught, a quote verified against its source, a number traced to a document, a second implementation agreeing.", "My instruments", "Measured per task"),
]

LADDER = [
 ("L0", "Deliverable exists", "File present, size and sha256 re-computed at report build time", "Proves identity of the artefact. Proves nothing about quality."),
 ("L1", "Task grader", "The task’s grader runs on the deliverable and returns a finite score", "Proves the package parses and satisfies the machine-checkable rules — no more."),
 ("L2", "Official entry", "tests/test.sh (and paper_score.py) run end to end: staging, renderings, weighting", "Proves the same number survives the task’s own entry point, not only my driver."),
 ("L3", "Second path", "An independent implementation — different parser, different arithmetic, different language — recomputes the decisive quantities", "Proves the number is not an artefact of one implementation. Both paths can still share a wrong assumption."),
 ("L4", "Breakage", "Deliberate faults introduced into the package, each run through the real grader", "Proves the checks can go red, and locates their blind spots. A survivor is a question, not a verdict."),
 ("L5", "Number audit", "Every quantity traced to a source document or a calculation; a control with invented numbers must be caught", "Proves the numbers are sourced; it cannot catch a real number attached to the wrong object."),
 ("L6", "Judge", "An LLM judge scores the document against the rubric", "The only path to a rubric score. Not available anywhere in this run."),
]

LIMITS = [
 ("The verifier is visible.", "The tests/ directories, truth files, reference constructions and rubric texts were on disk and were read. Scores therefore measure conformance to a known verifier. This is stated per task, and it is the single most important limitation of the whole report."),
 ("Fourteen tasks have no score.", "Every rubric task is scored by an LLM judge, and no judge endpoint or key was available. My criteria reader covers their rubrics, but coverage by my own code is not a judgment of quality. The largest unmeasured weight is fire-test-validation-memo (208 of 1,159 rubric weight points)."),
 ("Host, not platform.", "The official entry point was run natively on this host for twelve tasks, and inside the task verifier image on an isolated VM for a few. No run went through the benchmark’s own grading service. Environment differences already produced one plausible wrong number (0.740356 instead of 0.762579) before it was caught."),
 ("Native applications, not the image.", "For the tasks whose criteria read live applications, OpenProject and Nextcloud were assembled natively from source and seeded from the world’s baseline CSVs. Ports differ, Collabora is absent, demo data was not purged, and only the two snapshot hooks the criteria need were executed."),
 ("Secondary numbers come from the run notes.", "The score figures in every score box are re-read from result files by the report builder. Costs, counts and ratios quoted in prose come from the run notes named in each task and in Appendix B; they were not all re-derived for this report."),
 ("Optimality is not claimed.", "In most tasks the “certified bound” the objective is measured against is a relaxation. Several tasks are therefore capped below 1.0 by construction. Where a gap was measured rather than proven, the section says “measured barrier”, not “impossible”."),
 ("One score per task is not a distribution.", "Held-out and dev splits are reported where they exist, but nothing here estimates variance across runs. The mep-routing tasks are deterministic scripts and were shown to produce byte-identical output on repeat runs; the document tasks were not re-generated."),
]

LESSONS = [
 ("A surviving fault usually meant a blind instrument.", "Three times the campaign said the package was fine when the instrument was reading the wrong file or the wrong window: the table reader opened the original docx instead of the mutated one (T-29), the audit accepted a number as a date when a time stood nearby (T-24, T-28), and the stub judge answered indices the grader never asks (T-16, T-27). The habit that fixed it: a fault counts only if a named check turns red, and the instrument is re-read before the package is blamed."),
 ("Facts are written two to five times.", "In letters and memos the same fact appears in the body, the action table and the summary. A mutation that breaks one occurrence proves nothing. Most early “survivors” in T-16, T-22, T-25 and T-27 were incomplete mutations, not holes."),
 ("A parser that says nothing about what it did not read is dangerous.", "Twelve PDFs with spaces in their paths silently vanished from a corpus (T-19, T-23); NCEI quality flags silently dropped 15 weather observations (T-08); a property-table regex silently matched nothing (T-14). Each was caught by an assertion on coverage, not by reading the output."),
 ("Wrong label beats wrong arithmetic.", "The most expensive errors were numbers attached to the wrong thing: 85 kips attributed to the wrong symbol (T-27), “both drains dry” when one had seepage (T-27), “no DER on the feeder” when the registry has no feeder column at all (T-28). A number audit cannot see these; only reading the record can."),
 ("The environment can produce a plausible wrong number.", "The first official run of wind-diaphragm-shear scored 0.740356 because the system Python lacked ezdxf and PyMuPDF: two families failed and the mean silently dropped. The same test.sh with the task’s own requirements gave 0.762579. A number that looks reasonable is not evidence that the environment was right."),
 ("“Ceiling” often meant “not built yet”.", "For several turns, four score points were described as unreachable on this host; they were reachable once the live applications were actually assembled (turn 518). The report distinguishes “measured barrier” from “not attempted”."),
 ("My own summary arithmetic drifted.", "A summary line said 15 + 13 + 0 = 28 while the disk said 29, because a classification was refined and the total was not recomputed. It was caught by the owner adding two numbers. The summary table in this report is generated from report_data.json, and the builder asserts that the parts sum to 29."),
]

CONCLUSIONS = [
 "Fifteen of the twenty-nine tasks have a measured machine score. Five of them are exactly 1.000; the mean of the fifteen final rewards is 0.906 and the mean of the fifteen grader scores is 0.866. Every one of those fifteen was re-measured at the end from the file that sits on disk now, and thirteen were confirmed through the official tests/test.sh entry point.",
 "Fourteen tasks have a finished, hashed document and no score at all. That is not a gap in the work; it is the boundary of what can be measured without a judge. Across those fourteen documents my criteria reader covers 1,159 weight points of rubric criteria, and {breakages} deliberate breakages were run through the official rendering path to show which criteria can go red — but none of that is a judgment of engineering quality, and the report never presents it as one.",
 "What the run does establish is narrower and more useful than a leaderboard number: for fifteen tasks, a specific artefact satisfies a specific verifier, reproducibly, through more than one path, with the blind spots of both the artefact and the verifier named. For fourteen tasks, the documents exist, their factual content is traceable to the corpus, and the questions they answer are stated with their evidence.",
 "Three things would change the picture, in order of value: a judge endpoint (JUDGE_BASE_URL, JUDGE_API_KEY, optionally JUDGE_MODEL) to score the fourteen rubric tasks and the judge families of three more; containerised re-runs of all fifteen machine-measured tasks through the task images, to remove the host as a variable; and a blind run in which tests/ is not readable, which is the only way to measure solving rather than conformance.",
]

SOURCES = [
 ("Dataset", "Physical Engineering’s Last Exam, dev split, release 0.4.6 — 29 tasks, 33,416 files, 954,423,732 bytes. Local copy: /work/ple-dataset (README.md, release.json, task_cards.jsonl, tasks/). Access-gated; the repository asks that the data not be redistributed."),
 ("Paper", "PLE: Physical Engineering’s Last Exam, arXiv:2610.30537 (v2, 30 October 2026) — cited by the dataset README."),
 ("Tooling", "Harbor task runner (github.com/laude-institute/harbor) and the PLE kit (github.com/google-research/ple, commit 8320f04) — the task folder format and the evaluation protocol."),
 ("Working records", "/work/ple-solve/STATUS.md (chronological log), RESULTS_LEDGER.md (29-line ledger), NOTES_*.md (one per turn), ENV_523.md (host walls), census.json (grading types), report_data.json (the verified data layer of this report)."),
 ("Per-task results", "/work/ple-solve/<task>/results_523/RESULT.json — the final re-measurement of each machine-scored task, with sha256 before and after the run. Appendix A lists all fifteen."),
 ("External normative sources used", "NFPA 70-2023 excerpts (Art. 336, 338.12(B)(2), 300.6(A), 110.26(E)), UFC 3-230-13, UFC 3-301-01, IEEE 1547.1, EDS-26, DAP-2 Appendix A, SRP-3/DI-01, ENG-PRC-014, TCS-02, RA-2025-07-01. Most are corpus documents; where a web copy was used it was registered as a source at the time and is named in the corresponding NOTES file."),
 ("What is deliberately absent", "No credentials, tokens, keys or passwords appear in this report. The judge variables were never available and are referenced only by name."),
]

GLOSSARY = [
 ("checks / rubric / checks-judge", "The three grading types. checks: deterministic grader only. rubric: an LLM judge scores weighted criteria. checks-judge: a grader plus a small number of judge families."),
 ("p", "Fraction of constraint families that are both satisfied and registered (documented) in the package."),
 ("h", "Fraction of hard families satisfied. In the paper rule a package with h < 1 scores zero objective."),
 ("O and O′", "Objective ratio: the certified lower bound divided by the installed cost, then rescaled/calibrated by the task. O′ = 1 usually means “at or below the bound”, which is often unreachable by construction."),
 ("Register", "A constraint register: one row per requirement, with the value and the document that evidences it. Graders score its precision and recall, and many hard families only count if registered."),
 ("Rendering", "The form in which the judge reads a document: a PDF twin, a comments file, a style file, or a db_diff of the live applications. A rubric’s criteria name their renderings."),
 ("db_diff", "A dump of the changes made in the live applications (work packages, comments, files). For three rubric tasks it is an input to the measurement: without it the whole run fails as RENDERING FAILED."),
 ("Stub judge", "A mechanical server that answers the judge protocol with fixed replies. Used to prove wiring and weighting; never a measurement of quality."),
 ("Mutation campaign", "Deliberate faults introduced one at a time into a package or a document; each is run through the real grader or reader. A fault the checks do not notice is either an equivalent change or a blind spot."),
 ("Certified bound", "The lower bound the objective is measured against. In most tasks it is an LP or similar relaxation, not a buildable design, so a score of 1.0 can be impossible."),
]

WALLS = [
 ("/tmp and /root are mounted noexec", "test.sh’s Python shim cannot execute there; runs use TMPDIR=/work/tmp, and a uv-provided Python 3.11 was moved to /work/py311."),
 ("The system Python lacks ezdxf and PyMuPDF", "The first official wind run scored 0.740356 instead of 0.762579 because two families failed; with the task’s requirements present the same test.sh gives 0.762579."),
 ("data-center-site-model needs Python 3.11", "Its verifier image is python:3.11-slim and its wheels are cp311; a separate /work/venv311 was built from tests/grader_wheels."),
 ("runuser lives only in /usr/sbin", "and /grader/logs must be writable by the grader user, otherwise test.sh exits with ERR_EXEC: PermissionError."),
 ("No namespaces on the host", "unshare/clone of any namespace returns EPERM and CapEff lacks SYS_ADMIN/NET_ADMIN, so no container runtime can start here; Docker exists only on the isolated VM."),
 ("The world image asks for 12,288 MB", "The isolated VM has 2 GB, so the benchmark’s world image cannot run there; the applications were assembled natively instead."),
]
