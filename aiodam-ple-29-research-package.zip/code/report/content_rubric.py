# -*- coding: utf-8 -*-
"""Narrative content for the rubric tasks (T-16 .. T-29).

These tasks have no machine score.  The numbers quoted here are from the run
notes named in report_data.json; the deliverable files were re-hashed at build
time and the criteria counts/weights re-read from the task rubrics.
"""

RUBRIC = {
"backfeed-energization-reply": dict(
 headline="The answer is “not on 07/29/2025”, and the reason is three cable types and one permit condition — not the contract.",
 task="Write the utility's reply to a request to energize a solar site before permission to operate (PXA-2024-0002, Halbray Field Solar Site 3): can backfeed happen on 07/29/2025? The deliverable is a letter; three of the seventeen criteria read the live applications (the work log, comments and the file store) through a db_diff.",
 inputs="The interconnection agreement, the permit and inspection record, the telemetry and settings records, four drawing sheets, NFPA 70-2023, and the project correspondence.",
 ambiguities=[
  "The contract does not block it: the ISA of 18/11/2024 says the Company may energize on the interconnection customer's written request.",
  "Telemetry does not block it either: the RTU was accepted end-to-end on 02/07/2025, recloser settings on 16/06 and acceptance on 07/07, meter RM-0002 on 08/07, and the inverters are in CEL-2025-Q2.",
  "What blocks it is the installation: three NFPA 70-2023 violations sit on the record — Type TC cable run along the row piles outside a tray or raceway (Art. 336.10/336.12, 96 drives), USE-2 cable used above ground (338.12(B)(2)), and a strut support with green enamel finish instead of corrosion protection (300.6(A)).",
  "And the permit condition: “No permitted work shall be energized before final approval”, with the inspection booked for 24/07/2025, five days before the date, and no written final approval — which the three items above make unattainable.",
 ],
 did=[
  "A letter that separates what blocks from what does not, names Tamsworth Electrical Constructors Inc. as the permit holder, and says plainly that we can attend and answer for our equipment but cannot obtain their permit.",
  "Each violation quoted from the drawing or the code, with the consequence tied to the specific circuits that the requested energization would put live (T-1, the 800 V assembly, CSB-1, feeders C-1…C-4, the inverters' output circuits, and through the 30 A breaker AUX-1 and the eight TC controllers).",
 ],
 result=["16 of 17 criteria met by my reader on the PDF twin — 59 of 61 weight; criterion 11 stays open because it asks for work in the live applications."],
 verified=[
  "The reader on both PDF extractions (fitz and pypdf) — the same two the judge is known to use.",
  "Five closure checks (counts, dates, “no date promised”, quotes).",
  "A second path: seven decisive facts re-read from the structural files (pypdf plus cells located by header).",
  "All 17 quotes found verbatim in the letter and in the source; a number audit over 77 tokens with 0 unexplainable, and a control that catches 3 of 3 invented numbers.",
  "Sixteen breakages through the official transform.py — all noticed, each by its own criterion.",
  "The official test.sh → verify.py → grade.py chain with a stub judge: 1.0 on a synthetic db_diff; with an empty db_diff it fails the whole rendering stage (GRADER FAILED), which is itself a finding: those points are an input to the measurement, not a bonus.",
 ],
 errors=[
  "Five of sixteen mutations survived at first because every fact appears two to four times in the letter (body, action table, Table 1). The rule since then: a fact must be mutated in all its occurrences.",
  "A reader window crossed paragraph boundaries, so criterion 5 was satisfied by a paragraph about drive cable plus the heading of section 3.2. Fixed by cutting blocks at paragraph openings.",
  "Criterion 9 accepted a neighbouring table row where the owner was Halbray; fixed to require the actor within two sentences.",
  "The stub judge answered all 17 indices while the grader asks in rendering groups (16 + 1), which produced “criterion index mismatch: unexpected [11]”; and it read the prompt including the criteria text, which literally contains what the checks look for.",
  "Case sensitivity cost me two mutations — the same error as in T-25 and T-26.",
 ],
 unverified="No judge score. The work in the live applications was not done for this task (2 weight points), and the docx was not rendered inside the verifier image; it was rendered locally with the official transform.py under LibreOffice 25.2.3.2 520, the same build measured in the base image.",
 gt="None. Every fact comes from the corpus; no reference construction exists for a letter.",
),

"emergency-spillway-check": dict(
 headline="G-4 is not answered on the drawing, the freeboard does not hold once the weir works, and the overflow has no discharge right.",
 task="Review G-4, the emergency spillway of an accepted drainage study, and write a memo: is the sheet answerable, do the revisions require an amendment, and does the freeboard hold? Fifteen criteria, weight 37.",
 inputs="The G-4 sheet, the accepted study, the CCRFCD letter, the site plan OS-1, the survey, and the punch-list close-out.",
 ambiguities=[
  "G-4 is not answered on the sheet: no freeboard dimension, no weir calculation, no section through the weir, the apron only in plan, and the sheet gives 0.71/0.60 ft for one size where the arithmetic gives 0.59 ft.",
  "No revision triggers an amendment: none of the CCRFCD letter's triggers of 28/02/2022 is touched.",
  "The freeboard of 1.29 ft does not hold with the weir working: crest 2,858.50 is 0.59 ft above the computed pool 2,857.91, leaving 0.70 ft to the berm at 2,859.20 against the 1.0 ft required — a 0.41 ft shortfall.",
  "The overflow runs to the accepted County curb-and-gutter on Windmill Lane (OS-1, $612,000, punch list closed 12/03/2025), but there is no discharge right in the record — no easement, no permit; the accepted study knows one outfall, a 30 in RCP in the south-west corner under 78 cfs.",
 ],
 did=[
  "A memo answering the three questions in order and showing the weir checks: 30.5 cfs at 0.70 ft against 41.5 cfs in Table D-2; with a working headwall the water surface is 2,858.88 and the clearance 0.32 ft; with a blocked headwall it is 2,859.36, 0.16 ft above the berm.",
 ],
 result=["20 of 20 (15 rubric criteria plus 5 closure checks) and 37 of 37 weight by my reader on the PDF twin."],
 verified=[
  "The reader on the docx and on the PDF twin (25,506 characters — the judge's view).",
  "A number audit over 472 tokens with 0 unexplainable; a record-side check 12/12.",
  "An independent recomputation of 21 quantities to 0.01.",
  "Twenty breakages through the official transform.py — all noticed.",
  "The official test.sh chain with a stub judge: all 15 indices present, candidate 25,816 characters, prompt 39,618 characters.",
 ],
 errors=[
  "My normaliser collapsed line breaks and failed a correct document; python-docx column widths are ignored unless columns[i].width is set; a storage-summary parser lost rows with a split elevation.",
  "Three checks (C0, C7, C14) could be satisfied by extraneous text — a quoted comment, the phrase “the accepted study” — and were narrowed.",
  "The mutation campaign started at 3 of 18 and showed that every fact is written two to four times: an honest mutation has to break all occurrences.",
 ],
 unverified="No judge score. The engineering conclusion is only as good as my reading of the corpus; the external normative check is limited — no regional flood registry was reachable, and the weir formula is Cetegen–Ahmed from the study itself.",
 gt="None.",
),

"engineers-estimate-check": dict(
 headline="Four line items are wrong by $26,783.70 in total; the bond comes out at $5,384,000, not $5,357,000.",
 task="Check an engineer's estimate against the drawings and specifications and write a memo to the client. Ten criteria, weight 46.",
 inputs="The estimate, the drawing set, the specification sections, and the client's correspondence.",
 ambiguities=[
  "Four item corrections: 2.35 removes 14 EA × $6,400 (−$89,600.00) because the 48 in manholes in that item are not in the schedule; 2.36 becomes 10 EA × $8,750.00 (+$87,500.00); 2.38 becomes 22.02 VF × $685.00 (+$15,083.70); 2.03 becomes 100 LF × $138.00 (+$13,800.00).",
  "Section 2 moves from $1,276,934.00 to $1,303,717.70; the construction subtotal from $4,856,565.75 to $4,883,349.45; the bond from $5,357,000 to $5,384,000 (from $5,383,349.45).",
  "Two flags carry no sum: the pool service ramp (6 in ABC against 2.47's “4 in AC over 6 in ABC”) and the Type G heads (item 2.30 keeps $58,200.00).",
 ],
 did=["A memo that shows each correction against the document that governs it, and keeps the two unsized flags separate from the priced corrections."],
 result=["10 of 10 criteria plus 4 closure checks, 46 of 46 weight by my reader."],
 verified=[
  "The reader on the document.",
  "A number audit: 126 tokens, 57 identifiers, 4 not traced (parts of dates and counting words) — declared, not hidden.",
  "Twelve breakages through the official transform.py — all noticed after two reader fixes.",
  "The official test.sh chain with a stub judge: complete.",
 ],
 errors=[
  "C3 searched “10 EA” anywhere in the row — and “depth ≤ 10 ft” matched. C10 counted a sentence about Type G heads as the ramp flag.",
  "After the fix the reader raised AttributeError on one mutation and the campaign counted that as “caught” — a false 12/12. The rule since then: a mutation counts only when the list of red criteria is non-empty.",
 ],
 unverified="No judge score. Whether the client accepts the bond rounding is a correspondence matter, not a measurement.",
 gt="None.",
),

"fill-compaction-acceptance": dict(
 headline="REJECTED: the test was made on a different borrow material, and the density that was specified cannot be shown for the fill that was placed.",
 task="Decide acceptance of fill compaction for a building pad and write the materials-acceptance memo. Twenty-eight criteria, weight 108.",
 inputs="The field density tests, the proctor curves (D698 and D1557), the borrow-source records, RFI 079, and the specification.",
 ambiguities=[
  "SF-26-0708 computes density on the D698 curve (118.6 pcf, Wexford Ridge), while the project's D1557 (128.4 pcf / 9.2%) was made on Larchwood Pit material — and the material actually placed came from the Block C stockpile, whose retest (RFI 079) was never performed.",
  "On the 128.4 pcf curve the density is at or above 95% everywhere, but the moisture contents of 6.1% and 5.8% are below the 8.2% required.",
  "Item 054 therefore stays open.",
 ],
 did=["A memo that states the determination, shows both curves side by side, and traces the material from borrow to stockpile to fill."],
 result=["28 of 28 criteria plus 4 closure checks, 108 of 108 weight by my reader."],
 verified=[
  "The reader on the document.",
  "Zero unexplainable numbers and dates.",
  "Ten breakages through the official transform.py — all noticed.",
 ],
 errors=[
  "My corpus extraction silently dropped 12 PDFs whose paths contain spaces — including the TAB calendar. It was rewritten as a Python walk. This is the same class of failure as elsewhere in this report: a parser that says nothing about what it did not read.",
 ],
 unverified="No judge score.",
 gt="None.",
),

"fire-solve-convergence": dict(
 headline="The plateau is burner pulsation at 0.87 Hz, there is no steady solution, and the run departs from the modelling standard in four named ways.",
 task="Write the disposition of the transient CFD solve (attempt 3) for a fire case: is the plateau a converged steady state, and does the run comply? Forty-three criteria, weight 129.",
 inputs="The solver logs, the case setup, the three-grid study, the modelling standard, and the validation record.",
 ambiguities=[
  "The plateau is burner pulsation: f = 0.87 Hz, T = 1.15 s, 0.41% agreement with the Mulshi record when compared against the unrounded 0.8660 Hz / 1.1547 s — not against the rounded values.",
  "There is no steady solution to report.",
  "Four nonconformities: radiation with 32 rays and one band against four directions and two bands with a 2.5 µm split; RAS k-ε against the required LES + WALE; the direction vector (cos240, sin240, 0) = (−0.500, −0.866, 0) points to 210°, not to wind from 240° (the correct vector is (0.866, 0.500, 0)); and a roughness of 0.03 m that is not in the met file.",
 ],
 did=[
  "The authorised block: adjustTimeStep yes, maxCo 0.9, maxDeltaT 0.01 s, adjustableRunTime, writeInterval 0.0461 s (T/25), endTime 31.10 s (8 + 20 × 1.1547005 = 31.09401).",
  "Attempt 3 ran on 11,214,862 cells, 5 cell zones and 13 patches; the three-grid study is fluid-only, with 1 cell zone and 6 patches per grid, covering D*/dx = 7.52 and Pope 0.84 but not the baffles, the cavity radiation or the connections.",
  "Cost: 4 h 28 m per case and 26 h 49 m for the matrix as lower bounds; attempt 3 took 6 h 41 m, 424.3 CPU-hours, 1.50×, 2 h 13 m longer.",
 ],
 result=["43 of 43 criteria and 129 of 129 weight by my reader on the PDF twin."],
 verified=[
  "Reader on the PDF twin; 316 distinguishable numbers, 0 unexplainable.",
  "An independent recomputation of 19 quantities with a second parser.",
  "Forty-two breakages — all noticed, each by its own criterion.",
  "The official test.sh chain with a stub judge: complete, no GRADER_FAILED.",
 ],
 errors=[
  "The first mutation run gave 27 of 39: some survivors were my own incomplete mutations (a fact stands two to five times), and some were reader holes — c12 found “2000” in a note near endTime, c23 accepted a permuted vector because it checked two numbers without order, c30/c34/c28/c29 passed on keywords scattered across the document, c9 read a standard's “typically 0.01 s” as the set value, c21 accepted “carried forward” 300 characters before EDC. All six were tightened.",
  "The first text had broken cross-references after section renumbering, “31.08 s” instead of “31.09 s”, and “0.0460 s — smaller than the standard permits” where the truth is “compliant, but not the largest”. Found by reading the rendered PDF, not the docx.",
 ],
 unverified="No judge score. The external normative check is limited to the standard text in the corpus.",
 gt="None.",
),

"fire-test-validation-memo": dict(
 headline="The run does not validate the design: the prediction is 13 minutes past a criterion whose own uncertainty is ±9 minutes.",
 task="Write Section 7 of the validation memo for a fire test: does the run validate the design? Forty-eight criteria, weight 208 — the largest single weight in the set.",
 inputs="The test report, the certified assembly, the client's report, the validation procedure, and the simulation predictions.",
 ambiguities=[
  "Not validated: E = +13 min against a criterion of 11.8 min, with u_val = ±9 min; the maximum passing prediction is 129.8 min.",
  "D = 118 min comes from the certified report; the client's 129 min is not accepted under §6 of the procedure.",
  "The run assembly equals the certificate assembly (50/205/305 mm, siliceous, 9-gauge 3.8 mm, 600 mm o.c., 25 mm) — so the comparison is like for like.",
 ],
 did=["A memo that states the determination, shows the uncertainty band, and explains why 129 min cannot replace 118 min."],
 result=["48 of 48 criteria and 208 of 208 weight by my reader; plus two structural checks."],
 verified=[
  "Reader; 116 numbers and units traced to sources, 0 unexplainable.",
  "Twelve breakages through verify.py — all noticed (M01 0.9952, M06 0.9519, M10 0.9423).",
  "The world against tests/world.md5: 50 files, 0 changed, 0 extra.",
  "Wiring: verify.py + grade.py with an all-pass stub, a blind stub and the reader stub gave 1.0 / 0.0 / 1.0 — the path is alive and the weights arrive.",
 ],
 errors=[
  "My error here was an expectation, not a number: I assumed a rubric task could be scored offline. It cannot. This task established the boundary that shaped the next fourteen.",
 ],
 unverified="No judge score — and with 208 weight this is the largest unmeasured quantity in the set. The docx was not rendered inside the verifier image; this rubric has no separate rendering, so the judge reads the document itself.",
 gt="None.",
),

"footing-settlement-verification": dict(
 headline="The settlement calculation stands on a footing elevation the drawings do not have — and the consolidation it omits is 5.4 in on its own.",
 task="Verify the settlement of Item 051 Block C and write the memo. Seventeen criteria, weight 62.",
 inputs="The geotechnical report, the foundation details, the settlement calculation CB-GEO-007, the survey, the monitoring rounds and the laboratory results.",
 ambiguities=[
  "CB-GEO-007 stands on footing El. 740.5, while Detail 3/S-201 Rev.4 gives El. 746.0 (5.5 ft higher), DBM Rev.2 §9 says “4,000 psf at El. 748 ± 2 ft”, and S-101 gives no elevation at all.",
  "Depth to mid-clay is 11.5 ft against 17.0 ft, and Δσ is 900 against 571 psf — so the calculation is held and the 0.90 in is not confirmed.",
  "Only immediate settlement is computed (Sheet 4 says “Not computed” for consolidation). By the record's own parameters: 0.28 × 216 / 1.92 × log10(2750/1850) = 5.42 in; total 6.32 in against a 1.0 in allowance.",
  "Art. 3.6.B is triggered: the load is already applied and no notice was given — the memo itself is the notice.",
  "Round 15 gives 0.61 in at MP-7, 61% of the allowance, and accelerating (0.03 → 0.07 in per round); the distribution omits the SER.",
  "The calculation cites “S-101 Rev.2 (09/12/2025)” while the revision block issues Rev.2 on 12/12/2025; LL 34–39 against laboratory 40 and 41; PI 15–19 against 21 on all 25 CL samples.",
 ],
 did=[
  "Disposition NOT VERIFIED, with the consolidation analysis and the elevation reconciliation assigned to the SER, indices to Kelbrook, monitoring transfer to Rowan Bay, and the hold point of 22/07/2026 moved.",
  "A side note to Item 052: the readiness letter cites A615, while Spec 03 20 00 Art 2.1 and S-201 forbid A615 and require A706.",
 ],
 result=["17 of 17 criteria plus 5 closure checks, 62 of 62 weight by my reader on the PDF twin."],
 verified=[
  "Reader on the PDF twin; 63 number tokens, 0 unexplainable; 52 of 52 citations checked against their source; 20 breakages — all noticed.",
  "The official test.sh chain with a stub judge: rendering, staging, 17 indices and a reward.json, with GRADER_FAILED empty.",
 ],
 errors=[
  "The first mutation run gave 2 of 15 — and that was true of the document, not of the reader: every fact stands two to six times. One genuine reader failure was found (c13 accepted “the Contractor is the party required to produce it” because the SER stood in another sentence); the reader now requires the obligation in one sentence and not the Contractor.",
  "cite_check.py first reported 44 of 52; all eight were my own typos inside quotations, not errors of the memo.",
 ],
 unverified="No judge score.",
 gt="None.",
),

"landscape-sheet-revision": dict(
 headline="Eleven of thirty trees cannot be promised until the planning department defines “significant change” — and the application window has already closed once.",
 task="Write the street-tree memo for a landscape sheet revision. Eighteen criteria, weight 77. This rubric has no separate rendering: the judge reads the document itself.",
 inputs="The landscape sheet, the tree survey, the town's tree ordinance, the TAB calendar and the attorney's letter.",
 ambiguities=[
  "Eleven of thirty trees cannot be promised until Comprehensive Planning issues its significant-change determination.",
  "The TAB application window for 18/11 closed on 28/10; the next meeting is 16/12 with applications due 25/11.",
  "Fifty-eight trees are in scope against 208 on the survey; the attorney's letter covers only L-2 and does not remove Condition 14.",
 ],
 did=["A memo that separates the eleven conditional trees from the nineteen that can be promised, with the procedural route and dates."],
 result=["18 of 18 criteria and 77 of 77 weight by my reader."],
 verified=[
  "Reader; 211 numbers, 0 unexplainable; 14 dates, all in the corpus (one declared as my own recommendation).",
  "Twelve breakages: eleven noticed, one equivalent (a change that no criterion can distinguish).",
 ],
 errors=[
  "Twelve PDFs with spaces in their paths were silently missing from my corpus extraction — including the TAB calendar that the memo's dates depend on. Fixed by a Python walk; the dates were then verified.",
 ],
 unverified="No judge score.",
 gt="None.",
),

"les-mesh-resolution": dict(
 headline="On the grid the report actually rests on, the wake is resolved at 29.9 — not 7.52 — and the acceptance survives only through the Pope criterion.",
 task="Write the note on the LES mesh-resolution basis for the same fire case. Fourteen criteria, weight 82.",
 inputs="The three-grid study, the case setup, the QA standard, the met data and the run logs.",
 ambiguities=[
  "The wake-resolution index on the fine grid of the three-grid study is 29.9 against a reported 7.52: D* = 3.74 m (the record says 3.76 — a last-step error, since 27.08^(2/5) = 3.742), the fire cell is 0.125 m (two snappy levels over a 0.500 m background; confirmed by a minimum volume of 0.001936 m³ → 0.1246 m and a zone volume of ≈2,454 m³ on all three grids), and the 5–10 band is missed by a factor of three.",
  "Acceptance rests on Pope alone (0.84 ≥ 0.80). §5 allows either criterion, so no escalation is needed and no decision on Marguerite's edge length is required; requiring both is the default only for AHJ or life-safety cases, which this phase is not.",
  "The refinement zone's radius and height are recorded nowhere — the volume fixes only πr²h — so the probe landing at 2.81 m inside the zone is an inference.",
  "The ambient behind D* is the reference atmosphere (1.204 kg/m³, 293.15 K), not the site (35–42 °C, maximum 41.8 °C in the met export), and D* at site conditions cannot be computed from the files: there is no pressure.",
  "Checklist item 4 stays open: QA §3(a) requires naming the SGS closure, and it is in no file (the only solver log is a steady k-ε bring-up; the only case export is rhoSimpleFoam + kOmegaSST from DWA). Closing it needs a case-setup memo — the Mixed-convection LES setup memo, SOW §4 deliverable 2 — not a new run.",
 ],
 did=["A note that separates what the record supports from what it implies, and states the one open item with the deliverable that closes it."],
 result=["14 of 14 criteria and 82 of 82 weight by my reader on the PDF twin."],
 verified=[
  "Reader on the PDF twin; 218 tokens, 0 unexplainable; an independent recomputation of 12 quantities in Decimal.",
  "Nineteen breakages — all noticed, plus one harmless control that was correctly not noticed.",
  "Render completeness: 0 of 105 paragraphs and cells lost.",
  "The official test.sh chain with a stub judge: 1.0 by construction; negative controls on the same path: 0.914634 (c0, weight 7) and 0.890244 (c3, weight 9).",
 ],
 errors=[
  "The number audit initially accepted an invented number as a date if a time appeared within 40 characters — a control with 7,300 went unnoticed; the window was narrowed to the token itself.",
  "Three mutations were marked incomplete after I rebuilt a table, so the pairs no longer applied.",
  "c12 stayed green when “8,760” was removed because “9,125” remained — but the rubric accepts either counter, so the rubric was right and my reader was too narrow.",
 ],
 unverified="No judge score. The docx was not rendered inside the verifier image; the PDF twin was produced by the official transform.py locally.",
 gt="None.",
),

"permission-to-operate-memo": dict(
 headline="Permission to operate cannot be issued on 08/04/2025: the only supply to the RTU is downstream of a recloser that the procedure holds open until PTO.",
 task="Decide whether permission to operate can be issued for PXA-2023-0629 (Corwyn) and write the memo. Thirteen criteria, weight 44; three of the weight points require work in the live applications.",
 inputs="The interconnection agreement, the witness-test record, TCS-02, the PTO hold log, the RTU power diagram, and the queue and equipment records.",
 ambiguities=[
  "The only supply to the RTU is PP-1 circuit 1 through TX-1 from SWBD-PV — downstream of the recloser that §6.1 holds open until PTO.",
  "The witness test closed the recloser from 08:10 to 15:35 on 08/07/2025; the 5.5 h UPS carried the RTU to about 21:05 that day.",
  "TCS-02 §5(c) judges points at the operator at the moment of issue, and the SOC confirmation of 08/07/2025 sits inside the test window; the PTO hold log says §5 has no intermediate state.",
 ],
 did=[
  "A memo that refuses the issue and gives the remedy: an instrument under §12.1 signed by the DER Program Office and Corwyn (Corwyn has no pre-PTO backfeed; Halbray does), then energization from ALN-072 by Distribution Operations under its own switching order with AD-C1…AD-C5 closed and inverter DC disconnects open, then a new SOC confirmation.",
  "Feasible before 08/04/2025 — 21 days, no study, no queue, no delivery, and Corwyn is not in DER-EQP-COMPL — but the record obliges no one to sign.",
 ],
 result=["11 of 11 criterion groups reachable without the live applications: 41 of 44 weight by my reader, with 29 of 29 quotes verified."],
 verified=[
  "Reader on both extractions (fitz and pypdf); 86 tokens, 0 unexplainable; 16 breakages — all noticed.",
  "The official test.sh chain with a stub judge: 1.0 on a synthetic db_diff; with an empty db_diff 0.931818; without db_diff the run fails (GRADER FAILED).",
 ],
 errors=[
  "Three checks searched raw text.lower() instead of the normalised text: everything was green on fitz and c6 was red on pypdf, which the judge uses, because justification produces double spaces and breaks “COM-\\nRTU”.",
  "The sentence splitter glued paragraphs when a full stop preceded a closing quote or when the next sentence began with a number, so a criterion was satisfied from the neighbouring paragraph and two mutations survived.",
  "c12 accepted “P.E.” anywhere in the document; it now requires the signature in one sentence with the DER Program Office.",
  "Six mutations were incomplete because facts stand two to five times.",
 ],
 unverified="No judge score. The work in the live applications was not performed for this task, so 3 of 44 weight is not reachable at all; 41/44 is the ceiling of what this package can show.",
 gt="None.",
),

"pre-application-capacity-response": dict(
 headline="3.0 MW cannot be confirmed — not because data is missing, but because all five records retract themselves.",
 task="Answer a pre-application capacity request for a feeder (ALN-108, Northline Renewables): is 3.0 MW available? Fourteen criteria, weight 39; four criteria are programmatic and read the live applications through a db_diff.",
 inputs="The hosting-capacity map, the planning memorandum, the queue report, the study backlog, the reliability agreement §3.7, and the request file.",
 ambiguities=[
  "The map of 15/05/2024 points to Distribution Planning and says it does not reflect the queue after publication; the edition is 425 days old at the letter date, and the request file holds one edition against a quarterly commitment — 4.7 cycles without reissue.",
  "The planning memo of 15/10/2024 gives 3.0 − 1.2 = 1.8 MW and requires reissue on any new queue movement; Cindermere (1.0 MW) joined on 06/02/2025, 158 days before the queue report, and no reissue exists; the memo is 272 days old.",
  "The queue of 14/07/2025 holds four active records on the feeder, 3.99 MW in total (Ravenford 1.1, Fenwyn 0.69, Grantwyck 1.2, Cindermere 1.0); none is on hold and none is in the NOIW log.",
  "RA-2025-07-01 §3.7 requires confirming the current feeder state before any external number, and there is no such confirmation; the study backlog (44 rows) has no row for PXA-2024-0231 although the queue holds it in system-impact study.",
 ],
 did=[
  "A letter that holds confirmation, makes any reliance conditional, keeps feasibility and upgrades pending, requires a full feeder study, offers a meeting (10 business days of availability, 3 business days to confirm) and requests a priority hosting-capacity refresh under §3.7.",
  "Issued by the DER Program Office on 14/07/2025 with the §12.3 caveat that a pre-application creates no queue position.",
  "Three readings of the same record are shown as illustrations, not as findings: 0.8 MW, 1.8 MW and −0.99 MW; the spread is 2.79 MW and the smallest shortfall is 1.2 MW on the most generous reading. The negative number is explicitly qualified: it does not mean the feeder is overloaded, because the published figure was never a reservation registry.",
 ],
 result=["35 of 39 weight (89.7%) against the document alone; 39 of 39 once the programmatic criteria are fed the real application dump — measured later in the live world, where the deal was closed, two comments written and the file uploaded."],
 verified=[
  "Reader on the PDF twin; 12 breakages — all noticed.",
  "Second path over the record: every queue, backlog and map figure re-read from the source files.",
  "The official test.sh chain with a stub judge: 1.0 with the real db_diff; without any db_diff the trial is not measured at all (GRADER FAILED: RENDERING FAILED).",
 ],
 errors=[
  "Criterion 13 first passed on the heading alone; narrowed to verb + object.",
  "The negative scan accepted any “no” in the sentence: an inserted “The 3 MW project is feasible … with no overload expected” passed. Negation is now searched near the claim (70 characters before, 30 after).",
  "Two mutations survived on case — the same error as T-16 and T-25.",
  "A check looked for a PDF file next to the text, while the judge's directory holds only a .pdf.txt; the criterion was red on a correct document.",
  "cite_check mixed paraphrase with quotation: 19 “failures” were sentences restated in my own words.",
 ],
 unverified="No judge score. The verifier image itself was not run in a container; the programmatic criteria were measured against the live applications, not inside the grader image.",
 gt="None.",
),

"shoring-design-verification": dict(
 headline="Item 048 is NOT VERIFIED: the design is built on three premises that are not on site, and its factor of safety reads 0.81 where 1.55 is required.",
 task="Verify the shoring design for Item 048 Block B and write the memo. Thirty criteria, weight 122; the judge reads a PDF, a comments file and a style file.",
 inputs="The shoring drawings 31-SH-B, the geotechnical report, S-101 Rev.4, the dewatering record, the pile capacity calculation CB-GEO-004, and the correspondence.",
 ambiguities=[
  "The Plant Room pit lies inside an already poured mat (S-101 Rev.4); the retained height is 8.5 ft (734.5 − 726.0). R2.3 is built on a free elevation of 750.0, 24 ft and hydrostatic pressure from 742.0 — none of which exists on site; R2.4–R2.7 take their demand from R2.3 and do not transfer.",
  "s_u = 1,400 psf is unconfirmed (GIR §6.3 gives 900–1,100); on these numbers toe factors of safety are 0.81 and 0.31 against the required 1.55.",
  "The anchor bond zone lies in clay (El. 736.95–728.74), not in the SW-GW layer.",
  "Base heave at 1.60 stands on a dewatering that no sealed project demonstrates (31-DW-A covers Block A only); without pumping it is 0.58, and the trigger at 727.0 gives 1.48 < 1.50.",
  "Dewatering by 11.5 ft gives 717.6 psf at the clay base (0 at the roof) on effective stress under an already built structure — 14.35× margin to σ′p — and no one has assessed the effect on piles, mats or slab (CB-GEO-004 counts the clay as resistance, Qs,upper = 85 kips).",
 ],
 did=["A memo with NOT VERIFIED, the arithmetic behind each item, and the two documents needed before work starts: a revised 31-SH-B (Kesterline via Rowan Bay) and a separately sealed Block B dewatering plan under 31 23 19 (Rowan Bay with the designer)."],
 result=["30 of 30 criteria and 122 of 122 weight by my reader on the PDF twin."],
 verified=[
  "Reader; a second recomputation of 34 internal ratios in Decimal with a different parser; 173 number tokens, 0 unexplainable.",
  "Thirty breakages — each noticed by its own criterion; one harmless control not noticed.",
  "The official test.sh chain with a stub judge: three renderings status 0, reward 1.0, GRADER_FAILED empty; negative controls M08 0.942623 (c6, weight 7) and M01 0.918033 (c0, weight 10).",
  "The official transform.py in a container on the isolated VM (LibreOffice 25.2.3.2 520, Python 3.13.18): the docx → PDF → text path works.",
 ],
 errors=[
  "The first campaign gave 24 of 30: six survivors were incomplete mutations (facts stand two to three times). After the mutator broke all occurrences and c11/c29 required the number next to its subject and the whole subtraction chain, the campaign gave 30 of 30.",
  "The stub judge answered all 30 indices while the grader asks in rendering groups (criterion 28 has its own group), and it ran the reader over the whole prompt including the criteria text, so five checks went red on the criterion wording. Fixed: the stub cuts the request by schema and reads only the body.",
  "Two factual errors in the memo, found by reading the record: Qs,B = 85 kips was actually Qs,upper (Qs,B = 75); and “both drains dry for all five days” was wrong — on 01/07/2026 there was seepage in Zone 1 at C-4 (K-6 was dry). A number audit cannot catch this: the numbers exist in the record; the error was in what they were attached to.",
 ],
 unverified="No judge score. The memo's conclusion rests on the corpus; the two documents that would close it do not exist yet in the record.",
 gt="None.",
),

"solar-supplemental-review": dict(
 headline="The earlier determination's outcome stands; its reason does not — Screen D passes on the record, and the study agreement is required for four other screens.",
 task="Decide the supplemental interconnection review for a solar project (Bramwick Commons, feeder ALN-214) and write the screening memo. Twenty-two criteria, weight 77.",
 inputs="The interconnection standard SRP-3, DI-01/DIS-01, the tariff, the meter (AMI) export, the feeder map, the queues, and the study backlog.",
 ambiguities=[
  "The memo of 25/06/2025 sent the application to a study agreement through a failure of Screen D: 1.8 MW against “a minimum of 1.1 MW”. On the record Screen D passes: the daytime minimum is 2,400 kW and the request is 1,800 kW.",
  "A study agreement is still required — under SRP-3 §2, because four other screens are inconclusive.",
  "Screen A has no threshold to apply: the word “penetration” does not occur in DIS-01 at all, and the tariff sets only a 500 kW scope.",
  "Screens B, C and E are inconclusive for want of records: no planning study for ALN-214 (a “Last Study Date” of 12/2023 is a date, not a study), no impedance data, no interrupting rating or fault contribution, and no certified reverse power for the Larkspur Ridge transformer.",
 ],
 did=[
  "Recomputed Screen D from the AMI export: 01/07/2024–30/06/2025, 15-minute steps, 35,040 intervals without gaps, 8,760 evaluated (10:00–15:45), no exclusions because no outage, transfer or switching record exists on ALN-214.",
  "Minimum 2,400 kW at 11:30 on 12/02/2025; the next values are 2,418 and 2,433; only three intervals in the year fall below 2,500 kW, and no day has a daily minimum at or below 1,800 kW.",
  "The 1,100 kW figure is the absolute night minimum (03:45 on 23/03/2025), which §4 excludes by name. The memo's window and step also differ from the export (“24/06/2024–24/06/2025”, “sixty minutes”).",
 ],
 result=["22 of 22 criteria and 77 of 77 weight by my reader on the PDF twin."],
 verified=[
  "Reader on the PDF twin; a second path over 69 checks (raw XLSX XML with hand-decoded Excel serial dates, pdftotext for the standards, document.xml for the older memo).",
  "Render completeness: 117 of 117 paragraphs and cells over 20 characters.",
  "28 numbers with recorded provenance, 0 unexplainable; a control with three invented numbers catches 3 of 3.",
  "Twenty-one breakages — all noticed; two harmless controls not noticed.",
  "The official test.sh chain: reward 1.0 with a stub judge, and the official rendering text is character-identical to mine. Negative controls: m01 0.870130 (c0, weight 10), m18 0.961039, m20 0.974026, and no file at all 0.0.",
 ],
 errors=[
  "I wrote that there is no existing DER on the feeder. The DER registry and the holds registry have no feeder column at all: their silence about ALN-214 is blindness of the key, not evidence. No checker caught this — reading the registry did.",
  "ALN-214 has two rows in the map (capacity and the pre-application note); my first draft had one.",
  "The number audit accepted an invented number as a date if a time stood within 40 characters.",
  "Three mutations were incomplete after I rebuilt the Screen D table.",
  "c12 stayed green when “8,760” was removed because “9,125” remained; the rubric accepts either counter — the rubric was right.",
 ],
 unverified="No judge score. The live applications were not touched, because no criterion in this task reads db_diff.",
 gt="None. The AMI export is project data, not a reference answer.",
),

"solar-witness-test-package": dict(
 headline="The release list is empty: no array in the batch has a signed disposition — and three of the five arrays are not in the current inverter list at all.",
 task="Assemble the municipal witness-test package for the arrays in the batch: disposition status, test plan, and what must be in the file before a test. Thirty-four criteria, weight 67; four criteria are programmatic and read the live applications and the file store.",
 inputs="Six checklists, the inverter eligibility list CEL-2025-Q2 (34 models, 6 PCS; the prior Q4 had 28 and 3), ENG-PRC-014, IEEE 1547.1, DIS-01 Rev 4, the tracking record, and the notice log.",
 ambiguities=[
  "The batch has five arrays: Cravenwood High (Solmery SM-215K-3P, carried in CEL row 5), Darnwick Elementary (Arvexa PV-750, not in the current edition and in no edition in the record), Holcott Library (Selvix SV-720, only in Q4), Lockmere Middle (SV-720 as a site replacement; the checklist still shows TE-180K) and Marden Falls WRF (Solmery SM-245K-3P, row 6).",
  "No in-scope array has a signed Standards Engineering disposition: Cravenwood 6.4 “pending signature — Section 8”; Darnwick “Reviewed by Pending”; Holcott counter-signature “pending”; Lockmere Sections 7 and 9 blank; Marden “Pending”.",
  "ENG-PRC-014 §4.3 does not allow PTO without either a signed witness disposition or a signed waiver with a §4.1 definition against the current edition — and no waiver was issued, refused or recommended.",
  "Cravenwood has a second door: all of Section 5 is open and 5.5 says “PTO withheld until live telemetry confirmed by SOC (TCS-02 §5)”.",
  "Tresbay Community Center withdrew on 09/07/2025 (deal 45), but its checklist still looks active and the ICQ notice log has no entry.",
 ],
 did=[
  "A package with an empty release list, a per-array disposition status, and a witness-test plan for the three arrays outside the current list: protective-function trip tests, anti-islanding, and ride-through verifications under ENG-PRC-014 §4.2 with IEEE 1547.1 and DIS-01 Rev 4 §6 — performed by the customer or its commissioning agent, witnessed by an Alleniom witness engineer, with the checklist, certificate and scheduling correspondence in the file before the test (§4.3).",
  "Two observations recorded as observations: DIS-01 Rev 4 §6 is “Monitoring and Control” and contains no ride-through verifications, so the §4.2 reference leads into a void (the quote is reproduced as it stands); and the CEL change summary says “2 inverter models removed” without naming them — by set difference they are Halbrick Solar HB-175 and Selvix SV-720, and 28 − 2 + 8 = 34, which is an inference of the reader, not a record.",
 ],
 result=["30 of 30 rendered criteria (63 of 63 weight) by my reader, plus 4 of 4 programmatic criteria through the official code_verifier on real application dumps (score 1.0, status valid)."],
 verified=[
  "Reader on the PDF twin; 93 table cells all found in the judge's text; 162 number tokens, 0 unexplainable.",
  "Twenty-eight breakages — 27 caught by their own criterion and one harmless control not caught.",
  "The four programmatic criteria measured against the live OpenProject and Nextcloud dumps, not against the document.",
 ],
 errors=[
  "My table reader opened the original docx instead of the file the mutation campaign had written: the first campaign gave 9 of 26, and seventeen “survivors” were instrument blindness. This is the third time in this set that a surviving mutation meant a blind instrument.",
  "“Five” stood twice in the document (§2 introduction and conclusion); mutating one occurrence survived.",
  "Tests were listed once for three arrays while the criteria are per array.",
  "A “what must be in the file” check accepted any non-empty cell — “TBD” passed.",
  "The live world died and had to be rebuilt, failing in five different ways (broken symlinks, Postgres permissions, an existing clone directory, Nextcloud autoload, a redis password policy).",
 ],
 unverified="No judge score. The world is a native build, not the image: ports differ, Collabora is absent, the OpenProject demo data was not purged (which is why the deal gets id 45), and only the two snapshot hooks the criteria need were run. The docx was not rendered inside the verifier image. My reader implements 12 of the 30 rendered criteria as explicit semantic checks; the rest are structural (a section or a table cell exists), which is exactly why its 30/30 is not a score.",
 gt="None.",
),
}
