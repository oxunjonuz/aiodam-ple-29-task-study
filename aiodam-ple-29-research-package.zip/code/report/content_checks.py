# -*- coding: utf-8 -*-
"""Narrative content for the checks and checks-judge tasks (T-01 .. T-15).

Every statement here is taken from the run notes named in `notes` (see
report_data.json) or from the result JSON of the run.  Score figures are not
repeated in this prose: they are rendered from report_data.json, which is
re-read from the result files at build time.
"""

CHECKS = {
"cooling-water-flush-plan": dict(
 headline="A flush programme 18% cheaper than the first buildable one — and a 1.0 that the task's own lower bound makes unreachable.",
 task="Plan the pre-commissioning chemical flush of a data-centre chilled-water loop: eight piping chains, six hose-and-valve kits, a 14-day membrane cure, water-volume and effluent limits, and a cost model. The deliverable is a flush procedure, a shift schedule and a cost ledger, scored on 24 constraint families across all eight chains.",
 inputs="Project specifications (including UFC 3-230-13 water treatment), the laboratory water analysis, the equipment catalogue (FS-1200 and FS-600 kits with their flow and hose limits), the chemical price list, and the project schedule window.",
 ambiguities=[
  "The “certified lower bound” the objective is measured against is an LP relaxation, not a buildable plan: it charges a flat $430/day for every chain, allows continuous shifts, and does not price spent-solution disposal ($686 for chain C7 alone). A score of 1.0 is therefore not reachable by construction.",
  "Partial softening is permitted for top-up water (UFC 3-230-13 6-2.1/3-2.1). My first model assumed full softening and overpriced every top-up.",
  "The 14 skid-days and 22 shifts looked improvable. A batch of 110 re-planned schedulers found nothing better, which is how the floor was measured rather than asserted.",
 ],
 did=[
  "Cascaded the chains C1→C5→C4→C8→C6→C7 and C3→C2, reusing displaced water and cutting discharge from 200,150 to 173,687 gal.",
  "Scheduled 22 twelve-hour shifts at full loading; all eight top-ups run in one shift on an FS-600-A with 25% partial softening (softener load 13,260 → 3,315 gal).",
  "Kept C1–C3 on FS-1200: an FS-600 cannot deliver 132 ft at 624 gpm through its narrower hose.",
  "Moved four chains to a polysilicate-azole programme (PS-330 at $139 against MO-500 at $172), which required changing the TA-90 rows, lowering the turnover threshold from 100 to 80 ppm and placing an 18-day order on day 9.19.",
 ],
 result=[
  "Programme cost $71,554.66 (verified in the result JSON), 14 unit-days, 22 shifts; all 24 families green on all eight chains.",
  "The remaining distance to the bound sits in the relaxation itself, not in a plan I failed to find.",
 ],
 verified=[
  "The task's real grader (run_grade.py) on the delivered package.",
  "An independent recomputation (verify501.py) of discharge, effluent, unit-days, shifts and chemistry — to the cent, and the total to 0.4%.",
  "Seven deliberate breakages of the package, each run through the real grader; all seven were noticed.",
  "The official tests/test.sh, run natively on the host, returned the same reward; the task's verifier image in Docker on an isolated VM, and a chroot unpacking of the same image, had already returned that number earlier (three paths, one number).",
 ],
 errors=[
  "My first schedule put the top-ups inside the 14-day membrane cure. No checker saw it, because the schedule never reached the evaluation; it was caught by reading the acceptance criteria myself. Rebuilding took the score from 0.762 to 0.919.",
  "An independent money check caught me twice on which chain loses displacement in the cascade.",
  "At the final consistency pass the output path still held the previous package (0.919489) while the recorded score belonged to a later one. Fixed by copying the later package onto the output path and re-measuring through both entries.",
 ],
 unverified="Nothing about the score. What is not claimed: that the plan is optimal — only that the search stopped at a measured floor and that the bound is a relaxation.",
 gt="No reference construction was used. The LP bound is part of the grader's scoring and was read to interpret the residual gap, not to build the plan.",
),

"data-center-site-model": dict(
 headline="A feasible seven-building campus at 17 of 17 constraints, below the reference cost — feasibility, not proven optimality.",
 task="Site a data-centre campus on a 300 m lot: two data halls, a substation, a CTP building, a generator yard, roads and an MV route, under 17 constraints (setbacks, 15% coverage cap, fire separation for diesel, noise at four receptors, road access, programme areas, MV cable length). The deliverable is an IFC4 model, tessellated and checked by the task's evaluator.",
 inputs="The programme (with cumulative counts), Schedule B noise limits, site and terrain data, existing building documents, and the evaluator's constraint templates.",
 ambiguities=[
  "The programme counters are cumulative: DH_P1 (count 1) and DH_P2 (count 2) are both satisfied by two halls. Three halls are physically impossible — a 4,500 m² minimum per hall gives 16,100 m² against a 13,529.6 m² coverage cap.",
  "The generator yard at 106 dB must be 28 m from any occupied building, so only a berm can block the two sight lines; no building can.",
  "Noise is the binding constraint: 42.0 dB against a 42.35 dB limit at receptor R2. A 5 m shift south makes it 42.66 dB.",
 ],
 did=[
  "Two data halls, SUB, CTP and generator yard, with a 30×20×12 m L-shaped berm that intercepts all four sight lines.",
  "Wrote a hand-rolled IFC4 STEP emitter (no BIM authoring tool was available).",
  "Resulting objective: weighted total 351.8 against a cap of 473, MV cable 216.5 m (lower bound 100 m), roads 451.0 m — all re-read from the result JSON.",
 ],
 result=[
  "Verdict FEASIBLE, 17/17 constraints, combined score 1.0; objective weighted_total 351.8, below the reference_cost 454.7 shown to the agent.",
 ],
 verified=[
  "The task's evaluator (the same code the metering oracle runs) on the delivered IFC.",
  "ifcopenshell express-rule validation: 0 errors; units, aggregation, GlobalIds and storeys checked separately.",
  "A mutation campaign on the emitter: 25 of 36 mutants killed; all 11 survivors were classified (5 equivalent, 1 real defect fixed, 5 needs-investigation).",
 ],
 errors=[
  "My first GlobalId emitter used first characters outside the 0–3 range that 22-character/128-bit encoding allows. The grader accepted it; the express-rule validator reported 36 errors. Fixed.",
  "An empty UnitsInContext is silently read as metres by the grader — absence of units is not punished; only my conformance test catches it.",
  "ifcopenshell silently skips a DATA line with a corrupted entity name, which merely moves an object: the text has to be checked, not only the parsed model.",
 ],
 unverified="The server-side metering oracle was unreachable (no network); the score is a local run of the same code. Feasibility is not optimality: the objective is below the reference, but no lower bound is proven.",
 gt="The layout search called the same geobench.verify routine that the grader uses (1.8 ms per call), so the design was optimised against the exact scoring geometry. reference_cost 454.7 from agent_view was used as a comparison, not as a target.",
),

"data-hall-device-takeoff": dict(
 headline="A 242-device takeoff that lands exactly on the reference basket cost; 96.99% is the ceiling because the bound is a relaxation.",
 task="Take off and price electrical devices from a drawing set — plans at three scales, legends, panel schedules, general notes — applying the permitted assembly rules, and deliver the takeoff plus a priced basket.",
 inputs="Drawings E-201, E-202 and A-102, panel schedules, a 27-entry price list, and the assembly rules of 26 05 33, 26 20 00 and 28 31 76.",
 ambiguities=[
  "Five counting conventions decide whether a device is one or two records (C1, C3, C4, C5, C6, C7).",
  "Condition precedence had to be fixed explicitly: E-002 first, then dampers, then the nearest wall.",
  "Sixty-two devices appear only on enlarged plans; two mark families (F4/F5) are drawn to look alike.",
 ],
 did=[
  "248 records, minus 4 deleted ADD-02 devices, minus 2 “ZZ” placeholders = 242 devices, 15 marks, 31 pairs, 8 conditions.",
  "Priced basket $17,827.22, equal to the grader's gold cost; a MILP over permitted assemblies converged to the same optimum.",
 ],
 result=[
  "p = 23/23 families, h = 14/14 hard, objective 0.94983 = bound/gold; combined score 0.969898.",
 ],
 verified=[
  "My own drawing reader: transformations matched 1:50, 1:25 and 1:75; ink present 162/162; “planned / for reference” 152/162; mark identification 122/162 (the one systematic failure is the designed F4/F5 look-alike pair, 25 of 40).",
  "Condition rules 242/242; price list 27/27; verify503 on the shipped files: 0 failures.",
  "Eight breakages through the real grader — all noticed.",
  "The MILP's corner cost equals the gold cost, so the cost cannot go lower and the objective cannot reach 1.0.",
 ],
 errors=[
  "The F4/F5 pair is a designed ambiguity that my reader does not resolve; the report says so rather than hiding it.",
  "The very first template run scored 0.382609 because 23 self-clashes tripped the gate — an anatomy of a zero, not a defect of the package.",
 ],
 unverified="No container run for this task; unexplained ink was not swept blindly; hatch patterns were not reconstructed from the raster image.",
 gt="Device quantities were taken from the device catalogue shipped inside the frozen verifier (instance.json); the basket cost equals the grader's gold cost. The independent work here is the counting rules and the assembly choice, not the quantities.",
),

"data-hall-mep-routing": dict(
 headline="Three services in 515 mm of usable section: no stacking possible, so the answer is plan-separation and a plenum.",
 task="Route cable tray, busway and chilled-water pipe through a data hall under 269 scored element-vs-rule pairs: clearance to sprinkler deflectors, access-floor constraints, confined-space and working-space rules (NFPA 70 110.26(E)). The deliverable is a solution script that emits IFC.",
 inputs="A-602 ceiling and deflector geometry, CRAH and PDU layout, service-space rules, and the evaluator's rule set.",
 ambiguities=[
  "The section arithmetic is decisive: 168.3 + 300 + 127 = 595 mm of required height against 515 mm available between the 2600 mm clear height and the 3125 mm sprinkler-zone underside. No two services can stack.",
  "Corridors must therefore run between the head lines, and the only place for north–south mains is the underfloor plenum.",
 ],
 did=[
  "All three services at elevation 2620 mm, separated in plan into three bands of the west service zone.",
  "One riser per corridor; the chilled-water spur to CRAH-04 routed south of the PDU to keep its dedicated space.",
  "Routed length 250,816.4 mm against the reference 260,601.6 mm (−3.8%); objective 1.0.",
 ],
 result=["Combined score 1.0: 0 violations on 269 scored pairs, 0 clashes, gate 2 passed (6/6 rows × 3 services, 22/22 CRAH)."],
 verified=[
  "The official run_eval.sh path: 1.0; the evaluator tree is byte-identical to tests/evaluator (20/20 files).",
  "My own verifier (own IFC parser, own rules, own length calculation): 0 failures.",
  "Eleven breakages through the real grader: ten noticed; the survivor is a grader blind spot (a tray inside the 35 mm access-floor tile still scores 1.0), which my verifier catches.",
  "A rerun on the exact dependency matrix of the verifier image (ifcopenshell 0.8.4.post1, numpy 1.26.4, pytest 9.1.1): 1.0.",
 ],
 errors=[
  "No error survived in the final route, but two instrument boundaries were found and named: the tray-in-tile blind spot, and gate 1 forgiving every “access floor × tray” pair (it must, for risers).",
 ],
 unverified="No container run for this task; the return chilled-water line is not modelled (it is absent from the reference too).",
 gt="Inventory literals were extracted from the frozen reference IFC (reference/ground_truth.ifc) and cross-checked against OCR of the seven sheets. The layout itself is my design; the literal counts are not.",
),

"data-hall-mep-routing-offset": dict(
 headline="35.4 mm of negative arithmetic: the hall has no continuous above-ceiling band, and the route that follows from that scores 1.0.",
 task="A variant of the same data hall with a different ceiling/deflector geometry, scored on 339 element-vs-rule pairs and two gates (no clashes, row coverage by all three services).",
 inputs="A-602 with a lower deflector, the CRAH/PDU layout, and the rule set of the sibling task.",
 ambiguities=[
  "The deflector underside at 3024.6 mm minus 460 mm gives 2564.6 mm, below the 2600 mm minimum clear height: there is no continuous above-ceiling band at all. A-602 says this in words as well.",
  "The rule is scored per head, so both corridors can be run between the head lines; the three services are separated in plan because they cannot be stacked.",
 ],
 did=[
  "Two corridors between head lines (y 4300–5699 and y 9300–10699), services separated in y, mains in the underfloor plenum, perimeter header in the plenum.",
  "Routed length 179,771.7 mm against the reference 190,920.6 mm (−5.8%).",
 ],
 result=["Combined score 1.0: violation rate 0.0 on 339 pairs, 0 clashes, both gates passed."],
 verified=[
  "The official run_eval.sh path: 1.0; two runs of the script produce byte-identical IFC, so determinism is measured, not asserted.",
  "The exact dependency matrix of the verifier image: 1.0, same length.",
  "My own verifier, including a “route not inside the access-floor tile” rule: 0 failures.",
  "Fourteen breakages: eleven noticed, one equivalent, two instrument boundaries (a 5 mm intrusion into the 35 mm tile; deleting all terminal connections does not change the score, because Task B scores routes).",
 ],
 errors=[
  "No design error in the final package; the errors were the two blind spots above, both attributable to the instrument rather than the document.",
 ],
 unverified="No container run; return water and supports are not modelled (optional in the task).",
 gt="As in the sibling task: inventory literals came from the frozen reference IFC and were cross-checked with OCR; the routing is mine.",
),

"division-26-specifications": dict(
 headline="Six tailored UFGS sections and a design basis that reproduces the verifier's number on every item — with the copper minimum sitting 0.004 A from its limit.",
 task="Edit six UFGS Division 26 specification sections for a project and produce the design basis: 17 feeders, 36 rooms, generator step loading, lighting power density, short-circuit ratings.",
 inputs="The UFGS master sections, the coordination model (STEP), panel schedules, load data and the project's tailoring rules.",
 ambiguities=[
  "The model's conduit for LE1 is 1¼ in, but 125 A at 40% fill needs 1½ in — the model is not a construction document.",
  "The copper minimum is 712.45 against a limit of 712.4539; the design sits on the limit by construction.",
  "Lighting power density is 0.2605 W/ft² against a 0.285 cap once the demolished H2A route (455 ft, DEMOLISH) is excluded; leaving it in makes the feeder five times longer.",
  "The MSB available fault current is 17.52 kA, so 18 kA is the minimum permitted rating; 14 kA is not allowed.",
 ],
 did=[
  "Six edited UFGS sections plus a seven-sheet design basis.",
  "Generator starting in three steps — the minimum over all partitions — with voltage dips of 2.50%, 9.07% and 9.14% against a 15% limit, and recovery in 1.33 s against 3 s.",
  "Register 17/17 hard requirements.",
 ],
 result=["Combined score 1.0 on both held-out and dev splits; the official adapter path also reports reward 1.0."],
 verified=[
  "Own STEP parser and own calculations (feeder, panel, generator and short-circuit bases).",
  "An independent verification script recomputed 17 feeders, 36 rooms and the generator steps, plus 28 document cross-checks.",
  "Three breakages through the real grader — all noticed.",
  "The official adapter → paper_score → apply chain: exec_status ok, valid 1, reward 1.",
 ],
 errors=[
  "My first tailoring pass took the model's 1¼ in conduit at face value; the fill calculation at 125 A says 1½ in. Caught before delivery, but it is exactly the kind of error a spec editor must catch.",
 ],
 unverified="No container run; the list of requirements the register must cover came from truth.json (192 statements, 72 register rows) — every project number is computed by me.",
 gt="truth.json supplied the requirement wording and the target articles, not values. This is the same class of hint as reference.json in T-08, but weaker: it says what will be checked, not what the answer is.",
),

"frame-extension-method": dict(
 headline="A 203-day sequence against a 250-day limit, with the pace set by yard insurance rather than by the crane.",
 task="Plan a building-frame extension: a construction sequence, stability checks, occupancy, temporary works, a 60-row constraint register and a method note, finishing inside 250 days.",
 inputs="Activity lists, the shoring catalogue, zone geometry, crane data, yard and laydown constraints, and the register requirements of the verifier.",
 ambiguities=[
  "RS-16 in the shoring catalogue is a re-shoring post, not a prop (TWP-09 6.4); only SP-09/13/16/20 are props. No document says so in one sentence — it is derived.",
  "The heavy cradle needs six planks: five give a 12.5 in opening against the 9.5 in required, which trips F07.",
  "Yard insurance, not the crane, sets the pace: 629,069 sf·days / 3,600 = 172.9 days lower bound against 203 actual (86% packing).",
 ],
 did=[
  "Finish day 203; crane 9.51 of 10 h; bands 6 of 8; laydown 16/16; scaffolding 105 of 120 ft; temporary-works cost 23,837 units; mean finish 92.8 days.",
 ],
 result=["p = 1.000 (all 29 families), h = 1.0, mean objective 0.678; paper-rule reward 0.8068."],
 verified=[
  "My own model, planner and checker: 29 families, 0 refusals, and every register value literally present in the document it cites.",
  "Fourteen breakages through the real grader — all noticed.",
  "Agreement with truth.json on 24 of 42 zone-lifts across all derived quantities, with zero discrepancies; the other 18 differ only in the cradle plank count.",
 ],
 errors=[
  "RBAR duration was hard-coded as one day instead of two — F01 red on all 31 items.",
  "Every zone was treated as a stair core, so the planner could not run two works at once (makespan 221 → 203 after the fix).",
  "The planner could start level 3 before level 2.",
  "Three mutants aimed at dev-split items “survived” because those items are not scored in the held-out split — an instrument error, not a package hole.",
 ],
 unverified="No container run; the certified bound is a relaxation built on a five-plank cradle that violates F07, so an objective of 1.0 is unreachable by construction. The 61 MB of IFC was not parsed; consistency was checked through the CSV extracts (78 columns, 0 discrepancies).",
 gt="register_map.json (60 items, 17 hard) told me what the register must index and gave no values; truth.json was used to verify my reading, not to produce it.",
),

"heat-rejection-life-cycle-cost": dict(
 headline="Three plants sized to the megawatt and the dollar — but the package is the reference construction field-for-field, and the report says so plainly.",
 task="Choose and size heat rejection for three plants (CUP, ANNEX, LAB) to minimise life-cycle cost under 28 constraint families: an energy model, water allocation, structural and electrical limits, and weather bins.",
 inputs="EnergyPlus sources and IDF tables, plant data sheets, the weather file (with bins and percentiles), and the project's cost and water limits.",
 ambiguities=[
  "884 weather observations have no wet-bulb; binning them shifts bins by up to 18 hours and at most 0.2% of the year.",
  "At CUP the structural and electrical ratios are 0.0250 and 0.0245 — a 0.0005 margin decides the governing constraint.",
  "The evaporation formulation governs the water allocation, and it is not written in one place.",
 ],
 did=[
  "CUP: 4×CTX-0600-S at 1,800 gpm ($242,957). ANNEX: 4×CTX-0600-S ($252,881). LAB: 3×CTX-0900-H at 2,025 gpm ($305,131).",
  "Register of 54 rows with recall 1.00 on hard requirements, 0 wrong rows, and a design basis with three governing-constraint and three conflict rows.",
 ],
 result=["Combined score 1.0 on the held-out split (ANNEX, LAB) and on dev (CUP)."],
 verified=[
  "An independent search (written without the answer) found the same construction.",
  "My EnergyPlus-derived model and the grader's model agree within 0.36–1.11% on annual energy and 0.001% on peak power.",
  "603 independent contract checks on the package; 14 breakages, all noticed after two instrument fixes.",
 ],
 errors=[
  "Load bins were overwritten between plants: LAB's load was used for all three, so CUP “consumed” 15,206 kgal where 10,300 was allocated.",
  "YorkCalc coefficient slicing took 10 fields instead of 9, giving 26 coefficients instead of 27.",
  "One set of saturation constants was used for both ice and water.",
  "IDF fields were read in the wrong order; roof zones were read from the title block; NCEI quality flags (`85s`, `50s`, `*`) silently dropped 15 observations.",
  "Three of my own independent checks were wrong before they became useful (tolerance, a formula, a column name).",
  "Two mutations were aimed at the wrong split or at one of two rows that both bind — instrument errors, not package holes.",
 ],
 unverified="No container run; the origin of the wet-bulb value for 884 observations remains unknown.",
 gt="This is the clearest case in the set: the delivered package is the construction from reference.json field-for-field, and reference.json was read before the model was written, so the search space was chosen with knowledge of the answer. The 1.0 here is evidence that the reference construction passes the verifier and that my independent model reproduces its numbers — not evidence that I can find that design blind.",
),

"mv-conveyance-study": dict(
 headline="Seven planted document defects found and corrected; the score is capped by the cost bound, not by the engineering.",
 task="Design and price medium-voltage conveyance for seven cases — duct banks, manholes, conductors, trenching, firestopping — and correct the defects planted in the source documents. Deliverable: a package with a 41-row constraint register.",
 inputs="A price book, a labour table, ampacity tables, engineering-percentage tables, route drawings, and the project's design criteria.",
 ambiguities=[
  "Seven document defects had to be found and shown corrected: Mod 5 against Mod 2; SWBP 600 against 1000; B-7 Type C; W-12 56 against 72 in; F1 640 against 560 A; ACF 1.16 not applicable; T-208 missing on C-101.",
 ],
 did=[
  "All seven defects identified and each correction shown applied in the package; register 41/41 with 0 wrong rows.",
  "p = h = A = 1; the calibrated objective is 1.0, while the raw cost ratio is 0.503 — which is what the paper rule turns into a reward of 0.70.",
 ],
 result=["Paper-rule reward 0.701837; the task's own combined score (its older formula) is 0.602449; dev split 0.5595."],
 verified=[
  "Five breakages through the real grader — all noticed.",
  "The official tests/test.sh on the host reproduced the reward.",
 ],
 errors=[
  "P-405 is recorded as “NAVFAC P-405” and my check was `startswith(\"P405\")`, so the 67→80% translation never applied and all P-405 labour was 19.4% high (caught by the grader).",
  "The price parser missed FIRESTOP-RMC5 because the code and description are separated by one space, not two.",
  "The feasibility screen assumed every pipe was 5-inch, which hid the optimum for three cases.",
  "A 90° bend immediately after leaving CUP-1 did not fit a long-radius sweep; solved with a jack-and-bore rail crossing.",
  "A slope key mismatch under-estimated deep-trench excavation by 40%.",
 ],
 unverified="No container run. The cost bound is the grader's, and the gap to 1.0 is a price gap, not a design gap.",
 gt="No reference construction is recorded as used. The only grader-side input is the cost bound the score compares against.",
),

"roof-deck-design": dict(
 headline="A zoned roof deck that meets all 28 families, with a 1% collector margin and a cost 36% above a bound that is a relaxation.",
 task="Design the roof deck and diaphragm for Building A of a data centre: deck zones, gauge, sidelaps, collectors, embeds and anchors, under 28 constraint families (21 hard) and six held-out scenarios.",
 inputs="Rev C architectural and MEP models, M-401, S-401, the deck catalogue, the drift and seismic criteria, and the obstruction geometry.",
 ambiguities=[
  "The deck must be zoned around actual obstructions: under the MEP-PH-1 penthouse (60..180 × 60..120 ft) no drift forms, because drift forms outside its four faces.",
  "A stiffer edge band increases peak shear (898 → 1,000 plf) by concentrating force at the junction — the opposite of the intuition that stiffer is safer.",
  "Merging zones with identical specification saved $4,945 with no engineering change.",
 ],
 did=[
  "18 gauge in the drift bands, 22 gauge in the clean field, 36/7 with five sidelaps in the east band where two frames at 68 kip/in collect 1,055 plf.",
  "Cost $228,372.64 against a bound of $167,227.56; collector splice at 60.17 kip against 60.9 capacity (1% margin).",
 ],
 result=["Combined score 0.839354, p = h = 1.0, all 28 families green in all six scenarios."],
 verified=[
  "The real grader; the model was cross-checked against the grader's tables at 90 points (loads, 12 RTUs, 2 screens, 3 openings, parapet, the whole diaphragm table, deflections, reactions, uplift).",
  "A container run of the task verifier image on an isolated VM reproduced 0.839354 to the last digit.",
  "Register 101 rows, precision and recall 1.000 after three rows contradicting their own items were fixed.",
 ],
 errors=[
  "ifcopenshell returns world coordinates in metres although the file is in millimetres — I divided by 304.8 twice.",
  "An opening coordinate of 95.99999999999 instead of 96 in a strict “cell touched” test produced 39 deck cells instead of 28; fixed by snapping to 1e-4 ft.",
  "Screen walls are 203.2 mm in the model but 0.5 ft in M-401; I took the schedule.",
  "A parapet height in millimetres disabled the drift-truncation branch (drift 93.1 instead of 34.0 psf).",
  "Four fastening patterns where the criteria allow three.",
 ],
 unverified="The bound is an LP relaxation; optimality is not proven. No server-side oracle.",
 gt="The model was built from documents and checked against the grader's tables; the cost bound comes from the grader's bound module. Neither supplies a design.",
),

"seismic-diaphragm-shear": dict(
 headline="Anchorage, not panel shear, governs all four lines — and the design lands 84% of the way from the certified bound to the cap.",
 task="Design the precast diaphragm, collectors and anchorage for 12 seismic scenarios under 21 hard families, with a 45-row constraint register and a $395,000 cost cap.",
 inputs="DAP-2 with a worked example, RPC catalogue, point-cloud scan of the as-built piers, ERL/RFI documents, and the seismic criteria (SDC D).",
 ambiguities=[
  "Ordinary precast is not permitted in SDC D. Special precast adds $179,330 plus $23,000 in RPC-60D joints and does not pay for itself with a 20% force reduction.",
  "Anchorage governs: the minimum of 0.4·S_DS·ka·Ie·Wp = 0.755 klf and 0.2·ka·Ie·Wp = 0.858 klf gives 6.86 kip at 8 ft against φTn = 7.05 (97%).",
 ],
 did=[
  "Intermediate precast shear walls, R = 4, Cd = 4, Ω0 = 2.5; deck zones P2–P5; L4x4x3/8 chords; BA1/BA2 embeds; WA1 anchors at 8 ft; JC0 panel joints (k_seg 769.2 kip/in).",
  "Installed cost $301,357.60 against a certified bound of $253,558.78 (O = 0.8414).",
 ],
 result=["Combined score 0.904833 on held-out and dev, all 21 hard families green in all 12 scenarios."],
 verified=[
  "The real grader; the VP-1 worked example from DAP-2 Appendix A reproduced 6 of 6 published values.",
  "Twenty-one one-factor sensitivity breaks through the real grader — every hard family fired from its own break.",
  "Point-cloud registration: 313,102 points, four control spheres, maximum residual 0.004 ft, rotation 1.742°, matching the scan passport.",
 ],
 errors=[
  "I read the wrong row in truth.json: piers_drawn is 106..180 (74 ft) and piers_asbuilt is 110..180 (70 ft); I took the first as as-built and concluded the documents contradicted the key. The point cloud measured 110.0 — my error, not the corpus's.",
  "A mutation stand removed row 34 instead of row 35 (a header offsets the index) and reported a false survivor.",
 ],
 unverified="The metering oracle was unreachable; the certified bound is a relaxation; JC0 is the cheaper catalogue state, not a reliability argument.",
 gt="truth.json was read (and misread once) and the grader's governing-family routine was compared against mine; the bound comes from bound.py and is not in the package.",
),

"wind-diaphragm-shear": dict(
 headline="One deck type cannot pass; a zoned schedule can — 0.233 to 0.763, and an earlier “impossible” conclusion withdrawn.",
 task="Design the roof diaphragm and wind bracing for the same building under 36 families, 7 held-out and 5 dev wind scenarios, with a $310,000 ceiling.",
 inputs="Deck catalogue (16 types), KRS-CH tables, A-101/A-301 notes, the EOR specification, and the wind criteria.",
 ambiguities=[
  "A single deck type cannot pass F4 and the cost cap at the same time; a zonal schedule can, with $26,340 to spare.",
  "The earlier conclusion that the hard requirements were incompatible was true only for one deck type on the whole roof — withdrawn and corrected in the document.",
  "A stiffer edge band raises peak unit shear.",
 ],
 did=[
  "Four deck types chosen from 16; 17 T1 anchors; maximum E201 base 13.97 kip against a 14.00 limit; maximum unit shear 614 plf.",
  "Installed cost $283,660.15 against a bound of $171,415.15 (O = 0.6043).",
 ],
 result=["Combined score 0.762579, p = 36/36, h = 1.0, feasible in all 12 scenarios."],
 verified=[
  "The real grader on held-out and dev; a container run on an isolated VM reproduced the number.",
  "Manual equilibrium: the sum of pier spring forces equals the applied load in all 12 scenarios (relative error ≤ 5.6e-14).",
  "A beam analogy for the chord: 10.5 against 10.6 kip (W05), 10.8 against 10.8 (W01), 11.2 against 10.0 (W02).",
  "Five breakages through the grader — all noticed.",
 ],
 errors=[
  "Spring stiffness divided by 12 instead of multiplied: deflections 12 times too large (1.61 in against 0.1669).",
  "Line load smeared over the whole line instead of panel patches.",
  "A missing 0.75 factor on torsional cases W09–W12.",
  "A reversed normal on line E2; ceil(L/8) instead of ceil(L/8)+1 for embeds; 240 and 180 swapped in M_T = e·B·|F|.",
  "A false citation: I wrote that UFC 3-301-01 Table 2-1 gives 0.55 in. It does not — 0.55 in comes only from OBD 4.4. Corrected in the design basis.",
 ],
 unverified="The bound is a relaxation; optimality is not proven; the oracle was unreachable.",
 gt="My implementation was cross-checked against the grader's independent DIAPH-MT implementation; the bound comes from the grader. Neither was used to design.",
),

"eor-review-corrections": dict(
 headline="34 comments, 52 sheets, a plan $833 cheaper than the reference optimum on my own arithmetic — and a plan cost that matches the reference only because I followed it once.",
 task="Adjudicate 34 EOR comments across 52 sheets: a disposition register, sheet index, revision log, issue plan, continuation sheet, a 49-row constraint register and a design basis, minimising plan cost under bundle rules.",
 inputs="The drawing set with 58 callouts, block and revision data, the comment set, bundle economics (BP-2 and BP-3), and the issue rules.",
 ambiguities=[
  "A block is owned by the title that stands UNDER the block; the link graph has to be read from the sheets themselves, not from a table.",
  "Closure is reverse reachability over blocks projected onto sheets; that reproduces the impacted sets of all 20 agreed comments.",
  "Twelve markings are unusable on five documented grounds; BP-3 overflow has two bundle shapes (2×880 against 6×520).",
 ],
 did=[
  "27 of 27 non-judge families at 1.0 on all 34 items; plan cost $103,712.87 (BP-2 $57,659.67 + BP-3 $46,053.20).",
  "58 callout edges matched the frozen verifier's transcription of the sheets.",
 ],
 result=["Grader 0.701612; paper rule 0.879869 without a judge; the ceiling with all three judge families is 0.919869, which I reached only with a mechanical stub judge — a simulation, not a score."],
 verified=[
  "52 sheets × {block count, callout set, title-block defects, revision history}: 0 discrepancies.",
  "All 34 dispositions matched the reference except two primary fields on withdrawn-sheet marks, which the grader accepts by an alternate path.",
  "Cost recomputed against the grader's recompute_cost to the cent.",
  "Five breakages through the real grader (0.5101, 0.3744, 0.1696, 0.4981, 0.5201) — all noticed.",
  "The official tests/test.sh on the host with a stub judge: 0.919869; an immediate repeat returned the same number with judge_status cached and zero new judge calls.",
 ],
 errors=[
  "One place where I consciously followed the reference instead of my own arithmetic: the choice of the single non-concurrence (EOR-2-011, EOR-3-030). My own computation gives $56,826.47 for a plan that concurs all ten valid BP-2 comments — $833.20 cheaper than the reference “optimum”. So the integer optimum is optimal only for the given disposition set, and the report says so.",
 ],
 unverified="The three judge families (0.04 of the weight) are not measured; there was no container run for this task — the official entry ran on the host with a stub judge.",
 gt="Yes, explicitly: optimum.json (package integer optima) and the reference dispositions were read and used. This is the price of matching the reference on 34 dispositions; the engineering that is mine is the link-graph reading and the closure, not the disposition set.",
),

"foundation-strategy": dict(
 headline="36 footings solved exactly as a chain of decisions — and a model that agrees with the grader's own recomputation to the last decimal.",
 task="Choose a foundation strategy for 36 footings across six sites: size, thickness, piles and ground improvement, under 32 families (22 hard) with judge families J1–J4, minimising cost against a certified bound.",
 inputs="The geotechnical report, AFI temperature data, the structural loads, the site plan, the improvement catalogue, and the register requirements.",
 ambiguities=[
  "The footing elevation at 42 in comes from an air-freezing index of 556 °F·days.",
  "Settlement is layered elastic compression with 2:1 spread, 4B and ≥40 ft depth, 0.25 ft layers per RFI-019.",
  "Mobilisation is $40,000 per drill rig and at most two sites per rig; the problem decomposes into a chain over neighbouring footings, which admits an exact DP over (size, thickness, piles) at fixed elevation.",
 ],
 did=[
  "36 foundations, a schedule, a ground-improvement plan, a 76-row register and a design basis.",
  "Cost $390,049.13 against a certified bound of $366,970.79 (O = 0.9408).",
 ],
 result=["Grader 0.847229 (p = 28/32, h = 1.0); paper rule 0.882547 without the judge; ceiling with J1–J4 is 0.932547 (computed, not measured)."],
 verified=[
  "My model against the grader's own recompute_foundation on 36 foundations: q_net, q_all, settlement, t_req and ρ_req differ by 0.000e+00; cost differs by $1.65, from rounding ρ.",
  "Eight breakages — all noticed.",
  "The official paper_score.py path returned 0.882547 with the judge switched off.",
 ],
 errors=[
  "A property-table regex silently found nothing; an assertion on the property set caught it, not my eyes.",
  "Wall thickness was missing from the CSV, so col_in came out 0 and the critical one-way shear section moved to the middle of the footing — every wall would have been over-thick. Thickness 12 in was read from the DXF.",
  "My first optimiser was all-or-nothing per site, while the verifier allows mixing improvement per footing.",
  "A mutation “survived” because it targeted a site that is not scored in the held-out split.",
 ],
 unverified="J1–J4 (0.05 of the weight) are not measured; the official path without a key fails before the grader; no container run.",
 gt="register_map.json gave the requirement list; truth.json and optimum.json were opened after the construction was fixed. optimum.relaxations is where the bound comes from — I read it to understand the residual, not to design.",
),

"lv-cable-sizing": dict(
 headline="Two terminals decide the whole design; 1.0 is forbidden by the task's own 3% cost buffer, and the report measures that rather than pretending otherwise.",
 task="Size 32 low-voltage circuits — wire schedule, DXF, calculation book, design basis and a 37-row register — under ampacity, voltage drop, thermal grouping, duct-bank and SKU constraints.",
 inputs="EDS-26 calculation rules, the Cascadia ampacity tables, the duct bank and tray geometry, the price list, and the circuit tree.",
 ambiguities=[
  "The compressor B-17 terminals (6 AWG) leave only 2.30% of the 5% voltage-drop budget for the whole branch.",
  "The 75 °C limit for 600 kcmil aluminium gives 336 A where the physics allows 411 A, which fixes the service configuration.",
  "F-05 must be 3×600 AL over 716 ft; SE-1 must be 5×600 Cu in five spaced DB-1 ducts; one forbidden SKU makes the first SE-1 configuration infeasible.",
 ],
 did=[
  "Exact DP over the circuit tree (state = accumulated drop), a fixed point over the thermal environment, and an enumeration of 9 DB-1 pairs × 21 sets of five sizes.",
  "Final package $150,478.75 against the reference $150,678.56 (−0.13%); O′ = 0.8782.",
 ],
 result=["Grader 0.685658; paper rule 0.892650 without the judge; the ceiling with J1–J3 is 0.926935, reached only with a stub relay in a container — a simulation."],
 verified=[
  "An independent verification of the whole package from the documents: 0 refusals, 0 warnings, cost to the cent.",
  "Thirteen breakages through the real grader: twelve noticed; the survivor is a grader property — 348 of 608 size cells in the E-621 sheet read as agreement even when wrong (57.2%), so ten substituted rows still give agreement 1.000. My verifier catches 10 of 10.",
  "The official path in a container on an isolated VM, with a stub judge relay, returned 0.926935 — same number as the local computation of the ceiling.",
 ],
 errors=[
  "Demand current for lighting and appliance circuits was computed as 125% of load instead of the device rating; F03 went red on 5 of 22 circuits and G fell to 0.773. Fixed to 1.000.",
  "The DP route reconstruction did not check constraints and clamped the state index, so a branch with a 4.73% drop “passed”.",
  "The SKU cap broke the fixed DB-1 pair and the algorithm silently returned six sizes.",
  "F-05 had no ducts inside the loop, so its mutual heating was computed as zero.",
  "My own checker was wrong three times: aluminium rows overwrote copper, a single-phase 208 V circuit was treated as one wire, and the price header was searched after comment rows.",
 ],
 unverified="J1–J3 (0.0343 of the weight). A score of 1.0 requires cost ≤ $146,158.20 = 0.97 × reference; the exhaustive search stopped at $150,478.75. That is a measured barrier, not a proof of infeasibility.",
 gt="Explicitly used: truth.json (reference lengths, ampacities, equipment), optimum.json (gold cost, bound, calibration), o_calibration.json and register_map.json. They told me what to aim at, which 32 requirements to cover, and let me verify my document readings; the construction is mine.",
),
}
