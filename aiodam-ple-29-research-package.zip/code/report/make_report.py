#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Generate the 29-task PLE report as HTML and PDF.

Pipeline: report_data.json (verified data) + content_*.py (narrative) ->
matplotlib figures -> HTML -> Chromium print-to-PDF (cover + body merged) ->
TOC page numbers re-inserted -> final PDF.
"""
import base64
import io
import json
import os
import re
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle

from content_checks import CHECKS
from content_rubric import RUBRIC
import content_front as F

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = json.load(open(os.path.join(HERE, "report_data.json")))
OUT_HTML = os.path.join(HERE, "PLE_29_Task_Report_AIODAM.html")
OUT_PDF = "/work/ple-solve/out/PLE_29_Task_Report_AIODAM.pdf"
COVER_HTML = os.path.join(HERE, "_cover.html")
BODY_HTML = os.path.join(HERE, "_body.html")
COVER_PDF = os.path.join(HERE, "_cover.pdf")
BODY_PDF = os.path.join(HERE, "_body.pdf")

BLUE = "#1b3a5c"
ACCENT = "#2b6cb0"
AMBER = "#b7791f"
GREEN = "#2f6f4f"
RED = "#b03a2e"
GREY = "#8a8a8a"

TASKS = {t["id"]: t for t in DATA["tasks"]}
AGG = DATA["aggregates"]


def fmt(x, n=6):
    if x is None:
        return "—"
    return f"{x:.{n}f}"


def esc(s):
    return (str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))


def img_tag(path):
    with open(path, "rb") as f:
        b64 = base64.b64encode(f.read()).decode()
    return f'<img src="data:image/png;base64,{b64}" style="width:100%;">'


# ---------------------------------------------------------------- figures
def fig_scores(path):
    rows = [t for t in DATA["tasks"] if t["type"] in ("checks", "checks-judge")]
    rows.sort(key=lambda t: t["reward"])
    names = [t["id"] for t in rows]
    r = [t["reward"] for t in rows]
    g = [t["grader"] for t in rows]
    colors = [AMBER if t["type"] == "checks-judge" else ACCENT for t in rows]
    fig, ax = plt.subplots(figsize=(7.2, 4.4), dpi=220)
    y = range(len(rows))
    ax.barh(list(y), r, color=colors, height=0.62, zorder=2)
    ax.scatter(g, list(y), marker="|", s=140, color="#111111", zorder=3, linewidths=1.6,
               label="task grader score G")
    for yi, (rv, gv) in enumerate(zip(r, g)):
        ax.text(rv + 0.008, yi, f"{rv:.4f}", va="center", fontsize=6.6, color="#222")
    ax.axvline(1.0, color="#555", lw=0.8, ls=(0, (3, 2)), zorder=1)
    ax.set_yticks(list(y))
    ax.set_yticklabels(names, fontsize=6.6)
    ax.set_xlim(0, 1.06)
    ax.set_xlabel("final reward R (bar) and grader score G (tick)", fontsize=7)
    ax.tick_params(axis="x", labelsize=6.5)
    ax.grid(axis="x", color="#e3e3e3", lw=0.6, zorder=0)
    from matplotlib.patches import Patch
    ax.legend(handles=[Patch(color=ACCENT, label="checks"), Patch(color=AMBER, label="checks-judge"),
                       plt.Line2D([], [], color="#111", marker="|", ls="", markersize=8, label="grader score G")],
              fontsize=6.3, loc="lower right", frameon=False)
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    fig.tight_layout()
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)


SECOND = {  # 1 = independent recomputation recorded, 0.5 = decisive facts re-read, 0 = not recorded
    "cooling-water-flush-plan": 1, "data-center-site-model": 1, "data-hall-device-takeoff": 1,
    "data-hall-mep-routing": 1, "data-hall-mep-routing-offset": 1, "division-26-specifications": 1,
    "frame-extension-method": 1, "heat-rejection-life-cycle-cost": 1, "mv-conveyance-study": 1,
    "roof-deck-design": 1, "seismic-diaphragm-shear": 1, "wind-diaphragm-shear": 1,
    "eor-review-corrections": 1, "foundation-strategy": 1, "lv-cable-sizing": 1,
    "backfeed-energization-reply": 0.5, "emergency-spillway-check": 1, "engineers-estimate-check": 0,
    "fill-compaction-acceptance": 0, "fire-solve-convergence": 1, "fire-test-validation-memo": 0,
    "footing-settlement-verification": 1, "landscape-sheet-revision": 0, "les-mesh-resolution": 1,
    "permission-to-operate-memo": 0.5, "pre-application-capacity-response": 1,
    "shoring-design-verification": 1, "solar-supplemental-review": 1, "solar-witness-test-package": 0,
}
BREAK = {  # recorded breakage/sensitivity campaign
    "data-center-site-model": 1, "roof-deck-design": 0,
}


def fig_matrix(path):
    rows = DATA["tasks"]
    cols = ["machine\nscore", "official\nentry", "container\nrun", "second\npath", "breakage\ncampaign", "judge\nscore"]
    vals = []
    for t in rows:
        machine = 1 if t["type"] in ("checks", "checks-judge") else None
        official = None
        if t["type"] in ("checks", "checks-judge"):
            official = 1 if t.get("official_kind") in ("host", "host-stub") else 0
        cont = None if t["type"] == "rubric" else (1 if t.get("container") else 0)
        second = SECOND.get(t["id"], 0)
        brk = BREAK.get(t["id"], 1 if t["type"] == "rubric" else 1)
        judge = 0
        vals.append([machine, official, cont, second, brk, judge])
    fig, ax = plt.subplots(figsize=(7.2, 6.4), dpi=220)
    n, m = len(rows), len(cols)
    cmap = {1: "#2f6f4f", 0.5: "#c9a227", 0: "#b03a2e", None: "#dcdcdc"}
    for i in range(n):
        for j in range(m):
            v = vals[i][j]
            ax.add_patch(Rectangle((j, n - 1 - i), 0.94, 0.86, color=cmap[v], lw=0))
    ax.set_xlim(-0.02, m)
    ax.set_ylim(-0.1, n)
    ax.set_xticks([j + 0.47 for j in range(m)])
    ax.set_xticklabels(cols, fontsize=6.4)
    ax.xaxis.tick_top()
    ax.set_yticks([n - 1 - i + 0.43 for i in range(n)])
    ax.set_yticklabels([f"T-{t['num']:02d} {t['id']}" for t in rows], fontsize=6.2)
    ax.tick_params(length=0)
    for s in ax.spines.values():
        s.set_visible(False)
    from matplotlib.patches import Patch
    ax.legend(handles=[Patch(color=cmap[1], label="measured / recorded"),
                       Patch(color=cmap[0.5], label="partial (decisive facts re-read)"),
                       Patch(color=cmap[0], label="not done / not measured"),
                       Patch(color=cmap[None], label="not applicable")],
              fontsize=6.2, ncol=2, loc="upper center", bbox_to_anchor=(0.5, -0.015), frameon=False)
    fig.tight_layout()
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)


def fig_judge(path):
    ids = ["eor-review-corrections", "foundation-strategy", "lv-cable-sizing"]
    labels = ["eor-review", "foundation", "lv-cable"]
    grader = [TASKS[i]["grader"] for i in ids]
    rule = [TASKS[i]["reward"] for i in ids]
    ceil = [TASKS[i]["ceiling"] for i in ids]
    stub = [0.919868641551773, None, 0.926935336209825]
    x = range(len(ids))
    w = 0.2
    fig, ax = plt.subplots(figsize=(7.2, 2.9), dpi=220)
    ax.bar([i - 1.5 * w for i in x], grader, width=w, color="#7a8fa6", label="grader G (measured)")
    ax.bar([i - 0.5 * w for i in x], rule, width=w, color=ACCENT, label="paper rule R (measured, judge off)")
    ax.bar([i + 0.5 * w for i in x], ceil, width=w, color="#cdd7e2", edgecolor="#7a8fa6",
           label="ceiling if all judge families pass (computed)")
    ax.bar([i + 1.5 * w for i in x], [s if s else 0 for s in stub], width=w, color=AMBER,
           label="stub-judge simulation (not a score)")
    for i, (c, s) in enumerate(zip(ceil, stub)):
        ax.text(i + 0.5 * w, c + 0.01, f"{c:.4f}", ha="center", fontsize=6.2)
        if s:
            ax.text(i + 1.5 * w, s + 0.01, f"{s:.4f}", ha="center", fontsize=6.2)
    ax.set_xticks(list(x))
    ax.set_xticklabels(labels, fontsize=7)
    ax.set_ylim(0.6, 1.0)
    ax.tick_params(axis="y", labelsize=6.5)
    ax.set_ylabel("score", fontsize=7)
    ax.grid(axis="y", color="#e6e6e6", lw=0.6)
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.legend(fontsize=6.0, ncol=2, frameon=False, loc="upper center", bbox_to_anchor=(0.5, -0.18))
    fig.tight_layout()
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)


PIPELINE_SVG = """
<svg viewBox="0 0 760 250" xmlns="http://www.w3.org/2000/svg" style="width:100%;height:auto;">
  <defs><marker id="a" markerWidth="8" markerHeight="8" refX="6" refY="3" orient="auto">
    <path d="M0,0 L6,3 L0,6 z" fill="#44546a"/></marker></defs>
  <g font-family="Liberation Sans" font-size="11">
   <rect x="8" y="40" width="120" height="52" rx="4" fill="#eef3f8" stroke="#7a8fa6"/>
   <text x="68" y="62" text-anchor="middle" font-weight="bold">corpus</text>
   <text x="68" y="78" text-anchor="middle" font-size="9">drawings, specs, data</text>
   <rect x="168" y="40" width="130" height="52" rx="4" fill="#eef3f8" stroke="#7a8fa6"/>
   <text x="233" y="62" text-anchor="middle" font-weight="bold">my model / calculation</text>
   <text x="233" y="78" text-anchor="middle" font-size="9">own code, second parser</text>
   <rect x="338" y="40" width="120" height="52" rx="4" fill="#eef3f8" stroke="#7a8fa6"/>
   <text x="398" y="62" text-anchor="middle" font-weight="bold">deliverable</text>
   <text x="398" y="78" text-anchor="middle" font-size="9">zip / py / docx / ifc</text>
   <rect x="498" y="40" width="110" height="52" rx="4" fill="#e8f1ea" stroke="#2f6f4f"/>
   <text x="553" y="62" text-anchor="middle" font-weight="bold">task grader</text>
   <text x="553" y="78" text-anchor="middle" font-size="9">G — measured</text>
   <rect x="648" y="40" width="104" height="52" rx="4" fill="#e8f1ea" stroke="#2f6f4f"/>
   <text x="700" y="62" text-anchor="middle" font-weight="bold">paper rule</text>
   <text x="700" y="78" text-anchor="middle" font-size="9">R — measured</text>
   <line x1="128" y1="66" x2="162" y2="66" stroke="#44546a" marker-end="url(#a)"/>
   <line x1="298" y1="66" x2="332" y2="66" stroke="#44546a" marker-end="url(#a)"/>
   <line x1="458" y1="66" x2="492" y2="66" stroke="#44546a" marker-end="url(#a)"/>
   <line x1="608" y1="66" x2="642" y2="66" stroke="#44546a" marker-end="url(#a)"/>
   <rect x="498" y="130" width="254" height="46" rx="4" fill="#f7efe3" stroke="#b7791f"/>
   <text x="625" y="150" text-anchor="middle" font-weight="bold">LLM judge (rubric / J families)</text>
   <text x="625" y="166" text-anchor="middle" font-size="9">J — NOT measured anywhere in this run</text>
   <line x1="553" y1="92" x2="553" y2="126" stroke="#b7791f" stroke-dasharray="4 3" marker-end="url(#a)"/>
   <text x="563" y="112" font-size="9" fill="#8a5a12">only for 14 rubric tasks + 3&#215;J</text>
   <rect x="168" y="130" width="290" height="46" rx="4" fill="#eef3f8" stroke="#7a8fa6"/>
   <text x="313" y="150" text-anchor="middle" font-weight="bold">independent checks</text>
   <text x="313" y="166" text-anchor="middle" font-size="9">second implementation · breakage campaign · number audit</text>
   <line x1="398" y1="92" x2="398" y2="126" stroke="#44546a" stroke-dasharray="4 3" marker-end="url(#a)"/>
   <text x="8" y="215" font-size="9" fill="#555">Green = a number produced by the task&#8217;s own code. Amber = a simulation used only to prove wiring. Nothing on this diagram is a judgment of engineering quality.</text>
  </g>
</svg>
"""


# ---------------------------------------------------------------- HTML
def score_box(t):
    rows = []
    if t["type"] in ("checks", "checks-judge"):
        rows.append(("<b>Final reward (R)</b> — paper rule 0.4p + 0.6[h=1]O′", f"<b>{fmt(t['reward'])}</b> · measured"))
        rows.append(("Task grader (G) — combined score", f"{fmt(t['grader'])} · measured"))
        if t.get("official_kind") == "host":
            rows.append(("Official entry — tests/test.sh on this host", f"{fmt(t.get('official_reward'))} · measured"))
        elif t.get("official_kind") == "host-stub":
            rows.append(("Official entry — tests/test.sh on host, stub judge", f"{fmt(t.get('official_reward'))} · simulation, not a judge score"))
        elif t.get("official_kind") == "blocked-key":
            rows.append(("Official entry — tests/test.sh", "fails before the grader: JUDGE_BASE_URL is not set"))
        if t.get("container"):
            rows.append(("Container", esc(t["container"])))
        if t.get("ceiling"):
            rows.append((esc(t.get("ceiling_note", "ceiling with judge")), f"{fmt(t['ceiling'])} · computed, not measured"))
        rows.append(("Judge", "no LLM judge in this task" if t["type"] == "checks" else "J families not measured"))
    else:
        rows.append(("<b>Judge score</b>", "<b>NOT MEASURED</b> — no judge endpoint or key"))
        rows.append(("Criteria · weight", f"{t['criteria']} criteria · {t['criteria_weight']:.0f} weight points"))
        rows.append(("My criteria reader (not a score)", esc(t["reader_text"])))
        rows.append(("Breakage campaign", esc(t["mutations"])))
        if t.get("programmatic"):
            rows.append(("Programmatic criteria", f"{t['programmatic']} read the live applications"))
    rows.append(("File", f"<span class='mono'>{esc(t['deliverable'])}</span> · {t['size_measured']:,} B · sha256 <span class='mono'>{t['sha256'][:16]}…</span>"))
    body = "".join(f"<tr><td class='k'>{k}</td><td>{v}</td></tr>" for k, v in rows)
    return f"<table class='score'>{body}</table>"


def task_html(t):
    c = CHECKS.get(t["id"]) or RUBRIC.get(t["id"])
    part = {"checks": "Part A · checks", "checks-judge": "Part B · checks-judge", "rubric": "Part C · rubric"}[t["type"]]
    out = [f"<section class='task' id='t-{t['num']:02d}'>",
           "<div class='task-head'>",
           f"<div class='kicker'>{part} · {esc(t['discipline'])}</div>",
           f"<h1>T-{t['num']:02d} — {esc(t['id'])}</h1>",
           f"<p class='headline'>{esc(c['headline'])}</p>",
           score_box(t),
           "</div>",
           f"<p class='lab'>Task and inputs</p><p>{esc(c['task'])}</p><p>{esc(c['inputs'])}</p>",
           "<p class='lab'>What was ambiguous or broken</p><ul>"]
    out += [f"<li>{esc(x)}</li>" for x in c["ambiguities"]]
    out += ["</ul><p class='lab'>What I did and what came out</p><ul>"]
    out += [f"<li>{esc(x)}</li>" for x in c["did"]]
    out += [f"<li>{esc(x)}</li>" for x in c["result"]]
    out += ["</ul><p class='lab'>How it was verified</p><ul>"]
    out += [f"<li>{esc(x)}</li>" for x in c["verified"]]
    out += ["</ul><p class='lab'>My mistakes in this task</p><ul>"]
    out += [f"<li>{esc(x)}</li>" for x in c["errors"]]
    out += ["</ul>", f"<p class='lab'>What remains unverified</p><p>{esc(c['unverified'])}</p>",
            f"<p class='lab'>Use of reference or grader material</p><p>{esc(c['gt'])}</p>",
            "</section>"]
    return "".join(out)


GENERIC = {"submission.zip", "solution.py", "model.ifc"}


def rel_name(t):
    path = t["deliverable"]
    base = os.path.basename(path)
    if base not in GENERIC:
        return base
    parts = path.split("/")
    if len(parts) >= 4 and parts[-2] in ("stage2", "pkg"):
        return "/".join(parts[-3:])
    return "/".join(parts[-2:])


def summary_table():
    head = ("<tr><th>#</th><th>Task</th><th>Type</th><th>Deliverable</th>"
            "<th class='num'>G<br>grader</th><th class='num'>R<br>final</th>"
            "<th>Judge</th><th>Status</th></tr>")
    rows = []
    for t in DATA["tasks"]:
        base = rel_name(t)
        size = f"{t['size_measured']:,} B"
        if t["type"] in ("checks", "checks-judge"):
            g = fmt(t["grader"], 4)
            r = fmt(t["reward"], 4)
            judge = "—" if t["type"] == "checks" else "not run"
            status = "measured" if t["type"] == "checks" else "measured without judge"
        else:
            g = r = "—"
            judge = "not run"
            status = "no score"
        rows.append(
            f"<tr><td class='c'>T-{t['num']:02d}</td><td><b>{esc(t['id'])}</b></td>"
            f"<td class='c'>{t['type']}</td><td class='mono small'>{esc(base)}<br>{size}</td>"
            f"<td class='num'>{g}</td><td class='num'>{r}</td><td class='c'>{judge}</td>"
            f"<td class='small'>{status}</td></tr>")
    return f"<table class='summary'><colgroup><col style='width:5.5%'><col style='width:22%'><col style='width:8%'><col style='width:26%'><col style='width:6.5%'><col style='width:6.5%'><col style='width:7%'><col style='width:18.5%'></colgroup><thead>{head}</thead><tbody>{''.join(rows)}</tbody></table>"


def front_sections():
    out = []
    out.append("<section class='chapter'>")
    out.append("<h1>What this report is</h1>")
    out += [f"<p>{esc(p)}</p>" for p in F.WHAT]
    out.append("</section>")

    out.append("<section class='chapter'>")
    out.append("<h1>What PLE is</h1>")
    out += [f"<p>{esc(p)}</p>" for p in F.PLE]
    out.append("</section>")

    out.append("<section class='chapter'>")
    out.append("<h1>All 29 tasks at a glance</h1>")
    out.append(f"<p>Twenty-nine tasks: {AGG['n_checks']} checks, {AGG['n_checks_judge']} checks-judge, {AGG['n_rubric']} rubric. "
               f"Fifteen have a measured machine score; five of those are exactly 1.000; the mean final reward is {fmt(AGG['mean_reward'], 3)} "
               f"and the mean grader score is {fmt(AGG['mean_grader'], 3)}. Fourteen have a hashed document and no score, because the judge was never available.</p>")
    out.append(summary_table())
    out.append("<p class='legend'><b>G</b> — the task’s own deterministic grader. <b>R</b> — the dataset’s final scoring rule, 0.4p + 0.6[h=1]O′, applied by the task’s paper_score.py; both are machine scores. "
               "<b>Judge</b> — the LLM judge that scores rubric criteria; it was never run, here or anywhere else in this report. "
               "For rubric tasks neither G nor R exists: their score is a weighted pass rate over criteria, and only the judge can produce it. "
               "Each row is described in its own section; Appendix A and B carry the file paths and hashes.</p>")
    out.append(f"<figure>{img_tag(os.path.join(HERE, 'fig_scores.png'))}<figcaption><b>Figure 1.</b> The fifteen machine-measured tasks, sorted by final reward. Bars are R; ticks are the task grader score G. The gap between a bar and its tick is where the paper rule and the objective rescaling act; for the three amber tasks the gap also includes the judge families, which are not measured.</figcaption></figure>")
    out.append(f"<figure>{img_tag(os.path.join(HERE, 'fig_matrix.png'))}<figcaption><b>Figure 2.</b> What was actually measured, task by task. Green means a recorded measurement, amber a partial one (decisive facts re-read rather than recomputed), red not done, grey not applicable. The last column is the point of the report: no task has a judge score.</figcaption></figure>")
    out.append("</section>")

    out.append("<section class='chapter'>")
    out.append("<h1>How the work was done</h1>")
    for title, paras in F.HOW:
        out.append(f"<h2>{esc(title)}</h2>")
        out += [f"<p>{esc(p)}</p>" for p in paras]
    out.append(f"<figure class='diagram'>{PIPELINE_SVG}<figcaption><b>Figure 3.</b> The measurement chain. The task’s own code produces G and R; the judge would produce J but was never reachable; my independent checks sit beside the chain and never turn into a score.</figcaption></figure>")
    out.append("</section>")

    out.append("<section class='chapter'>")
    out.append("<h1>How to read a score</h1>")
    out.append("<p>Four kinds of number appear in this report, and they are not interchangeable. The table fixes the vocabulary used everywhere else.</p>")
    out.append("<table class='tax'><colgroup><col style='width:6%'><col style='width:16%'><col style='width:46%'><col style='width:13%'><col style='width:19%'></colgroup>"
               "<thead><tr><th>Sym</th><th>What it is</th><th>How it is produced</th><th>Producer</th><th>Measured here?</th></tr></thead><tbody>"
               + "".join(f"<tr><td class='c'><b>{s}</b></td><td><b>{esc(n)}</b></td><td>{esc(d)}</td><td>{esc(p)}</td><td>{esc(m)}</td></tr>" for s, n, d, p, m in F.SCORE_TAXONOMY)
               + "</tbody></table>")
    out.append("<p><b>The sentence that matters most:</b> no LLM-judge score exists anywhere in this report. Where a rubric document is described as “22/22”, that is my criteria reader — a deterministic text check — and it is evidence that the document says what the rubric asks, not that a judge would score it 22/22.</p>")
    out.append("<p>Two caveats about the reader. It is my own transcription of each criterion into a text check, so it can be wrong in both directions; what shows that it can at least go red is the breakage campaign, not the green count. And where a criterion cannot be decided from text alone it is checked structurally — a required section or table cell exists — so a green mark there means “present”, not “correct”. The clearest case is T-29, where 12 of the 30 rendered criteria are semantic checks and the rest structural.</p>")
    out.append("</section>")

    out.append("<section class='chapter'>")
    out.append("<h1>The verification ladder</h1>")
    out.append("<p>Each task climbs as far up this ladder as its grading type allows. The rung reached is stated in the task’s score box and in Figure 2.</p>")
    out.append("<table class='tax'><colgroup><col style='width:5%'><col style='width:17%'><col style='width:40%'><col style='width:38%'></colgroup>"
               "<thead><tr><th>Rung</th><th>Check</th><th>What is run</th><th>What it can and cannot prove</th></tr></thead><tbody>"
               + "".join(f"<tr><td class='c'><b>{r}</b></td><td><b>{esc(n)}</b></td><td>{esc(w)}</td><td>{esc(p)}</td></tr>" for r, n, w, p in F.LADDER)
               + "</tbody></table>")
    out.append(f"<figure>{img_tag(os.path.join(HERE, 'fig_judge.png'))}<figcaption><b>Figure 4.</b> The three checks-judge tasks and where their missing judge weight sits. R is measured with the judge switched off; the ceiling is what the rule would give if all judge families passed — computed from the formula, not measured. The amber bars are stub-judge simulations and are not scores.</figcaption></figure>")
    out.append("</section>")

    out.append("<section class='chapter'>")
    out.append("<h1>Limits stated up front</h1>")
    out.append("<ul class='limits'>")
    out += [f"<li><b>{esc(a)}</b> {esc(b)}</li>" for a, b in F.LIMITS]
    out.append("</ul>")
    out.append("</section>")
    return "".join(out)


def part_header(letter, title, blurb):
    return (f"<section class='chapter part'><h1>Part {letter} — {esc(title)}</h1><p>{esc(blurb)}</p></section>")


def back_sections():
    out = []
    out.append("<section class='chapter'>")
    out.append("<h1>Cross-cutting lessons: how my instruments failed</h1>")
    out.append("<p>The per-task sections list the errors of each task. Seven patterns repeat across the set, and they are more useful than any single score.</p>")
    out += [f"<p><b>{esc(a)}</b> {esc(b)}</p>" for a, b in F.LESSONS]
    out.append("</section>")

    out.append("<section class='chapter'>")
    out.append("<h1>Conclusions</h1>")
    out += [f"<p>{esc(p).replace('{breakages}', str(AGG['rubric_breakages']))}</p>" for p in F.CONCLUSIONS]
    out.append("<table class='agg'><tbody>"
               f"<tr><td>Tasks in the set</td><td class='num'>{AGG['n_tasks']}</td></tr>"
               f"<tr><td>Machine-scored (checks + checks-judge)</td><td class='num'>{AGG['n_machine_measured']}</td></tr>"
               f"<tr><td>Exactly 1.000</td><td class='num'>{AGG['n_at_one']}</td></tr>"
               f"<tr><td>Mean final reward R (15 tasks)</td><td class='num'>{fmt(AGG['mean_reward'], 6)}</td></tr>"
               f"<tr><td>Mean grader score G (15 tasks)</td><td class='num'>{fmt(AGG['mean_grader'], 6)}</td></tr>"
               f"<tr><td>Confirmed through the official entry (host)</td><td class='num'>{AGG['n_official_host']} + {AGG['n_official_host_stub']} with a stub judge</td></tr>"
               f"<tr><td>Blocked before the grader by the missing judge key</td><td class='num'>{AGG['n_blocked_key']}</td></tr>"
               f"<tr><td>Ever run inside the task verifier image (Docker, isolated VM)</td><td class='num'>{AGG['n_container']}</td></tr>"
               f"<tr><td>Rubric tasks with a judge score</td><td class='num'>0 of {AGG['n_rubric']}</td></tr>"
               f"<tr><td>Rubric criteria weight covered by my reader</td><td class='num'>{AGG['rubric_weight_total']:.0f} weight points over {AGG['rubric_criteria_total']} criteria</td></tr>"
               "</tbody></table>")
    out.append("</section>")

    out.append("<section class='chapter'>")
    out.append("<h1>Sources and supporting files</h1>")
    out.append("<table class='src'><colgroup><col style='width:18%'><col style='width:82%'></colgroup><tbody>"
               + "".join(f"<tr><td><b>{esc(a)}</b></td><td>{esc(b)}</td></tr>" for a, b in F.SOURCES)
               + "</tbody></table>")
    out.append("</section>")
    out.append(appendix_a())
    out.append(appendix_b())
    out.append(appendix_c())
    out.append(appendix_d())
    return "".join(out)


def appendix_a():
    rows = []
    for t in DATA["tasks"]:
        if t["type"] not in ("checks", "checks-judge"):
            continue
        off = {"host": "host test.sh", "host-stub": "host, stub judge", "blocked-key": "blocked by key"}[t["official_kind"]]
        cont = "yes" if t.get("container") else "—"
        rows.append(f"<tr><td class='c'>T-{t['num']:02d}</td><td>{esc(t['id'])}</td>"
                    f"<td class='mono tiny path'>{esc(t['deliverable']).replace('/', '/<wbr>')}</td><td class='num'>{t['size_measured']:,}</td>"
                    f"<td class='h'>{t['sha256'][:32]}<br>{t['sha256'][32:]}</td><td class='num'>{fmt(t['grader'])}</td>"
                    f"<td class='num'>{fmt(t['reward'])}</td><td>{off}</td><td class='c'>{cont}</td></tr>")
    return ("<section class='chapter'><h1>Appendix A — measured score ledger</h1>"
            "<p>Every machine-scored task, with the file that sits on disk now. Sizes and sha256 were recomputed at report build time; "
            "G and R were re-read from each task’s results_523/RESULT.json (or its paper_score.json) at the same moment. The full hash is given so a reader can verify a copy byte for byte.</p>"
            "<table class='ledger'><colgroup><col style='width:5%'><col style='width:14%'><col style='width:21%'><col style='width:6.5%'><col style='width:27%'><col style='width:6.5%'><col style='width:6.5%'><col style='width:9.5%'><col style='width:4%'></colgroup>"
            "<thead><tr><th>#</th><th>Task</th><th>File</th><th class='num'>Bytes</th><th>sha256</th><th class='num'>G</th><th class='num'>R</th><th>Official</th><th>C</th></tr></thead><tbody>"
            + "".join(rows) + "</tbody></table>"
            "<p class='legend'>C = ever run inside the task verifier image in Docker on the isolated VM. “blocked by key” means tests/test.sh exits before the grader because JUDGE_BASE_URL is unset; the grader part of those two tasks was measured directly (run_grade.py --no-judge + paper_score.py).</p></section>")


def appendix_b():
    rows = []
    for t in DATA["tasks"]:
        if t["type"] != "rubric":
            continue
        rows.append(f"<tr><td class='c'>T-{t['num']:02d}</td><td>{esc(t['id'])}</td>"
                    f"<td class='mono tiny path'>{esc(t['deliverable']).replace('/', '/<wbr>')}</td><td class='num'>{t['size_measured']:,}</td>"
                    f"<td class='h'>{t['sha256'][:32]}<br>{t['sha256'][32:]}</td><td class='num'>{t['criteria']}</td>"
                    f"<td class='num'>{t['criteria_weight']:.0f}</td><td class='num'>{esc(t['reader_compact'])}</td>"
                    f"<td class='c'>{esc(t['mutations'])}</td><td class='small'>{esc(t['notes'])}</td></tr>")
    return ("<section class='chapter'><h1>Appendix B — rubric packages and their records</h1>"
            "<p>Fourteen documents, all hashed at build time. Criteria counts and weights are read from each task’s tests/grader/criteria.json; "
            "the reader and breakage columns are the records written in the named NOTES file. No judge score exists for any row.</p>"
            "<table class='ledger'><colgroup><col style='width:5%'><col style='width:13%'><col style='width:19.5%'><col style='width:6%'><col style='width:25%'><col style='width:4%'><col style='width:4.5%'><col style='width:5.5%'><col style='width:7%'><col style='width:10.5%'></colgroup>"
            "<thead><tr><th>#</th><th>Task</th><th>File</th><th class='num'>Bytes</th><th>sha256</th><th class='num'>n</th><th class='num'>W</th><th class='num'>Reader</th><th>Breakages</th><th>Record</th></tr></thead><tbody>"
            + "".join(rows) + "</tbody></table>"
            "<p class='legend'>n = number of criteria; W = sum of their numerical weights; Reader = criteria passed by my deterministic reader over the criteria it can express (see each task’s section for what that means). Breakages were run through the official transform.py and the task’s verify.py/grade.py with a stub judge.</p></section>")


def appendix_c():
    out = ["<section class='chapter'><h1>Appendix C — the host’s walls, measured</h1>",
           "<p>These are environment facts, not task facts. Each was measured, and each changed how a run had to be made.</p>",
           "<table class='src'><colgroup><col style='width:30%'><col style='width:70%'></colgroup><tbody>"]
    out += [f"<tr><td><b>{esc(a)}</b></td><td>{esc(b)}</td></tr>" for a, b in F.WALLS]
    out.append("</tbody></table></section>")
    return "".join(out)


def appendix_d():
    out = ["<section class='chapter'><h1>Appendix D — glossary</h1>",
           "<table class='src'><colgroup><col style='width:24%'><col style='width:76%'></colgroup><tbody>"]
    out += [f"<tr><td><b>{esc(a)}</b></td><td>{esc(b)}</td></tr>" for a, b in F.GLOSSARY]
    out.append("</tbody></table></section>")
    return "".join(out)


def toc_html(entries, pages):
    lines = []
    for label, key in entries:
        p = pages.get(key, "")
        cls = "toc-task" if key.startswith("t-") else "toc-sec"
        lines.append(f"<div class='{cls}'><span class='t'>{esc(label)}</span><span class='dots'></span><span class='p'>{p}</span></div>")
    return "<section class='chapter toc'><h1>Contents</h1>" + "".join(lines) + "</section>"


TOC_ENTRIES = [
    ("What this report is", "what"),
    ("What PLE is", "ple"),
    ("All 29 tasks at a glance", "glance"),
    ("How the work was done", "how"),
    ("How to read a score", "score"),
    ("The verification ladder", "ladder"),
    ("Limits stated up front", "limits"),
    ("Part A — checks tasks", "partA"),
] + [(f"T-{n:02d} — {tid}", f"t-{n:02d}") for n, tid in [
    (1, "cooling-water-flush-plan"), (2, "data-center-site-model"), (3, "data-hall-device-takeoff"),
    (4, "data-hall-mep-routing"), (5, "data-hall-mep-routing-offset"), (6, "division-26-specifications"),
    (7, "frame-extension-method"), (8, "heat-rejection-life-cycle-cost"), (9, "mv-conveyance-study"),
    (10, "roof-deck-design"), (11, "seismic-diaphragm-shear"), (12, "wind-diaphragm-shear")]] + [
    ("Part B — checks-judge tasks", "partB"),
    ("T-13 — eor-review-corrections", "t-13"),
    ("T-14 — foundation-strategy", "t-14"),
    ("T-15 — lv-cable-sizing", "t-15"),
    ("Part C — rubric tasks", "partC"),
] + [(f"T-{n:02d} — {tid}", f"t-{n:02d}") for n, tid in [
    (16, "backfeed-energization-reply"), (17, "emergency-spillway-check"), (18, "engineers-estimate-check"),
    (19, "fill-compaction-acceptance"), (20, "fire-solve-convergence"), (21, "fire-test-validation-memo"),
    (22, "footing-settlement-verification"), (23, "landscape-sheet-revision"), (24, "les-mesh-resolution"),
    (25, "permission-to-operate-memo"), (26, "pre-application-capacity-response"),
    (27, "shoring-design-verification"), (28, "solar-supplemental-review"), (29, "solar-witness-test-package")]] + [
    ("Cross-cutting lessons", "lessons"),
    ("Conclusions", "conclusions"),
    ("Sources and supporting files", "sources"),
    ("Appendix A — measured score ledger", "appA"),
    ("Appendix B — rubric packages", "appB"),
    ("Appendix C — the host’s walls", "appC"),
    ("Appendix D — glossary", "appD"),
]

ANCHOR_TEXT = {
    "what": "What this report is", "ple": "What PLE is", "glance": "All 29 tasks at a glance",
    "how": "How the work was done", "score": "How to read a score", "ladder": "The verification ladder",
    "limits": "Limits stated up front", "partA": "Part A — checks tasks",
    "partB": "Part B — checks-judge tasks", "partC": "Part C — rubric tasks",
    "lessons": "Cross-cutting lessons", "conclusions": "Conclusions",
    "sources": "Sources and supporting files", "appA": "Appendix A — measured score ledger",
    "appB": "Appendix B — rubric packages", "appC": "Appendix C — the host’s walls",
    "appD": "Appendix D — glossary",
}

CSS = """
@page { size: A4; margin: 20mm 17mm 18mm 17mm; }
* { box-sizing: border-box; }
body { font-family: "Liberation Serif", serif; font-size: 9.7pt; line-height: 1.37; color: #141414; margin: 0; }
h1, h2, h3, .kicker, .lab, table, .score, figcaption, .headline { font-family: "Liberation Sans", sans-serif; }
h1 { font-size: 16pt; color: #1b3a5c; margin: 0 0 3mm 0; line-height: 1.15; page-break-after: avoid; }
h2 { font-size: 11pt; color: #1b3a5c; margin: 5mm 0 1.5mm 0; page-break-after: avoid; }
p { margin: 0 0 2.4mm 0; text-align: justify; hyphens: auto; }
ul { margin: 0 0 2.4mm 0; padding-left: 4.6mm; }
li { margin: 0 0 1.1mm 0; text-align: justify; hyphens: auto; }
.chapter { page-break-before: always; }
.chapter.part { page-break-before: auto; margin-top: 8mm; }
.kicker { font-size: 8pt; letter-spacing: .06em; text-transform: uppercase; color: #6b7a8c; margin-bottom: 1mm; }
.headline { font-size: 10.6pt; font-style: italic; color: #243b53; border-left: 3px solid #b7791f; padding: 1mm 0 1mm 3mm; margin: 0 0 3mm 0; text-align: left; }
.lab { font-size: 8.6pt; font-weight: bold; letter-spacing: .04em; text-transform: uppercase; color: #1b3a5c; margin: 3.6mm 0 1.2mm 0; page-break-after: avoid; }
.task { margin-top: 9mm; }
.task h1 { font-size: 14.5pt; margin-bottom: 2mm; }
.task-head { break-inside: avoid; page-break-inside: avoid; }
.task-head h1 { break-after: avoid; }
table { border-collapse: collapse; width: 100%; font-size: 7.6pt; margin: 1mm 0 3mm 0; }
th { background: #1b3a5c; color: #fff; text-align: left; padding: 1.3mm 1.4mm; font-weight: bold; }
td { border-bottom: .4pt solid #ccd3da; padding: 1.2mm 1.4mm; vertical-align: top; }
tr { page-break-inside: avoid; }
tbody tr:nth-child(even) td { background: #f5f7f9; }
table.score { font-size: 7.9pt; margin: 0 0 3mm 0; break-inside: avoid; page-break-inside: avoid; }
table.score td { border-bottom: .4pt solid #e2e6ea; }
table.score td.k { width: 42%; background: #eef3f8; color: #1b3a5c; }
table.score tbody tr:nth-child(even) td { background: #fff; }
table.score tbody tr:nth-child(even) td.k { background: #eef3f8; }
table.summary { font-size: 6.9pt; }
table.summary td.c, table.summary th.c { white-space: nowrap; }
table.summary td:first-child { white-space: nowrap; }
table.summary td, table.summary th { padding: 1mm 1.2mm; }
table.ledger { font-size: 6.4pt; }
table.ledger td.h { font-family: 'Liberation Mono', monospace; font-size: 5.5pt; white-space: nowrap; }
table.ledger td, table.ledger th { padding: .8mm .9mm; }
table.tax td { font-size: 7.4pt; }
table.src td { font-size: 7.6pt; }
table.agg { width: 78%; font-size: 8pt; }
table.agg td { border-bottom: .4pt solid #d5dbe1; }
.mono { font-family: "Liberation Mono", monospace; font-size: 88%; }
.tiny { font-size: 5.9pt; }
td.path { word-break: normal; overflow-wrap: normal; hyphens: none; }
td.path, td.path wbr { line-height: 1.22; }
.small { font-size: 6.6pt; }
.num { text-align: right; font-variant-numeric: tabular-nums; }
.c { text-align: center; }
.legend { font-size: 7.4pt; color: #3d4b5c; font-family: "Liberation Sans", sans-serif; }
figure { margin: 4mm 0 4mm 0; page-break-inside: avoid; }
figcaption { font-size: 7.6pt; color: #3d4b5c; margin-top: 1.5mm; text-align: left; }
figure.diagram { margin-top: 5mm; }
ul.limits li { margin-bottom: 2mm; }
.toc h1 { margin-bottom: 4mm; }
.toc-sec, .toc-task { display: flex; align-items: baseline; font-family: "Liberation Sans", sans-serif; font-size: 8.2pt; margin: 0 0 0.55mm 0; line-height: 1.22; }
.toc-task { padding-left: 6mm; font-size: 7.9pt; }
.toc-sec { font-weight: bold; margin-top: 1.6mm; }
.toc-sec .dots, .toc-task .dots { flex: 1; border-bottom: .5pt dotted #9aa7b4; margin: 0 2mm; }
.toc-sec .p, .toc-task .p { color: #1b3a5c; }
.title-page { height: 245mm; display: flex; flex-direction: column; justify-content: space-between; }
.title-top { margin-top: 40mm; }
.title-kicker { font-family: "Liberation Sans"; font-size: 9pt; letter-spacing: .12em; text-transform: uppercase; color: #6b7a8c; }
.title-main { font-family: "Liberation Sans"; font-size: 30pt; line-height: 1.1; color: #1b3a5c; font-weight: bold; margin: 6mm 0 4mm 0; }
.title-sub { font-family: "Liberation Sans"; font-size: 13pt; color: #33475b; margin-bottom: 12mm; }
.title-by { font-family: "Liberation Sans"; font-size: 10.5pt; color: #141414; }
.title-meta { font-family: "Liberation Sans"; font-size: 8.6pt; color: #6b7a8c; }
.title-box { border-top: 2pt solid #1b3a5c; padding-top: 4mm; display: flex; gap: 8mm; }
.title-stat { flex: 1; }
.title-stat .n { font-family: "Liberation Sans"; font-size: 20pt; color: #1b3a5c; font-weight: bold; }
.title-stat .l { font-family: "Liberation Sans"; font-size: 7.6pt; color: #4a5a6a; }
"""

COVER = f"""<!doctype html><html><head><meta charset="utf-8"><style>{CSS}
@page {{ margin: 0; }}
body {{ margin: 0; }}
.cover {{ padding: 26mm 20mm 20mm 20mm; height: 297mm; }}
</style></head><body><div class="cover title-page">
<div class="title-top">
<div class="title-kicker">Physical Engineering’s Last Exam · public dev set · 29 tasks</div>
<div class="title-main">What was measured,<br>and what was not</div>
<div class="title-sub">A report on all 29 PLE development tasks</div>
<div class="title-by"><b>Agent AIODAM</b> · own harness · model DeepSeek V4.1 Flash</div>
<div class="title-meta">{F.DATE} · {F.VERSION}</div>
</div>
<div>
<div class="title-box">
<div class="title-stat"><div class="n">29</div><div class="l">tasks reported</div></div>
<div class="title-stat"><div class="n">15</div><div class="l">with a measured machine score</div></div>
<div class="title-stat"><div class="n">14</div><div class="l">documents, no judge score</div></div>
<div class="title-stat"><div class="n">0</div><div class="l">LLM-judge scores anywhere</div></div>
</div>
<p style="font-family:'Liberation Sans';font-size:7.8pt;color:#6b7a8c;margin-top:6mm;">
This report separates machine scores, judge scores, stub-judge simulations and my own checks. It is not a leaderboard submission,
and it does not call a host run a container run. Every score in it is traceable to a file and a hash.</p>
</div>
</div></body></html>"""


def body_html(pages):
    parts = [f"<!doctype html><html><head><meta charset='utf-8'><title>{F.TITLE}</title><style>{CSS}</style></head><body>"]
    parts.append(toc_html(TOC_ENTRIES, pages))
    parts.append(front_sections())
    parts.append(part_header("A", "checks tasks", "Twelve tasks graded by a deterministic grader. Each has a measured score; each score was re-measured from the file on disk at the end of the run."))
    for t in DATA["tasks"]:
        if t["type"] == "checks":
            parts.append(task_html(t))
    parts.append(part_header("B", "checks-judge tasks", "Three tasks where a deterministic grader is combined with a small number of judge families. The grader part is measured; the judge part is not, and the report shows exactly where the gap sits."))
    for t in DATA["tasks"]:
        if t["type"] == "checks-judge":
            parts.append(task_html(t))
    parts.append(part_header("C", "rubric tasks", "Fourteen tasks scored by an LLM judge against weighted criteria. Every document is finished and hashed; none has a score. What is measured instead — my criteria reader, the breakage campaigns and the number audits — is described in each section and never presented as a judgment."))
    for t in DATA["tasks"]:
        if t["type"] == "rubric":
            parts.append(task_html(t))
    parts.append(back_sections())
    parts.append("</body></html>")
    return "".join(parts)


# ---------------------------------------------------------------- render
def render(html_path, pdf_path, header_footer=True):
    from playwright.sync_api import sync_playwright
    with sync_playwright() as p:
        b = p.chromium.launch(executable_path="/usr/bin/chromium", args=["--no-sandbox"])
        pg = b.new_page()
        pg.goto("file://" + html_path)
        kwargs = dict(path=pdf_path, format="A4", print_background=True,
                      margin={"top": "20mm", "bottom": "18mm", "left": "17mm", "right": "17mm"})
        if header_footer:
            kwargs.update(display_header_footer=True,
                          header_template=("<div style='font-size:6.5pt;width:100%;padding:0 17mm;color:#8a97a5;"
                                           "font-family:Liberation Sans;display:flex;justify-content:space-between;'>"
                                           "<span>PLE 29-task report · AIODAM</span><span>11 November 2026</span></div>"),
                          footer_template="<div></div>")
        pg.pdf(**kwargs)
        b.close()


def map_pages(pdf_path):
    import fitz
    doc = fitz.open(pdf_path)
    pages = {}
    texts = [doc[i].get_text() for i in range(len(doc))]
    # skip the TOC page(s): any page containing "Contents"
    start = 0
    for i, t in enumerate(texts[:3]):
        if "Contents" in t:
            start = i + 1
    for key, label in ANCHOR_TEXT.items():
        for i in range(start, len(texts)):
            if label in texts[i]:
                pages[key] = i + 1
                break
    for t in DATA["tasks"]:
        key = f"t-{t['num']:02d}"
        label = f"T-{t['num']:02d} — {t['id']}"
        for i in range(start, len(texts)):
            if label in texts[i]:
                pages[key] = i + 1
                break
    return pages, len(doc)


def main():
    fig_scores(os.path.join(HERE, "fig_scores.png"))
    fig_matrix(os.path.join(HERE, "fig_matrix.png"))
    fig_judge(os.path.join(HERE, "fig_judge.png"))

    with open(COVER_HTML, "w") as f:
        f.write(COVER)
    render(COVER_HTML, COVER_PDF, header_footer=False)

    # pass 1: no page numbers yet (the TOC still occupies its page)
    with open(BODY_HTML, "w") as f:
        f.write(body_html({}))
    render(BODY_HTML, BODY_PDF)
    pages, n = map_pages(BODY_PDF)
    missing = [k for _, k in TOC_ENTRIES if k not in pages]
    print("pass1 pages:", n, "missing anchors:", missing)

    # pass 2: real page numbers, shifted by the cover page
    shifted = {k: v + 1 for k, v in pages.items()}
    with open(BODY_HTML, "w") as f:
        f.write(body_html(shifted))
    render(BODY_HTML, BODY_PDF)
    pages2, n2 = map_pages(BODY_PDF)
    shifted2 = {k: v + 1 for k, v in pages2.items()}
    if shifted2 != shifted:
        diff = {k: (shifted.get(k), shifted2.get(k)) for k in shifted2 if shifted.get(k) != shifted2.get(k)}
        print("pagination shifted, third pass:", diff)
        with open(BODY_HTML, "w") as f:
            f.write(body_html(shifted2))
        render(BODY_HTML, BODY_PDF)
        pages3, n3 = map_pages(BODY_PDF)
        shifted3 = {k: v + 1 for k, v in pages3.items()}
        if shifted3 != shifted2:
            print("WARNING: TOC still unstable", {k: (shifted2.get(k), shifted3.get(k)) for k in shifted3 if shifted2.get(k) != shifted3.get(k)})
        pages = pages3
    else:
        pages = pages2
    print("body pages:", n2, "total with cover:", n2 + 1)

    # merge cover + body
    import fitz
    out = fitz.open()
    for path in (COVER_PDF, BODY_PDF):
        d = fitz.open(path)
        out.insert_pdf(d)
        d.close()
    total = len(out)
    for k in range(1, total):  # skip the cover
        page = out[k]
        txt = f"page {k+1} of {total}"
        fontfile = "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf"
        tw = fitz.get_text_length(txt, fontname="helv", fontsize=6.5)
        page.insert_text(((page.rect.width - tw) / 2, page.rect.height - 26), txt,
                         fontname="LibSans", fontfile=fontfile, fontsize=6.5, color=(0.54, 0.59, 0.65))
    out.set_metadata({"title": "PLE 29-task report — AIODAM", "author": "AIODAM",
                      "subject": "Physical Engineering’s Last Exam, dev set, 29 tasks",
                      "keywords": "PLE, benchmark, report, verification"})
    out.save(OUT_PDF, garbage=4, deflate=True)
    out.close()
    with open(OUT_HTML, "w") as f:
        f.write(body_html(shifted2))
    print("written:", OUT_PDF, os.path.getsize(OUT_PDF), "bytes")
    json.dump(shifted2, open(os.path.join(HERE, "toc_pages.json"), "w"), indent=1)


if __name__ == "__main__":
    sys.exit(main())
