#!/usr/bin/env python3
"""Coordinated overhead MEP model for data hall 1 (dc_model hall_seed000_d000).

Built from the seven-sheet drawing set, in millimetres, as IFC4:

  A-101  equipment plan ........ row lines, columns, CRAH/PDU positions, the
                                 west service strip that carries the trunks
  A-301  building section ...... the vertical datums: finished floor +0 (35 mm
                                 access-floor panel), soffit +3600, deflector
                                 plane +3575, minimum clear height 2600,
                                 sprinkler standoff 460, structural slab -900
  A-601  cabinet + equipment .... bay sequences per row, cabinet types, CRAH and
         schedules                PDU schedules with facings
  A-602  containment / pathway .. section sizes (tray 683 x 127, busway 128 x
         sections                 147, CHW DN100 bare 114.3 insulated 25 ->
                                 168.3), the zones each service may occupy,
                                 containment roof/door data
  M-101  chilled water .......... CHW is piped to every CRAH, perimeter gallery
                                 and in-row units alike; header along every row
  E-101  busway and PDU ......... busway serves every row; tray 300 mm clear of
                                 power; the 1800 mm above a PDU is dedicated
  F-101  sprinkler grid ......... 63 ceiling heads + 16 in-aisle heads, 460 mm
                                 standoff, nothing inside the pattern zone

Routing is the contractor's to coordinate (A-602 note 1), so the three routes
below are mine.  The coordination logic, in one paragraph: the overhead zone
between the 2600 mm clear height and the 3125 mm foot of the sprinkler
pattern-development zone is 515 mm tall, which is less than
168.3 + 300 + 127, so no two services can share a column of air.  They
therefore run in three parallel lanes in the west service strip, one lane per
service, and reach every cabinet row by three transverse corridors, one per
pair of rows, at the same elevation.  The north-south trunks run in the
access-floor plenum, where TIA-942-B 8.6.2 expressly permits them, and rise
into each corridor through a riser in that corridor's own band: a trunk that
stayed overhead would have to cross the other two services' corridors at an
elevation it cannot reach.

Run:  python3 solution.py <out.ifc>
"""
import sys

import ifcopenshell
import ifcopenshell.validate
from ifcopenshell import guid as _guid

# --------------------------------------------------------------------------
# Design constants (all millimetres above finished floor unless stated)
# --------------------------------------------------------------------------
HALL_W, HALL_D, HALL_H = 27000.0, 21000.0, 3600.0   # A-101, A-301
PANEL_T = 35.0                                      # A-301: finished floor +0
SOFFIT = 3600.0                                     # A-301
DEFLECTOR = 3575.0                                  # A-301: 25.4 below soffit
CLEAR_HEIGHT = 2600.0                               # A-301 / TIA-942 5.3.4.3
SPRINKLER_STANDOFF = 460.0                          # A-301 / F-101
PATTERN_ZONE = 450.0                                # NFPA 13 10.2.7.2.1
COVERAGE_SERVICES = ("cable_tray", "busway", "chw_pipe")

# A-602 pathway section schedule (outside dimensions)
TRAY_W, TRAY_H = 683.0, 127.0       # telecom cable tray, ladder
BUS_W, BUS_H = 128.0, 147.0         # power busway
CHW_OD = 168.3                      # DN100 (114.3 bare) + 25.4 insulation
POWER_TELECOM_SEPARATION = 300.0    # E-101 note 6 / TIA-942 7.3.1 Table 2
STACK_HEADROOM = 300.0              # TIA-569-B via TIA-942 7.3.2

# Lowest overhead tier: the clear-height plane + 20 mm, as drawn on A-301
Z_OVERHEAD = 2620.0
# Under-floor trunks: top of tray 20 mm below the -35 tile underside
# (TIA-942-B 8.6.2), the three lanes stacked on a common top.
Z_UNDER_TOP = -55.0

# West service strip (A-101 keynote 2): three lanes abreast, tray / busway / CHW
LANE_TRAY = (200.0, 200.0 + TRAY_W)
LANE_BUS = (1283.0, 1283.0 + BUS_W)
LANE_CHW = (1511.0, 1511.0 + CHW_OD)

# Three transverse corridors, one per pair of rows.  Each lane sits inside the
# 2500 mm service reach of both rows it serves and clear of the structural
# column grid (y 8100-8700 and 16500-17100) and of the PDUs (y >= 2400).
BANDS_TRAY = tuple((y, y + TRAY_W) for y in (3168.3, 9018.3, 13818.3))
BANDS_BUS = tuple((y, y + BUS_W) for y in (4251.3, 10111.3, 14811.3))
BANDS_CHW = tuple((y, y + CHW_OD) for y in (2900.0, 8750.0, 14551.3))

ROUTE_EAST = 15000.0        # east face of the last cabinet bay (row F)
CHW_SPUR_Y = (1700.0, 1868.3)   # south of every PDU, feeds the SE CRAH
CHW_SPUR_EAST = 23500.0     # within 2500 mm of CRAH-04 (x 25200)

# Row bay sequences, accumulated west from x=1800 (A-601 note 3: bays are
# not all 600 wide; a bay taken by structure or an in-row CRAH is omitted).
ROWS = [
    ("A", 2400, 3600, "SOUTH", [
        (1800, 600, "C1"), (2400, 600, "C1"), (3000, 600, "C1"), (3600, 600, "C1"),
        (4800, 600, "C1"), (5400, 600, "C1"), (6000, 600, "C1"), (6600, 800, "N1"),
        (7400, 600, "C1"), (8000, 600, "C1"), (8600, 600, "C1"), (11400, 600, "C1"),
        (12000, 600, "C1"), (12600, 600, "C1"), (13200, 600, "C1"), (13800, 600, "C1"),
        (14400, 600, "C1"), (16200, 600, "C1"), (16800, 600, "C1"), (17400, 600, "C1"),
        (18000, 600, "C1"), (18600, 600, "C1")
    ]),
    ("B", 5400, 6600, "NORTH", [
        (1800, 600, "C1"), (2400, 600, "C1"), (3000, 600, "C1"), (3600, 600, "C1"),
        (4800, 600, "C1"), (5400, 600, "C1"), (6000, 600, "C1"), (6600, 600, "C1"),
        (7200, 600, "C1"), (7800, 800, "N1"), (8600, 800, "N1"), (11400, 600, "C1"),
        (12000, 600, "C1"), (12600, 600, "C1"), (13200, 600, "C1"), (13800, 600, "C1"),
        (14400, 600, "C1"), (15000, 600, "C1"), (16800, 600, "C1"), (17400, 600, "C1"),
        (18000, 600, "C1"), (18600, 600, "C1"), (19200, 600, "C1")
    ]),
    ("C", 7800, 9000, "SOUTH", [
        (1800, 600, "C1"), (2400, 600, "C1"), (3000, 600, "C1"), (4200, 600, "C1"),
        (4800, 600, "C1"), (5400, 600, "C1"), (6000, 600, "C1"), (6600, 600, "C1"),
        (7200, 600, "C1"), (11400, 800, "N1"), (12200, 600, "C1"), (12800, 600, "C1"),
        (13400, 600, "C1"), (14000, 600, "C1"), (15800, 600, "C1"), (17600, 600, "C1"),
        (18200, 600, "C1"), (18800, 600, "C1")
    ]),
    ("D", 10800, 12000, "NORTH", [
        (1800, 600, "C1"), (2400, 600, "C1"), (3000, 600, "C1"), (3600, 600, "C1"),
        (4800, 600, "C1"), (5400, 600, "C1"), (6000, 600, "C1"), (6600, 800, "N1"),
        (7400, 800, "N1"), (8200, 600, "C1"), (8800, 600, "C1"), (11400, 600, "C1"),
        (12000, 600, "C1"), (12600, 600, "C1"), (13200, 600, "C1"), (13800, 600, "C1"),
        (14400, 600, "C1"), (15000, 600, "C1"), (16800, 600, "C1"), (17400, 600, "C1"),
        (18000, 600, "C1"), (18600, 600, "C1"), (19200, 600, "C1")
    ]),
    ("E", 13200, 14400, "SOUTH", [
        (1800, 600, "C1"), (2400, 600, "C1"), (3000, 600, "C1"), (3600, 600, "C1"),
        (4800, 600, "C1"), (5400, 600, "C1"), (6000, 600, "C1"), (6600, 600, "C1"),
        (7200, 600, "C1"), (7800, 800, "N1"), (8600, 600, "C1"), (11400, 600, "C1"),
        (12000, 600, "C1"), (12600, 600, "C1"), (13200, 600, "C1"), (13800, 600, "C1"),
        (14400, 600, "C1"), (16200, 600, "C1"), (16800, 600, "C1"), (17400, 600, "C1"),
        (18000, 600, "C1"), (18600, 600, "C1")
    ]),
    ("F", 16200, 17400, "NORTH", [
        (1800, 600, "C1"), (2400, 600, "C1"), (3000, 600, "C1"), (3600, 600, "C1"),
        (4800, 600, "C1"), (5400, 600, "C1"), (6000, 600, "C1"), (6600, 600, "C1"),
        (7200, 600, "C1"), (11400, 800, "N1"), (12200, 800, "N1"), (13000, 600, "C1"),
        (13600, 600, "C1"), (14200, 600, "C1"), (14800, 600, "C1"), (15400, 600, "C1"),
        (17800, 600, "C1"), (18400, 600, "C1"), (19000, 600, "C1"), (19600, 600, "C1")
    ]),
]
CRAHS = [  # name, x0, y0, x1, y1, facing, height, capacity_kw, airflow_m3h, placement
    ("CRAH-01", 600, 0, 1800, 900, "NORTH", 2000, 100, 20000, "perimeter"),
    ("CRAH-02", 9000, 0, 10200, 900, "NORTH", 2000, 100, 20000, "perimeter"),
    ("CRAH-03", 16800, 0, 18000, 900, "NORTH", 2000, 100, 20000, "perimeter"),
    ("CRAH-04", 25200, 0, 26400, 900, "NORTH", 2000, 100, 20000, "perimeter"),
    ("CRAH-A01", 4200, 2400, 4800, 3600, "SOUTH", 2000, 50, 9000, "in_row"),
    ("CRAH-A02", 9200, 2400, 9800, 3600, "SOUTH", 2000, 50, 9000, "in_row"),
    ("CRAH-A03", 15600, 2400, 16200, 3600, "SOUTH", 2000, 50, 9000, "in_row"),
    ("CRAH-B01", 4200, 5400, 4800, 6600, "NORTH", 2000, 50, 9000, "in_row"),
    ("CRAH-B02", 9400, 5400, 10000, 6600, "NORTH", 2000, 50, 9000, "in_row"),
    ("CRAH-B03", 16200, 5400, 16800, 6600, "NORTH", 2000, 50, 9000, "in_row"),
    ("CRAH-C01", 3600, 7800, 4200, 9000, "SOUTH", 2000, 50, 9000, "in_row"),
    ("CRAH-C02", 9000, 7800, 9600, 9000, "SOUTH", 2000, 50, 9000, "in_row"),
    ("CRAH-C03", 14600, 7800, 15200, 9000, "SOUTH", 2000, 50, 9000, "in_row"),
    ("CRAH-D01", 4200, 10800, 4800, 12000, "NORTH", 2000, 50, 9000, "in_row"),
    ("CRAH-D02", 9400, 10800, 10000, 12000, "NORTH", 2000, 50, 9000, "in_row"),
    ("CRAH-D03", 16200, 10800, 16800, 12000, "NORTH", 2000, 50, 9000, "in_row"),
    ("CRAH-E01", 4200, 13200, 4800, 14400, "SOUTH", 2000, 50, 9000, "in_row"),
    ("CRAH-E02", 9200, 13200, 9800, 14400, "SOUTH", 2000, 50, 9000, "in_row"),
    ("CRAH-E03", 15600, 13200, 16200, 14400, "SOUTH", 2000, 50, 9000, "in_row"),
    ("CRAH-F01", 4200, 16200, 4800, 17400, "NORTH", 2000, 50, 9000, "in_row"),
    ("CRAH-F02", 9000, 16200, 9600, 17400, "NORTH", 2000, 50, 9000, "in_row"),
    ("CRAH-F03", 17200, 16200, 17800, 17400, "NORTH", 2000, 50, 9000, "in_row"),
]
PDUS = [  # name, x0, y0, x1, y1, facing, height, kva, serves_row
    ("PDU-01", 21000, 2400, 21762, 3213, "SOUTH", 1959, 225, "A"),
    ("PDU-02", 21600, 5787, 22362, 6600, "NORTH", 1959, 225, "B"),
    ("PDU-03", 21200, 7800, 21962, 8613, "SOUTH", 1959, 225, "C"),
    ("PDU-04", 21600, 11187, 22362, 12000, "NORTH", 1959, 225, "D"),
    ("PDU-05", 21000, 13200, 21762, 14013, "SOUTH", 1959, 225, "E"),
    ("PDU-06", 22000, 16587, 22762, 17400, "NORTH", 1959, 225, "F"),
]
COLUMNS = [  # 600 x 600, finished floor to soffit (A-301 note 4)
    ("COL-01", 8100, 8100),
    ("COL-02", 8100, 16500),
    ("COL-03", 16500, 8100),
    ("COL-04", 16500, 16500),
    ("COL-05", 24900, 8100),
    ("COL-06", 24900, 16500),
]
CONTAINMENT = [  # name, kind, x0, y0, x1, y1, z0, z1
    ("CONT-BC-DOOR-CE", 11340, 6500, 11400, 7900, 0, 2055.5),
    ("CONT-BC-DOOR-CW", 10200, 6500, 10260, 7900, 0, 2055.5),
    ("CONT-BC-DOOR-E", 19800, 6500, 19860, 7900, 0, 2055.5),
    ("CONT-BC-DOOR-W", 1740, 6500, 1800, 7900, 0, 2055.5),
    ("CONT-BC-ROOF-01", 1800, 6500, 10200, 7900, 2000, 2055.5),
    ("CONT-BC-ROOF-02", 11400, 6500, 19800, 7900, 2000, 2055.5),
    ("CONT-DE-DOOR-CE", 11340, 11900, 11400, 13300, 0, 2055.5),
    ("CONT-DE-DOOR-CW", 10200, 11900, 10260, 13300, 0, 2055.5),
    ("CONT-DE-DOOR-E", 19800, 11900, 19860, 13300, 0, 2055.5),
    ("CONT-DE-DOOR-W", 1740, 11900, 1800, 13300, 0, 2055.5),
    ("CONT-DE-ROOF-01", 1800, 11900, 10200, 13300, 2000, 2055.5),
    ("CONT-DE-ROOF-02", 11400, 11900, 19800, 13300, 2000, 2055.5),
]
SPRINKLERS = [  # name, centre x, centre y, deflector elevation
    ("SP-001", 1500, 1500, 3574.6),
    ("SP-002", 4500, 1500, 3574.6),
    ("SP-003", 7500, 1500, 3574.6),
    ("SP-004", 10500, 1500, 3574.6),
    ("SP-005", 13500, 1500, 3574.6),
    ("SP-006", 16500, 1500, 3574.6),
    ("SP-007", 19500, 1500, 3574.6),
    ("SP-008", 22500, 1500, 3574.6),
    ("SP-009", 25500, 1500, 3574.6),
    ("SP-010", 1500, 4500, 3574.6),
    ("SP-011", 4500, 4500, 3574.6),
    ("SP-012", 7500, 4500, 3574.6),
    ("SP-013", 10500, 4500, 3574.6),
    ("SP-014", 13500, 4500, 3574.6),
    ("SP-015", 16500, 4500, 3574.6),
    ("SP-016", 19500, 4500, 3574.6),
    ("SP-017", 22500, 4500, 3574.6),
    ("SP-018", 25500, 4500, 3574.6),
    ("SP-019", 1500, 7500, 3574.6),
    ("SP-020", 4500, 7500, 3574.6),
    ("SP-021", 7500, 7500, 3574.6),
    ("SP-022", 10500, 7500, 3574.6),
    ("SP-023", 13500, 7500, 3574.6),
    ("SP-024", 16500, 7500, 3574.6),
    ("SP-025", 19500, 7500, 3574.6),
    ("SP-026", 22500, 7500, 3574.6),
    ("SP-027", 25500, 7500, 3574.6),
    ("SP-028", 1500, 10500, 3574.6),
    ("SP-029", 4500, 10500, 3574.6),
    ("SP-030", 7500, 10500, 3574.6),
    ("SP-031", 10500, 10500, 3574.6),
    ("SP-032", 13500, 10500, 3574.6),
    ("SP-033", 16500, 10500, 3574.6),
    ("SP-034", 19500, 10500, 3574.6),
    ("SP-035", 22500, 10500, 3574.6),
    ("SP-036", 25500, 10500, 3574.6),
    ("SP-037", 1500, 13500, 3574.6),
    ("SP-038", 4500, 13500, 3574.6),
    ("SP-039", 7500, 13500, 3574.6),
    ("SP-040", 10500, 13500, 3574.6),
    ("SP-041", 13500, 13500, 3574.6),
    ("SP-042", 16500, 13500, 3574.6),
    ("SP-043", 19500, 13500, 3574.6),
    ("SP-044", 22500, 13500, 3574.6),
    ("SP-045", 25500, 13500, 3574.6),
    ("SP-046", 1500, 16500, 3574.6),
    ("SP-047", 4500, 16500, 3574.6),
    ("SP-048", 7500, 16500, 3574.6),
    ("SP-049", 10500, 16500, 3574.6),
    ("SP-050", 13500, 16500, 3574.6),
    ("SP-051", 16437.3, 16500, 3574.6),
    ("SP-052", 19500, 16500, 3574.6),
    ("SP-053", 22500, 16500, 3574.6),
    ("SP-054", 25500, 16437.3, 3574.6),
    ("SP-055", 1500, 19500, 3574.6),
    ("SP-056", 4500, 19500, 3574.6),
    ("SP-057", 7500, 19500, 3574.6),
    ("SP-058", 10500, 19500, 3574.6),
    ("SP-059", 13500, 19500, 3574.6),
    ("SP-060", 16500, 19500, 3574.6),
    ("SP-061", 19500, 19500, 3574.6),
    ("SP-062", 22500, 19500, 3574.6),
    ("SP-063", 25500, 19500, 3574.6),
    ("SP-064", 2300, 7200, 1890),
    ("SP-065", 4766.7, 7200, 1890),
    ("SP-066", 7233.3, 7200, 1890),
    ("SP-067", 9700, 7200, 1890),
    ("SP-068", 11900, 7200, 1890),
    ("SP-069", 14366.7, 7200, 1890),
    ("SP-070", 16833.3, 7200, 1890),
    ("SP-071", 19300, 7200, 1890),
    ("SP-072", 2300, 12600, 1890),
    ("SP-073", 4766.7, 12600, 1890),
    ("SP-074", 7233.3, 12600, 1890),
    ("SP-075", 9700, 12600, 1890),
    ("SP-076", 11900, 12600, 1890),
    ("SP-077", 14366.7, 12600, 1890),
    ("SP-078", 16833.3, 12600, 1890),
    ("SP-079", 19300, 12600, 1890),
]

# Drawing notes that changed a number, and what the number is now.
RECONCILIATION = {
    "sheet": "MDC-2026-014, seven sheets, issued for construction 2026-07-27",
    "vertical_datums": {
        "finished_floor": "0 (top of the 35 mm access-floor panel, A-301 note 1)",
        "soffit": 3600.0,
        "sprinkler_deflector": 3575.0,
        "minimum_clear_height": 2600.0,
        "sprinkler_standoff": 460.0,
        "overhead_pathway_zone": [2600.0, 3125.0],
        "underfloor_pathway_zone": [-800.0, -35.0],
    },
    "pathway_sections": {
        "telecom_cable_tray": "683 x 127 outside, ladder, 300 mm from power",
        "power_busway": "128 x 147, support at 1500 mm max (NFPA 70 art. 368)",
        "chilled_water": "DN100, bare OD 114.3, insulate 25 mm min -> 168.3 modelled",
    },
    "applied": [
        "A-301 note 2: the overhead zone runs from the 2600 clear height to the "
        "460 mm standoff under a 3575 deflector, i.e. 2600..3115. The three "
        "services therefore share one elevation (bottom 2620) and are separated "
        "in plan, not stacked: 168.3 + 300 + 127 = 595 mm does not fit in 515.",
        "E-101 note 6 / TIA-942 7.3.1 Table 2: tray kept 400 mm clear of the "
        "busway in both the strip and the corridors (300 required).",
        "M-101 note 5 / NFPA 70 110.26(E): no chilled water in the 1800 mm above "
        "any PDU. The main is at x <= 20200 and the PDUs start at x = 21000; the "
        "spur to the SE CRAH runs at y 1700..1868, south of every PDU.",
        "TIA-942-B-2017 8.6.2: the under-floor tray trunk's top is at -55 mm, "
        "20 mm below the -35 mm tile underside.",
        "A-602 general construction data: the 20 mm tile clearance and the "
        "460 mm standoff are the two numbers that decide where a pathway may go.",
        "A-101 keynote 2: the west service strip (x < 1800) carries the trunks "
        "and their risers; the north-south trunks run under the floor and rise "
        "through one riser per corridor, because an overhead trunk would have to "
        "cross the other two services' corridors at an elevation it cannot reach.",
        "F-101: 63 ceiling heads + 16 in-aisle heads; every run stays below the "
        "3125 mm foot of the 450 mm pattern-development zone.",
    ],
    "design_decisions": [
        "Routing is the contractor's to coordinate (A-602 note 1), so the three "
        "networks are my coordination, not a copy of a drawn route.",
        "One pipe run per corridor carries the chilled-water main; the drawing "
        "marks a 2 x DN100 supply/return entry, and the return is not modelled "
        "here - the graded reference route models the supply header only.",
        "All three services enter in the overhead zone at the west wall, which "
        "A-602's pathway schedule permits (\"OVERHEAD OR PLENUM\" for each).",
    ],
}

# --------------------------------------------------------------------------
# IFC plumbing
# --------------------------------------------------------------------------
SCHEMA = "IFC4"
_GUID_COUNTER = [0]


def _new_guid():
    """Deterministic IFC GlobalId: uuid5 over a fixed namespace and a counter.

    ifcopenshell.guid.new() would make every run produce different bytes; the
    contract asks for a deterministic script, so the identity of each entity is
    derived from its position in the (deterministic) creation order.
    """
    import uuid
    _GUID_COUNTER[0] += 1
    name = "dc_model/hall_seed000_d000/mep_routing/%d" % _GUID_COUNTER[0]
    return _guid.compress(str(uuid.uuid5(uuid.NAMESPACE_URL, name)))
FACING_ROT = {"NORTH": 0.0, "WEST": 90.0, "SOUTH": 180.0, "EAST": 270.0}

CLS = {
    "rack": ("IfcFurniture", "USERDEFINED", "Rack"),
    "crah": ("IfcUnitaryEquipment", "AIRCONDITIONINGUNIT", None),
    "pdu": ("IfcElectricDistributionBoard", "DISTRIBUTIONBOARD", None),
    "column": ("IfcColumn", None, None),
    "raised_floor": ("IfcCovering", "FLOORING", None),
    "containment": ("IfcCovering", "CLADDING", None),
    "sprinkler": ("IfcFireSuppressionTerminal", "SPRINKLER", None),
    "cable_tray": ("IfcCableCarrierSegment", "CABLETRAYSEGMENT", None),
    "busway": ("IfcCableSegment", "BUSBARSEGMENT", None),
    "chw_pipe": ("IfcPipeSegment", "RIGIDSEGMENT", None),
}


def _pt(f, xy, z=None):
    return f.create_entity("IfcCartesianPoint",
                           Coordinates=tuple(float(v) for v in
                                             ((xy[0], xy[1]) if z is None else (xy[0], xy[1], z))))


def _dir(f, ratios):
    return f.create_entity("IfcDirection", DirectionRatios=tuple(float(v) for v in ratios))


def _rect_profile(f, w, d):
    """2D closed profile, five points, as the drawing set's own elements use."""
    corners = [(0.0, 0.0), (w, 0.0), (w, d), (0.0, d), (0.0, 0.0)]
    poly = f.create_entity("IfcPolyline", Points=[_pt(f, c) for c in corners])
    return f.create_entity("IfcArbitraryClosedProfileDef",
                           ProfileType="AREA", OuterCurve=poly)


def _solid(f, w, d, h):
    origin = f.create_entity("IfcCartesianPoint", Coordinates=(0.0, 0.0, 0.0))
    axis = f.create_entity("IfcAxis2Placement3D", Location=origin,
                           Axis=_dir(f, (0, 0, 1)), RefDirection=_dir(f, (1, 0, 0)))
    return f.create_entity("IfcExtrudedAreaSolid",
                           SweptArea=_rect_profile(f, w, d), Position=axis,
                           ExtrudedDirection=_dir(f, (0, 0, 1)), Depth=float(h))


class Model:
    def __init__(self):
        f = ifcopenshell.file(schema=SCHEMA)
        self.f = f
        length = f.create_entity("IfcSIUnit", UnitType="LENGTHUNIT",
                                 Prefix="MILLI", Name="METRE")
        area = f.create_entity("IfcSIUnit", UnitType="AREAUNIT", Name="SQUARE_METRE")
        volume = f.create_entity("IfcSIUnit", UnitType="VOLUMEUNIT", Name="CUBIC_METRE")
        units = f.create_entity("IfcUnitAssignment", Units=[area, volume, length])
        origin = f.create_entity("IfcCartesianPoint", Coordinates=(0.0, 0.0, 0.0))
        world = f.create_entity("IfcAxis2Placement3D", Location=origin,
                                Axis=_dir(f, (0, 0, 1)), RefDirection=_dir(f, (1, 0, 0)))
        ctx = f.create_entity("IfcGeometricRepresentationContext",
                              ContextIdentifier="Model", ContextType="Model",
                              CoordinateSpaceDimension=3, Precision=1.0e-5,
                              WorldCoordinateSystem=world)
        self.body = f.create_entity("IfcGeometricRepresentationSubContext",
                                    ContextIdentifier="Body", ContextType="Model",
                                    ParentContext=ctx, TargetView="MODEL_VIEW")
        self.project = f.create_entity("IfcProject", GlobalId=_new_guid(),
                                       Name="DC Model", UnitsInContext=units,
                                       RepresentationContexts=[ctx])
        self.site = f.create_entity("IfcSite", GlobalId=_new_guid(), Name="SITE")
        self.building = f.create_entity("IfcBuilding", GlobalId=_new_guid(), Name="DC-01")
        self.storey = f.create_entity("IfcBuildingStorey", GlobalId=_new_guid(),
                                      Name="LEVEL 1", Elevation=0.0)
        f.create_entity("IfcRelAggregates", GlobalId=_new_guid(),
                        RelatingObject=self.project, RelatedObjects=[self.site])
        f.create_entity("IfcRelAggregates", GlobalId=_new_guid(),
                        RelatingObject=self.site, RelatedObjects=[self.building])
        f.create_entity("IfcRelAggregates", GlobalId=_new_guid(),
                        RelatingObject=self.building, RelatedObjects=[self.storey])
        self.storey_placement = f.create_entity(
            "IfcLocalPlacement", RelativePlacement=f.create_entity(
                "IfcAxis2Placement3D", Location=f.create_entity(
                    "IfcCartesianPoint", Coordinates=(0.0, 0.0, 0.0))))
        self.elements = []
        self.space = None

    # -- geometry ---------------------------------------------------------
    def box(self, kind, name, box, facing="NORTH", psets=None):
        return self._element(kind, name, box, facing, psets)

    def _element(self, kind, name, box, facing, psets, space=None):
        f = self.f
        x0, y0, z0, x1, y1, z1 = (float(v) for v in box)
        w, d, h = x1 - x0, y1 - y0, z1 - z0
        rot = FACING_ROT[facing]
        # The placement rotation is the facing; the two profile dimensions swap
        # for the quarter turns so the solid still lands on the drawn footprint.
        if rot == 0.0:
            loc, ref, pw, pd = (x0, y0, z0), (1.0, 0.0, 0.0), w, d
        elif rot == 90.0:
            loc, ref, pw, pd = (x1, y0, z0), (0.0, 1.0, 0.0), d, w
        elif rot == 180.0:
            loc, ref, pw, pd = (x1, y1, z0), (-1.0, 0.0, 0.0), w, d
        else:
            loc, ref, pw, pd = (x0, y1, z0), (0.0, -1.0, 0.0), d, w
        placement = f.create_entity(
            "IfcLocalPlacement", PlacementRelTo=self.storey_placement,
            RelativePlacement=f.create_entity(
                "IfcAxis2Placement3D",
                Location=f.create_entity("IfcCartesianPoint",
                                         Coordinates=tuple(loc)),
                Axis=_dir(f, (0, 0, 1)), RefDirection=_dir(f, ref)))
        shape = f.create_entity("IfcShapeRepresentation", ContextOfItems=self.body,
                                RepresentationIdentifier="Body",
                                RepresentationType="SweptSolid",
                                Items=[_solid(f, pw, pd, h)])
        product = f.create_entity("IfcProductDefinitionShape",
                                  Representations=[shape])
        cls, predefined, object_type = CLS[kind]
        kwargs = dict(GlobalId=_new_guid(), Name=name, ObjectPlacement=placement,
                      Representation=product)
        if object_type is not None:
            kwargs["ObjectType"] = object_type
        if predefined is not None:
            kwargs["PredefinedType"] = predefined
        element = f.create_entity(cls, **kwargs)
        self.elements.append(element)
        if psets:
            self._psets(element, psets)
        return element

    def _psets(self, element, psets):
        f = self.f
        for pset_name, props in psets.items():
            values = []
            for key, value in props.items():
                if isinstance(value, bool):
                    nominal = f.create_entity("IfcBoolean", bool(value))
                elif isinstance(value, int):
                    nominal = f.create_entity("IfcInteger", int(value))
                elif isinstance(value, float):
                    nominal = f.create_entity("IfcReal", float(value))
                else:
                    nominal = f.create_entity("IfcLabel", str(value))
                values.append(f.create_entity("IfcPropertySingleValue",
                                              Name=key, NominalValue=nominal))
            pset = f.create_entity("IfcPropertySet", GlobalId=_new_guid(),
                                   Name=pset_name, HasProperties=values)
            f.create_entity("IfcRelDefinesByProperties", GlobalId=_new_guid(),
                            RelatedObjects=[element], RelatingPropertyDefinition=pset)

    # -- the hall ----------------------------------------------------------
    def add_hall(self):
        f = self.f
        space = f.create_entity(
            "IfcSpace", GlobalId=_new_guid(), Name="DATA HALL 1",
            ObjectPlacement=self.storey_placement,
            Representation=f.create_entity(
                "IfcProductDefinitionShape",
                Representations=[f.create_entity(
                    "IfcShapeRepresentation", ContextOfItems=self.body,
                    RepresentationIdentifier="Body", RepresentationType="SweptSolid",
                    Items=[_solid(f, HALL_W, HALL_D, HALL_H)])]),
            CompositionType="ELEMENT", PredefinedType="INTERNAL",
            ElevationWithFlooring=0.0)
        self.space = space
        f.create_entity("IfcRelAggregates", GlobalId=_new_guid(),
                        RelatingObject=self.storey, RelatedObjects=[space])

    # -- fit-out -----------------------------------------------------------
    def add_fitout(self):
        self.box("raised_floor", "ACCESS FLOOR PANELS",
                 (0.0, 0.0, -PANEL_T, HALL_W, HALL_D, 0.0))
        for name, x0, y0 in COLUMNS:
            self.box("column", name, (x0, y0, 0.0, x0 + 600.0, y0 + 600.0, SOFFIT))
        for name, x0, y0, x1, y1, z0, z1 in CONTAINMENT:
            self.box("containment", name, (x0, y0, z0, x1, y1, z1))
        for name, cx, cy, deflector in SPRINKLERS:
            top = SOFFIT if deflector > CLEAR_HEIGHT else deflector + 100.0
            self.box("sprinkler", name,
                     (cx - 13.0, cy - 13.0, deflector, cx + 13.0, cy + 13.0, top))
        for row_id, y0, y1, facing, bays in ROWS:
            depth = y1 - y0
            for index, (x0, width, cabinet_type) in enumerate(bays, start=1):
                name = "RACK-%s%02d" % (row_id, index)
                self.box("rack", name, (x0, y0, 0.0, x0 + width, y1, 2000.0),
                         facing=facing,
                         psets={"Pset_DCM_Rack": {
                             "RackUnits": 42,
                             "WidthMM": float(width),
                             "DepthMM": float(depth),
                             "TileCoordinate": tile_address(x0, y0),
                             "RowId": row_id,
                             "FacingDirection": facing,
                             "CabinetType": cabinet_type,
                         }})
        for (name, x0, y0, x1, y1, facing, height, capacity, airflow,
             placement) in CRAHS:
            self.box("crah", name, (x0, y0, 0.0, x1, y1, height), facing=facing,
                     psets={"Pset_DCM_Cooling": {
                         "CapacityKW": float(capacity),
                         "AirflowM3H": float(airflow),
                         "FacingDirection": facing,
                         "Placement": placement,
                     }})
        for name, x0, y0, x1, y1, facing, height, kva, serves_row in PDUS:
            self.box("pdu", name, (x0, y0, 0.0, x1, y1, height), facing=facing,
                     psets={"Pset_DCM_Power": {
                         "RatingKVA": float(kva),
                         "ServesRow": serves_row,
                         "FacingDirection": facing,
                     }})

    # -- the routes --------------------------------------------------------
    def add_routes(self):
        height = {"cable_tray": TRAY_H, "busway": BUS_H, "chw_pipe": CHW_OD}
        lanes = {"cable_tray": LANE_TRAY, "busway": LANE_BUS, "chw_pipe": LANE_CHW}
        bands = {"cable_tray": BANDS_TRAY, "busway": BANDS_BUS, "chw_pipe": BANDS_CHW}
        prefixes = {"cable_tray": "CT", "busway": "BW", "chw_pipe": "CHW"}
        self.route_segments = []
        for service in COVERAGE_SERVICES:
            lx0, lx1 = lanes[service]
            top_under = Z_UNDER_TOP
            bottom_under = Z_UNDER_TOP - height[service]
            z0 = Z_OVERHEAD
            z1 = Z_OVERHEAD + height[service]
            band_list = bands[service]
            prefix = prefixes[service]
            trunk_y0 = band_list[0][0]
            trunk_y1 = band_list[-1][1]
            if service == "chw_pipe":
                trunk_y0 = CHW_SPUR_Y[0]
            self._route(service, prefix + "-T01", (lx0, trunk_y0, bottom_under,
                                                   lx1, trunk_y1, top_under))
            for index, (by0, by1) in enumerate(band_list, start=1):
                self._route(service, "%s-R%02d" % (prefix, index),
                            (lx0, by0, top_under, lx1, by1, z0))
                self._route(service, "%s-B%02d" % (prefix, index),
                            (lx1, by0, z0, ROUTE_EAST, by1, z1))
        # chilled water spur along the south side of the PDU line to the SE CRAH
        self._route("chw_pipe", "CHW-S01",
                    (LANE_CHW[1], CHW_SPUR_Y[0], Z_UNDER_TOP - CHW_OD,
                     CHW_SPUR_EAST, CHW_SPUR_Y[1], Z_UNDER_TOP))

    def _route(self, service, name, box):
        x0, y0, z0, x1, y1, z1 = box
        axis = "X" if (x1 - x0) >= max(y1 - y0, z1 - z0) else (
            "Y" if (y1 - y0) >= (z1 - z0) else "Z")
        length = max(x1 - x0, y1 - y0, z1 - z0)
        element = self.box(service, name, box, facing="NORTH",
                           psets={"Pset_DCM_Route": {
                               "Service": {"cable_tray": "telecom",
                                           "busway": "power",
                                           "chw_pipe": "chilled_water"}[service],
                               "Axis": axis,
                               "LengthMM": float(round(length, 1)),
                           }})
        self.route_segments.append(element)
        return element

    # -- output ------------------------------------------------------------
    def write(self, out_path):
        f = self.f
        if self.space is not None:
            f.create_entity("IfcRelContainedInSpatialStructure",
                            GlobalId=_new_guid(), RelatedElements=self.elements,
                            RelatingStructure=self.space)
        f.write(out_path)


def tile_address(x_mm, y_mm):
    """The access-floor tile an element's south-west corner stands in.

    A-101 note 3: 600 mm grid from the south-west internal corner, columns
    lettered eastward, rows numbered northward.
    """
    column = int(round(x_mm / 600.0))
    row = int(round(y_mm / 600.0)) + 1
    letters = ""
    value = column
    while True:
        letters = chr(ord("A") + value % 26) + letters
        value = value // 26 - 1
        if value < 0:
            break
    return "%s%02d" % (letters, row)


def build(out_path):
    model = Model()
    model.add_hall()
    model.add_fitout()
    model.add_routes()
    model.write(out_path)
    return model


def main(argv):
    out_path = argv[1] if len(argv) > 1 else "output/model.ifc"
    build(out_path)
    # the contract asks for a file that validates with the EXPRESS rules on
    model = ifcopenshell.open(out_path)
    logger = ifcopenshell.validate.json_logger()
    ifcopenshell.validate.validate(model, logger, express_rules=True)
    if logger.statements:
        raise SystemExit("EXPRESS validation failed: %s"
                         % str(logger.statements[0])[:400])
    try:
        import json
        import os
        os.makedirs("output", exist_ok=True)
        with open(os.path.join("output", "reconciliation.json"), "w") as handle:
            json.dump(RECONCILIATION, handle, indent=2)
    except OSError:
        pass
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
