
# --------------------------------------------------------------------------
# IFC plumbing
# --------------------------------------------------------------------------
SCHEMA = "IFC4"
_GUID_COUNTER = [0]


def _new_guid():
    """Deterministic IFC GlobalId: uuid5 over a fixed namespace and a counter.

    ifcopenshell.guid.new() would make every run produce different bytes; the
    contract asks for a deterministic script, so the identity of each entity is
    derived from its position in the (deterministic) creation order.
    """
    import uuid
    _GUID_COUNTER[0] += 1
    name = "dc_model/hall_seed000_d000/mep_routing/%d" % _GUID_COUNTER[0]
    return _guid.compress(str(uuid.uuid5(uuid.NAMESPACE_URL, name)))
FACING_ROT = {"NORTH": 0.0, "WEST": 90.0, "SOUTH": 180.0, "EAST": 270.0}

CLS = {
    "rack": ("IfcFurniture", "USERDEFINED", "Rack"),
    "crah": ("IfcUnitaryEquipment", "AIRCONDITIONINGUNIT", None),
    "pdu": ("IfcElectricDistributionBoard", "DISTRIBUTIONBOARD", None),
    "column": ("IfcColumn", None, None),
    "raised_floor": ("IfcCovering", "FLOORING", None),
    "containment": ("IfcCovering", "CLADDING", None),
    "sprinkler": ("IfcFireSuppressionTerminal", "SPRINKLER", None),
    "cable_tray": ("IfcCableCarrierSegment", "CABLETRAYSEGMENT", None),
    "busway": ("IfcCableSegment", "BUSBARSEGMENT", None),
    "chw_pipe": ("IfcPipeSegment", "RIGIDSEGMENT", None),
}


def _pt(f, xy, z=None):
    return f.create_entity("IfcCartesianPoint",
                           Coordinates=tuple(float(v) for v in
                                             ((xy[0], xy[1]) if z is None else (xy[0], xy[1], z))))


def _dir(f, ratios):
    return f.create_entity("IfcDirection", DirectionRatios=tuple(float(v) for v in ratios))


def _rect_profile(f, w, d):
    """2D closed profile, five points, as the drawing set's own elements use."""
    corners = [(0.0, 0.0), (w, 0.0), (w, d), (0.0, d), (0.0, 0.0)]
    poly = f.create_entity("IfcPolyline", Points=[_pt(f, c) for c in corners])
    return f.create_entity("IfcArbitraryClosedProfileDef",
                           ProfileType="AREA", OuterCurve=poly)


def _solid(f, w, d, h):
    origin = f.create_entity("IfcCartesianPoint", Coordinates=(0.0, 0.0, 0.0))
    axis = f.create_entity("IfcAxis2Placement3D", Location=origin,
                           Axis=_dir(f, (0, 0, 1)), RefDirection=_dir(f, (1, 0, 0)))
    return f.create_entity("IfcExtrudedAreaSolid",
                           SweptArea=_rect_profile(f, w, d), Position=axis,
                           ExtrudedDirection=_dir(f, (0, 0, 1)), Depth=float(h))


class Model:
    def __init__(self):
        f = ifcopenshell.file(schema=SCHEMA)
        self.f = f
        length = f.create_entity("IfcSIUnit", UnitType="LENGTHUNIT",
                                 Prefix="MILLI", Name="METRE")
        area = f.create_entity("IfcSIUnit", UnitType="AREAUNIT", Name="SQUARE_METRE")
        volume = f.create_entity("IfcSIUnit", UnitType="VOLUMEUNIT", Name="CUBIC_METRE")
        units = f.create_entity("IfcUnitAssignment", Units=[area, volume, length])
        origin = f.create_entity("IfcCartesianPoint", Coordinates=(0.0, 0.0, 0.0))
        world = f.create_entity("IfcAxis2Placement3D", Location=origin,
                                Axis=_dir(f, (0, 0, 1)), RefDirection=_dir(f, (1, 0, 0)))
        ctx = f.create_entity("IfcGeometricRepresentationContext",
                              ContextIdentifier="Model", ContextType="Model",
                              CoordinateSpaceDimension=3, Precision=1.0e-5,
                              WorldCoordinateSystem=world)
        self.body = f.create_entity("IfcGeometricRepresentationSubContext",
                                    ContextIdentifier="Body", ContextType="Model",
                                    ParentContext=ctx, TargetView="MODEL_VIEW")
        self.project = f.create_entity("IfcProject", GlobalId=_new_guid(),
                                       Name="DC Model", UnitsInContext=units,
                                       RepresentationContexts=[ctx])
        self.site = f.create_entity("IfcSite", GlobalId=_new_guid(), Name="SITE")
        self.building = f.create_entity("IfcBuilding", GlobalId=_new_guid(), Name="DC-01")
        self.storey = f.create_entity("IfcBuildingStorey", GlobalId=_new_guid(),
                                      Name="LEVEL 1", Elevation=0.0)
        f.create_entity("IfcRelAggregates", GlobalId=_new_guid(),
                        RelatingObject=self.project, RelatedObjects=[self.site])
        f.create_entity("IfcRelAggregates", GlobalId=_new_guid(),
                        RelatingObject=self.site, RelatedObjects=[self.building])
        f.create_entity("IfcRelAggregates", GlobalId=_new_guid(),
                        RelatingObject=self.building, RelatedObjects=[self.storey])
        self.storey_placement = f.create_entity(
            "IfcLocalPlacement", RelativePlacement=f.create_entity(
                "IfcAxis2Placement3D", Location=f.create_entity(
                    "IfcCartesianPoint", Coordinates=(0.0, 0.0, 0.0))))
        self.elements = []
        self.space = None

    # -- geometry ---------------------------------------------------------
    def box(self, kind, name, box, facing="NORTH", psets=None):
        return self._element(kind, name, box, facing, psets)

    def _element(self, kind, name, box, facing, psets, space=None):
        f = self.f
        x0, y0, z0, x1, y1, z1 = (float(v) for v in box)
        w, d, h = x1 - x0, y1 - y0, z1 - z0
        rot = FACING_ROT[facing]
        # The placement rotation is the facing; the two profile dimensions swap
        # for the quarter turns so the solid still lands on the drawn footprint.
        if rot == 0.0:
            loc, ref, pw, pd = (x0, y0, z0), (1.0, 0.0, 0.0), w, d
        elif rot == 90.0:
            loc, ref, pw, pd = (x1, y0, z0), (0.0, 1.0, 0.0), d, w
        elif rot == 180.0:
            loc, ref, pw, pd = (x1, y1, z0), (-1.0, 0.0, 0.0), w, d
        else:
            loc, ref, pw, pd = (x0, y1, z0), (0.0, -1.0, 0.0), d, w
        placement = f.create_entity(
            "IfcLocalPlacement", PlacementRelTo=self.storey_placement,
            RelativePlacement=f.create_entity(
                "IfcAxis2Placement3D",
                Location=f.create_entity("IfcCartesianPoint",
                                         Coordinates=tuple(loc)),
                Axis=_dir(f, (0, 0, 1)), RefDirection=_dir(f, ref)))
        shape = f.create_entity("IfcShapeRepresentation", ContextOfItems=self.body,
                                RepresentationIdentifier="Body",
                                RepresentationType="SweptSolid",
                                Items=[_solid(f, pw, pd, h)])
        product = f.create_entity("IfcProductDefinitionShape",
                                  Representations=[shape])
        cls, predefined, object_type = CLS[kind]
        kwargs = dict(GlobalId=_new_guid(), Name=name, ObjectPlacement=placement,
                      Representation=product)
        if object_type is not None:
            kwargs["ObjectType"] = object_type
        if predefined is not None:
            kwargs["PredefinedType"] = predefined
        element = f.create_entity(cls, **kwargs)
        self.elements.append(element)
        if psets:
            self._psets(element, psets)
        return element

    def _psets(self, element, psets):
        f = self.f
        for pset_name, props in psets.items():
            values = []
            for key, value in props.items():
                if isinstance(value, bool):
                    nominal = f.create_entity("IfcBoolean", bool(value))
                elif isinstance(value, int):
                    nominal = f.create_entity("IfcInteger", int(value))
                elif isinstance(value, float):
                    nominal = f.create_entity("IfcReal", float(value))
                else:
                    nominal = f.create_entity("IfcLabel", str(value))
                values.append(f.create_entity("IfcPropertySingleValue",
                                              Name=key, NominalValue=nominal))
            pset = f.create_entity("IfcPropertySet", GlobalId=_new_guid(),
                                   Name=pset_name, HasProperties=values)
            f.create_entity("IfcRelDefinesByProperties", GlobalId=_new_guid(),
                            RelatedObjects=[element], RelatingPropertyDefinition=pset)

    # -- the hall ----------------------------------------------------------
    def add_hall(self):
        f = self.f
        space = f.create_entity(
            "IfcSpace", GlobalId=_new_guid(), Name="DATA HALL 1",
            ObjectPlacement=self.storey_placement,
            Representation=f.create_entity(
                "IfcProductDefinitionShape",
                Representations=[f.create_entity(
                    "IfcShapeRepresentation", ContextOfItems=self.body,
                    RepresentationIdentifier="Body", RepresentationType="SweptSolid",
                    Items=[_solid(f, HALL_W, HALL_D, HALL_H)])]),
            CompositionType="ELEMENT", PredefinedType="INTERNAL",
            ElevationWithFlooring=0.0)
        self.space = space
        f.create_entity("IfcRelAggregates", GlobalId=_new_guid(),
                        RelatingObject=self.storey, RelatedObjects=[space])

    # -- fit-out -----------------------------------------------------------
    def add_fitout(self):
        self.box("raised_floor", "ACCESS FLOOR PANELS",
                 (0.0, 0.0, -PANEL_T, HALL_W, HALL_D, 0.0))
        for name, x0, y0 in COLUMNS:
            self.box("column", name, (x0, y0, 0.0, x0 + 600.0, y0 + 600.0, SOFFIT))
        for name, x0, y0, x1, y1, z0, z1 in CONTAINMENT:
            self.box("containment", name, (x0, y0, z0, x1, y1, z1))
        for name, cx, cy, deflector in SPRINKLERS:
            top = SOFFIT if deflector > CLEAR_HEIGHT else deflector + 100.0
            self.box("sprinkler", name,
                     (cx - 13.0, cy - 13.0, deflector, cx + 13.0, cy + 13.0, top))
        for row_id, y0, y1, facing, bays in ROWS:
            depth = y1 - y0
            for index, (x0, width, cabinet_type) in enumerate(bays, start=1):
                name = "RACK-%s%02d" % (row_id, index)
                self.box("rack", name, (x0, y0, 0.0, x0 + width, y1, 2000.0),
                         facing=facing,
                         psets={"Pset_DCM_Rack": {
                             "RackUnits": 42,
                             "WidthMM": float(width),
                             "DepthMM": float(depth),
                             "TileCoordinate": tile_address(x0, y0),
                             "RowId": row_id,
                             "FacingDirection": facing,
                             "CabinetType": cabinet_type,
                         }})
        for (name, x0, y0, x1, y1, facing, height, capacity, airflow,
             placement) in CRAHS:
            self.box("crah", name, (x0, y0, 0.0, x1, y1, height), facing=facing,
                     psets={"Pset_DCM_Cooling": {
                         "CapacityKW": float(capacity),
                         "AirflowM3H": float(airflow),
                         "FacingDirection": facing,
                         "Placement": placement,
                     }})
        for name, x0, y0, x1, y1, facing, height, kva, serves_row in PDUS:
            self.box("pdu", name, (x0, y0, 0.0, x1, y1, height), facing=facing,
                     psets={"Pset_DCM_Power": {
                         "RatingKVA": float(kva),
                         "ServesRow": serves_row,
                         "FacingDirection": facing,
                     }})

    # -- the routes --------------------------------------------------------
    def add_routes(self):
        height = {"cable_tray": TRAY_H, "busway": BUS_H, "chw_pipe": CHW_OD}
        lanes = {"cable_tray": LANE_TRAY, "busway": LANE_BUS, "chw_pipe": LANE_CHW}
        bands = {"cable_tray": BANDS_TRAY, "busway": BANDS_BUS, "chw_pipe": BANDS_CHW}
        prefixes = {"cable_tray": "CT", "busway": "BW", "chw_pipe": "CHW"}
        self.route_segments = []
        for service in COVERAGE_SERVICES:
            lx0, lx1 = lanes[service]
            top_under = Z_UNDER_TOP
            bottom_under = Z_UNDER_TOP - height[service]
            z0 = Z_OVERHEAD
            z1 = Z_OVERHEAD + height[service]
            band_list = bands[service]
            prefix = prefixes[service]
            trunk_y0 = band_list[0][0]
            trunk_y1 = band_list[-1][1]
            if service == "chw_pipe":
                trunk_y0 = CHW_SPUR_Y[0]
            self._route(service, prefix + "-T01", (lx0, trunk_y0, bottom_under,
                                                   lx1, trunk_y1, top_under))
            for index, (by0, by1) in enumerate(band_list, start=1):
                self._route(service, "%s-R%02d" % (prefix, index),
                            (lx0, by0, top_under, lx1, by1, z0))
                self._route(service, "%s-B%02d" % (prefix, index),
                            (lx1, by0, z0, ROUTE_EAST, by1, z1))
        # chilled water spur along the south side of the PDU line to the SE CRAH
        self._route("chw_pipe", "CHW-S01",
                    (LANE_CHW[1], CHW_SPUR_Y[0], Z_UNDER_TOP - CHW_OD,
                     CHW_SPUR_EAST, CHW_SPUR_Y[1], Z_UNDER_TOP))

    def _route(self, service, name, box):
        x0, y0, z0, x1, y1, z1 = box
        axis = "X" if (x1 - x0) >= max(y1 - y0, z1 - z0) else (
            "Y" if (y1 - y0) >= (z1 - z0) else "Z")
        length = max(x1 - x0, y1 - y0, z1 - z0)
        element = self.box(service, name, box, facing="NORTH",
                           psets={"Pset_DCM_Route": {
                               "Service": {"cable_tray": "telecom",
                                           "busway": "power",
                                           "chw_pipe": "chilled_water"}[service],
                               "Axis": axis,
                               "LengthMM": float(round(length, 1)),
                           }})
        self.route_segments.append(element)
        return element

    # -- output ------------------------------------------------------------
    def write(self, out_path):
        f = self.f
        if self.space is not None:
            f.create_entity("IfcRelContainedInSpatialStructure",
                            GlobalId=_new_guid(), RelatedElements=self.elements,
                            RelatingStructure=self.space)
        f.write(out_path)


def tile_address(x_mm, y_mm):
    """The access-floor tile an element's south-west corner stands in.

    A-101 note 3: 600 mm grid from the south-west internal corner, columns
    lettered eastward, rows numbered northward.
    """
    column = int(round(x_mm / 600.0))
    row = int(round(y_mm / 600.0)) + 1
    letters = ""
    value = column
    while True:
        letters = chr(ord("A") + value % 26) + letters
        value = value // 26 - 1
        if value < 0:
            break
    return "%s%02d" % (letters, row)


def build(out_path):
    model = Model()
    model.add_hall()
    model.add_fitout()
    model.add_routes()
    model.write(out_path)
    return model


def main(argv):
    out_path = argv[1] if len(argv) > 1 else "output/model.ifc"
    build(out_path)
    # the contract asks for a file that validates with the EXPRESS rules on
    model = ifcopenshell.open(out_path)
    logger = ifcopenshell.validate.json_logger()
    ifcopenshell.validate.validate(model, logger, express_rules=True)
    if logger.statements:
        raise SystemExit("EXPRESS validation failed: %s"
                         % str(logger.statements[0])[:400])
    try:
        import json
        import os
        os.makedirs("output", exist_ok=True)
        with open(os.path.join("output", "reconciliation.json"), "w") as handle:
            json.dump(RECONCILIATION, handle, indent=2)
    except OSError:
        pass
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
