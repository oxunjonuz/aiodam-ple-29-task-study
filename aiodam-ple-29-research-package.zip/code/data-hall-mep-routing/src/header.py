#!/usr/bin/env python3
"""Coordinated overhead MEP model for data hall 1 (dc_model hall_seed000_d000).

Built from the seven-sheet drawing set, in millimetres, as IFC4:

  A-101  equipment plan ........ row lines, columns, CRAH/PDU positions, the
                                 west service strip that carries the trunks
  A-301  building section ...... the vertical datums: finished floor +0 (35 mm
                                 access-floor panel), soffit +3600, deflector
                                 plane +3575, minimum clear height 2600,
                                 sprinkler standoff 460, structural slab -900
  A-601  cabinet + equipment .... bay sequences per row, cabinet types, CRAH and
         schedules                PDU schedules with facings
  A-602  containment / pathway .. section sizes (tray 683 x 127, busway 128 x
         sections                 147, CHW DN100 bare 114.3 insulated 25 ->
                                 168.3), the zones each service may occupy,
                                 containment roof/door data
  M-101  chilled water .......... CHW is piped to every CRAH, perimeter gallery
                                 and in-row units alike; header along every row
  E-101  busway and PDU ......... busway serves every row; tray 300 mm clear of
                                 power; the 1800 mm above a PDU is dedicated
  F-101  sprinkler grid ......... 63 ceiling heads + 16 in-aisle heads, 460 mm
                                 standoff, nothing inside the pattern zone

Routing is the contractor's to coordinate (A-602 note 1), so the three routes
below are mine.  The coordination logic, in one paragraph: the overhead zone
between the 2600 mm clear height and the 3125 mm foot of the sprinkler
pattern-development zone is 515 mm tall, which is less than
168.3 + 300 + 127, so no two services can share a column of air.  They
therefore run in three parallel lanes in the west service strip, one lane per
service, and reach every cabinet row by three transverse corridors, one per
pair of rows, at the same elevation.  The north-south trunks run in the
access-floor plenum, where TIA-942-B 8.6.2 expressly permits them, and rise
into each corridor through a riser in that corridor's own band: a trunk that
stayed overhead would have to cross the other two services' corridors at an
elevation it cannot reach.

Run:  python3 solution.py <out.ifc>
"""
import sys

import ifcopenshell
import ifcopenshell.validate
from ifcopenshell import guid as _guid

# --------------------------------------------------------------------------
# Design constants (all millimetres above finished floor unless stated)
# --------------------------------------------------------------------------
HALL_W, HALL_D, HALL_H = 27000.0, 21000.0, 3600.0   # A-101, A-301
PANEL_T = 35.0                                      # A-301: finished floor +0
SOFFIT = 3600.0                                     # A-301
DEFLECTOR = 3575.0                                  # A-301: 25.4 below soffit
CLEAR_HEIGHT = 2600.0                               # A-301 / TIA-942 5.3.4.3
SPRINKLER_STANDOFF = 460.0                          # A-301 / F-101
PATTERN_ZONE = 450.0                                # NFPA 13 10.2.7.2.1
COVERAGE_SERVICES = ("cable_tray", "busway", "chw_pipe")

# A-602 pathway section schedule (outside dimensions)
TRAY_W, TRAY_H = 683.0, 127.0       # telecom cable tray, ladder
BUS_W, BUS_H = 128.0, 147.0         # power busway
CHW_OD = 168.3                      # DN100 (114.3 bare) + 25.4 insulation
POWER_TELECOM_SEPARATION = 300.0    # E-101 note 6 / TIA-942 7.3.1 Table 2
STACK_HEADROOM = 300.0              # TIA-569-B via TIA-942 7.3.2

# Lowest overhead tier: the clear-height plane + 20 mm, as drawn on A-301
Z_OVERHEAD = 2620.0
# Under-floor trunks: top of tray 20 mm below the -35 tile underside
# (TIA-942-B 8.6.2), the three lanes stacked on a common top.
Z_UNDER_TOP = -55.0

# West service strip (A-101 keynote 2): three lanes abreast, tray / busway / CHW
LANE_TRAY = (200.0, 200.0 + TRAY_W)
LANE_BUS = (1283.0, 1283.0 + BUS_W)
LANE_CHW = (1511.0, 1511.0 + CHW_OD)

# Three transverse corridors, one per pair of rows.  Each lane sits inside the
# 2500 mm service reach of both rows it serves and clear of the structural
# column grid (y 8100-8700 and 16500-17100) and of the PDUs (y >= 2400).
BANDS_TRAY = tuple((y, y + TRAY_W) for y in (3168.3, 9018.3, 13818.3))
BANDS_BUS = tuple((y, y + BUS_W) for y in (4251.3, 10111.3, 14811.3))
BANDS_CHW = tuple((y, y + CHW_OD) for y in (2900.0, 8750.0, 14551.3))

ROUTE_EAST = 20200.0        # east face of the last cabinet bay (row F)
CHW_SPUR_Y = (1700.0, 1868.3)   # south of every PDU, feeds the SE CRAH
CHW_SPUR_EAST = 23500.0     # within 2500 mm of CRAH-04 (x 25200)

