"""Independent re-measurement of one built model with the packaged grader.

Run from a file (not stdin) so the grader's BVH child process can spawn.
"""
import sys

sys.path.insert(0, "/work/ple-solve/data-hall-mep-routing/bench/frontier_eval")

from dc_model.dcgrade.score import score_task_b  # noqa: E402


def main():
    model = sys.argv[1] if len(sys.argv) > 1 else \
        "/work/ple-solve/data-hall-mep-routing/src/model.ifc"
    report = score_task_b(
        model,
        "/work/ple-solve/data-hall-mep-routing/bench/frontier_eval/reference/ground_truth.ifc",
        l_opt_mm=260601.59999999998,
    )
    print("score %.6f objective %s status %s clashes %d"
          % (report.score or 0.0, report.objective, report.exec_status,
             report.clash_count))
    compliance = report.compliance
    print("violation_rate %s checkable %s violating %s"
          % (compliance["violation_rate"], compliance["checkable_pairs"],
             compliance["violating_pairs"]))
    for name, result in compliance["violations_by_rule"].items():
        print("  %-34s checkable=%3d violations=%d  %s"
              % (name, result["n_checkable"], result["n_violations"],
                 result["threshold"]))
    for name, result in compliance["advisory"].items():
        print("  ADV %-30s checkable=%3d violations=%d"
              % (name, result["n_checkable"], result["n_violations"]))
    for clash in report.clashes:
        print("  CLASH", clash)
    routed = report.routed_length
    print("routed total %.1f of l_opt %.1f (%.4f)"
          % (routed["total_mm"], routed["l_opt_mm"],
             routed["total_mm"] / routed["l_opt_mm"]))
    for service, length in routed["by_service"].items():
        print("   %-12s %.1f" % (service, length))
    gates = report.gates or {}
    print("gates:", {k: (v["passed"] if isinstance(v, dict) else v)
                     for k, v in gates.items()})
    conn = gates.get("gate_2_connectivity") or {}
    print("coverage:", conn.get("coverage"))
    print("unserved:", conn.get("unserved_rows"), "disconnected:",
          conn.get("disconnected"), "unreached:", conn.get("unreached_consumers"))


if __name__ == "__main__":
    main()
