import sys
sys.path.insert(0,'/work/ple-solve/data-hall-mep-routing/bench/frontier_eval')
from dc_model.dcgrade.score import score_task_b
rep=score_task_b(sys.argv[1],'/work/ple-solve/data-hall-mep-routing/bench/frontier_eval/reference/ground_truth.ifc',l_opt_mm=260601.6)
g=rep.gates['gate_2_connectivity']
print("passed", g['passed'])
print("unserved", g['unserved_rows'])
print("disconnected", g['disconnected'])
print("unreached", g['unreached_consumers'])
