#!/usr/bin/env python3
"""Fault campaign: break the model on purpose, then let the packaged grader judge it.

Every mutant is a one-line edit of the shipped solution.py; the model is rebuilt
by that mutant and graded by the real evaluator code, so a mutant that survives
is a hole in the grader - or in my understanding of it - and not an opinion.
"""
import json
import pathlib
import re
import subprocess
import sys

HERE = pathlib.Path(__file__).resolve().parent
BENCH = HERE.parent / "bench" / "frontier_eval"
sys.path.insert(0, str(BENCH))

from dc_model.dcgrade.score import score_task_b  # noqa: E402

GT = BENCH / "reference" / "ground_truth.ifc"
L_OPT = 260601.59999999998
PYTHON = "/work/venv-verifier/bin/python"

# name -> (expectation, [(old, new), ...])
MUTANTS = {
    "chw_into_pdu_space": (
        "pdu_dedicated_space",
        [("CHW_SPUR_EAST = 23500.0", "CHW_SPUR_EAST = 23500.0\nBANDS_CHW_PUSH = 1"),
         ("        # chilled water spur along the south side of the PDU line to the SE CRAH",
          "        self._route('chw_pipe', 'CHW-X01', (LANE_CHW[1], 2600.0, 2620.0, 22700.0, 2768.3, 2788.3))\n"
          "        # chilled water spur along the south side of the PDU line to the SE CRAH")]),
    "overhead_too_low": ("clear_height", [("Z_OVERHEAD = 2620.0", "Z_OVERHEAD = 2580.0")]),
    "overhead_in_pattern_zone": ("sprinkler", [("Z_OVERHEAD = 2620.0", "Z_OVERHEAD = 3100.0")]),
    "tray_wider_than_1200": ("wide_obstruction", [
        ("        # chilled water spur along the south side of the PDU line to the SE CRAH",
         "        self._route('cable_tray', 'CT-X01', (200.0, 5700.0, -55.0, 883.0, 7000.0, 2620.0))\n"
         "        self._route('cable_tray', 'CT-X02', (883.0, 5700.0, 2620.0, 8000.0, 7000.0, 2747.0))\n"
         "        # chilled water spur along the south side of the PDU line to the SE CRAH")]),
    "power_telecom_too_close": ("power_telecom_separation",
                                [("for y in (4251.3, 10111.3, 14811.3)",
                                  "for y in (3980.0, 10111.3, 14811.3)")]),
    "no_chw_spur": ("gate_2_connectivity", [("CHW_SPUR_EAST = 23500.0", "CHW_SPUR_EAST = 1679.3")]),
    "one_riser_missing": ("gate_2_connectivity",
                          [("            for index, (by0, by1) in enumerate(band_list, start=1):",
                            "            for index, (by0, by1) in enumerate(band_list[:1] + band_list[2:], start=1):")]),
    "branches_stop_short": ("gate_2_connectivity", [("ROUTE_EAST = 20200.0", "ROUTE_EAST = 15000.0")]),
    "underfloor_tray_too_high": ("tray_below_tile", [("Z_UNDER_TOP = -55.0", "Z_UNDER_TOP = -30.0")]),
    "second_tray_tier": ("tray_stack_headroom",
                         [("        # chilled water spur along the south side of the PDU line to the SE CRAH",
                           "        self._route('cable_tray', 'CT-X01', (200.0, 3168.3, 2847.0, 883.0, 3851.3, 2974.0))\n"
                           "        # chilled water spur along the south side of the PDU line to the SE CRAH")]),
    "redundant_return_pipe": ("objective", [
        ("        # chilled water spur along the south side of the PDU line to the SE CRAH",
         "        self._route('chw_pipe', 'CHW-RET', (1679.3, 1900.0, -223.3, 23500.0, 2068.3, -55.0))\n"
         "        # chilled water spur along the south side of the PDU line to the SE CRAH")]),
}


def run(name, replacements):
    source = (HERE / "solution.py").read_text()
    patched = source
    for old, new in replacements:
        if old not in patched:
            raise SystemExit("mutant %s: pattern not found: %r" % (name, old[:60]))
        patched = patched.replace(old, new, 1)
    out_py = HERE / ("mutant_%s.py" % name)
    out_py.write_text(patched)
    out_ifc = HERE / ("mutant_%s.ifc" % name)
    proc = subprocess.run([PYTHON, str(out_py), str(out_ifc)],
                          capture_output=True, text=True)
    if proc.returncode != 0:
        return {"name": name, "built": False,
                "error": proc.stderr[-600:]}
    report = score_task_b(str(out_ifc), str(GT), l_opt_mm=L_OPT)
    rules = report.compliance["violations_by_rule"]
    firing = sorted(k for k, v in rules.items() if v["n_violations"])
    gates = {k: (v["passed"] if isinstance(v, dict) else v)
             for k, v in (report.gates or {}).items()}
    return {"name": name, "built": True, "score": report.score,
            "status": report.exec_status, "clashes": report.clash_count,
            "violating_rules": firing,
            "n_violations": sum(v["n_violations"] for v in rules.values()),
            "gates": gates,
            "length": report.routed_length["total_mm"] if report.routed_length else None}


def main():
    results = []
    for name, (expect, replacements) in MUTANTS.items():
        result = run(name, replacements)
        result["expected"] = expect
        ok = False
        if result.get("built"):
            score = result["score"] or 0.0
            caught = (score < 1.0 - 1e-9)
            named = any(expect.split("_")[0] in rule for rule in result["violating_rules"])
            gate = expect.startswith("gate_") and not all(
                v for v in result["gates"].values())
            obj = expect == "objective" and score < 1.0
            ok = caught and (named or gate or obj)
            result["caught"] = caught
        result["verdict"] = "CAUGHT" if ok else "SURVIVED"
        results.append(result)
        print("%-26s %-10s score=%-8s rules=%-38s gates=%s"
              % (name, result["verdict"],
                 None if result.get("score") is None else round(result["score"], 6),
                 ",".join(result.get("violating_rules") or []) or "-",
                 result.get("gates")))
        if not result.get("built"):
            print("   build error:", result["error"][:300])
    survivors = [r for r in results if r["verdict"] == "SURVIVED"]
    print("\n%d mutants, %d caught, %d survived" % (len(results), len(results) - len(survivors), len(survivors)))
    (HERE / "mutations_504.json").write_text(json.dumps(results, indent=2, default=str))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
