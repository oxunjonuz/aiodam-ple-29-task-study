#!/usr/bin/env python3
"""Second path: my own reading of the built IFC, checked against the drawings.

Nothing here imports the packaged grader.  The model is read with
ifcopenshell.geom (world coordinates, metres -> millimetres) and classified by
its own IFC class / PredefinedType / ObjectType; the row envelopes, CRAH boxes
and vertical datums come from the drawing tables in layout_block.py, not from
the answer key's parsed scene.  Every number below is a re-derivation from the
sheet notes quoted in solution.py's docstring.

    python3 verify504.py <model.ifc>
"""
import sys

import ifcopenshell
import ifcopenshell.geom
import numpy as np

import layout_block as DRW   # the drawing tables (rows, CRAHs, PDUs, heads)

HALL = (0.0, 0.0, 0.0, 27000.0, 21000.0, 3600.0)
TILE_UNDERSIDE = -35.0
SOFFIT, DEFLECTOR = 3600.0, 3575.0
CLEAR_HEIGHT, STANDOFF = 2600.0, 460.0
PATTERN_ZONE, OFFSET_CAP = 450.0, 610.0
WIDE_OBSTRUCTION = 1200.0
POWER_TELECOM = 300.0
STACK_HEADROOM = 300.0
DEDICATED_SPACE = 1800.0
REACH, COVERAGE = 2500.0, 0.8
JOINT = 250.0
CLASH = 2.0
TOL = 0.05                   # geom hands back float32; 0.05 mm is below every graded threshold
L_OPT = 260601.59999999998
ENTRY = (200.0, 3359.8)      # west wall, centre of the tray corridor's west end

KIND_OF = {
    "IfcFurniture": "rack",
    "IfcUnitaryEquipment": "crah",
    "IfcElectricDistributionBoard": "pdu",
    "IfcColumn": "column",
    "IfcFireSuppressionTerminal": "sprinkler",
    "IfcCableCarrierSegment": "cable_tray",
    "IfcCableSegment": "busway",
    "IfcPipeSegment": "chw_pipe",
}
SERVICES = ("cable_tray", "busway", "chw_pipe")


def classify(product):
    kind = KIND_OF.get(product.is_a())
    if kind is None and product.is_a() == "IfcCovering":
        kind = ("raised_floor" if product.PredefinedType == "FLOORING"
                else "containment")
    return kind


def boxes(path):
    model = ifcopenshell.open(path)
    settings = ifcopenshell.geom.settings()
    settings.set("use-world-coords", True)
    products = [p for p in model.by_type("IfcElement")
                if not p.is_a("IfcFeatureElement")]
    out = []
    it = ifcopenshell.geom.iterator(settings, model, 1, include=products)
    if not it.initialize():
        raise SystemExit("geometry iterator could not start")
    while True:
        shape = it.get()
        verts = np.asarray(shape.geometry.verts, dtype=float).reshape(-1, 3) * 1000.0
        product = model.by_id(shape.id)
        out.append({"kind": classify(product), "name": product.Name,
                    "id": product.GlobalId,
                    "lo": tuple(verts.min(axis=0)), "hi": tuple(verts.max(axis=0))})
        if not it.next():
            break
    return out


def gap(a, b, axes=(0, 1, 2)):
    return max(max(a["lo"][i], b["lo"][i]) - min(a["hi"][i], b["hi"][i])
               for i in axes)


def overlaps_box(e, lo, hi):
    return all(e["lo"][i] < hi[i] and e["hi"][i] > lo[i] for i in range(3))


def plan_overlap(a, b):
    return (a["lo"][0] < b["hi"][0] and a["hi"][0] > b["lo"][0]
            and a["lo"][1] < b["hi"][1] and a["hi"][1] > b["lo"][1])


def row_boxes():
    rows = {}
    for row_id, y0, y1, _facing, bays in DRW.ROWS:
        x0 = min(b[0] for b in bays)
        x1 = max(b[0] + b[1] for b in bays)
        rows[row_id] = (x0, x1, y0, y1)
    return rows


def covered_fraction(runs, lo, hi, across_lo, across_hi, axis):
    other = 1 - axis
    spans = []
    for run in runs:
        if (run["lo"][other] > across_hi + REACH
                or run["hi"][other] < across_lo - REACH):
            continue
        a = max(run["lo"][axis], lo)
        b = min(run["hi"][axis], hi)
        if b > a:
            spans.append((a, b))
    if not spans or hi <= lo:
        return 0.0
    spans.sort()
    total, reach = 0.0, spans[0][0]
    for a, b in spans:
        a = max(a, reach)
        if b > a:
            total += b - a
            reach = b
    return total / (hi - lo)


def network_count(runs):
    seen, parts = set(), 0
    for start in runs:
        if start["id"] in seen:
            continue
        parts += 1
        stack = [start]
        seen.add(start["id"])
        while stack:
            node = stack.pop()
            for other in runs:
                if other["id"] not in seen and gap(node, other) < JOINT:
                    seen.add(other["id"])
                    stack.append(other)
    return parts


def main(path):
    els = boxes(path)
    by_kind = {}
    for e in els:
        by_kind.setdefault(e["kind"], []).append(e)
    fails, notes = [], []

    # ---- the hall is the hall -------------------------------------------
    racks, crahs, pdus = (by_kind.get(k, []) for k in ("rack", "crah", "pdu"))
    sprinklers, containments = by_kind.get("sprinkler", []), by_kind.get("containment", [])
    columns, floor = by_kind.get("column", []), by_kind.get("raised_floor", [])
    if len(racks) != sum(len(r[4]) for r in DRW.ROWS):
        fails.append("rack count %d != the scheduled %d" % (len(racks), sum(len(r[4]) for r in DRW.ROWS)))
    if len(crahs) != len(DRW.CRAHS):
        fails.append("CRAH count %d != %d" % (len(crahs), len(DRW.CRAHS)))
    if len(pdus) != len(DRW.PDUS):
        fails.append("PDU count %d != %d" % (len(pdus), len(DRW.PDUS)))
    if len(sprinklers) != len(DRW.SPRINKLERS):
        fails.append("sprinkler count %d != %d" % (len(sprinklers), len(DRW.SPRINKLERS)))
    if len(columns) != len(DRW.COLUMNS):
        fails.append("column count %d != %d" % (len(columns), len(DRW.COLUMNS)))
    if len(floor) != 1:
        fails.append("access floor: %d elements" % len(floor))
    ceiling_heads = [h for h in sprinklers if h["lo"][2] > 3000.0]
    aisle_heads = [h for h in sprinklers if h["lo"][2] <= 3000.0]
    notes.append("fit-out: %d racks, %d CRAHs, %d PDUs, %d columns, %d containment, "
                 "%d heads (%d ceiling + %d in-aisle)"
                 % (len(racks), len(crahs), len(pdus), len(columns),
                    len(containments), len(sprinklers), len(ceiling_heads),
                    len(aisle_heads)))
    if (len(ceiling_heads), len(aisle_heads)) != (63, 16):
        fails.append("heads are %d ceiling + %d in-aisle, F-101 note 1 says 63 + 16"
                     % (len(ceiling_heads), len(aisle_heads)))

    # ---- the six row envelopes the drawing schedules --------------------
    rows = row_boxes()
    services = {s: by_kind.get(s, []) for s in SERVICES}
    for service in SERVICES:
        if not services[service]:
            fails.append("no %s at all" % service)
            continue
        if network_count(services[service]) != 1:
            fails.append("%s is %d networks, not one" % (service, network_count(services[service])))
        runs = services[service]
        near_entry = any(r["lo"][0] - REACH <= ENTRY[0] <= r["hi"][0] + REACH
                         and r["lo"][1] - REACH <= ENTRY[1] <= r["hi"][1] + REACH
                         for r in runs)
        if not near_entry:
            fails.append("%s never reaches the west-wall entry" % service)
        for row_id, (x0, x1, y0, y1) in rows.items():
            frac = covered_fraction(runs, x0, x1, y0, y1, 0)
            if frac < COVERAGE:
                fails.append("%s covers row %s only %.1f%%" % (service, row_id, 100 * frac))
            notes.append("  row %s: %s coverage %.3f" % (row_id, service, frac))
    for _name, x0, y0, x1, y1, *_rest in DRW.CRAHS:
        unit = {"lo": (x0, y0), "hi": (x1, y1)}
        if not any(gap(run, unit, (0, 1)) <= REACH for run in services["chw_pipe"]):
            fails.append("CRAH %s has no chilled water within %.0f mm" % (_name, REACH))

    # ---- code compliance, re-derived from the sheet notes ---------------
    runs_all = [e for s in SERVICES for e in by_kind.get(s, [])]
    overhead = [r for r in runs_all if r["lo"][2] > 0.0]
    for run in overhead:                                    # clear height
        if run["lo"][2] < CLEAR_HEIGHT - TOL:
            fails.append("%s underside %.0f < %.0f clear height"
                         % (run["name"], run["lo"][2], CLEAR_HEIGHT))
    for head in ceiling_heads:                              # 460 below a deflector
        deflector = head["lo"][2]
        for other in els:
            if other["kind"] == "sprinkler" or not plan_overlap(head, other):
                continue
            if other["hi"][2] <= deflector and deflector - other["hi"][2] < STANDOFF - TOL:
                fails.append("%s only %.0f mm below the deflector"
                             % (other["name"], deflector - other["hi"][2]))
    for head in sprinklers:                                 # pattern-development zone
        deflector = head["lo"][2]
        for run in runs_all:
            if run["hi"][2] < deflector - PATTERN_ZONE or run["lo"][2] > deflector:
                continue
            width = min(run["hi"][0] - run["lo"][0], run["hi"][1] - run["lo"][1])
            need = min(3.0 * width, OFFSET_CAP)
            if gap(head, run, (0, 1)) < need - TOL:
                fails.append("%s inside the %.0f mm zone of %s (%.0f < %.0f)"
                             % (run["name"], PATTERN_ZONE, head["name"],
                                gap(head, run, (0, 1)), need))
    for run in runs_all + containments:                     # wide obstructions
        width = min(run["hi"][0] - run["lo"][0], run["hi"][1] - run["lo"][1])
        if width <= WIDE_OBSTRUCTION:
            continue
        beneath = any(plan_overlap(h, run) and h["hi"][2] <= run["lo"][2] + 1.0
                      for h in sprinklers)
        if not beneath:
            fails.append("%s is %.0f wide and has no head beneath it" % (run["name"], width))
    trays = by_kind.get("cable_tray", [])                   # 300 from power
    for tray in trays:
        for bus in by_kind.get("busway", []):
            if gap(tray, bus) < POWER_TELECOM - TOL:
                fails.append("%s is %.1f mm from %s" % (tray["name"], gap(tray, bus), bus["name"]))
    for lower in runs_all:                                  # 300 between stacked runs
        for upper in runs_all:
            if upper is lower or not plan_overlap(lower, upper):
                continue
            clearance = upper["lo"][2] - lower["hi"][2]
            if 0.0 <= clearance < STACK_HEADROOM - TOL and upper["kind"] != lower["kind"]:
                fails.append("%s has %.1f mm over %s" % (upper["name"], clearance, lower["name"]))
    for pdu in pdus:                                        # dedicated space
        lo = (pdu["lo"][0], pdu["lo"][1], pdu["hi"][2])
        hi = (pdu["hi"][0], pdu["hi"][1], pdu["hi"][2] + DEDICATED_SPACE)
        for pipe in by_kind.get("chw_pipe", []):
            if overlaps_box(pipe, lo, hi):
                fails.append("%s is inside the dedicated space above %s"
                             % (pipe["name"], pdu["name"]))
    for tray in trays:                                      # 20 below the tile
        if tray["hi"][2] <= TILE_UNDERSIDE:
            if TILE_UNDERSIDE - tray["hi"][2] < 20.0 - TOL:
                fails.append("%s top is %.2f below the tile underside"
                             % (tray["name"], TILE_UNDERSIDE - tray["hi"][2]))

    # ---- a horizontal run may not live inside the access-floor slab ------
    # The tile underside is only a datum; a run that pokes into the 35 mm panel
    # is inside the floor, which no drawing permits (pathways go under it or
    # over it, and only a riser crosses it).
    for run in runs_all:
        vertical = (run["hi"][2] - run["lo"][2]) > max(run["hi"][0] - run["lo"][0],
                                                       run["hi"][1] - run["lo"][1])
        if vertical:
            continue
        if run["hi"][2] > TILE_UNDERSIDE + TOL and run["lo"][2] < 0.0 - TOL:
            fails.append("%s lies inside the access-floor slab (z %.1f..%.1f)"
                         % (run["name"], run["lo"][2], run["hi"][2]))

    # ---- nothing may interpenetrate -------------------------------------
    solids = [e for e in els if e["kind"] is not None]
    for i, a in enumerate(solids):
        for b in solids[i + 1:]:
            if "raised_floor" in (a["kind"], b["kind"]) and (
                    {a["kind"], b["kind"]} & set(SERVICES)):
                continue
            if min(min(a["hi"][k], b["hi"][k]) - max(a["lo"][k], b["lo"][k])
                   for k in range(3)) > CLASH:
                fails.append("%s interpenetrates %s" % (a["name"], b["name"]))

    # ---- material ---------------------------------------------------------
    total = 0.0
    for service in SERVICES:
        length = sum(max(r["hi"][k] - r["lo"][k] for k in range(3))
                     for r in services[service])
        total += length
        notes.append("  %-11s %.1f mm in %d segments"
                     % (service, length, len(services[service])))
    notes.append("total %.1f mm against the reference route %.1f mm (%.1f%%)"
                 % (total, L_OPT, 100.0 * (total / L_OPT - 1.0)))
    if total > L_OPT + 1e-6:
        fails.append("route is %.1f mm, longer than the %.1f mm reference" % (total, L_OPT))

    for line in notes:
        print(line)
    print("\nFAILURES:", len(fails))
    for line in fails[:40]:
        print("  -", line)
    return 1 if fails else 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1] if len(sys.argv) > 1 else "model.ifc"))
