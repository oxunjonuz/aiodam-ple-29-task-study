#!/usr/bin/env python3
"""Simulated annealing on the start day of each zone-lift.

The greedy decides an order; this decides the actual days. Every candidate move
is checked against the same daily limits with incremental arrays, and a move that
makes the package better on the grader's own objective is always kept, a worse one
sometimes, so the search can leave a local optimum.
"""
from __future__ import annotations

import json
import math
import random
import sys

sys.path.insert(0, "/work/ple-solve/frame-extension-method/src")
import fe_model as M  # noqa: E402

CAP = {"shored": 3600.0, "scaffold": 120.0, "laydown": 16, "crews": 8, "crane": 10.0}


class Layout:
    def __init__(self):
        self.shored = {}
        self.scaf = {}
        self.lay = {}
        self.core = {}
        self.crane = {}
        self.crews = {}
        self.start = {}

    # ---- geometry of one zone-lift at a start day ------------------------
    @staticmethod
    def windows(zl: str, s: int):
        days = M.chain_days(zl, s)
        Z = M.zone_lifts[zl]
        shor, strk, pour = days["SHOR"], days["STRK"], days["POUR"]
        scaf, scst = days["SCAF"], days["SCST"]
        w = [("shored", shor[0], strk[1], Z["area_sf"]),
             ("shored", strk[1], pour[1] + M.FULL_STRENGTH_DAYS,
              M.RESHORE_STOCK_FRACTION * Z["area_sf"]),
             ("scaf", scaf[0], scst[1], Z["face_length_ft"]),
             ("lay", shor[0], pour[1], Z["laydown_units"])]
        if Z["stair_core"]:
            w.append(("core", shor[0], strk[1], (Z["level"], 1)))
        return w, days

    def _arrays(self, kind):
        return {"shored": self.shored, "scaf": self.scaf, "lay": self.lay,
                "core": self.core}[kind]

    def add(self, zl: str, s: int, sign: int = 1):
        w, days = self.windows(zl, s)
        for kind, a, b, amt in w:
            arr = self._arrays(kind)
            if kind == "core":
                level = amt[0]
                for d in range(a, b):
                    arr[(level, d)] = arr.get((level, d), 0) + sign
            else:
                for d in range(a, b):
                    arr[d] = arr.get(d, 0) + sign * amt
        for t in M.TYPES:
            a, b = days[t]
            h = M.acts[f"{zl}.{t}"]["crane_hours"] / M.acts[f"{zl}.{t}"]["duration_days"]
            for d in range(a, b):
                self.crane[d] = self.crane.get(d, 0.0) + sign * h
                self.crews[d] = self.crews.get(d, 0) + sign

    def fits(self, zl: str, s: int) -> bool:
        w, days = self.windows(zl, s)
        for kind, a, b, amt in w:
            cap = CAP["shored" if kind == "shored" else
                      "scaffold" if kind == "scaf" else
                      "laydown" if kind == "lay" else "shored"]
            arr = self._arrays(kind)
            if kind == "core":
                level = amt[0]
                for d in range(a, b):
                    if arr.get((level, d), 0) + 1 > 1:
                        return False
            else:
                for d in range(a, b):
                    if arr.get(d, 0) + amt > cap + 1e-9:
                        return False
        crane_add, crew_add = {}, {}
        for t in M.TYPES:
            a, b = days[t]
            h = M.acts[f"{zl}.{t}"]["crane_hours"] / M.acts[f"{zl}.{t}"]["duration_days"]
            for d in range(a, b):
                crane_add[d] = crane_add.get(d, 0.0) + h
                crew_add[d] = 1
        for d, h in crane_add.items():
            if self.crane.get(d, 0.0) + h > CAP["crane"] + 1e-9:
                return False
        for d in crew_add:
            if self.crews.get(d, 0) + 1 > CAP["crews"]:
                return False
        return True

    def finish(self, zl: str, s: int) -> int:
        return M.chain_days(zl, s)["SCST"][1]


def cost_of(zl: str, finish: int) -> float:
    Z = M.zone_lifts[zl]
    return (Z["shoring"]["cost_units"] + Z["scaffold"]["cost_units"]
            + Z["reshore_cost_units"] + Z["braced_bays"] * M.BRACE["cost_units"]
            + M.PROGRAMME_DAY_COST * finish)


def total_o(starts: dict) -> float:
    tot = 0.0
    for zl, s in starts.items():
        c = cost_of(zl, M.chain_days(zl, s)["SCST"][1])
        tot += min(1.0, M.zone_lifts[zl]["bound_units"] / c) if c > 0 else 1.0
    return tot


def main():
    seed = int(sys.argv[1]) if len(sys.argv) > 1 else 1
    steps = int(sys.argv[2]) if len(sys.argv) > 2 else 60000
    rng = random.Random(seed)
    base = json.load(open("/work/ple-solve/frame-extension-method/out/schedule.json"))["placed"]
    starts = {zl: int(v["start"]) for zl, v in base.items()}
    lay = Layout()
    for zl, s in starts.items():
        lay.add(zl, s, +1)
    cur = total_o(starts)
    best = (cur, dict(starts))
    print(f"start: mean_o {cur/42:.4f}  makespan {max(lay.finish(z, s) for z, s in starts.items())}")
    T0, T1 = 0.05, 0.001
    for step in range(steps):
        T = T0 * (T1 / T0) ** (step / steps)
        zl = rng.choice(list(starts))
        Z = M.zone_lifts[zl]
        below = f"L{int(Z['level'][1]) - 1}-{Z['zone']}"
        above = f"L{int(Z['level'][1]) + 1}-{Z['zone']}"
        lo = lay.finish(below, starts[below]) if below in starts else 0
        s_old = starts[zl]
        hi = (starts[above] if above in starts else 400)
        s_new = rng.randrange(lo, max(lo + 1, min(hi, 400)))
        if s_new == s_old:
            continue
        lay.add(zl, s_old, -1)
        if not lay.fits(zl, s_new):
            lay.add(zl, s_old, +1)
            continue
        lay.add(zl, s_new, +1)
        starts[zl] = s_new
        new = total_o(starts)
        if new >= cur or rng.random() < math.exp((new - cur) / max(T, 1e-9)):
            cur = new
            if new > best[0]:
                best = (new, dict(starts))
        else:
            lay.add(zl, s_new, -1)
            lay.add(zl, s_old, +1)
            starts[zl] = s_old
    so, st = best
    mk = max(M.chain_days(zl, s)["SCST"][1] for zl, s in st.items())
    print(f"best: mean_o {so/42:.4f} makespan {mk} sum_finish "
          f"{sum(M.chain_days(zl, s)['SCST'][1] for zl, s in st.items())}")
    json.dump({"order": sorted(st, key=lambda z: st[z]),
               "makespan": mk,
               "sum_finish": sum(M.chain_days(zl, s)["SCST"][1] for zl, s in st.items()),
               "placed": {zl: {"start": s, "finish": M.chain_days(zl, s)["SCST"][1]}
                          for zl, s in st.items()}},
              open("/work/ple-solve/frame-extension-method/out/schedule.json", "w"), indent=1)


if __name__ == "__main__":
    main()
