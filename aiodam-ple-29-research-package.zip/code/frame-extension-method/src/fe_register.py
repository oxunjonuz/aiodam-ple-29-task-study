#!/usr/bin/env python3
"""The constraint register and the method note.

Every row names the document it comes from and the clause inside it; the value
is the number the clause states, transcribed from the shipped copy of that
clause. Rows that carry no number carry no value, rather than a guess.
"""
from __future__ import annotations

import csv
from pathlib import Path

OUT = Path("/work/ple-solve/frame-extension-method/out/pkg")

CFR451 = "29 CFR 1926.451"
CFR703 = "29 CFR 1926.703"
CFR250 = "29 CFR 1926.250"
CFR34 = "29 CFR 1926.34"
CFR1408 = "29 CFR 1926.1408"
TWP = "TWP-09 revision C"

ALL = ("every zone-lift of the package (columns, shoring, scaffold, crane)")

ROWS = [
    # --- 29 CFR 1926.451, scaffolds general requirements ---------------------
    ("A scaffold and its components carry, without failure, their own weight and at least 4 times the maximum intended load", CFR451, "(a)(1)", 4, "times the maximum intended load", ALL),
    ("Scaffolds are designed by a qualified person and constructed and loaded to that design", CFR451, "(a)(6)", "", "", "the scaffold of every zone-lift"),
    ("Each working platform is fully planked between the front uprights and the guardrail supports; the open space between platform and upright leaves not more than 9.5 in", CFR451, "(b)(1)", "", "", "the plank count of every scaffold bay"),
    ("Each scaffold platform and walkway is at least 18 in wide", CFR451, "(b)(2)", 18, "in", "platform width of every bay"),
    ("The front edge of a platform stands no more than 14 in from the face unless a guardrail is erected along it", CFR451, "(b)(3)", 14, "in", "the front edge distance to the face"),
    ("Each platform end extends at least 6 in over the centreline of its support", CFR451, "(b)(4)", 6, "in", "plank end bearing"),
    ("Each end of a platform 10 ft or less in length does not cantilever more than 12 in", CFR451, "(b)(5)(i)", 12, "in", "plank end cantilever"),
    ("A scaffold whose height to base width ratio exceeds 4 to 1 is restrained against tipping by guying, tying or bracing", CFR451, "(c)(1)", 4, "height to base width ratio", "the tie design of every scaffold"),
    ("Ties go at the closest horizontal member to the 4:1 height and repeat every 20 ft vertically for scaffolds 3 ft wide or less (26 ft for wider), at each end and at horizontal intervals not exceeding 30 ft", CFR451, "(c)(1)(ii)", 20, "ft vertical interval, scaffolds 3 ft wide or less", "tie levels and tie columns"),
    ("Supported scaffold legs bear on base plates and mud sills or other adequate firm foundation", CFR451, "(c)(2)", "", "", "the scaffold base of every zone-lift"),
    ("Supported scaffold poles, legs, posts and frames are plumb and braced to prevent swaying and displacement", CFR451, "(c)(3)", "", "", "scaffold erection"),
    ("A means of access is provided where the platform is more than 2 ft above or below the point of access", CFR451, "(e)(1)", 2, "ft", "access means of every scaffold"),
    ("A scaffold more than 35 ft high has rest platforms at 35 ft maximum vertical intervals", CFR451, "(e)(2)(iii)", 35, "ft", "platform levels of every scaffold"),
    ("Direct access to or from another surface is only permitted where the scaffold is not more than 24 in horizontally from it", CFR451, "(e)(8)", 24, "in vertical", "access means of every scaffold"),
    ("Scaffolds are not loaded in excess of their maximum intended load or rated capacity", CFR451, "(f)(1)", "", "", "the duty class and plank count"),
    ("Scaffolds and components are inspected for visible defects before each workshift and after any occurrence that could affect structural integrity", CFR451, "(f)(3)", "", "", "scaffold use across the programme"),
    ("Scaffolds closer than 10 ft to power lines are not used unless the lines are de-energised or the clearance is insulated", CFR451, "(f)(6)", 10, "ft", "crane and scaffold operations near the 34.5 kV line"),
    ("Each employee on a scaffold more than 10 ft above a lower level is protected from falling", CFR451, "(g)(1)", 10, "ft", "fall protection on every scaffold level"),
    ("Guardrail systems are installed along all open sides and ends of platforms before the platform is released for use", CFR451, "(g)(4)(i)", "", "", "guardrail bays of every platform level"),
    ("Where the falling-object protection is a guardrail, the top edge of the toprail sits between 38 in and 45 in above the platform surface", CFR451, "(g)(4)(ii)", 38, "in (lower bound of the 38 to 45 in band)", "guardrail height of every scaffold"),
    # --- 29 CFR 1926.703, cast-in-place concrete ----------------------------
    ("Formwork is designed, fabricated, erected, supported, braced and maintained to carry all vertical and lateral loads without failure", CFR703, "(a)(1)", "", "", "the shoring grid and post of every zone-lift"),
    ("Drawings for the formwork, the shoring and the scaffolds, including all revisions, are available at the jobsite", CFR703, "(a)(2)", "", "", "drawing reference TW-FE-2026-014"),
    ("Shoring equipment is inspected before erection and found to be in satisfactory condition", CFR703, "(b)(1)", "", "", "shoring of every zone-lift"),
    ("Shoring equipment is inspected immediately before, during and after concrete placement", CFR703, "(b)(3)", "", "", "shoring during every pour"),
    ("Shoring sills rest on a firm, rigid and stable base with the sills bearing on the full sill area", CFR703, "(b)(5)", "", "", "the shoring base of every zone-lift"),
    ("All base plates, shore heads, extension devices and adjustment screws are in firm contact with the form and the footing", CFR703, "(b)(6)", "", "", "shoring heads of every zone-lift"),
    ("Eccentric loads on shore heads and similar members are prohibited unless the member is designed for them", CFR703, "(b)(7)", "", "", "shoring of every zone-lift"),
    ("Forms and shores are not removed from a slab until that slab is reshored as the original shores are removed", CFR703, "(b)(10)", "", "", "reshoring of every zone-lift"),
    ("Forms and shores are not removed until the concrete has gained sufficient strength to carry its own weight and the superimposed loads", CFR703, "(e)(1)", "", "", "striking day of every zone-lift"),
    ("Where the removal conditions of (e)(1)(i) are stipulated, they are set out in the plans and the concrete is tested as those conditions require", CFR703, "(e)(1)(i)", "", "", "the striking method adopted"),
    ("Reshoring is not removed until the slab it supports has gained sufficient strength to support its own weight and the superimposed loads", CFR703, "(e)(2)", "", "", "reshore removal day"),
    # --- 29 CFR 1926.250, storage -------------------------------------------
    ("The weight of stored material on a floor does not exceed the maximum safe load limit of that floor", CFR250, "(a)(2)(i)", "", "", "laydown units staged on every zone"),
    ("Aisles and passageways are kept clear for the free movement of material handling equipment and employees", CFR250, "(a)(3)", "", "", "laydown and egress routes"),
    ("Material stored inside a building under construction is not placed within 6 ft of any hoistway or floor opening", CFR250, "(b)(1)", 6, "ft from a floor opening", "laydown position on every zone"),
    # --- 29 CFR 1926.34, means of egress ------------------------------------
    ("Exits are arranged and maintained to provide free and unobstructed egress at all times the building is occupied", CFR34, "(a)", "", "", "the occupied ground floor and every level's two means of egress"),
    ("Means of egress are continually maintained free of all obstructions or impediments to full instant use", CFR34, "(c)", "", "", "every level while it is being built over the occupied floor"),
    # --- 29 CFR 1926.1408, power line safety --------------------------------
    ("The work zone is identified and the hazards of the overhead line are assessed before equipment is operated near it", CFR1408, "(a)(1)", "", "", "crane operations at every standing position"),
    ("Where the equipment could come within 20 ft of a power line, option (1), (2) or (3) of the section is used", CFR1408, "(a)(2)", 20, "ft", "the crane route adopted for every pick"),
    ("Option (3) is used: the minimum approach distance of Table A is determined and the work zone demarcated so no part of the equipment, line or load can get closer", CFR1408, "(a)(2)(iii)", "", "", "demarcated radius of every pick"),
    ("An elevated warning line, barricade or line of signs is placed at the demarcated boundary where the equipment may come within the minimum approach distance", CFR1408, "(b)(3)", "", "", "the demarcated boundary of every pick"),
    ("Table A minimum approach distance for 34.5 kV is 10 ft", CFR1408, "Table A", 10, "ft, up to 50 kV", "minimum approach distance held at every pick"),
    # --- TWP-09 revision C ---------------------------------------------------
    ("The method package is the construction sequence, the temporary-works design, the stability check sheet, the workspace and resource occupancy report, the constraint register and the method note", TWP, "1.2", "", "", "all six deliverables"),
    ("Early-strike age is the age in the concrete mix schedule at which the mix may carry its own weight under reshoring; full-strength age is 28 days", TWP, "2.3", 28, "days", "striking and reshore removal"),
    ("Every activity follows every activity it depends on; the dependencies issued in the activity list are not negotiable", TWP, "3.1", "", "", "all 294 issued activities"),
    ("The whole programme is complete by day 250 from the first working day of the first activity", TWP, "3.3", 250, "days", "the programme's completion date"),
    ("The duty class of a scaffold follows from the work it serves; a scaffold to which neither clause 5.3 nor 5.4 applies is light duty", TWP, "5.1", "", "", "the duty class of every scaffold"),
    ("The shoring design load is the slab self-weight plus 10 psf formwork plus 50 psf pump (75 psf bucket) plus 15 psf protective deck; the design load per post is that load times the square of the shore spacing and does not exceed the post rating; the post extension is not less than the zone's required extension", TWP, "6.1", "", "", "the shoring of every zone-lift"),
    ("The lateral system resists the greater of 12 psf construction wind on the exposed area and 2 per cent of the vertical load supported", TWP, "6.2", 12, "psf construction wind", "the bracing system of every zone-lift"),
    ("Forms and shores are struck at the early-strike age only where the slab is reshored as the original shores are removed; otherwise they stay until the full-strength age", TWP, "6.3", "", "", "the striking day of every zone-lift"),
    ("Reshoring is to RS-16 at 8 ft centres in both directions and is not removed until the slab reaches its full-strength age", TWP, "6.4", 8, "ft centres", "reshore posts and their removal day"),
    ("The workspace an activity needs is the volume of its zone plus the volume its temporary works occupy", TWP, "7.1", "", "", "the workspace volume of all 294 activities"),
    ("No two zone-lifts of the same zone are in progress at the same time", TWP, "7.2", "", "", "the level sequence within every zone"),
    ("Two means of egress are kept open on every level and no more than 1 stair-core zone may be shored on any one day", TWP, "7.3", 1, "stair-core zones shored at once", "shoring of the three stair-core zones"),
    ("There is one tower crane and it works 10 crane hours in a shift; the crane hours drawn on any one day do not exceed that shift", TWP, "8.1", 10, "crane hours per day", "the crane draw of every activity"),
    ("The contractor has 8 gangs; no more than that many activities are in progress on any one day", TWP, "8.2", 8, "gangs", "concurrent activities across the programme"),
    ("The yard holds shoring for 3600 square feet of soffit and 120 feet of scaffold face at any one time; reshoring occupies 25 per cent of the zone area until full strength", TWP, "8.3", 3600, "sf of soffit", "the yard stock drawn by every zone-lift"),
    ("The laydown area holds 16 units of staged material from the day a zone's shoring goes up to the day its slab is placed", TWP, "8.4", 16, "units", "the laydown units of every zone"),
    ("The crane's rated capacity at the radius from the standing position to the zone is not less than the heaviest pick and the radius does not exceed the position's maximum working radius", TWP, "9.1", "", "", "the crane position and radius of every pick"),
    ("Option (3) is adopted for the 34.5 kV line: the demarcated radius is at least the radius the zone needs and no more than the standing position's distance to the line less the Table A minimum approach", TWP, "9.2", "", "", "the demarcated radius of every pick"),
    ("A zone-lift is priced at its temporary-works cost plus 4 units for every day from the first working day of the programme to the day its last activity finishes", TWP, "10.2", 4, "units per day", "the programme cost of every zone-lift"),
]

NOTE = """\
# Method note — frame extension over an occupied ground floor

## Which document governs

Three documents in the issued set speak to the same subject and do not agree.
**TWP-09 revision C governs.** Revision B is retained in the document set marked
SUPERSEDED and is not in force: its completion date (day 310), its yard stock
(4500 sf of soffit and 160 ft of scaffold face), its ten gangs, its twelve crane
hours, its reshoring at 10 ft centres and its twenty-one day full-strength age
are all superseded, and its permission to strike at the early-strike age without
reshoring is withdrawn — which is the change that decides this package. No value
has been taken from revision B and none of its numbers appears in the register.
The baseline programme revision A is likewise superseded: its shoring durations
are two days longer than the issued activity list and it carries no scaffold
re-use logic, so it has not been used; the issued activity list is the programme
of record. Where the issued set is silent, the adopted CFR sections govern.

## Striking and reshoring method adopted

Every slab is **struck at the early-strike age and reshored**: the forms and
shores come out at day 7 (M40-PUMP) or day 4 (M50-HE) after the pour, and RS-16
posts at 8 ft centres in both directions go in on the day the original shores
come out, staying until the slab reaches its full-strength age of 28 days. The
reshoring is what buys the programme its rate: waiting for 28 days instead would
add twenty-one days to every one of the forty-two zone-lifts, and it would hold
the full soffit area in the yard for that time rather than a quarter of it.
Reshoring occupies 25 per cent of the zone area in the yard until full strength,
and that occupancy — not the crane — is the resource that paces this programme.

## The governing constraint, zone by zone

The limits are read from the corpus and applied per zone:
* **Bands A to D, every level — the shoring grid.** The design load (self-weight
  plus 10 psf formwork plus 50 psf pump, plus 15 psf protective deck on L2 zones
  A to C) is carried by SP-16 posts at 4.0 ft where the load allows it and 3.5 ft
  where it does not; SP-13 does not extend far enough (13.0 ft against the 13.83
  ft these lifts need) and RS-16 is the reshore post of clause 6.4, not a shore.
* **Bands E to G — the crane.** These bands are placed by crane and bucket, so
  the POUR draws 8 to 9.5 crane hours in a two-day pour and the scaffold is heavy
  duty: six PL-95 planks per bay, which is what closes the 9.5 in opening between
  a 47.5 in platform and a 60 in frame. Five planks would leave 12.5 in open.
* **Zones Z-A-N, Z-B-S and Z-E-S — the two means of egress.** Each carries a
  stair core, so only one of them may be shored on any one day; the programme
  never has two cores of the same level shored together.
* **Every zone — one zone-lift at a time.** The level above starts only when the
  lift below has finished in that zone, which is why each zone is a 42-day chain
  and the site is a pipeline of them.

## The margins applied

The declared capacities are never the demanded ones. Braced bays are taken at
4,000 lb each against a demand of 2 to 3 bays' worth, so the declared capacity
exceeds the demand by up to one whole bay. Planks are taken at six per bay on
heavy duty against the four-times-load requirement of five. The crane works at
radii of 38 to 82 ft against a chart that still carries 14,898 lb at 82 ft for a
heaviest pick of 8,746 lb, and the demarcated radius sits 63 ft inside the
Table A minimum approach at the nearest standing position. The programme
completes on day {makespan} against the day 250 completion date, and the peak
soffit shored is {peak_shored:.0f} sf against the 3600 sf the yard holds — a peak
utilisation of {util:.0f} per cent and an average of {util_mean:.0f} per cent over
the {makespan} days. The yard, not the crane, is what paces this package: the
crane averages {crane_mean:.1f} of its 10 hours a shift and peaks at
{crane_peak:.1f}, while the yard is saturated from day 2. The headroom kept is in
the completion date, not in the yard.

## Attribution

The building in this corpus — storey elevations, column grid and sections, slab
thickness and stair cores — is derived from the LivingBIM Dataset (DOI
10.5281/zenodo.17934615), licensed CC BY 4.0. That attribution and the CC BY 4.0
conditions are carried with anything reproduced from the design schedules here.
"""


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    with open(OUT / "constraint_register.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["requirement", "document", "clause", "value", "unit", "items_bound"])
        for req, doc, clause, value, unit, binds in ROWS:
            w.writerow([req, doc, clause, value, unit, binds])
    print("register rows:", len(ROWS))


if __name__ == "__main__":
    main()
