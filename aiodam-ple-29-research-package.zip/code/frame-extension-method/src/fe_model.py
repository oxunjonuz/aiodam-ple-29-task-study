#!/usr/bin/env python3
"""My own reading of the frame-extension corpus.

Everything here is parsed from the shipped CSV/MD corpus in
`ws/field_eng__constructability_4d__blind/`, not from the grader's model.json,
so that comparing the two is a real check of my reading rather than a copy.
"""
from __future__ import annotations

import csv
import math
from pathlib import Path

WS = Path("/work/ple-solve/frame-extension-method/ws/field_eng__constructability_4d__blind")


def rows(rel: str) -> list[dict]:
    with open(WS / rel, newline="", encoding="utf-8") as fh:
        return list(csv.DictReader(fh))


def fnum(x, default=None):
    try:
        return float(str(x).strip())
    except (TypeError, ValueError):
        return default


# --------------------------------------------------------------- the corpus
storeys = {r["level_id"]: {
    "index": int(r["index"]),
    "lift_base_ft": fnum(r["lift_base_ft"]),
    "soffit_ft": fnum(r["soffit_ft"]),
    "slab_top_ft": fnum(r["slab_top_ft"]),
    "clear_height_ft": fnum(r["clear_height_ft"]),
    "height_above_grade_ft": fnum(r["height_above_grade_ft"]),
    "supported_by": r["supported_by"],
} for r in rows("model/storey_schedule.csv")}

zones = {r["zone_id"]: {
    "band": r["band"], "strip": r["strip"],
    "x0": fnum(r["x0_ft"]), "x1": fnum(r["x1_ft"]),
    "y0": fnum(r["y0_ft"]), "y1": fnum(r["y1_ft"]),
    "area_sf": fnum(r["area_sf"]), "face_length_ft": fnum(r["face_length_ft"]),
    "exterior_face": r["exterior_face"],
    "stair_core": r["stair_core"].strip().lower() == "yes",
    "adjacent": [a for a in r["adjacent_zones"].split(";") if a],
} for r in rows("model/zone_schedule.csv")}

slabs = {(r["level"], r["zone"]): {
    "area_sf": fnum(r["area_sf"]), "thickness_in": fnum(r["thickness_in"]),
    "volume_cy": fnum(r["volume_cy"]), "self_weight_psf": fnum(r["self_weight_psf"]),
    "mix_id": r["mix_id"], "placement_method": r["placement_method"],
} for r in rows("model/slab_schedule.csv")}

cols = {}
for r in rows("model/column_schedule.csv"):
    key = (r["level"], r["zone"])
    cols.setdefault(key, []).append(r)

zsched = {r["zone_lift"]: {
    "level": r["level"], "zone": r["zone"],
    "area_sf": fnum(r["area_sf"]), "n_columns": int(r["n_columns"]),
    "heaviest_pick_lb": fnum(r["heaviest_pick_lb"]),
    "face_length_ft": fnum(r["face_length_ft"]),
    "scaffold_height_ft": fnum(r["scaffold_height_ft"]),
    "clear_height_ft": fnum(r["clear_height_ft"]),
    "mix_id": r["mix_id"], "laydown_units": int(r["laydown_units"]),
    "wind_exposed_sf": fnum(r["wind_exposed_sf"]),
} for r in rows("programme/zone_work_schedule.csv")}

activities = []
for r in rows("programme/activity_list.csv"):
    activities.append({
        "activity_id": r["activity_id"], "zone_lift": r["zone_lift"],
        "zone": r["zone"], "level": r["level"], "activity_type": r["activity_type"],
        "quantity": fnum(r["quantity"]), "unit": r["unit"],
        "crew_type": r["crew_type"], "duration_days": int(r["duration_days"]),
        "crane_hours": fnum(r["crane_hours"]),
        "predecessors": [p for p in r["predecessors"].split(";") if p],
    })
acts = {a["activity_id"]: a for a in activities}

occupied_below = {r["zone_lift"]: r["protection_required"]
                  for r in rows("site/existing_occupation.csv")}

crane_positions = {r["position_id"]: {
    "x_ft": fnum(r["x_ft"]), "y_ft": fnum(r["y_ft"]),
    "max_radius_ft": fnum(r["max_radius_ft"]),
    "distance_to_power_line_ft": fnum(r["distance_to_power_line_ft"]),
} for r in rows("site/crane_standing_positions.csv")}

crane_chart = [(fnum(r["radius_ft"]), fnum(r["rated_capacity_lb"]))
               for r in rows("site/crane_chart.csv")]

post_cat = {r["post_type"]: {
    "max_extension_ft": fnum(r["max_extension_ft"]),
    "rated_capacity_lb": fnum(r["rated_capacity_lb"]),
    "weight_lb": fnum(r["weight_lb"]), "cost_units": fnum(r["cost_units"]),
} for r in rows("catalogue/shoring_catalogue.csv")}

# RS-16 sits in the same catalogue but TWP-09 clause 6.4 makes it the RESHORE
# post, at 8 ft centres, not a shore under the slab: it is priced through the
# reshore, never through `shoring.post_type`.  Two post types with identical
# extension and capacity, one of them 20 % cheaper, is exactly the trap this
# exclusion is here to close.
RESHORE_POST_TYPE = "RS-16"
SHORE_POSTS = {k: v for k, v in post_cat.items() if k != RESHORE_POST_TYPE}

spacings = [fnum(r["spacing_ft"]) for r in rows("catalogue/shoring_grid_options.csv")]

scaf_cat = {r["system"]: {
    "base_width_ft": fnum(r["base_width_ft"]), "bay_length_ft": fnum(r["bay_length_ft"]),
    "frame_height_ft": fnum(r["frame_height_ft"]), "leg_ultimate_lb": fnum(r["leg_ultimate_lb"]),
    "frame_weight_lb": fnum(r["frame_weight_lb"]), "frame_cost_units": fnum(r["frame_cost_units"]),
} for r in rows("catalogue/scaffold_catalogue.csv")}

components = {r["component"]: {
    "width_in": fnum(r["width_in"]), "length_ft": fnum(r["length_ft"]),
    "ultimate_capacity_lb": fnum(r["ultimate_capacity_lb"]),
    "weight_lb": fnum(r["weight_lb"]), "cost_units": fnum(r["cost_units"]),
} for r in rows("catalogue/scaffold_components.csv")}
PLANK = components["PL-95"]
TIE = components["TIE-1"]
BRACE = components["XB-1"]

duty = {r["duty_class"]: {
    "workers": int(r["workers_per_bay"]), "worker_lb": fnum(r["worker_allowance_lb"]),
    "material_lb": fnum(r["staged_material_lb_per_bay"]),
    "max_intended": fnum(r["maximum_intended_load_lb_per_bay"]),
} for r in rows("catalogue/scaffold_duty_classes.csv")}

mixes = {r["mix_id"]: {
    "strength_psi": fnum(r["strength_psi"]), "strike_days": int(r["strike_days"]),
    "full_strength_days": int(r["full_strength_days"]), "placement": r["placement"],
} for r in rows("catalogue/concrete_mix_schedule.csv")}

# ---------------------------------------------- TWP-09 clause 6.1 parameters
FORMWORK_PSF = 10.0
LIVE_PUMP_PSF = 50.0
LIVE_BUCKET_PSF = 75.0
DECK_PSF = 15.0
FORM_DEPTH_FT = 0.75
WIND_PSF = 12.0
LATERAL_FRACTION = 0.02
RESHORE_SPACING_FT = 8.0
RESHORE_POST = {"post_type": "RS-16", "cost_units": 4.0, "rated_capacity_lb": 6000.0}
CRANE_SHIFT_HOURS = 10.0
SHORING_STOCK_SF = 3600.0
SCAFFOLD_STOCK_FT = 120.0
RESHORE_STOCK_FRACTION = 0.25
CREW_CAP = 8
LAYDOWN_CAPACITY = 16
EGRESS_CORES_MAX = 1
DEADLINE_DAYS = 250
PROGRAMME_DAY_COST = 4.0
FULL_STRENGTH_DAYS = 28
POWER_KV = 34.5
TABLE_A_FT = 10.0
OPTION2_CLEARANCE_FT = 20.0
BEARING_PSF = 2000.0
PLATFORM_MIN_WIDTH_IN = 18.0
PLATFORM_FRONT_EDGE_MAX_IN = 14.0
RATIO_LIMIT = 4.0
TIE_STEP_NARROW_FT = 20.0
TIE_STEP_WIDE_FT = 26.0
TIE_HORIZ_MAX_FT = 30.0
REST_PLATFORM_FT = 35.0
FALL_PROTECTION_FT = 10.0
GUARDRAIL_MIN_IN, GUARDRAIL_MAX_IN = 38.0, 45.0
OPEN_GAP_MAX_IN = 9.5


def crane_capacity(radius: float) -> float:
    if radius <= crane_chart[0][0]:
        return crane_chart[0][1]
    for (r0, c0), (r1, c1) in zip(crane_chart, crane_chart[1:]):
        if radius <= r1:
            t = (radius - r0) / (r1 - r0)
            return c0 + t * (c1 - c0)
    return 0.0


# ------------------------------------------------------------- zone-lift ids
zone_lifts = {}
for level, st in storeys.items():
    for zone, Z in zones.items():
        zl = f"{level}-{zone}"
        if zl not in zsched:
            continue
        slab = slabs[(level, zone)]
        occupied = zl in occupied_below
        bucket = slab["placement_method"] == "crane_bucket"
        design_psf = (slab["self_weight_psf"] + FORMWORK_PSF
                      + (LIVE_BUCKET_PSF if bucket else LIVE_PUMP_PSF)
                      + (DECK_PSF if occupied else 0.0))
        if bucket or Z["band"] >= "E":
            duty_class = "heavy"
        elif occupied:
            duty_class = "medium"
        else:
            duty_class = "light"
        zone_lifts[zl] = {
            "zone_lift": zl, "level": level, "zone": zone,
            "area_sf": Z["area_sf"], "face_length_ft": Z["face_length_ft"],
            "clear_height_ft": st["clear_height_ft"],
            "height_above_grade_ft": st["height_above_grade_ft"],
            "stair_core": Z["stair_core"], "adjacent": Z["adjacent"],
            "laydown_units": zsched[zl]["laydown_units"],
            "heaviest_pick_lb": zsched[zl]["heaviest_pick_lb"],
            "mix_id": slab["mix_id"],
            "strike_days": mixes[slab["mix_id"]]["strike_days"],
            "placement_method": slab["placement_method"],
            "occupied_below": occupied,
            "shoring_design_load_psf": design_psf,
            "required_extension_ft": round(st["soffit_ft"] - st["lift_base_ft"], 3) - FORM_DEPTH_FT,
            "wind_exposed_sf": zsched[zl]["wind_exposed_sf"],
            "scaffold_duty": duty_class,
            "level_index": st["index"],
        }

for zl, Z in zone_lifts.items():
    Z["supported_vertical_load_lb"] = Z["shoring_design_load_psf"] * Z["area_sf"]
    Z["lateral_demand_lb"] = max(WIND_PSF * Z["wind_exposed_sf"],
                                 LATERAL_FRACTION * Z["supported_vertical_load_lb"])
    Z["crane"] = {}
    cx = (zones[Z["zone"]]["x0"] + zones[Z["zone"]]["x1"]) / 2.0
    cy = (zones[Z["zone"]]["y0"] + zones[Z["zone"]]["y1"]) / 2.0
    best = None
    for pid, P in crane_positions.items():
        r = math.hypot(P["x_ft"] - cx, P["y_ft"] - cy)
        cap = crane_capacity(r)
        if r <= P["max_radius_ft"] + 1e-9 and cap >= Z["heaviest_pick_lb"] - 1e-9:
            if best is None or r < best[1]:
                best = (pid, r, cap)
    if best is None:
        raise SystemExit(f"{zl}: no crane position can make the pick")
    Z["crane"] = {"position": best[0], "radius_ft": best[1],
                  "rated_capacity_lb": best[2]}


# ------------------------------------------------------------------- design
def choose_shoring(Z) -> dict:
    """Cheapest admissible shore post + grid for the zone-lift (clause 6.1)."""
    best = None
    for ptype, P in SHORE_POSTS.items():
        if P["max_extension_ft"] + 1e-9 < Z["required_extension_ft"]:
            continue
        for s in spacings:
            load = Z["shoring_design_load_psf"] * s * s
            if load > P["rated_capacity_lb"] + 1e-6:
                continue
            n = math.ceil(Z["area_sf"] / (s * s))
            cost = n * P["cost_units"]
            key = (cost, load, -s)
            if best is None or key < best[0]:
                best = (key, {"post_type": ptype, "spacing_ft": s, "posts": n,
                              "design_load_per_post_lb": load,
                              "cost_units": cost,
                              "rated_capacity_lb": P["rated_capacity_lb"]})
    if best is None:
        raise SystemExit(f"{Z['zone_lift']}: no post carries the design load")
    return best[1]


def tie_levels(height_ft: float, base_ft: float, frame_ft: float) -> list[float]:
    """29 CFR 1926.451(c)(1)(ii) via TWP-09 4.4: ties at the 4:1 height and
    every 20 ft (base <= 3 ft) or 26 ft (base > 3 ft), on the horizontal members."""
    if base_ft <= 0 or height_ft / base_ft <= RATIO_LIMIT + 1e-9:
        return []
    n = int(math.floor(height_ft / frame_ft))
    members = [round(k * frame_ft, 3) for k in range(1, n + 1)]
    if not members:
        return []
    step = TIE_STEP_NARROW_FT if base_ft <= 3.0 else TIE_STEP_WIDE_FT
    four = RATIO_LIMIT * base_ft
    out, t = [], four
    while t <= height_ft + 1e-9:
        lv = min(members, key=lambda m: (abs(m - t), m))
        if lv not in out:
            out.append(lv)
        t += step
    if not out:
        out.append(members[-1])
    if height_ft - out[-1] > four + 1e-9:
        out.append(members[-1])
    return sorted(set(out))


def choose_scaffold(Z) -> dict:
    """Cheapest admissible scaffold for the zone-lift's face and duty class."""
    h = Z["height_above_grade_ft"]
    face = Z["face_length_ft"]
    d = duty[Z["scaffold_duty"]]
    intended = d["workers"] * d["worker_lb"] + d["material_lb"]
    best = None
    for sid, S in scaf_cat.items():
        bays = math.ceil(face / S["bay_length_ft"])
        lifts = math.ceil(h / S["frame_height_ft"])
        frames = (bays + 1) * lifts
        per_bay = max(
            math.ceil(4.0 * intended / (PLANK["ultimate_capacity_lb"] - PLANK["weight_lb"])),
            math.ceil(PLATFORM_MIN_WIDTH_IN / PLANK["width_in"]),
            math.ceil((S["base_width_ft"] * 12.0 - OPEN_GAP_MAX_IN) / PLANK["width_in"]),
        )
        width_in = per_bay * PLANK["width_in"]
        if width_in < PLATFORM_MIN_WIDTH_IN - 1e-9:
            continue
        if width_in > S["base_width_ft"] * 12.0 + 1e-6:
            continue
        ratio = h / S["base_width_ft"]
        levels_n = 1 + (0 if h <= REST_PLATFORM_FT else math.ceil(h / REST_PLATFORM_FT) - 1)
        own = frames * S["frame_weight_lb"] / 2.0
        if S["leg_ultimate_lb"] < own + 2.0 * intended * levels_n - 1e-9:
            continue
        tlev = tie_levels(h, S["base_width_ft"], S["frame_height_ft"])
        tcols = max(2, math.ceil(face / TIE_HORIZ_MAX_FT) + 1)
        ties = len(tlev) * tcols
        planks = bays * per_bay * levels_n
        # TWP-09 10.1 prices a guardrail bay along an open side OR across one end
        # of a platform level: `bays` along the face plus the two ends, on every
        # platform level, because 4.7 requires them on all open sides and ends.
        rails = (bays + 2) * levels_n
        cost = (frames * S["frame_cost_units"] + planks * PLANK["cost_units"]
                + ties * TIE["cost_units"] + rails * 1.0)
        key = (cost, sid)
        if best is None or key < best[0]:
            best = (key, {
                "system": sid, "base_width_ft": S["base_width_ft"], "bays": bays,
                "frame_lifts": lifts, "frames": frames, "planks_per_bay": per_bay,
                "platform_width_in": width_in,
                "platform_capacity_lb": per_bay * PLANK["ultimate_capacity_lb"],
                "platform_levels": levels_n, "planks": planks,
                "guardrail_height_in": 42.0, "guardrails": rails,
                "height_ft": h, "height_to_base_ratio": ratio,
                "tie_levels_ft": tlev, "tie_columns": tcols, "ties": ties,
                "maximum_intended_load_lb": intended,
                "front_edge_gap_in": 12.0, "front_edge_guardrail": "yes",
                "mudsill": "yes",
                "bearing_pressure_psf": round(4.0 * intended * levels_n
                                              / (S["base_width_ft"] * 4.0), 1),
                "access_means": "stair_tower", "fall_protection": "both",
                "cost_units": cost,
            })
    if best is None:
        raise SystemExit(f"{Z['zone_lift']}: no scaffold system fits the face")
    return best[1]


for zl, Z in zone_lifts.items():
    Z["shoring"] = choose_shoring(Z)
    Z["scaffold"] = choose_scaffold(Z)
    Z["braced_bays"] = math.ceil(Z["lateral_demand_lb"] / BRACE["ultimate_capacity_lb"])
    Z["reshore_posts"] = math.ceil(Z["area_sf"] / RESHORE_SPACING_FT ** 2)
    Z["reshore_cost_units"] = Z["reshore_posts"] * RESHORE_POST["cost_units"]
    Z["tw_cost_units"] = (Z["shoring"]["cost_units"] + Z["scaffold"]["cost_units"]
                          + Z["reshore_cost_units"]
                          + Z["braced_bays"] * BRACE["cost_units"])


TYPES = ["COL", "SCAF", "SHOR", "RBAR", "POUR", "STRK", "SCST"]


def chain_days(zl: str, s: int) -> dict:
    """The seven activities of a zone-lift laid out from its start day, on the
    issued durations and the strength-gain age the mix demands."""
    a = {t: acts[f"{zl}.{t}"] for t in TYPES}
    dur = {t: a[t]["duration_days"] for t in TYPES}
    strike = zone_lifts[zl]["strike_days"]
    col = (s, s + dur["COL"])
    scaf = (s, s + dur["SCAF"])
    t0 = max(col[1], scaf[1])
    shor = (t0, t0 + dur["SHOR"])
    rbar = (shor[1], shor[1] + dur["RBAR"])
    pour = (rbar[1], rbar[1] + dur["POUR"])
    strk = (pour[1] + strike, pour[1] + strike + dur["STRK"])
    scst = (strk[1], strk[1] + dur["SCST"])
    return {"COL": col, "SCAF": scaf, "SHOR": shor, "RBAR": rbar,
            "POUR": pour, "STRK": strk, "SCST": scst}


# ---------------------------------------------------------------------- CPM
ZONE_OF = {zl: (Z["level"], Z["zone"]) for zl, Z in zone_lifts.items()}


def cpm() -> dict:
    """Earliest start/finish over the issued logic, with the strength-gain age
    the issued mix demands (the plan this package adopts is reshored, so the
    early-strike age governs), plus the zone-exclusivity edge of TWP-09 7.2."""
    est = {}

    def dur(aid):
        return acts[aid]["duration_days"]

    def lag(aid):
        # STRK waits for the concrete: the early-strike age when reshored
        if acts[aid]["activity_type"] == "STRK":
            zl = acts[aid]["zone_lift"]
            return zone_lifts[zl]["strike_days"]
        return 0

    order = sorted(acts)
    changed = True
    while changed:
        changed = False
        for aid in order:
            a = acts[aid]
            ready = 0.0
            for p in a["predecessors"]:
                if p not in est:
                    ready = None
                    break
                ready = max(ready, est[p][1] + lag(aid))
            # zone exclusivity: a level starts only once the lift below is done
            zl = a["zone_lift"]
            lvl, zone = ZONE_OF[zl]
            below = f"L{int(lvl[1]) - 1}-{zone}"
            if below in zone_lifts and a["activity_type"] in ("COL", "SCAF"):
                fin = est.get(f"{below}.SCST")
                if fin is None:
                    ready = None
                elif ready is not None:
                    ready = max(ready, fin[1])
            if ready is None:
                continue
            new = (ready, ready + dur(aid))
            if est.get(aid) != new:
                est[aid] = new
                changed = True
    return est


_est = cpm()
for _zl, _Z in zone_lifts.items():
    _cpm_fin = _est[f"{_zl}.SCST"][1]
    _Z["cpm_finish_day"] = _cpm_fin
    _Z["bound_units"] = (_Z["shoring"]["cost_units"] + _Z["scaffold"]["cost_units"]
                         + _Z["braced_bays"] * BRACE["cost_units"]
                         + PROGRAMME_DAY_COST * _cpm_fin)


if __name__ == "__main__":
    est = cpm()
    print(f"{'zone_lift':12s} {'tw':>5s} {'cpm_fin':>7s} {'bound?':>7s}  shoring / scaffold")
    for zl in sorted(zone_lifts):
        Z = zone_lifts[zl]
        fin = est[f"{zl}.SCST"][1]
        print(f"{zl:12s} {Z['tw_cost_units']:5.0f} {fin:7.0f} "
              f"{Z['tw_cost_units'] + PROGRAMME_DAY_COST * fin:7.0f}  "
              f"{Z['shoring']['post_type']}@{Z['shoring']['spacing_ft']}x{Z['shoring']['posts']} "
              f"/ {Z['scaffold']['system']} b{Z['scaffold']['bays']} p{Z['scaffold']['planks_per_bay']}")
