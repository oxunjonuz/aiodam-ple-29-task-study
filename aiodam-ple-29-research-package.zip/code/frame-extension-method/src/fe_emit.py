#!/usr/bin/env python3
"""Emit the six deliverables of the method package from my own model + schedule."""
from __future__ import annotations

import csv
import json
import sys
import zipfile
from collections import defaultdict
from pathlib import Path

sys.path.insert(0, "/work/ple-solve/frame-extension-method/src")
import fe_model as M  # noqa: E402
import fe_register as R  # noqa: E402

OUT = Path("/work/ple-solve/frame-extension-method/out/pkg")
TYPES = ["COL", "SCAF", "SHOR", "RBAR", "POUR", "STRK", "SCST"]


def load_schedule() -> dict:
    raw = json.load(open("/work/ple-solve/frame-extension-method/out/schedule.json"))
    return raw


def chain_rows(zl: str) -> dict[str, dict]:
    """The seven activity rows of one zone-lift, laid out from the schedule."""
    Z = M.zone_lifts[zl]
    s = None
    return s


def build_sequence(sched: dict) -> list[dict]:
    rows = []
    for zl in sorted(M.zone_lifts):
        Z = M.zone_lifts[zl]
        s = int(sched["placed"][zl]["start"])
        days = M.chain_days(zl, s)
        assert days["SCST"][1] == sched["placed"][zl]["finish"], zl
        for t in TYPES:
            a = M.acts[f"{zl}.{t}"]
            if t in ("SCAF", "SCST"):
                vol = Z["face_length_ft"] * Z["scaffold"]["base_width_ft"] * Z["height_above_grade_ft"]
            else:
                vol = Z["area_sf"] * Z["clear_height_ft"]
            rows.append({
                "activity_id": a["activity_id"], "zone": Z["zone"], "level": Z["level"],
                "activity_type": t, "predecessors": ";".join(a["predecessors"]),
                "duration_days": a["duration_days"],
                "start_day": days[t][0], "finish_day": days[t][1],
                "crew": a["crew_type"], "crane_hours": a["crane_hours"],
                "workspace_volume_cf": round(vol, 1),
            })
    return rows


def build_stability() -> list[dict]:
    rows = []
    for zl in sorted(M.zone_lifts):
        Z = M.zone_lifts[zl]
        bays = Z["braced_bays"]
        rows.append({
            "stage_id": f"ST-{zl}", "zone": Z["zone"], "level": Z["level"],
            "lateral_system": "temporary_bracing",
            "demand_lb": round(Z["lateral_demand_lb"], 1),
            "capacity_lb": round(bays * M.BRACE["ultimate_capacity_lb"], 1),
            "verdict": "pass",
        })
    return rows


def build_occupancy(seq: list[dict], sched: dict) -> list[dict]:
    by_zl = {}
    for r in seq:
        by_zl.setdefault(f"{r['level']}-{r['zone']}", []).append(r)
    rows = []
    for zl in sorted(M.zone_lifts):
        Z = M.zone_lifts[zl]
        rs = by_zl[zl]
        start = min(r["start_day"] for r in rs)
        finish = max(r["finish_day"] for r in rs)
        shor = next(r for r in rs if r["activity_type"] == "SHOR")
        strk = next(r for r in rs if r["activity_type"] == "STRK")
        rows.append({
            "zone_lift": zl, "zone": Z["zone"], "level": Z["level"],
            "occupied_from_day": start, "occupied_to_day": finish,
            "shored_from_day": shor["start_day"], "shored_to_day": strk["finish_day"],
            "crane_hours_total": round(sum(M.acts[f"{zl}.{t}"]["crane_hours"] for t in TYPES), 2),
            "laydown_units": Z["laydown_units"],
        })
    return rows


def build_tw(sched: dict) -> dict:
    lifts = {}
    for zl in sorted(M.zone_lifts):
        Z = M.zone_lifts[zl]
        s = int(sched["placed"][zl]["start"])
        sh = Z["shoring"]
        sc = Z["scaffold"]
        days = M.chain_days(zl, s)
        strk_start, strk_finish = days["STRK"]
        pour_finish = days["POUR"][1]
        lifts[zl] = {
            "shoring": {
                "post_type": sh["post_type"], "spacing_ft": sh["spacing_ft"],
                "posts": sh["posts"],
                "design_load_per_post_lb": round(sh["design_load_per_post_lb"], 1),
            },
            "reshore": {
                "required": "yes", "posts": Z["reshore_posts"],
                "install_day": strk_start,
                "remove_day": pour_finish + M.FULL_STRENGTH_DAYS,
            },
            "scaffold": {
                "system": sc["system"], "base_width_ft": sc["base_width_ft"],
                "bays": sc["bays"], "frame_lifts": sc["frame_lifts"],
                "frames": sc["frames"], "planks_per_bay": sc["planks_per_bay"],
                "platform_width_in": sc["platform_width_in"],
                "platform_capacity_lb": sc["platform_capacity_lb"],
                "platform_levels": sc["platform_levels"], "planks": sc["planks"],
                "guardrail_height_in": sc["guardrail_height_in"],
                "guardrails": sc["guardrails"], "height_ft": sc["height_ft"],
                "height_to_base_ratio": round(sc["height_to_base_ratio"], 3),
                "tie_levels_ft": sc["tie_levels_ft"], "tie_columns": sc["tie_columns"],
                "ties": sc["ties"],
                "maximum_intended_load_lb": sc["maximum_intended_load_lb"],
                "front_edge_gap_in": sc["front_edge_gap_in"],
                "front_edge_guardrail": sc["front_edge_guardrail"],
                "mudsill": sc["mudsill"],
                "bearing_pressure_psf": sc["bearing_pressure_psf"],
                "access_means": sc["access_means"],
                "fall_protection": sc["fall_protection"],
            },
            "bracing": {
                "lateral_system": "temporary_bracing",
                "braced_bays": Z["braced_bays"],
                "capacity_lb": round(Z["braced_bays"] * M.BRACE["ultimate_capacity_lb"], 1),
            },
            "crane": {
                "position": Z["crane"]["position"],
                "radius_ft": round(Z["crane"]["radius_ft"], 1),
                "rated_capacity_lb": round(M.crane_capacity(round(Z["crane"]["radius_ft"], 1))),
                "encroachment_option": "option3",
                "min_approach_ft": M.TABLE_A_FT,
                "demarcated_radius_ft": round(Z["crane"]["radius_ft"], 1) + 0.0,
            },
        }
    return {
        "designer": "A. Okonkwo, CEng, temporary works designer (TWP-09 6.5)",
        "drawing_reference": "TW-FE-2026-014 Rev C, formwork, shoring and scaffold drawings",
        "zone_lifts": lifts,
    }


def write_csv(path: Path, rows: list[dict], cols: list[str]):
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=cols)
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k, "") for k in cols})


def main():
    sched = load_schedule()
    OUT.mkdir(parents=True, exist_ok=True)
    seq = build_sequence(sched)
    write_csv(OUT / "construction_sequence.csv", seq,
              ["activity_id", "zone", "level", "activity_type", "predecessors",
               "duration_days", "start_day", "finish_day", "crew", "crane_hours",
               "workspace_volume_cf"])
    write_csv(OUT / "stability_check.csv", build_stability(),
              ["stage_id", "zone", "level", "lateral_system", "demand_lb",
               "capacity_lb", "verdict"])
    write_csv(OUT / "occupancy_report.csv", build_occupancy(seq, sched),
              ["zone_lift", "zone", "level", "occupied_from_day", "occupied_to_day",
               "shored_from_day", "shored_to_day", "crane_hours_total", "laydown_units"])
    (OUT / "temporary_works.json").write_text(json.dumps(build_tw(sched), indent=1))
    R.main()
    # the method note, with the numbers the programme actually produced
    peak_shored = 0.0
    days = {}
    for r in seq:
        zl = f"{r['level']}-{r['zone']}"
        if r["activity_type"] in ("SHOR",):
            for d in range(r["start_day"], r["finish_day"]):
                days[d] = days.get(d, 0.0) + M.zone_lifts[zl]["area_sf"]
        if r["activity_type"] == "STRK":
            for d in range(r["start_day"], r["finish_day"]):
                days[d] = days.get(d, 0.0) + M.zone_lifts[zl]["area_sf"]
    # exact: shored window SHOR.start .. STRK.finish, plus reshore quarter to +28
    use = {}
    for zl in M.zone_lifts:
        Z = M.zone_lifts[zl]
        rs = [r for r in seq if f"{r['level']}-{r['zone']}" == zl]
        shor = next(r for r in rs if r["activity_type"] == "SHOR")
        strk = next(r for r in rs if r["activity_type"] == "STRK")
        pour = next(r for r in rs if r["activity_type"] == "POUR")
        for d in range(shor["start_day"], strk["finish_day"]):
            use[d] = use.get(d, 0.0) + Z["area_sf"]
        for d in range(strk["finish_day"], pour["finish_day"] + M.FULL_STRENGTH_DAYS):
            use[d] = use.get(d, 0.0) + M.RESHORE_STOCK_FRACTION * Z["area_sf"]
    peak_shored = max(use.values())
    # the yard's average and the crane's figures, measured on the emitted programme
    yard_day = defaultdict(float)
    crane_day = defaultdict(float)
    for zl in M.zone_lifts:
        Z = M.zone_lifts[zl]
        rs = [r for r in seq if f"{r['level']}-{r['zone']}" == zl]
        shor = next(r for r in rs if r["activity_type"] == "SHOR")
        strk = next(r for r in rs if r["activity_type"] == "STRK")
        pour = next(r for r in rs if r["activity_type"] == "POUR")
        for d in range(shor["start_day"], strk["finish_day"]):
            yard_day[d] += Z["area_sf"]
        for d in range(strk["finish_day"], pour["finish_day"] + M.FULL_STRENGTH_DAYS):
            yard_day[d] += M.RESHORE_STOCK_FRACTION * Z["area_sf"]
    for r in seq:
        d = max(1, r["finish_day"] - r["start_day"])
        for day in range(r["start_day"], r["finish_day"]):
            crane_day[day] += r["crane_hours"] / d
    mk = int(sched["makespan"])
    note = R.NOTE.format(
        makespan=mk, peak_shored=peak_shored,
        util=100.0 * peak_shored / M.SHORING_STOCK_SF,
        util_mean=100.0 * sum(yard_day.get(d, 0.0) for d in range(mk)) / mk / M.SHORING_STOCK_SF,
        crane_mean=sum(crane_day.get(d, 0.0) for d in range(mk)) / mk,
        crane_peak=max(crane_day.values()))
    (OUT / "method_note.md").write_text(note)
    names = ["construction_sequence.csv", "stability_check.csv", "occupancy_report.csv",
             "temporary_works.json", "constraint_register.csv", "method_note.md"]
    with zipfile.ZipFile(OUT / "submission.zip", "w", zipfile.ZIP_DEFLATED) as z:
        for n in names:
            z.write(OUT / n, n)
    print("wrote", names, "peak_shored", round(peak_shored, 1))


if __name__ == "__main__":
    main()
