#!/usr/bin/env python3
"""A resource-constrained programme for the frame extension, on my own model.

Objective: the grader prices a zone-lift at its temporary works plus 4 units for
every day to the day it finishes, so the schedule is chosen to minimise the sum
of finish days subject to the site's shared limits:

  crane 10 h/day, 8 gangs, 3600 sf of soffit shored, 120 ft of scaffold face,
  16 laydown units, one shored stair core per level, the 250-day completion date
  and one zone-lift at a time in a zone.

The same rules are re-implemented in fe_check.py from the corpus, so a schedule
this file likes is not accepted on this file's word alone.
"""
from __future__ import annotations

import heapq
import itertools
import json
import math
import random
import sys
from collections import defaultdict

sys.path.insert(0, "/work/ple-solve/frame-extension-method/src")
import fe_model as M  # noqa: E402

TYPES = ["COL", "SCAF", "SHOR", "RBAR", "POUR", "STRK", "SCST"]


class Chain:
    """One zone-lift's seven activities, laid out from its start day."""

    def __init__(self, zl: str, s: float):
        Z = M.zone_lifts[zl]
        a = {t: M.acts[f"{zl}.{t}"] for t in TYPES}
        dur = {t: a[t]["duration_days"] for t in TYPES}
        self.zl, self.s = zl, s
        self.pd = dur["POUR"]
        self.strike = Z["strike_days"]
        self.area = Z["area_sf"]
        self.face = Z["face_length_ft"]
        self.lay = Z["laydown_units"]
        self.core = Z["stair_core"]
        self.level = Z["level"]
        self.hours = {t: a[t]["crane_hours"] / a[t]["duration_days"] for t in TYPES}
        # windows (start, end) on the day axis, from the ISSUED durations
        self.col = (s, s + dur["COL"])
        self.scaf = (s, s + dur["SCAF"])
        t0 = max(self.col[1], self.scaf[1])
        self.shor = (t0, t0 + dur["SHOR"])
        self.rbar = (self.shor[1], self.shor[1] + dur["RBAR"])
        self.pour = (self.rbar[1], self.rbar[1] + dur["POUR"])
        self.strk = (self.pour[1] + self.strike, self.pour[1] + self.strike + dur["STRK"])
        self.scst = (self.strk[1], self.strk[1] + dur["SCST"])
        self.finish = self.scst[1]

    def crane_days(self):
        out = []
        for t in TYPES:
            a, b = getattr(self, t.lower())
            for d in range(int(a), int(b)):
                out.append((d, self.hours[t]))
        return out

    def windows(self):
        """(resource, kind, start, end, amount, key) tuples."""
        out = [
            ("shored", "add", self.shor[0], self.strk[1], self.area, None),
            # the grader charges the reshoring to the SAME yard pool as the
            # shored soffit (TWP-09 8.3): 25 % of the area until full strength
            ("shored", "add", self.strk[1], self.pour[1] + M.FULL_STRENGTH_DAYS,
             M.RESHORE_STOCK_FRACTION * self.area, None),
            ("scaffold", "add", self.scaf[0], self.scst[1], self.face, None),
            ("laydown", "add", self.shor[0], self.pour[1], self.lay, None),
        ]
        # only a stair-core zone is a core: the egress rule counts cores shored
        if self.core:
            out.append(("core", "add", self.shor[0], self.strk[1], 1, (self.level,)))
        return out


CAPS = {"crane": M.CRANE_SHIFT_HOURS, "crews": M.CREW_CAP, "shored": M.SHORING_STOCK_SF,
        "scaffold": M.SCAFFOLD_STOCK_FT, "laydown": M.LAYDOWN_CAPACITY}


class Board:
    def __init__(self):
        self.use = defaultdict(float)
        self.core = defaultdict(int)

    def fits(self, ch: Chain) -> bool:
        # accumulate within the chain first: two of its activities may fall on
        # the same day (COL and SCAF both stand on day s)
        crane_add, crew_add = {}, {}
        for d, h in ch.crane_days():
            crane_add[d] = crane_add.get(d, 0.0) + h
        for d in {d for d, _ in ch.crane_days()}:
            crew_add[d] = 1
        for d, h in crane_add.items():
            if self.use[("crane", d)] + h > CAPS["crane"] + 1e-9:
                return False
        for d in crew_add:
            if self.use[("crews", d)] + 1 > CAPS["crews"]:
                return False
        for kind, _op, a, b, amt, key in ch.windows():
            if kind == "core":
                for d in range(a, b):
                    if self.core[(ch.level, d)] + 1 > M.EGRESS_CORES_MAX:
                        return False
            else:
                for d in range(a, b):
                    if self.use[(kind, d)] + amt > CAPS[kind] + 1e-9:
                        return False
        return True

    def place(self, ch: Chain):
        for d, h in ch.crane_days():
            self.use[("crane", d)] += h
            self.use[("crews", d)] += 1
        for kind, _op, a, b, amt, key in ch.windows():
            if kind == "core":
                for d in range(a, b):
                    self.core[(ch.level, d)] += 1
            else:
                for d in range(a, b):
                    self.use[(kind, d)] += amt


def earliest(board: Board, zl: str, floor_day: float, horizon: int = 300):
    for s in range(int(math.ceil(floor_day)), horizon):
        ch = Chain(zl, s)
        if board.fits(ch):
            return ch
    return None


def schedule(order: list[str]) -> dict:
    board = Board()
    placed = {}
    floor = {zl: 0 for zl in M.zone_lifts}
    for zl in order:
        Zl = M.zone_lifts[zl]
        below = f"L{int(Zl['level'][1]) - 1}-{Zl['zone']}"
        if below in M.zone_lifts and below not in placed:
            return {"ok": False}
        ch = earliest(board, zl, floor[zl])
        if ch is None:
            return {"ok": False}
        board.place(ch)
        placed[zl] = ch
        zone = M.zone_lifts[zl]["zone"]
        lvl = M.zone_lifts[zl]["level"]
        nxt = f"L{int(lvl[1]) + 1}-{zone}"
        if nxt in M.zone_lifts:
            floor[nxt] = ch.finish
    sum_o = 0.0
    for zl, c in placed.items():
        Z = M.zone_lifts[zl]
        cost = (Z["shoring"]["cost_units"] + Z["scaffold"]["cost_units"]
                + Z["reshore_cost_units"] + Z["braced_bays"] * M.BRACE["cost_units"]
                + M.PROGRAMME_DAY_COST * c.finish)
        bnd = Z["bound_units"]
        sum_o += min(1.0, bnd / cost) if cost > 0 else 1.0
    return {"ok": True, "placed": placed,
            "sum_finish": sum(c.finish for c in placed.values()),
            "sum_o": sum_o, "mean_o": sum_o / len(placed),
            "makespan": max(c.finish for c in placed.values())}


def topological_orders(rng: random.Random) -> list[str]:
    """A random order that keeps L2 before L3 before L4 within a zone."""
    zones = sorted({M.zone_lifts[z]["zone"] for z in M.zone_lifts})
    levels = ["L2", "L3", "L4"]
    order = []
    # pick jobs whose level-below is already placed
    remaining = set(M.zone_lifts)
    while remaining:
        ready = [z for z in remaining
                 if f"L{int(M.zone_lifts[z]['level'][1]) - 1}-{M.zone_lifts[z]['zone']}"
                 not in remaining]
        z = rng.choice(sorted(ready))
        order.append(z)
        remaining.discard(z)
    return order


def level_major() -> list[str]:
    return [f"{lv}-{zn}" for lv in ("L2", "L3", "L4")
            for zn in sorted({z.split('-', 1)[1] for z in M.zone_lifts})
            if f"{lv}-{zn}" in M.zone_lifts]


def main():
    seed = int(sys.argv[1]) if len(sys.argv) > 1 else 7
    rng = random.Random(seed)
    best = None
    cands = [level_major()]
    for _ in range(400):
        cands.append(topological_orders(rng))
    # adjacent-swap refinement of the best few
    scored = []
    for i, order in enumerate(cands):
        r = schedule(order)
        if r["ok"]:
            scored.append((r["sum_finish"], r["makespan"], order))
    scored.sort(key=lambda x: (x[0], x[1]))
    print(f"multi-start: best sum_finish {scored[0][0]:.0f} "
          f"makespan {scored[0][1]:.0f} over {len(scored)} feasible orders")
    pool = [o for _, _, o in scored[:6]]
    for order in pool:
        cur = list(order)
        cur_score = schedule(cur)["sum_finish"]
        for _ in range(3000):
            i, j = rng.randrange(len(cur)), rng.randrange(len(cur))
            if i == j:
                continue
            trial = list(cur)
            trial[i], trial[j] = trial[j], trial[i]
            # keep the zone precedence legal
            pos = {z: k for k, z in enumerate(trial)}
            ok = all(pos[f"L2-{M.zone_lifts[z]['zone']}"] < pos[f"L3-{M.zone_lifts[z]['zone']}"]
                     < pos[f"L4-{M.zone_lifts[z]['zone']}"]
                     for z in M.zone_lifts if M.zone_lifts[z]["level"] == "L2")
            if not ok:
                continue
            r = schedule(trial)
            if r["ok"] and r["sum_finish"] < cur_score - 1e-9:
                cur, cur_score = trial, r["sum_finish"]
        if best is None or cur_score < best[0]:
            best = (cur_score, cur)
    r = schedule(best[1])
    print(f"refined: sum_finish {r['sum_finish']:.0f} makespan {r['makespan']:.0f}")
    out = {zl: {"start": c.s, "finish": c.finish} for zl, c in r["placed"].items()}
    json.dump({"order": best[1], "sum_finish": r["sum_finish"],
               "makespan": r["makespan"], "placed": out},
              open("/work/ple-solve/frame-extension-method/out/schedule.json", "w"),
              indent=1)
    print("written out/schedule.json")


if __name__ == "__main__":
    main()
