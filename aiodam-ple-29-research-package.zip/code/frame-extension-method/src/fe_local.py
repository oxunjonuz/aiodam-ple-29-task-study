#!/usr/bin/env python3
"""Randomised greedy + repeated left-shift, on my own feasibility model.

The greedy keeps the pipeline full; the left-shift pass then walks the jobs from
the latest finish backwards and pulls each one as early as the yard, the crane,
the gangs, the laydown and the egress rule allow while everything else stays put.
"""
from __future__ import annotations

import json
import random
import sys

sys.path.insert(0, "/work/ple-solve/frame-extension-method/src")
import fe_model as M  # noqa: E402
import fe_sched as S  # noqa: E402


def usage_from(placed: dict, skip: str | None = None):
    board = S.Board()
    for zl, ch in placed.items():
        if zl == skip:
            continue
        board.place(ch)
    return board


def feasible(placed: dict, zl: str, s: int) -> bool:
    board = usage_from(placed, skip=zl)
    return board.fits(S.Chain(zl, s))


def release(placed: dict, zl: str) -> int:
    Z = M.zone_lifts[zl]
    below = f"L{int(Z['level'][1]) - 1}-{Z['zone']}"
    if below in placed:
        return int(placed[below].finish)
    return 0


def objective(placed: dict) -> tuple[float, float]:
    sum_o = 0.0
    for zl, c in placed.items():
        Z = M.zone_lifts[zl]
        cost = (Z["shoring"]["cost_units"] + Z["scaffold"]["cost_units"]
                + Z["reshore_cost_units"] + Z["braced_bays"] * M.BRACE["cost_units"]
                + M.PROGRAMME_DAY_COST * c.finish)
        sum_o += min(1.0, Z["bound_units"] / cost) if cost > 0 else 1.0
    return sum_o, sum(c.finish for c in placed.values())


def greedy(rng: random.Random | None, jitter: float = 0.0) -> dict | None:
    board = S.Board()
    placed = {}
    floor = {zl: 0 for zl in M.zone_lifts}
    remaining = set(M.zone_lifts)
    while remaining:
        cands = []
        for zl in remaining:
            Zl = M.zone_lifts[zl]
            below = f"L{int(Zl['level'][1]) - 1}-{Zl['zone']}"
            if below in M.zone_lifts and below not in placed:
                continue          # the level below must stand first (TWP-09 7.2)
            ch = S.earliest(board, zl, floor[zl])
            if ch is None:
                continue
            noise = rng.random() * jitter if rng else 0.0
            cands.append((ch.s + noise, M.zone_lifts[zl]["area_sf"], zl, ch))
        if not cands:
            return None
        cands.sort(key=lambda x: (x[0], x[1], x[2]))
        _s, _a, zl, ch = cands[0]
        board.place(ch)
        placed[zl] = ch
        remaining.discard(zl)
        Z = M.zone_lifts[zl]
        nxt = f"L{int(Z['level'][1]) + 1}-{Z['zone']}"
        if nxt in M.zone_lifts:
            floor[nxt] = ch.finish
    return placed


def left_shift(placed: dict, rounds: int = 12) -> dict:
    for _ in range(rounds):
        moved = 0
        for zl in sorted(placed, key=lambda z: -placed[z].finish):
            cur = int(placed[zl].s)
            low = release(placed, zl)
            for s in range(low, cur):
                if feasible(placed, zl, s):
                    placed[zl] = S.Chain(zl, s)
                    moved += 1
                    break
        if not moved:
            break
    return placed


def main():
    seed = int(sys.argv[1]) if len(sys.argv) > 1 else 5
    rng = random.Random(seed)
    best = None
    trials = []
    trials.append(greedy(None))
    for jitter in (0.5, 1.0, 2.0, 4.0):
        for _ in range(25):
            trials.append(greedy(rng, jitter))
    for placed in trials:
        if not placed:
            continue
        placed = left_shift(placed)
        so, sf = objective(placed)
        if best is None or so > best[0]:
            best = (so, sf, placed)
    so, sf, placed = best
    print(f"best: mean_o {so/42:.4f} sum_finish {sf:.0f} "
          f"makespan {max(c.finish for c in placed.values()):.0f}")
    order = sorted(placed, key=lambda z: placed[z].s)
    json.dump({"order": order, "sum_finish": sf,
               "makespan": max(c.finish for c in placed.values()),
               "placed": {zl: {"start": c.s, "finish": c.finish} for zl, c in placed.items()}},
              open("/work/ple-solve/frame-extension-method/out/schedule.json", "w"), indent=1)
    print("written out/schedule.json")


if __name__ == "__main__":
    main()
