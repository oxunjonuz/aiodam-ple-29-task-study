#!/usr/bin/env python3
"""A better programme search: greedy that keeps the pipeline full, then local search.

At every step it asks, for each zone-lift whose zone-predecessor is placed, what
the earliest day is at which its whole chain fits the yard, the crane, the gangs,
the laydown and the egress rule, and then places the one that fits earliest --
smallest yard footprint first when several fit on the same day. That ordering
matters twice over: the objective credits a cheap zone-lift more for the same day
saved, and a small zone-lift is what fits in the yard next.
"""
from __future__ import annotations

import json
import random
import sys

sys.path.insert(0, "/work/ple-solve/frame-extension-method/src")
import fe_model as M  # noqa: E402
import fe_sched as S  # noqa: E402


def greedy(score_key, horizon: int = 320) -> dict:
    board = S.Board()
    placed = {}
    floor = {zl: 0 for zl in M.zone_lifts}
    remaining = set(M.zone_lifts)
    while remaining:
        cands = []
        for zl in remaining:
            ch = S.earliest(board, zl, floor[zl], horizon=horizon)
            if ch is not None:
                cands.append((score_key(ch), zl, ch))
        if not cands:
            return {"ok": False}
        cands.sort(key=lambda x: (x[0], x[1]))
        _k, zl, ch = cands[0]
        board.place(ch)
        placed[zl] = ch
        remaining.discard(zl)
        Z = M.zone_lifts[zl]
        nxt = f"L{int(Z['level'][1]) + 1}-{Z['zone']}"
        if nxt in M.zone_lifts:
            floor[nxt] = ch.finish
    sum_o = 0.0
    for zl, c in placed.items():
        Z = M.zone_lifts[zl]
        cost = (Z["shoring"]["cost_units"] + Z["scaffold"]["cost_units"]
                + Z["reshore_cost_units"] + Z["braced_bays"] * M.BRACE["cost_units"]
                + M.PROGRAMME_DAY_COST * c.finish)
        sum_o += min(1.0, Z["bound_units"] / cost) if cost > 0 else 1.0
    return {"ok": True, "placed": placed, "sum_o": sum_o, "mean_o": sum_o / len(placed),
            "sum_finish": sum(c.finish for c in placed.values()),
            "makespan": max(c.finish for c in placed.values())}


KEYS = {
    # earliest start, then small yard footprint
    "start_area": lambda ch: (ch.s, M.zone_lifts[ch.zl]["area_sf"]),
    # earliest start, then big footprint (fill the yard while there is room)
    "start_bigarea": lambda ch: (ch.s, -M.zone_lifts[ch.zl]["area_sf"]),
    # cheap first: smallest bound, earliest start second
    "cheap": lambda ch: (M.zone_lifts[ch.zl]["bound_units"], ch.s),
    # earliest finish of the whole chain
    "finish": lambda ch: (ch.finish, M.zone_lifts[ch.zl]["area_sf"]),
    # yard-time of the job (area x window), smallest first
    "yardtime": lambda ch: (M.zone_lifts[ch.zl]["area_sf"] * (ch.strk[1] - ch.shor[0]), ch.s),
}


def main():
    seed = int(sys.argv[1]) if len(sys.argv) > 1 else 3
    rng = random.Random(seed)
    best = None
    for name, key in KEYS.items():
        r = greedy(key)
        if r["ok"]:
            print(f"  greedy {name:14s} mean_o {r['mean_o']:.4f} sum_fin {r['sum_finish']:.0f} "
                  f"makespan {r['makespan']:.0f}")
            if best is None or r["sum_o"] > best[0]:
                best = (r["sum_o"], name, r)
    print(f"best greedy: {best[1]} mean_o {best[0]/42:.4f}")
    order = sorted(best[2]["placed"], key=lambda z: best[2]["placed"][z].s)
    cur = list(order)
    r = S.schedule(cur)
    cur_o = r["sum_o"]
    for _ in range(6000):
        i, j = rng.randrange(42), rng.randrange(42)
        if i == j:
            continue
        trial = list(cur)
        trial[i], trial[j] = trial[j], trial[i]
        pos = {z: k for k, z in enumerate(trial)}
        if not all(pos[f"L2-{M.zone_lifts[z]['zone']}"] < pos[f"L3-{M.zone_lifts[z]['zone']}"]
                   < pos[f"L4-{M.zone_lifts[z]['zone']}"]
                   for z in M.zone_lifts if M.zone_lifts[z]["level"] == "L2"):
            continue
        rr = S.schedule(trial)
        if rr["ok"] and rr["sum_o"] > cur_o + 1e-12:
            cur, cur_o = trial, rr["sum_o"]
    r = S.schedule(cur)
    print(f"after local search: mean_o {r['mean_o']:.4f} sum_fin {r['sum_finish']:.0f} "
          f"makespan {r['makespan']:.0f}")
    json.dump({"order": cur, "sum_finish": r["sum_finish"], "makespan": r["makespan"],
               "placed": {zl: {"start": c.s, "finish": c.finish}
                          for zl, c in r["placed"].items()}},
              open("/work/ple-solve/frame-extension-method/out/schedule.json", "w"), indent=1)
    print("written out/schedule.json")


if __name__ == "__main__":
    main()
