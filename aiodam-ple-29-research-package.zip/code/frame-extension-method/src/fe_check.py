#!/usr/bin/env python3
"""An independent check of the emitted package.

This reads the six delivered files as text and recomputes every rule from the
corpus CSVs with its own arithmetic, its own day simulation and its own reading
of the clauses. It shares no code path with fe_sched/fe_emit and nothing with the
grader: where it agrees with both, three implementations agree; where it does
not, one of them is wrong and the disagreement is the finding.
"""
from __future__ import annotations

import csv
import json
import math
import re
import sys
from collections import defaultdict
from pathlib import Path

WS = Path("/work/ple-solve/frame-extension-method/ws/field_eng__constructability_4d__blind")
PKG = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(
    "/work/ple-solve/frame-extension-method/out/pkg")

FAILS: list[str] = []
NOTES: list[str] = []


def check(cond, msg):
    if not cond:
        FAILS.append(msg)


def rows(rel):
    with open(WS / rel, newline="", encoding="utf-8") as fh:
        return list(csv.DictReader(fh))


def num(x, d=None):
    try:
        return float(str(x).strip())
    except (TypeError, ValueError):
        return d


# ------------------------------------------------------------------ corpus
storey = {r["level_id"]: r for r in rows("model/storey_schedule.csv")}
zone = {r["zone_id"]: r for r in rows("model/zone_schedule.csv")}
slab = {(r["level"], r["zone"]): r for r in rows("model/slab_schedule.csv")}
cols = defaultdict(list)
for r in rows("model/column_schedule.csv"):
    cols[(r["level"], r["zone"])].append(r)
acts = {r["activity_id"]: r for r in rows("programme/activity_list.csv")}
zws = {r["zone_lift"]: r for r in rows("programme/zone_work_schedule.csv")}
occ = {r["zone_lift"]: r for r in rows("site/existing_occupation.csv")}
cpos = {r["position_id"]: r for r in rows("site/crane_standing_positions.csv")}
chart = [(num(r["radius_ft"]), num(r["rated_capacity_lb"])) for r in rows("site/crane_chart.csv")]
posts = {r["post_type"]: r for r in rows("catalogue/shoring_catalogue.csv")}
spacings = [num(r["spacing_ft"]) for r in rows("catalogue/shoring_grid_options.csv")]
scaf = {r["system"]: r for r in rows("catalogue/scaffold_catalogue.csv")}
comp = {r["component"]: r for r in rows("catalogue/scaffold_components.csv")}
duty = {r["duty_class"]: r for r in rows("catalogue/scaffold_duty_classes.csv")}
mix = {r["mix_id"]: r for r in rows("catalogue/concrete_mix_schedule.csv")}
twp = (WS / "rules/TWP-09_temporary_works_procedure.md").read_text()

ZONE_LIFTS = sorted(zws)
TYPES = ["COL", "SCAF", "SHOR", "RBAR", "POUR", "STRK", "SCST"]


def design_psf(zl):
    z = slab[(zws[zl]["level"], zws[zl]["zone"])]
    base = num(z["self_weight_psf"]) + 10.0
    base += 75.0 if z["placement_method"] == "crane_bucket" else 50.0
    if zl in occ:
        base += 15.0
    return base


def required_ext(zl):
    st = storey[zws[zl]["level"]]
    return (num(st["soffit_ft"]) - num(st["lift_base_ft"])) - 0.75


def crane_cap(r):
    if r <= chart[0][0]:
        return chart[0][1]
    for (r0, c0), (r1, c1) in zip(chart, chart[1:]):
        if r <= r1:
            return c0 + (r - r0) / (r1 - r0) * (c1 - c0)
    return 0.0


def tie_levels_wanted(h, base, frame=6.5):
    if h / base <= 4.0 + 1e-9:
        return []
    n = int(math.floor(h / frame))
    members = [round(k * frame, 3) for k in range(1, n + 1)]
    step = 20.0 if base <= 3.0 else 26.0
    out, t = [], 4.0 * base
    while t <= h + 1e-9:
        lv = min(members, key=lambda m: (abs(m - t), m))
        if lv not in out:
            out.append(lv)
        t += step
    if not out:
        out.append(members[-1])
    if h - out[-1] > 4.0 * base + 1e-9:
        out.append(members[-1])
    return sorted(set(out))


# -------------------------------------------------------------- deliverables
def read_csv(name):
    with open(PKG / name, newline="", encoding="utf-8") as fh:
        rdr = csv.DictReader(fh)
        return [{re.sub(r"[^a-z0-9]", "", (k or "").lower()): v for k, v in r.items()}
                for r in rdr]


seq = read_csv("construction_sequence.csv")
stab = read_csv("stability_check.csv")
occr = read_csv("occupancy_report.csv")
reg = read_csv("constraint_register.csv")
tw = json.loads((PKG / "temporary_works.json").read_text())
note = (PKG / "method_note.md").read_text()

# ---- the sequence -------------------------------------------------------
by_id = {}
for r in seq:
    aid = r.get("activityid", "").strip()
    check(aid in acts, f"sequence row {aid!r} is not an issued activity")
    check(aid not in by_id, f"{aid} appears twice")
    by_id[aid] = r
check(len(by_id) == len(acts), f"{len(by_id)} rows against {len(acts)} issued activities")

plan = {}
for aid, r in by_id.items():
    want = int(acts[aid]["duration_days"])
    d = num(r.get("durationdays"))
    s, f = num(r.get("startday")), num(r.get("finishday"))
    check(d == want, f"{aid}: duration {d} against issued {want}")
    check(s is not None and f is not None and abs((f - s) - want) < 1e-9,
          f"{aid}: finish-start {f - s if s is not None else None} against {want}")
    check(s is not None and s >= 0 and abs(s - round(s)) < 1e-9, f"{aid}: start {s} not a whole day")
    check(str(r.get("activitytype", "")).strip() == acts[aid]["activity_type"],
          f"{aid}: activity_type {r.get('activitytype')!r}")
    plan[aid] = {"start": s, "finish": f, "zl": acts[aid]["zone_lift"],
                 "type": acts[aid]["activity_type"]}

for aid, r in by_id.items():
    for p in [x for x in acts[aid]["predecessors"].split(";") if x]:
        check(p in plan, f"{aid}: predecessor {p} not in the programme")
        if p in plan:
            check(plan[aid]["start"] >= plan[p]["finish"] - 1e-9,
                  f"{aid} starts on {plan[aid]['start']}, before {p} finishes on {plan[p]['finish']}")

for zl in ZONE_LIFTS:
    pour = plan[f"{zl}.POUR"]
    strk = plan[f"{zl}.STRK"]
    strike_days = int(mix[slab[(zws[zl]["level"], zws[zl]["zone"])]["mix_id"]]["strike_days"])
    check(strk["start"] >= pour["finish"] + strike_days - 1e-9,
          f"{zl}: struck {strk['start'] - pour['finish']:g} days after the pour, {strike_days} required")
    check(plan[f"{zl}.SCST"]["start"] >= strk["finish"] - 1e-9, f"{zl}: scaffold struck before the forms")

# zone exclusivity, from the declared days alone
spans = {}
for zl in ZONE_LIFTS:
    got = [plan[f"{zl}.{t}"] for t in TYPES]
    spans[zl] = (min(g["start"] for g in got), max(g["finish"] for g in got))
by_zone = defaultdict(list)
for zl in ZONE_LIFTS:
    by_zone[zws[zl]["zone"]].append(zl)
for zn, members in by_zone.items():
    for i, a in enumerate(sorted(members)):
        for b in sorted(members)[i + 1:]:
            (a0, a1), (b0, b1) = spans[a], spans[b]
            check(not (a0 < b1 and b0 < a1), f"{a} and {b} are both in {zn} at once")

# ---- the daily demands --------------------------------------------------
crane = defaultdict(float)
crews = defaultdict(int)
for aid, p in plan.items():
    d = max(1.0, p["finish"] - p["start"])
    for day in range(int(p["start"]), int(p["finish"])):
        crane[day] += num(acts[aid]["crane_hours"]) / d
        crews[day] += 1
check(max(crane.values()) <= 10.0 + 1e-9, f"crane peak {max(crane.values()):.2f} h/day")
check(max(crews.values()) <= 8, f"gang peak {max(crews.values())}")
check(max(p["finish"] for p in plan.values()) <= 250, "programme runs past day 250")

shored = defaultdict(float)
scaf_face = defaultdict(float)
lay = defaultdict(int)
core = defaultdict(int)
for zl in ZONE_LIFTS:
    Z = zws[zl]
    area = num(Z["area_sf"])
    face = num(Z["face_length_ft"])
    e = tw["zone_lifts"][zl]
    shor, strk, pour = plan[f"{zl}.SHOR"], plan[f"{zl}.STRK"], plan[f"{zl}.POUR"]
    for d in range(int(shor["start"]), int(strk["finish"])):
        shored[d] += area
        if zone[Z["zone"]]["stair_core"] == "yes":
            core[(Z["level"], d)] += 1
    if str(e["reshore"]["required"]).lower() in ("yes", "y", "true", "1"):
        for d in range(int(strk["finish"]), int(pour["finish"]) + 28):
            shored[d] += 0.25 * area
    for d in range(int(shor["start"]), int(pour["finish"])):
        lay[d] += int(Z["laydown_units"])
    for d in range(int(plan[f"{zl}.SCAF"]["start"]), int(plan[f"{zl}.SCST"]["finish"])):
        scaf_face[d] += face
check(max(shored.values()) <= 3600 + 1e-6, f"yard peak {max(shored.values()):.0f} sf")
check(max(scaf_face.values()) <= 120 + 1e-6, f"scaffold face peak {max(scaf_face.values()):.0f} ft")
check(max(lay.values()) <= 16, f"laydown peak {max(lay.values())}")
check(max(core.values(), default=0) <= 1, "two stair cores shored on one level at once")

# ---- occupancy report against the programme -----------------------------
occ_by = {r.get("zonelift", "").strip(): r for r in occr}
for zl in ZONE_LIFTS:
    o = occ_by.get(zl)
    check(o is not None, f"{zl}: no occupancy row")
    if not o:
        continue
    check(num(o["occupiedfromday"]) == spans[zl][0], f"{zl}: occupied_from_day")
    check(num(o["occupiedtoday"]) == spans[zl][1], f"{zl}: occupied_to_day")
    check(num(o["shoredfromday"]) == plan[f"{zl}.SHOR"]["start"], f"{zl}: shored_from_day")
    check(num(o["shoredtoday"]) == plan[f"{zl}.STRK"]["finish"], f"{zl}: shored_to_day")
    want_h = round(sum(num(acts[f"{zl}.{t}"]["crane_hours"]) for t in TYPES), 2)
    check(abs(num(o["cranehourstotal"]) - want_h) <= 0.02, f"{zl}: crane_hours_total")
    check(int(num(o["laydownunits"])) == int(zws[zl]["laydown_units"]), f"{zl}: laydown_units")

# workspace volumes
for aid, r in by_id.items():
    zl = acts[aid]["zone_lift"]
    Z = zws[zl]
    t = acts[aid]["activity_type"]
    if t in ("SCAF", "SCST"):
        want = (num(Z["face_length_ft"]) * num(tw["zone_lifts"][zl]["scaffold"]["base_width_ft"])
                * num(storey[Z["level"]]["height_above_grade_ft"]))
    else:
        want = num(Z["area_sf"]) * num(storey[Z["level"]]["clear_height_ft"])
    got = num(r.get("workspacevolumecf"))
    check(got is not None and abs(got - want) <= 0.05 * want,
          f"{aid}: workspace volume {got} against {want:.0f}")

# ---- stability ----------------------------------------------------------
stab_by = {f"{r.get('level', '').strip()}-{r.get('zone', '').strip()}": r for r in stab}
for zl in ZONE_LIFTS:
    Z = zws[zl]
    area = num(Z["area_sf"])
    dem = max(12.0 * num(Z["wind_exposed_sf"]), 0.02 * design_psf(zl) * area)
    s = stab_by.get(zl)
    check(s is not None, f"{zl}: no stability row")
    if not s:
        continue
    got = num(s.get("demandlb"))
    check(abs(got - dem) <= 0.05 * dem, f"{zl}: demand {got} against {dem:.0f}")
    check(str(s.get("lateralsystem", "")).strip().lower().replace("_", "") == "temporarybracing",
          f"{zl}: lateral system")
    cap = num(s.get("capacitylb"))
    check(cap >= dem - 1e-6, f"{zl}: capacity {cap} below demand {dem:.0f}")
    bays = num(tw["zone_lifts"][zl]["bracing"]["braced_bays"])
    check(bays >= math.ceil(dem / num(comp["XB-1"]["ultimate_capacity_lb"])) - 1e-9,
          f"{zl}: {bays} braced bays")
    check(str(s.get("verdict", "")).strip().lower() == "pass", f"{zl}: verdict")

# ---- the temporary works design ----------------------------------------
for zl in ZONE_LIFTS:
    Z = zws[zl]
    area = num(Z["area_sf"])
    face = num(Z["face_length_ft"])
    h = num(storey[Z["level"]]["height_above_grade_ft"])
    e = tw["zone_lifts"][zl]
    sh = e["shoring"]
    p = posts[str(sh["post_type"]).upper()]
    check(str(sh["post_type"]).upper() in ("SP-09", "SP-13", "SP-16", "SP-20"),
          f"{zl}: {sh['post_type']} is the reshore post, not a shore")
    check(num(sh["spacing_ft"]) in spacings, f"{zl}: spacing {sh['spacing_ft']}")
    check(num(p["max_extension_ft"]) >= required_ext(zl) - 1e-9,
          f"{zl}: {sh['post_type']} extends {p['max_extension_ft']} < {required_ext(zl):.3f}")
    load = design_psf(zl) * num(sh["spacing_ft"]) ** 2
    check(load <= num(p["rated_capacity_lb"]) + 1e-6, f"{zl}: {load:.0f} lb on a {p['rated_capacity_lb']} post")
    check(abs(num(sh["design_load_per_post_lb"]) - load) <= 0.02 * load,
          f"{zl}: declared {sh['design_load_per_post_lb']} against {load:.0f}")
    check(num(sh["posts"]) >= math.ceil(area / num(sh["spacing_ft"]) ** 2) - 1e-9,
          f"{zl}: {sh['posts']} posts")
    rs = e["reshore"]
    check(str(rs["required"]).lower() == "yes", f"{zl}: early strike needs reshoring")
    check(num(rs["posts"]) >= math.ceil(area / 64.0) - 1e-9, f"{zl}: {rs['posts']} reshore posts")
    check(num(rs["install_day"]) <= plan[f"{zl}.STRK"]["finish"] + 1e-9, f"{zl}: reshore installed late")
    check(num(rs["remove_day"]) >= plan[f"{zl}.POUR"]["finish"] + 28 - 1e-9, f"{zl}: reshore removed early")

    sc = e["scaffold"]
    sid = str(sc["system"]).upper()
    S = scaf[sid]
    bays_need = math.ceil(face / num(S["bay_length_ft"]))
    check(num(sc["bays"]) >= bays_need, f"{zl}: {sc['bays']} bays against {bays_need}")
    check(abs(num(sc["base_width_ft"]) - num(S["base_width_ft"])) < 1e-9, f"{zl}: base width")
    cl = slab[(Z["level"], Z["zone"])]
    dclass = "heavy" if (cl["placement_method"] == "crane_bucket" or zone[Z["zone"]]["band"] >= "E") \
        else ("medium" if zl in occ else "light")
    intended = float(num(duty[dclass]["maximum_intended_load_lb_per_bay"]))
    check(abs(num(sc["maximum_intended_load_lb"]) - intended) < 1e-9,
          f"{zl}: intended load {sc['maximum_intended_load_lb']} against {intended}")
    per_bay = int(num(sc["planks_per_bay"]))
    need_pl = max(math.ceil(4.0 * intended / (num(comp["PL-95"]["ultimate_capacity_lb"])
                                              - num(comp["PL-95"]["weight_lb"]))),
                  math.ceil(18.0 / num(comp["PL-95"]["width_in"])))
    check(per_bay >= need_pl, f"{zl}: {per_bay} planks against {need_pl}")
    width = per_bay * num(comp["PL-95"]["width_in"])
    check(width >= 18.0 - 1e-9, f"{zl}: platform {width} in")
    check(width <= num(S["base_width_ft"]) * 12.0 + 1e-6, f"{zl}: platform wider than the frame")
    check(num(S["base_width_ft"]) * 12.0 - width <= 9.5 + 1e-6,
          f"{zl}: {num(S['base_width_ft'])*12 - width:g} in open between platform and uprights")
    check(abs(num(sc["platform_width_in"]) - width) < 0.51, f"{zl}: platform_width_in")
    check(abs(num(sc["platform_capacity_lb"]) - per_bay * num(comp["PL-95"]["ultimate_capacity_lb"])) < 1e-6,
          f"{zl}: platform capacity")
    levels_n = 1 + (0 if h <= 35.0 else math.ceil(h / 35.0) - 1)
    check(int(num(sc["platform_levels"])) >= levels_n, f"{zl}: {sc['platform_levels']} platform levels")
    lifts = math.ceil(h / num(S["frame_height_ft"]))
    frames = int(num(sc["frames"]))
    check(frames == (int(num(sc["bays"])) + 1) * lifts, f"{zl}: {frames} frames")
    check(int(num(sc["planks"])) == int(num(sc["bays"])) * per_bay * levels_n, f"{zl}: plank total")
    own = frames * num(S["frame_weight_lb"]) / 2.0
    check(num(S["leg_ultimate_lb"]) >= own + 2.0 * intended * levels_n - 1e-9,
          f"{zl}: leg capacity")
    check(38.0 <= num(sc["guardrail_height_in"]) <= 45.0, f"{zl}: guardrail height")
    check(abs(num(sc["height_ft"]) - h) <= 0.51, f"{zl}: scaffold height")
    check(abs(num(sc["height_to_base_ratio"]) - h / num(S["base_width_ft"])) <= 0.05, f"{zl}: ratio")
    want_t = tie_levels_wanted(h, num(S["base_width_ft"]))
    got_t = [num(x) for x in sc["tie_levels_ft"]]
    check(len(got_t) == len(want_t) and all(abs(a - b) <= 3.25 for a, b in zip(sorted(got_t), want_t)),
          f"{zl}: tie levels {got_t} against {want_t}")
    check(int(num(sc["tie_columns"])) >= max(2, math.ceil(face / 30.0) + 1), f"{zl}: tie columns")
    check(int(num(sc["ties"])) >= len(want_t) * max(2, math.ceil(face / 30.0) + 1), f"{zl}: ties")
    check(0 < num(sc["bearing_pressure_psf"]) <= 2000.0, f"{zl}: bearing pressure")
    check(str(sc["mudsill"]).lower() in ("yes", "y", "true"), f"{zl}: mudsills")
    check(str(sc["access_means"]).lower() in ("stair_tower", "hook_on_ladder", "attachable_ladder",
                                              "stairway_type_ladder", "portable_ladder",
                                              "integral_access_frame"), f"{zl}: access means")
    check(str(sc["fall_protection"]).lower() in ("guardrail", "personal_fall_arrest", "both"),
          f"{zl}: fall protection")
    check(num(sc["front_edge_gap_in"]) <= 14.0 or str(sc["front_edge_guardrail"]).lower() in ("yes", "y"),
          f"{zl}: front edge")

    cr = e["crane"]
    P = cpos[str(cr["position"]).upper()]
    cx = (num(zone[Z["zone"]]["x0_ft"]) + num(zone[Z["zone"]]["x1_ft"])) / 2.0
    cy = (num(zone[Z["zone"]]["y0_ft"]) + num(zone[Z["zone"]]["y1_ft"])) / 2.0
    want_r = math.hypot(num(P["x_ft"]) - cx, num(P["y_ft"]) - cy)
    check(abs(num(cr["radius_ft"]) - want_r) <= 2.0, f"{zl}: radius {cr['radius_ft']} against {want_r:.1f}")
    check(num(cr["radius_ft"]) <= num(P["max_radius_ft"]), f"{zl}: radius beyond the position")
    cap = crane_cap(num(cr["radius_ft"]))
    check(cap >= num(zws[zl]["heaviest_pick_lb"]) - 1e-6, f"{zl}: {cap:.0f} lb at {cr['radius_ft']} ft")
    check(abs(num(cr["rated_capacity_lb"]) - cap) <= 0.02 * cap, f"{zl}: declared capacity")
    check(str(cr["encroachment_option"]).lower() == "option3", f"{zl}: encroachment option")
    check(abs(num(cr["min_approach_ft"]) - 10.0) < 1e-9, f"{zl}: minimum approach")
    check(num(cr["demarcated_radius_ft"]) >= num(cr["radius_ft"]) - 1e-9, f"{zl}: demarcated radius too small")
    check(num(cr["demarcated_radius_ft"]) <= num(P["distance_to_power_line_ft"]) - 10.0 + 1e-9,
          f"{zl}: demarcated radius reaches the line")

check(not re.search(r"(rev\.?\s*b|revision\s*b)", tw.get("drawing_reference", "").lower()),
      "the drawing reference cites revision B")

# ---- the register -------------------------------------------------------
def flat(text: str) -> str:
    """The shipped documents wrap at 70 columns, so a clause id can be split
    across a line: compare on collapsed whitespace, not raw bytes."""
    return re.sub(r"\s+", " ", text)


docs = {p.name: flat(p.read_text(encoding="utf-8", errors="replace"))
        for p in (WS / "rules").glob("*.md")}
docs.update({p.name: flat(p.read_text(encoding="utf-8", errors="replace"))
             for p in (WS / "method_statements").glob("*.md")})
docs.update({p.name: flat(p.read_text(encoding="utf-8", errors="replace"))
             for p in (WS / "programme").glob("*.csv")})
NUMDOC = {"29 CFR 1926.451": "29_CFR_1926_451.md", "29 CFR 1926.703": "29_CFR_1926_703.md",
          "29 CFR 1926.250": "29_CFR_1926_250.md", "29 CFR 1926.34": "29_CFR_1926_34.md",
          "29 CFR 1926.1408": "29_CFR_1926_1408.md",
          "TWP-09 revision C": "TWP-09_temporary_works_procedure.md"}
for r in reg:
    doc = r.get("document", "").strip()
    check(doc in NUMDOC, f"register row cites {doc!r}, which is not a document in force")
    check("rev b" not in doc.lower() and "superseded" not in doc.lower(),
          f"register cites the superseded revision: {doc}")
    txt = docs.get(NUMDOC.get(doc, ""), "")
    clause = r.get("clause", "").strip()
    if txt and clause and not clause.lower().startswith("table"):
        # the CFR prints "(e) Removal of formwork. (1) ..." and lawyers cite the
        # composed "(e)(1)"; accept either, but the parts must appear IN ORDER
        ok = clause in txt
        if not ok:
            parts = re.findall(r"\([^()]+\)", clause)
            if parts:
                pos, ok = 0, True
                for pt in parts:
                    k = txt.find(pt, pos)
                    if k < 0:
                        ok = False
                        break
                    pos = k + len(pt)
        check(ok, f"clause {clause!r} of {doc} is not in the shipped text")
    v = (r.get("value") or "").strip()
    if v and txt:
        try:
            fv = float(v)
        except ValueError:
            fv = None
        if fv is not None:
            check(re.search(rf"(?<![0-9.]){re.escape(v)}(?![0-9])", txt) is not None,
                  f"the value {v} of {doc} {clause} does not appear in that document")
check(len(reg) >= 44, f"register has {len(reg)} rows, below the 0.55 recall floor's 33")

# ---- the note -----------------------------------------------------------
words = len(re.findall(r"\S+", note))
check(words >= 200, f"method note is {words} words")
low = note.lower()
for pat, why in ((r"revision\s*b", "revision B"), (r"revision\s*c", "revision C"),
                 (r"revision\s*a", "revision A"), (r"(supersed|governs?|in force)", "which governs"),
                 (r"reshor", "reshoring"), (r"(strike|struck)", "striking"),
                 (r"(per zone|zone by zone|governing constraint)", "the per-zone constraint"),
                 (r"(margin|headroom|utilisation)", "the margins")):
    check(re.search(pat, low) is not None, f"the note does not mention {why}")

print(f"checked: {len(seq)} sequence rows, {len(stab)} stability rows, {len(occr)} occupancy rows, "
      f"{len(reg)} register rows, note {words} words")
print(f"yard peak {max(shored.values()):.0f} sf, scaffold {max(scaf_face.values()):.0f} ft, "
      f"crane {max(crane.values()):.2f} h, gangs {max(crews.values())}, "
      f"makespan {max(p['finish'] for p in plan.values()):.0f}")
if FAILS:
    print(f"\n{len(FAILS)} FAILURES")
    for f in FAILS[:40]:
        print("  -", f)
    sys.exit(1)
print("\nall checks pass")
