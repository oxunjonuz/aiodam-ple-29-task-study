#!/usr/bin/env python3
"""One deliberate fault at a time, each graded by the REAL verifier.

A mutation that nobody notices is a hole in my own checking; a mutation the
grader catches is evidence that the grader is measuring the thing I claim it
measures. The original package is never touched: every mutant is written to its
own directory and zipped there.
"""
from __future__ import annotations

import json
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

SRC = Path("/work/ple-solve/frame-extension-method/out/pkg")
WORK = Path("/work/ple-solve/frame-extension-method/out/mut")


def read(name):
    return (SRC / name).read_text()


def write_pkg(dst: Path, files: dict[str, str]):
    dst.mkdir(parents=True, exist_ok=True)
    for name, text in files.items():
        (dst / name).write_text(text)
    with zipfile.ZipFile(dst / "submission.zip", "w", zipfile.ZIP_DEFLATED) as z:
        for name in files:
            z.write(dst / name, name)


def base_files() -> dict[str, str]:
    return {n: read(n) for n in ("construction_sequence.csv", "stability_check.csv",
                                 "occupancy_report.csv", "temporary_works.json",
                                 "constraint_register.csv", "method_note.md")}


def mutate_planks(files):
    tw = json.loads(files["temporary_works.json"])
    tw["zone_lifts"]["L3-Z-E-S"]["scaffold"]["planks_per_bay"] = 5
    tw["zone_lifts"]["L3-Z-E-S"]["scaffold"]["planks"] = 25
    tw["zone_lifts"]["L3-Z-E-S"]["scaffold"]["platform_width_in"] = 47.5
    files["temporary_works.json"] = json.dumps(tw)


def mutate_short_post(files):
    tw = json.loads(files["temporary_works.json"])
    tw["zone_lifts"]["L2-Z-A-S"]["shoring"]["post_type"] = "SP-13"
    files["temporary_works.json"] = json.dumps(tw)


def mutate_reshore_post(files):
    tw = json.loads(files["temporary_works.json"])
    tw["zone_lifts"]["L3-Z-B-S"]["shoring"]["post_type"] = "RS-16"
    files["temporary_works.json"] = json.dumps(tw)


def mutate_no_reshore(files):
    tw = json.loads(files["temporary_works.json"])
    tw["zone_lifts"]["L2-Z-A-S"]["reshore"]["required"] = "no"
    files["temporary_works.json"] = json.dumps(tw)


def mutate_guardrail(files):
    tw = json.loads(files["temporary_works.json"])
    tw["zone_lifts"]["L4-Z-D-S"]["scaffold"]["guardrail_height_in"] = 50
    files["temporary_works.json"] = json.dumps(tw)


def mutate_strike_early(files):
    """Strike the slab three days early, in the sequence itself."""
    lines = files["construction_sequence.csv"].splitlines()
    out = []
    for ln in lines:
        cells = ln.split(",")
        if cells and cells[0] in ("L2-Z-A-S.STRK",):
            cells[6] = str(int(cells[6]) - 3)
            cells[7] = str(int(cells[7]) - 3)
        if cells and cells[0] in ("L2-Z-A-S.SCST",):
            cells[6] = str(int(cells[6]) - 3)
            cells[7] = str(int(cells[7]) - 3)
        out.append(",".join(cells))
    files["construction_sequence.csv"] = "\n".join(out) + "\n"


def mutate_occupancy(files):
    lines = files["occupancy_report.csv"].splitlines()
    out = [lines[0]]
    for ln in lines[1:]:
        cells = ln.split(",")
        if cells[0] == "L3-Z-C-S":
            cells[3] = str(int(cells[3]) + 1)   # occupied_from_day
        out.append(",".join(cells))
    files["occupancy_report.csv"] = "\n".join(out) + "\n"


def mutate_crane_overload(files):
    """Pull one more zone-lift into the busiest days: the crane shift must break."""
    lines = files["construction_sequence.csv"].splitlines()
    starts = {}
    for ln in lines[1:]:
        cells = ln.split(",")
        if cells[0].endswith(".POUR"):
            starts[cells[0]] = int(cells[6])
    # move a bucket pour onto the day another bucket pour already runs
    target = "L2-Z-F-N"
    donor = "L2-Z-E-N"
    delta = starts[f"{donor}.POUR"] - starts[f"{target}.POUR"]
    out = [lines[0]]
    for ln in lines[1:]:
        cells = ln.split(",")
        if cells[0].startswith(target + "."):
            cells[6] = str(int(cells[6]) + delta)
            cells[7] = str(int(cells[7]) + delta)
        out.append(",".join(cells))
    files["construction_sequence.csv"] = "\n".join(out) + "\n"


def mutate_zone_overlap(files):
    """Run the level above while the level below is still in the zone."""
    lines = files["construction_sequence.csv"].splitlines()
    below = {}
    for ln in lines[1:]:
        cells = ln.split(",")
        below[cells[0]] = (int(cells[6]), int(cells[7]))
    shift = below["L3-Z-D-N.SCST"][1] - below["L2-Z-D-N.SCST"][0] + 2
    out = [lines[0]]
    for ln in lines[1:]:
        cells = ln.split(",")
        if cells[0].startswith("L3-Z-D-N.") or cells[0].startswith("L4-Z-D-N."):
            cells[6] = str(int(cells[6]) - shift)
            cells[7] = str(int(cells[7]) - shift)
        out.append(",".join(cells))
    files["construction_sequence.csv"] = "\n".join(out) + "\n"


def mutate_deadline(files):
    lines = files["construction_sequence.csv"].splitlines()
    out = [lines[0]]
    for ln in lines[1:]:
        cells = ln.split(",")
        if cells[0].startswith("L4-Z-G-S."):
            cells[6] = str(int(cells[6]) + 150)
            cells[7] = str(int(cells[7]) + 150)
        out.append(",".join(cells))
    files["construction_sequence.csv"] = "\n".join(out) + "\n"


def mutate_register_drop(files):
    lines = files["constraint_register.csv"].splitlines()
    keep = [ln for ln in lines if not ln.startswith("Reshoring is to RS-16")
            and not ln.startswith("The lateral system resists")]
    files["constraint_register.csv"] = "\n".join(keep) + "\n"


def mutate_register_superseded(files):
    lines = files["constraint_register.csv"].splitlines()
    lines.append("The whole programme is complete by day 310 measured from the first working day,"
                 "TWP-09 rev B,3.3,310,days,the programme's completion date")
    files["constraint_register.csv"] = "\n".join(lines) + "\n"


def mutate_wrong_yard_peak(files):
    """Declare a shoring grid that overloads the yard: all zones shored at 3.0 ft."""
    tw = json.loads(files["temporary_works.json"])
    for zl, e in tw["zone_lifts"].items():
        e["shoring"]["posts"] = 400
    files["temporary_works.json"] = json.dumps(tw)


def mutate_note(files):
    files["method_note.md"] = "# Method note\n\nThe package is issued. It is short.\n"


MUTANTS = [
    ("planks_heavy_5", mutate_planks),
    ("shore_sp13_too_short", mutate_short_post),
    ("reshore_post_as_shore", mutate_reshore_post),
    ("no_reshoring", mutate_no_reshore),
    ("guardrail_50in", mutate_guardrail),
    ("strike_early", mutate_strike_early),
    ("occupancy_day", mutate_occupancy),
    ("crane_overload", mutate_crane_overload),
    ("zone_overlap", mutate_zone_overlap),
    ("past_deadline", mutate_deadline),
    ("register_drop_two_hard", mutate_register_drop),
    ("register_cites_rev_b", mutate_register_superseded),
    ("wrong_post_count", mutate_wrong_yard_peak),
    ("note_too_short", mutate_note),
]


def grade(zip_path: Path, work: Path, split="heldout") -> dict:
    out = subprocess.run(["bash", "src/run_grade.sh", str(zip_path), str(work), split],
                         cwd="/work/ple-solve/frame-extension-method",
                         capture_output=True, text=True, timeout=1800)
    g = json.loads((work / f"grade_{split}.json").read_text())
    paper = work / f"paper_{split}.json"
    reward = json.loads(paper.read_text())["reward"] if paper.exists() else None
    fails = sorted({f for it in g["items"] for f in it["failed_families"]})
    return {"score": g["score"], "reward": reward, "fails": fails,
            "mean_p": g["mean_p"], "mean_O": g["mean_O"],
            "forfeits": len({tuple(it["forfeited_by"]) for it in g["items"] if it["forfeited_by"]}),
            "rc": out.returncode}


def main():
    only = sys.argv[1] if len(sys.argv) > 1 else None
    WORK.mkdir(parents=True, exist_ok=True)
    results = {}
    base = read("construction_sequence.csv")
    for name, fn in MUTANTS:
        if only and only != name:
            continue
        files = base_files()
        fn(files)
        assert files["construction_sequence.csv"] is not None
        dst = WORK / name
        shutil.rmtree(dst, ignore_errors=True)
        write_pkg(dst, files)
        r = grade(dst / "submission.zip", WORK / f"{name}_w")
        results[name] = r
        print(f"{name:26s} reward {r['reward']}  score {r['score']:.4f}  "
              f"fails {r['fails'][:6]}")
    json.dump(results, open(WORK / "mutations.json", "w"), indent=1)


if __name__ == "__main__":
    main()
