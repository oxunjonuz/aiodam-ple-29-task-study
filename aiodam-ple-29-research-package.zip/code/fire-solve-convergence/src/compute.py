#!/usr/bin/env python3
"""Every number the disposition carries, re-derived from the case record.

Sources (read-only): the attempt-3 log, the delivered and reference controlDicts,
the three-grid study, the meshing log, the site met pull, the SOW. Nothing is
taken from the rubric; the rubric was not read into this file.
"""
import csv, json, math, re, os

FILES = "/work/ple-dataset/tasks/fire-solve-convergence/environment/files"
P = os.path.join(FILES, "Projects/CFDME-2025-041_Ocotillo_WUI")

def read(p):
    return open(p, encoding="utf-8", errors="replace").read()

log3   = read(f"{P}/Case/logs/log.solve_20251009_attempt3.txt")
snappy = read(f"{P}/Case/logs/log.snappyHexMesh_20251009.txt")
three  = read(f"{P}/Case/verification/three_grid_study_outputs.txt")
ctrl   = read(f"{P}/Case/system/controlDict")
ref    = read(os.path.join(FILES, "Firm/Standards/Reference_Cases/fireFoam_transient_controlDict.txt"))
met    = read(f"{P}/Data/site_met_avra_valley_2015-2024.csv")

out = {}

# ---- 1. puffing frequency and period, Cetegen-Ahmed per Modeling Standard rev4 s4
D = 3.0                                  # m, front segment (scoping memo s5; study header)
f_pred = 1.5 * D ** -0.5                 # Hz
T_pred = 1.0 / f_pred                    # s
out["D_m"] = D
out["f_pred_Hz"] = f_pred
out["T_pred_s"] = T_pred
out["f_pred_2dp"] = round(f_pred, 2)
out["T_pred_2dp"] = round(T_pred, 2)

# ---- 2. what the run showed: the closing narrative quotes a period
m = re.search(r"oscillate at\s*\n?//\s*a matching period of ~([\d.]+) s", log3)
assert m, "closing-narrative period not found"
T_quoted = float(m.group(1))
f_quoted = 1.0 / T_quoted
out["T_quoted_s"] = T_quoted
out["f_quoted_Hz"] = f_quoted
out["agreement_pct_as_frequency"] = abs(f_quoted - f_pred) / f_pred * 100
out["agreement_pct_as_period"]    = abs(T_quoted - T_pred) / T_pred * 100
out["agreement_pct_2dp"] = round(out["agreement_pct_as_frequency"], 2)
# the circular reading the note must avoid: both rounded to 2 dp
out["circular_pct_from_rounded"] = abs(round(f_quoted,2) - round(f_pred,2)) / round(f_pred,2) * 100

# ---- 3. write interval: >= 25 monitor samples per puffing period, largest to 4 dp
samples_min = 25
write_ceiling = T_pred / samples_min               # s
write_chosen  = math.floor(write_ceiling * 1e4) / 1e4
out["write_ceiling_s"] = write_ceiling
out["write_interval_s"] = write_chosen
out["samples_per_period_at_chosen"] = T_pred / write_chosen
out["samples_per_period_at_next"]   = T_pred / (write_chosen + 1e-4)

# ---- 4. end time: 8 s recorded startup + 20 puffing periods, as a floor to 2 dp
startup = None
m = re.search(r"initial transient cleared by t ~ (\d+) s", three)
assert m
startup = float(m.group(1))
periods_min = 20
end_exact = startup + periods_min * T_pred
end_chosen = math.ceil(end_exact * 100) / 100
out["startup_s"] = startup
out["periods_min"] = periods_min
out["end_time_exact_s"] = end_exact
out["end_time_s"] = end_chosen
out["periods_at_float_down"] = (math.floor(end_exact*100)/100 - startup) / T_pred

# ---- 5. the fine-grid benchmark of record and the projection basis
#     wall clock and simulated time per grid, read from the three solver summaries
grids = {}
for tag in ("COARSE", "MEDIUM", "FINE"):
    blk = three.split(f"Solver summary : {tag} grid")[1].split("---", 1)[0]
    wc = re.search(r"Wall-clock \(([^)]*)\)\s*:\s*(\d+)h\s*(\d+)m", blk)
    co = re.search(r"Max Courant number\s*:\s*([\d.]+)\s*\(limit ([\d.]+)\)", blk)
    meanc = re.search(r"Mean Courant number\s*:\s*([\d.]+)", blk)
    dt = re.search(r"Time-step average\s*:\s*([\d.eE+-]+) s", blk)
    cells = re.search(r"Cells\s*:\s*([\d ]+)", blk)
    per = re.search(r"Puffing period recovered\s*:\s*([\d.]+) s", blk)
    grids[tag] = dict(host_cores=wc.group(1).strip(),
                      wall_h=int(wc.group(2)) + int(wc.group(3))/60.0,
                      maxCo=float(co.group(1)), Co_limit=float(co.group(2)),
                      meanCo=float(meanc.group(1)), dt_mean=float(dt.group(1)),
                      cells=int(cells.group(1).replace(" ","")),
                      period=float(per.group(1)))
out["grids"] = grids
sample_t = float(re.search(r"Sample time\s*:\s*t = ([\d.]+) s", three).group(1))
out["benchmark_simulated_s"] = sample_t
rate = grids["FINE"]["wall_h"] / sample_t          # h of wall clock per simulated second
out["fine_rate_h_per_sim_s"] = rate

per_case_h = rate * end_exact
out["per_case_h"] = per_case_h
out["per_case_hm"] = (int(per_case_h), round((per_case_h % 1) * 60))
n_cases = 6
out["n_cases"] = n_cases
matrix_h = per_case_h * n_cases
out["matrix_h"] = matrix_h
out["matrix_hm"] = (int(matrix_h), round((matrix_h % 1) * 60))

# ---- 6. attempt 3 consumption and the comparison
m = re.search(r"Wall clock\s*:\s*(\d+)h\s*(\d+)m\s*(\d+)s", log3)
a3_h = int(m.group(1)) + int(m.group(2))/60.0 + int(m.group(3))/3600.0
out["attempt3_h"] = a3_h
out["attempt3_hm"] = (int(m.group(1)), int(m.group(2)))
out["attempt3_cpu_hours"] = float(re.search(r"User CPU-hours\s*:\s*([\d.]+)", log3).group(1))
out["attempt3_cores"] = int(re.search(r"Cores\s*:\s*(\d+)", log3).group(1))
out["attempt3_iterations"] = int(re.search(r"Reached endTime = (\d+)", log3).group(1))
out["attempt3_vs_case_ratio"] = a3_h / per_case_h
out["attempt3_excess_h"] = a3_h - per_case_h
out["attempt3_excess_hm"] = (int(a3_h - per_case_h), round(((a3_h - per_case_h) % 1) * 60))

# ---- 7. delivered controlDict, entry by entry
def entry(text, key):
    m = re.search(rf"^\s*{key}\s+([^\s;]+)\s*;", text, re.M)
    return m.group(1) if m else None
for k in ("application","startFrom","startTime","stopAt","endTime","deltaT","adjustTimeStep",
          "writeControl","writeInterval","maxCo","maxDeltaT","writePrecision"):
    out[f"delivered_{k}"] = entry(ctrl, k)
    out[f"reference_{k}"] = entry(ref, k)
out["delivered_simulated_s_at_fixed_dt"] = int(out["delivered_endTime"]) * float(out["delivered_deltaT"])
out["attempt3_simulated_s"] = out["attempt3_iterations"] * float(out["delivered_deltaT"])

# ---- 8. meshes
m = re.search(r"Mesh statistics\s*\n\s*cells\s+([\d ]+)", log3)
out["attempt3_cells"] = int(m.group(1).replace(" ",""))
out["attempt3_nonorth"] = float(re.search(r"max non-orth\s+([\d.]+)", log3).group(1))
out["attempt3_skew"]    = float(re.search(r"max skewness\s+([\d.]+)", log3).group(1))
zones = dict(re.findall(r"^\s{4}(atmosphere|outerLeaf|cavity|innerLeaf|ties)\s+(?:\([^)]*\))?\s*:?\s+([\d ]+)\s+[\d ]+$",
                        snappy, re.M))
# the block above carries a header line per zone; fall back to the explicit table
zones = {}
blk = snappy.split("Cell breakdown by cellZone :")[1].split("Refinement level distribution")[0]
for name, cnt in re.findall(r"(atmosphere|outerLeaf|cavity|innerLeaf|ties)\s*(?:\([^)]*\))?\s*:\s*([\d ]+)", blk):
    zones[name] = int(cnt.replace(" ", ""))
out["production_zones"] = zones
out["production_cell_zones"] = int(re.search(r"cell zones\s*:\s*(\d+)", snappy).group(1))
out["production_patches"] = int(re.search(r"boundary patches\s*:\s*(\d+)", snappy).group(1))
out["production_cells_checkMesh"] = int(re.search(r"cells\s*:\s*([\d ]+)\n\s*faces per cell", snappy).group(1).replace(" ",""))
out["production_finest_cells_m"] = [0.0625, 0.03125]
out["study_cell_zones"] = [int(x) for x in re.findall(r"cell zones:\s+(\d+)", three)]
out["study_patches"] = [int(x) for x in re.findall(r"boundary patches:\s+(\d+)", three)]
out["study_patch_names"] = sorted(set(re.findall(r"^\s{4}(ground|inlet_240|inlet_270|outlet|top|fire_source)\s+\d+", three, re.M)))
out["study_min_cell_m"] = round(float(re.search(r"Min volume = ([\d.eE+-]+)\.", three.split("GRID 3 of 3")[1]).group(1)) ** (1/3), 4)
out["production_patch_names"] = re.findall(r"^\d+\s+(?:wall|patch)\s+(\w+)$", snappy, re.M)
out["Dstar_over_dx_study"] = float(re.search(r"D\*/dx = 3\.76 / 0\.5 = ([\d.]+)", three).group(1))
out["pope_resolved"] = float(re.search(r"k_res/\(k_res\+k_sgs\) = ([\d.]+)", three).group(1))

# ---- 9. inlet settings as delivered, and the correct vector for wind from 240 deg
out["inlet_Uref"] = float(re.search(r"Uref\s+([\d.]+) m/s", log3).group(1))
out["inlet_Zref"] = float(re.search(r"Zref\s+([\d.]+) m", log3).group(1))
out["inlet_z0"]   = float(re.search(r"z0\s+([\d.]+) m", log3).group(1))
out["inlet_flowDir_entry"] = re.search(r"flowDir\s+(\S+)", log3).group(1)
vx, vy = math.cos(math.radians(240)), math.sin(math.radians(240))
out["delivered_flow_vector"] = (round(vx,3), round(vy,3), 0.0)
out["delivered_flow_bearing_compass"] = (math.degrees(math.atan2(vx, vy)) + 360) % 360
wx, wy = math.sin(math.radians(60)), math.cos(math.radians(60))
out["correct_vector_for_from240"] = (round(wx,3), round(wy,3), 0.0)
out["correct_bearing_toward_compass"] = 60
out["twenty_ft_in_m"] = 20 * 0.3048

# ---- 10. site met pull: columns and the design envelope footer
rows = list(csv.reader(met.splitlines()))
cols = rows[0]
out["met_columns"] = cols
out["met_rows"] = sum(1 for r in rows[1:] if r and not r[0].startswith("#"))
out["met_has_roughness_column"] = any("rough" in c.lower() or c.lower() in ("z0","z_0") for c in cols)
out["met_footer"] = [l for l in met.splitlines() if l.startswith("#")]
# 20-ft wind and direction extremes in the record
vals = [(float(r[3]), float(r[4])) for r in rows[1:] if r and not r[0].startswith("#")]
out["met_wind_min_max"] = (min(v[0] for v in vals), max(v[0] for v in vals))
out["met_dir_set"] = sorted({v[1] for v in vals})

json.dump(out, open("/work/fsc/out/computed.json","w"), indent=1)
for k,v in out.items():
    if k in ("grids","met_footer","production_patch_names"): continue
    print(f"{k:38s} {v}")
print("\ngrids:")
for t,g in out["grids"].items(): print(" ", t, g)
