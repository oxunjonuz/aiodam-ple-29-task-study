#!/usr/bin/env python3
"""Builds /work/fsc/out/CFDME-2025-041_transient_solve_disposition_revA.docx.

Every number in the text is interpolated from out/computed.json, which compute.py
derives from the case record. Nothing is typed in by hand.
"""
import json, os
from docx import Document
from docx.shared import Pt, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

C = json.load(open("/work/fsc/out/computed.json"))
OUT = "/work/fsc/out/CFDME-2025-041_transient_solve_disposition_revA.docx"

def f2(x):  return f"{x:.2f}"
def f4(x):  return f"{x:.4f}"
def hm(h):  return f"{int(h)} h {round((h-int(h))*60):02d} m"

D_m      = 3.0
f_hz     = C["f_pred_Hz"]                 # 0.866025...
T_s      = C["T_pred_s"]                  # 1.1547005...
f_2      = f"{C['f_pred_2dp']:.2f}"       # 0.87
T_2      = f"{C['T_pred_2dp']:.2f}"       # 1.15
agr      = f"{C['agreement_pct_2dp']:.2f}"# 0.41
agr_f    = f"{C['agreement_pct_as_frequency']:.4f}"
agr_T    = f"{C['agreement_pct_as_period']:.4f}"
Tq       = C["T_quoted_s"]                # 1.15
fq       = C["f_quoted_Hz"]               # 0.869565
wceil    = C["write_ceiling_s"]           # 0.046188
wint     = C["write_interval_s"]          # 0.0461
samp_ok  = C["samples_per_period_at_chosen"]
samp_no  = C["samples_per_period_at_next"]
startup  = C["startup_s"]                 # 8
end_ex   = C["end_time_exact_s"]          # 31.09401
end_t    = C["end_time_s"]                # 31.10
end_down = C["periods_at_float_down"]     # 19.9965
bench_t  = C["benchmark_simulated_s"]     # 40.00
fine_h   = C["grids"]["FINE"]["wall_h"]   # 5.75
rate     = C["fine_rate_h_per_sim_s"]     # 0.14375
per_case = C["per_case_h"]                # 4.4698
matrix   = C["matrix_h"]                  # 26.8186
a3_h     = C["attempt3_h"]                # 6.6833
ratio    = C["attempt3_vs_case_ratio"]    # 1.4952
excess   = C["attempt3_excess_h"]         # 2.21357
zones    = C["production_zones"]
prod_n   = C["production_cells_checkMesh"]
fluid_n  = zones["atmosphere"]
solid_n  = prod_n - fluid_n
cells_st = C["grids"]["COARSE"]["cells"]; cells_md = C["grids"]["MEDIUM"]["cells"]; cells_fn = C["grids"]["FINE"]["cells"]
dt_fine  = C["grids"]["FINE"]["dt_mean"]  # 0.0022
maxco    = C["grids"]["FINE"]["maxCo"]    # 0.9
meanc    = C["grids"]["FINE"]["meanCo"]   # 0.47
a3_iter  = C["attempt3_iterations"]       # 800
a3_sim   = C["attempt3_simulated_s"]      # 8.00
deliv_end= C["delivered_endTime"]         # 2000
deliv_sim= C["delivered_simulated_s_at_fixed_dt"]  # 20.00
samples_delivered = T_s / (100*0.01)      # writes every 1.00 s
min_sim  = f"{20*T_s:.2f}"

doc = Document()

# ---------- page and styles
sec = doc.sections[0]
sec.page_width, sec.page_height = Inches(8.5), Inches(11)
for attr, val in (("left_margin",0.95),("right_margin",0.95),("top_margin",0.8),("bottom_margin",0.8)):
    setattr(sec, attr, Inches(val))

st = doc.styles["Normal"]
st.font.name = "Calibri"; st.font.size = Pt(10)
st.paragraph_format.space_after = Pt(5)
st.paragraph_format.line_spacing = 1.06
st.element.rPr.rFonts.set(qn("w:eastAsia"), "Calibri")

def shade(cell, hexcolor):
    tcPr = cell._tc.get_or_add_tcPr()
    sh = OxmlElement("w:shd"); sh.set(qn("w:val"), "clear"); sh.set(qn("w:color"), "auto"); sh.set(qn("w:fill"), hexcolor)
    tcPr.append(sh)

def rule(par, sz=12, color="1F3864"):
    pPr = par._p.get_or_add_pPr()
    pbdr = OxmlElement("w:pBdr"); bottom = OxmlElement("w:bottom")
    bottom.set(qn("w:val"), "single"); bottom.set(qn("w:sz"), str(sz)); bottom.set(qn("w:space"), "1"); bottom.set(qn("w:color"), color)
    pbdr.append(bottom); pPr.append(pbdr)

def para(text="", bold=False, italic=False, size=None, align=None, space_before=None, space_after=None, color=None):
    p = doc.add_paragraph()
    r = p.add_run(text); r.bold = bold; r.italic = italic
    if size: r.font.size = Pt(size)
    if color: r.font.color.rgb = RGBColor.from_string(color)
    if align == "c": p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    if align == "r": p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    if space_before is not None: p.paragraph_format.space_before = Pt(space_before)
    if space_after is not None: p.paragraph_format.space_after = Pt(space_after)
    return p

def lead(bold_lead, text, size=None):
    p = doc.add_paragraph()
    r = p.add_run(bold_lead); r.bold = True
    if size: r.font.size = Pt(size)
    r2 = p.add_run(text)
    if size: r2.font.size = Pt(size)
    return p

def h1(text):
    p = doc.add_paragraph(); p.paragraph_format.space_before = Pt(12); p.paragraph_format.space_after = Pt(3)
    p.paragraph_format.keep_with_next = True
    r = p.add_run(text); r.bold = True; r.font.size = Pt(12); r.font.color.rgb = RGBColor.from_string("1F3864")
    return p

def h2(text):
    p = doc.add_paragraph(); p.paragraph_format.space_before = Pt(8); p.paragraph_format.space_after = Pt(2)
    p.paragraph_format.keep_with_next = True
    r = p.add_run(text); r.bold = True; r.italic = False; r.font.size = Pt(10.5)
    return p

def bullet(text, bold_lead=None):
    p = doc.add_paragraph(style="List Bullet")
    p.paragraph_format.space_after = Pt(2)
    p.paragraph_format.left_indent = Inches(0.28)
    if bold_lead:
        r = p.add_run(bold_lead); r.bold = True
    p.add_run(text)
    return p

def table(rows, widths, header=True, font=8.6, header_fill="D9E2F3"):
    t = doc.add_table(rows=0, cols=len(widths))
    t.style = "Table Grid"; t.alignment = WD_TABLE_ALIGNMENT.CENTER
    t.autofit = False
    for ri, row in enumerate(rows):
        cells = t.add_row().cells
        for ci, val in enumerate(row):
            cells[ci].width = Inches(widths[ci])
            p = cells[ci].paragraphs[0]
            p.paragraph_format.space_after = Pt(1); p.paragraph_format.space_before = Pt(1)
            r = p.add_run(str(val)); r.font.size = Pt(font)
            if header and ri == 0:
                r.bold = True; shade(cells[ci], header_fill)
    for row in t.rows:
        for ci, cell in enumerate(row.cells):
            cell.width = Inches(widths[ci])
    doc.add_paragraph().paragraph_format.space_after = Pt(2)
    return t

def field(par, instr):
    fld = OxmlElement("w:fldSimple"); fld.set(qn("w:instr"), instr)
    r = OxmlElement("w:r"); t = OxmlElement("w:t"); t.text = "1"; r.append(t); fld.append(r)
    par._p.append(fld)

# ---------- letterhead
p = para("THE CFD ME", bold=True, size=14, space_after=0)
r = p.add_run("    |    Tucson, Arizona    |    AZ PE #48213    |    CFDME-2025-041    rev A")
r.font.size = Pt(9); r.font.color.rgb = RGBColor.from_string("404040")
rule(p)
para("TECHNICAL NOTE — TRANSIENT SOLVE DISPOSITION", bold=True, size=13, align="c", space_before=8, space_after=1)
para("Third steady-solve attempt, the authorized transient run, and the solver wall-clock projection — "
     "Ocotillo desert-fire case CFDME-2025-041", italic=True, size=9.5, align="c", space_after=8)

table([
 ["Project", "CFDME-2025-041 — Ocotillo WUI Wildfire, Phase 1 (client: Ocotillo Additive Structures)"],
 ["Subject", "Disposition of the third steady-solve attempt (SLURM job 41304); authorization and time-control block of the "
             "replacement transient run; solver wall-clock projection for the six-case matrix"],
 ["From", "Marguerite Falk, PE — Technical Director & Reviewing Engineer, AZ PE #42798"],
 ["Copy", "Gordon Selby, PE — Owner & Principal Engineer, AZ PE #48213"],
 ["To", "Project file CFDME-2025-041; Mulshi Simulation Labs (S. Bhatia), case supplier"],
 ["Date", "10/10/2025"],
 ["Governing documents", "Modeling Standards — Fire & Buoyant Flows rev 4 (effective 08/15/2025); QA Verification Standard — Mesh & "
                         "Resolution rev 3 (effective 07/01/2025); Units and Conversions SOP rev 2 (effective 04/01/2025); "
                         "SOW CFDME-2025-041-SOW-01 (signed 10/08/2025)"],
 ["Revision", "rev A — issued for action ahead of any fourth attempt"],
], widths=[1.35, 5.25], header=False, font=8.8)

# ---------- 1. disposition
h1("1.  Disposition")
para(f"This note closes the third steady-solve attempt on the Ocotillo desert-fire case and authorizes the transient run that "
     f"replaces it. It is dated 10/10/2025 and is issued before Mulshi starts a fourth attempt. The disposition, in order:")
bullet(f"The residual plateau in attempt 3 is the puffing oscillation of the buoyant plume — a physical frequency of the flow, "
       f"not a numerical stall. The period the run showed and the Cetegen–Ahmed prediction for this plume agree to {agr} %.",
       "The plateau is physics. ")
bullet("No steady solution exists for this problem, because the plume oscillates at a finite, deterministic, physical frequency "
       "and no time-invariant flow field exists for a residual-tolerance schedule to converge to. A fourth steady attempt is not "
       "authorized, and the operator's alternative of loosening the residual controls and keeping the cycle-averaged field is refused.",
       "There is no steady state to converge to. ")
bullet(f"FireFoam LES, EDC combustion, fvDOM at the firm reference settings, on the production conjugate mesh, for "
       f"{f2(end_t)} s of simulated time at a {f4(wint)} s write interval, on the block of Section 4.",
       "The transient run is authorized. ")
bullet("The radiation configuration (Section 3.1), the turbulence closure (Section 3.2) and the inlet flow direction "
       "(Section 6.2). Two record items are open and must be closed before the case is set up: a temperature-dependent solid "
       "property table (Section 3.3) and a sourced inlet roughness length (Section 6.3).",
       "Three items of the delivered setup are non-conforming and must be corrected. ")
bullet("An unconverged steady RAS field of a formulation the Modeling Standards forbid cannot seed a transient LES.",
       "The solved fields from attempt 3 are discarded. ")
bullet(f"{hm(per_case)} of solver wall clock for one authorized case and {hm(matrix)} for the six-case matrix. Both are a lower "
       f"bound, not a firm figure: two of the three conditions the firm projection basis sets are not met by the benchmark of "
       f"record (Section 7.4).", "Cost. ")

# ---------- 2. plateau
h1("2.  The residual plateau in attempt 3")
h2("2.1  What the plateau is")
para(f"The plume above a {D_m:.1f} m fire segment necks, sheds and re-forms at a frequency that depends only on the fire diameter "
     f"and gravity. Modeling Standards rev 4 Section 4 adopts the Cetegen–Ahmed relation as normative for design fires in this "
     f"regime, f = 1.5 × D^(−1/2) with D in m. For the {D_m:.1f} m front segment fixed in the scoping memo of 10/08/2025 and "
     f"carried in the three-grid study:")
para(f"        f = 1.5 × ({D_m:.1f} m)^(−1/2) = {f2(f_hz)} Hz      (unrounded {f_hz:.4f} Hz)")
para(f"        T = 1 / f = {f2(T_s)} s                    (unrounded {T_s:.4f} s)")
para(f"Every LES run at this diameter is expected to display monitor-point oscillation at this frequency, and the standard is "
     f"explicit that this is a physical property of the plume rather than a numerical artefact. The same section states the "
     f"consequence that governs this disposition: because the plume oscillates at a finite, deterministic, physical frequency, "
     f"no time-invariant flow field exists that any residual-tolerance schedule can converge to.")

h2("2.2  What the run showed")
para(f"The closing narrative of the attempt-3 log records the plateau exactly where the plume is: over outer iterations 400 to 800 "
     f"the Ux initial residual holds in the band 3e-4 to 8e-4 (dimensionless) and the p initial residual in the band 2e-5 to 3e-5 "
     f"(dimensionless), while the plume-centreline probes oscillate at a quoted period of about {Tq:.2f} s with roughly 40 K "
     f"peak-to-peak on temperature and 2.4 m/s peak-to-peak on vertical velocity. The wall stand-off probes stay flat across the "
     f"same window: probe 3 reads U = (8.00, 0.13, 0.02) m/s at T = 308.5 K and probe 4 reads U = (7.74, 0.10, 0.12) m/s at "
     f"T = 310.2 K. An oscillation confined to the plume axis, in phase at 4 m, 8 m and 12 m above grade, is the plume's own "
     f"structure. A residual tail from the pressure solve would not look like that.")
table([
 ["Probe", "Location (mesh axes, m)", "Behaviour over outer iterations 400–800"],
 ["0", "(1.5, 0.0, 8.0) — plume centreline, 8 m AGL", f"oscillates at ~{Tq:.2f} s; ~40 K and ~2.4 m/s peak-to-peak"],
 ["1, 2", "(1.5, 0.0, 4.0) and (1.5, 0.0, 12.0) — plume centreline, 4 m and 12 m AGL", "oscillate in phase with probe 0"],
 ["3, 4", "(10.0, 0.0, 2.0) and (10.0, 0.0, 8.0) — wall stand-off, upwind face and above roof",
          "flat: T = 308.5 K and 310.2 K, U unchanged to two decimals"],
], widths=[0.6, 3.2, 2.8])

h2("2.3  How close the prediction and the run are, as a percentage")
para(f"The comparison has to be made against the unrounded prediction. Rounded to the two decimals the note reports, both the "
     f"prediction and the quoted value read {f_2} Hz and {T_2} s, and comparing those with each other returns a circular "
     f"0.00 %, which is not an agreement figure. Carried unrounded:")
bullet(f"as a frequency: quoted 1 / {Tq:.2f} s = {fq:.4f} Hz against the prediction {f_hz:.4f} Hz — {agr_f} %;")
bullet(f"as a period: quoted {Tq:.4f} s against the prediction {T_s:.4f} s — {agr_T} %.")
para(f"Both readings give {agr} %, and the agreement is stated as {agr} % on that basis.")

h2("2.4  Whether a steady solution exists")
para("It does not. The frequency is finite, deterministic and physical, so the flow has no time-invariant state for a "
     "residual-tolerance schedule to reach; the residual plateau is the signature of the physical oscillation and not evidence "
     "of a defective solver. Attempt 3 is therefore not a failed solve — it is a correct solve of the wrong formulation on a flow "
     "that has no steady state. The three recommendations in the operator's closing narrative are each declined:")
bullet(" cannot converge a physical oscillation; it changes the path toward a destination that does not exist.",
       "1. Further under-relaxation (U 0.3 to 0.2) ")
bullet(" cannot either. The pressure residual is a consequence of the plume passing through the pressure field; the probes that "
       "carry the physical signal are temperature and vertical velocity on the plume axis, and they lock onto the predicted "
       "frequency to " + agr + " % — which is what distinguishes a physical mode from numerical noise.",
       "2. Tightening the pressure tolerance to 1e-8 ")
bullet(" is refused. A steady RANS buoyant field is not a permissible starting point for fire work (Section 3.6 of the "
       "Modeling Standards), k-epsilon applied to LES is not permitted (Section 5), and a cycle-averaged field is a time-invariant "
       "object constructed from a flow that has none.", "3. Loosening the residual controls and keeping the cycle-averaged field ")

# ---------- 3. conformance
h1("3.  How the rest of the delivered setup stands against our standards")
para("The delivered case is read from the attempt-3 log and the case system directory. Four items fail the Modeling Standards "
     "and one record item is open; each carries the conforming configuration that replaces it.")
h2("3.1  Radiation — non-conforming")
para("The delivered case runs fvDOM with 32 rays and a single grey band (greyMeanCombustion absorption/emission, no scattering, "
     "no soot model). Modeling Standards rev 4 Section 3.4 takes the number of angular directions and the wavelength banding from "
     "the firm reference table, and Appendix A gives that table for the 1200–1700 K design range as four angular directions "
     "(S4-equivalent quadrature) and two wavelength bands split at 2.5 micrometres. The conforming configuration — and the one the "
     "authorized run carries — is therefore four angular directions and two wavelength bands split at 2.5 micrometres, with the "
     "absorption and emission coefficients set consistent with the combustion product composition rather than defaulted.")
h2("3.2  Turbulence closure — non-conforming")
para("The delivered case runs RAS k-epsilon (kEpsilon) inside the fire solver, with the operator's note that the steady k-epsilon "
     "solve was a bring-up device for a later LES. Modeling Standards rev 4 Section 5 permits only large-eddy simulation, with "
     "either a dynamic Smagorinsky closure (Germano–Lilly, test filter twice the mesh spacing) or WALE, and forbids k-epsilon "
     "variants applied to LES and hybrid RANS/LES formulations. The authorized run is therefore large-eddy simulation with a WALE "
     "sub-grid closure — the standard's preferred closure where solid boundaries carry a significant fraction of the thermal load, "
     "which is the case here, the wall assembly being the object of the analysis — with dynamic Smagorinsky as the permitted "
     "alternative. The choice is recorded in the case-setup record per Section 5.")
h2("3.3  Solid-region properties — record item open")
para("The delivered case carries no solid regions at all. The production mesh does — the outer leaf, the inner leaf and the ties — "
     "and Modeling Standards Section 3.5 requires k, rho and c_p for solid regions to be entered as temperature-tabulated functions or "
     "supported polynomial fits over the design temperature range. What the record holds are constants: Appendix A gives the "
     "printed siliceous-aggregate concrete as k = 1.4 W/(m·K), rho = 2200 kg/m³ and c_p = 900 J/(kg·K), and the galvanized steel "
     "ties as k = 45 W/(m·K), rho = 7850 kg/m³ and c_p = 490 J/(kg·K), and states that solid-region properties are held constant "
     "over the design range absent case-specific data. There is no temperature-dependent property table for the concrete leaves "
     "or for the steel ties anywhere in the record. This is an open record item: the only solid-region property values on file are "
     "constants, and a table must be established and entered before the conjugate solve is set up, because a constant-property "
     "short-cut for solid regions in a fire case is not permitted.")
h2("3.4  Case inheritance from a non-fire parent — non-conforming")
para("The case-setup export of record (OAS_case_setup_from_DWA.txt) documents the case as built from the validated Dry Wash "
     "Aerospace high-altitude external-aerodynamics case, with the solver, turbulence, freestream, combustion and radiation blocks "
     "carried forward and only the geometry and patch naming swapped to revC. Modeling Standards rev 4 Section 7 prohibits that "
     "transfer in terms: a validated aerospace compressible non-reacting case shall not be pulled forward as the physics basis for "
     "a ground-level fire case, and case-directory reuse without a full physics rebuild is not acceptable practice. The export also "
     "records that no combustion model, no radiation dictionary and no reactive scalars are compiled in, while the live "
     "controlDict and the attempt-3 log show fireFoam with EDC and fvDOM — so the record holds no case-setup artifact that conforms "
     "to Section 3. The freestream block of the export (p_inf = 26 500 Pa, T_inf = 223 K, rho_inf = 0.4 kg/m³, M_inf = 0.25) is an "
     "aerospace reference condition and must not appear in the authorized case; the run of record used an ambient of 308.15 K "
     "(35 °C). The physics on the production mesh is to be recorded as built new, per Section 7 of the Modeling Standards.")
h2("3.5  What the case must be")
para("On that reading the authorized run is: fireFoam, large-eddy simulation with WALE, EDC combustion carried forward unchanged, "
     "fvDOM with four angular directions and two bands split at 2.5 micrometres, a four-region conjugate treatment (outer leaf and "
     "inner leaf as solid regions with temperature-dependent properties, the cavity as a fluid region with participating "
     "radiation, and each tie as a separate solid region with refinement at the tie–concrete interfaces) coupled with the "
     "chtMultiRegion boundary conditions of Modeling Standards Section 6, the atmospheric-boundary-layer inlet of Section 7 with "
     "matching turbulence fields, and the time-control block of Section 4 below.")

# ---------- 5 (numbered 4 in the note)
h1("4.  The run I am authorizing — the time-control block")
h2("4.1  The block, with values")
table([
 ["Entry", "Authorized value", "Basis"],
 ["application", "fireFoam", "Modeling Standards §3.1"],
 ["startFrom", "latestTime", "firm reference transient controlDict"],
 ["startTime", "0 s", "first run of the authorized case"],
 ["stopAt", "endTime", "—"],
 ["endTime", f"{f2(end_t)} s", f"§4: {startup:.0f} s startup + 20 periods (Section 4.3)"],
 ["deltaT", "0.001 s (first step, then Courant-controlled)", "firm reference transient controlDict"],
 ["adjustTimeStep", "yes", "§4, mandatory"],
 ["maxCo", "0.9 (dimensionless)", "§4, mandatory"],
 ["maxDeltaT", "0.01 s", "§4 ceiling, fixed by the firm reference dictionary (Section 4.2)"],
 ["writeControl", "adjustableRunTime", "§4, mandatory"],
 ["writeInterval", f"{f4(wint)} s", f"§4: ≥ 25 samples per period (Section 4.3)"],
 ["purgeWrite", "0", "all written times retained for the spectra"],
 ["writeFormat / writePrecision", "ascii / 8 (significant figures)", "firm reference transient controlDict"],
 ["writeCompression / timeFormat", "off / general", "firm reference transient controlDict"],
 ["runTimeModifiable", "true", "firm reference transient controlDict"],
], widths=[1.55, 2.55, 2.5])

h2("4.2  The reference dictionary that governs the case-specific ceiling")
para("Section 4 of the Modeling Standards fixes adjustTimeStep yes, maxCo 0.9, writeControl adjustableRunTime and a maxDeltaT "
     "ceiling that it leaves case-specific, \"typically 0.01 s\". Our reference transient dictionary — "
     "Firm/Standards/Reference_Cases/fireFoam_transient_controlDict.txt — sets maxDeltaT 0.01 s, and that is the ceiling carried "
     "into the authorized block. Two of that dictionary's own settings are not carried: its endTime of 60 s and its writeInterval "
     "of 0.1 s are the settings of its own 60 s run, and a 0.1 s write interval would capture only "
     f"{T_s/0.1:.1f} samples per puffing period here, against the 25 the standard requires. The ceiling that governs the step is "
     "0.01 s; the write interval and the end time are set from Section 4 of the standard for this case, below.")

h2("4.3  Largest write interval and shortest end time the standard allows here")
para(f"Write interval. Section 4 requires at least 25 monitor samples per puffing period. With the period carried at full "
     f"precision, T = {T_s:.4f} s, the ceiling is T / 25 = {wceil:.6f} s. The largest four-decimal write interval that meets it "
     f"is {f4(wint)} s, which gives {samp_ok:.2f} samples per period; {f4(wint+0.0001)} s gives {samp_no:.2f} and fails. A write "
     f"interval derived from the rounded period of {T_2} s would be {1.15/25:.4f} s — still compliant, but not the largest the "
     f"standard allows, because the rounded period is the shorter of the two.")
para(f"End time. Section 4 requires the simulated end time to span a minimum of 20 puffing periods after the initial transient "
     f"has cleared, which it puts at no less than approximately {min_sim} s of physical time for a {D_m:.1f} m fire, exclusive of "
     f"startup. The three-grid study records the startup transient as cleared by t ≈ {startup:.0f} s, and the Phase 1 draft "
     f"samples from t ≥ {startup:.0f} s on the same basis. Hence:")
para(f"        end time = {startup:.0f} s + 20 × {T_s:.4f} s = {startup:.0f} s + {20*T_s:.5f} s = {end_ex:.5f} s")
para(f"As a floor, {f2(end_t)} s is the shortest value to two decimals that satisfies the rule: {end_t-0.01:.2f} s leaves "
     f"{end_down:.4f} periods after startup, short of the twenty required. The authorized end time is {f2(end_t)} s.")

h2("4.4  The block Mulshi delivered, entry by entry")
para("Every entry that differs between the delivered controlDict and the authorized block, with both values:")
table([
 ["Entry", "Delivered by Mulshi", "Authorized", "Why it differs"],
 ["startFrom", "startTime", "latestTime", "the authorized run may restart from the last written time"],
 ["endTime", f"{deliv_end} (counted as outer iterations)", f"{f2(end_t)} s (physical time)",
  f"{deliv_end} iterations × 0.01 s = {deliv_sim:.2f} s of simulated time, under the {min_sim} s the standard requires before startup is added"],
 ["deltaT", "0.01 s, fixed", "0.001 s first step, then Courant-controlled", "a fixed step cannot hold maxCo through the plume passage"],
 ["adjustTimeStep", "no", "yes", "§4, mandatory"],
 ["maxCo", "absent (no entry)", "0.9 (dimensionless)", "§4, mandatory"],
 ["maxDeltaT", "absent (no entry)", "0.01 s", "§4 ceiling, firm reference dictionary"],
 ["writeControl", "timeStep", "adjustableRunTime", "§4: writes pegged to simulated time, not to solver iteration"],
 ["writeInterval", "100 time steps", f"{f4(wint)} s",
  f"100 steps × 0.01 s = 1.00 s of simulated time between writes, i.e. {samples_delivered:.2f} samples per puffing period"],
 ["writePrecision", "6", "8", "firm reference transient controlDict"],
], widths=[1.25, 1.6, 1.55, 2.2])
para(f"The delivered write interval records about {samples_delivered:.2f} samples per puffing period, against the 25 the standard "
     f"requires; the delivered endTime of {deliv_end} outer iterations is an iteration count rather than a simulated time, and at "
     f"the delivered fixed step it corresponds to {deliv_sim:.2f} s. Attempt 3 reached {a3_iter} of those iterations, that is "
     f"{a3_sim:.2f} s of simulated time — it stopped at the end of the startup window, before a single period of the window the "
     f"standard requires had been sampled.")

# ---------- 5 mesh & verification
h1("5.  The mesh the attempt ran on, and what our verification of it covers")
h2("5.1  The attempt ran on the production conjugate mesh")
para(f"The attempt-3 log reports {prod_n:,} cells with a maximum non-orthogonality of 58.34 (limit 65, dimensionless) and a maximum "
     f"skewness of 2.14 (limit 4, dimensionless) — the figures the meshing log of 10/09/2025 records for the production mesh "
     f"(job borrego/41287, 32 cores, geometry of record OAS-WUI-01_revC). Its five cell zones are atmosphere (fluid, "
     f"{zones['atmosphere']:,} cells), outerLeaf (solid, {zones['outerLeaf']:,} cells), cavity (fluid with participating radiation, "
     f"{zones['cavity']:,} cells), innerLeaf (solid, {zones['innerLeaf']:,} cells) and ties (solid, {zones['ties']:,} cells), and it "
     f"carries 13 boundary patches.")
h2("5.2  The three-grid study is a different, fluid-only family of meshes")
para(f"The verification study of 10/09/2025 runs three separate meshes: {cells_st:,} cells at a background dx = 1.0 m, {cells_md:,} "
     f"cells at dx = 0.7 m and {cells_fn:,} cells at dx = 0.5 m. Each of the three carries a single cell zone, which is fluid "
     f"(fireRefinementZone), and six boundary patches — ground, inlet_240, inlet_270, outlet, top and fire_source — with no wall "
     f"patch among them. None of the wall assembly, the cavity or the ties exists in these meshes.")
h2("5.3  What the verification covers")
para(f"It verifies plume resolution in the fluid domain. On the fine grid the plume resolution index is D*/dx = {C['Dstar_over_dx_study']:.2f} "
     f"(dimensionless, within the required band of 5 to 10) and the Pope resolved-TKE fraction is {C['pope_resolved']:.2f} "
     f"({C['pope_resolved']*100:.0f} %), above the 80 % minimum. On that basis the fluid-domain resolution at dx = 0.5 m carries "
     f"into the authorized run. A Richardson or GCI band is not part of that evidence: QA Verification Standard rev 3 Section 4 "
     f"states that the grid convergence index is not valid for LES and shall not be used to verify any large-eddy result.")
h2("5.4  What it does not cover")
para("The solid leaves, the cavity radiation and the tie regions of the production mesh are outside the scope of the three-grid "
     "verification. None of those regions exists in the study meshes — one fluid cell zone per mesh, no wall patch, no conjugate "
     "region and no participating-radiation cavity — so nothing about the conjugate heat transfer through the leaves, the "
     "radiative exchange inside the cavity or the conduction into the ties is verified by the three grids. Those mechanisms are "
     "exactly what sets the single-point temperature rise of this assembly. The verification that carries to the authorized run "
     "is therefore the fluid-plume resolution only; the conjugate response needs its own verification and reporting under Sections "
     "5 and 6 of the QA standard.")

# ---------- 6 what carries forward
h1("6.  What in the delivered case carries forward, with the inlet's defining settings")
h2("6.1  Carries forward")
bullet("The production conjugate mesh on the geometry of record OAS-WUI-01_revC, with its five cell zones and 13 boundary patches.")
bullet("The EDC combustion model of the delivered case (version v2005), which Modeling Standards Section 3.3 mandates: EDC "
       "carries forward unchanged into the authorized run, with the finite-rate chemistry coupling and its C_gamma 2.1377 and "
       "C_num 0.4083 constants.")
bullet("The atmospheric-boundary-layer inlet formulation with its matching turbulence inlet fields, and the probe set of "
       "Section 2.2 (plume centreline at 4 m, 8 m and 12 m above grade; wall stand-off at 2 m and 8 m).")
bullet("The job accounting of attempt 3, as a cost datum only (Section 7.7).")
h2("6.2  The inlet's defining settings, and the one that must change")
para(f"The delivered inlet is atmBoundaryLayerInletVelocity with Uref = {C['inlet_Uref']:.1f} m/s at Zref = {C['inlet_Zref']:.1f} m "
     f"(the 20 ft reference height of SOW Section 3.1, case 3.1-B of the matrix), z0 = {C['inlet_z0']:.2f} m and flowDir "
     f"(cos(240) sin(240) 0). The reference velocity and the reference height carry forward unchanged.")
para("The flow direction does not. Units and Conversions SOP rev 2 Section 2 fixes wind direction on the compass convention, "
     "north = 0 degrees and clockwise positive, with solver-internal angles in radians. Evaluated, (cos 240°, sin 240°, 0) = "
     "(−0.500, −0.866, 0): that vector points to 210 degrees on the compass, so it drives the flow out through the western boundary "
     "and does not describe a wind from 240 degrees — it describes a wind from 030 degrees. A wind from 240 degrees flows toward "
     "060 degrees, and with x east and y north — the axes the production mesh fixes with its inlet_west, outlet_east, "
     "lateral_north and lateral_south patches — the unit vector for the inlet flow direction is (0.866, 0.500, 0), equivalently "
     "(cos 30°, sin 30°, 0). That is the direction the authorized run carries. The delivered entry is also neither convention "
     "cleanly: it is a mathematical angle in degrees evaluated on mesh axes, while the SOP puts wind directions on the compass in "
     "degrees and solver-internal angles in radians.")
h2("6.3  The roughness length cannot carry forward as conforming")
para("Modeling Standards Section 3.2 requires the roughness length, the reference height and the reference velocity to be taken "
     "from the project's site meteorological pull. The pull of record (site_met_avra_valley_2015-2024.csv, 240 hourly records plus "
     "the design-envelope footer) carries a timestamp, ambient temperature, relative humidity, 20 ft wind speed, wind direction and "
     "solar irradiance, and holds no roughness length. The 0.03 m on the delivered inlet is Mulshi's own annotation in the "
     "attempt-3 log (\"buffelgrass roughness\"); it is not sourced from the pull and the record holds no other basis for it. This "
     "is an open record item: the roughness length must be sourced and recorded with its reference before the authorized run is "
     "set up, and the value entered at the 6.1 m reference height it belongs to.")

# ---------- 7 cost
h1("7.  Cost")
h2("7.1  The basis of record")
para("The firm projection basis is the reviewing engineer's note of 10/09/2025 18:05 to R. Ellsworth. It has five points: (1) at "
     "a fixed mesh, a fixed solver stack and a fixed core count, solver wall clock is linear in simulated physical time, the rate "
     "being taken from a run of record on that grid as simulated seconds reached divided by wall clock consumed; (2) the rate is "
     "taken from the grid the production case will actually run on, never carried from one grid to another; (3) the figure is "
     "quoted per case first and then multiplied by the number of cases the governing scope document procures; (4) the number is "
     "solver wall clock and nothing else — queue wait, staging, meshing and decomposition, post-processing and cloud-burst "
     "provisioning latency are excluded; (5) the linear-scaling step is written into the assumptions section of whatever document "
     "carries the number. Nothing beyond those five steps is applied.")
h2("7.2  Solver wall clock for one authorized case")
para(f"The run of record on the fine grid is the FINE run of the three-grid study: {bench_t:.2f} s of simulated time in "
     f"{fine_h:.2f} h of solver wall clock (5 h 45 m as posted for that run; the queue wait before its burst allocation is "
     f"excluded under point 4 of the basis). The rate is therefore {fine_h:.2f} h / {bench_t:.2f} s = {rate:.6f} h per simulated "
     f"second, and one authorized case is:")
para(f"        {rate:.6f} h/s × {end_ex:.5f} s = {per_case:.3f} h  =  {hm(per_case)} of solver wall clock")
h2("7.3  Solver wall clock for the full six-case matrix")
para(f"SOW Section 3.1 procures six cases (240 and 270 degrees at 5, 8 and 12 m/s). Within the matrix every case carries the same "
     f"mesh and the same required physical duration and only the inlet condition changes, so the per-case figure multiplies by "
     f"six, with no discount for cases expected to restart from a neighbour:")
para(f"        6 × {per_case:.3f} h = {matrix:.2f} h  =  {hm(matrix)} of solver wall clock")
para(f"({hm(round(per_case*60)/60*6)} from multiplying the rounded per-case figure of {hm(per_case)} is equally correct.)")
h2("7.4  Whether that basis can be met for this run, on every condition it sets")
para("The basis sets three conditions of equal standing. The verdict on each:")
table([
 ["Condition", "Verdict", "Evidence in the record"],
 ["Fixed solver stack", "Met",
  "The study runs fireFoam LES with EDC combustion and fvDOM radiation, and Modeling Standards Section 3.1 makes fireFoam the "
  "solver for the production case: the study and the production case both run the same reacting solver family. The conjugate "
  "regions are mesh content and are counted under the fixed-mesh condition, not here."],
 ["Fixed mesh", "Not met",
  f"The benchmark ran on the {cells_fn:,}-cell fluid-only plume mesh, which carries none of the wall assembly, the cavity or the "
  f"ties. The production run is the {prod_n:,}-cell multi-region conjugate solve with five cell zones."],
 ["Fixed core count", "Not met",
  "The study records 96 cores for the coarse grid and 192 cores for the medium grid, and no core allocation at all for the fine "
  "grid (posted as \"borrego + cloud burst\"). The allocation behind the rate is therefore not recorded."],
], widths=[1.1, 0.7, 4.8])
para("Two of the three conditions therefore fail, so the linear-scaling precondition the projection rests on is not satisfied by "
     "the benchmark of record. The figures of Sections 7.2 and 7.3 remain the answer the basis produces, and they are a projection "
     "under a stated assumption rather than a measurement.")
h2("7.5  What the time step and the Courant margin behind the figure imply")
para(f"The fine-grid benchmark reached a maximum Courant number of {maxco:.2f} against the 0.9 ceiling — no margin at all, with a "
     f"mean Courant number of {meanc:.2f} (dimensionless) and an average time step of {dt_fine:.4f} s. Its finest cells measure "
     f"0.125 m (minimum cell volume 0.001936 m³ on the fine grid). The production mesh carries 0.0625 m cells in the wall assembly and the cavity and 0.03125 m cells at the ties and "
     f"the tie–concrete interfaces, and {solid_n:,} cells in the four non-atmosphere zones that the benchmark never advanced. A "
     f"Courant-limited step scales with cell size at fixed velocity, so the production conjugate solve will advance at a smaller "
     f"average time step than the {dt_fine:.4f} s recorded on the fine study grid, and it does extra work per step in the solid and "
     f"tie zones. Both effects push the true cost above the projection.")
h2("7.6  What the figure is worth")
para(f"Both figures — {hm(per_case)} for one case and {hm(matrix)} for the matrix — are a lower bound on the true cost, not a firm "
     f"estimate. They carry no conjugate solid, cavity-radiation or tie work, and the rate behind them comes from a fluid-only grid "
     f"whose core allocation is unrecorded. A firm solver wall-clock figure for this project requires a benchmark run on the "
     f"production conjugate mesh — a transient fireFoam run of record on the {prod_n:,}-cell mesh. The only run that exists on that "
     f"mesh is attempt 3, and its rate cannot be used either: it is a steady RANS solve on a different solver stack and has no "
     f"Courant-controlled time step ({a3_iter} outer iterations at a fixed 0.01 s, that is {a3_sim:.2f} s of simulated time, in "
     f"{hm(a3_h)}).")
para(f"No contingency, margin or risk multiplier is applied to either figure, and no overhead percentage is applied to either "
     f"figure. Nothing is added for queue wait, staging, meshing or decomposition, post-processing or cloud-burst provisioning "
     f"latency: the basis excludes them (point 4) and none of them appears in the projection. The two figures are the measured rate "
     f"multiplied by the procured cases and nothing else.")
h2("7.7  What attempt 3 consumed, against one authorized case")
para(f"Attempt 3 (SLURM job 41304, {C['attempt3_cores']} cores across four nodes of the borrego cluster) consumed "
     f"{hm(a3_h)} of wall clock and {C['attempt3_cpu_hours']:.1f} CPU-hours. Against one authorized case at {hm(per_case)} that is "
     f"{ratio:.2f} times the solver wall clock, and {hm(excess)} more solver wall clock than one authorized case.")
h2("7.8  What of it, if anything, is usable downstream")
para("Nothing of the solved fields: they are discarded. An unconverged steady RAS field of a formulation Modeling Standards "
     "Sections 3.6 and 5 forbid cannot seed a transient LES, and nothing in it is a boundary condition for the authorized run. What "
     "is usable is everything around the fields — the production mesh, the probe set, the EDC configuration, the inlet formulation "
     "once its direction and roughness are corrected (Section 6), and the job accounting as a cost datum.")

# ---------- 8 assumptions
h1("8.  Assumptions behind the cost figures")
bullet(f" Solver wall clock is linear in simulated physical time at a fixed mesh, a fixed solver stack and a fixed core count. "
       f"That is the assumption the projection rests on, and Section 7.4 records that two of its three conditions are not satisfied "
       f"by the benchmark of record; the figures are a projection, not a measurement.")
bullet(f" The rate is that of the fine-grid run of record: {bench_t:.2f} s of simulated time in {fine_h:.2f} h of solver wall "
       f"clock, queue wait excluded.")
bullet(f" The simulated duration of each authorized case is {end_ex:.5f} s, the {startup:.0f} s startup recorded in the three-grid "
       f"study plus twenty unrounded puffing periods of {T_s:.4f} s.")
bullet(" Six cases are procured, per SOW Section 3.1; every case carries the same mesh and the same required duration, and only the "
       "inlet condition changes.")
bullet(" The ambient condition of record is 308.15 K (35 °C); 20 ft is 6.096 m, recorded throughout as 6.1 m.")

# ---------- 9 sign-off
h1("9.  Reviewer and stamp block")
table([
 ["Reviewing engineer", "Marguerite Falk, PE — Technical Director & Reviewing Engineer, AZ PE #42798"],
 ["Signature", "_/s/ Marguerite Falk, PE /_"],
 ["Date", "10/10/2025"],
 ["Disposition", "Attempt 3 is closed as non-converging by physics; a fourth steady attempt is not authorized. The transient run "
                 "of Section 4 is authorized, subject to closure of the two record items in Sections 3.3 and 6.3."],
], widths=[1.35, 5.25], header=False, font=8.8)
table([
 ["[  PE STAMP — APPLIED  ]", "The CFD Mechanical Engineer, LLC — Arizona PE #48213\nGordon Selby, PE — Owner & Principal Engineer\nDate: 10/10/2025"],
 ["Signature", "_/s/ Gordon Selby, PE /_"],
 ["Stamp boundary", "CFD thermal analysis only. Fire-resistance rating certified separately by others."],
], widths=[1.6, 5.0], header=False, font=8.8)
para("This note is a computational thermal analysis. It does not certify, extend or modify any fire-resistance rating of the "
     "assembly; the certified rating is issued separately by others under a separate engagement, as SOW Sections 4 and 10 require.",
     italic=True, size=8.8)

# ---------- footer
footer = sec.footer.paragraphs[0]
footer.text = ""
r = footer.add_run("CFDME-2025-041  rev A   |   Transient solve disposition   |   10/10/2025   |   page ")
r.font.size = Pt(8); r.font.color.rgb = RGBColor.from_string("595959")
field(footer, "PAGE")

doc.save(OUT)
print("wrote", OUT, os.path.getsize(OUT), "bytes")
