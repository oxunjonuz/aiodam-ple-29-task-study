#!/usr/bin/env python3
"""Second, independent path to the note's numbers.

It does not import compute.py and does not read the corpus dump: it parses the raw record files with its own
patterns, recomputes each headline value with its own arithmetic (Fractions for the wall clocks), and then
asserts that the rendered note carries that exact value. A disagreement anywhere fails.
"""
import math, re, sys
from fractions import Fraction

RAW = "/work/ple-dataset/tasks/fire-solve-convergence/environment/files/Projects/CFDME-2025-041_Ocotillo_WUI"
LOG3  = open(f"{RAW}/Case/logs/log.solve_20251009_attempt3.txt").read()
SNAP  = open(f"{RAW}/Case/logs/log.snappyHexMesh_20251009.txt").read()
THREE = open(f"{RAW}/Case/verification/three_grid_study_outputs.txt").read()
CTRL  = open(f"{RAW}/Case/system/controlDict").read()
NOTE  = open(sys.argv[1], encoding="utf-8", errors="replace").read()
NOTE  = re.sub(r"\s+", " ", NOTE)

fails = []
def want(needle, why):
    if needle not in NOTE:
        fails.append(f"{why}: the note does not carry {needle!r}")

# ---- inputs, each read from the record by this file's own patterns
D = Fraction(3)                                             # front segment, m (study header, scoping memo s5)
startup_s = Fraction(int(re.search(r"initial transient cleared by t ~ (\d+) s", THREE).group(1)))
fine_wall = re.search(r"Wall-clock \(borrego \+ cloud burst\)\s*:\s*(\d+)h\s*(\d+)m", THREE)
fine_h = Fraction(int(fine_wall.group(1))) + Fraction(int(fine_wall.group(2)), 60)
sim_s  = Fraction(re.search(r"Sample time\s*:\s*t = ([\d.]+) s", THREE).group(1))
a3 = re.search(r"Wall clock\s*:\s*(\d+)h\s*(\d+)m\s*(\d+)s", LOG3)
a3_h = Fraction(int(a3.group(1))) + Fraction(int(a3.group(2)), 60) + Fraction(int(a3.group(3)), 3600)
quoted = Fraction(str(re.search(r"matching period of ~([\d.]+) s", LOG3).group(1)))

# ---- the physics
f = 1.5 / math.sqrt(float(D))                    # Cetegen-Ahmed, standard s4
T = 1.0 / f
want(f"{f:.2f} Hz", "predicted frequency")
want(f"{T:.2f} s", "predicted period")
agree = abs(1/float(quoted) - f) / f * 100
want(f"{agree:.2f} %", "agreement percentage")

# ---- the time-control block
ceil = T / 25
w = math.floor(ceil * 1e4) / 1e4
want(f"{w:.4f} s", "write interval")
end = float(startup_s) + 20 * T
want(f"{math.ceil(end*100)/100:.2f} s", "end time")

# ---- the projection, in exact fractions until the last step
rate = fine_h / sim_s                            # hours per simulated second
per_case = rate * Fraction(str(round(end, 5)))
ch = int(per_case); cm = round(float(per_case - ch) * 60)
want(f"{ch} h {cm:02d} m", "one authorized case")
matrix = per_case * 6
mh = int(matrix); mm = round(float(matrix - mh) * 60)
want(f"{mh} h {mm:02d} m", "six-case matrix")
ratio = a3_h / per_case
want(f"{float(ratio):.2f} times", "attempt 3 vs one case")
ex = a3_h - per_case
want(f"{int(ex)} h {round(float(ex - int(ex)) * 60):02d} m", "excess wall clock")

# ---- the record figures the note quotes
for pat, label in [
    (r"cells\s+([\d ]+)", "attempt-3 cells"),
]:
    pass
cells = re.search(r"Mesh statistics\s*\n\s*cells\s+([\d ]+)", LOG3).group(1).replace(" ", "")
want(f"{int(cells):,}", "attempt-3 cell count")
studied = re.search(r"GRID 3 of 3.*?cells:\s+([\d ]+)", THREE, re.S).group(1).replace(" ", "")
want(f"{int(studied):,}", "fine study cell count")
want("five cell zones", "production cell zones")
want("six boundary patches", "study boundary patches")
want(f"{float(re.search(r'Uref\s+([\d.]+) m/s', LOG3).group(1)):.1f} m/s", "inlet Uref")
want(f"{float(re.search(r'Zref\s+([\d.]+) m', LOG3).group(1)):.1f} m", "inlet Zref")
want(f"{float(re.search(r'Max Courant number\s*:\s*([\d.]+)', THREE.split('GRID 3 of 3')[1]).group(1)):.2f}", "max Courant, fine grid")
want(f"{float(re.search(r'Time-step average\s*:\s*([\d.eE+-]+) s', THREE.split('GRID 3 of 3')[1]).group(1)):.4f} s", "average time step, fine grid")
want(f"{float(re.search(r'User CPU-hours\s*:\s*([\d.]+)', LOG3).group(1)):.1f} CPU-hours", "attempt-3 CPU hours")
want(f"{float(re.search(r'D\*/dx = 3\.76 / 0\.5 = ([\d.]+)', THREE).group(1)):.2f}", "plume resolution index")
want(f"{float(re.search(r'k_res/\(k_res\+k_sgs\) = ([\d.]+)', THREE).group(1)):.2f}", "Pope fraction")

# ---- the delivered block this second path reads for itself
for k, v in [("endTime", "2000"), ("deltaT", "0.01"), ("writeInterval", "100"), ("adjustTimeStep", "no"),
             ("writeControl", "timeStep"), ("startFrom", "startTime")]:
    got = re.search(rf"^\s*{k}\s+(\S+);", CTRL, re.M).group(1)
    if got != v:
        fails.append(f"delivered {k}: record has {got!r}, verifier expected {v!r}")
want("2000", "delivered end time")
want("0.01 s", "delivered deltaT")

print(f"checked {len(NOTE)} characters against {RAW.rsplit('/',1)[-1]}")
if fails:
    for f_ in fails: print("  FAIL", f_)
    sys.exit(1)
print("all recomputed values are carried by the note, and the delivered block re-reads as the note states it")
