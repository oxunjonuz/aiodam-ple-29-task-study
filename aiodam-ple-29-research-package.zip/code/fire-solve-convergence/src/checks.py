#!/usr/bin/env python3
"""The 43 rubric criteria of fire-solve-convergence written as code, BEFORE the memo text.

Written against the criteria statements and the case record only: it asks whether the
document says a thing, never whether it says it the way the memo happens to say it.
Run on the rendered PDF text (what the judge reads) or on the docx text.
"""
import re, sys, json, unicodedata

def norm(t):
    t = unicodedata.normalize("NFKC", t)
    t = t.replace("\u2212", "-").replace("\u2013", "-").replace("\u2014", "-").replace("\u00a0", " ")
    t = t.replace("\u00b5", "u").replace("\u03bc", "u")      # micro sign / mu
    t = t.lower()
    t = re.sub(r"[ \t\r\n]+", " ", t)
    return t

def compact(t):
    return re.sub(r"[\s,]", "", norm(t))

def has(t, *pats):
    n = norm(t)
    return all(re.search(p.lower(), n) for p in pats)

def has_c(t, *pats):
    c = compact(t)
    return all(re.search(p, c) for p in pats)

def near(t, a, b, window=260):
    """a and b within `window` characters of each other (same sentence/row)."""
    n = norm(t)
    a, b = a.lower(), b.lower()
    for m in re.finditer(a, n):
        seg = n[max(0, m.start()-window): m.end()+window]
        if re.search(b, seg):
            return True
    return False

CHECKS = []
def chk(i, w, label):
    def deco(fn):
        CHECKS.append((i, w, label, fn)); return fn
    return deco

# 0-4  the plateau, the prediction, the agreement, no steady solution
@chk(0, 2.0, "plateau is the puffing oscillation of the buoyant plume")
def c0(t):
    return near(t, r"puffing", r"oscillat|shed|neck", 320) and "plateau" in norm(t)

@chk(1, 2.0, "predicted frequency 0.87 Hz and period 1.15 s")
def c1(t):
    return has(t, r"0\.87\s*hz") and has(t, r"1\.15\s*s\b")

@chk(2, 1.0, "attempt-3 narrative quotes 1.15 s")
def c2(t):
    return near(t, r"closing narrative", r"1\.15\s*s\b", 400)

@chk(3, 4.0, "agreement 0.41 percent")
def c3(t):
    return has(t, r"0\.41\s*(%|percent)")

@chk(4, 1.0, "no steady solution exists")
def c4(t):
    n = norm(t)
    return bool(re.search(r"no steady (solution|state|flow field)", n)
                or re.search(r"steady solution does not exist", n)
                or re.search(r"no time-invariant (flow )?field", n))

# 5-7  conformance: radiation directions, banding, LES closure
@chk(5, 3.0, "four angular directions")
def c5(t):
    return has(t, r"\b(four|4)\s+angular directions")

@chk(6, 1.0, "two wavelength bands split at 2.5 um")
def c6(t):
    return has(t, r"\b(two|2)\s+wavelength bands") and has(t, r"2\.5\s*u\s*m|2\.5\s*microm")

@chk(7, 1.0, "LES with WALE or dynamic Smagorinsky")
def c7(t):
    n = norm(t)
    return bool(re.search(r"large-eddy simulation|\bles\b", n) and re.search(r"wale", n)
                and re.search(r"dynamic smagorinsky", n))

# 8-13  the authorized time-control block and the delivered one
@chk(8, 1.0, "adjustTimeStep yes, maxCo 0.9, writeControl adjustableRunTime")
def c8(t):
    return near(t, r"adjusttimestep", r"\byes\b", 80) and near(t, r"maxco", r"\b0\.9\b", 80) \
           and near(t, r"writecontrol", r"adjustableruntime", 80)

@chk(9, 1.0, "maxDeltaT 0.01 s")
def c9(t):
    """maxDeltaT 0.01 s stated as the value carried, not as the standard's 'typically'."""
    n = norm(t)
    for m in re.finditer(r"maxdeltat", n):
        seg = n[m.end(): m.end()+70]
        if re.search(r"0\.01\s*s\b", seg) and "typically" not in seg and "typically" not in n[max(0,m.start()-40):m.end()]:
            return True
    return False

@chk(10, 6.0, "write interval 0.0461 s")
def c10(t):
    return has_c(t, r"0\.0461s?\b")

@chk(11, 3.0, "end time 31.10 s")
def c11(t):
    return has_c(t, r"31\.10s?\b")

@chk(12, 2.0, "delivered block: 2000 iterations, adjustTimeStep no, deltaT 0.01 s fixed, writeControl timeStep, writeInterval 100")
def c12(t):
    return near(t, r"endtime", r"\b2000\b", 120) and has(t, r"outer iterations") \
           and near(t, r"adjusttimestep", r"\bno\b", 80) and near(t, r"deltaT", r"0\.01\s*s", 80) \
           and near(t, r"writecontrol", r"\btimestep\b", 80) and near(t, r"writeinterval", r"\b100\b", 80)

@chk(13, 1.0, "delivered startFrom startTime, no maxCo / no maxDeltaT vs latestTime, 0.9, 0.01 s")
def c13(t):
    n = norm(t)
    absent = r"(absent|none|not set|not present|not carried|no entry|-)"
    return near(t, r"startfrom", r"starttime", 80) and near(t, r"startfrom", r"latesttime", 200) \
           and near(t, r"maxco", absent, 120) and near(t, r"maxco", r"0\.9", 200) \
           and near(t, r"maxdeltat", absent, 120) and near(t, r"maxdeltat", r"0\.01\s*s", 200)

# 14-19  the mesh and the verification scope
@chk(14, 1.0, "attempt 3 ran on the production conjugate mesh")
def c14(t):
    return near(t, r"attempt 3", r"11,214,862|11214862", 500) or \
           near(t, r"attempt 3", r"production conjugate mesh", 400)

@chk(15, 1.0, "production mesh carries five cell zones")
def c15(t):
    n = norm(t)
    return bool(re.search(r"five cell zones|5 cell zones", n)) and \
           all(z in n for z in ("atmosphere", "outerleaf", "cavity", "innerleaf", "ties"))

@chk(16, 1.0, "study verifies plume resolution in the fluid domain")
def c16(t):
    return has_c(t, r"7\.52") and (has(t, r"pope") and has(t, r"0\.84|84\s*%|84 percent"))

@chk(17, 1.0, "solid leaves, cavity radiation, ties outside the study's scope")
def c17(t):
    n = norm(t)
    return all(k in n for k in ("solid leaves", "cavity radiation", "tie regions")) and \
           bool(re.search(r"outside the scope|not verified|does not (cover|verify)", n))

@chk(18, 5.0, "each study mesh carries a single cell zone, which is fluid")
def c18(t):
    n = norm(t)
    return bool(re.search(r"(single|one|\b1\b) cell zone", n)) and bool(re.search(r"fluid", n)) and \
           bool(re.search(r"firerefinementzone|fire refinement zone", n))

@chk(19, 8.0, "each study mesh carries six boundary patches")
def c19(t):
    n = norm(t)
    ok_names = all(k in n for k in ("ground", "inlet_240", "inlet_270", "outlet", "top", "fire_source"))
    return bool(re.search(r"\bsix boundary patches|\b6 boundary patches", n)) and ok_names

# 20-25  what carries forward, with the inlet's defining settings
@chk(20, 1.0, "inlet Uref 8.0 m/s at Zref 6.1 m")
def c20(t):
    return has(t, r"8\.0\s*m/s") and has(t, r"6\.1\s*m\b")

@chk(21, 1.0, "EDC carries forward")
def c21(t):
    for s_ in sentences(norm(t)):
        if re.search(r"\bedc\b", s_) and re.search(r"carries forward|carried forward|carry forward|retained|carries over", s_):
            return True
    return False

@chk(22, 3.0, "delivered flow direction does not describe a wind from 240 deg")
def c22(t):
    n = norm(t)
    if not re.search(r"cos\s*\(?\s*240", n):
        return False
    return bool(re.search(r"does not (describe|represent|give|model)|is not a wind from|not a wind from 240", n)) \
       and bool(re.search(r"wind from 240", n))

@chk(23, 6.0, "correct inlet vector (0.866, 0.500, 0)")
def c23(t):
    ordered = has_c(t, r"0\.8660\.5000\.0?\)?") or has_c(t, r"cos30.{0,10}sin30")
    return ordered and near(t, r"0\.866", r"wind from 240|unit vector|flow direction", 500)

@chk(24, 8.0, "0.03 m roughness not from the site meteorological record, which holds none")
def c24(t):
    n = norm(t)
    return bool(re.search(r"0\.03\s*m", n)) \
           and bool(re.search(r"not taken from|not sourced|is not from|no basis|not from the (site )?(met|meteorological)", n)) \
           and bool(re.search(r"meteorological|met pull|site met", n)) \
           and bool(re.search(r"holds no roughness|no roughness length|carries no roughness", n))

@chk(25, 8.0, "only constants on file; no temperature-dependent property table")
def c25(t):
    n = norm(t)
    return bool(re.search(r"no temperature-dependent", n)) and bool(re.search(r"table", n)) and \
           bool(re.search(r"constant", n))

# 26-39  cost
@chk(26, 2.0, "one authorized case 4 h 28 m")
def c26(t):
    return has_c(t, r"4h28m")

@chk(27, 2.0, "six-case matrix 26 h 49 m")
def c27(t):
    return has_c(t, r"26h49m")

@chk(28, 1.0, "fixed core count condition unmet; fine-grid allocation unrecorded")
def c28(t):
    return near(t, r"core count", r"not (recorded|stated)|unrecorded|no core allocation|no allocation", 600) \
           and near(t, r"core count", r"fine", 600)

@chk(29, 1.0, "fixed mesh condition fails: fluid-only mesh without the wall assembly")
def c29(t):
    for s_ in sentences(norm(t)):
        if "fixed mesh" in s_ and re.search(r"not met|fails", s_) \
           and re.search(r"fluid-only|carries none of|no wall assembly", s_):
            return True
    return False

@chk(30, 9.0, "fixed solver stack condition satisfied: same reacting solver family")
def c30(t):
    for s_ in sentences(norm(t)):
        if "solver stack" in s_ and re.search(r"\bmet\b|satisf", s_) and re.search(r"\bsame\b", s_) \
           and "firefoam" in s_:
            return True
    return False

@chk(31, 1.0, "max Courant 0.90 against the 0.9 ceiling")
def c31(t):
    return has_c(t, r"0\.90") and near(t, r"0\.90", r"0\.9\s*(ceiling|limit)", 200)

@chk(32, 3.0, "production solve advances at a smaller average time step than 0.0022 s")
def c32(t):
    n = norm(t)
    return bool(re.search(r"smaller (average )?time step|shorter (average )?time step", n)) and \
           bool(re.search(r"0\.0022\s*s", n))

@chk(33, 1.0, "figures are a lower bound")
def c33(t):
    return has(t, r"lower bound")

@chk(34, 1.0, "a firm figure requires a benchmark on the production conjugate mesh")
def c34(t):
    return near(t, r"benchmark", r"production conjugate mesh", 300) and near(t, r"benchmark", r"firm", 400)

def sentences(n):
    return re.split(r"(?<=\.)\s+", n)

@chk(35, 10.0, "no contingency, margin or risk multiplier applied")
def c35(t):
    """A sentence must say, about the figure, that contingency / risk multiplier is NOT applied."""
    for s_ in sentences(norm(t)):
        if "contingency" in s_ and re.search(r"\bno\b|\bnot\b|\bnever\b", s_) \
           and re.search(r"applied|carried|added", s_) and re.search(r"risk multiplier|margin", s_):
            return True
    return False

@chk(36, 10.0, "no overhead percentage applied")
def c36(t):
    for s_ in sentences(norm(t)):
        if "overhead" in s_ and re.search(r"\bno\b|\bnot\b|\bnever\b", s_) \
           and re.search(r"applied|carried|added", s_):
            return True
    return False

@chk(37, 1.0, "attempt 3: 6 h 41 m and 424.3 CPU-hours")
def c37(t):
    return has_c(t, r"6h41m") and has_c(t, r"424\.3")

@chk(38, 1.0, "attempt 3 = 1.50 times one authorized case")
def c38(t):
    return has_c(t, r"1\.50") and near(t, r"1\.50", r"times", 120)

@chk(39, 10.0, "attempt 3 consumed 2 h 13 m more")
def c39(t):
    return has_c(t, r"2h13m")

@chk(40, 1.0, "solved fields from attempt 3 are discarded")
def c40(t):
    return near(t, r"(solved )?fields", r"discard", 200) or near(t, r"discard", r"field", 200)

@chk(41, 1.0, "stamp boundary: CFD thermal analysis only; rating certified separately")
def c41(t):
    n = norm(t)
    return bool(re.search(r"cfd thermal analysis only", n)) and \
           bool(re.search(r"fire-resistance rating (is )?certified separately by others", n))

@chk(42, 1.0, "dated 10/10/2025")
def c42(t):
    return "10/10/2025" in norm(t)

def run(text):
    res = []
    for i, w, label, fn in sorted(CHECKS):
        try:
            ok = bool(fn(text))
            err = None
        except Exception as e:
            ok, err = False, f"{e.__class__.__name__}: {e}"
        res.append({"index": i, "weight": w, "label": label, "pass": ok, "error": err})
    return res

if __name__ == "__main__":
    text = open(sys.argv[1], encoding="utf-8", errors="replace").read()
    res = run(text)
    red = [r for r in res if not r["pass"]]
    got = sum(r["weight"] for r in res if r["pass"]); tot = sum(r["weight"] for r in res)
    for r in red:
        print(f"RED  #{r['index']:2d} w={r['weight']:4.1f}  {r['label']}" + (f"  [{r['error']}]" if r["error"] else ""))
    print(f"\npassed {len(res)-len(red)}/{len(res)} criteria, weight {got:.1f}/{tot:.1f}")
    sys.exit(1 if red else 0)
