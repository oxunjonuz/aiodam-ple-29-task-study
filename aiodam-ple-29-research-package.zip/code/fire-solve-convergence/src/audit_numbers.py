#!/usr/bin/env python3
"""Strict number audit: every *distinctive* number in the note (a decimal with 2+ places, or an integer of 3+
digits) must match, exactly and at its own precision, either a literal in the case record or a value compute.py
derived. Short integers and section numbers are excluded: a 1.1 MB corpus contains every one of them somewhere,
so matching them would prove nothing.
"""
import json, re, sys, os
from collections import Counter

REC = "/work/fsc/corpus"
COMP = json.load(open("/work/fsc/out/computed.json"))

def record_literals():
    toks = set()
    for f in os.listdir(REC):
        try: t = open(os.path.join(REC, f), encoding="utf-8", errors="replace").read()
        except OSError: continue
        for m in re.finditer(r"\d[\d,]*(?:\.\d+)?", t):
            toks.add(m.group(0).replace(",", ""))
    return toks

def derived_strings(o, out):
    """Every string a value takes when formatted at 0..6 decimals, plus the rounded forms of derived results."""
    if isinstance(o, dict):
        for v in o.values(): derived_strings(v, out)
    elif isinstance(o, list):
        for v in o: derived_strings(v, out)
    elif isinstance(o, (int, float)) and not isinstance(o, bool):
        for dp in range(0, 7): out.add(f"{o:.{dp}f}")

ALLOWED = record_literals()
derived_strings(COMP, ALLOWED)
# values the note derives by one arithmetic step on the record, stated at their own precision
EXTRA = {
 "31.10":"8 s + 20 x 1.1547005 s = 31.09401 s, floored up", "31.09":"one hundredth below 31.10",
 "0.0461":"floor(T/25 to 4 dp)", "0.0462":"next step up, fails the 25-sample rule", "0.0460":"1.15/25",
 "0.046188":"T/25", "23.09":"20 periods", "23.09401":"20 x 1.1547005",
 "4.470":"5.75 h x 31.09401 / 40.00", "26.82":"6 x 4.470", "2.21357":"6.6833 - 4.4698",
 "0.143750":"5.75/40", "1.4952":"6.6833/4.4698", "1.342,754":"sum of the four non-atmosphere zones",
 "1342754":"sum of the four non-atmosphere zones", "19.9965":"(31.09-8)/T",
}
ALLOWED |= {k.replace(",", "") for k in EXTRA}
# section numbers the note cites (references, not quantities)
ALLOWED |= {f"{a}.{b}" for a in range(1,10) for b in range(1,9)}

text = open(sys.argv[1], encoding="utf-8", errors="replace").read()
# a decimal split by the line wrapper ("308\n.5 K") is one token, not two
text = re.sub(r"(\d)\s*\n\s*\.(\d)", r"\1.\2", text)
toks = re.findall(r"(?<![\w.])\d[\d,]*(?:\.\d+)?(?![\w.])", text)
distinctive = [t for t in toks if ("." in t and len(t.split(".")[1]) >= 2) or len(t.replace(",", "")) >= 3]
unknown = []
for t in distinctive:
    plain = t.replace(",", "")
    if plain in ALLOWED: continue
    # a time step written as h/m or a date is not a quantity to audit here
    unknown.append(t)
# bearings written with a leading zero are compass directions, not quantities
unknown = [t for t in unknown if not (re.fullmatch(r"0\d\d", t))]

# wall clocks and percentages get their own audit: a wrong 4 h 31 m must not slip through
HM_OK = {("4","28"), ("26","49"), ("26","48"), ("6","41"), ("5","45"), ("2","13")}
for h, m in re.findall(r"(\d+)\s*h\s*(\d+)\s*m\b", text):
    if (h, m) not in HM_OK:
        unknown.append(f"{h} h {m} m")
PCT_OK = {"0.41","0.40","0.4087","0.4071","0.00","84","80","7.5","1.5","100","15","10"}
for p in re.findall(r"(\d+(?:\.\d+)?)\s*%", text):
    if p not in PCT_OK:
        unknown.append(f"{p} %")
c = Counter(unknown)
print(f"{len(toks)} numeric tokens, {len(distinctive)} distinctive; {sum(c.values())} unexplained")
for t, n in c.most_common(40):
    i = text.find(t)
    print(f"  {t!r} x{n}   ...{text[max(0,i-70):i+45]!r}...")
sys.exit(1 if c else 0)
