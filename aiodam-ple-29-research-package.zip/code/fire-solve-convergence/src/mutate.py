#!/usr/bin/env python3
"""Mutation campaign on the disposition.

Each mutation breaks exactly one claim, in every place the document states it (prose and
table cells), is rendered by the task's own transform.py, and read by checks.py. A
mutation is CAUGHT only when a non-empty list of criteria goes red. A survivor is a hole
in the reader (or an equivalent mutation) and is reported, not hidden.
"""
import json, os, subprocess, sys
from docx import Document
sys.path.insert(0, "/work/fsc/src")
import checks

BASE = "/work/fsc/out/CFDME-2025-041_transient_solve_disposition_revA.docx"
TR   = "/work/ple-dataset/tasks/fire-solve-convergence/tests/tools/verifiers/deps/transform.py"
VARD = "/work/fsc/mut"
os.makedirs(VARD, exist_ok=True)

def rewrite(doc, pairs, cell_pairs):
    hits = 0
    def fix(par, exact_only=False):
        nonlocal hits
        whole = "".join(r.text for r in par.runs)
        new = whole
        if exact_only:
            for old, rep in cell_pairs:
                if new.strip() == old:
                    new = rep; break
        else:
            for old, rep in pairs:
                if old in new:
                    new = new.replace(old, rep)
        if new != whole:
            hits += 1
            for r in par.runs[1:]:
                r._element.getparent().remove(r._element)
            if par.runs: par.runs[0].text = new
            else: par.add_run(new)
    for p in doc.paragraphs: fix(p)
    for t in doc.tables:
        for row in t.rows:
            for c in row.cells:
                for p in c.paragraphs: fix(p)          # substring pairs apply everywhere
    for t in doc.tables:
        for row in t.rows:
            for c in row.cells:
                for p in c.paragraphs: fix(p, exact_only=True)
    for s in doc.sections:
        for p in s.footer.paragraphs: fix(p)
        for p in s.header.paragraphs: fix(p)
    return hits

M = [
 ("M01", "#1 predicted frequency 0.87 -> 0.88 Hz", [("0.87 Hz", "0.88 Hz")], [], [1]),
 ("M02", "#3 agreement 0.41 -> 0.40 percent", [("0.41 %", "0.40 %")], [], [3]),
 ("M03", "#10 write interval 0.0461 -> 0.0462 s", [("0.0461 s", "0.0462 s")], [], [10]),
 ("M04", "#11 end time 31.10 -> 31.09 s", [("31.10 s", "31.09 s")], [], [11]),
 ("M05", "#4 'no steady solution' turned into a positive statement",
  [("No steady solution exists for this problem", "A steady solution exists for this problem"),
   ("no time-invariant flow field exists", "a time-invariant flow field exists"),
   ("the flow has no time-invariant state", "the flow has a time-invariant state"),
   ("a flow that has no steady state", "a flow that has a steady state"),
   ("There is no steady state to converge to.", "There is a steady state to converge to.")], [], [4]),
 ("M06", "#5 four angular directions -> eight", [("four angular directions", "eight angular directions")], [], [5]),
 ("M07", "#6 band split 2.5 -> 3.0 micrometres", [("2.5 micrometres", "3.0 micrometres")], [], [6]),
 ("M08", "#7 closure turned into k-epsilon",
  [("large-eddy simulation with a WALE sub-grid closure", "steady RANS with a k-epsilon closure"),
   ("WALE", "k-epsilon"), ("dynamic Smagorinsky", "k-epsilon")], [], [7]),
 ("M09", "#8 writeControl adjustableRunTime -> timeStep", [("adjustableRunTime", "timeStep")], [], [8]),
 ("M10", "#9 maxDeltaT 0.01 -> 0.02 s",
  [("maxDeltaT 0.01 s", "maxDeltaT 0.02 s")], [("0.01 s", "0.02 s")], [9]),
 ("M11", "#12 delivered endTime 2000 -> 3000",
  [("2000 iterations × 0.01 s = 20.00 s", "3000 iterations × 0.01 s = 20.00 s"),
   ("the delivered endTime of 2000 outer iterations", "the delivered endTime of 3000 outer iterations")],
  [("2000 (counted as outer iterations)", "3000 (counted as outer iterations)")], [12]),
 ("M12", "#14 attempt 3 said to have run on the study grid",
  [("The attempt ran on the production conjugate mesh", "The attempt ran on the fine study grid"),
   ("production conjugate mesh", "fine study grid"),
   ("11,214,862-cell", "11,196,000-cell"), ("11,214,862 cells", "11,196,000 cells")], [], [14]),
 ("M13", "#15 five cell zones -> four", [("five cell zones", "four cell zones")], [], [15]),
 ("M14", "#16 Pope fraction 0.84 -> 0.72", [("0.84 (84 %)", "0.72 (72 %)")], [], [16]),
 ("M15", "#17 scope reversed: study said to cover the solid and tie regions",
  [("are outside the scope of the three-grid verification", "are inside the scope of the three-grid verification"),
   ("What it does not cover", "What else it covers"),
   ("so nothing about the conjugate heat transfer", "so everything about the conjugate heat transfer")], [], [17]),
 ("M16", "#18 study meshes carry two zones, one solid",
  [("carries a single cell zone, which is fluid", "carries two cell zones, one of them solid")], [], [18]),
 ("M17", "#19 six boundary patches -> four", [("six boundary patches", "four boundary patches")], [], [19]),
 ("M18", "#20 inlet reference velocity 8.0 -> 12.0 m/s", [("Uref = 8.0 m/s", "Uref = 12.0 m/s")], [], [20]),
 ("M19", "#21 EDC replaced",
  [("EDC carries forward unchanged", "EDC is replaced by a mixture-fraction model"),
   ("EDC combustion carried forward unchanged", "EDC combustion replaced by a mixture-fraction model")], [], [21]),
 ("M20", "#22 delivered flow direction called correct",
  [("and does not describe a wind from 240 degrees", "and correctly describes a wind from 240 degrees")], [], [22]),
 ("M21", "#23 inlet vector transposed",
  [("(0.866, 0.500, 0)", "(0.500, 0.866, 0)"), ("(cos 30°, sin 30°, 0)", "(cos 60°, sin 60°, 0)")], [], [23]),
 ("M22", "#24 roughness attributed to the met record",
  [("it is not sourced from the pull and the record holds no other basis for it",
    "it is taken from the site meteorological record, which is where a roughness length is carried")], [], [24]),
 ("M23", "#25 temperature-dependent table claimed on file",
  [("There is no temperature-dependent property table for the concrete leaves or for the steel ties anywhere in the record.",
    "A temperature-dependent property table for the concrete leaves and the steel ties is on file.")], [], [25]),
 ("M24", "#26 one case 4 h 28 m -> 4 h 30 m", [("4 h 28 m", "4 h 30 m")], [], [26]),
 ("M25", "#27 matrix 26 h 49 m -> 26 h 50 m", [("26 h 49 m", "26 h 50 m")], [], [27]),
 ("M26", "#28 core-count record claim removed",
  [("and no core allocation at all for the fine grid", "and the same core allocation as the other two grids"),
   ("The allocation behind the rate is therefore not recorded.", "The allocation behind the rate is therefore on record.")], [], [28]),
 ("M27", "#30 solver-stack verdict flipped: different families",
  [("the study and the production case both run the same reacting solver family",
    "the study and the production case run different solver families")], [], [30]),
 ("M28", "#31 max Courant 0.90 -> 0.80",
  [("maximum Courant number of 0.90 against the 0.9 ceiling", "maximum Courant number of 0.80 against the 0.9 ceiling")], [], [31]),
 ("M29", "#32 time-step comparison reversed",
  [("will advance at a smaller average time step than the 0.0022 s", "will advance at the same average time step as the 0.0022 s")], [], [32]),
 ("M30", "#33 lower bound -> firm estimate",
  [("are a lower bound on the true cost", "are a firm estimate of the true cost"),
   ("are a lower bound, not a firm figure", "are a firm estimate, not a bound")], [], [33]),
 ("M31", "#34 benchmark requirement moved off the production mesh",
  [("requires a benchmark run on the production conjugate mesh", "requires a benchmark run on the fine study grid")], [], [34]),
 ("M32", "#35/#36 contingency and overhead applied",
  [("No contingency, margin or risk multiplier is applied to either figure, and no overhead percentage is applied to either "
    "figure.",
    "A 15 % contingency and risk multiplier is applied to either figure, and a 10 % overhead percentage is applied to either "
    "figure.")], [], [35, 36]),
 ("M33", "#37 attempt-3 consumption misquoted", [("424.3 CPU-hours", "442.3 CPU-hours")], [], [37]),
 ("M34", "#38 ratio 1.50 -> 1.20", [("1.50 times the solver wall clock", "1.20 times the solver wall clock")], [], [38]),
 ("M35", "#39 excess 2 h 13 m -> 2 h 14 m", [("2 h 13 m", "2 h 14 m")], [], [39]),
 ("M36", "#40 fields retained",
  [("Nothing of the solved fields: they are discarded", "Nothing of the solved fields: they are retained as the LES initial condition"),
   ("The solved fields from attempt 3 are discarded.", "The solved fields from attempt 3 are retained.")], [], [40]),
 ("M37", "#41 stamp boundary altered",
  [("CFD thermal analysis only. Fire-resistance rating certified separately by others.",
    "CFD thermal analysis and fire-resistance rating. Fire-resistance rating certified separately by others.")], [], [41]),
 ("M38", "#42 date moved to 10/11/2025", [("10/10/2025", "10/11/2025")], [], [42]),
 ("M39", "#2 closing-narrative period re-attributed",
  [("The closing narrative of the attempt-3 log", "The operator's covering email")], [], [2]),
 ("M40", "#13 delivered startFrom said to be latestTime",
  [("startFrom | startTime", "startFrom | startTime")], [("startTime", "latestTime")], [13]),
 ("M41", "#0 plateau re-labelled as numerical noise", [("puffing", "residual")], [], [0]),
 ("M42", "#29 fixed-mesh verdict flipped to Met",
  [("The benchmark ran on the 11,196,000-cell fluid-only plume mesh, which carries none of the wall assembly, the cavity or the ties.",
    "The benchmark ran on the production conjugate mesh, which carries the wall assembly, the cavity and the ties."),
   ("Not met", "Met")], [], [29]),
]


def render(docx_path, pdf_path):
    r = subprocess.run(["/work/venv-verifier/bin/python", TR, "--input", docx_path, "--output", pdf_path,
                        "--transformation", "docx_to_pdf"], capture_output=True, text=True)
    if r.returncode != 0: return None, r.stdout + r.stderr
    t = subprocess.run(["pdftotext", "-layout", pdf_path, "-"], capture_output=True, text=True)
    return t.stdout, ""

base_text = open("/work/fsc/out/memo.txt", encoding="utf-8").read()
print("baseline red:", sorted(r["index"] for r in checks.run(base_text) if not r["pass"]) or "none")

results = []
for mid, desc, pairs, cell_pairs, expected in M:
    docx = os.path.join(VARD, f"{mid}.docx"); pdf = os.path.join(VARD, f"{mid}.pdf")
    d = Document(BASE); hits = rewrite(d, pairs, cell_pairs); d.save(docx)
    text, err = render(docx, pdf)
    if text is None:
        results.append(dict(id=mid, desc=desc, expected=expected, red=[], verdict="RENDER FAILED", hits=hits)); continue
    red = sorted(r["index"] for r in checks.run(text) if not r["pass"])
    ok = all(e in red for e in expected) and bool(red) and hits > 0
    results.append(dict(id=mid, desc=desc, expected=expected, red=red, verdict="caught" if ok else "SURVIVED", hits=hits))

for r in results:
    print(f"{r['id']} {r['verdict']:9s} hits={r['hits']} expected={r['expected']} red={r['red']} :: {r['desc']}")
print(f"\ncaught {sum(1 for r in results if r['verdict']=='caught')}/{len(results)}")
json.dump(results, open("/work/fsc/out/mutations.json","w"), indent=1)
