import os, subprocess, sys, re
ROOT="/work/ple-dataset/tasks/fire-solve-convergence/environment/files"
OUT="/work/fsc/corpus"
import docx, openpyxl, fitz
n=0
for dp,dn,fn in os.walk(ROOT):
    for f in sorted(fn):
        src=os.path.join(dp,f)
        rel=os.path.relpath(src,ROOT)
        dst=os.path.join(OUT, rel.replace('/','__')+'.txt')
        if os.path.exists(dst) and os.path.getsize(dst)>0:
            n+=1; continue
        text=None
        lo=f.lower()
        try:
            if lo.endswith('.pdf'):
                r=subprocess.run(['pdftotext','-layout',src,'-'],capture_output=True,text=True,timeout=120)
                text=r.stdout
            elif lo.endswith('.docx'):
                d=docx.Document(src)
                parts=[]
                for p in d.paragraphs:
                    parts.append(p.text)
                for ti,t in enumerate(d.tables):
                    parts.append(f'[TABLE {ti}]')
                    for row in t.rows:
                        parts.append(' | '.join(c.text.strip() for c in row.cells))
                text='\n'.join(parts)
            elif lo.endswith('.xlsx'):
                wb=openpyxl.load_workbook(src,data_only=True)
                parts=[]
                for ws in wb.worksheets:
                    parts.append(f'[SHEET {ws.title}] dims={ws.dimensions}')
                    for row in ws.iter_rows(values_only=True):
                        if any(v is not None for v in row):
                            parts.append(' | '.join('' if v is None else str(v) for v in row))
                text='\n'.join(parts)
            elif lo.endswith(('.txt','.csv','.eml','.json','.md','')):
                text=open(src,encoding='utf-8',errors='replace').read()
            elif lo.endswith(('.fcstd','.png','.whl')):
                text='[BINARY %s %d bytes]'%(lo,os.path.getsize(src))
            else:
                text='[UNKNOWN %s]'%lo
        except Exception as e:
            text='[ERROR %s: %s]'%(lo,e)
        open(dst,'w',encoding='utf-8').write(text or '')
        n+=1
print('dumped',n)
