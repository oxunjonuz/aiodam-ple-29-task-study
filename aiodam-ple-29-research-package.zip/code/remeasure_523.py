#!/usr/bin/env python3
"""Re-measure every checks / checks-judge task from the submission file that is on disk NOW.

Each run: sha256 of the submission before -> the task's own harness -> sha256 after.
The two hashes must agree (nothing touched the submission) and the numbers are written to
<task>/results_523/RESULT.json with the submission path and hash that produced them.

Harness kinds, read from tests/:
  corrino   : tests/test.sh + harbor_adapter.py + paper_score.py  (offline_grade.sh runs that chain)
  evaluator : tests/evaluator/frontier_eval/{evaluate.py|run_eval.sh}
  verify    : tests/verify.py -> grading/verification/run_grade.py -> tests/paper_score.py
"""
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

PY = "/work/venv-verifier/bin/python"
RIG = "/work/ple-rig/offline_grade.sh"

# task -> (kind, submission file on disk now)
TASKS = {
    "cooling-water-flush-plan": ("corrino", "/work/cw/ws/output/submission.zip"),
    "data-hall-device-takeoff": ("corrino", "/work/ple-solve/data-hall-device-takeoff/output/submission.zip"),
    "division-26-specifications": (
        "corrino", "/work/ple-solve/division-26-specifications/build/stage2/submission.zip"),
    "heat-rejection-life-cycle-cost": (
        "corrino", "/work/ple-solve/heat-rejection-life-cycle-cost/out/submission.zip"),
    "roof-deck-design": ("corrino", "/work/ple-solve/roof-deck-design/submission.zip"),
    "seismic-diaphragm-shear": ("corrino", "/work/ple-solve/seismic-diaphragm-shear/submission.zip"),
    "data-hall-mep-routing": ("evaluator", "/work/ple-solve/data-hall-mep-routing/output/solution.py"),
    "data-hall-mep-routing-offset": (
        "evaluator", "/work/ple-solve/data-hall-mep-routing-offset/output/solution.py"),
    "frame-extension-method": ("verify", "/work/ple-solve/frame-extension-method/out/pkg/submission.zip"),
    "foundation-strategy": ("verify", "/work/ple-solve/foundation-strategy/out/submission.zip"),
    "lv-cable-sizing": ("verify", "/work/lv-cable-sizing/build3/submission.zip"),
    "eor-review-corrections": ("verify", "/work/ple-solve/eor-review-corrections/build/submission.zip"),
    "mv-conveyance-study": ("corrino", "/work/ple-solve/mv-conveyance-study/build/submission.zip"),
    "wind-diaphragm-shear": ("corrino", "/work/ple-solve/wind-diaphragm-shear/out/submission.zip"),
    "data-center-site-model": ("evaluator", "/work/ple-solve/data-center-site-model/ws/submission/model.ifc"),
}

TASKDIR = Path("/work/ple-dataset/tasks")


def sha(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def run(cmd, **kw):
    return subprocess.run(cmd, capture_output=True, text=True, **kw)


def do_corrino(task, sub, out):
    r = run(["bash", RIG, task, sub, str(out)])
    reward = None
    for line in r.stdout.splitlines():
        if line.startswith("REWARD="):
            reward = line.split("=", 1)[1]
    paper = out / "paper.json"
    metrics = out / "logs" / "metrics.json"
    pap = json.loads(paper.read_text()) if paper.is_file() else None
    num = pap.get("reward") if isinstance(pap, dict) and isinstance(pap.get("reward"), (int, float)) else (
        float(reward) if reward not in (None, "") else None)
    return {"reward": num,
            "paper": pap,
            "metrics": json.loads(metrics.read_text()) if metrics.is_file() else None,
            "stdout_tail": r.stdout[-400:]}


def do_evaluator(task, sub, out):
    tests = TASKDIR / task / "tests"
    bench = out / "bench"
    if bench.exists():
        subprocess.run(["rm", "-rf", str(bench)])
    bench.parent.mkdir(parents=True, exist_ok=True)
    subprocess.run(["cp", "-a", str(tests / "evaluator") + "/.", str(bench)], check=True)
    cand_rel = "output/solution.py" if sub.endswith(".py") else "submission/model.ifc"
    (bench / Path(cand_rel).parent).mkdir(parents=True, exist_ok=True)
    subprocess.run(["cp", sub, str(bench / cand_rel)], check=True)
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1", OPENBLAS_NUM_THREADS="1",
               OMP_NUM_THREADS="1", MKL_NUM_THREADS="1")
    if (bench / "frontier_eval" / "evaluate.py").is_file():
        args = [PY, str(bench / "frontier_eval" / "evaluate.py"), str(bench / cand_rel)]
        r = subprocess.run(args, cwd=str(bench), capture_output=True, text=True, env=env)
    else:
        shim = out / "shim"; shim.mkdir(exist_ok=True)
        (shim / "python3").write_text(f'#!/bin/sh\n"{PY}" "$@"\nrc=$?\necho $rc > {shim}/exit\nexit $rc\n')
        (shim / "python3").chmod(0o755)
        r = subprocess.run(["bash", str(bench / "frontier_eval" / "run_eval.sh"),
                            str(shim / "python3"), str(bench), str(bench / cand_rel)],
                           cwd=str(bench), capture_output=True, text=True, env=env)
    m = bench / "metrics.json"
    metrics = json.loads(m.read_text()) if m.is_file() else None
    return {"reward": None,
            "metrics": metrics,
            "eval_exit": r.returncode,
            "stderr_tail": r.stderr[-400:]}


def do_verify(task, sub, out):
    """run_grade.py --no-judge -> paper_score score -> apply, the chain tests/test.sh runs."""
    tests = TASKDIR / task / "tests"
    grading = tests / "grading"
    out.mkdir(parents=True, exist_ok=True)
    env = dict(os.environ, PATH="/usr/local/bin:/usr/bin:/bin", PYTHONDONTWRITEBYTECODE="1")
    # no split env here: tests/test.sh sets none, so each grader must run at its own default
    extra = [] if task == "frame-extension-method" else ["--no-judge"]
    rg = run([PY, str(grading / "verification" / "run_grade.py"), sub,
              "--metrics-out", str(out / "metrics.json"),
              "--artifacts-out", str(out / "artifacts.json")] + extra, env=env)
    m = out / "metrics.json"
    metrics = json.loads(m.read_text()) if m.is_file() else None
    artifacts = json.loads((out / "artifacts.json").read_text()) if (out / "artifacts.json").is_file() else {}
    grade = {"task_id": task, "score_key": "combined_score",
             "reward": (metrics or {}).get("combined_score"),
             "exec_status": (metrics or {}).get("exec_status"),
             "valid": (metrics or {}).get("valid"),
             "judge_status": (metrics or {}).get("judge_status"),
             "metrics": metrics, "artifacts": artifacts}
    (out / "grade.json").write_text(json.dumps(grade, indent=1, default=str))
    ps = run([PY, str(tests / "paper_score.py"), "score", "--verifier", str(out),
              "--submission", sub, "--grader-dir", str(grading)])
    paper = None
    if ps.returncode == 0 and ps.stdout.strip():
        try:
            paper = json.loads(ps.stdout.strip().splitlines()[-1])
        except Exception:
            paper = None
    if paper is not None:
        (out / "paper_score.json").write_text(json.dumps(paper, indent=1))
        subprocess.run([PY, str(tests / "paper_score.py"), "apply", "--result",
                        str(out / "paper_score.json"), "--grade", str(out / "grade.json")],
                       capture_output=True, text=True)
    return {"reward": (paper or {}).get("reward"),
            "paper": paper, "metrics": metrics,
            "run_grade_exit": rg.returncode, "paper_exit": ps.returncode,
            "run_grade_err": rg.stderr[-300:], "paper_err": ps.stderr[-300:]}


only = set(sys.argv[1:])
for task, (kind, sub) in TASKS.items():
    if only and task not in only:
        continue
    s = Path(sub)
    out = Path("/work/ple-solve") / task / "results_523"
    if not s.is_file():
        print(f"{task}: SUBMISSION MISSING {sub}")
        continue
    before = sha(s)
    out.mkdir(parents=True, exist_ok=True)
    if kind == "corrino":
        got = do_corrino(task, sub, out)
    elif kind == "evaluator":
        got = do_evaluator(task, sub, out)
    else:
        got = do_verify(task, sub, out)
    after = sha(s)
    rec = {"task": task, "kind": kind, "submission": {"path": sub, "size": s.stat().st_size,
           "sha256_before": before, "sha256_after": after, "unchanged": before == after},
           "result": got}
    (out / "RESULT.json").write_text(json.dumps(rec, indent=1, default=str))
    m = got.get("metrics") or {}
    reward = got.get("reward")
    print(f"{task}: reward={reward} combined={m.get('combined_score')} "
          f"p={m.get('mean_p')} h={m.get('hard_pass_rate')} judge={m.get('judge_status')} "
          f"sha={before[:12]} same={before == after}")
